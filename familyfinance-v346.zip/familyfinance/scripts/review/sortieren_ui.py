# Review-Skript (Stand v342). In einer KOPIE des Projekts im Ordner backend/ ausführen; zwischen zwei Läufen ~4 s warten (Port 8420).
# Prüft im Browser (iPhone-Breite, Demo-Daten): Statuszeile, Monatsabschluss, Zähler "n offen", Karte "Offene Bankumsätze",
# Sortier-Dialog (Überlauf, Alltag, Zuordnen), eingeklappte Import-Bereiche, Fehlermeldung bei abgelehnter Schreibaktion.
# Exit-Code 1 bei Befund.
import sys, threading, time, warnings
warnings.filterwarnings("ignore"); sys.path.insert(0, '.')
import database, auth, demo_data, bank_routes as br
database.init_db(); demo_data.generate_demo_db()
import database as d
d._use_demo_db.set(True)
conn = d.get_connection()
acc = {"iban": "DE0011112222333344", "account_number": "123", "label": "Girokonto", "balance": "1"}
def tx(dt, a, n, p): return {"booking_date": dt, "value_date": dt, "amount": a, "counterparty_name": n, "purpose": p, "currency": "EUR"}
res = {"status": "ok", "accounts": [acc], "transactions_by_account": [{"account": acc, "transactions": (
    [tx(f"2026-10-0{i}", f"-{20 + i}.00", "AMAZON EU SARL", "Bestellung " + str(i)) for i in range(1, 5)]
    + [tx(f"2026-10-1{i}", "-35.50", "ALDI SUED", "Einkauf") for i in range(3)]
    + [tx("2026-10-20", "-12.00", "Ein sehr sehr langer Empfängername ohne Leerzeichen-Pause AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Zweck " + "x" * 120)])}]}
br.store_sync_result(conn, "bank_conn_1", res)
conn.commit(); conn.close()
import uvicorn, app as appmod
from fastapi.testclient import TestClient
TestClient(appmod.app).post('/api/auth/setup', json={'username': 'tester', 'password': 'testtest123'})
srv = uvicorn.Server(uvicorn.Config(appmod.app, host="127.0.0.1", port=8420, log_level="error"))
threading.Thread(target=srv.run, daemon=True).start(); time.sleep(3)
from playwright.sync_api import sync_playwright
tok = auth._serializer.dumps({'stage': 'full', 'iat': 'x', 'demo': True})
FAILS = []
def check(name, ok, info=""):
    print(("✓ " if ok else "✗ ") + name + (f" – {info}" if info != "" else ""))
    if not ok: FAILS.append(name)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True, device_scale_factor=2)
    ctx.add_cookies([{'name': 'ffz_session', 'value': tok, 'url': 'http://localhost:8420'}])
    pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)[:120]))
    pg.goto("http://localhost:8420")
    for _ in range(40):   # auf die Anzeige warten statt eine Zeit zu raten (kalter Server; die Seite lädt beim Start ggf. einmal neu)
        try:
            if pg.evaluate("document.getElementById('status-line').style.display==='flex' && document.getElementById('monthclose').style.display==='block'"):
                break
        except Exception:
            pass
        pg.wait_for_timeout(500)

    print("== Dashboard")
    st = pg.evaluate("document.getElementById('status-line').innerText")
    check("Statuszeile sichtbar mit Bank/Sicherung", "Bank" in st and "Sicherung" in st, st.replace("\n", " | "))
    check("Statuszeile ohne Überlauf", pg.evaluate("document.getElementById('status-line').scrollWidth <= innerWidth + 1"))
    mc = pg.evaluate("document.getElementById('monthclose-summary')?.innerText || ''")
    check("Monatsabschluss sichtbar", "Monatsabschluss" in mc, mc)
    badge = pg.evaluate("document.getElementById('duedates-count').innerText")
    check("Zähler an der Hinweiskarte nur bei echten Hinweisen", badge == "", badge)
    hint = pg.evaluate("[...document.querySelectorAll('#duedates-list li')].map(l=>l.innerText).join(' || ')")
    check("keine Mahnung zu offenen Bankumsätzen im Dashboard", "ohne Zuordnung" not in hint, hint[:80])
    pg.screenshot(path="/tmp/sortieren_dashboard.png")

    print("== Ausgaben-Tab")
    pg.evaluate("document.querySelector('[data-tab=tab-contracts]').click()"); pg.wait_for_timeout(1500)
    card = pg.evaluate("getComputedStyle(document.getElementById('bank-open-card')).display")
    check("Karte 'Offene Bankumsätze' sichtbar", card != "none", pg.evaluate("document.getElementById('bank-open-text').innerText"))
    check("Import-Bereich eingeklappt", pg.evaluate("[...document.querySelectorAll('#tab-contracts .maintain-group')].every(d=>!d.open)"))
    check("Beleg-Upload bleibt außerhalb des Pflege-Bereichs", pg.evaluate("!document.getElementById('upload').closest('.maintain-group')"))
    pg.evaluate("document.getElementById('bank-open-sort-btn').click()"); pg.wait_for_timeout(1500)
    rows = pg.locator(".sort-row").count()
    check("Sortier-Dialog zeigt Gruppen", rows == 3, rows)
    check("kein seitlicher Überlauf im Dialog", pg.evaluate("[...document.querySelectorAll('#bank-sort-overlay *')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.right>innerWidth+1||r.left<-1)}).length") == 0)
    check("Tippflächen >= 40 px", pg.evaluate("[...document.querySelectorAll('#bank-sort-overlay button, #bank-sort-overlay select')].filter(e=>e.getBoundingClientRect().height<40).length") == 0)
    pg.screenshot(path="/tmp/sortieren_dialog.png")
    pg.locator("[data-sort-everyday]").first.click(); pg.wait_for_timeout(1800)
    check("Unkategorisiert: Gruppe verschwindet", pg.locator(".sort-row").count() == rows - 1, pg.locator(".sort-row").count())
    check("Rückmeldung (Toast)", "als unkategorisiert markiert" in pg.evaluate("document.getElementById('app-toast')?.innerText || ''"))
    # Zuordnen über Auswahl
    sel = pg.locator("[data-sort-target]").first
    val = sel.evaluate("s=>[...s.options].find(o=>o.value.startsWith('contract:'))?.value || ''")
    if val:
        sel.select_option(val); pg.wait_for_timeout(1800)
        check("Zuordnen: Gruppe verschwindet", pg.locator(".sort-row").count() == rows - 2, pg.locator(".sort-row").count())
    pg.once("dialog", lambda d: d.accept())
    pg.evaluate("document.getElementById('bank-sort-all-btn').click()"); pg.wait_for_timeout(1800)
    check("Alle übrigen unkategorisiert: Liste leer", pg.locator(".sort-row").count() == 0, pg.locator(".sort-row").count())
    pg.evaluate("document.getElementById('bank-sort-close-btn').click()"); pg.wait_for_timeout(800)
    check("Karte verschwindet, wenn alles abgelegt ist", pg.evaluate("getComputedStyle(document.getElementById('bank-open-card')).display") == "none")

    print("== Zentrale Fehlermeldung bei abgelehnter Schreibaktion")
    pg.evaluate("document.getElementById('app-toast')?.remove()")
    pg.evaluate("authedFetch('/api/payslips/999999/confirm', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({income_id:1})})")
    pg.wait_for_timeout(1000)
    t = pg.evaluate("document.getElementById('app-toast')?.innerText || ''")
    check("Fehler wird sichtbar gemeldet", "Nicht gespeichert" in t and "nicht gefunden" in t.lower(), t)

    print("== Einnahmen-Tab")
    pg.evaluate("document.querySelector('[data-tab=tab-income]').click()"); pg.wait_for_timeout(1200)
    check("Einzel-Upload für Gehaltsabrechnung bleibt sichtbar", pg.evaluate("getComputedStyle(document.getElementById('payslip-upload')).display") != "none")
    check("Sammelimport im eingeklappten Pflege-Bereich", pg.evaluate("document.getElementById('payslip-bulk-upload').closest('.maintain-group')?.open === false"))
    check("Seite ohne seitlichen Überlauf", pg.evaluate("document.documentElement.scrollWidth <= innerWidth + 1"))
    check("keine JS-Fehler", not errs, errs)
    b.close()
print()
if FAILS:
    print("✗ FEHLER:", FAILS); sys.exit(1)
print("ALLES GRÜN")
