"""
Zuordnung von Bankumsätzen zu Verträgen (Ausgaben) und Einnahmen -- plus die
daraus ableitbaren Hinweise (Preisänderung, ausbleibende Zahlung, neue
wiederkehrende Abbuchung).

GRUNDSÄTZE:
- Regeln entstehen NUR aus einer Handlung des Nutzers (manuelle Zuordnung).
  Vorschläge der App werden nie still übernommen.
- Eine Regel nutzt das eindeutigste vorhandene Merkmal: Gläubiger-ID +
  Mandatsreferenz (je Vertrag eindeutig) > Gläubiger-ID > IBAN > Name.
- Vertragsbeträge ändern sich nie von allein -- ein Preis-Hinweis bietet nur
  "übernehmen" an (wie beim Beleg-Import).
- Preis-Hinweis erst nach ZWEI aufeinanderfolgenden gleich abweichenden
  Buchungen; eine einzelne Abweichung (Nachzahlung, anteiliger Monat) wird
  nur dezent markiert.
- "Zahlung ausgeblieben" nur für Verträge, die bereits zugeordnete Umsätze
  haben -- läuft ein Vertrag über ein nicht angebundenes Konto, gäbe es sonst
  ständig Fehlalarme.
"""
import re
from datetime import date, timedelta
from typing import Optional

FIELD_PRIORITY = ["creditor_mandate", "creditor", "iban", "name"]
PERIOD_DAYS = {"monthly": 31, "quarterly": 92, "yearly": 366}
AMOUNT_TOLERANCE = 0.01   # Euro -- darunter gilt ein Betrag als unverändert

_CRED_RE = re.compile(r"CRED\+\s*([A-Z]{2}\d{2}[A-Z0-9]{3}[A-Z0-9]{1,28})", re.I)
_CRED_TEXT_RE = re.compile(r"Gl(?:ä|ae)ubiger-?ID[:\s]+([A-Z]{2}\d{2}[A-Z0-9]{3}[A-Z0-9]{1,28})", re.I)
_MREF_RE = re.compile(r"MREF\+\s*([^\s+]{1,35})", re.I)
_MREF_TEXT_RE = re.compile(r"Mandat(?:sref(?:erenz)?)?[:\s.]+([A-Za-z0-9\-/.]{1,35})", re.I)


def extract_sepa(purpose: Optional[str]) -> tuple:
    """Gläubiger-ID und Mandatsreferenz aus dem Verwendungszweck. Banken
    liefern sie meist als 'CRED+…'/'MREF+…' (SEPA-Strukturfelder), manche
    als Klartext ('Gläubiger-ID: …', 'Mandatsref.: …')."""
    text = purpose or ""
    cred = _CRED_RE.search(text) or _CRED_TEXT_RE.search(text)
    mref = _MREF_RE.search(text) or _MREF_TEXT_RE.search(text)
    return (cred.group(1).upper() if cred else None, mref.group(1) if mref else None)


def _norm_name(name: Optional[str]) -> str:
    n = re.sub(r"[^a-z0-9äöüß ]", " ", (name or "").lower())
    n = re.sub(r"\b(gmbh|ag|se|kg|e ?v|co|und|mbh|ltd|inc|sarl|bv)\b", " ", n)
    return re.sub(r"\s+", " ", n).strip()


def identifiers(tx: dict) -> dict:
    """Alle verfügbaren Merkmale eines Umsatzes, stärkstes zuerst."""
    ids = {}
    cred, mref = tx.get("creditor_id"), tx.get("mandate_ref")
    if cred and mref:
        ids["creditor_mandate"] = f"{cred}|{mref}"
    if cred:
        ids["creditor"] = cred
    iban = re.sub(r"\s", "", tx.get("counterparty_iban") or "").upper()
    if len(iban) >= 15:
        ids["iban"] = iban
    name = _norm_name(tx.get("counterparty_name"))
    if len(name) >= 3:
        ids["name"] = name
    return ids


def backfill_sepa(conn):
    """Gläubiger-ID/Mandat für Umsätze nachtragen, die vor v284 gespeichert wurden."""
    rows = conn.execute("SELECT id, purpose FROM bank_transactions WHERE creditor_id IS NULL AND mandate_ref IS NULL "
                        "AND purpose IS NOT NULL").fetchall()
    for r in rows:
        cred, mref = extract_sepa(r["purpose"])
        if cred or mref:
            conn.execute("UPDATE bank_transactions SET creditor_id=?, mandate_ref=? WHERE id=?", (cred, mref, r["id"]))
    conn.commit()


# ---------- Regeln ----------

def _target_exists(conn, kind: str, target_id: int) -> bool:
    table = "contracts" if kind == "contract" else "income"
    return conn.execute(f"SELECT 1 FROM {table} WHERE id=?", (target_id,)).fetchone() is not None


def find_rule(conn, tx: dict):
    ids = identifiers(tx)
    for field in FIELD_PRIORITY:
        if field in ids:
            r = conn.execute("SELECT * FROM bank_match_rules WHERE match_field=? AND match_value=?",
                             (field, ids[field])).fetchone()
            if r and _target_exists(conn, r["kind"], r["target_id"]):
                return r
    return None


def apply_rules(conn) -> int:
    """Ordnet alle noch offenen Umsätze anhand der Regeln zu. 'none' (bewusst
    keine Zuordnung) und manuelle Zuordnungen werden nie angefasst."""
    backfill_sepa(conn)
    rows = conn.execute("SELECT * FROM bank_transactions WHERE match_source IS NULL").fetchall()
    n = 0
    for tx in rows:
        rule = find_rule(conn, dict(tx))
        if rule:
            col = "contract_id" if rule["kind"] == "contract" else "income_id"
            conn.execute(f"UPDATE bank_transactions SET {col}=?, match_source='rule' WHERE id=?", (rule["target_id"], tx["id"]))
            n += 1
    conn.commit()
    return n


def assign(conn, tx_id: int, kind: str, target_id: int, learn: bool = True) -> dict:
    if kind not in ("contract", "income"):
        raise ValueError("kind muss 'contract' oder 'income' sein")
    tx = conn.execute("SELECT * FROM bank_transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx:
        raise LookupError("Umsatz nicht gefunden")
    if not _target_exists(conn, kind, target_id):
        raise LookupError("Vertrag/Einnahme nicht gefunden")
    contract_id = target_id if kind == "contract" else None
    income_id = target_id if kind == "income" else None
    conn.execute("UPDATE bank_transactions SET contract_id=?, income_id=?, match_source='manual' WHERE id=?",
                 (contract_id, income_id, tx_id))
    rule_field = None
    if learn:
        ids = identifiers(dict(tx))
        for field in FIELD_PRIORITY:
            if field in ids:
                conn.execute("INSERT INTO bank_match_rules (kind, target_id, match_field, match_value) VALUES (?,?,?,?) "
                             "ON CONFLICT(match_field, match_value) DO UPDATE SET kind=excluded.kind, target_id=excluded.target_id",
                             (kind, target_id, field, ids[field]))
                rule_field = field
                break
    conn.commit()
    retro = apply_rules(conn) if rule_field else 0
    return {"rule_field": rule_field, "also_assigned": retro}


def unassign(conn, tx_id: int, forget_rule: bool = False):
    tx = conn.execute("SELECT * FROM bank_transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx:
        raise LookupError("Umsatz nicht gefunden")
    if forget_rule:
        for field, value in identifiers(dict(tx)).items():
            conn.execute("DELETE FROM bank_match_rules WHERE match_field=? AND match_value=?", (field, value))
    conn.execute("UPDATE bank_transactions SET contract_id=NULL, income_id=NULL, match_source='none' WHERE id=?", (tx_id,))
    conn.commit()


# ---------- Vorschläge ----------

def _tokens(text: Optional[str]) -> set:
    return {t for t in _norm_name(text).split() if len(t) >= 3}


def suggestions(conn, tx_id: int, limit: int = 3) -> list:
    """Kandidaten für einen offenen Umsatz -- Ausgaben für Abbuchungen,
    Einnahmen für Gutschriften. Bewertet Namensübereinstimmung und wie nah
    der Betrag am hinterlegten Betrag liegt."""
    tx = conn.execute("SELECT * FROM bank_transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx or tx["amount"] is None:
        return []
    amount = abs(tx["amount"])
    tx_tokens = _tokens(tx["counterparty_name"]) | _tokens(tx["purpose"])
    if tx["amount"] < 0:
        rows = conn.execute("SELECT id, label, provider, amount FROM contracts WHERE COALESCE(status,'active') = 'active'").fetchall()
        kind = "contract"
    else:
        rows = conn.execute("SELECT id, label, NULL AS provider, amount FROM income WHERE COALESCE(active,1)=1").fetchall()
        kind = "income"
    scored = []
    for r in rows:
        name_hits = len(tx_tokens & (_tokens(r["label"]) | _tokens(r["provider"])))
        amt = r["amount"] or 0
        amount_score = max(0.0, 1 - abs(amount - amt) / amt) if amt else 0.0
        score = name_hits * 2 + amount_score * 1.5
        if name_hits or amount_score > 0.9:
            scored.append({"kind": kind, "id": r["id"], "label": r["label"], "provider": r["provider"],
                           "amount": amt, "score": round(score, 2)})
    scored.sort(key=lambda s: -s["score"])
    return scored[:limit]


# ---------- Hinweise (Preisänderung & Co.) ----------

def insights(conn, today: Optional[date] = None) -> dict:
    today = today or date.today()
    price_changes, deviations, missing = [], [], []
    targets = [("contract", r) for r in conn.execute(
        "SELECT id, label, amount, frequency FROM contracts WHERE COALESCE(status,'active') = 'active'")]
    targets += [("income", r) for r in conn.execute(
        "SELECT id, label, amount, frequency FROM income WHERE COALESCE(active,1)=1")]
    for kind, t in targets:
        col = "contract_id" if kind == "contract" else "income_id"
        txs = conn.execute(f"SELECT booking_date, amount FROM bank_transactions WHERE {col}=? AND amount IS NOT NULL "
                           "ORDER BY booking_date DESC, id DESC LIMIT 6", (t["id"],)).fetchall()
        if not txs:
            continue
        expected = abs(t["amount"] or 0)
        latest = abs(txs[0]["amount"])
        base = {"kind": kind, "id": t["id"], "label": t["label"], "expected": round(expected, 2),
                "actual": round(latest, 2), "last_date": txs[0]["booking_date"]}
        if abs(latest - expected) > AMOUNT_TOLERANCE:
            if len(txs) >= 2 and abs(abs(txs[1]["amount"]) - latest) <= AMOUNT_TOLERANCE:
                price_changes.append(base)   # zweimal hintereinander derselbe neue Betrag
            else:
                deviations.append(base)      # einmalig abweichend -- nur dezent
        period = PERIOD_DAYS.get(t["frequency"] or "monthly")
        try:
            last = date.fromisoformat(str(txs[0]["booking_date"])[:10])
        except ValueError:
            last = None
        if period and last and (today - last).days > period + 10:
            missing.append({**base, "days_since": (today - last).days})
    return {"price_changes": price_changes, "deviations": deviations, "missing": missing,
            "recurring_unmapped": recurring_unmapped(conn, today)}


def recurring_unmapped(conn, today: date) -> list:
    """Offene Abbuchungen desselben Empfängers in mindestens zwei
    verschiedenen Monaten mit ähnlichem Betrag -- vermutlich ein Vertrag, der
    noch nicht angelegt ist."""
    since = (today - timedelta(days=200)).isoformat()
    rows = conn.execute("SELECT * FROM bank_transactions WHERE match_source IS NULL AND amount < 0 "
                        "AND booking_date >= ? ORDER BY booking_date", (since,)).fetchall()
    groups = {}
    for tx in rows:
        ids = identifiers(dict(tx))
        key = next((f"{f}:{ids[f]}" for f in FIELD_PRIORITY if f in ids), None)
        if key:
            groups.setdefault(key, []).append(tx)
    out = []
    for key, txs in groups.items():
        months = {str(t["booking_date"])[:7] for t in txs}
        amounts = [abs(t["amount"]) for t in txs]
        if len(months) >= 2 and (max(amounts) - min(amounts)) <= max(1.0, 0.1 * max(amounts)):
            last = txs[-1]
            out.append({"counterparty_name": last["counterparty_name"], "amount": round(abs(last["amount"]), 2),
                        "months": len(months), "transaction_id": last["id"]})
    return sorted(out, key=lambda o: -o["amount"])
