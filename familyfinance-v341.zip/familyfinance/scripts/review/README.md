# Review-Skripte

Wiederholbare Prüfungen aus der Review-Runde (v301–v304). Immer in einer **Kopie** des Projekts laufen lassen
(sie legen Testdaten an und starten einen Server auf Port 8420).

| Skript | Prüft |
|---|---|
| `design.py` | Alle Tabs auf iPhone- (390 px) und Mac-Breite (1280 px), zusätzlich iPhone mit Textgröße L: seitlicher Überlauf (rechts **und links** – rechtsbündige `.row-actions` schieben zu breite Elemente nach links aus der Karte), Tippflächen < 40 px (Checkbox/Radio in einem `<label>`: zählt die Fläche der Beschriftung), Eingabefelder < 16 px (iOS-Zoom), JS-Fehler. Seit v336 auf dem iPhone (M und L) auch **alle Dialoge**, die wichtigsten mit echten Daten geöffnet (Vertragsdetails inkl. Belege, Einnahme, Rentenkonto, Vermögen, Person, Einstellungen mit Personen/Ausgaben/Versicherungen, Integrationen). Bei L zählt in Tabs nur der Seitenüberlauf, in Dialogen auch Elemente, die aus der Karte ragen. Seit v337 wird der Vermögensdialog zusätzlich für jede weitere Vermögensart (Konto, Immobilie …) geöffnet. Exit-Code 1 bei Befund. |
| `users.py` | Zwei Anwender-Szenarien (Benjamin/iPhone, Raphaela/Mac): Bankkonto zuordnen/neu anlegen, ⋯-Menü, Umsatzliste, Suche, Esc, Chat |
| `xss.py` | Bösartige Namen (`<img onerror>`) in Vermögen, Bankumsatz, Vertrag, Kategorie dürfen nie als HTML ankommen |
| `hints.py` | Karte „Erkannt aus Bankumsätzen“: Name/IBAN getrennt, Details, Ablehnen/Wiederherstellen, Überlauf auf dem iPhone |
| `fk.py` | Alle Lösch-Endpunkte mit Demodaten (inkl. Lohnabrechnung, Ablesefoto, Bank-Zuordnung): kein Serverfehler durch Fremdschlüssel, danach keine verwaisten Verweise (auch in Spalten ohne Fremdschlüssel) |
| `routen.py` | Jede API-Route hängt an der richtigen Funktion (Pfad-Platzhalter vorhanden, keine Hilfsfunktion, keine Dopplung) – auch in eingebundenen Routern. Ohne Server, Sekunden. Anlass: „Übernehmen“ von Gehaltsabrechnungen war 10.–22.10. still kaputt. |
| `bankregeln.py` | Gelernte Bank-Regeln mit Betrag (centgenau, keine Bandbreiten): ein/mehrere Ziele je Empfänger, nicht exakte Beträge bleiben offen, Preisänderung ab 1 Cent, Korrekturen, Regel vergessen, wiederkehrende Hinweise je Betrag, Migration alter Datenbanken inkl. Neu-Lernen. Ohne Server, Sekunden. |
| `rechnen.py` | Rechenlogik mit von Hand nachrechenbaren Zahlen (Intervalle, Tilgung inkl. 0 %, Vorsorge inkl. 29.02., Strom-Tagesrate, Auto/Haushalt, Kostenbeteiligung). Ohne Server, Sekunden. |
| `sicherung.py` | Sicherung außerhalb des App-Ordners (v330/v331) und CSRF-Sperre (v329): leere DB wird nicht nach außen kopiert, Obergrenze externer Kopien, externer Ordner im App-Ordner wird übersprungen, Belege-Spiegel (nur Belege, keine DBs/Schlüssel/Sicherungen/losen Dateien, nur Neues/Geändertes, löscht nie), Sonderzeichen im Pfad (Leerzeichen, #, %), Status-Abfrage; schreibende Anfragen mit `Sec-Fetch-Site: cross-site/same-site` → 403, sonst nicht. Arbeitet nur in Temp-Ordnern. Ohne Server, Sekunden. |
| `themes.py` | Alle fünf Design-Themes auf iPhone-Breite, alle Tabs **und alle Dialoge**: Felder/Knöpfe ohne sichtbare Kante (helle Themes = Fehler), Kurz-Einblendung lesbar (Kontrast ≥ 4,5), `color-scheme` passt zum Theme. Exit-Code 1 bei Fehler. |

Kniffe: Routen über `app.openapi()['paths']` auflisten (nicht `app.routes`); Zugang vorab per `POST /api/auth/setup`
einrichten, sonst verdeckt der Ersteinrichtungs-Dialog alles; Demo-Sitzung = Cookie mit `'demo': True`.

**Wichtig:** zwischen zwei Skriptläufen ca. 4 Sekunden warten, sonst ist Port 8420 noch belegt und das Skript spricht mit dem alten Server.
