"""
Zentrale DB-Verbindung. Läuft komplett lokal auf SQLite — keine Server, keine Cloud.
"""
import contextvars
import sqlite3
from contextlib import contextmanager
import re
import hashlib
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "finance.db"
DEMO_DB_PATH = BASE_DIR / "data" / "demo.db"
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"

# Pro Request gesetzt (siehe app.py-Middleware, aus dem Session-Cookie) --
# lässt ALLE bestehenden get_connection()-Aufrufe im ganzen Backend ohne jede
# Änderung automatisch auf die Demo-Datenbank umschalten, sobald der Demo-
# Modus aktiv ist. contextvars sind pro asyncio-Task isoliert, zwei
# gleichzeitige Anfragen (eine echt, eine Demo) stören sich also nie.
_use_demo_db = contextvars.ContextVar("use_demo_db", default=False)


def set_demo_context(enabled: bool):
    return _use_demo_db.set(enabled)


def reset_demo_context(token):
    _use_demo_db.reset(token)


def is_demo_active() -> bool:
    return _use_demo_db.get()


def get_connection() -> sqlite3.Connection:
    path = DEMO_DB_PATH if _use_demo_db.get() else DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30)   # bei gleichzeitigem Schreiben (z.B. Bank-Abruf im Hintergrund) bis 30 s warten statt sofort 'database is locked'
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db(real: bool = False):
    """Verbindung, die garantiert wieder geschlossen wird (v359).

        with db() as conn:
            conn.execute("UPDATE …")
            if fehlt: raise HTTPException(404, …)   # schließt trotzdem

    Ende ohne Fehler -> commit; jeder Fehler (auch HTTPException) -> rollback,
    dann close und der Fehler läuft weiter. Ohne WAL hält eine offene
    Schreibaktion sonst die ganze Datei gesperrt (andere warten bis 30 s).
    Achtung: Pythons eingebautes `with conn:` schließt NICHT -- deshalb diese Hülle.
    real=True -> immer die echte DB (wie get_real_connection, für Login/Passkeys)."""
    conn = get_real_connection() if real else get_connection()
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


def get_real_connection() -> sqlite3.Connection:
    """Wie get_connection(), aber IMMER die echte Datenbank -- unabhängig vom
    Demo-Modus. Für sicherheitsrelevante Daten (Login, Passkeys, Sitzungen,
    Fehlversuchs-Zähler), die niemals in die Demo-Datenbank ausweichen dürfen:
    sonst würde beim Umschalten in den Demo-Modus "user_exists()" in der
    frischen, leeren Demo-Datenbank nachsehen und fälschlich "noch kein
    Account eingerichtet" melden -- der Demo-Modus setzt ja gerade eine
    bereits laufende, echte Anmeldung voraus, statt sie zu ersetzen."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# Spalten, die nach dem ersten Release ergänzt wurden. CREATE TABLE IF NOT
# EXISTS ändert bestehende Tabellen nicht — ohne diese Migration würde eine
# schon vorhandene finance.db beim Öffnen mit "no such column" abstürzen.
_COLUMN_MIGRATIONS = [
    # Umsatz-Zuordnung (v284): an welchen Vertrag / welche Einnahme ein
    # Bankumsatz gehört, und wodurch ('manual' | 'rule' | 'none' = bewusst
    # keine Zuordnung, Regeln dürfen den Umsatz dann nicht mehr anfassen).
    ("bank_transactions", "contract_id", "INTEGER"),
    ("bank_transactions", "income_id", "INTEGER"),
    ("bank_transactions", "match_source", "TEXT"),
    ("bank_transactions", "creditor_id", "TEXT"),      # SEPA Gläubiger-ID (CRED+)
    ("bank_transactions", "mandate_ref", "TEXT"),      # SEPA Mandatsreferenz (MREF+)
    # v306: Konten, die nicht uns gehören (z. B. Vollmachtskonten) -- werden beim Abruf übersprungen.
    ("bank_accounts", "ignored", "INTEGER NOT NULL DEFAULT 0"),
    # v307: Darlehenskonto der Bank <-> Vertrag (Haus · Finanzierung); Restschuld kommt dann von der Bank.
    ("bank_accounts", "contract_id", "INTEGER"),
    ("app_user", "totp_secret", "TEXT"),  # NULL = TOTP nicht eingerichtet, Passkey bleibt Pflicht-2FA
    ("contracts", "subcategory", "TEXT"),
    ("contracts", "source", "TEXT"),
    ("contracts", "updated_at", "TIMESTAMP"),
    ("contracts", "last_receipt_id", "INTEGER"),
    ("contracts", "reviewed", "INTEGER"),
    ("contracts", "link", "TEXT"),
    ("contracts", "sort_order", "INTEGER"),
    ("contracts", "person_id", "INTEGER"),
    ("contracts", "interest_rate", "REAL"),
    ("contracts", "remaining_debt", "REAL"),
    ("contracts", "repayment_rate", "REAL"),
    ("contracts", "fixed_interest_until", "DATE"),
    ("contracts", "insurance_type", "TEXT"),
    ("contracts", "insurance_expiry", "DATE"),
    ("contracts", "insurance_sum", "REAL"),
    ("contracts", "insurance_sum_type", "TEXT"),
    ("contracts", "bu_monthly_pension", "REAL"),
    ("pension_accounts", "disability_pension_monthly", "REAL"),
    ("income", "source", "TEXT"),
    ("income", "category", "TEXT"),
    ("income", "updated_at", "TIMESTAMP"),
    ("income", "sort_order", "INTEGER"),
    ("payslips", "file_hash", "TEXT"),
    ("pension_accounts", "linked_contract_id", "INTEGER"),
    ("receipts", "asset_id", "INTEGER"),
    ("assets", "account_number", "TEXT"),
    ("assets", "purpose", "TEXT"),
    ("family_members", "freistellungsauftrag_used", "REAL"),
    ("family_members", "sv_nummer", "TEXT"),
    ("family_members", "steuer_id", "TEXT"),
    ("family_members", "steuerklasse", "TEXT"),
    ("family_members", "krankenkasse", "TEXT"),
    ("family_members", "etin", "TEXT"),
    ("family_members", "steuernummer", "TEXT"),
    ("family_members", "finanzamt", "TEXT"),
    ("assets", "account_type", "TEXT"),
    # v315: Vermögenskonten werden archiviert statt gelöscht (Belege, Depotpositionen, Bank-Umsätze bleiben erhalten).
    ("assets", "archived_at", "TEXT"),
    # v327: Vermögenswert aus dem Gesamtvermögen ausnehmen (wirkt auch rückwirkend im Verlauf).
    ("assets", "exclude_from_networth", "INTEGER NOT NULL DEFAULT 0"),
    # v327: Anlagedatum (ältere Einträge: NULL = unbekannt, gilt im Verlauf als "schon immer vorhanden").
    ("assets", "created_at", "TEXT"),
    ("pension_accounts", "is_riester", "INTEGER DEFAULT 0"),
    ("income", "person_id", "INTEGER"),
    ("categories", "sort_order", "INTEGER"),
    ("passkeys", "rp_id", "TEXT"),
    ("receipts", "file_hash", "TEXT"),
]


def _migrate_schema(conn: sqlite3.Connection):
    existing_tables = {r["name"] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()}

    for table, column, coltype in _COLUMN_MIGRATIONS:
        if table not in existing_tables:
            continue
        columns = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in columns:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
            print(f"Migration: Spalte {table}.{column} ergänzt")

    # Sinnvolle Defaults für Zeilen, die es schon vor der Migration gab
    if "contracts" in existing_tables:
        conn.execute("UPDATE contracts SET source='import' WHERE source IS NULL")
        conn.execute("UPDATE contracts SET updated_at=CURRENT_TIMESTAMP WHERE updated_at IS NULL")
        # reviewed war vorher nicht vorhanden -> für bestehende "Sonstiges"-Positionen
        # auf "noch zu prüfen" setzen, alles andere gilt als bereits erledigt
        conn.execute(
            """UPDATE contracts SET reviewed = CASE
                 WHEN category_id IN (SELECT id FROM categories WHERE name='Sonstiges') THEN 0
                 ELSE 1 END
               WHERE reviewed IS NULL"""
        )
    if "income" in existing_tables:
        conn.execute("UPDATE income SET source='import' WHERE source IS NULL")
        conn.execute("UPDATE income SET updated_at=CURRENT_TIMESTAMP WHERE updated_at IS NULL")
    if "passkeys" in existing_tables:
        conn.execute("UPDATE passkeys SET rp_id='localhost' WHERE rp_id IS NULL")
    conn.commit()


def _seed_family_members(conn: sqlite3.Connection):
    """Stammdaten für Vorsorge/Risikoabsicherung: leer nur beim allerersten
    Start befüllen, danach bleibt es vollständig in der Hand des Nutzers
    (umbenennen/löschen über die UI, keine erneute Befüllung)."""
    count = conn.execute("SELECT COUNT(*) AS n FROM family_members").fetchone()["n"]
    if count > 0:
        return
    # Bewusst keine Standard-Personen vorbelegen — jede Installation (auch
    # bei anderen Nutzern) soll mit einer leeren Personen-Liste starten,
    # die über "Einstellungen -> Personen" selbst befüllt wird.


def _auto_match_persons(conn: sqlite3.Connection):
    """Leitet person_id für Einkommen/Verträge automatisch aus der
    Bezeichnung ab (z.B. 'Gehalt Anna' -> Anna), wo noch keine Zuordnung
    gesetzt ist. Überschreibt nie eine bereits bewusst gesetzte Zuordnung."""
    members = [dict(r) for r in conn.execute("SELECT id, name FROM family_members").fetchall()]
    if not members:
        return
    from vorsorge import match_family_member

    for table, has_provider in [("income", False), ("contracts", True)]:
        cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if "person_id" not in cols:
            continue
        select_cols = "id, label" + (", provider" if has_provider else "")
        rows = conn.execute(f"SELECT {select_cols} FROM {table} WHERE person_id IS NULL").fetchall()
        for row in rows:
            provider = row["provider"] if has_provider else None
            match = match_family_member(row["label"], provider, members)
            if match:
                conn.execute(f"UPDATE {table} SET person_id=? WHERE id=?", (match, row["id"]))
    conn.commit()


def _pin_changed_import_categories_once(conn: sqlite3.Connection):
    """Einmalige Migration (v340): Aus categorize.py wurden feste Personennamen
    entfernt. Damit _resync_categories dadurch keine bestehenden Verträge still
    umsortiert, werden alle Import-Verträge, deren Kategorie sich mit der neuen
    Logik ändern würde, auf source='manuell' festgeschrieben (Kategorie bleibt
    wie sie ist). Läuft VOR _resync_categories, enthält selbst keine Namen."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_pinned_import_categories'"
    ).fetchone()
    if flag:
        return
    from categorize import categorize
    rows = conn.execute(
        "SELECT c.id, c.label, c.subcategory, cat.name AS cat_name "
        "FROM contracts c LEFT JOIN categories cat ON cat.id = c.category_id "
        "WHERE c.source='import'"
    ).fetchall()
    pinned = 0
    for row in rows:
        new_category, new_subcategory = categorize(row["label"])
        if new_category != row["cat_name"] or new_subcategory != row["subcategory"]:
            conn.execute("UPDATE contracts SET source='manuell' WHERE id=?", (row["id"],))
            pinned += 1
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_pinned_import_categories', 'true')"
    )
    conn.commit()
    if pinned:
        print(f"Migration: {pinned} Vertrag/Verträge mit abweichender Kategorie festgeschrieben")


def _resync_categories(conn: sqlite3.Connection):
    """Wendet die aktuelle categorize.py-Logik erneut auf alle Positionen an,
    die noch nie manuell bearbeitet wurden (source='import'). So kommen
    Verbesserungen an der Kategorisierung (z.B. eine neue Kategorie wie
    "Auto") automatisch auch bei schon importierten Daten an — ohne jemals
    eine bewusste manuelle Zuordnung zu überschreiben."""
    from categorize import categorize

    rows = conn.execute(
        "SELECT id, label, category_id, subcategory FROM contracts WHERE source='import'"
    ).fetchall()
    for row in rows:
        new_category, new_subcategory = categorize(row["label"])
        cur = conn.execute("SELECT id FROM categories WHERE name=?", (new_category,))
        cat_row = cur.fetchone()
        new_category_id = cat_row["id"] if cat_row else conn.execute(
            "INSERT INTO categories (name) VALUES (?)", (new_category,)
        ).lastrowid

        if new_category_id != row["category_id"] or new_subcategory != row["subcategory"]:
            reviewed = 0 if new_category == "Sonstiges" else 1
            conn.execute(
                "UPDATE contracts SET category_id=?, subcategory=?, reviewed=? WHERE id=?",
                (new_category_id, new_subcategory, reviewed, row["id"]),
            )
    conn.commit()


def _clear_insurance_labels_once(conn: sqlite3.Connection):
    """Einmalige Migration: bestehende Versicherungs-Verträge bekommen einen
    leeren Namen, damit sie ab sofort automatisch aus Person/Anbieter/Typ
    abgeleitet werden, statt den alten, manuell eingetippten Namen zu zeigen.
    Über ein Settings-Flag abgesichert, damit das NICHT bei jedem Start
    erneut läuft und einen später bewusst manuell gesetzten Namen wieder
    löscht."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_cleared_insurance_labels'"
    ).fetchone()
    if flag:
        return
    conn.execute(
        """UPDATE contracts SET label=''
           WHERE category_id IN (SELECT id FROM categories WHERE name='Versicherungen')"""
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_cleared_insurance_labels', 'true')"
    )
    conn.commit()


def _fix_financing_zinsbindung_once(conn: sqlite3.Connection):
    """Bei Finanzierungen wurde 'Fälligkeit/Laufzeitende' bisher fälschlich
    für die Zinsbindung genutzt (die aber etwas anderes ist als das
    tatsächliche Tilgungsende). Einmalig: vorhandene Werte in das neue Feld
    fixed_interest_until übernehmen und contract_end dort leeren, da das
    Tilgungsende künftig aus Restschuld+Zins+Tilgung berechnet wird, nicht
    mehr manuell eingetragen."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_fixed_financing_zinsbindung'"
    ).fetchone()
    if flag:
        return
    conn.execute(
        """UPDATE contracts SET fixed_interest_until = contract_end, contract_end = NULL
           WHERE id IN (
               SELECT co.id FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
               WHERE c.name='Haus' AND co.subcategory='Finanzierung'
                 AND co.contract_end IS NOT NULL AND co.fixed_interest_until IS NULL
           )"""
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_fixed_financing_zinsbindung', 'true')"
    )
    conn.commit()


def _categorize_existing_income_once(conn: sqlite3.Connection):
    """Bestehende Einnahmen (vor Einführung des Kategorie-Felds) einmalig
    anhand des Namens grob vorsortieren, statt dass sie alle in
    'Ohne Kategorie' landen. Reine Startwert-Zuordnung — der Nutzer kann
    jede Position danach jederzeit umkategorisieren."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_categorized_income'"
    ).fetchone()
    if flag:
        return
    rules = [
        ("%gehalt%", "Gehalt"), ("%lohn%", "Gehalt"), ("%salär%", "Gehalt"),
        ("%kindergeld%", "Kindergeld"),
    ]
    for pattern, category in rules:
        conn.execute(
            "UPDATE income SET category=? WHERE category IS NULL AND LOWER(label) LIKE ?",
            (category, pattern),
        )
    conn.execute("UPDATE income SET category='Sonstiges' WHERE category IS NULL")
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_categorized_income', 'true')"
    )
    conn.commit()


def _migrate_pension_documents_once(conn: sqlite3.Connection):
    """Bestehende Einzel-Dokumente (vor Einführung der Dokument-Zeitreihe)
    einmalig in die neue pension_documents-Tabelle übernehmen, damit sie
    nicht verloren gehen."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_pension_documents'"
    ).fetchone()
    if flag:
        return
    rows = conn.execute(
        "SELECT id, document_filename, document_path FROM pension_accounts WHERE document_path IS NOT NULL"
    ).fetchall()
    for r in rows:
        conn.execute(
            "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path) VALUES (?,?,?)",
            (r["id"], r["document_filename"], r["document_path"]),
        )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_pension_documents', 'true')"
    )
    conn.commit()


def _reorganize_documents_by_person_once(conn: sqlite3.Connection):
    """Bestehende Dokumente einmalig in die neue Speicherstruktur
    "Themenbereich/Person/..." überführen (physische Datei verschieben UND
    stored_path in der jeweiligen Tabelle aktualisieren). Erkennt am alten
    Ordnernamen im gespeicherten Pfad, ob eine Datei noch nicht migriert
    ist -- bereits migrierte oder physisch fehlende Dateien werden
    übersprungen, nie ein Fehler bei einer einzelnen Datei bricht die
    gesamte Migration ab, damit ein Teilerfolg nicht riskiert wird."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_document_person_folders'"
    ).fetchone()
    if flag:
        return

    from shared_helpers import _contract_folder_parts, _person_folder_slug

    def move_file(old_rel: str, new_parts: list) -> str:
        old_abs = BASE_DIR / old_rel
        if not old_abs.exists():
            return old_rel  # nichts zu verschieben -- Pfad unverändert lassen
        filename = old_abs.name
        new_dir = BASE_DIR / "data" / Path(*new_parts)
        new_abs = new_dir / filename
        if old_abs == new_abs:
            return old_rel
        new_dir.mkdir(parents=True, exist_ok=True)
        # Namenskollision (z.B. gleicher Dateiname aus anderem alten Ordner):
        # nie überschreiben, stattdessen fortlaufend nummerieren.
        counter = 1
        while new_abs.exists():
            new_abs = new_dir / f"{old_abs.stem}_{counter}{old_abs.suffix}"
            counter += 1
        try:
            old_abs.rename(new_abs)
        except OSError:
            return old_rel  # z.B. Berechtigungsproblem -- lieber am alten Ort belassen als riskieren
        return str(new_abs.relative_to(BASE_DIR))

    # 1) Vertrags-Belege
    rows = conn.execute(
        "SELECT r.id, r.stored_path, c.label, c.provider, c.subcategory, "
        "cat.name AS category_name, fm.name AS person_name "
        "FROM receipts r JOIN contracts c ON c.id = r.contract_id "
        "LEFT JOIN categories cat ON cat.id = c.category_id "
        "LEFT JOIN family_members fm ON fm.id = c.person_id "
        "WHERE r.contract_id IS NOT NULL AND r.stored_path LIKE 'data/receipts/%'"
    ).fetchall()
    for row in rows:
        parts = _contract_folder_parts(row["category_name"], row["subcategory"], row["provider"],
                                        row["label"], row["person_name"])
        new_path = move_file(row["stored_path"], ["Ausgaben"] + parts)
        conn.execute("UPDATE receipts SET stored_path=? WHERE id=?", (new_path, row["id"]))

    # 2) Vermögens-Belege
    rows = conn.execute(
        "SELECT r.id, r.stored_path, a.label AS asset_label, fm.name AS person_name "
        "FROM receipts r JOIN assets a ON a.id = r.asset_id "
        "LEFT JOIN family_members fm ON fm.id = a.person_id "
        "WHERE r.asset_id IS NOT NULL AND r.stored_path LIKE 'data/receipts/%'"
    ).fetchall()
    for row in rows:
        label_slug = re.sub(r"[^\w.-]", "_", row["asset_label"] or "Vermoegenswert")
        new_path = move_file(row["stored_path"], ["Vermoegen", _person_folder_slug(row["person_name"]), label_slug])
        conn.execute("UPDATE receipts SET stored_path=? WHERE id=?", (new_path, row["id"]))

    # 3) Gehaltsabrechnungen
    rows = conn.execute(
        "SELECT p.id, p.stored_path, fm.name AS person_name FROM payslips p "
        "LEFT JOIN income i ON i.id = p.income_id "
        "LEFT JOIN family_members fm ON fm.id = i.person_id "
        "WHERE p.stored_path LIKE 'data/payslips/%'"
    ).fetchall()
    for row in rows:
        new_path = move_file(row["stored_path"], ["Gehalt", _person_folder_slug(row["person_name"])])
        conn.execute("UPDATE payslips SET stored_path=? WHERE id=?", (new_path, row["id"]))

    # 4) Vorsorge-Dokumente
    rows = conn.execute(
        "SELECT pd.id, pd.stored_path, pa.label AS account_label, fm.name AS person_name "
        "FROM pension_documents pd LEFT JOIN pension_accounts pa ON pa.id = pd.pension_account_id "
        "LEFT JOIN family_members fm ON fm.id = pa.person_id "
        "WHERE pd.stored_path LIKE 'data/pension_docs/%'"
    ).fetchall()
    for row in rows:
        label_slug = re.sub(r"[^\w.-]", "_", row["account_label"] or "Konto")
        new_path = move_file(row["stored_path"], ["Vorsorge", _person_folder_slug(row["person_name"]), label_slug])
        conn.execute("UPDATE pension_documents SET stored_path=? WHERE id=?", (new_path, row["id"]))

    # 5) Personendokumente
    rows = conn.execute(
        "SELECT pdoc.id, pdoc.stored_path, fm.name AS person_name FROM person_documents pdoc "
        "LEFT JOIN family_members fm ON fm.id = pdoc.person_id "
        "WHERE pdoc.stored_path LIKE 'data/person_docs/%'"
    ).fetchall()
    for row in rows:
        new_path = move_file(row["stored_path"], ["Personendokumente", _person_folder_slug(row["person_name"])])
        conn.execute("UPDATE person_documents SET stored_path=? WHERE id=?", (new_path, row["id"]))

    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_document_person_folders', 'true')"
    )
    conn.commit()


def _fix_manual_contract_source_once(conn: sqlite3.Connection):
    """Rückwirkender Schutz: create_contract hat 'source' nie explizit
    gesetzt und damit ungewollt den Tabellen-Standard 'import' geerbt —
    wodurch auch manuell angelegte Verträge (allen voran Versicherungen mit
    bewusst leerem Label für die automatische Namensableitung) fälschlich
    für die label-basierte Nachkategorisierung in Frage kamen und bei jedem
    Neustart auf 'Sonstiges' zurückfallen konnten. Ein leeres Label ist ein
    zuverlässiges Zeichen für manuelle Anlage, da ein echter Import immer
    einen erkannten Namen mitbringt."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_fixed_manual_contract_source'"
    ).fetchone()
    if flag:
        return
    conn.execute(
        "UPDATE contracts SET source='manuell' WHERE source='import' AND (label IS NULL OR label='')"
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_fixed_manual_contract_source', 'true')"
    )
    conn.commit()


def _dedupe_documents_once(conn: sqlite3.Connection):
    """Einmalige Bereinigung: byteidentische Duplikate (gleicher Datei-Hash)
    innerhalb desselben Kontexts (gleiche Einnahme / gleiches Rentenkonto /
    gleicher Vertrag) automatisch entfernen — behält jeweils die älteste
    Kopie. Ein echter Hash-Treffer ist verlustfrei entfernbar, da der
    Dateiinhalt exakt identisch ist; auf Kontext beschränkt, damit z.B. eine
    zufällig inhaltsgleiche Datei bei zwei verschiedenen Verträgen nicht
    fälschlich als Duplikat gilt."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_deduped_documents'"
    ).fetchone()
    if flag:
        return

    # Gehaltsabrechnungen hatten bisher keinen Hash — für bestehende
    # Dateien einmalig nachträglich berechnen, soweit die Datei noch existiert.
    rows = conn.execute(
        "SELECT id, stored_path FROM payslips WHERE file_hash IS NULL"
    ).fetchall()
    for r in rows:
        file_path = BASE_DIR / r["stored_path"]
        if file_path.exists():
            file_hash = hashlib.sha256(file_path.read_bytes()).hexdigest()
            conn.execute("UPDATE payslips SET file_hash=? WHERE id=?", (file_hash, r["id"]))

    removed_total = 0
    for table, context_col in [
        ("payslips", "income_id"),
        ("pension_documents", "pension_account_id"),
        ("receipts", "contract_id"),
    ]:
        dupe_groups = conn.execute(
            f"""SELECT {context_col} AS ctx, file_hash, COUNT(*) AS n
                FROM {table}
                WHERE file_hash IS NOT NULL AND {context_col} IS NOT NULL
                GROUP BY {context_col}, file_hash HAVING COUNT(*) > 1"""
        ).fetchall()
        for g in dupe_groups:
            dupes = conn.execute(
                f"SELECT id, stored_path FROM {table} WHERE {context_col}=? AND file_hash=? ORDER BY uploaded_at ASC",
                (g["ctx"], g["file_hash"]),
            ).fetchall()
            for extra in dupes[1:]:  # erste (älteste) behalten, Rest entfernen
                file_path = BASE_DIR / extra["stored_path"]
                if file_path.exists():
                    file_path.unlink()
                if table == "receipts":
                    conn.execute("DELETE FROM expenses WHERE receipt_id=?", (extra["id"],))
                    conn.execute("UPDATE contracts SET last_receipt_id=NULL WHERE last_receipt_id=?", (extra["id"],))
                conn.execute(f"DELETE FROM {table} WHERE id=?", (extra["id"],))
                removed_total += 1

    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_deduped_documents', 'true')"
    )
    conn.commit()
    if removed_total:
        print(f"Migration: {removed_total} doppelte Belege/Dokumente entfernt")


def _migrate_asset_financing_links_once(conn: sqlite3.Connection):
    """Überführt eine bereits gesetzte assets.linked_contract_id (aus der
    ursprünglichen 1:1-Verknüpfung) in die neue asset_financing_links-
    Tabelle, die mehrere Verträge pro Immobilie erlaubt — kein Datenverlust
    für alle, die schon vor der Umstellung eine Immobilie verknüpft hatten."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_asset_financing_links'"
    ).fetchone()
    if flag:
        return
    rows = conn.execute(
        "SELECT id, linked_contract_id FROM assets WHERE linked_contract_id IS NOT NULL"
    ).fetchall()
    for r in rows:
        conn.execute(
            "INSERT OR IGNORE INTO asset_financing_links (asset_id, contract_id) VALUES (?,?)",
            (r["id"], r["linked_contract_id"]),
        )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_asset_financing_links', 'true')"
    )
    conn.commit()
    if rows:
        print(f"Migration: {len(rows)} Immobilien-Vertrags-Verknüpfungen übernommen")


def _backfill_payslip_month_from_filename_once(conn: sqlite3.Connection):
    """Für bestehende Gehaltsabrechnungen ohne erkannten Monat (z.B. eine
    Lohnsteuerbescheinigung, deren PDF-Text kein 'Monatsname Jahr' enthält)
    einmalig versuchen, den Monat aus dem Dateinamen nachzutragen — dieselbe
    Fallback-Logik, die jetzt auch bei neuen Uploads greift."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_backfilled_payslip_month'"
    ).fetchone()
    if flag:
        return
    from payslip_import import _extract_month_from_filename

    rows = conn.execute(
        "SELECT id, original_filename FROM payslips WHERE detected_month IS NULL AND original_filename IS NOT NULL"
    ).fetchall()
    updated = 0
    for r in rows:
        month = _extract_month_from_filename(r["original_filename"])
        if month:
            conn.execute("UPDATE payslips SET detected_month=? WHERE id=?", (month, r["id"]))
            updated += 1

    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_backfilled_payslip_month', 'true')"
    )
    conn.commit()
    if updated:
        print(f"Migration: {updated} Gehaltsabrechnungen Monat aus Dateinamen nachgetragen")


def _reset_incorrect_zappi_readings_once(conn: sqlite3.Connection):
    """Einmalige Bereinigung nach dem Zappi-Berechnungsfehler (v263): alle
    bisher automatisch synchronisierten 'ev_charging'-Ablesungen wurden mit
    einer fehlerhaften Formel berechnet (u.a. falsche Einheit, fehlende
    Minutenwerte-Summierung) und sind daher komplett verworfen. Ohne diese
    Bereinigung würde der normale Sync-Ablauf (der nur Tage NACH der
    letzten vorhandenen Ablesung nachträgt) die falschen Werte für immer
    stehen lassen, da er sie fälschlich für 'bereits synchronisiert' hält."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_reset_zappi_readings_v263'"
    ).fetchone()
    if flag:
        return
    conn.execute(
        "DELETE FROM meter_readings WHERE meter_type='ev_charging' "
        "AND note='Automatisch von Zappi synchronisiert'"
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_reset_zappi_readings_v263', 'true')"
    )
    conn.commit()


def _migrate_bank_rules_amount(conn: sqlite3.Connection):
    """v333: Gelernte Bank-Regeln berücksichtigen den Betrag. Die alte Tabelle hatte UNIQUE(match_field,
    match_value) -- ein Empfänger konnte nur EIN Ziel haben, eine neue Zuordnung überschrieb die alte Regel.
    SQLite kann eine Tabellen-Eindeutigkeit nicht entfernen -> einmaliger Neuaufbau, alle Regeln bleiben
    erhalten (amount_cents = NULL, also "jeder Betrag" wie bisher). Idempotent: läuft nur, solange die
    Spalte fehlt; der Index wird immer mit IF NOT EXISTS angelegt."""
    tables = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    if "bank_match_rules" not in tables:
        return
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(bank_match_rules)").fetchall()}
    if "amount_cents" not in cols:
        n = conn.execute("SELECT COUNT(*) FROM bank_match_rules").fetchone()[0]
        conn.executescript("""
            BEGIN;
            CREATE TABLE bank_match_rules_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                target_id INTEGER NOT NULL,
                match_field TEXT NOT NULL,
                match_value TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                amount_cents INTEGER
            );
            INSERT INTO bank_match_rules_new (id, kind, target_id, match_field, match_value, created_at)
                SELECT id, kind, target_id, match_field, match_value, created_at FROM bank_match_rules;
            DROP TABLE bank_match_rules;
            ALTER TABLE bank_match_rules_new RENAME TO bank_match_rules;
            COMMIT;
        """)
        after = conn.execute("SELECT COUNT(*) FROM bank_match_rules").fetchone()[0]
        print(f"Migration: Bank-Regeln um Betrag erweitert ({after} von {n} Regeln übernommen)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_bank_rules_key "
                     "ON bank_match_rules(match_field, match_value, IFNULL(amount_cents, -1))")
        # Aus den bisherigen manuellen Zuordnungen je Betrag neu lernen (nur einmal, im selben Umbau)
        try:
            import bank_matching
            if "bank_transactions" in tables:
                learned = bank_matching.relearn_from_manual(conn)
                print(f"Migration: {learned} manuelle Zuordnungen als Regeln mit Betrag übernommen "
                      f"({conn.execute('SELECT COUNT(*) FROM bank_match_rules').fetchone()[0]} Regeln)")
        except Exception as e:
            print(f"Hinweis: Regeln nicht neu gelernt ({e}) – bestehende Regeln gelten weiter")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_bank_rules_key "
                 "ON bank_match_rules(match_field, match_value, IFNULL(amount_cents, -1))")
    conn.commit()


# Indizes auf Verweis-Spalten (Zahlungslisten je Vertrag/Einnahme, Belege je Konto usw.).
# Liegen NICHT in schema.sql, weil dort Spalten, die erst per Migration entstehen,
# in alten Datenbanken noch fehlen. Idempotent; fehlende Tabellen/Spalten werden übersprungen.
_REFERENCE_INDEXES = [
    ("bank_transactions", "contract_id"),
    ("bank_transactions", "income_id"),
    ("payslips", "income_id"),
    ("pension_documents", "pension_account_id"),
    ("pension_accounts", "person_id"),
    ("expenses", "contract_id"),
    ("expenses", "receipt_id"),
    ("meter_readings", "receipt_id"),
    ("person_documents", "person_id"),
]


def _ensure_reference_indexes(conn):
    for table, column in _REFERENCE_INDEXES:
        try:
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
            if column in cols:
                conn.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_{column} "
                             f"ON {table}({column})")
        except Exception as e:
            print(f"Hinweis: Index {table}.{column} nicht angelegt ({e})")
    conn.commit()


def init_db():
    conn = get_connection()
    try:
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn.executescript(f.read())
        conn.commit()
        _migrate_schema(conn)
        _ensure_reference_indexes(conn)
        _migrate_bank_rules_amount(conn)
        _seed_family_members(conn)
        _auto_match_persons(conn)
        _clear_insurance_labels_once(conn)
        _fix_financing_zinsbindung_once(conn)
        _categorize_existing_income_once(conn)
        _migrate_pension_documents_once(conn)
        _reorganize_documents_by_person_once(conn)
        _fix_manual_contract_source_once(conn)
        _dedupe_documents_once(conn)
        _backfill_payslip_month_from_filename_once(conn)
        _migrate_asset_financing_links_once(conn)
        _pin_changed_import_categories_once(conn)
        _resync_categories(conn)
        _reset_incorrect_zappi_readings_once(conn)
        try:
            import receipts_routes
            receipts_routes.repair_unconfirmed_payslips_once(conn)
        except Exception as e:
            print(f"Hinweis: Reparatur Gehaltsabrechnungen übersprungen ({e})")
        try:
            import receipts_routes
            r = receipts_routes.relink_orphan_asset_documents_once(conn)
            if r.get("relinked") or r.get("dropped_missing"):
                print(f"Reparatur Belege: {len(r['relinked'])} Vermögens-Dokument(e) wieder zugeordnet, "
                      f"{len(r['dropped_missing'])} hängende unbestätigte Einträge entfernt")
            # v367: für Ordner ohne Vermögenswert synthetische Einträge anlegen, dann erneut zuordnen
            s = receipts_routes.create_assets_for_orphan_folders_once(conn)
            if s.get("created"):
                r2 = receipts_routes.relink_orphan_asset_documents_once(conn, marker="migration_relink_orphan_asset_docs_v2")
                print(f"Reparatur Belege: {len(s['created'])} Eintrag/Einträge für verwaiste Dokumente angelegt, "
                      f"{len(r2.get('relinked', []))} Dokument(e) zugeordnet")
        except Exception as e:
            print(f"Hinweis: Reparatur Vermögens-Dokumente übersprungen ({e})")
        try:
            import cost_shares
            cost_shares.setup_house_share_once(conn)
            cost_shares.add_house_internet_share_once(conn)
        except Exception as e:
            print(f"Hinweis: Kostenbeteiligung nicht eingerichtet ({e})")
        # Zugangsdaten der Integrationen ins Schlüsselbund umziehen (idempotent;
        # ohne funktionierendes Schlüsselbund bleibt alles unverändert).
        try:
            import secret_store
            moved = secret_store.secure_all(conn)
            if moved["moved"]:
                print(f"Zugangsdaten gesichert: {moved['moved']} Wert(e) ins {moved['keychain']} verschoben")
            elif moved["kept_in_database"]:
                print("Hinweis: Kein Schlüsselbund verfügbar -- Zugangsdaten bleiben in der Datenbank")
        except Exception as e:
            print(f"Hinweis: Zugangsdaten-Sicherung übersprungen ({e})")
        conn.close()
        print(f"Datenbank initialisiert: {DEMO_DB_PATH if _use_demo_db.get() else DB_PATH}")
    finally:
        conn.close()


if __name__ == "__main__":
    init_db()
