"""
Vorsorge (Rente + Risikoabsicherung): Klassifizierung von Versicherungstypen
und Personen-Zuordnung anhand vorhandener Bezeichnungen, sowie die
Versorgungslücken-Berechnung für die Altersvorsorge.

Rechenlogik bewusst als klar benannte, nachvollziehbare Faustregeln
umgesetzt (mit Quellenangabe in den Docstrings) — keine individuelle
Finanzberatung, sondern grobe Orientierung, wie auch beim bestehenden
Finanz-Check.
"""
from typing import Optional
from datetime import date

# ---------- Versicherungstyp-Klassifizierung ----------

INSURANCE_TYPES = [
    "Risikolebensversicherung",
    "Berufsunfähigkeitsversicherung",
    "Unfallversicherung",
    "Hausratversicherung",
    "Haftpflichtversicherung",
    "Grundbesitzer-Haftpflichtversicherung",
    "Gebäudeversicherung",
    "KFZ-Versicherung",
    "Rechtsschutzversicherung",
    "Zahnzusatzversicherung",
    "Auslandskrankenversicherung",
    "Krankenzusatzversicherung",
    "Sonstige Versicherung",
]

# Reihenfolge ist wichtig: spezifischere Muster zuerst, damit z.B.
# "Berufsunfähigkeit" nicht fälschlich schon bei "versicherung" landet.
_INSURANCE_PATTERNS = [
    (("berufsunfähig", "bu-rente", " bu "), "Berufsunfähigkeitsversicherung"),
    (("risikoleben", "risiko-leben", "risiko leben", "rlv"), "Risikolebensversicherung"),
    (("unfallvers",), "Unfallversicherung"),
    (("hausrat",), "Hausratversicherung"),
    # Vor den generischen Gebäude-/Haftpflicht-Mustern geprüft, da
    # "Grundbesitzerhaftpflicht" sonst schon am "haftpflicht"-Teilstring
    # hängen bleiben würde (z.B. bei kombinierten Policen wie "Gebäudevers.
    # + Grundbesitzerhaftpflicht").
    (("grundbesitzerhaftpflicht", "grundbesitzer-haftpflicht", "grundbesitzerhaftpflichtversicherung"),
     "Grundbesitzer-Haftpflichtversicherung"),
    (("gebäudevers", "wohngebäude"), "Gebäudeversicherung"),
    (("haftpflicht",), "Haftpflichtversicherung"),
    (("kfz", "autoversicherung", "kraftfahrzeug"), "KFZ-Versicherung"),
    (("rechtsschutz",), "Rechtsschutzversicherung"),
    (("zahnzusatz", "zahnzusatzvers"), "Zahnzusatzversicherung"),
    (("auslandskranken", "auslandsreisekranken", "reisekranken"), "Auslandskrankenversicherung"),
    (("krankenzusatz", "krankenschutz", "zusatzversicherung"), "Krankenzusatzversicherung"),
]


def classify_insurance_type(label: str, provider: Optional[str] = None) -> str:
    """Leitet den Versicherungstyp aus Bezeichnung/Anbieter ab (z.B. 'Benny:
    Allianz Risiko-Lebensversicherung' -> 'Risikolebensversicherung').
    Fällt auf 'Sonstige Versicherung' zurück, wenn nichts passt."""
    haystack = f"{label or ''} {provider or ''}".lower()
    for needles, itype in _INSURANCE_PATTERNS:
        if any(n in haystack for n in needles):
            return itype
    return "Sonstige Versicherung"


# ---------- Personen-Zuordnung ----------

def match_family_member(label: str, provider: Optional[str], members: list) -> Optional[int]:
    """Sucht einen Familienmitglieder-Namen in Bezeichnung/Anbieter (z.B.
    'Raphi: SwissLife Berufsunfähigkeitsversicherung' -> Raphi's id). Gibt
    None zurück, wenn kein Name vorkommt (z.B. Haushalts-weite Verträge)."""
    haystack = f"{label or ''} {provider or ''}".lower()
    for m in members:
        if m["name"].lower() in haystack:
            return m["id"]
    return None


# ---------- Versorgungslücke (Rente) ----------
# Quellen der Faustregeln (Stand 2026, öffentlich zugängliche Orientierung,
# u.a. Verbraucherzentrale, Deutsche Rentenversicherung):
# - Zielversorgungsniveau: häufig genannter Richtwert 80 % des letzten
#   Netto-Erwerbseinkommens, um den Lebensstandard zu halten.
# - Renteneintrittsalter: gesetzliche Regelaltersgrenze für ab 1964 Geborene
#   liegt bei 67 — hier fest als Zielalter verwendet, wie gewünscht.
# - Kapitalverzehr im Ruhestand: vereinfachte lineare Verrentung über eine
#   angenommene Restlebenserwartung (Default 25 Jahre ab 67, entspricht
#   ungefähr der ferneren Lebenserwartung 67-Jähriger laut Sterbetafel des
#   Statistischen Bundesamts) — bewusst konservativ ohne weitere Verzinsung
#   während der Auszahlphase.
TARGET_REPLACEMENT_RATE = 0.80  # Zielversorgungsniveau: 80 % des letzten Nettoeinkommens
RETIREMENT_AGE = 67
DEFAULT_RETURN_RATE = 0.03      # Angenommene reale Rendite während der Ansparphase, p.a.
DEFAULT_PAYOUT_YEARS = 25       # Angenommene Rentenbezugsdauer ab 67


def years_until_retirement(birth_date: Optional[date], today: Optional[date] = None) -> Optional[float]:
    if not birth_date:
        return None
    today = today or date.today()
    retirement_date = date(birth_date.year + RETIREMENT_AGE, birth_date.month, birth_date.day)
    return max(0.0, (retirement_date - today).days / 365.25)


def project_private_pension_capital(current_value: float, monthly_contribution: float,
                                     years_remaining: float, annual_return: float = DEFAULT_RETURN_RATE) -> float:
    """Projiziert den Kapitalwert einer privaten Vorsorge bis zum Renteneintritt
    (Zinseszins auf den Bestand + monatliche Einzahlungen), einfache, transparente
    Standardformel — keine Berücksichtigung von Kosten/Steuern."""
    if years_remaining <= 0:
        return current_value
    months = years_remaining * 12
    r_monthly = annual_return / 12
    fv_current = current_value * ((1 + r_monthly) ** months)
    if r_monthly > 0:
        fv_contributions = monthly_contribution * (((1 + r_monthly) ** months - 1) / r_monthly)
    else:
        fv_contributions = monthly_contribution * months
    return fv_current + fv_contributions


def capital_to_monthly_pension(capital: float, payout_years: float = DEFAULT_PAYOUT_YEARS) -> float:
    """Rechnet einen Kapitalwert in eine monatliche Rente um — vereinfacht
    linear über die angenommene Bezugsdauer, ohne weitere Verzinsung während
    der Auszahlphase (konservative Annahme)."""
    if payout_years <= 0:
        return 0.0
    return capital / (payout_years * 12)


def compute_pension_gap(net_income_monthly: float, statutory_pension_monthly: float,
                         private_pension_monthly_projected: float) -> dict:
    """Versorgungslücke: Zielrente (80 % des aktuellen Netto) minus die Summe
    aus gesetzlicher und (projizierter) privater Rente."""
    target_pension = net_income_monthly * TARGET_REPLACEMENT_RATE
    total_projected = statutory_pension_monthly + private_pension_monthly_projected
    gap = target_pension - total_projected
    coverage_rate = (total_projected / target_pension * 100) if target_pension > 0 else 0
    if coverage_rate >= 100:
        status = "green"
    elif coverage_rate >= 80:
        status = "yellow"
    else:
        status = "red"
    return {
        "target_pension_monthly": round(target_pension, 2),
        "statutory_pension_monthly": round(statutory_pension_monthly, 2),
        "private_pension_monthly_projected": round(private_pension_monthly_projected, 2),
        "total_projected_monthly": round(total_projected, 2),
        "gap_monthly": round(gap, 2),
        "coverage_rate": round(coverage_rate, 1),
        "status": status,
    }


def compute_household_pension_gap(household_net_income_monthly: float,
                                   household_statutory_monthly: float,
                                   household_private_monthly: float,
                                   expense_relief_monthly: float = 0) -> dict:
    """Wie compute_pension_gap, aber für den ganzen Haushalt — das ist oft
    aussagekräftiger als die Einzelbetrachtung, da beide Einkommen zusammen
    den Lebensstandard tragen. expense_relief_monthly (z.B. eine bis zum
    Renteneintritt abbezahlte Immobilienfinanzierung) wird dabei wie eine
    zusätzliche monatliche Einnahme behandelt, nicht als Senkung der
    Zielrente — eine abbezahlte Immobilie ist selbst eine Form von Vorsorge."""
    target = household_net_income_monthly * TARGET_REPLACEMENT_RATE
    total_projected = household_statutory_monthly + household_private_monthly + expense_relief_monthly
    gap = target - total_projected
    coverage_rate = (total_projected / target * 100) if target > 0 else 0
    if coverage_rate >= 100:
        status = "green"
    elif coverage_rate >= 80:
        status = "yellow"
    else:
        status = "red"
    return {
        "target_pension_monthly": round(target, 2),
        "statutory_pension_monthly": round(household_statutory_monthly, 2),
        "private_pension_monthly_projected": round(household_private_monthly, 2),
        "expense_relief_monthly": round(expense_relief_monthly, 2),
        "total_projected_monthly": round(total_projected, 2),
        "gap_monthly": round(gap, 2),
        "coverage_rate": round(coverage_rate, 1),
        "status": status,
    }
# Faustregeln (Stand 2026, gängige Verbraucherzentrale-/Fachpresse-Richtwerte):
# - Berufsunfähigkeit: BU-Rente sollte 60-80 % des bisherigen Nettoeinkommens
#   ersetzen, um den Lebensstandard zumindest größtenteils zu halten.
# - Risikolebensversicherung: verbreiteter Richtwert 3-5x Jahresnettoeinkommen
#   ohne Kinder; mit Kindern im Haushalt wird oft ein höherer Richtwert von
#   5-8x genannt, da die Familie länger auf das wegfallende Einkommen
#   angewiesen ist. Eine laufende Immobilienfinanzierung erhöht den Bedarf
#   zusätzlich (die Restschuld selbst wird hier NICHT verfolgt — nur die
#   monatliche Rate als Hinweis, das im Ernstfall mit einzuplanen).
def compute_bu_em_combination(bu_monthly_pension: Optional[float],
                               disability_pension_monthly: Optional[float],
                               net_income_monthly: float) -> dict:
    """Prüft die Kombination aus privater BU-Rente und gesetzlicher
    Erwerbsminderungsrente (EM).

    Hintergrund: Versicherer begrenzen die private BU-Rente üblicherweise so,
    dass die abgesicherte Summe nicht über dem bisherigen Nettoeinkommen
    liegt — eine 'Überversicherung' wird beim Abschluss meist gar nicht erst
    angeboten, verbreitet ist ein Richtwert um 80 % des Nettos. Wer eine
    EM-Rente bezieht, bekommt diese zusätzlich zur BU-Rente; entscheidend ist
    deshalb die SUMME beider Leistungen.

    Die genauen Grenzen legt jeder Versicherer in seinen Bedingungen selbst
    fest und prüft sie beim Abschluss — das hier ist eine grobe Orientierung,
    keine verbindliche Auskunft."""
    if not net_income_monthly or net_income_monthly <= 0:
        return {"status": "unknown"}
    bu = bu_monthly_pension or 0
    em = disability_pension_monthly or 0
    combined = bu + em
    combined_rate = combined / net_income_monthly * 100
    cap_soft = net_income_monthly * 0.80
    cap_hard = net_income_monthly

    if combined > cap_hard:
        status = "over"
    elif combined > cap_soft:
        status = "near_cap"
    else:
        status = "ok"

    return {
        "status": status,
        "bu_monthly": round(bu, 2),
        "em_monthly": round(em, 2),
        "combined_monthly": round(combined, 2),
        "combined_rate": round(combined_rate, 1),
        "cap_soft": round(cap_soft, 2),
        "cap_hard": round(cap_hard, 2),
        "headroom_to_soft_cap": round(cap_soft - combined, 2),
    }


BU_TARGET_MIN_RATE = 0.60
BU_TARGET_MAX_RATE = 0.80
RLV_MULTIPLE_NO_KIDS = (3, 5)
RLV_MULTIPLE_WITH_KIDS = (5, 8)


def compute_bu_assessment(bu_monthly_pension: Optional[float], net_income_monthly: float) -> dict:
    if not net_income_monthly or net_income_monthly <= 0:
        return {"assessment": "unknown"}
    target_min = net_income_monthly * BU_TARGET_MIN_RATE
    target_max = net_income_monthly * BU_TARGET_MAX_RATE
    current = bu_monthly_pension or 0
    coverage_rate = (current / net_income_monthly * 100) if net_income_monthly else 0
    if current >= target_max:
        status = "green"
    elif current >= target_min:
        status = "yellow"
    else:
        status = "red"
    return {
        "assessment": status,
        "income_replacement_rate": round(coverage_rate, 1),
        "target_min_monthly": round(target_min, 2),
        "target_max_monthly": round(target_max, 2),
        "gap_to_min_monthly": round(max(0, target_min - current), 2),
    }


def compute_rlv_assessment(insurance_sum: Optional[float], net_income_monthly: float,
                            has_children: bool, financing_monthly: float = 0) -> dict:
    if not net_income_monthly or net_income_monthly <= 0:
        return {"assessment": "unknown"}
    annual = net_income_monthly * 12
    mult_min, mult_max = RLV_MULTIPLE_WITH_KIDS if has_children else RLV_MULTIPLE_NO_KIDS
    target_min = annual * mult_min
    target_max = annual * mult_max
    current = insurance_sum or 0
    years_covered = (current / annual) if annual else 0
    if current >= target_max:
        status = "green"
    elif current >= target_min:
        status = "yellow"
    else:
        status = "red"
    return {
        "assessment": status,
        "years_of_income_covered": round(years_covered, 1),
        "target_min_sum": round(target_min, 2),
        "target_max_sum": round(target_max, 2),
        "gap_to_min_sum": round(max(0, target_min - current), 2),
        "target_multiple_min": mult_min,
        "target_multiple_max": mult_max,
        "financing_monthly": round(financing_monthly, 2) if financing_monthly else 0,
    }
