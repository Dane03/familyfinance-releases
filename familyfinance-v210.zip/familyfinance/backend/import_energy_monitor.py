"""
Einmaliger Import der historischen Zählerstände aus der bisherigen
eigenständigen Energy-Monitor-App (localStorage-basiert) in die Family-Hub-
Datenbank. Analog zu import_ods.py für die ursprüngliche Excel-Migration.

Aufruf einmalig:
    python3 import_energy_monitor.py

Sicher mehrfach ausführbar: überspringt Ablesungen, die für dasselbe Datum
beim selben Zähler bereits existieren, statt sie zu duplizieren.
"""
import json
from database import get_connection, init_db

# ---------------- Echte historische Daten aus Energy_Monitor_1.html ----------------

GAS_READINGS = [
    ("2024-08-09", 16388), ("2024-08-27", 16429), ("2024-09-14", 16472),
    ("2024-12-06", 17347), ("2025-01-01", 17854), ("2025-02-26", 18961),
    ("2025-03-12", 19191), ("2025-04-14", 19623), ("2025-09-10", 20145),
    ("2025-11-19", 20587), ("2025-12-23", 20971), ("2026-01-24", 21440),
    ("2026-02-08", 21669), ("2026-03-13", 22008), ("2026-03-22", 22097),
    ("2026-04-06", 22263), ("2026-04-10", 22276), ("2026-04-17", 22337),
    ("2026-04-26", 22362), ("2026-05-17", 22427), ("2026-05-20", 22437),
    ("2026-05-25", 22452), ("2026-05-29", 22462), ("2026-06-07", 22481),
    ("2026-06-09", 22487), ("2026-06-20", 22514), ("2026-06-25", 22524),
    ("2026-07-09", 22552), ("2026-07-12", 22557), ("2026-07-17", 22569),
]

# elec_in: echter Zählerstand je Zähler. Zählerwechsel am 05.11.2025 —
# is_new_meter=True markiert den ersten Stand des neuen Zählers (1ISK0093728750,
# Register 1.8.0), damit der Sprung nicht als Verbrauch gezählt wird.
ELEC_IN_READINGS = [
    ("2025-03-13", 45452, False), ("2025-04-14", 46227, False),
    ("2025-04-24", 46236, False), ("2025-04-25", 46461, False),
    ("2025-08-01", 46494, False), ("2025-09-10", 46503, False),
    ("2025-10-27", 46607, False), ("2025-11-04", 46634, False),
    ("2025-11-05", 0, True),
    ("2026-03-13", 1067, False), ("2026-04-01", 1103, False),
    ("2026-05-01", 1134, False), ("2026-06-01", 1165, False),
    ("2026-07-01", 1176, False), ("2026-07-17", 1181, False),
]

ELEC_OUT_READINGS = [
    ("2026-07-09", 5443), ("2026-07-17", 5859),
]

# Echte PV-Monatsdaten aus dem Sungrow-Wechselrichter (iSolarCloud-Export)
PV_MONTHLY = [
    {"key": "2025-04", "pv": 302.9, "bezug": 1.1, "einsp": 151.9, "batt_lad": 51.2, "batt_ent": 51.2, "gesamt": 146.0},
    {"key": "2025-05", "pv": 2038.8, "bezug": 4.5, "einsp": 1296.8, "batt_lad": 224.9, "batt_ent": 224.9, "gesamt": 742.5},
    {"key": "2025-06", "pv": 2284.1, "bezug": 0.6, "einsp": 1716.2, "batt_lad": 156.7, "batt_ent": 156.7, "gesamt": 565.3},
    {"key": "2025-07", "pv": 2072.0, "bezug": 1.0, "einsp": 1452.6, "batt_lad": 186.0, "batt_ent": 186.0, "gesamt": 617.8},
    {"key": "2025-08", "pv": 2013.3, "bezug": 1.0, "einsp": 1525.8, "batt_lad": 176.3, "batt_ent": 176.3, "gesamt": 487.9},
    {"key": "2025-09", "pv": 1294.7, "bezug": 54.2, "einsp": 717.1, "batt_lad": 222.3, "batt_ent": 222.3, "gesamt": 629.4},
    {"key": "2025-10", "pv": 962.0, "bezug": 44.6, "einsp": 378.1, "batt_lad": 258.1, "batt_ent": 258.1, "gesamt": 621.4},
    {"key": "2025-11", "pv": 472.4, "bezug": 188.2, "einsp": 76.3, "batt_lad": 192.8, "batt_ent": 192.8, "gesamt": 584.7},
    {"key": "2025-12", "pv": 325.6, "bezug": 380.0, "einsp": 8.1, "batt_lad": 148.2, "batt_ent": 149.5, "gesamt": 692.6},
    {"key": "2026-01", "pv": 354.70, "bezug": 353.17, "einsp": 25.83, "batt_lad": 158.70, "batt_ent": 149.50, "gesamt": 672.84},
    {"key": "2026-02", "pv": 547.60, "bezug": 154.29, "einsp": 117.41, "batt_lad": 210.50, "batt_ent": 203.50, "gesamt": 577.48},
    {"key": "2026-03", "pv": 1368.30, "bezug": 46.47, "einsp": 709.93, "batt_lad": 278.20, "batt_ent": 269.70, "gesamt": 696.34},
    {"key": "2026-04", "pv": 1855.00, "bezug": 32.37, "einsp": 1159.07, "batt_lad": 246.60, "batt_ent": 242.40, "gesamt": 724.10},
    {"key": "2026-05", "pv": 2096.40, "bezug": 31.44, "einsp": 1323.07, "batt_lad": 254.30, "batt_ent": 245.90, "gesamt": 796.36},
    {"key": "2026-06", "pv": 2240.40, "bezug": 11.97, "einsp": 1612.36, "batt_lad": 185.50, "batt_ent": 182.80, "gesamt": 642.71},
    {"key": "2026-07", "pv": 1824.80, "bezug": 8.73, "einsp": 1276.35, "batt_lad": 154.90, "batt_ent": 155.10, "gesamt": 557.38},
]

GAS_SETTINGS = {
    "abschlag": 241.43, "arbeitspreis": 0.0899, "grundpreis": 8.08, "brennwert": 10.55,
    "anbieter": "Octopus Energy", "vertragsende": "2027-01-24",
    "settle_month": 1, "settle_day": 24,
}

# Echte monatliche Durchschnittstemperaturen (für die Temperatur-Kurve auf
# der Gas-Seite) — statische historische Werte, keine automatische Aktualisierung.
GAS_MONTHLY_TEMPS = {
    "2024-08": 22.3, "2024-09": 16.2, "2024-10": 12.8, "2024-11": 7.4, "2024-12": 2.5,
    "2025-01": 2.0, "2025-02": 5.8, "2025-03": 9.2, "2025-04": 12.1, "2025-05": 15.8,
    "2025-06": 20.8, "2025-07": 22.4, "2025-08": 21.5, "2025-09": 16.5, "2025-10": 13.4,
    "2025-11": 5.6, "2025-12": 3.5, "2026-01": 2.8, "2026-02": 7.2, "2026-03": 9.4,
    "2026-04": 13.0, "2026-05": 17.5, "2026-06": 21.3, "2026-07": 22.5,
}

ELEC_IN_SETTINGS = {
    "abschlag": 50.00, "arbeitspreis": 0.2853, "grundpreis": 11.25,
    "anbieter": "Octopus Energy", "vertragsende": "2028-03-13",
    "settle_month": 3, "settle_day": 13,
}
ELEC_OUT_SETTINGS = {
    "abschlag": 70.00, "einspeisepreis": 0.0688, "anbieter": "badenovaNETZE",
    "settle_month": 1, "settle_day": 31,
}


def _insert_readings(conn, meter_type, rows):
    inserted, skipped = 0, 0
    for row in rows:
        if len(row) == 3:
            reading_date, value, is_new = row
        else:
            reading_date, value = row
            is_new = False
        existing = conn.execute(
            "SELECT id FROM meter_readings WHERE meter_type=? AND reading_date=?",
            (meter_type, reading_date),
        ).fetchone()
        if existing:
            skipped += 1
            continue
        conn.execute(
            "INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter) VALUES (?,?,?,?)",
            (meter_type, reading_date, value, int(is_new)),
        )
        inserted += 1
    return inserted, skipped


def _insert_pv_monthly(conn, rows):
    inserted, updated = 0, 0
    for row in rows:
        existing = conn.execute("SELECT key FROM pv_monthly WHERE key=?", (row["key"],)).fetchone()
        conn.execute(
            """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                 einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
                 gesamt=excluded.gesamt""",
            (row["key"], row["pv"], row["bezug"], row["einsp"], row["batt_lad"], row["batt_ent"], row["gesamt"]),
        )
        if existing:
            updated += 1
        else:
            inserted += 1
    return inserted, updated


def _save_settings(conn, meter_type, settings_dict):
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (f"meter_settings_{meter_type}", json.dumps(settings_dict)),
    )


def main():
    init_db()
    conn = get_connection()

    gi, gs = _insert_readings(conn, "gas", GAS_READINGS)
    ei, es = _insert_readings(conn, "elec_in", ELEC_IN_READINGS)
    oi, os_ = _insert_readings(conn, "elec_out", ELEC_OUT_READINGS)
    pvi, pvu = _insert_pv_monthly(conn, PV_MONTHLY)

    _save_settings(conn, "gas", GAS_SETTINGS)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(GAS_MONTHLY_TEMPS),),
    )
    _save_settings(conn, "elec_in", ELEC_IN_SETTINGS)
    _save_settings(conn, "elec_out", ELEC_OUT_SETTINGS)

    conn.commit()
    conn.close()

    print(f"Gas: {gi} Ablesungen importiert, {gs} bereits vorhanden übersprungen")
    print(f"Strombezug: {ei} Ablesungen importiert, {es} bereits vorhanden übersprungen")
    print(f"Einspeisung: {oi} Ablesungen importiert, {os_} bereits vorhanden übersprungen")
    print(f"PV-Monatsdaten: {pvi} neu, {pvu} aktualisiert")
    print("Tarifeinstellungen für Gas, Strombezug und Einspeisung gespeichert.")


if __name__ == "__main__":
    main()
