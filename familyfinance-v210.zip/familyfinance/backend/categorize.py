"""
Einheitliche Kategorisierung nach den festen Themen:
Versicherungen, Abos, Internet, Mobilfunk, Mitgliedsbeiträge, Sparen, Haus
(mit Unterkategorien Finanzierung / Nebenkosten), sowie Sonstiges als Auffangbecken.

Wird sowohl beim Excel-Import als auch bei der Beleg-OCR verwendent, damit
überall dieselbe Struktur entsteht.
"""
from typing import Optional, Tuple

CATEGORIES = [
    "Versicherungen", "Abos", "Internet", "Mobilfunk",
    "Mitgliedsbeiträge", "Sparen", "Haus", "Auto", "Sonstiges",
]

# Exakte Treffer für die aus deiner bestehenden Excel bekannten Positionen.
# (label_lowercase) -> (category, subcategory_or_None)
_EXACT_MAP = {
    "abfallgebühren": ("Haus", "Nebenkosten"),
    "g.e.z.": ("Sonstiges", None),
    "amazon prime": ("Abos", None),
    "deezer": ("Abos", None),
    "thalia skoobe": ("Abos", None),
    "kfz-steuer": ("Auto", None),
    "adac": ("Mitgliedsbeiträge", None),
    "adac krankenschutz": ("Versicherungen", None),
    "handyvertrag raphi": ("Mobilfunk", None),
    "handyvertrag  benny": ("Mobilfunk", None),
    "handyvertrag benny": ("Mobilfunk", None),
    "jano: kindergartengebühren": ("Sonstiges", None),
    "milan: schulgebühren+essen": ("Sonstiges", None),
    "milan: sv ebnet": ("Mitgliedsbeiträge", None),
    "hausratvers.: zurich": ("Versicherungen", None),
    "haftpflicht: vhv": ("Versicherungen", None),
    "autoversicherung: vhv": ("Auto", None),
    "rechtsschutzversicherung ks auxilia": ("Versicherungen", None),
    "benny: allianz risiko-lebensversicherung": ("Versicherungen", None),
    "benny: barmenia zahnzusatzversicherung": ("Versicherungen", None),
    "benny: volkswohl bund berufsunfähigkeitsversicherung": ("Versicherungen", None),
    "inter zusatzversicherungen": ("Versicherungen", None),
    "raphi: swisslife berufsunfähigkeitsversicherung": ("Versicherungen", None),
    "raphi: barmenia zahnzusatzversicherung": ("Versicherungen", None),
    "raphi: sutor-bank riester": ("Sparen", None),
    "tagesgeld r&b": ("Sparen", None),
    "tagesgeld milan": ("Sparen", None),
    "tagesgeld jano": ("Sparen", None),
    "fondssparen": ("Sparen", None),
    "gas – octopus": ("Haus", "Nebenkosten"),
    "gas - octopus": ("Haus", "Nebenkosten"),
    "strom - naturwerke": ("Haus", "Nebenkosten"),
    "wasser / abwasser – bnnetze": ("Haus", "Nebenkosten"),
    "wasser / abwasser - bnnetze": ("Haus", "Nebenkosten"),
    "r+v – gebäudevers. + grundbesitzerhaftpflicht": ("Versicherungen", None),
    "r+v - gebäudevers. + grundbesitzerhaftpflicht": ("Versicherungen", None),
    "grundsteuer": ("Haus", "Nebenkosten"),
    "telefon & internet telekom": ("Internet", None),
    "einspeisevergütung bnnetze": ("Haus", "Nebenkosten"),
    "bbbank baufinanzierung": ("Haus", "Finanzierung"),
    "nebenkosten haus": ("Haus", "Nebenkosten"),
    "netflix": ("Abos", None),
    "disney": ("Abos", None),
}

# Substring-Fallback für alles, was nicht 1:1 bekannt ist (z.B. neue Belege per Foto)
_SUBSTRING_MAP = [
    ("kfz", "Auto"), ("autoversicherung", "Auto"), ("tüv", "Auto"), ("tuv", "Auto"),
    ("werkstatt", "Auto"), ("reifen", "Auto"), ("tanken", "Auto"), ("benzin", "Auto"),
    ("versicherung", "Versicherungen"),
    ("vers.", "Versicherungen"),
    ("octopus", "Haus"), ("naturwerke", "Haus"), ("bnnetze", "Haus"),
    ("gas", "Haus"), ("strom", "Haus"), ("wasser", "Haus"), ("grundsteuer", "Haus"),
    ("baufinanzierung", "Haus"), ("nebenkosten", "Haus"), ("miete", "Haus"),
    ("telekom", "Internet"), ("internet", "Internet"), ("vodafone dsl", "Internet"),
    ("handy", "Mobilfunk"), ("mobilfunk", "Mobilfunk"), ("o2", "Mobilfunk"), ("vodafone", "Mobilfunk"),
    ("deezer", "Abos"), ("netflix", "Abos"), ("disney", "Abos"), ("amazon prime", "Abos"),
    ("spotify", "Abos"), ("skoobe", "Abos"),
    ("adac", "Mitgliedsbeiträge"), ("verein", "Mitgliedsbeiträge"), ("mitglied", "Mitgliedsbeiträge"),
    ("tagesgeld", "Sparen"), ("fondssparen", "Sparen"), ("riester", "Sparen"), ("depot", "Sparen"),
]


def categorize(label: str) -> Tuple[str, Optional[str]]:
    """Gibt (category, subcategory) zurück. subcategory ist nur bei 'Haus' relevant."""
    key = (label or "").strip().lower()
    if key in _EXACT_MAP:
        return _EXACT_MAP[key]
    for needle, category in _SUBSTRING_MAP:
        if needle in key:
            subcategory = "Nebenkosten" if category == "Haus" else None
            if category == "Haus" and "finanzierung" in key:
                subcategory = "Finanzierung"
            return (category, subcategory)
    return ("Sonstiges", None)


def derive_contract_label(category: Optional[str], insurance_type: Optional[str],
                           person_name: Optional[str], provider: Optional[str],
                           contract_number: Optional[str]) -> str:
    """Leitet einen sprechenden Namen aus den Stammdaten ab, wenn kein Name
    manuell gesetzt ist. Bei Versicherungen im bereits etablierten Muster
    'Person: Anbieter Typ' (z.B. 'Benny: Allianz Risikolebensversicherung'),
    sonst 'Anbieter Vertragsnummer'."""
    if category == "Versicherungen":
        parts = []
        if person_name:
            parts.append(f"{person_name}:")
        if provider:
            parts.append(provider)
        parts.append(insurance_type or "Versicherung")
        return " ".join(parts)
    parts = [provider or "Vertrag"]
    if contract_number:
        parts.append(contract_number)
    return " ".join(parts)
