# Family Finance -- Windows Einrichtung & Start
# Läuft alles auf dem Ziel-PC selbst ab (Downloads über die eigene
# Internetverbindung), damit nicht mehrere GB an Fremd-Software durch den
# Chat transportiert werden müssen. Beim ersten Start dauert es je nach
# Verbindung einige Minuten (v.a. das KI-Modell, ca. 5 GB).

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPath = Join-Path $ProjectRoot "venv"
$BackendPath = Join-Path $ProjectRoot "backend"

function Write-Step($text) {
    Write-Host ""
    Write-Host "==> $text" -ForegroundColor Cyan
}

function Test-CommandExists($cmd) {
    return [bool](Get-Command $cmd -ErrorAction SilentlyContinue)
}

# ---------- 1. Python pruefen ----------
Write-Step "Pruefe Python..."
if (-not (Test-CommandExists "python")) {
    Write-Host "Python wurde nicht gefunden." -ForegroundColor Yellow
    Write-Host "Bitte von https://www.python.org/downloads/ installieren"
    Write-Host "(Haken bei 'Add python.exe to PATH' waehrend der Installation setzen!)"
    Write-Host "Danach dieses Skript erneut starten."
    Read-Host "Enter zum Beenden druecken"
    exit 1
}
$pyVersion = python --version
Write-Host "Gefunden: $pyVersion"

# ---------- 2. Virtuelle Umgebung + Python-Pakete ----------
if (-not (Test-Path $VenvPath)) {
    Write-Step "Erstelle virtuelle Python-Umgebung (einmalig)..."
    python -m venv $VenvPath
}
$VenvPython = Join-Path $VenvPath "Scripts\python.exe"
$VenvPip = Join-Path $VenvPath "Scripts\pip.exe"

Write-Step "Installiere/aktualisiere Python-Pakete (einmalig, kann einige Minuten dauern)..."
& $VenvPip install --quiet --upgrade pip
& $VenvPip install --quiet -r (Join-Path $BackendPath "requirements.txt")

# ---------- 3. Tesseract OCR pruefen/installieren ----------
Write-Step "Pruefe Tesseract (Texterkennung fuer Belege)..."
$tesseractDefault = "C:\Program Files\Tesseract-OCR\tesseract.exe"
if ((Test-CommandExists "tesseract") -or (Test-Path $tesseractDefault)) {
    Write-Host "Tesseract bereits vorhanden."
} else {
    Write-Host "Tesseract nicht gefunden -- lade Installer herunter..."
    $tessInstaller = Join-Path $env:TEMP "tesseract-setup.exe"
    Invoke-WebRequest -Uri "https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-5.5.0.20241111.exe" -OutFile $tessInstaller
    Write-Host "Installiere Tesseract (still, ohne Rueckfragen)..."
    Start-Process -FilePath $tessInstaller -ArgumentList "/S" -Wait
    Remove-Item $tessInstaller -ErrorAction SilentlyContinue
    # PATH fuer diese Sitzung ergaenzen, damit es sofort nutzbar ist
    $env:Path += ";C:\Program Files\Tesseract-OCR"
}

# ---------- 4. Poppler (fuer gescannte PDFs ohne Textebene) ----------
Write-Step "Pruefe Poppler (PDF-Seiten-Rendering)..."
$popplerPath = Join-Path $ProjectRoot "poppler\Library\bin"
if (Test-Path $popplerPath) {
    Write-Host "Poppler bereits vorhanden."
} else {
    Write-Host "Poppler nicht gefunden -- lade herunter..."
    $popplerZip = Join-Path $env:TEMP "poppler.zip"
    Invoke-WebRequest -Uri "https://github.com/oschwartz10612/poppler-windows/releases/download/v26.02.0-0/Release-26.02.0-0.zip" -OutFile $popplerZip
    Expand-Archive -Path $popplerZip -DestinationPath (Join-Path $ProjectRoot "poppler-tmp") -Force
    Get-ChildItem (Join-Path $ProjectRoot "poppler-tmp") -Directory | Select-Object -First 1 | ForEach-Object {
        Move-Item $_.FullName (Join-Path $ProjectRoot "poppler") -Force
    }
    Remove-Item (Join-Path $ProjectRoot "poppler-tmp") -Recurse -ErrorAction SilentlyContinue
    Remove-Item $popplerZip -ErrorAction SilentlyContinue
}
$env:Path += ";$popplerPath"

# ---------- 5. Ollama + KI-Modell ----------
Write-Step "Pruefe Ollama (lokales KI-Modell)..."
if (-not (Test-CommandExists "ollama")) {
    Write-Host "Ollama nicht gefunden -- lade Installer herunter (ca. 1 GB, dauert je nach Verbindung)..."
    $ollamaInstaller = Join-Path $env:TEMP "OllamaSetup.exe"
    Invoke-WebRequest -Uri "https://github.com/ollama/ollama/releases/latest/download/OllamaSetup.exe" -OutFile $ollamaInstaller
    Write-Host "Installiere Ollama (still, ohne Rueckfragen)..."
    Start-Process -FilePath $ollamaInstaller -ArgumentList "/SILENT" -Wait
    Remove-Item $ollamaInstaller -ErrorAction SilentlyContinue
    Write-Host "Warte, bis Ollama gestartet ist..."
    Start-Sleep -Seconds 5
}

Write-Step "Pruefe KI-Modell qwen3:8b (ca. 5 GB, laeuft nur beim ersten Mal)..."
$modelList = & ollama list 2>&1
if ($modelList -match "qwen3:8b") {
    Write-Host "Modell bereits vorhanden."
} else {
    Write-Host "Lade Modell herunter -- das dauert je nach Internetverbindung eine Weile..."
    & ollama pull qwen3:8b
}

# ---------- 6. Datenbank einmalig initialisieren (komplett leer) ----------
$dbPath = Join-Path $ProjectRoot "data\finance.db"
if (-not (Test-Path $dbPath)) {
    Write-Step "Richte leere Datenbank ein (erster Start)..."
    Push-Location $BackendPath
    & $VenvPython -c "from database import init_db; init_db()"
    # Alle Module von Anfang an sichtbar, nicht erst manuell in den
    # Einstellungen aktivieren muessen
    & $VenvPython -c @"
import sqlite3, json
conn = sqlite3.connect('../data/finance.db')
for key in ('vorsorge_enabled', 'energy_monitor_enabled'):
    conn.execute(
        'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
        (key, json.dumps(True)),
    )
conn.commit()
conn.close()
"@
    Pop-Location
}

# ---------- 7. Server starten (mit automatischem Neustart nach Updates) ----------
Write-Step "Starte Family Finance..."
Write-Host "Die App oeffnet sich gleich im Browser unter http://localhost:8420"
Write-Host "Dieses Fenster bitte offen lassen, solange die App genutzt wird."
Write-Host "Zum Beenden: dieses Fenster schliessen."
Write-Host ""

Start-Sleep -Seconds 2
Start-Process "http://localhost:8420"

Push-Location $BackendPath
while ($true) {
    & $VenvPython -m uvicorn app:app --host 127.0.0.1 --port 8420
    # Kommt hierher zurueck, wenn sich der Server selbst beendet hat
    # (z.B. nach "Aktualisieren & Neustarten" in den Einstellungen)
    Write-Host "Server wird neu gestartet..."
    Start-Sleep -Seconds 2
}
Pop-Location
