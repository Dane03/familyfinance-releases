"""
Lokaler Finanz-Chatbot — beantwortet Fragen zu Konten, Verträgen, Vermögen
und Ausgaben, komplett offline über Ollama (https://ollama.com), das
ebenfalls lokal auf dem Mac Mini läuft. Kein Datenaustausch mit der Cloud.

WICHTIG, DAUERHAFT GÜLTIG: build_context() muss bei JEDER künftigen
Funktionserweiterung, die neue Datenbank-Tabellen/-Felder mit sich bringt,
mit überprüft und bei Bedarf erweitert werden — sonst kennt der Chatbot
neue App-Bereiche schlicht nicht (siehe z.B. den ursprünglich fehlenden
insurance_type/person_id-Bezug und das komplett fehlende Vermögen, beides
nachträglich ergänzt). Diese Regel gilt ab sofort für jedes Update, nicht
nur rückwirkend.

Voraussetzung auf dem Mac Mini:
    brew install ollama
    ollama serve                     # läuft dauerhaft im Hintergrund
    ollama pull qwen3:8b              # einmalig, ca. 5.2 GB, läuft gut auf M-Chips

Funktionsweise (bewusst einfach gehalten statt komplexer Vektor-Suche):
Bei der Datenmenge einer Familie (ein paar Dutzend Verträge/Posten) passt der
komplette relevante Datenbestand problemlos in den Kontext eines lokalen
Sprachmodells. Eine Vektordatenbank wäre hier unnötige Komplexität — bei sehr
vielen Jahren an Belegdaten kann man später leicht auf Retrieval umstellen.
"""
import json
import re
import urllib.request

from database import get_connection

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "qwen3:8b"

SYSTEM_PROMPT = """Du bist der Finanz-Assistent einer Familie. Du bekommst unten den \
aktuellen Stand aller Konten, Verträge, Vermögenswerte, Einnahmen und anstehenden \
Erinnerungen. Beantworte Fragen NUR auf Basis dieser Daten. Wenn etwas nicht in den \
Daten steht, sag das ehrlich, anstatt zu raten. Antworte auf Deutsch, kurz und klar."""


def build_context() -> str:
    conn = get_connection()
    members = [dict(r) for r in conn.execute("SELECT id, name, role FROM family_members")]
    member_names = {m["id"]: m["name"] for m in members}

    income = [dict(r) for r in conn.execute("SELECT * FROM income WHERE active=1")]
    contracts_raw = [dict(r) for r in conn.execute(
        """SELECT co.label, co.provider, co.contract_number, co.amount, co.frequency,
                  co.contract_end, co.notice_period_days, co.insurance_type, co.person_id,
                  co.subcategory, c.name AS category
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.status='active'"""
    )]
    # person_id durch den tatsächlichen Namen ersetzen -- eine rohe Zahl wie
    # "person_id: 2" ist für das Sprachmodell bedeutungslos, der Name "wem
    # gehört dieser Vertrag" ist es, worauf Fragen wie "wo haben X und ich..."
    # abzielen.
    contracts = []
    for c in contracts_raw:
        pid = c.pop("person_id", None)
        c["person"] = member_names.get(pid, "Haushalt (keiner Person zugeordnet)")
        contracts.append(c)

    pension_accounts = [dict(r) for r in conn.execute(
        """SELECT pa.type, pa.label, pa.provider, pa.is_riester, pa.current_value,
                  pa.monthly_contribution, pa.person_id
           FROM pension_accounts pa"""
    )]
    for p in pension_accounts:
        pid = p.pop("person_id", None)
        p["person"] = member_names.get(pid, "Unbekannt")

    assets_raw = [dict(r) for r in conn.execute(
        """SELECT type, label, provider, purpose, current_value, account_type, person_id, note
           FROM assets"""
    )]
    assets = []
    for a in assets_raw:
        pid = a.pop("person_id", None)
        a["person"] = member_names.get(pid, "Haushalt (gemeinsam)")
        assets.append(a)

    reminders = [dict(r) for r in conn.execute(
        """SELECT r.trigger_date, r.message FROM reminders r
           WHERE r.sent=0 ORDER BY r.trigger_date"""
    )]
    conn.close()

    return (
        "FAMILIENMITGLIEDER:\n" + json.dumps(members, ensure_ascii=False, default=str) + "\n\n"
        "EINNAHMEN:\n" + json.dumps(income, ensure_ascii=False, default=str) + "\n\n"
        "VERTRÄGE / FIXKOSTEN (inkl. Versicherungen -- 'insurance_type' zeigt die genaue Art, "
        "z.B. 'Berufsunfähigkeit', 'Risikolebensversicherung', 'Hausrat'; 'person' zeigt, wem "
        "der Vertrag zugeordnet ist):\n" + json.dumps(contracts, ensure_ascii=False, default=str) + "\n\n"
        "RENTENKONTEN / ALTERSVORSORGE:\n" + json.dumps(pension_accounts, ensure_ascii=False, default=str) + "\n\n"
        "VERMÖGEN (Konten, Depots, Immobilien, Sonstiges -- 'type' unterscheidet 'konto'/"
        "'immobilie'/'depot'/'sonstiges', 'purpose' zeigt den Zweck z.B. 'Altersvorsorge' "
        "oder 'Liquiditätsreserve'):\n" + json.dumps(assets, ensure_ascii=False, default=str) + "\n\n"
        "OFFENE ERINNERUNGEN:\n" + json.dumps(reminders, ensure_ascii=False, default=str)
    )


def ask(question: str) -> str:
    context = build_context()
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT + "\n\n" + context},
            {"role": "user", "content": question},
        ],
        "stream": False,
        # Qwen3 denkt standardmäßig (sichtbarer <think>-Reasoning-Block vor
        # der eigentlichen Antwort) — für einen schnellen Finanz-Chatbot
        # unnötig und würde in der UI wie ein kaputter Text wirken.
        "think": False,
    }
    req = urllib.request.Request(
        OLLAMA_URL, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
        content = data["message"]["content"]
        # Sicherheitsnetz: falls eine Ollama-/Modell-Version "think": false
        # ignoriert und trotzdem einen Denk-Block mitschickt, diesen entfernen
        # statt ihn ungefiltert in der Chat-Oberfläche anzuzeigen.
        content = re.sub(r"<think>.*?</think>\s*", "", content, flags=re.DOTALL).strip()
        return content
    except Exception as e:
        return (f"Der lokale Chatbot (Ollama) ist gerade nicht erreichbar ({e}). "
                f"Läuft 'ollama serve' auf dem Mac Mini?")


if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) or "Welche Verträge laufen bald aus?"
    print(ask(q))
