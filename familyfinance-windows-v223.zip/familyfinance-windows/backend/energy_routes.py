"""
Energy Monitor — alle Endpunkte rund um Zählerstände, Gas/Strom/Wasser,
PV-Anlage und Verbrauchsauswertung.

Aus app.py herausgelöst, um die zentrale Datei überschaubar zu halten. Die
Routen sind unverändert übernommen; registriert werden sie über einen
APIRouter, der in app.py eingebunden wird — die URLs bleiben damit exakt
dieselben wie vorher.
"""
import csv
import hashlib
import io
import json
import re
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

import auth
import meters
from database import get_connection
from ocr import extract_receipt_data

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent
RECEIPTS_DIR = BASE_DIR / "data" / "receipts"


def _get_meter_settings(conn, meter_type: str) -> dict:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (f"meter_settings_{meter_type}",)).fetchone()
    defaults = meters.DEFAULT_SETTINGS.get(meter_type, {})
    if not row:
        return dict(defaults)
    saved = json.loads(row["value"])
    return {**defaults, **saved}


def _get_readings(conn, meter_type: str) -> list:
    rows = conn.execute(
        "SELECT id, reading_date, value, is_new_meter, note, receipt_id FROM meter_readings "
        "WHERE meter_type=? ORDER BY reading_date ASC", (meter_type,),
    ).fetchall()
    return [dict(r) for r in rows]


def _validate_meter_type(meter_type: str):
    if meter_type not in meters.METER_TYPES:
        raise HTTPException(404, f"Unbekannter Zählertyp: {meter_type}")


@router.get("/api/meters/overview")
def meters_overview(session=Depends(auth.require_full_auth)):
    """Kompakte Übersicht aller Zähler fürs Energy-Monitor-Dashboard."""
    conn = get_connection()
    result = []
    for meter_type in meters.METER_TYPES:
        readings = _get_readings(conn, meter_type)
        if not readings:
            continue  # Zähler, für die es noch keine einzige Ablesung gibt, nicht anzeigen
        settings_ = _get_meter_settings(conn, meter_type)
        settlement = meters.compute_settlement(meter_type, readings, settings_)
        result.append({
            "meter_type": meter_type,
            "label": meters.METER_META[meter_type]["label"],
            "icon": meters.METER_META[meter_type]["icon"],
            "unit": meters.METER_META[meter_type]["unit"],
            "latest_reading": readings[-1],
            "current_daily_rate": meters.current_daily_rate(readings),
            "settlement": settlement,
        })
    conn.close()
    return {"meters": result}


@router.get("/api/meters/{meter_type}/readings")
def get_meter_readings(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"readings": readings}


class MeterReadingIn(BaseModel):
    reading_date: date
    value: float
    is_new_meter: bool = False
    note: Optional[str] = None
    receipt_id: Optional[int] = None


@router.post("/api/meters/{meter_type}/readings")
def add_meter_reading(meter_type: str, payload: MeterReadingIn, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    existing = conn.execute(
        "SELECT id FROM meter_readings WHERE meter_type=? AND reading_date=?",
        (meter_type, payload.reading_date.isoformat()),
    ).fetchone()
    if existing:
        conn.close()
        raise HTTPException(409, f"Für den {payload.reading_date.isoformat()} liegt bei diesem Zähler bereits eine Ablesung vor.")
    cur = conn.execute(
        """INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note, receipt_id)
           VALUES (?,?,?,?,?,?)""",
        (meter_type, payload.reading_date.isoformat(), payload.value,
         int(payload.is_new_meter), payload.note, payload.receipt_id),
    )
    reading_id = cur.lastrowid
    if payload.receipt_id:
        conn.execute("UPDATE receipts SET review_needed=0 WHERE id=?", (payload.receipt_id,))
    conn.commit()
    conn.close()
    return {"id": reading_id, "status": "created"}


@router.delete("/api/meters/{meter_type}/readings/{reading_id}")
def delete_meter_reading(meter_type: str, reading_id: int, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    conn.execute("DELETE FROM meter_readings WHERE id=? AND meter_type=?", (reading_id, meter_type))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/meters/{meter_type}/settings")
def get_meter_settings_endpoint(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    settings_ = _get_meter_settings(conn, meter_type)
    conn.close()
    return settings_


@router.put("/api/meters/{meter_type}/settings")
def put_meter_settings(meter_type: str, payload: dict, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    current = _get_meter_settings(conn, meter_type)
    current.update(payload)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (f"meter_settings_{meter_type}", json.dumps(current)),
    )
    conn.commit()
    conn.close()
    return current


@router.get("/api/meters/{meter_type}/monthly")
def get_meter_monthly(meter_type: str, session=Depends(auth.require_full_auth)):
    """Monatsverbrauch fürs Diagramm — inkl. Prognose fürs laufende Jahr für
    Monate ohne echte Ablesung/Import."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    monthly = meters.get_effective_monthly(meter_type, readings, pv_monthly)
    rate = meters.current_daily_rate(readings)
    today = date.today()
    forecast = meters.forecast_missing_months(
        monthly, rate, date(today.year, 1, 1), date(today.year, 12, 31)
    )
    return {"monthly": monthly, "forecast": forecast, "current_daily_rate": rate}


@router.get("/api/meters/{meter_type}/kpis")
def get_meter_kpis(meter_type: str, session=Depends(auth.require_full_auth)):
    """Die 5 KPI-Chips für die Detailseite (Letzter Stand, Tagesrate,
    optimaler Abschlag, erwartete Differenz, Jahresprognose)."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"chips": meters.compute_kpi_chips(meter_type, readings, settings_, pv_monthly)}


def _refresh_actual_temperatures_if_due():
    """Holt beim Serverstart automatisch aktuelle Monatstemperaturen nach —
    aber höchstens einmal pro Tag, damit ein mehrfacher Neustart am selben
    Tag nicht unnötig oft die (kostenlose, aber fremde) Wetter-API
    beansprucht. Läuft komplett im Hintergrund; ein Fehlschlag (kein
    Standort hinterlegt, kein Netz) darf den App-Start nie verzögern oder
    stören."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        return

    last_row = conn.execute("SELECT value FROM settings WHERE key='weather_last_fetched'").fetchone()
    last_fetched = json.loads(last_row["value"]) if last_row else None
    today_str = date.today().isoformat()
    if last_fetched == today_str:
        conn.close()
        return

    import threading

    def _do_fetch():
        fresh = meters.fetch_actual_monthly_temperatures(location)
        if not fresh:
            return
        c = get_connection()
        existing_row = c.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
        existing = json.loads(existing_row["value"]) if existing_row else {}
        existing.update(fresh)  # neue/aktualisierte Monate überschreiben, ältere bleiben erhalten
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(existing),),
        )
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(today_str),),
        )
        c.commit()
        c.close()

    # Im Hintergrund, damit ein langsamer/fehlender Netzwerkzugriff den
    # eigentlichen Serverstart nicht blockiert.
    threading.Thread(target=_do_fetch, daemon=True).start()
    conn.close()


@router.post("/api/meters/gas/temperature/refresh")
def refresh_gas_temperature(session=Depends(auth.require_full_auth)):
    """Manueller Sofort-Abruf (z.B. nach dem erstmaligen Eintragen eines
    Standorts, ohne auf den nächsten Neustart warten zu müssen)."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        raise HTTPException(400, "Kein Standort in den Einstellungen hinterlegt.")

    fresh = meters.fetch_actual_monthly_temperatures(location)
    if not fresh:
        conn.close()
        return {"status": "error", "error": "Kein Ergebnis — Standort nicht gefunden oder Wetterdienst nicht erreichbar."}

    existing_row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    existing = json.loads(existing_row["value"]) if existing_row else {}
    existing.update(fresh)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(existing),),
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(date.today().isoformat()),),
    )
    conn.commit()
    conn.close()
    return {"status": "ok", "months_updated": len(fresh)}


@router.get("/api/meters/gas/temperature")
def get_gas_temperature(session=Depends(auth.require_full_auth)):
    """Klimamittel (DWD, statisch) + tatsächliche Monatstemperaturen für die
    Temperatur-Kurve auf der Gas-Seite."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    conn.close()
    actual = json.loads(row["value"]) if row else {}
    return {"dwd_climate_avg": meters.DWD_CLIMATE_AVG, "actual": actual}


@router.get("/api/meters/{meter_type}/intervals")
def get_meter_intervals(meter_type: str, session=Depends(auth.require_full_auth)):
    """Ablesungen mit Delta/Tage/Tagesrate für die Detailtabelle."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"intervals": meters.compute_reading_intervals(readings)}


@router.get("/api/meters/{meter_type}/cumulative")
def get_meter_cumulative(meter_type: str, session=Depends(auth.require_full_auth)):
    """Kumulative Ist-Kosten vs. Abschlag vs. optimaler Abschlag übers Jahr —
    nicht sinnvoll für Einspeisung (keine Kosten, sondern Erlös)."""
    _validate_meter_type(meter_type)
    if meter_type == "elec_out":
        raise HTTPException(400, "Kumulativ-Ansicht ist nur für Gas und Strombezug verfügbar.")
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_cumulative_cost(meter_type, readings, settings_, pv_monthly)}


class PVSystemSpecIn(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: date
    note: Optional[str] = None


class PVSystemSpecPatch(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: Optional[date] = None
    note: Optional[str] = None


@router.get("/api/pv/system-specs")
def list_pv_system_specs(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM pv_system_specs ORDER BY valid_from").fetchall()
    conn.close()

    today = date.today().isoformat()
    specs = [dict(r) for r in rows]
    # Aktuell gültigen und (falls vorhanden) als nächstes anstehenden
    # Ausbauschritt markieren — nützlich für die geplante Erweiterung, damit
    # die Oberfläche "ab wann gilt was" nicht selbst nachrechnen muss.
    current = None
    upcoming = []
    for s in specs:
        if s["valid_from"] <= today:
            current = s
        else:
            upcoming.append(s)
    return {"specs": specs, "current": current, "upcoming": upcoming}


@router.post("/api/pv/system-specs")
def create_pv_system_spec(payload: PVSystemSpecIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO pv_system_specs (installed_year, kwp, battery_kwh, valid_from, note)
           VALUES (?,?,?,?,?)""",
        (payload.installed_year, payload.kwp, payload.battery_kwh, payload.valid_from, payload.note),
    )
    conn.commit()
    sid = cur.lastrowid
    conn.close()
    return {"id": sid, "status": "created"}


@router.patch("/api/pv/system-specs/{spec_id}")
def update_pv_system_spec(spec_id: int, patch: PVSystemSpecPatch, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    if not fields:
        conn.close()
        return {"status": "unchanged"}
    fields["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE pv_system_specs SET {set_clause} WHERE id=?", (*fields.values(), spec_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@router.delete("/api/pv/system-specs/{spec_id}")
def delete_pv_system_spec(spec_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    conn.execute("DELETE FROM pv_system_specs WHERE id=?", (spec_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/pv/autarkie")
def get_pv_autarkie(session=Depends(auth.require_full_auth)):
    """Autarkiegrad je Monat (PV-Eigenverbrauchsanteil) — für den
    Autarkie-Chart auf der Strom-Detailseite."""
    conn = get_connection()
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_autarkie_series(pv_monthly)}


@router.get("/api/meters/{meter_type}/settlement")
def get_meter_settlement(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    if not readings:
        raise HTTPException(400, "Noch keine Ablesungen für diesen Zähler erfasst.")
    return meters.compute_settlement(meter_type, readings, settings_, pv_monthly)


# ---------- Energy Monitor Dashboard: vollständige Übersicht ----------

def _all_readings_and_settings(conn) -> tuple:
    readings_by_type = {mt: _get_readings(conn, mt) for mt in meters.METER_TYPES}
    settings_by_type = {mt: _get_meter_settings(conn, mt) for mt in meters.METER_TYPES}
    return readings_by_type, settings_by_type


def _get_pv_monthly(conn) -> list:
    rows = conn.execute(
        "SELECT key, pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_monthly ORDER BY key"
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/api/energy/overview")
def energy_overview(range: str = "ytd", session=Depends(auth.require_full_auth)):
    """Die vier KPI-Karten (Gas, Bezug, Einspeisung, PV-Ertrag) für den
    Energy-Monitor-Dashboard-Kopf, für den gewählten Zeitraum."""
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    cards = meters.compute_overview_cards(readings_by_type, settings_by_type, pv_monthly, range)
    return {"ranges": meters.RANGES, **cards}


@router.get("/api/energy/cost-trend")
def energy_cost_trend(range: str = "ytd", session=Depends(auth.require_full_auth)):
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_cost_trend(readings_by_type, settings_by_type, pv_monthly, range)}


@router.get("/api/energy/settlement")
def energy_settlement(session=Depends(auth.require_full_auth)):
    """Vollständige Jahresabrechnung — Gas, Strombezug und Einspeisung mit
    Fälligkeits-Countdown, für den Jahresabrechnung-Block im Dashboard."""
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return meters.compute_full_settlement(readings_by_type, settings_by_type, pv_monthly)


class MeterSettlementIn(BaseModel):
    meter_type: str
    settlement_date: date
    note: Optional[str] = None


@router.get("/api/energy/settlements")
def list_meter_settlements(session=Depends(auth.require_full_auth)):
    """Alle manuell erfassten Abrechnungszeitpunkte, je Zählerseite —
    unabhängig von der kalenderjahr-basierten Jahresabrechnung oben. Der
    jeweils letzte Eintrag pro Zählerseite dient als Reset-Basis für
    'Verbrauch seit der Abrechnung'."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.post("/api/energy/settlements")
def create_meter_settlement(payload: MeterSettlementIn, session=Depends(auth.require_full_auth)):
    if payload.meter_type not in meters.METER_TYPES:
        raise HTTPException(400, f"Ungültiger Zählertyp: {payload.meter_type}")
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO meter_settlements (meter_type, settlement_date, note) VALUES (?,?,?)",
        (payload.meter_type, payload.settlement_date.isoformat(), payload.note),
    )
    conn.commit()
    conn.close()
    return {"id": cur.lastrowid, "status": "created"}


@router.delete("/api/energy/settlements/{settlement_id}")
def delete_meter_settlement(settlement_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM meter_settlements WHERE id=?", (settlement_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Abrechnungszeitpunkt nicht gefunden")
    conn.execute("DELETE FROM meter_settlements WHERE id=?", (settlement_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/energy/consumption-since-settlement")
def consumption_since_settlement_overview(session=Depends(auth.require_full_auth)):
    """Verbrauch seit dem jeweils letzten manuell erfassten Abrechnungs-
    zeitpunkt, je Zählerseite — ergänzt die Jahresabrechnung oben um einen
    Reset-Punkt, der nicht an den Kalenderjahreswechsel gebunden ist."""
    conn = get_connection()
    readings_by_type, _ = _all_readings_and_settings(conn)
    settlements = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()

    result = {}
    for mt in meters.METER_TYPES:
        latest_settlement = next((s for s in settlements if s["meter_type"] == mt), None)
        if not latest_settlement:
            result[mt] = None
            continue
        settlement_date = date.fromisoformat(latest_settlement["settlement_date"])
        readings = [dict(r) for r in (readings_by_type.get(mt) or [])]
        since = meters.consumption_since_settlement(readings, settlement_date)
        if since:
            since["settlement_note"] = latest_settlement["note"]
        result[mt] = since
    return result


@router.get("/api/pv/monthly")
def get_pv_monthly(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    data = _get_pv_monthly(conn)
    conn.close()
    return {"months": data, "plant": meters.PV_PLANT_DEFAULTS}


class PVMonthIn(BaseModel):
    key: str
    pv: float = 0
    bezug: float = 0
    einsp: float = 0
    batt_lad: float = 0
    batt_ent: float = 0
    gesamt: float = 0


@router.put("/api/pv/monthly/{key}")
def upsert_pv_month(key: str, payload: PVMonthIn, session=Depends(auth.require_full_auth)):
    if not re.match(r"^\d{4}-\d{2}$", key):
        raise HTTPException(400, "Ungültiger Monatsschlüssel (erwartet YYYY-MM).")
    conn = get_connection()
    conn.execute(
        """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
             einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
             gesamt=excluded.gesamt""",
        (key, payload.pv, payload.bezug, payload.einsp, payload.batt_lad, payload.batt_ent, payload.gesamt),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


@router.delete("/api/pv/monthly/{key}")
def delete_pv_month(key: str, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM pv_monthly WHERE key=?", (key,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.post("/api/pv/import")
async def import_pv_sungrow(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    """Sungrow-Jahresbericht (iSolarCloud-Export, XLSX) einlesen — Spalten
    'Zeit', 'PV-Ertrag(kWh)', 'Netzbezug(kWh)', 'Einspeisung(kWh)',
    'Batt.-Ladung(kWh)', 'Batt.-Entladung(kWh)', 'Gesamtverbrauch(kWh)'.
    Bestehende Monate werden aktualisiert, neue Monate ergänzt."""
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    tmp_path = SMART_IMPORT_STAGING / f"pv_{hashlib.sha256(content).hexdigest()[:12]}.xlsx"
    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)
    try:
        import pandas as pd
        df = pd.read_excel(tmp_path, engine="openpyxl")
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise HTTPException(400, f"Datei konnte nicht gelesen werden: {e}")
    tmp_path.unlink(missing_ok=True)

    cols = df.columns.tolist()

    def find_col(fragment):
        return next((c for c in cols if fragment.lower() in str(c).lower()), None)

    zeit_col = find_col("zeit")
    pv_col, bezug_col, einsp_col = find_col("pv-ertrag"), find_col("netzbezug"), find_col("einspeisung")
    batt_lad_col, batt_ent_col = find_col("batt.-ladung"), find_col("batt.-entladung")
    ges_col = find_col("gesamtverbrauch")

    if not zeit_col or not pv_col or not einsp_col:
        raise HTTPException(
            400,
            "Diese Datei sieht nicht wie ein Sungrow-Jahresbericht aus — erwartet werden "
            "Spalten wie 'Zeit', 'PV-Ertrag(kWh)', 'Einspeisung(kWh)', 'Netzbezug(kWh)'.",
        )

    conn = get_connection()
    added, updated = 0, 0
    for _, row in df.iterrows():
        zeit = str(row[zeit_col]).strip()
        m = re.match(r"^(\d{4})-(\d{1,2})$", zeit)
        if not m:
            continue
        key = f"{m.group(1)}-{int(m.group(2)):02d}"

        def num(col):
            if not col or col not in df.columns:
                return 0.0
            try:
                return float(str(row[col]).replace(",", "."))
            except (ValueError, TypeError):
                return 0.0

        existing = conn.execute("SELECT key FROM pv_monthly WHERE key=?", (key,)).fetchone()
        conn.execute(
            """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                 einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
                 gesamt=excluded.gesamt""",
            (key, num(pv_col), num(bezug_col), num(einsp_col), num(batt_lad_col), num(batt_ent_col), num(ges_col)),
        )
        if existing:
            updated += 1
        else:
            added += 1
    conn.commit()
    conn.close()
    return {"added": added, "updated": updated}


@router.post("/api/meters/{meter_type}/upload")
async def upload_meter_bill(meter_type: str, file: UploadFile = File(...),
                             session=Depends(auth.require_full_auth)):
    """Foto/PDF einer Ablesekarte oder Abrechnung einlesen — analog zum
    Beleg-Upload bei den Ausgaben: lokale OCR-Erkennung, Vorschlag zur
    Bestätigung, kein automatisches Speichern eines Zählerstands."""
    _validate_meter_type(meter_type)
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    file_hash = hashlib.sha256(content).hexdigest()
    conn = get_connection()
    existing = conn.execute(
        "SELECT id, uploaded_at FROM receipts WHERE file_hash=? AND review_needed=0",
        (file_hash,),
    ).fetchone()
    if existing:
        conn.close()
        raise HTTPException(409, f"Diese exakte Datei wurde bereits am {existing['uploaded_at']} importiert.")
    # Beide Module werden von app.py eingebunden, ein Import auf Modulebene
    # wäre ein Zirkelbezug -- zum Aufrufzeitpunkt ist alles fertig geladen.
    import receipts_routes
    receipts_routes._cleanup_unconfirmed_receipts(conn, max_age_hours=None)
    conn.close()

    today = datetime.now()
    safe_stem = re.sub(r"[^\w.-]", "_", Path(file.filename or "zaehlerstand").stem)[:80] or "zaehlerstand"
    suffix = Path(file.filename or "").suffix or ".jpg"
    filename = f"{today.strftime('%Y%m%d%H%M%S')}_{safe_stem}{suffix}"
    tmp_path = RECEIPTS_DIR / "_unbestaetigt" / filename
    tmp_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)

    result = extract_receipt_data(tmp_path)

    # Aus dem erkannten Text zusätzlich nach einem plausiblen Zählerstand
    # suchen (reine Zahl, evtl. mit Tausenderpunkt, in der Nähe von "Zähler-
    # stand"/"Stand"/"m³"/"kWh") — Betrag bleibt die primäre OCR-Info, der
    # Zählerstand ist ein zusätzlicher Bonus-Fund, kein Muss.
    suggested_value = None
    if result.get("raw_text"):
        m = re.search(
            r"(?:z[äa]hlerstand|stand|z[äa]hlerstd)[^\d]{0,15}(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,3})?)",
            result["raw_text"], re.IGNORECASE,
        )
        if m:
            try:
                suggested_value = float(m.group(1).replace(".", "").replace(",", "."))
            except ValueError:
                suggested_value = None

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO receipts
           (original_filename, stored_path, file_hash, ocr_text, detected_amount,
            detected_provider, detected_date, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(tmp_path.relative_to(BASE_DIR)), file_hash, result.get("raw_text"),
         result.get("amount"), result.get("provider"),
         result["date"].isoformat() if result.get("date") else None),
    )
    receipt_id = cur.lastrowid
    conn.commit()
    conn.close()

    return {
        "receipt_id": receipt_id,
        "suggested_value": suggested_value,
        "suggested_date": result["date"].isoformat() if result.get("date") else None,
        "detected": result,
        "note": ("Zählerstand erkannt — bitte prüfen." if suggested_value
                  else "Kein Zählerstand automatisch erkannt — bitte manuell eintragen."),
    }
