"""
Gemeinsam genutzte kleine Helfer, die mehrere Route-Module brauchen.

Bewusst ein eigenes Modul statt einer Definition in app.py: Die Route-Module
werden VON app.py eingebunden, ein Import in die Gegenrichtung wäre ein
Zirkelbezug. Hier importiert niemand etwas aus app.py, damit bleibt die
Abhängigkeitsrichtung eindeutig.
"""
import re
from typing import Optional


def monthly_expr(amount_col: str, freq_col: str, split_col: Optional[str] = None) -> str:
    """Baut einen SQL-Ausdruck, der einen Betrag unabhängig von seinem
    Zahlungsintervall auf einen Monatswert normalisiert — damit lassen sich
    monatliche, quartalsweise und jährliche Posten direkt vergleichen und
    summieren."""
    amt = f"{amount_col}*{split_col}" if split_col else amount_col
    return (f"CASE {freq_col} WHEN 'monthly' THEN {amt} "
            f"WHEN 'quarterly' THEN {amt}/3.0 WHEN 'yearly' THEN {amt}/12.0 END")


def _contract_folder_parts(category_name: str, subcategory: Optional[str],
                            provider: Optional[str], label: str,
                            person_name: Optional[str] = None) -> list:
    """Die Ordner-Teilpfade für die Ablage eines Vertrags — dieselbe Logik wie
    beim Einsortieren eines bestätigten Belegs, damit Archivieren denselben
    Ordner wiederfindet, den confirm_receipt angelegt hat. Ist der Vertrag
    einer Person zugeordnet (z.B. eine individuelle BU-Versicherung), wird
    dafür eine eigene Ordnerebene eingezogen, damit sich z.B. Annas und
    Toms Versicherungsunterlagen nicht im selben Ordner vermischen.
    Haushaltsweite Verträge ohne Personen-Zuordnung bleiben unverändert."""
    category_slug = re.sub(r"[^\w.-]", "_", category_name or "Sonstiges")
    contract_slug = re.sub(r"[^\w.-]", "_", (provider or label or "Vertrag"))[:60]
    parts = [category_slug]
    if subcategory:
        parts.append(re.sub(r"[^\w.-]", "_", subcategory))
    if person_name:
        parts.append(re.sub(r"[^\w.-]", "_", person_name))
    parts.append(contract_slug)
    return parts
