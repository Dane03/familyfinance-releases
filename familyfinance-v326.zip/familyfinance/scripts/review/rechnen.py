"""Regressionsschutz für die Rechenlogik — reine Funktionsaufrufe, kein Server, keine Datenbank.

Jeder Fall hat von Hand nachrechenbare Zahlen (Rechenweg im Kommentar). Läuft in wenigen Sekunden:
    cd kopie/backend && python3 ../scripts/review/rechnen.py
Exit-Code 0 = alles grün, 1 = mindestens eine Abweichung.

Herkunft der Fälle: Nachtlauf Fachlogik 2026-10-11 (Tagesrate, Auto/Haushalt) und Fixes v326
(29.02., 0-%-Darlehen, effektiver Monatszins).
"""
import sqlite3
import sys
from datetime import date
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))          # aus backend/ starten
import meters                                 # noqa: E402
import cost_shares                            # noqa: E402
import finanzierung                           # noqa: E402
import vorsorge                               # noqa: E402
import shared_helpers                         # noqa: E402

FAILS = []


def check(name, got, want, tol=0.005):
    ok = (abs(got - want) <= tol) if isinstance(want, (int, float)) and not isinstance(want, bool) and got is not None \
        else got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


class FakeDate(date):
    TODAY = date(2026, 10, 11)

    @classmethod
    def today(cls):
        return cls.TODAY


# ---------- Intervalle: 300 €/Quartal = 1200 €/Jahr = 100 €/Monat ----------
for freq, amount in (("monthly", 100), ("quarterly", 300), ("yearly", 1200)):
    check(f"monthly_amount {freq}", shared_helpers.monthly_amount(amount, freq), 100)
    check(f"cost_shares._monthly {freq}", cost_shares._monthly(amount, freq), 100)
db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE t (amount REAL, frequency TEXT, split REAL)")
db.executemany("INSERT INTO t VALUES (?,?,?)", [(100, "monthly", 1), (300, "quarterly", 0.5), (1200, "yearly", 1)])
check("monthly_expr Summe (100 + 300/3×0,5 + 1200/12)",
      db.execute(f"SELECT SUM({shared_helpers.monthly_expr('amount', 'frequency', 'split')}) FROM t").fetchone()[0], 250)

# ---------- Tilgung ----------
# 0 %: 12.000 € mit 1.000 €/Monat -> genau 12 Monate, 0 € Zinsen
r = finanzierung.compute_repayment_schedule(12000, 0.0, monthly_payment=1000, start=date(2026, 1, 1))
check("0-%-Darlehen: kein Fehler", r["error"], None)
check("0-%-Darlehen: Monate", r["months_to_payoff"], 12)
check("0-%-Darlehen: Zinsen", r["total_interest"], 0.0)
# 12 % p.a. = 1 %/Monat, 1.000 € Schuld, 510 €/Monat:
#   Monat 1: Zins 10, Tilgung 500 -> 500 Rest; Monat 2: Zins 5, Rest 500 getilgt -> 15 € Zinsen, 2 Monate
r = finanzierung.compute_repayment_schedule(1000, 12.0, monthly_payment=510, start=date(2026, 1, 1))
check("Annuität 12 %: Monate", r["months_to_payoff"], 2)
check("Annuität 12 %: Zinsen", r["total_interest"], 15.0)
# Rate unter den Zinsen (100.000 € × 3 % / 12 = 250 € Zins, Rate 200 €) -> klare Fehlermeldung
r = finanzierung.compute_repayment_schedule(100000, 3.0, monthly_payment=200)
check("Rate unter Zinsen -> Fehler", bool(r["error"]), True)

# ---------- Vorsorge ----------
check("67. Geburtstag bei *29.02.1964 (2031 kein Schaltjahr)", vorsorge.retirement_date_for(date(1964, 2, 29)), date(2031, 2, 28))
check("67. Geburtstag bei *15.06.1985", vorsorge.retirement_date_for(date(1985, 6, 15)), date(2052, 6, 15))
check("Jahre bis Rente am Stichtag", vorsorge.years_until_retirement(date(1964, 2, 29), today=date(2031, 2, 28)), 0.0)
# 1.000 € × 1,03 = 1.030 € nach einem Jahr (nicht 1.030,42 € wie mit 0,25 %/Monat)
check("Projektion 3 % p.a., 1 Jahr", vorsorge.project_private_pension_capital(1000, 0, 1, 0.03), 1030.0)
# 1.000 € × 1,03^10 = 1.343,92 €
check("Projektion 3 % p.a., 10 Jahre", vorsorge.project_private_pension_capital(1000, 0, 10, 0.03), 1343.92)
# 0 %: 100 €/Monat × 12 = 1.200 €
check("Projektion 0 %, Beiträge", vorsorge.project_private_pension_capital(0, 100, 1, 0.0), 1200.0)
# Rente: 300.000 € über 25 Jahre = 300.000 / 300 = 1.000 €/Monat
check("Kapital -> Monatsrente", vorsorge.capital_to_monthly_pension(300000, 25), 1000.0)

# ---------- Strom-Tagesrate im laufenden Monat (heute 11.10.) ----------
with patch.object(meters, "date", FakeDate):
    # 66 kWh bis zum 11. -> 66 / 11 = 6,00 kWh/Tag (Fehler bis v323: 66 / 31 = 2,13)
    check("Tagesrate laufender Monat", meters.current_daily_rate_with_pv("elec_in", [], [{"key": "2026-10", "bezug": 66}]), 6.0)
    # abgeschlossener Monat: 180 kWh im September / 30 = 6,00
    check("Tagesrate Vormonat", meters.current_daily_rate_with_pv("elec_in", [], [{"key": "2026-09", "bezug": 180}]), 6.0)

    # ---------- Auto/Haushalt (Rechenweg aus dem Nachtlauf 2026-10-11) ----------
    # Jeden Tag 6 kWh Bezug, 10 kWh Hausverbrauch, davon 2 kWh Auto; 0,30 €/kWh, 12 €/Monat Grundpreis.
    # Jahreskosten = 365 × 6 × 0,30 + 12 × 12 = 801 €; Auto = 365 × 6 × 0,2 × 0,30 = 131,40 €.
    year = 2026
    pv_daily, ev_readings, cum = [], [], 0.0
    d = date(year, 1, 1)
    while d <= FakeDate.TODAY:
        pv_daily.append({"key": d.isoformat(), "bezug": 6.0, "gesamt": 10.0})
        cum += 2.0
        ev_readings.append({"reading_date": d.isoformat(), "value": cum})
        d = date.fromordinal(d.toordinal() + 1)
    consumption = {f"{year}-{m:02d}": 6.0 * meters._days_in_month(year, m) for m in range(1, 13)}
    ev_monthly = {f"{year}-{m:02d}": 2.0 * meters._days_in_month(year, m) for m in range(1, 13)}
    gesamt = {f"{year}-{m:02d}": 10.0 * meters._days_in_month(year, m) for m in range(1, 13)}
    res = meters.split_auto_household_cost(consumption, ev_monthly, year, 0.30, 12.0,
                                           pv_daily=pv_daily, ev_readings=ev_readings, gesamt_by_month=gesamt)
    check("Auto + Haushalt = Jahreskosten", res["auto"] + res["haus"], 801.0, tol=0.01)
    check("davon Auto", res["auto"], 131.40, tol=0.01)

# ---------- Kostenbeteiligung: 1/2 von 120 €/Monat + 1/2 von 360 €/Quartal = 60 + 60 = 120 € ----------
db = sqlite3.connect(":memory:")
db.row_factory = sqlite3.Row
db.executescript("""
CREATE TABLE income (id INTEGER PRIMARY KEY, label TEXT, amount REAL, frequency TEXT, active INTEGER DEFAULT 1);
CREATE TABLE contracts (id INTEGER PRIMARY KEY, label TEXT, provider TEXT, amount REAL, frequency TEXT,
                        status TEXT DEFAULT 'active', split_share REAL DEFAULT 1.0);
CREATE TABLE income_cost_shares (income_id INTEGER, contract_id INTEGER, share REAL);
INSERT INTO income VALUES (1, 'Anteil Haus', 120, 'monthly', 1);
INSERT INTO contracts (id, label, amount, frequency) VALUES (1, 'Gas', 120, 'monthly'), (2, 'Wasser', 360, 'quarterly');
INSERT INTO income_cost_shares VALUES (1, 1, 0.5), (1, 2, 0.5);
""")
with patch.object(cost_shares, "_contract_names", lambda conn: {}):
    c = cost_shares.check_all(db)[0]
    check("Kostenbeteiligung erwartet", c["expected_monthly"], 120.0)
    check("Kostenbeteiligung ok", c["ok"], True)
    check("ohne split_share keine Warnung", c["split_contracts"], [])
    db.execute("UPDATE contracts SET split_share=0.5 WHERE id=1")
    c = cost_shares.check_all(db)[0]
    check("split_share < 1 -> Warnung", c["split_contracts"], ["Gas"])

print()
if FAILS:
    print(f"✗ {len(FAILS)} Abweichung(en): {', '.join(FAILS)}")
    sys.exit(1)
print("✓ Rechenlogik: alle Fälle stimmen")
