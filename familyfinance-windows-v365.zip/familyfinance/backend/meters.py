"""
Energy Monitor — Berechnungslogik für Zählerstände, Verbrauch und Abrechnung.

Migriert aus der eigenständigen Energy-Monitor-App (localStorage-basiert) in
die Family-Hub-Datenbank. Rechenlogik bewusst vereinfacht gegenüber dem
Original:
- Verbrauchsprognose für fehlende Monate nutzt die aktuelle Tagesrate statt
  der sehr hausspezifischen Monatsfaktor-Tabelle des Originals.
- Der Sungrow/PV-Import (iSolarCloud) ist NICHT migriert — nur Gas, Strombezug,
  Strom-Einspeisung und neu Wasser, mit denselben Kernrechnungen (Verbrauch,
  Tagesrate, Abrechnungsvergleich Abschlag vs. tatsächliche Kosten).

Zählerwechsel werden generisch über das Flag is_new_meter gehandhabt: die
erste Ablesung nach einem Wechsel markiert eine Zäsur, das Intervall davor
wird bei der Verbrauchsberechnung übersprungen — keine hausspezifischen
Konstanten mehr nötig (anders als im Original mit fest einprogrammiertem
ELEC_BASIS_OLD).
"""
import json
from datetime import date, datetime, timedelta
from typing import Optional

METER_TYPES = ("gas", "elec_in", "elec_out", "water", "ev_charging")

METER_META = {
    "gas": {"label": "Gas", "unit": "m³", "icon": "🔥"},
    "elec_in": {"label": "Strombezug", "unit": "kWh", "icon": "⚡"},
    "elec_out": {"label": "Einspeisung", "unit": "kWh", "icon": "↑"},
    "water": {"label": "Wasser", "unit": "m³", "icon": "💧"},
    # Bewusst als eigener, vollwertiger Zählertyp statt nur einer Kennzahl --
    # dadurch bekommt "Auto laden" automatisch dieselbe Infrastruktur wie
    # Gas/Wasser/Strom (Chart, KPI-Kacheln, Jahresabrechnung), ohne
    # Sonderfälle im Code. Die "Ablesungen" sind dabei keine echten
    # physischen Zählerstände, sondern ein aus den täglichen Zappi-Werten
    # aufsummierter, synthetischer Zählerstand (siehe zappi_client.py).
    "ev_charging": {"label": "Auto laden", "unit": "kWh", "icon": "🚗"},
}

# Anlagenstammdaten der PV-Anlage — rein informativ auf der Übersichtskarte,
# kein Berechnungsfaktor. Bewusst ohne Vorbelegung, jede Installation trägt
# ihre eigene Anlage über die Einstellungen ein.
PV_PLANT_DEFAULTS = {"kwp": 0, "model": "", "hersteller": ""}

# Klimamittel-Referenzwerte (DWD, bundesweiter Durchschnitt Deutschland) —
# permanente Konstante, kein Live-Datenabruf. Für die Temperatur-Kurve auf
# der Gas-Seite. Bewusst der bundesweite statt ein regionaler Durchschnitt,
# damit kein Rückschluss auf den Wohnort einzelner Nutzer möglich ist.
DWD_CLIMATE_AVG = {1: 2.1, 2: 2.8, 3: 6.2, 4: 10.3, 5: 14.4, 6: 17.4,
                   7: 19.4, 8: 19.0, 9: 14.9, 10: 10.3, 11: 5.6, 12: 2.9}

RANGES = [
    {"id": "1m", "label": "1 Mo"},
    {"id": "3m", "label": "3 Mo"},
    {"id": "12m", "label": "12 Mo"},
    {"id": "ytd", "label": "YTD"},
    {"id": "all", "label": "Gesamt"},
]


def fetch_actual_monthly_temperatures(location: str, months_back: int = 15) -> dict:
    """Holt tatsächliche Monats-Durchschnittstemperaturen für einen vom
    Nutzer selbst eingetragenen Standort (z.B. Ort oder Postleitzahl) über
    Open-Meteo — kostenlos, ohne API-Schlüssel, kein Standort fest im Code
    hinterlegt. Wird nur aufgerufen, wenn der Nutzer selbst einen Standort
    in den Einstellungen hinterlegt hat. Gibt {} zurück und wirft nie einen
    Fehler nach außen, falls Standort leer, Geocoding erfolglos oder das
    Netzwerk nicht erreichbar ist -- ein fehlgeschlagener Wetter-Abruf darf
    den restlichen App-Start niemals stören."""
    import urllib.request
    import urllib.parse
    from datetime import date as _date, timedelta

    if not location or not location.strip():
        return {}

    try:
        geo_url = "https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(
            {"name": location.strip(), "count": 1, "language": "de"}
        )
        with urllib.request.urlopen(geo_url, timeout=10) as resp:
            geo = json.loads(resp.read().decode("utf-8"))
        results = geo.get("results") or []
        if not results:
            return {}
        lat, lon = results[0]["latitude"], results[0]["longitude"]

        end = _date.today() - timedelta(days=3)  # Archiv braucht ein paar Tage Vorlauf
        start = (end.replace(day=1) - timedelta(days=months_back * 31)).replace(day=1)
        archive_url = "https://archive-api.open-meteo.com/v1/archive?" + urllib.parse.urlencode({
            "latitude": lat, "longitude": lon,
            "start_date": start.isoformat(), "end_date": end.isoformat(),
            "daily": "temperature_2m_mean", "timezone": "auto",
        })
        with urllib.request.urlopen(archive_url, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        daily = data.get("daily", {})
        dates = daily.get("time", [])
        temps = daily.get("temperature_2m_mean", [])
        by_month: dict[str, list[float]] = {}
        for d, t in zip(dates, temps):
            if t is None:
                continue
            month_key = d[:7]  # "YYYY-MM"
            by_month.setdefault(month_key, []).append(t)

        return {m: round(sum(vals) / len(vals), 1) for m, vals in by_month.items() if vals}
    except Exception:
        return {}



def resolution_for_range(range_id: str) -> str:
    """Die zum Zeitraum passende Auflösung — kurze Zeiträume feiner, lange
    gröber. Ohne das zeigt z.B. "1 Monat" nur einen einzigen Balken, was
    keinerlei Verlauf erkennen lässt."""
    return {"1m": "day", "3m": "week"}.get(range_id, "month")


def range_start_date(range_id: str) -> Optional[date]:
    """Startdatum des Zeitraums, oder None für "alles"."""
    if range_id == "all" or not range_id:
        return None
    today = date.today()
    if range_id == "ytd":
        return date(today.year, 1, 1)
    months_back = {"1m": 1, "3m": 3, "12m": 12}.get(range_id)
    if months_back is None:
        return None
    m, y = today.month - months_back, today.year
    while m <= 0:
        m += 12
        y -= 1
    return date(y, m, today.day if range_id != "12m" else 1)


def filter_keys_by_range(keys: list, range_id: str) -> list:
    """Filtert Zeitabschnitt-Schlüssel nach Zeitraum. Versteht alle drei
    Schlüssel-Formate (Tag '2026-07-15', Woche '2026-W29', Monat '2026-07'),
    damit dieselbe Funktion unabhängig von der gewählten Auflösung greift."""
    if range_id == "all" or not range_id:
        return sorted(keys)
    cutoff = range_start_date(range_id)
    if cutoff is None:
        return sorted(keys)

    def in_range(k: str) -> bool:
        try:
            if "W" in k:  # ISO-Woche: über das Montagsdatum der Woche vergleichen
                iso_year, iso_week = int(k[:4]), int(k.split("W")[1])
                monday = date.fromisocalendar(iso_year, iso_week, 1)
                return monday >= cutoff
            parts = k.split("-")
            if len(parts) == 3:  # Tag
                return date(int(parts[0]), int(parts[1]), int(parts[2])) >= cutoff
            # Monat: der ganze Monat zählt, wenn sein Ende nach dem Stichtag liegt
            return f"{parts[0]}-{parts[1]}" >= f"{cutoff.year}-{cutoff.month:02d}"
        except (ValueError, IndexError):
            return False

    return sorted(k for k in keys if in_range(k))


def months_in_range(range_id: str) -> float:
    """Näherungsweise Monatsanzahl im Zeitraum — für Kostenhochrechnung
    (Grundpreis-Anteil etc.)."""
    today = date.today()
    return {"1m": 1, "3m": 3, "ytd": today.month, "all": 24}.get(range_id, today.month)

DEFAULT_SETTINGS = {
    "gas": {"abschlag": 0.0, "arbeitspreis": 0.0, "grundpreis": 0.0, "brennwert": 10.0,
            "anbieter": "", "vertragsende": None, "settle_month": 1, "settle_day": 1},
    "elec_in": {"abschlag": 0.0, "arbeitspreis": 0.0, "grundpreis": 0.0,
                "anbieter": "", "vertragsende": None, "settle_month": 1, "settle_day": 1},
    "elec_out": {"abschlag": 0.0, "einspeisepreis": 0.0, "anbieter": "",
                 "settle_month": 1, "settle_day": 31},
    "water": {"abschlag": 0.0, "arbeitspreis": 0.0, "grundpreis": 0.0, "entwaesserung_preis": 0.0,
              "anbieter": "", "vertragsende": None, "settle_month": 1, "settle_day": 1},
    # Kein separater Vertrag/Abschlag -- der Ladestrom läuft über denselben
    # Netzbezug-Vertrag. Der Arbeitspreis dient hier rein informativ, um zu
    # sehen, was allein das Auto-Laden bei aktuellem Strompreis kosten würde.
    "ev_charging": {"abschlag": 0.0, "arbeitspreis": 0.0, "grundpreis": 0.0,
                    "anbieter": "", "settle_month": 1, "settle_day": 1},
}




# ---------- Verknüpfung Zähler <-> Ausgaben/Einnahmen (Abschlag live aus dem Vertrag) ----------
# Gas/Wasser/Strombezug hängen an einem Vertrag unter Ausgaben, die Einspeisung an einer Einnahme. Der
# monatliche Abschlag (und das Vertragsende) wird bei JEDER Auswertung frisch von dort gelesen -- es gibt keine
# zweite, von Hand gepflegte Kopie, die veraltet. settings["link_id"]: fehlt/None = automatisch erkennen
# (nur bei genau einem Treffer), 0 = bewusst keine Verknüpfung, sonst die ID des Vertrags bzw. der Einnahme.
import re as _re

LINK_PATTERNS = {"gas": r"\bgas\b", "water": r"wasser", "elec_in": r"strom", "elec_out": r"einspeis"}
LINK_EXCLUDE = {"elec_in": r"einspeis"}
_FREQ_DIV = {"monthly": 1.0, "quarterly": 3.0, "yearly": 12.0}


def _link_rows(conn, meter_type: str) -> list:
    """Kandidaten (aktive Verträge bzw. aktive Einnahmen) mit Monatsbetrag."""
    if meter_type == "elec_out":
        rows = conn.execute("SELECT id, label, NULL AS provider, NULL AS subcategory, amount, frequency, NULL AS contract_end "
                            "FROM income WHERE COALESCE(active,1)=1").fetchall()
    else:
        rows = conn.execute("SELECT id, COALESCE(NULLIF(label,''), NULLIF(provider,''), 'Vertrag') AS label, provider, subcategory, "
                            "amount, frequency, contract_end FROM contracts WHERE COALESCE(status,'active')='active'").fetchall()
    out = []
    for r in rows:
        div = _FREQ_DIV.get(r["frequency"] or "monthly", 1.0)
        out.append({"id": r["id"], "label": r["label"], "provider": r["provider"], "subcategory": r["subcategory"],
                    "monthly": round((r["amount"] or 0) / div, 2), "contract_end": r["contract_end"]})
    return out


def link_candidates(conn, meter_type: str) -> list:
    """Auswahlliste fürs Verknüpfen -- wahrscheinlichste Treffer (Stichwort im Namen) zuerst."""
    if meter_type not in LINK_PATTERNS:
        return []
    rows = _link_rows(conn, meter_type)
    pat, exc = LINK_PATTERNS[meter_type], LINK_EXCLUDE.get(meter_type)

    def likely(r):
        text = f"{r['label']} {r['provider'] or ''} {r['subcategory'] or ''}".lower()
        return bool(_re.search(pat, text)) and not (exc and _re.search(exc, text))
    for r in rows:
        r["likely"] = likely(r)
    return sorted(rows, key=lambda r: (not r["likely"], (r["label"] or "").lower()))


def resolve_settings(conn, meter_type: str, settings: dict) -> dict:
    """Legt den Betrag des verknüpften Vertrags/der Einnahme über die gespeicherten Einstellungen.
    Ergänzt "link" mit Infos für die Anzeige (None = nicht verknüpft)."""
    out = dict(settings)
    out["link"] = None
    if meter_type not in LINK_PATTERNS:
        return out
    mode = settings.get("link_id")
    if mode == 0:
        return out
    cands = link_candidates(conn, meter_type)
    chosen, auto = None, False
    if mode:
        chosen = next((c for c in cands if c["id"] == mode), None)   # inaktiv/gelöscht -> keine Verknüpfung
    else:
        likely = [c for c in cands if c["likely"]]
        if len(likely) == 1:
            chosen, auto = likely[0], True
    if chosen:
        out["abschlag"] = chosen["monthly"]
        if meter_type != "elec_out" and chosen.get("contract_end"):
            out["vertragsende"] = chosen["contract_end"]
        if not out.get("anbieter") and chosen.get("provider"):
            out["anbieter"] = chosen["provider"]
        out["link"] = {"id": chosen["id"], "label": chosen["label"], "monthly": chosen["monthly"],
                       "auto": auto, "kind": "income" if meter_type == "elec_out" else "contract"}
    return out


def _parse_date(d) -> date:
    if isinstance(d, date):
        return d
    return datetime.strptime(str(d)[:10], "%Y-%m-%d").date()


def _period_key(d: date, resolution: str) -> str:
    """Ordnet ein Datum dem passenden Zeitabschnitt zu.

    - 'day'   -> '2026-07-15'  (Tag)
    - 'week'  -> '2026-W29'    (ISO-Kalenderwoche, beginnt montags)
    - 'month' -> '2026-07'     (Monat)
    """
    if resolution == "day":
        return d.isoformat()
    if resolution == "week":
        iso_year, iso_week, _ = d.isocalendar()
        return f"{iso_year}-W{iso_week:02d}"
    return f"{d.year}-{d.month:02d}"


def consumption_by_period(readings: list, resolution: str = "month") -> dict:
    """Verteilt den Verbrauch zwischen zwei Ablesungen tagesanteilig auf die
    betroffenen Zeitabschnitte. readings: Liste von dicts mit reading_date,
    value, is_new_meter, sortiert aufsteigend nach Datum.

    'resolution' steuert die Feinheit: 'day', 'week' oder 'month'. Die
    tagesanteilige Verteilung ist in allen Fällen identisch — es ändert sich
    nur, wie die Tage anschließend zusammengefasst werden. Dadurch bleibt die
    Summe über einen Zeitraum unabhängig von der gewählten Auflösung gleich.

    Ergebnis: {'2026-07': 45.3, ...} — Verbrauch je Abschnitt in derselben
    Einheit wie die Zählerstände (m³ oder kWh)."""
    by_period: dict = {}
    for prev, cur in zip(readings, readings[1:]):
        # Zählerwechsel: die erste Ablesung des neuen Zählers markiert eine
        # Zäsur — der "Sprung" zwischen altem Endstand und neuem Startstand
        # ist kein Verbrauch, das Intervall wird übersprungen.
        if cur.get("is_new_meter"):
            continue
        d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
        days = (d2 - d1).days
        if days <= 0:
            continue
        delta = cur["value"] - prev["value"]
        if delta < 0:
            continue  # unplausibel (z.B. vertauschte Reihenfolge) -> ignorieren
        daily_rate = delta / days
        d = d1
        while d < d2:
            key = _period_key(d, resolution)
            next_day_start = min(d + timedelta(days=1), d2)
            fraction_days = (next_day_start - d).days
            by_period[key] = by_period.get(key, 0.0) + daily_rate * fraction_days
            d = next_day_start
    return {k: round(v, 3) for k, v in by_period.items()}


def monthly_consumption(readings: list) -> dict:
    """Monatliche Aggregation — dünne Hülle um consumption_by_period(), damit
    alle bestehenden Aufrufer unverändert weiterlaufen."""
    return consumption_by_period(readings, "month")


def current_daily_rate(readings: list) -> Optional[float]:
    """Tagesrate aus dem letzten gültigen (nicht durch Zählerwechsel
    unterbrochenen) Intervall — für "aktueller Verbrauch pro Tag" auf dem
    Dashboard."""
    for prev, cur in zip(reversed(readings[:-1]), reversed(readings[1:])):
        if cur.get("is_new_meter"):
            continue
        d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
        days = (d2 - d1).days
        if days <= 0:
            continue
        delta = cur["value"] - prev["value"]
        if delta < 0:
            continue
        return round(delta / days, 3)
    return None


def current_daily_rate_with_pv(meter_type: str, readings: list, pv_monthly: list) -> Optional[float]:
    """Wie current_daily_rate(), aber für elec_in/elec_out zusätzlich den
    PV-Import als Quelle einbezogen und die JEWEILS AKTUELLERE Quelle gewählt.

    Hintergrund: Netzbezug und Einspeisung kommen bei den meisten Haushalten
    ausschließlich aus dem monatlichen PV-Import, nicht aus manuell erfassten
    Zählerständen. Verließe sich die Tagesrate ausschließlich auf
    readings, bliebe sie beim letzten manuellen Ablesewert eingefroren,
    sobald jemand nur noch importiert — ein neuer Monatsimport würde die
    Kennzahl dann nie wieder aktualisieren."""
    reading_rate, reading_date_ = None, None
    for prev, cur in zip(reversed(readings[:-1]), reversed(readings[1:])):
        if cur.get("is_new_meter"):
            continue
        d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
        days = (d2 - d1).days
        if days <= 0:
            continue
        delta = cur["value"] - prev["value"]
        if delta < 0:
            continue
        reading_rate, reading_date_ = round(delta / days, 3), d2
        break

    if meter_type not in ("elec_in", "elec_out") or not pv_monthly:
        return reading_rate

    field = "bezug" if meter_type == "elec_in" else "einsp"
    last_pv = max(pv_monthly, key=lambda r: r["key"])
    y, m = int(last_pv["key"][:4]), int(last_pv["key"][5:7])
    days_in_month = (date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)) - date(y, m, 1)
    # Letzten Tag des PV-Monats als Vergleichsdatum nehmen, um zu entscheiden,
    # welche Quelle aktueller ist.
    pv_date = date(y, m, days_in_month.days)
    days_covered = days_in_month.days
    today = date.today()
    if (y, m) == (today.year, today.month):
        # Laufender Monat (täglicher Sungrow-Abruf): der Monatswert enthält erst
        # die Tage bis heute. Durch alle Tage des Monats geteilt, zeigte die
        # Tagesrate am 11. nur gut ein Drittel des echten Werts.
        days_covered = max(today.day, 1)
        pv_date = today
    pv_rate = round((last_pv.get(field) or 0.0) / days_covered, 3)

    if reading_date_ is None or pv_date >= reading_date_:
        return pv_rate
    return reading_rate


# Halbwertszeit (in Monaten) für die Gewichtung "jüngere Daten zählen mehr":
# ein Monat, der so weit zurückliegt, zählt halb so viel wie der jüngste.
FORECAST_HALF_LIFE_MONTHS = 3.0
# Steigerungsfaktor ggü. Vorjahr begrenzen -- verhindert absurde Prognosen,
# wenn z.B. nur ein einzelner, untypischer Monat zum Vergleich vorliegt.
FORECAST_GROWTH_MIN, FORECAST_GROWTH_MAX = 0.3, 3.0


def _month_index(key: str) -> int:
    return int(key[:4]) * 12 + int(key[5:7]) - 1


def _days_in_month(year: int, month: int) -> int:
    return (date(year + (month == 12), month % 12 + 1, 1) - date(year, month, 1)).days


def _recency_weight(age_months: float) -> float:
    return 0.5 ** (max(age_months, 0.0) / FORECAST_HALF_LIFE_MONTHS)


def _yoy_growth(monthly: dict, target_year: int) -> float:
    """Prozentuale Veränderung ggü. dem Vorjahr, aus allen Monaten, die in
    BEIDEN Jahren echte Werte haben. Jüngere Vergleichsmonate zählen stärker,
    damit ein aktueller Trend (neue Wärmepumpe, E-Auto, ...) schneller
    durchschlägt. 1.0 = keine Veränderung / kein Vergleich möglich."""
    pairs = []
    for m in range(1, 13):
        cur_k, prev_k = f"{target_year}-{m:02d}", f"{target_year - 1}-{m:02d}"
        if cur_k in monthly and prev_k in monthly:
            pairs.append((m, monthly[cur_k], monthly[prev_k]))
    if not pairs:
        return 1.0
    newest = max(m for m, _, _ in pairs)
    num = sum(_recency_weight(newest - m) * cur for m, cur, _ in pairs)
    den = sum(_recency_weight(newest - m) * prev for m, _, prev in pairs)
    if den <= 0:
        return 1.0
    return min(max(num / den, FORECAST_GROWTH_MIN), FORECAST_GROWTH_MAX)


def _weighted_daily_rate(monthly: dict, before_key: str) -> Optional[float]:
    """Gewichtetes Mittel des Tagesverbrauchs aller echten Monate VOR dem
    Zielmonat -- jüngere Monate mit höherem Gewicht (Halbwertszeit siehe oben).
    Pro Tag normiert, damit Februar und Juli vergleichbar sind."""
    target = _month_index(before_key)
    items = [(k, v) for k, v in monthly.items() if _month_index(k) < target and v is not None]
    if not items:
        # Zielmonat liegt VOR allen echten Werten (z.B. Januar, Ablesungen erst
        # ab Juni): dann die vorhandenen echten Monate verwenden -- immer noch
        # besser als eine flache Rate aus einem einzelnen Ableseintervall.
        items = [(k, v) for k, v in monthly.items() if v is not None]
    if not items:
        return None
    newest = max(_month_index(k) for k, _ in items)
    wsum = vsum = 0.0
    for k, v in items:
        w = _recency_weight(newest - _month_index(k))
        wsum += w
        vsum += w * (v / _days_in_month(int(k[:4]), int(k[5:7])))
    return vsum / wsum if wsum > 0 else None


def data_through_date(meter_type: str, readings: Optional[list], pv_monthly: Optional[list] = None,
                      today: Optional[date] = None) -> Optional[date]:
    """Letzter Tag mit echten Daten im laufenden Monat -- Startpunkt der
    Hochrechnung. Strom mit Sungrow-Daten im laufenden Monat: heute (täglicher
    Abruf). Sonst: Tag der letzten Zählerablesung."""
    today = today or date.today()
    ck = today.strftime("%Y-%m")
    if meter_type in ("elec_in", "elec_out") and pv_monthly and any(d.get("key") == ck for d in pv_monthly):
        return today
    if readings:
        try:
            last = date.fromisoformat(str(max(r["reading_date"] for r in readings))[:10])
        except ValueError:
            return None
        if meter_type == "ev_charging":
            return last   # Zappi-Stand vom Tag X enthält die Ladung des Tages X
        # Verbrauch zwischen zwei Ablesungen wird auf die Tage AB der ersten
        # BIS VOR die zweite verteilt (monthly_consumption) -- eine Ablesung
        # am 2. deckt also Daten nur bis einschließlich 1. ab.
        return last - timedelta(days=1)
    return None


def forecast_missing_months(monthly: dict, daily_rate: Optional[float],
                             start: date, end: date, data_through: Optional[date] = None,
                             today: Optional[date] = None) -> dict:
    """Ergänzt Monate ohne echte Werte im Zeitraum [start, end] um eine Prognose.

    Stufe 1 -- Vorjahresmonat vorhanden: Vorjahreswert × Steigerungsfaktor
    ggü. Vorjahr (_yoy_growth). Übernimmt damit den saisonalen VERLAUF des
    Vorjahres (Heizperiode, PV-Sommer) und rechnet die prozentuale
    Veränderung ein, statt eine flache Rate übers ganze Jahr zu legen.

    Stufe 2 -- kein Vorjahresmonat: gewichtetes Mittel des Tagesverbrauchs der
    vorhandenen Monate, jüngere Monate zählen stärker (_weighted_daily_rate).

    Stufe 3 -- gar keine Monatswerte: die übergebene aktuelle Tagesrate.

    Prognosen werden bewusst NUR aus echten Werten abgeleitet, nie aus bereits
    prognostizierten Monaten -- sonst würden sich Schätzfehler aufschaukeln.
    Ohne feste Jahres-Literale, funktioniert für jedes Kalenderjahr."""
    real = {k: v for k, v in monthly.items() if v is not None}
    result = dict(monthly)
    # Berechnungsgrundlage ohne unvollständige Monate: der ERSTE Monat einer
    # Messreihe (z.B. nur der 31.12. der ersten Ablesung) und der LAUFENDE
    # Monat. Beide bleiben als echte Werte im Ergebnis, würden aber als
    # "voller Monat" die Prognose verzerren -- ein 1-Tages-"Vorjahresmonat"
    # ergab sonst z.B. 10 statt 300 kWh, und der laufende Monat hätte beim
    # gewichteten Mittel das höchste Gewicht.
    real_all = dict(real)
    today = today or date.today()      # fest vorgebbar (Tests, period_consumption); Standard: heute
    current_key = today.strftime("%Y-%m")
    basis = dict(real)
    if len(basis) > 1:
        basis.pop(min(basis), None)
    if len(basis) > 1:
        basis.pop(current_key, None)
    real = basis
    growth_cache = {}
    cur = date(start.year, start.month, 1)
    while cur <= end:
        key = f"{cur.year}-{cur.month:02d}"
        if key not in result:
            days = _days_in_month(cur.year, cur.month)
            prior_key = f"{cur.year - 1}-{cur.month:02d}"
            if prior_key in real:
                if cur.year not in growth_cache:
                    growth_cache[cur.year] = _yoy_growth(real, cur.year)
                base = real[prior_key]
                prior_days = _days_in_month(cur.year - 1, cur.month)
                if prior_days != days:
                    # Nur Februar mit Schaltjahr-Wechsel (28 <-> 29 Tage): Vorjahreswert
                    # pro Tag auf die Länge des Zielmonats umrechnen. Bewusst nur dann,
                    # damit alle übrigen Monate exakt den bisherigen Wert behalten.
                    base = base / prior_days * days
                result[key] = round(base * growth_cache[cur.year], 2)
            else:
                rate = _weighted_daily_rate(real, key)
                if rate is None:
                    rate = daily_rate
                if rate is not None:
                    result[key] = round(rate * days, 2)
        cur = date(cur.year + (cur.month == 12), (cur.month % 12) + 1, 1)
    # LAUFENDER MONAT: Ist schon ein Teil gemessen, zählt er nicht nur mit dem
    # bisherigen Verbrauch -- die restlichen Tage werden hochgerechnet. Sonst
    # unterschätzen Jahreskosten und optimaler Abschlag systematisch, und der
    # Chart zeigt am Monatsanfang einen winzigen Balken.
    # data_through = letzter Tag mit echten Daten (Zähler: letzte Ablesung,
    # Sungrow: heute). Tempo der Resttage wie bei ganzen Monaten: Vorjahres-
    # monat × Steigerung, sonst gewichtetes Mittel; das eigene Teil-Tempo des
    # Monats nur als letzte Notlösung (wenige Tage sind wenig aussagekräftig).
    if current_key in real_all and start <= today <= end:
        through = data_through or today
        if (through.year, through.month) == (today.year, today.month):
            dim = _days_in_month(today.year, today.month)
            remaining = dim - through.day
            if remaining > 0:
                rate = None
                prior_key = f"{today.year - 1}-{today.month:02d}"
                if prior_key in real:
                    if today.year not in growth_cache:
                        growth_cache[today.year] = _yoy_growth(real, today.year)
                    rate = real[prior_key] * growth_cache[today.year] / _days_in_month(today.year - 1, today.month)
                others = {k: v for k, v in real.items() if k != current_key}
                if rate is None and others:
                    # Ohne den laufenden Teilmonat selbst -- er darf nie als
                    # "voller Monat" in seine eigene Hochrechnung einfließen.
                    rate = _weighted_daily_rate(others, current_key)
                if rate is None and through.day > 0:
                    rate = real_all[current_key] / through.day
                if rate is None:
                    rate = daily_rate
                if rate is not None:
                    result[current_key] = round(real_all[current_key] + rate * remaining, 2)
    return result



# ---------- Abrechnungszeitraum ab hinterlegtem Abrechnungsdatum ----------
# Ist für Gas/Wasser ein tatsächlicher Abrechnungszeitpunkt hinterlegt (meter_settlements), beginnt die
# Prognose dort: Verbrauch, Abschlag und erwartete Differenz beziehen sich auf die 12 Monate AB diesem
# Datum (z. B. 22.09.2026 – 21.09.2027) statt auf das Kalenderjahr.
PERIOD_METERS = ("gas", "water")


def _add_years(d: date, n: int) -> date:
    try:
        return d.replace(year=d.year + n)
    except ValueError:      # 29.02. -> 28.02.
        return d.replace(year=d.year + n, day=28)


def billing_period(settlement_date: Optional[date], today: Optional[date] = None) -> Optional[tuple]:
    """(Start, Ende) des laufenden 12-Monats-Abrechnungszeitraums: der jüngste Jahrestag des Abrechnungsdatums,
    der nicht in der Zukunft liegt, bis zum Tag vor dem nächsten Jahrestag. Liegt das Datum in der Zukunft
    (oder fehlt), gibt es keinen Zeitraum -> Kalenderjahr wie bisher."""
    today = today or date.today()
    if not settlement_date or settlement_date > today:
        return None
    start = settlement_date
    while _add_years(start, 1) <= today:
        start = _add_years(start, 1)
    return start, _add_years(start, 1) - timedelta(days=1)


def period_consumption(meter_type: str, readings: list, start: date, end: date,
                       today: Optional[date] = None) -> Optional[float]:
    """Verbrauch im Zeitraum [start, end]: bis zur letzten Ablesung tagesgenau aus den Zählerständen, danach
    hochgerechnet (gleiche saisonale Prognose wie sonst: Vorjahresmonat x Trend, sonst gewichteter Schnitt).
    None, wenn keine Ablesungen vorliegen."""
    if not readings:
        return None
    monthly = monthly_consumption(readings)
    through = data_through_date(meter_type, readings, today=today)
    rate = current_daily_rate(readings)
    fc = forecast_missing_months(monthly, rate, start, end, data_through=through, today=today)
    daily = consumption_by_period(readings, "day")
    first = _parse_date(readings[0]["reading_date"])

    def fallback_rate(key: str) -> float:
        others = {k: v for k, v in monthly.items() if k != key}
        prior = f"{int(key[:4]) - 1}-{key[5:7]}"
        if prior in others:
            return others[prior] / _days_in_month(int(prior[:4]), int(prior[5:7]))
        return _weighted_daily_rate(others, key) or rate or 0.0

    total, d = 0.0, start
    while d <= end:
        key, dim = d.strftime("%Y-%m"), _days_in_month(d.year, d.month)
        if through and first <= d <= through:
            total += daily.get(d.isoformat(), 0.0)
        else:
            fm = fc.get(key)
            if through and (d.year, d.month) == (through.year, through.month):
                remaining = max(dim - through.day, 1)
                per_day = ((fm or 0) - monthly.get(key, 0)) / remaining
                if per_day <= 0:
                    per_day = fallback_rate(key)      # Monat nicht hochgerechnet -> Rest mit Vergleichsrate
            else:
                per_day = (fm / dim) if fm is not None else fallback_rate(key)
            total += per_day
        d += timedelta(days=1)
    return total


def compute_settlement(meter_type: str, readings: list, settings: dict,
                        pv_monthly: Optional[list] = None, today: Optional[date] = None,
                        settlement_date: Optional[date] = None) -> dict:
    """Vergleicht gezahlte Abschläge mit den (gemessenen + hochgerechneten)
    tatsächlichen Jahreskosten — für Gas/Wasser/Strombezug: Kosten = Verbrauch
    × Arbeitspreis + 12 × Grundpreis. Für Einspeisung: Erlös = Verbrauch ×
    Einspeisepreis (kein Grundpreis, keine Kosten sondern Gutschrift)."""
    today = today or date.today()
    year = today.year
    monthly = get_effective_monthly(meter_type, readings, pv_monthly, extrapolate_current=False)
    rate = current_daily_rate_with_pv(meter_type, readings, pv_monthly or [])
    monthly_fc = forecast_missing_months(monthly, rate, date(year, 1, 1), date(year, 12, 31),
                                         data_through=data_through_date(meter_type, readings, pv_monthly))

    total_this_year = sum(v for k, v in monthly_fc.items() if k.startswith(f"{year}-"))
    months_with_data = sum(1 for k in monthly if k.startswith(f"{year}-"))

    abschlag = settings.get("abschlag", 0) or 0
    paid_so_far = abschlag * today.month
    paid_full_year = abschlag * 12
    period = billing_period(settlement_date, today) if meter_type in PERIOD_METERS else None
    if period:
        pc = period_consumption(meter_type, readings, period[0], period[1], today)
        if pc is not None:
            total_this_year = pc
            paid_so_far = abschlag * ((today.year - period[0].year) * 12 + today.month - period[0].month + 1)
        else:
            period = None

    if meter_type == "elec_out":
        preis = settings.get("einspeisepreis", 0) or 0
        jahres_ertrag = total_this_year * preis
        diff = jahres_ertrag - paid_full_year
        kosten_oder_erloes = jahres_ertrag
    else:
        ap = settings.get("arbeitspreis", 0) or 0
        gp = settings.get("grundpreis", 0) or 0
        ep = settings.get("entwaesserung_preis", 0) or 0
        bw = settings.get("brennwert", 1.0) or 1.0 if meter_type == "gas" else 1.0
        einheit_umgerechnet = total_this_year * bw if meter_type == "gas" else total_this_year
        jahres_kosten = einheit_umgerechnet * (ap + ep) + 12 * gp
        diff = paid_full_year - jahres_kosten
        kosten_oder_erloes = jahres_kosten

    return {
        "year": year,
        "total_consumption_this_year": round(total_this_year, 2),
        "months_with_real_data": months_with_data,
        "current_daily_rate": rate,
        "paid_so_far": round(paid_so_far, 2),
        "paid_full_year": round(paid_full_year, 2),
        "projected_annual_cost_or_revenue": round(kosten_oder_erloes, 2),
        "diff": round(diff, 2),
        "period_start": period[0].isoformat() if period else None,
        "period_end": period[1].isoformat() if period else None,
    }


def next_settle_date(month: int, day: int, today: Optional[date] = None) -> date:
    """Nächster Abrechnungstermin — dieses Jahr, falls noch nicht vorbei, sonst
    nächstes Jahr."""
    today = today or date.today()
    try:
        d = date(today.year, month, day)
    except ValueError:
        d = date(today.year, month, 28)
    if d <= today:
        try:
            d = date(today.year + 1, month, day)
        except ValueError:
            d = date(today.year + 1, month, 28)
    return d


def ev_daily_charge(readings: Optional[list], monthly: bool = False) -> dict:
    """Ladeenergie der Wallbox je Tag (bzw. Monat). Anders als bei manuell
    abgelesenen Zählern enthält ein Zappi-Stand vom Tag X die Ladung DES
    Tages X (der Sync schreibt den kumulierten Stand am Ende jedes Tages).
    Die Zähler-Logik (Verbrauch auf die Tage VOR der Ablesung verteilen)
    würde die Ladung jedes Monatsersten dem Vormonat zuschlagen.
    Der erste Stand zählt mit seinem vollen Wert: der Zappi-Sync beginnt bei 0."""
    if not readings:
        return {}
    srt = sorted(readings, key=lambda r: r["reading_date"])
    out, prev = {}, 0.0
    for r in srt:
        key = str(r["reading_date"])[:7] if monthly else str(r["reading_date"])[:10]
        out[key] = round(out.get(key, 0.0) + max(0.0, (r["value"] or 0) - prev), 3)
        prev = r["value"] or 0
    return out


def get_effective_monthly(meter_type: str, readings: list, pv_monthly: Optional[list],
                           today: Optional[date] = None, extrapolate_current: bool = True) -> dict:
    """Monatswerte für einen Zähler — bevorzugt bei Strombezug/Einspeisung die
    Werte aus dem iSolarCloud/Sungrow-PV-Import (Netzbezug, Einspeisung),
    da dieser Import i.d.R. vollständiger und zuverlässiger ist als die
    Zählerstand-basierte Berechnung aus einzelnen, oft lückenhaften
    Ablesungen. Fällt für Monate ohne Import-Daten auf die Zählerstand-
    Berechnung zurück. Bei Gas/Wasser unverändert zählerstandbasiert (dafür
    gibt es keine iSolarCloud-Quelle).

    Der LAUFENDE (noch nicht abgeschlossene) Monat wird gesondert behandelt:
    ein Import am 1. eines Monats deckt zwangsläufig nur diesen einen Tag ab
    — würde man das ungeprüft als Monatswert übernehmen, sähe es so aus, als
    würde der ganze Monat nur so wenig erzeugen/verbrauchen. Stattdessen wird
    der bisherige Wert auf Tagesbasis hochgerechnet: (Wert ÷ bisher
    vergangene Tage) × Tage im Monat. Für alle VERGANGENEN Monate (die
    zwangsläufig vollständig sind) wird der Importwert unverändert
    übernommen."""
    today = today or date.today()
    if meter_type == "ev_charging":
        return ev_daily_charge(readings, monthly=True)
    meter_monthly = monthly_consumption(readings)
    if meter_type not in ("elec_in", "elec_out") or not pv_monthly:
        return meter_monthly
    field = "bezug" if meter_type == "elec_in" else "einsp"
    current_key = f"{today.year}-{today.month:02d}"
    days_elapsed = today.day
    days_in_current_month = (
        date(today.year + (today.month == 12), (today.month % 12) + 1, 1) - date(today.year, today.month, 1)
    ).days

    merged = dict(meter_monthly)
    for d in pv_monthly:
        val = d.get(field)
        if val is None:
            continue
        if extrapolate_current and d["key"] == current_key and days_elapsed < days_in_current_month and days_elapsed > 0:
            # Laufender, noch nicht abgeschlossener Monat -> auf Tagesbasis
            # hochrechnen statt den bisherigen Teilwert 1:1 zu übernehmen.
            merged[d["key"]] = round((val / days_elapsed) * days_in_current_month, 2)
        else:
            merged[d["key"]] = val
    return merged


def compute_full_settlement(readings_by_type: dict, settings_by_type: dict, pv_monthly: list,
                             today: Optional[date] = None, settlement_dates: Optional[dict] = None) -> dict:
    """Vollständige Jahresabrechnung wie im Original: pro Zähler Abschlag
    gegen tatsächliche/prognostizierte Jahreskosten, mit eigenem Abrechnungs-
    termin und Tage-Countdown. Einspeisung nutzt die monatlichen PV-Daten
    (Sungrow) als primäre Datenquelle für den gemessenen Ertrag — genau wie
    im Original, da der iSolarCloud-Export zuverlässiger ist als der
    Wechselrichter-eigene Netto-Einspeisungszähler."""
    today = today or date.today()
    year = today.year
    month = today.month
    pv_by_key = {d["key"]: d for d in pv_monthly}

    # ---- Gas ----
    G = settings_by_type.get("gas") or DEFAULT_SETTINGS["gas"]
    gas_readings = readings_by_type.get("gas") or []
    gm = monthly_consumption(gas_readings)
    g_rate = current_daily_rate(gas_readings)
    g_forecast = forecast_missing_months(gm, g_rate, date(year, 1, 1), date(year, 12, 31),
                                         data_through=data_through_date("gas", gas_readings))
    tot_gas_m3 = sum(g_forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    gas_period = billing_period((settlement_dates or {}).get("gas"), today)
    if gas_period:
        pc = period_consumption("gas", gas_readings, gas_period[0], gas_period[1], today)
        if pc is None:
            gas_period = None
        else:
            tot_gas_m3 = pc
    gas_jahr_kosten = tot_gas_m3 * (G.get("brennwert") or 1.0) * (G.get("arbeitspreis") or 0) + 12 * (G.get("grundpreis") or 0)
    gas_abschlaege = 12 * (G.get("abschlag") or 0)
    gas_diff = gas_abschlaege - gas_jahr_kosten
    gas_settle = (gas_period[1] + timedelta(days=1)) if gas_period else next_settle_date(G.get("settle_month") or 1, G.get("settle_day") or 24, today)

    # ---- Wasser (nur wenn tatsächlich Ablesungen vorliegen — sonst würde
    # eine Karte mit lauter Nullen nur verwirren, bevor der Nutzer die
    # Wasser-Seite überhaupt zum ersten Mal befüllt hat) ----
    W = settings_by_type.get("water") or DEFAULT_SETTINGS["water"]
    water_readings = readings_by_type.get("water") or []
    has_water = len(water_readings) > 0
    wm = monthly_consumption(water_readings)
    w_rate = current_daily_rate(water_readings)
    w_forecast = forecast_missing_months(wm, w_rate, date(year, 1, 1), date(year, 12, 31),
                                         data_through=data_through_date("water", water_readings))
    tot_water_m3 = sum(w_forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    water_period = billing_period((settlement_dates or {}).get("water"), today)
    if water_period:
        pc = period_consumption("water", water_readings, water_period[0], water_period[1], today)
        if pc is None:
            water_period = None
        else:
            tot_water_m3 = pc
    water_jahr_kosten = tot_water_m3 * ((W.get("arbeitspreis") or 0) + (W.get("entwaesserung_preis") or 0)) + 12 * (W.get("grundpreis") or 0)
    water_abschlaege = 12 * (W.get("abschlag") or 0)
    water_diff = water_abschlaege - water_jahr_kosten
    water_settle = (water_period[1] + timedelta(days=1)) if water_period else next_settle_date(W.get("settle_month") or 1, W.get("settle_day") or 1, today)

    # ---- Strombezug ----
    E = settings_by_type.get("elec_in") or DEFAULT_SETTINGS["elec_in"]
    elec_in_readings = readings_by_type.get("elec_in") or []
    em = get_effective_monthly("elec_in", elec_in_readings, pv_monthly, extrapolate_current=False)
    # War früher ein simpler Durchschnitt der bekannten Monate × 12 -- eine
    # flache Hochrechnung ohne jede Saisonalität, komplett unabhängig von der
    # (späteren) forecast_missing_months-Logik, die Gas/Wasser hier bereits
    # nutzen UND die auch die einzelne Strombezug-Seite verwendet. Dadurch
    # zeigten Dashboard und Strombezug-Seite unterschiedliche, teils sogar
    # gegensätzlich vorzeichenbehaftete "Erwartete Differenz"-Werte für
    # denselben Zähler im selben Jahr. Jetzt exakt dieselbe Rechnung wie dort.
    e_rate = current_daily_rate_with_pv("elec_in", elec_in_readings, pv_monthly or [])
    e_forecast = forecast_missing_months(em, e_rate, date(year, 1, 1), date(year, 12, 31),
                                         data_through=data_through_date("elec_in", elec_in_readings, pv_monthly))
    bezug_jahr = sum(e_forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    bezug_kosten = bezug_jahr * (E.get("arbeitspreis") or 0) + 12 * (E.get("grundpreis") or 0)
    bezug_abschlaege = 12 * (E.get("abschlag") or 0)
    bezug_diff = bezug_abschlaege - bezug_kosten
    bezug_settle = next_settle_date(E.get("settle_month") or 3, E.get("settle_day") or 13, today)

    # ---- Einspeisung (PV-gestützt) ----
    EO = settings_by_type.get("elec_out") or DEFAULT_SETTINGS["elec_out"]
    einspeis_abschlag = EO.get("abschlag") or 70
    m_seit_januar = month
    einsp_bezahlt = m_seit_januar * einspeis_abschlag

    cur_month_key = f"{year}-{month:02d}"
    # Der laufende Monat ist per Definition noch nicht vollständig gemessen
    # (auch wenn schon ein PV-Import dafür vorliegt) — sonst würde er sowohl
    # roh in "Gemessen" als auch hochgerechnet in "Prognose" gezählt werden.
    pv_dies_jahr = [d for d in pv_monthly if d["key"].startswith(f"{year}-") and d["key"] != cur_month_key]
    pv_gemessene_keys = [d["key"] for d in pv_dies_jahr]
    einsp_bisher = sum(d["einsp"] for d in pv_dies_jahr)

    pv_cur_month = pv_by_key.get(cur_month_key)
    einsp_laufender_monat = 0.0
    einsp_laufend_label = ""
    if pv_cur_month:
        days_in_month = (date(year + (month == 12), (month % 12) + 1, 1) - date(year, month, 1)).days
        # Wie viele Tage des laufenden Monats deckt der PV-Import ab? Das
        # heutige Datum ist hierfür das verlässliche Signal — die Ablesung
        # des Einspeisungszählers ist eine unabhängige, oft viel seltener
        # gepflegte Datenquelle und darf hier nicht als Anker dienen.
        days_covered = max(min(today.day, days_in_month), 1)
        daily_einsp = pv_cur_month["einsp"] / days_covered
        einsp_laufender_monat = daily_einsp * days_in_month
        einsp_laufend_label = (f"Sungrow {days_covered} Tage: {pv_cur_month['einsp']:.0f} kWh → "
                                f"{einsp_laufender_monat:.0f} kWh/Monat hochgerechnet")

    einsp_prognose = einsp_laufender_monat
    for m in range(1, 13):
        key = f"{year}-{m:02d}"
        if key in pv_gemessene_keys or m == month:
            continue
        prev = pv_by_key.get(f"{year-1}-{m:02d}")
        einsp_prognose += prev["einsp"] if prev else 0

    einsp_jahr_gesamt = einsp_bisher + einsp_prognose
    ep = EO.get("einspeisepreis") or 0
    einsp_jahr_erloes = einsp_jahr_gesamt * ep
    einsp_jahres_abschlaege = 12 * einspeis_abschlag
    einsp_diff = einsp_jahr_erloes - einsp_jahres_abschlaege
    einsp_erloes_bisher = einsp_bisher * ep
    einsp_settle = date(year + 1, 1, 31)

    total_diff = gas_diff + bezug_diff + einsp_diff + (water_diff if has_water else 0)

    return {
        "year": year,
        "gas": {
            "diff": round(gas_diff, 2), "jahr_kosten": round(gas_jahr_kosten, 2),
            "abschlaege": round(gas_abschlaege, 2), "settle_date": gas_settle.isoformat(),
            "days_until_settle": (gas_settle - today).days,
            "period_start": gas_period[0].isoformat() if gas_period else None,
        },
        "elec_in": {
            "diff": round(bezug_diff, 2), "jahr_kosten": round(bezug_kosten, 2),
            "abschlaege": round(bezug_abschlaege, 2), "settle_date": bezug_settle.isoformat(),
            "days_until_settle": (bezug_settle - today).days,
            "monthly_cost": round(bezug_kosten / 12, 2),
        },
        "elec_out": {
            "diff": round(einsp_diff, 2), "jahr_erloes": round(einsp_jahr_erloes, 2),
            "jahres_abschlaege": round(einsp_jahres_abschlaege, 2), "abschlag": einspeis_abschlag,
            "bezahlt": round(einsp_bezahlt, 2), "bisher_kwh": round(einsp_bisher, 1),
            "prognose_kwh": round(einsp_prognose, 1), "jahr_gesamt_kwh": round(einsp_jahr_gesamt, 1),
            "erloes_bisher": round(einsp_erloes_bisher, 2), "m_seit_januar": m_seit_januar,
            "gemessene_monate": len(pv_gemessene_keys), "prognose_monate": 12 - len(pv_gemessene_keys),
            "laufender_monat_label": einsp_laufend_label,
            "settle_date": einsp_settle.isoformat(), "days_until_settle": (einsp_settle - today).days,
        },
        "water": {
            "has_data": has_water,
            "diff": round(water_diff, 2) if has_water else 0,
            "jahr_kosten": round(water_jahr_kosten, 2) if has_water else 0,
            "abschlaege": round(water_abschlaege, 2) if has_water else 0,
            "settle_date": water_settle.isoformat(),
            "days_until_settle": (water_settle - today).days,
            "period_start": water_period[0].isoformat() if water_period else None,
        },
        "total_diff": round(total_diff, 2),
    }


def compute_overview_cards(readings_by_type: dict, settings_by_type: dict, pv_monthly: list,
                            range_id: str = "ytd") -> dict:
    """Die vier KPI-Karten (Gas, Bezug, Einspeisung, PV-Ertrag) für den
    gewählten Zeitraum — entspricht renderOvCards() im Original."""
    G = settings_by_type.get("gas") or DEFAULT_SETTINGS["gas"]
    E = settings_by_type.get("elec_in") or DEFAULT_SETTINGS["elec_in"]
    EO = settings_by_type.get("elec_out") or DEFAULT_SETTINGS["elec_out"]
    W = settings_by_type.get("water") or DEFAULT_SETTINGS["water"]

    gas_readings = readings_by_type.get("gas") or []
    elec_in_readings = readings_by_type.get("elec_in") or []
    elec_out_readings = readings_by_type.get("elec_out") or []
    water_readings = readings_by_type.get("water") or []

    gm = monthly_consumption(gas_readings)
    g_rate = current_daily_rate(gas_readings)
    today = date.today()
    g_forecast = forecast_missing_months(gm, g_rate, date(today.year, 1, 1), date(today.year, 12, 31),
                                         data_through=data_through_date("gas", gas_readings))
    combined_gas = {**gm, **{k: v for k, v in g_forecast.items() if k not in gm}}

    em = get_effective_monthly("elec_in", elec_in_readings, pv_monthly)
    eom = get_effective_monthly("elec_out", elec_out_readings, pv_monthly)

    gas_keys = filter_keys_by_range(list(combined_gas.keys()), range_id)
    gas_m3 = sum(combined_gas.get(k, 0) for k in gas_keys)
    gas_kwh = gas_m3 * (G.get("brennwert") or 1.0)
    n_mo = months_in_range(range_id)
    gas_kosten = gas_kwh * (G.get("arbeitspreis") or 0) + n_mo * (G.get("grundpreis") or 0)

    bezug_keys = filter_keys_by_range(list(em.keys()), range_id)
    bezug_kwh = sum(em.get(k, 0) for k in bezug_keys)
    bezug_kosten = bezug_kwh * (E.get("arbeitspreis") or 0) + n_mo * (E.get("grundpreis") or 0)

    wm = monthly_consumption(water_readings)
    w_rate = current_daily_rate(water_readings)
    w_forecast = forecast_missing_months(wm, w_rate, date(today.year, 1, 1), date(today.year, 12, 31),
                                         data_through=data_through_date("water", water_readings))
    combined_water = {**wm, **{k: v for k, v in w_forecast.items() if k not in wm}}
    water_keys = filter_keys_by_range(list(combined_water.keys()), range_id)
    water_m3 = sum(combined_water.get(k, 0) for k in water_keys)
    water_kosten = water_m3 * ((W.get("arbeitspreis") or 0) + (W.get("entwaesserung_preis") or 0)) + n_mo * (W.get("grundpreis") or 0)

    einsp_keys = filter_keys_by_range(list(eom.keys()), range_id)
    # 'eom' bevorzugt bereits die iSolarCloud-Werte je Monat (get_effective_monthly),
    # der Zählerstand dient nur noch als Rückfallebene für Monate ohne Import.
    einsp_total = sum(eom.get(k, 0) for k in einsp_keys)
    pv_keys_filtered = filter_keys_by_range([d["key"] for d in pv_monthly], range_id)
    pv_by_key = {d["key"]: d for d in pv_monthly}
    einsp_erloes = einsp_total * (EO.get("einspeisepreis") or 0)

    pv_ertrag_kwh = sum(pv_by_key[k]["pv"] for k in pv_keys_filtered)

    g_rate_val = current_daily_rate(gas_readings)
    e_rate_val = current_daily_rate_with_pv("elec_in", elec_in_readings, pv_monthly)
    eo_rate_val = current_daily_rate_with_pv("elec_out", elec_out_readings, pv_monthly)
    w_rate_val = current_daily_rate(water_readings)

    return {
        "range": range_id,
        "gas": {
            "kwh": round(gas_kwh, 1), "m3": round(gas_m3, 1), "kosten": round(gas_kosten, 2),
            "daily_rate": round(g_rate_val, 2) if g_rate_val is not None else None, "anbieter": G.get("anbieter") or "",
        },
        "elec_in": {
            "kwh": round(bezug_kwh, 0), "kosten": round(bezug_kosten, 2),
            "daily_rate": round(e_rate_val, 2) if e_rate_val is not None else None,
            "anbieter": E.get("anbieter") or "",
        },
        "elec_out": {
            "kwh": round(einsp_total, 0), "erloes": round(einsp_erloes, 2),
            "daily_rate": round(eo_rate_val, 2) if eo_rate_val is not None else None,
            "anbieter": EO.get("anbieter") or "badenovaNETZE",
            "source": "pv" if pv_monthly else "meter",
        },
        "pv": {
            "kwh": round(pv_ertrag_kwh, 0), "months": len(pv_keys_filtered),
            **PV_PLANT_DEFAULTS,
        },
        "water": {
            "m3": round(water_m3, 1), "kosten": round(water_kosten, 2),
            "daily_rate": round(w_rate_val, 2) if w_rate_val is not None else None,
            "anbieter": W.get("anbieter") or "", "has_data": len(water_readings) > 0,
        },
    }


def compute_cost_trend(readings_by_type: dict, settings_by_type: dict, pv_monthly: list,
                        range_id: str = "ytd") -> list:
    """Monatliche Kostenreihe für den Kostentrend-Chart: je Monat Gas- und
    Strom-Netto-Kosten, getrennt nach 'gemessen' (echte Ablesung oder
    iSolarCloud-Import vorhanden) und 'prognose' (hochgerechnet)."""
    G = settings_by_type.get("gas") or DEFAULT_SETTINGS["gas"]
    E = settings_by_type.get("elec_in") or DEFAULT_SETTINGS["elec_in"]
    EO = settings_by_type.get("elec_out") or DEFAULT_SETTINGS["elec_out"]
    W = settings_by_type.get("water") or DEFAULT_SETTINGS["water"]
    today = date.today()

    gas_readings = readings_by_type.get("gas") or []
    elec_in_readings = readings_by_type.get("elec_in") or []
    elec_out_readings = readings_by_type.get("elec_out") or []
    water_readings = readings_by_type.get("water") or []

    gm = monthly_consumption(gas_readings)
    g_rate = current_daily_rate(gas_readings)
    g_fc = forecast_missing_months(gm, g_rate, date(today.year, 1, 1), date(today.year, 12, 31),
                                   data_through=data_through_date("gas", gas_readings))

    em = get_effective_monthly("elec_in", elec_in_readings, pv_monthly, extrapolate_current=False)
    e_rate = current_daily_rate_with_pv("elec_in", elec_in_readings, pv_monthly)
    e_fc = forecast_missing_months(em, e_rate, date(today.year, 1, 1), date(today.year, 12, 31),
                                   data_through=data_through_date("elec_in", elec_in_readings, pv_monthly))

    # Einspeisung wie der Einkauf: Rohwerte + Prognose (laufender Monat
    # hochgerechnet, künftige Monate gefüllt). Früher: naiv auf den vollen
    # Monat skaliert -> im laufenden Monat stand ein Teil-Einkauf gegen eine
    # Voll-Vergütung (Strom-Netto fast null/negativ), künftige Monate ohne Vergütung.
    eom = get_effective_monthly("elec_out", elec_out_readings, pv_monthly, extrapolate_current=False)
    eo_rate = current_daily_rate_with_pv("elec_out", elec_out_readings, pv_monthly)
    eo_fc = forecast_missing_months(eom, eo_rate, date(today.year, 1, 1), date(today.year, 12, 31),
                                    data_through=data_through_date("elec_out", elec_out_readings, pv_monthly))

    wm = monthly_consumption(water_readings)
    w_rate = current_daily_rate(water_readings)
    w_fc = forecast_missing_months(wm, w_rate, date(today.year, 1, 1), date(today.year, 12, 31),
                                   data_through=data_through_date("water", water_readings))
    has_water = len(water_readings) > 0

    all_keys = sorted(set(list(g_fc.keys()) + list(e_fc.keys()) + (list(w_fc.keys()) if has_water else [])))
    filtered_keys = filter_keys_by_range(all_keys, range_id) if range_id != "all" else all_keys

    # Je Monat: GESAMT aus der Prognose (enthält für den laufenden Monat die
    # Hochrechnung der Resttage), davon GEMESSEN = echter Wert. Früher gewann
    # der gemessene Teilwert ("gm.get(key, g_fc...)") -- der laufende Monat
    # endete dann mit dem Verbrauch der ersten Tage.
    gp_g, ap_g, bw = (G.get("grundpreis") or 0), (G.get("arbeitspreis") or 0), (G.get("brennwert") or 1.0)
    gp_e, ap_e, ep = (E.get("grundpreis") or 0), (E.get("arbeitspreis") or 0), (EO.get("einspeisepreis") or 0)
    gp_w = (W.get("grundpreis") or 0)
    ap_w = (W.get("arbeitspreis") or 0) + (W.get("entwaesserung_preis") or 0)

    def split(real: dict, fc: dict, key: str):
        has = key in real
        measured = (real.get(key) or 0) if has else 0
        total = fc.get(key, measured) or 0
        return measured, max(0.0, total - measured), has

    result = []
    for key in filtered_keys:
        g_meas, g_rest, g_has = split(gm, g_fc, key)
        gas_measured_cost = (g_meas * bw * ap_g + gp_g) if g_has else 0
        gas_forecast_cost = g_rest * bw * ap_g + (0 if g_has else gp_g)

        e_meas, e_rest, e_has = split(em, e_fc, key)
        o_meas, o_rest, _ = split(eom, eo_fc, key)
        if e_has:
            elec_measured_cost = e_meas * ap_e + gp_e - o_meas * ep
            elec_forecast_cost = e_rest * ap_e - o_rest * ep
        else:
            elec_measured_cost = 0
            elec_forecast_cost = (e_meas + e_rest) * ap_e + gp_e - (o_meas + o_rest) * ep

        if has_water:
            w_meas, w_rest, w_has = split(wm, w_fc, key)
            water_measured_cost = (w_meas * ap_w + gp_w) if w_has else 0
            water_forecast_cost = w_rest * ap_w + (0 if w_has else gp_w)
        else:
            water_measured_cost = water_forecast_cost = 0
        result.append({
            "key": key,
            "gas_measured": round(gas_measured_cost, 2),
            "gas_forecast": round(gas_forecast_cost, 2),
            "elec_measured": round(elec_measured_cost, 2),
            "elec_forecast": round(elec_forecast_cost, 2),
            "water_measured": round(water_measured_cost, 2),
            "water_forecast": round(water_forecast_cost, 2),
            "total": round(gas_measured_cost + gas_forecast_cost + elec_measured_cost + elec_forecast_cost
                           + water_measured_cost + water_forecast_cost, 2),
        })
    return result


def ev_monthly_with_forecast(ev_readings: list, year: int) -> dict:
    """Ladeenergie der Wallbox je Monat: echte Werte (Deltas der kumulierten
    Ablesungen) plus Hochrechnung der restlichen Monate -- aber NIE vor der
    Installation (erster Monat mit echtem Wert, siehe learnings: Wallbox)."""
    if not ev_readings:
        return {}
    # Dieselbe Monatsberechnung wie im Verbrauchs-Chart -- damit Kachel,
    # Kosten-Chart und Verbrauchs-Chart garantiert dieselben Ladewerte zeigen.
    real = {k: v for k, v in get_effective_monthly("ev_charging", ev_readings, None).items() if v is not None}
    if not real:
        return {}
    first = min(real)
    start = max(date(year, 1, 1), date(int(first[:4]), int(first[5:7]), 1))
    # Der unvollständige Installationsmonat wird von forecast_missing_months
    # selbst aus der Berechnungsgrundlage ausgeschlossen (erster Monat einer Reihe).
    return forecast_missing_months(real, None, start, date(year, 12, 31),
                                   data_through=data_through_date("ev_charging", ev_readings))


def _daily_ev_deltas(ev_readings: list) -> dict:
    """Tages-Ladeenergie, keyed 'YYYY-MM-DD' (siehe ev_daily_charge)."""
    return ev_daily_charge(ev_readings)


def _month_fully_covered(pv_daily_map: dict, year: int, month: int, today: date) -> int:
    """Anzahl der Tage des Monats, die bereits vergangen UND in pv_daily_map
    vorhanden sind -- 0, wenn auch nur ein einziger dieser Tage fehlt oder der
    Monat noch komplett in der Zukunft liegt. Nur bei VOLLER Abdeckung lohnt
    sich die tagesgenaue Berechnung; sonst bleibt es bei der bisherigen
    Monats-Schätzung für den kompletten Monat (kein Vermischen pro Tag)."""
    month_start = date(year, month, 1)
    if month_start > today:
        return 0
    last_day = today.day if (year, month) == (today.year, today.month) else _days_in_month(year, month)
    covered = all(f"{year}-{month:02d}-{d:02d}" in pv_daily_map for d in range(1, last_day + 1))
    return last_day if covered else 0


def gesamt_by_month_with_forecast(pv_monthly: Optional[list], year: int) -> dict:
    """Hausverbrauch (gesamt, egal woher: PV, Speicher, Netz) je Monat des
    Jahres inkl. Hochrechnung -- nur als VERTEILSCHLÜSSEL für die Aufteilung
    des Strom-Einkaufs auf Auto/Haushalt, nie als Kostenbasis."""
    real = {d["key"]: d.get("gesamt") for d in (pv_monthly or []) if d.get("gesamt")}
    if not real:
        return {}
    return forecast_missing_months(real, None, date(year, 1, 1), date(year, 12, 31),
                                   data_through=data_through_date("elec_in", None, pv_monthly))


def split_auto_household_cost(consumption_by_month: dict, ev_monthly: dict,
                              year: int, ap: float, gp: float,
                              pv_daily: Optional[list] = None,
                              ev_readings: Optional[list] = None,
                              gesamt_by_month: Optional[dict] = None) -> dict:
    """Teilt die STROM-EINKAUFSKOSTEN je Monat in Auto und Haushalt.

    KOSTENBASIS IST AUSSCHLIESSLICH DER NETZBEZUG (consumption_by_month bzw.
    'bezug' der Tageswerte) -- der Hausverbrauch aus PV und Speicher kostet
    nichts und gehört nicht in Abschlag/Jahresabrechnung. (Fehler bis v289:
    in tagesgenau gerechneten Monaten wurde der GESAMTE Hausverbrauch × Arbeits-
    preis als Kosten angesetzt.)

    Aufteilung des Einkaufs: im Verhältnis Auto-Ladung / Hausverbrauch.
    Lädt das Auto mittags mit PV-Überschuss, verursacht es kaum Einkauf.
    - Monate mit vollständigen Tageswerten: je Tag Bezug × Auto-Anteil des Tages.
    - Sonst: Monats-Einkauf × Auto-Anteil am Monats-Hausverbrauch.
    - Ohne PV-Daten (aller Verbrauch wird eingekauft): Ladung direkt, höchstens
      bis zum Einkauf.
    Grundpreis einmal pro Monat beim Haushalt."""
    daily = {d["key"]: d for d in pv_daily} if pv_daily else {}
    gesamt_daily = {k: (v.get("gesamt") or 0.0) for k, v in daily.items()}
    ev_daily_map = _daily_ev_deltas(ev_readings)
    gesamt_by_month = gesamt_by_month or {}
    today = date.today()
    months, auto_total, haus_total = [], 0.0, 0.0

    def share(ev_kwh, total_kwh):
        if total_kwh and total_kwh > 0:
            return min(1.0, max(0.0, ev_kwh / total_kwh))
        return 1.0 if ev_kwh > 0 else 0.0

    for m in range(1, 13):
        k = f"{year}-{m:02d}"
        last_day = _month_fully_covered(gesamt_daily, year, m, today) if daily else 0
        if last_day:
            auto = haus = 0.0
            bezug_sum = auto_kwh_sum = 0.0
            for d in range(1, last_day + 1):
                dk = f"{year}-{m:02d}-{d:02d}"
                row = daily.get(dk) or {}
                bezug = row.get("bezug") or 0.0
                auto_grid = bezug * share(ev_daily_map.get(dk, 0.0), row.get("gesamt") or 0.0)
                auto += auto_grid * ap
                haus += (bezug - auto_grid) * ap
                bezug_sum += bezug
                auto_kwh_sum += auto_grid
            # Laufender Monat: die Tageswerte reichen erst bis heute, die
            # Jahresprognose (consumption_by_month) rechnet den Monat aber
            # hoch. Den hochgerechneten Rest-Einkauf im bisherigen Auto-Anteil
            # des Monats verteilen -- sonst ergaben Haushalt + Auto weniger als
            # die prognostizierten Jahreskosten.
            rest = (consumption_by_month.get(k, 0) or 0) - bezug_sum
            if last_day < _days_in_month(year, m) and rest > 0:
                auto_share = (auto_kwh_sum / bezug_sum) if bezug_sum > 0 else 0.0
                auto += rest * auto_share * ap
                haus += rest * (1 - auto_share) * ap
            haus += gp
        else:
            einkauf = consumption_by_month.get(k, 0) or 0
            ev = ev_monthly.get(k, 0.0) or 0.0
            g = gesamt_by_month.get(k)
            auto_kwh = einkauf * share(ev, g) if g else min(ev, einkauf)
            auto = auto_kwh * ap
            haus = max(0.0, einkauf - auto_kwh) * ap + gp
        auto_total += auto
        haus_total += haus
        months.append({"key": k, "auto": auto, "haus": haus})
    return {"months": months, "auto": auto_total, "haus": haus_total}


def compute_kpi_chips(meter_type: str, readings: list, settings_: dict,
                       pv_monthly: Optional[list] = None, today: Optional[date] = None,
                       ev_charging_this_year: Optional[float] = None,
                       ev_readings: Optional[list] = None,
                       pv_daily: Optional[list] = None,
                       settlement_date: Optional[date] = None) -> list:
    """Die KPI-Chip-Zeile pro Zählerseite (Letzter Stand, Tagesrate, optimaler
    Abschlag, erwartete Differenz, prognostizierte Jahreskosten) — entspricht
    den gasKpis/elecKpis-Chips im Original."""
    today = today or date.today()
    year = today.year
    unit = METER_META[meter_type]["unit"]
    rate = current_daily_rate_with_pv(meter_type, readings, pv_monthly or [])
    last = readings[-1] if readings else None

    monthly = get_effective_monthly(meter_type, readings, pv_monthly, extrapolate_current=False)
    forecast = forecast_missing_months(monthly, rate, date(year, 1, 1), date(year, 12, 31),
                                       data_through=data_through_date(meter_type, readings, pv_monthly))
    total_this_year = sum(forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    # Gas/Wasser mit hinterlegtem Abrechnungsdatum: Prognose für die 12 Monate AB diesem Datum
    period = billing_period(settlement_date, today) if meter_type in PERIOD_METERS else None
    period_label = year
    if period:
        pc = period_consumption(meter_type, readings, period[0], period[1], today)
        if pc is None:
            period = None
        else:
            total_this_year = pc
            period_label = f"ab {period[0].strftime('%d.%m.')}"

    if meter_type == "elec_out":
        ep = settings_.get("einspeisepreis") or 0
        jahres_ertrag = total_this_year * ep
        abschlag = settings_.get("abschlag") or 0
        opt_abschlag = round(jahres_ertrag / 12) if jahres_ertrag else 0
        diff = jahres_ertrag - 12 * abschlag
        chips = [
            {"label": "Letzter Stand", "value": f"{last['value']:.0f} {unit}" if last else "–",
             "sub": last["reading_date"] if last else ""},
            {"label": "Tagesrate aktuell", "value": f"{rate:.1f} {unit}/Tag" if rate is not None else "–", "sub": ""},
            {"label": f"Opt. Abschlag {year}", "value": f"{opt_abschlag:.0f} €", "sub": f"statt {abschlag:.0f} €/Mo"},
            {"label": f"Erwart. Diff. {year}", "value": f"{'+' if diff >= 0 else ''}{diff:.0f} €",
             "sub": "Gutschrift" if diff >= 0 else "Nachzahlung", "status": "ok" if diff >= 0 else "red"},
            {"label": "Progn. Jahresertrag", "value": f"{jahres_ertrag:.0f} €", "sub": f"{total_this_year:.0f} {unit}"},
        ]
    else:
        ap = settings_.get("arbeitspreis") or 0
        gp = settings_.get("grundpreis") or 0
        ep = settings_.get("entwaesserung_preis") or 0
        bw = (settings_.get("brennwert") or 1.0) if meter_type == "gas" else 1.0
        cost = total_this_year * bw * (ap + ep) + 12 * gp
        abschlag = settings_.get("abschlag") or 0
        opt_abschlag = round(cost / 12) if cost else 0
        diff = 12 * abschlag - cost
        chips = [
            {"label": "Letzter Stand", "value": f"{last['value']:.0f} {unit}" if last else "–",
             "sub": last["reading_date"] if last else ""},
            {"label": "Tagesrate aktuell",
             "value": f"{(rate * bw):.2f} kWh/Tag" if rate is not None and meter_type == "gas" else (f"{rate:.2f} {unit}/Tag" if rate is not None else "–"),
             "sub": f"{rate:.2f} {unit}/Tag" if rate is not None and meter_type == "gas" else ""},
            {"label": f"Opt. Abschlag {period_label}", "value": f"{opt_abschlag:.0f} €", "sub": f"statt {abschlag:.0f} €/Mo"},
            {"label": f"Erwart. Diff. {period_label}", "value": f"{'+' if diff >= 0 else ''}{diff:.0f} €",
             "sub": "Gutschrift" if diff >= 0 else "Nachzahlung", "status": "ok" if diff >= 0 else "red"},
            {"label": "Progn. Jahreskosten", "value": f"{cost:.0f} €",
             "sub": ((f"{(total_this_year*bw):.0f} kWh" if meter_type == "gas"
                      else f"{total_this_year:.0f} {unit} Wasser" if meter_type == "water"
                      else f"{total_this_year:.0f} {unit} Strom-Einkauf")
                     + (f" · {period[0].strftime('%d.%m.%Y')}–{period[1].strftime('%d.%m.%Y')}" if period else ""))},
        ]
        if meter_type == "elec_in" and ev_readings:
            split = split_auto_household_cost(forecast, ev_monthly_with_forecast(ev_readings, year), year, ap, gp, pv_daily=pv_daily, ev_readings=ev_readings,
                                              gesamt_by_month=gesamt_by_month_with_forecast(pv_monthly, year))
            chips[-1]["sub"] = f"Strom-Einkauf: davon Haushalt {split['haus']:.0f} €, davon Auto {split['auto']:.0f} €"
        if meter_type == "elec_in" and pv_monthly:
            # HAUSVERBRAUCH = echter Verbrauch, egal woher (PV, Speicher, Netz).
            # Nur Information -- in Abschlag und Jahresabrechnung geht allein
            # der STROM-EINKAUF (Netzbezug) ein. Hochrechnung mit eigenem
            # Verlauf (früher fälschlich mit der Tagesrate des Einkaufs).
            gesamt_forecast = gesamt_by_month_with_forecast(pv_monthly, year)
            gesamt_total_year = sum(gesamt_forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
            if ev_readings or ev_charging_this_year:
                # Auto ebenfalls als JAHRES-Hochrechnung -- früher wurde der
                # bisherige Ladestand von der Jahres-Hochrechnung abgezogen,
                # dadurch war der Haushalt-Anteil zu hoch.
                ev_fc = ev_monthly_with_forecast(ev_readings, year) if ev_readings else {}
                auto_year = sum(ev_fc.get(f"{year}-{m:02d}", 0) for m in range(1, 13)) if ev_fc else (ev_charging_this_year or 0)
                auto_year = min(auto_year, gesamt_total_year) if gesamt_total_year else auto_year
                chips.append({
                    "label": f"Hausverbrauch {year}", "value": f"{gesamt_total_year:.0f} kWh",
                    "sub": f"davon Auto: {auto_year:.0f} kWh, davon Haushalt: {max(0.0, gesamt_total_year - auto_year):.0f} kWh · aus PV, Speicher und Netz",
                })
            else:
                chips.append({
                    "label": f"Hausverbrauch {year}", "value": f"{gesamt_total_year:.0f} kWh",
                    "sub": "echter Verbrauch aus PV, Speicher und Netz",
                })
        if meter_type == "elec_in":
            chips.append({
                "label": f"Strom-Einkauf {year}", "value": f"{total_this_year:.0f} kWh",
                "sub": "Netzbezug — Grundlage für Abschlag und Jahresabrechnung",
            })
    return chips


def consumption_since_settlement(readings: list, settlement_date: date) -> Optional[dict]:
    """Verbrauch seit einem manuell erfassten, tatsächlichen Abrechnungs-
    zeitpunkt — als Reset-Basis dient die letzte Ablesung am oder vor
    diesem Datum (oder, falls keine existiert, die erste Ablesung danach).
    Bewusst unabhängig von der kalenderjahr-basierten Jahresabrechnung
    (compute_full_settlement) gehalten, um deren bereits fein abgestimmte
    Logik nicht anzufassen."""
    if not readings:
        return None
    sorted_readings = sorted(readings, key=lambda r: _parse_date(r["reading_date"]))

    baseline = None
    for r in sorted_readings:
        if _parse_date(r["reading_date"]) <= settlement_date:
            baseline = r
    if baseline is None:
        baseline = sorted_readings[0]

    latest = sorted_readings[-1]
    if latest["id"] == baseline["id"]:
        return None

    # Ein Zählerwechsel zwischen Basis und aktuellem Stand würde die Differenz
    # verfälschen (Sprung auf einen neuen, bei 0 startenden Zähler) — in dem
    # Fall lieber keinen Wert zeigen als einen offensichtlich falschen.
    between = [r for r in sorted_readings if baseline["reading_date"] < r["reading_date"] <= latest["reading_date"]]
    if any(r.get("is_new_meter") for r in between):
        return None

    delta = latest["value"] - baseline["value"]
    days = (_parse_date(latest["reading_date"]) - _parse_date(baseline["reading_date"])).days
    return {
        "since_date": settlement_date.isoformat(),
        "baseline_date": baseline["reading_date"],
        "baseline_value": baseline["value"],
        "latest_date": latest["reading_date"],
        "latest_value": latest["value"],
        "consumption": round(delta, 2),
        "days": days,
    }


def compute_reading_intervals(readings: list) -> list:
    """Ablesungen mit Delta/Tage/Tagesrate zwischen aufeinanderfolgenden
    Ablesungen — für die Detailtabelle je Zählerseite."""
    result = []
    for i, cur in enumerate(readings):
        prev = readings[i - 1] if i > 0 else None
        entry = {**cur, "delta": None, "days": None, "rate": None}
        if prev and not cur.get("is_new_meter"):
            d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
            days = (d2 - d1).days
            if days > 0:
                delta = cur["value"] - prev["value"]
                entry["delta"] = round(delta, 2)
                entry["days"] = days
                entry["rate"] = round(delta / days, 3)
        elif prev and cur.get("is_new_meter"):
            entry["delta"] = "meter_switch"
        result.append(entry)
    return result


def compute_cumulative_cost(meter_type: str, readings: list, settings_: dict,
                             pv_monthly: Optional[list] = None, today: Optional[date] = None,
                             ev_readings: Optional[list] = None,
                             pv_daily: Optional[list] = None) -> list:
    """Kumulative Kosten übers Jahr — Ist-Kosten vs. Abschlag vs. optimaler
    Abschlag, monatsweise aufsummiert. Für den Kumulativ-Chart je Zählerseite
    (nur Gas/Strombezug, keine Einspeisung).

    Bei Strombezug UND vorhandenen Zappi-Ablesungen zusätzlich in "Auto" und
    "Sonstiges" aufgeschlüsselt, als Ergänzung zur (unverändert bleibenden)
    Gesamtansicht -- der Grundpreis (fixer Anschlusskostenanteil) bleibt
    dabei komplett bei "Sonstiges", da er nicht davon abhängt, wie viel
    gefahren wurde; nur der Arbeitspreis-Anteil wird nach tatsächlichem
    Auto- vs. Haushaltsverbrauch aufgeteilt."""
    today = today or date.today()
    year = today.year
    rate = current_daily_rate_with_pv(meter_type, readings, pv_monthly or [])
    monthly = get_effective_monthly(meter_type, readings, pv_monthly, extrapolate_current=False)
    forecast = forecast_missing_months(monthly, rate, date(year, 1, 1), date(year, 12, 31),
                                       data_through=data_through_date(meter_type, readings, pv_monthly))

    ap = settings_.get("arbeitspreis") or 0
    gp = settings_.get("grundpreis") or 0
    ep = settings_.get("entwaesserung_preis") or 0
    bw = (settings_.get("brennwert") or 1.0) if meter_type == "gas" else 1.0
    abschlag = settings_.get("abschlag") or 0

    total_this_year = sum(forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    full_year_cost = total_this_year * bw * (ap + ep) + 12 * gp
    opt_abschlag = round(full_year_cost / 12) if full_year_cost else 0

    # Auto/Sonstiges-Aufschlüsselung: dieselbe kWh-Quelle (Sungrow
    # "Gesamtverbrauch") wie im Verbrauchs-Chart, damit beide Ansichten
    # konsistent zueinander bleiben.
    split_by_key = {}
    if meter_type == "elec_in" and ev_readings:
        split = split_auto_household_cost(forecast, ev_monthly_with_forecast(ev_readings, year), year, ap, gp, pv_daily=pv_daily, ev_readings=ev_readings,
                                              gesamt_by_month=gesamt_by_month_with_forecast(pv_monthly, year))
        split_by_key = {row["key"]: row for row in split["months"]}

    result = []
    cum_cost = cum_abschlag = cum_opt = cum_auto = cum_sonstiges = 0.0
    for m in range(1, 13):
        key = f"{year}-{m:02d}"
        consumption = forecast.get(key, 0)
        cum_cost += consumption * bw * (ap + ep) + gp
        cum_abschlag += abschlag
        cum_opt += opt_abschlag
        row = {
            "key": key, "cost": round(cum_cost, 2),
            "abschlag": round(cum_abschlag, 2), "opt_abschlag": round(cum_opt, 2),
        }
        if meter_type == "elec_in" and ev_readings:
            cum_auto += split_by_key[key]["auto"]
            cum_sonstiges += split_by_key[key]["haus"]
            row["auto_cost"] = round(cum_auto, 2)
            row["sonstiges_cost"] = round(cum_sonstiges, 2)
        result.append(row)
    return result


def compute_autarkie_series(pv_monthly: list) -> list:
    """Autarkiegrad (Eigenverbrauchsanteil) je PV-Monatsdatensatz —
    (Gesamtverbrauch − Netzbezug) / Gesamtverbrauch × 100."""
    result = []
    for d in pv_monthly:
        gesamt = d.get("gesamt") or 0
        bezug = d.get("bezug") or 0
        autarkie = round(max(0, gesamt - bezug) / gesamt * 100) if gesamt > 0 else 0
        result.append({"key": d["key"], "autarkie": autarkie})
    return result
