#!/usr/bin/env python3
"""
Notfall-Zugang zurücksetzen — für den Fall, dass Passwort UND Passkey/TOTP
nicht mehr funktionieren (Gerät verloren, Passwort vergessen, ...).

WICHTIG: Dieses Skript rührt an KEINER Finanzdaten — es setzt ausschließlich
Benutzername, Passwort und alle registrierten 2FA-Verfahren (Passkeys, TOTP)
zurück. Alle Konten, Verträge, Einnahmen etc. bleiben unverändert erhalten.

Wird normalerweise NICHT direkt aufgerufen, sondern über die jeweilige
Startdatei für die eigene Plattform:
  - macOS:   reset-password.command (im Projekt-Hauptordner, doppelklicken)
  - Windows: Reset-Password.bat (im Projekt-Hauptordner, doppelklicken)

Diese Trennung ist bewusst: Jede Person mit physischem/lokalem Zugriff auf
IHRE EIGENE Installation (Mac Mini der Familie, oder der eigene Windows-PC
eines Freundes) kann sich damit selbst wieder Zugang verschaffen, ohne
Terminal-Kenntnisse oder Fernzugriff auf einen anderen Rechner zu brauchen.
"""
import getpass
import re
import sqlite3
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "finance.db"


def main():
    print("=" * 60)
    print("Family Finance — Zugang zurücksetzen")
    print("=" * 60)
    print()
    print("Dies setzt NUR Benutzername, Passwort und alle registrierten")
    print("Passkeys/TOTP-Codes zurück. Alle Finanzdaten bleiben erhalten.")
    print()

    if not DB_PATH.exists():
        print(f"FEHLER: Keine Datenbank gefunden unter {DB_PATH}")
        print("Ist der Ordner richtig? Läuft die App schon mindestens einmal?")
        sys.exit(1)

    confirm = input("Fortfahren? (ja/nein): ").strip().lower()
    if confirm not in ("ja", "j", "yes", "y"):
        print("Abgebrochen.")
        sys.exit(0)

    print()
    username = input("Neuer Benutzername: ").strip()
    if not username:
        print("FEHLER: Benutzername darf nicht leer sein.")
        sys.exit(1)

    while True:
        password = getpass.getpass("Neues Passwort (mind. 8 Zeichen): ")
        if len(password) < 8:
            print("Zu kurz — mindestens 8 Zeichen.")
            continue
        password2 = getpass.getpass("Neues Passwort wiederholen: ")
        if password != password2:
            print("Stimmt nicht überein, bitte erneut.")
            continue
        break

    # bcrypt erst hier importieren -- falls das Skript versehentlich mit
    # einem anderen Python als der venv aufgerufen wird, kommt die
    # Fehlermeldung erst nach den einfachen Eingaben, nicht schon ganz am Anfang.
    try:
        import bcrypt
    except ImportError:
        print()
        print("FEHLER: Das 'bcrypt'-Paket fehlt. Dieses Skript muss mit dem")
        print("Python der App-eigenen virtuellen Umgebung laufen (das erledigt")
        print("die jeweilige reset-password.command / Reset-Password.bat für dich).")
        sys.exit(1)

    password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        "UPDATE app_user SET username=?, password_hash=?, totp_secret=NULL WHERE id=1",
        (username, password_hash),
    )
    if conn.total_changes == 0:
        # Noch nie ein Zugang angelegt -- als Erststart behandeln
        conn.execute(
            "INSERT INTO app_user (id, username, password_hash, totp_secret) VALUES (1, ?, ?, NULL)",
            (username, password_hash),
        )
    deleted_passkeys = conn.execute("DELETE FROM passkeys").rowcount
    conn.commit()
    conn.close()

    print()
    print("=" * 60)
    print("✅ Zugang zurückgesetzt.")
    print(f"   Benutzername: {username}")
    print(f"   {deleted_passkeys} registrierte(r) Passkey(s) entfernt, TOTP zurückgesetzt.")
    print("   Beim nächsten Öffnen der App wird ein neuer Passkey (oder TOTP)")
    print("   zur Einrichtung verlangt, wie beim allerersten Start.")
    print("=" * 60)


if __name__ == "__main__":
    main()
