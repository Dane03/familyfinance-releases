-- Family Finance Center — Datenbankschema (SQLite)
-- Läuft komplett lokal, keine Cloud-Anbindung nötig.

-- Login: ein Familien-Zugang, gesichert durch Passwort + Passkey (WebAuthn) als 2FA
CREATE TABLE IF NOT EXISTS app_user (
    id INTEGER PRIMARY KEY CHECK (id = 1),   -- es gibt bewusst nur einen Account
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS passkeys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT,                       -- z.B. "iPhone von Anna"
    credential_id TEXT UNIQUE NOT NULL,
    public_key TEXT NOT NULL,
    sign_count INTEGER NOT NULL DEFAULT 0,
    rp_id TEXT,                       -- Adresse, unter der der Passkey registriert wurde
                                       -- (z.B. "localhost" oder "mac-mini.tailXXXXX.ts.net")
                                       -- Passkeys sind fest an ihre RP-ID gebunden — wechselt
                                       -- die Adresse (z.B. durch Tailscale-Einrichtung), zählt
                                       -- ein alter Passkey nicht mehr und ein neuer wird fällig.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,              -- z.B. "Gemeinschaftskonto BBBank"
    owner TEXT,                      -- z.B. "Anna", "Tom", "Gemeinsam"
    iban TEXT,
    note TEXT
);

CREATE TABLE IF NOT EXISTS income (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,             -- z.B. "Gehalt Anna"
    category TEXT,                   -- z.B. "Gehalt", "Kindergeld", "Sonstiges"
    amount REAL NOT NULL,
    frequency TEXT NOT NULL DEFAULT 'monthly',  -- monthly | quarterly | yearly
    account_id INTEGER REFERENCES accounts(id),
    active INTEGER NOT NULL DEFAULT 1,
    source TEXT NOT NULL DEFAULT 'manuell',     -- 'manuell' | 'lohnabrechnung'
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sort_order INTEGER DEFAULT 0     -- manuelle Reihenfolge (per Drag & Drop)
);

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,        -- feste Themen: Versicherungen, Abos, Internet,
                                       -- Mobilfunk, Mitgliedsbeiträge, Sparen, Haus, Sonstiges
    sort_order INTEGER DEFAULT 0
);

-- Versicherungstypen für die Vorsorge-/Risikoabsicherung-Einordnung — wie bei
-- categories: eine feste Grundliste (siehe vorsorge.py INSURANCE_TYPES) plus
-- hier gespeicherte, vom Nutzer selbst ergänzte Typen.
CREATE TABLE IF NOT EXISTS insurance_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    sort_order INTEGER DEFAULT 0
);

-- Verträge / Daueraufträge / Abos — das Herzstück für Kündigungs- und Änderungs-Erinnerungen
-- Familienmitglieder als Stammdaten — Namen werden überall daraus abgeleitet,
-- statt an jeder Stelle neu einzutippen.
CREATE TABLE IF NOT EXISTS family_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL DEFAULT 'kind',   -- 'elternteil' | 'kind'
    birth_date DATE,
    freistellungsauftrag_used REAL,      -- bereits bei Banken beantragter
        -- Freistellungsauftrag in €, zum Abgleich mit dem gesetzlichen
        -- Sparerpauschbetrag (1.000€/Person, Stand 2026) — manuell gepflegt,
        -- da nicht aus vorhandenen Daten ableitbar
    sv_nummer TEXT,            -- Sozialversicherungsnummer
    steuer_id TEXT,            -- steuerliche Identifikationsnummer (11-stellig, lebenslang gültig)
    steuerklasse TEXT,         -- I - VI, bei Ehepaaren z.B. auch "IV/IV" oder "III/V"
    krankenkasse TEXT,
    etin TEXT,                 -- electronic Taxpayer Identification Number (Lohnsteuerbescheinigung)
    steuernummer TEXT,         -- vom Finanzamt vergeben, ändert sich ggf. bei Umzug
    finanzamt TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS person_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id INTEGER NOT NULL REFERENCES family_members(id),
    original_filename TEXT,
    stored_path TEXT NOT NULL,
    file_hash TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contracts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,              -- z.B. "Gas – octopus"
    provider TEXT,                    -- z.B. "octopus energy" (Vertragspartner)
    contract_number TEXT,             -- Vertragsnummer / Kundennummer
    category_id INTEGER REFERENCES categories(id),
    subcategory TEXT,                 -- bei Haus z.B. "Finanzierung" | "Nebenkosten"
    account_id INTEGER REFERENCES accounts(id),
    amount REAL NOT NULL,             -- aktueller Beitrag
    frequency TEXT NOT NULL DEFAULT 'monthly',   -- monthly | quarterly | yearly
    payment_method TEXT,              -- Lastschrift | Dauerauftrag | Überweisung
    split_partner TEXT,               -- falls mit Dritten geteilt (z.B. Abo-Freunde)
    split_share REAL DEFAULT 1.0,     -- eigener Anteil, 1.0 = voll
    contract_start DATE,
    contract_end DATE,                -- Laufzeitende, falls bekannt
    notice_period_days INTEGER,       -- Kündigungsfrist in Tagen
    auto_renews INTEGER DEFAULT 1,    -- verlängert sich automatisch?
    status TEXT NOT NULL DEFAULT 'active',  -- active | cancelled | expired
    source TEXT NOT NULL DEFAULT 'import',  -- 'import' | 'manuell' | 'foto'
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed INTEGER NOT NULL DEFAULT 1,  -- 0 = beim Import als "Sonstiges" gelandet, noch nicht bestätigt
    last_receipt_id INTEGER,          -- letzter bestätigter Foto-Beleg (siehe receipts), für Anzeige in der UI
    link TEXT,                        -- z.B. Link zum Kundenportal des Anbieters
    sort_order INTEGER DEFAULT 0,     -- manuelle Reihenfolge innerhalb der Rubrik (per Drag & Drop)
    note TEXT,
    person_id INTEGER REFERENCES family_members(id),  -- wem gehört das (Vorsorge/Risikoabsicherung)
    interest_rate REAL,               -- Zinssatz bei Haus/Finanzierung, in % p.a.
    remaining_debt REAL,              -- aktuelle Restschuld bei Haus/Finanzierung, in €
    repayment_rate REAL,              -- anfänglicher Tilgungssatz bei Haus/Finanzierung, in % p.a.
    fixed_interest_until DATE,        -- Ende der Zinsbindung bei Haus/Finanzierung — NICHT das Tilgungsende!
    insurance_type TEXT,              -- z.B. 'Risikolebensversicherung', 'Berufsunfähigkeit', 'Hausrat', ...
    insurance_expiry DATE,            -- Ablaufdatum, bei Risikolebensversicherung
    insurance_sum REAL,               -- Versicherungssumme, bei Risikolebensversicherung
    insurance_sum_type TEXT,          -- 'fix' | 'fallend', bei Risikolebensversicherung
    bu_monthly_pension REAL           -- Höhe der BU-Rente/Monat, bei Berufsunfähigkeit
);

CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contract_id INTEGER REFERENCES contracts(id),  -- NULL bei Einzelausgaben
    label TEXT NOT NULL,
    amount REAL NOT NULL,
    category_id INTEGER REFERENCES categories(id),
    account_id INTEGER REFERENCES accounts(id),
    date DATE NOT NULL,
    receipt_id INTEGER REFERENCES receipts(id),
    note TEXT
);

-- Fotobelege — landen hier automatisch nach OCR-Verarbeitung
CREATE TABLE IF NOT EXISTS receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_filename TEXT,
    stored_path TEXT NOT NULL,        -- z.B. data/receipts/2026/Haus/octopus_2026-07-29.jpg
    file_hash TEXT,                   -- SHA-256 des Dateiinhalts, für Duplikat-Erkennung
    ocr_text TEXT,
    detected_amount REAL,
    detected_provider TEXT,
    detected_date DATE,
    contract_id INTEGER REFERENCES contracts(id),
    asset_id INTEGER REFERENCES assets(id),  -- alternativ zu contract_id: Beleg zu einem
        -- Vermögenswert (Kontoauszug, Depotauszug, Immobiliendokument) statt zu einem Vertrag
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    review_needed INTEGER DEFAULT 1   -- 1 = noch nicht bestätigt
);

-- Vermögensübersicht: Konten, Depots, Immobilien und sonstige Vermögenswerte,
-- die NICHT bereits über Altersvorsorge (pension_accounts) oder laufende
-- Ausgaben (contracts) erfasst sind. Eine Immobilie kann über
-- linked_contract_id mit ihrem Finanzierungsvertrag verknüpft werden, um
-- das Netto-Immobilienvermögen (Wert − Restschuld) zu berechnen.
CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,               -- 'konto' | 'immobilie' | 'depot' | 'sonstiges'
    label TEXT NOT NULL,
    provider TEXT,
    account_number TEXT,              -- Vertrags-/Konto-/Depotnummer, z.B. zur Unterscheidung
        -- mehrerer gleichartiger Konten beim selben Anbieter
    purpose TEXT,                     -- Zweck des Depots/Kontos, z.B. 'Altersvorsorge',
        -- 'Vermögensaufbau', 'Liquiditätsreserve' — ein Depot MIT dem Zweck
        -- Altersvorsorge ist konzeptionell dasselbe wie ein "Altersvorsorge"-
        -- Vermögenswert, nur eben strukturell als Depot mit Positionen geführt
    person_id INTEGER REFERENCES family_members(id),  -- NULL = gemeinsam/Haushalt
    current_value REAL,
    account_type TEXT,                 -- nur für type='konto': 'giro' | 'tagesgeld' |
        -- 'festgeld' — Grundlage für die Anlageklassen-Verteilung (Liquidität
        -- vs. Tages-/Festgeld sind unterschiedliche Anlageklassen)
    linked_contract_id INTEGER REFERENCES contracts(id),  -- LEGACY: nur noch für die
        -- einmalige Migration nach asset_financing_links gelesen, siehe unten
    note TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Einzelne Positionen innerhalb eines Depots (z.B. die 6 ETFs in einem
-- Riester-Fondsdepot) — Grundlage für die Asset-Allokations-Auswertung
-- (wie viel % Aktien/Anleihen, wie viel % je Region). Die App selbst hat
-- keinen eigenständigen Internetzugriff (Offline-First), daher werden
-- Asset-Klasse und Region hier manuell gepflegt statt automatisch online
-- abgefragt — Claude kann dabei im Gespräch unterstützen.
CREATE TABLE IF NOT EXISTS asset_holdings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL REFERENCES assets(id),
    isin TEXT,
    name TEXT NOT NULL,
    current_value REAL NOT NULL,
    asset_class TEXT,                 -- 'aktie' | 'anleihe' | 'cash' | 'rohstoffe' | 'sonstiges'
    region TEXT,                      -- 'usa' | 'europa' | 'schwellenlaender' |
        -- 'sonstige_industrielaender' | 'global' | 'sonstiges'
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Periodische Momentaufnahmen des Gesamtvermögens für den Zeitverlauf — ein
-- Wert pro Tag reicht, da sich Vermögen naturgemäß nur langsam ändert. Wird
-- beim täglichen Backup-Job UND bei jedem Server-Neustart geschrieben
-- (überschreibt den Eintrag desselben Tages statt neue Zeilen zu häufen).
CREATE TABLE IF NOT EXISTS networth_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_date DATE NOT NULL UNIQUE,
    total_networth REAL NOT NULL,
    liquid REAL,
    pension_capital REAL,
    immobilien_netto REAL
);

-- Ziel-Allokation (Soll) je Anlageklasse, für den Abgleich mit der
-- tatsächlichen (Ist-)Allokation aus asset_holdings. Nur eine Zeile pro
-- Klasse — beim Setzen wird die bestehende einfach überschrieben.
CREATE TABLE IF NOT EXISTS allocation_targets (
    asset_class TEXT PRIMARY KEY,
    target_percent REAL NOT NULL
);

-- Eine Immobilie kann mit MEHREREN Finanzierungsverträgen verknüpft sein
-- (z.B. Hauptdarlehen + KfW-Förderdarlehen) — deshalb eine eigene
-- Verknüpfungstabelle statt eines einzelnen Felds auf assets. Die
-- Restschulden aller verknüpften Verträge werden für das
-- Netto-Immobilienvermögen zusammengezählt.
CREATE TABLE IF NOT EXISTS asset_financing_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL REFERENCES assets(id),
    contract_id INTEGER NOT NULL REFERENCES contracts(id),
    UNIQUE(asset_id, contract_id)
);

-- Mehrere Dokumente je Rentenkonto über die Zeit (z.B. jährliche
-- Renteninformation) statt nur des jeweils letzten — die Historie bleibt
-- beim Hochladen eines neuen Dokuments erhalten statt überschrieben zu werden.
CREATE TABLE IF NOT EXISTS pension_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pension_account_id INTEGER NOT NULL REFERENCES pension_accounts(id),
    original_filename TEXT,
    stored_path TEXT NOT NULL,
    file_hash TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Gehaltsabrechnungen (PDF, teils passwortgeschützt) — analog zu Belegen
CREATE TABLE IF NOT EXISTS payslips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_filename TEXT,
    stored_path TEXT NOT NULL,
    file_hash TEXT,
    raw_text TEXT,
    detected_net_amount REAL,
    detected_employer TEXT,
    detected_month TEXT,              -- z.B. "2026-07"
    income_id INTEGER REFERENCES income(id),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    review_needed INTEGER DEFAULT 1
);

-- Anstehende Erinnerungen (Kündigungsfristen, Vertragsenden, Dauerauftrag-Anpassungen)
CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contract_id INTEGER REFERENCES contracts(id),
    reminder_type TEXT NOT NULL,      -- 'notice_period' | 'contract_end' | 'amount_change'
    trigger_date DATE NOT NULL,       -- wann die E-Mail rausgehen soll
    message TEXT NOT NULL,
    sent INTEGER DEFAULT 0,
    sent_at TIMESTAMP
);

-- Allgemeine App-Einstellungen (z.B. manuelle Reihenfolge der Dashboard-Blöcke,
-- Energy-Monitor-Feature-Toggle, Zähler-Tarifeinstellungen)
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- Zählerstände für den Energy Monitor (Gas, Strombezug, Einspeisung, Wasser).
-- Aus den erfassten Ständen wird der monatliche Verbrauch per Tagesrate
-- zwischen zwei Ablesungen berechnet (siehe backend/meters.py).
CREATE TABLE IF NOT EXISTS meter_readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meter_type TEXT NOT NULL,          -- 'gas' | 'elec_in' | 'elec_out' | 'water'
    reading_date DATE NOT NULL,
    value REAL NOT NULL,               -- Zählerstand in m³ (Gas/Wasser) oder kWh (Strom)
    is_new_meter INTEGER NOT NULL DEFAULT 0,  -- 1 = erster Stand nach einem Zählerwechsel
                                               -- (markiert eine Zählerstands-Zäsur, damit
                                               -- der Sprung nicht als Verbrauch gewertet wird)
    note TEXT,
    receipt_id INTEGER REFERENCES receipts(id),  -- optionaler Beleg-Nachweis (Ablesefoto etc.)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_meter_readings_type_date ON meter_readings(meter_type, reading_date);

-- Manuell erfasste, tatsächliche Abrechnungszeitpunkte je Zählerseite —
-- unabhängig vom kalenderjahr-basierten Jahresabrechnungs-Vergleich.
-- Der jeweils letzte Eintrag dient als Reset-Basis für "Verbrauch seit
-- der letzten Abrechnung" statt "seit Jahresbeginn".
CREATE TABLE IF NOT EXISTS meter_settlements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    meter_type TEXT NOT NULL,
    settlement_date DATE NOT NULL,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_meter_settlements_type_date ON meter_settlements(meter_type, settlement_date);

-- Gelernte Spalten-Zuordnungen für den intelligenten Datei-Import — pro
-- Zielbereich (expenses/income/contracts) und Datei-"Fingerabdruck" (Spalten-
-- überschriften) wird die einmal bestätigte Zuordnung gespeichert, damit
-- künftige Importe derselben Dateiform ohne erneute KI-Abfrage auskommen.
CREATE TABLE IF NOT EXISTS import_schemas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target TEXT NOT NULL,              -- 'expenses' | 'income' | 'contracts'
    header_signature TEXT NOT NULL,
    column_mapping TEXT NOT NULL,      -- JSON: {"Quellspalte": "zielfeld", ...}
    label TEXT,                        -- optionaler Name, z.B. "Sparkasse-Export"
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    use_count INTEGER DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_import_schema_sig ON import_schemas(target, header_signature);

-- Monatliche PV-Daten aus dem Sungrow-Wechselrichter (iSolarCloud-Export) —
-- ein Datensatz pro Monat, key im Format 'YYYY-MM'.
CREATE TABLE IF NOT EXISTS pv_monthly (
    key TEXT PRIMARY KEY,          -- 'YYYY-MM'
    pv REAL NOT NULL DEFAULT 0,        -- PV-Ertrag kWh
    bezug REAL NOT NULL DEFAULT 0,     -- Netzbezug kWh (laut Wechselrichter)
    einsp REAL NOT NULL DEFAULT 0,     -- Einspeisung kWh
    batt_lad REAL NOT NULL DEFAULT 0,  -- Batterieladung kWh
    batt_ent REAL NOT NULL DEFAULT 0,  -- Batterieentladung kWh
    gesamt REAL NOT NULL DEFAULT 0     -- Gesamtverbrauch Haushalt kWh
);

-- Technische Anlagendaten der PV-Anlage über die Zeit — als Verlauf statt
-- fester Wert, damit eine geplante Erweiterung (mehr kWp/Speicher ab einem
-- bestimmten Datum) sauber abgebildet werden kann, ohne die bisherige
-- Historie zu überschreiben.
CREATE TABLE IF NOT EXISTS pv_system_specs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    installed_year INTEGER,       -- Baujahr dieses Ausbauschritts
    kwp REAL,                     -- Anlagenleistung in kWp
    battery_kwh REAL,             -- Speichergröße in kWh
    valid_from DATE NOT NULL,     -- ab wann dieser Ausbaustand gilt
    note TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Renten-/Vorsorgekonten je Person: gesetzliche Rente (Prognosewert aus der
-- jährlichen Renteninformation) und private Vorsorge (Riester, Rürup,
-- private Rentenversicherung, ETF-Depot fürs Alter, ...).
CREATE TABLE IF NOT EXISTS pension_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id INTEGER NOT NULL REFERENCES family_members(id),
    type TEXT NOT NULL,                 -- 'gesetzlich' | 'privat'
    label TEXT NOT NULL,                -- z.B. "Deutsche Rentenversicherung" | "Riester Sutor-Bank"
    provider TEXT,
    current_value REAL,                 -- bisher angespartes Kapital (nur privat)
    is_riester INTEGER DEFAULT 0,       -- 1 = Riester-Vertrag, für die
        -- Zulagen-Berechnung (Grundzulage + Kinderzulage)
    monthly_contribution REAL,          -- monatliche Einzahlung (nur privat, IGNORIERT falls linked_contract_id gesetzt)
    linked_contract_id INTEGER REFERENCES contracts(id),  -- optional: Verknüpfung zu einem
        -- bestehenden Vertrag unter Ausgaben — Beitrag wird dann live vom
        -- Vertrag abgeleitet statt hier separat gepflegt, Belege kommen aus
        -- derselben Zeitreihe wie beim Vertrag (kein doppeltes Hochladen).
    projected_monthly_at_67 REAL,       -- direkt bekannter Prognosewert (Renteninformation, oder eigene Angabe)
    disability_pension_monthly REAL,    -- volle Erwerbsminderungsrente laut Renteninformation, €/Monat
    return_rate_assumption REAL,        -- individuelle Rendite-Annahme p.a., sonst Standard-Annahme
    document_filename TEXT,             -- LEGACY: nur noch für die einmalige Migration
    document_path TEXT,                 -- nach pension_documents gelesen, sonst ungenutzt
    note TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date);
CREATE INDEX IF NOT EXISTS idx_contracts_end ON contracts(contract_end);
CREATE INDEX IF NOT EXISTS idx_contracts_status ON contracts(status);
CREATE INDEX IF NOT EXISTS idx_receipts_contract ON receipts(contract_id);
CREATE INDEX IF NOT EXISTS idx_receipts_asset ON receipts(asset_id);
CREATE INDEX IF NOT EXISTS idx_asset_holdings_asset ON asset_holdings(asset_id);
CREATE INDEX IF NOT EXISTS idx_asset_financing_links_asset ON asset_financing_links(asset_id);
CREATE INDEX IF NOT EXISTS idx_asset_financing_links_contract ON asset_financing_links(contract_id);
CREATE INDEX IF NOT EXISTS idx_reminders_trigger ON reminders(trigger_date, sent);
