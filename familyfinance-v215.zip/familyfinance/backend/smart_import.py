"""
Intelligenter Datei-Import — liest beliebige Tabellendateien (CSV, XLSX, ODS)
ein, lässt den lokalen Ollama die Spalten den benötigten Feldern zuordnen
(Einnahmen/Ausgaben/Verträge), und merkt sich einmal bestätigte Zuordnungen
für künftige Importe derselben Dateiform (gleiche Spaltenüberschriften) —
dann ganz ohne erneuten Ollama-Aufruf.

Läuft komplett lokal: Ollama läuft auf demselben Mac Mini (siehe chatbot.py),
kein Cloud-Aufruf. Ist Ollama gerade nicht erreichbar oder liefert kein
brauchbares JSON, greift eine einfache Stichwort-Heuristik als Rückfallebene
— der Import funktioniert dann trotzdem, nur ohne KI-Unterstützung.
"""
import json
import re
import urllib.request
from pathlib import Path
from typing import Optional

import pandas as pd

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "qwen3:8b"

# Zielfelder je Import-Ziel — Beschreibung wird dem Modell mitgegeben, damit
# es die Spaltenüberschriften sinnvoll zuordnen kann.
TARGET_FIELDS = {
    "expenses": {
        "label": "Bezeichnung / Verwendungszweck der Ausgabe",
        "amount": "Betrag in Euro (Zahl)",
        "date": "Datum der Ausgabe/Buchung",
        "provider": "Anbieter / Empfänger / Zahlungsempfänger (optional)",
        "category": "Kategorie, z.B. Versicherung, Abo, Haus (optional)",
    },
    "income": {
        "label": "Bezeichnung der Einnahme, z.B. Gehalt, Kindergeld",
        "amount": "Betrag in Euro (Zahl)",
        "frequency": "Häufigkeit: monatlich/vierteljährlich/jährlich (optional)",
    },
    "contracts": {
        "label": "Bezeichnung des Vertrags",
        "provider": "Anbieter / Vertragspartner",
        "amount": "Betrag in Euro pro Zahlungsintervall (Zahl)",
        "frequency": "Häufigkeit: monatlich/vierteljährlich/jährlich (optional)",
        "category": "Kategorie, z.B. Versicherung, Abo, Haus (optional)",
        "contract_number": "Vertragsnummer / Versicherungsnummer (optional)",
        "contract_end": "Vertragsende / Laufzeitende / Fälligkeit (optional)",
    },
    "pv_monthly": {
        "key": "Monat im Format JJJJ-MM, z.B. 2026-07",
        "pv": "PV-Ertrag in kWh",
        "einsp": "Einspeisung ins Netz in kWh",
        "bezug": "Netzbezug laut Wechselrichter in kWh (optional)",
        "batt_lad": "Batterieladung in kWh (optional)",
        "batt_ent": "Batterieentladung in kWh (optional)",
        "gesamt": "Gesamtverbrauch Haushalt in kWh (optional)",
    },
    "meter_readings": {
        "reading_date": "Datum der Zählerablesung",
        "value": "Zählerstand (m³ bei Gas/Wasser, kWh bei Strom)",
    },
    "assets": {
        "label": "Bezeichnung des Vermögenswerts, z.B. Kontoname, Depotname",
        "current_value": "Aktueller Wert / Saldo in Euro (Zahl)",
        "type": "Art: konto, depot, immobilie oder sonstiges (optional)",
        "provider": "Anbieter / Bank / Institut (optional)",
    },
}

REQUIRED_FIELDS = {
    "expenses": ["label", "amount", "date"],
    "income": ["label", "amount"],
    "contracts": ["label", "amount"],
    "pv_monthly": ["key", "pv", "einsp"],
    "meter_readings": ["reading_date", "value"],
    "assets": ["label", "current_value"],
}

_HEURISTIC_KEYWORDS = {
    "label": ["verwendungszweck", "bezeichnung", "beschreibung", "buchungstext", "name", "titel", "empfänger", "text", "vertrag", "leistung"],
    "amount": ["betrag", "eur", "summe", "amount", "wert", "kosten", "preis", "monatsbeitrag"],
    "date": ["datum", "date", "buchungsdatum", "valuta"],
    "provider": ["anbieter", "empfänger", "zahlungsempfänger", "beguenstigter", "begünstigter", "firma"],
    "category": ["kategorie", "rubrik", "category"],
    "frequency": ["häufigkeit", "intervall", "turnus", "frequency", "zahlweise"],
    "contract_number": ["vertragsnummer", "versicherungsnummer", "kundennummer", "vertragsnr"],
    "contract_end": ["vertragsende", "laufzeitende", "fälligkeit", "kündigungsdatum"],
    "key": ["monat", "zeit", "period", "jahr-monat"],
    "pv": ["pv-ertrag", "pv ertrag", "pvertrag", "ertrag", "erzeugung"],
    "bezug": ["netzbezug", "bezug"],
    "einsp": ["einspeisung", "einspeisungng"],
    "batt_lad": ["batt.-ladung", "batterieladung", "ladung"],
    "batt_ent": ["batt.-entladung", "batterieentladung", "entladung"],
    "gesamt": ["gesamtverbrauch", "gesamt"],
    "reading_date": ["datum", "date", "ablesedatum", "zeit"],
    "value": ["zählerstand", "stand", "zaehlerstand", "wert", "value"],
    "current_value": ["wert", "saldo", "kontostand", "depotwert", "betrag", "value"],
    "type": ["art", "typ", "type", "kategorie"],
}


def read_tabular_file(path: Path) -> tuple:
    """Liest CSV/XLSX/XLS/ODS ein. Gibt (DataFrame, Fehlermeldung|None) zurück."""
    suffix = path.suffix.lower()
    try:
        if suffix == ".csv":
            # Deutsche Bank-/Budget-Exporte sind oft nicht UTF-8 und nutzen
            # Semikolon statt Komma als Trenner.
            for encoding in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
                try:
                    df = pd.read_csv(path, sep=None, engine="python", encoding=encoding)
                    break
                except (UnicodeDecodeError, UnicodeError):
                    continue
            else:
                return None, "Datei-Kodierung konnte nicht erkannt werden."
        elif suffix in (".xlsx", ".xls"):
            df = pd.read_excel(path, engine="openpyxl" if suffix == ".xlsx" else None)
        elif suffix == ".ods":
            df = pd.read_excel(path, engine="odf")
        else:
            return None, f"Dateiformat {suffix} wird nicht unterstützt (CSV, XLSX, ODS)."
    except Exception as e:
        return None, f"Datei konnte nicht gelesen werden: {e}"

    df = df.dropna(how="all")  # komplett leere Zeilen raus
    df.columns = [str(c).strip() for c in df.columns]
    if df.empty or len(df.columns) == 0:
        return None, "Datei enthält keine erkennbaren Daten."
    return df, None


def header_signature(columns: list) -> str:
    """Normalisierter, sortierter Schlüssel aus den Spaltenüberschriften —
    identifiziert 'dieselbe Dateiform' unabhängig von Zeilen-Inhalt/Reihenfolge."""
    normalized = sorted(c.strip().lower() for c in columns)
    return "|".join(normalized)


def _heuristic_mapping(columns: list, target: str) -> dict:
    """Einfache Stichwort-Zuordnung als Rückfallebene ohne Ollama."""
    mapping = {}
    used_fields = set()
    for col in columns:
        col_norm = col.strip().lower()
        for field, keywords in _HEURISTIC_KEYWORDS.items():
            if field not in TARGET_FIELDS[target] or field in used_fields:
                continue
            if any(kw in col_norm for kw in keywords):
                mapping[col] = field
                used_fields.add(field)
                break
    return mapping


def _ask_ollama_for_mapping(columns: list, sample_rows: list, target: str) -> Optional[dict]:
    fields_desc = "\n".join(f"- {k}: {v}" for k, v in TARGET_FIELDS[target].items())
    prompt = f"""Ordne die Spaltenüberschriften einer hochgeladenen Tabelle den passenden Zielfeldern zu.

Zielfelder:
{fields_desc}

Spaltenüberschriften der Tabelle: {json.dumps(columns, ensure_ascii=False)}

Beispielzeilen (erste {len(sample_rows)}):
{json.dumps(sample_rows, ensure_ascii=False, default=str)}

Antworte NUR mit einem JSON-Objekt, das Spaltenüberschriften auf Zielfeld-Namen abbildet — \
nur Spalten aufnehmen, bei denen du dir wirklich sicher bist. Beispiel-Format: \
{{"Verwendungszweck": "label", "Betrag EUR": "amount"}}. Kein Fließtext, kein Markdown, nur das JSON-Objekt."""

    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
        "format": "json",
        "think": False,
    }
    req = urllib.request.Request(
        OLLAMA_URL, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read())
        content = data["message"]["content"]
        # Sicherheitsnetz falls "think": false ignoriert wird — ein <think>-
        # Block vor dem eigentlichen JSON würde sonst den Parse-Versuch
        # unten zum Scheitern bringen.
        content = re.sub(r"<think>.*?</think>\s*", "", content, flags=re.DOTALL)
        content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content.strip())
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            return None
        # Nur gültige Zielfelder und tatsächlich vorhandene Spalten übernehmen
        valid_fields = set(TARGET_FIELDS[target])
        col_set = set(columns)
        return {k: v for k, v in parsed.items() if k in col_set and v in valid_fields}
    except Exception:
        return None


def guess_mapping(columns: list, sample_rows: list, target: str) -> tuple:
    """Gibt (mapping, source) zurück — source ist 'ai' oder 'heuristic'."""
    ai_mapping = _ask_ollama_for_mapping(columns, sample_rows, target)
    if ai_mapping:
        # Fehlende Pflichtfelder mit der Heuristik auffüllen, falls Ollama sie ausgelassen hat
        heuristic = _heuristic_mapping(columns, target)
        merged = {**heuristic, **ai_mapping}
        return merged, "ai"
    return _heuristic_mapping(columns, target), "heuristic"


def _parse_amount(raw) -> Optional[float]:
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    s = str(raw).strip()
    if not s:
        return None
    s = re.sub(r"[^\d,.\-]", "", s)
    if not s:
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _parse_date(raw) -> Optional[str]:
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return None
    try:
        parsed = pd.to_datetime(raw, dayfirst=True, errors="coerce")
        if pd.isna(parsed):
            return None
        return parsed.strftime("%Y-%m-%d")
    except Exception:
        return None


_FREQ_MAP = {
    "monatlich": "monthly", "monthly": "monthly", "mtl": "monthly", "mtl.": "monthly",
    "quartalsweise": "quarterly", "quarterly": "quarterly", "vierteljährlich": "quarterly",
    "jährlich": "yearly", "yearly": "yearly", "jaehrlich": "yearly", "jährl": "yearly",
}


def _parse_month_key(raw) -> Optional[str]:
    """Parst diverse Monatsangaben ('2026-07', '07.2026', ein Datum) zu 'YYYY-MM'."""
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return None
    s = str(raw).strip()
    m = re.match(r"^(\d{4})-(\d{1,2})$", s)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}"
    m = re.match(r"^(\d{1,2})[./](\d{4})$", s)
    if m:
        return f"{m.group(2)}-{int(m.group(1)):02d}"
    try:
        parsed = pd.to_datetime(s, dayfirst=True, errors="coerce")
        if pd.isna(parsed):
            return None
        return f"{parsed.year}-{parsed.month:02d}"
    except Exception:
        return None


_NUMERIC_FIELDS = {"amount", "pv", "bezug", "einsp", "batt_lad", "batt_ent", "gesamt", "value", "current_value"}


def apply_mapping(df: pd.DataFrame, mapping: dict, target: str) -> tuple:
    """Wendet die (bestätigte) Spalten-Zuordnung an. Gibt (rows, skipped_count) zurück.
    rows: Liste fertiger dicts passend zum jeweiligen Zielschema."""
    reverse = {v: k for k, v in mapping.items()}  # Zielfeld -> Quellspalte
    rows = []
    skipped = 0
    for _, row in df.iterrows():
        item = {}
        for field in TARGET_FIELDS[target]:
            col = reverse.get(field)
            if col is None or col not in df.columns:
                item[field] = None
                continue
            raw = row[col]
            if field in _NUMERIC_FIELDS:
                item[field] = _parse_amount(raw)
            elif field in ("date", "contract_end", "reading_date"):
                item[field] = _parse_date(raw)
            elif field == "key":
                item[field] = _parse_month_key(raw)
            elif field == "frequency":
                item[field] = _FREQ_MAP.get(str(raw).strip().lower(), "monthly") if raw is not None else "monthly"
            else:
                item[field] = None if (raw is None or (isinstance(raw, float) and pd.isna(raw))) else str(raw).strip()

        missing_required = [f for f in REQUIRED_FIELDS[target] if not item.get(f) and item.get(f) != 0]
        if missing_required:
            skipped += 1
            continue
        rows.append(item)
    return rows, skipped
