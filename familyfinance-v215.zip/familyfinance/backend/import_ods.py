"""
Importiert die bestehende Ausgabenübersicht.ods (Übersicht, Haus, Abos) in die
neue lokale Datenbank. Einmalig ausführen, danach läuft alles über die App weiter.

Nutzung:
    python import_ods.py /pfad/zu/Ausgabenuebersicht.ods
"""
import sys
from pathlib import Path
from typing import Optional
import pandas as pd
from database import get_connection, init_db
from categorize import categorize

FREQ_COLS = {4: "monthly", 5: "quarterly", 6: "yearly"}  # p.M. / p.Q. / p.a. Spalten (0-indexiert)


def get_or_create_category(conn, name: str) -> int:
    cur = conn.execute("SELECT id FROM categories WHERE name = ?", (name,))
    row = cur.fetchone()
    if row:
        return row["id"]
    cur = conn.execute("INSERT INTO categories (name) VALUES (?)", (name,))
    conn.commit()
    return cur.lastrowid


def detect_frequency(row) -> str:
    for col, freq in FREQ_COLS.items():
        val = row.get(col)
        if isinstance(val, str) and val.strip().lower() == "x":
            return freq
    return "monthly"


def parse_sheet(conn, df: pd.DataFrame, split_default: float = 1.0, fallback_category: Optional[str] = None):
    """
    Generischer Parser für die Blattstruktur:
    Spalte 1 = Label, Spalte 2 = Summe (Betrag), Spalte 3 = Abbuchungsart,
    Spalten 4/5/6 = p.M./p.Q./p.a. Kennzeichnung (x), Spalte 7 = entspricht p.M.
    Zeilen ohne Betrag oder mit Label "Summe" sind Abschnittstitel/Zwischensummen
    und werden übersprungen — die Kategorie wird pro Position über categorize()
    bestimmt. Erkennt categorize() nichts Passendes (Ergebnis "Sonstiges"), greift
    fallback_category, falls angegeben (z.B. "Abos" für Freundes-Rückerstattungen
    im Abos-Blatt, die sonst nicht als solche erkennbar wären).
    """
    imported = 0
    for _, row in df.iterrows():
        label = row.get(1)
        amount = row.get(2)
        if not isinstance(label, str):
            continue
        label = label.strip()
        if label == "" or label.lower() == "summe":
            continue
        if not isinstance(amount, (int, float)) or pd.isna(amount):
            continue  # Abschnittstitel, z.B. "Ausgaben – Haus" — keine eigene Position

        payment_method = row.get(3) if isinstance(row.get(3), str) else None
        frequency = detect_frequency(row)
        category_name, subcategory = categorize(label)
        needs_review = category_name == "Sonstiges"
        if category_name == "Sonstiges" and fallback_category:
            category_name = fallback_category
            needs_review = False
        category_id = get_or_create_category(conn, category_name)

        conn.execute(
            """INSERT INTO contracts
               (label, category_id, subcategory, amount, frequency, payment_method,
                split_share, status, source, reviewed)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'active', 'import', ?)""",
            (label, category_id, subcategory, float(amount), frequency,
             payment_method, split_default, int(not needs_review)),
        )
        imported += 1
    conn.commit()
    return imported


def parse_income(conn, df: pd.DataFrame):
    imported = 0
    for _, row in df.iterrows():
        label = row.get(1)
        amount = row.get(2)
        if not isinstance(label, str) or not isinstance(amount, (int, float)) or pd.isna(amount):
            continue
        label = label.strip()
        if label.lower() in ("summe", "einnahmen") :
            continue
        frequency = detect_frequency(row)
        conn.execute(
            "INSERT INTO income (label, amount, frequency, active, source) VALUES (?, ?, ?, 1, 'import')",
            (label, float(amount), frequency),
        )
        imported += 1
    conn.commit()
    return imported


def main(ods_path: str):
    init_db()
    conn = get_connection()

    xls = pd.ExcelFile(ods_path, engine="odf")

    # --- Übersicht: Einnahmen + allgemeine Ausgaben/Lebenshaltung/Sparen ---
    df_uebersicht = pd.read_excel(ods_path, engine="odf", sheet_name="Übersicht", header=None)
    n_income = parse_income(conn, df_uebersicht.iloc[1:7])          # Einnahmen-Block
    n_general = parse_sheet(conn, df_uebersicht.iloc[8:])

    # --- Haus: Fixkosten (Gas, Strom, Wasser, etc.) ---
    df_haus = pd.read_excel(ods_path, engine="odf", sheet_name="Haus", header=None)
    n_haus = parse_sheet(conn, df_haus.iloc[1:11])

    # --- Abos ---
    df_abos = pd.read_excel(ods_path, engine="odf", sheet_name="Abos", header=None)
    n_abos = parse_sheet(conn, df_abos.iloc[1:], fallback_category="Abos")

    conn.close()
    print(f"Import fertig: {n_income} Einnahmen, {n_haus} Hausfixkosten, "
          f"{n_general} weitere Ausgaben, {n_abos} Abo-Positionen.")
    print("Hinweis: Vertragsnummern, Laufzeitenden und Kündigungsfristen standen in der "
          "Ursprungsdatei nicht drin — die trägst du in der App einmalig pro Vertrag nach, "
          "danach übernehmen die Erinnerungen automatisch.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Nutzung: python import_ods.py /pfad/zu/Ausgabenuebersicht.ods")
        sys.exit(1)
    main(sys.argv[1])
