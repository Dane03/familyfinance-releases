"""
Import von Lohn-/Gehaltsabrechnungen (PDF, teils passwortgeschützt).

Läuft komplett lokal — das Passwort wird nur zum Entschlüsseln im Arbeits-
speicher verwendet und NICHT in der Datenbank gespeichert. Der Aufbau von
Gehaltsabrechnungen unterscheidet sich stark je nach Lohnprogramm (DATEV,
SAP, Lexware, ...), daher wird hier bewusst nicht "geraten", sondern der
erkannte Betrag/Monat immer noch einmal zur Bestätigung vorgelegt (analog
zum Beleg-Upload) — siehe /api/payslips/upload + /confirm in app.py.
"""
import re
from datetime import date
from pathlib import Path
from typing import Optional

from pypdf import PdfReader
from pypdf.errors import FileNotDecryptedError

MONTHS = {
    "januar": 1, "februar": 2, "märz": 3, "april": 4, "mai": 5, "juni": 6,
    "juli": 7, "august": 8, "september": 9, "oktober": 10, "november": 11, "dezember": 12,
}

# Typische Bezeichnungen für den Auszahlungsbetrag auf deutschen Gehaltsabrechnungen
NET_LABELS = [
    r"auszahlungsbetrag", r"netto[- ]?verdienst", r"nettoentgelt",
    r"überweisungsbetrag", r"auszuzahlender betrag",
]


def extract_text(pdf_path: Path, password: Optional[str] = None) -> str:
    reader = PdfReader(str(pdf_path))
    if reader.is_encrypted:
        if not password:
            raise ValueError("Diese PDF ist passwortgeschützt — bitte Passwort angeben.")
        result = reader.decrypt(password)
        if result == 0:
            raise ValueError("Passwort falsch — PDF konnte nicht entschlüsselt werden.")
    try:
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except FileNotDecryptedError:
        raise ValueError("Passwort falsch oder fehlt — PDF konnte nicht gelesen werden.")


def _extract_net_amount(text: str) -> Optional[float]:
    lower = text.lower()
    for label_pattern in NET_LABELS:
        match = re.search(label_pattern + r"[^\d\-]{0,20}(-?\d{1,3}(?:\.\d{3})*,\d{2})", lower)
        if match:
            raw = match.group(1).replace(".", "").replace(",", ".")
            return float(raw)

    # Fällt die Stichwortsuche aus (z.B. weil Label und Wert in der PDF-Tabelle
    # weit auseinandergerissen extrahiert werden), ist eine Zahl in der Nähe
    # der IBAN sehr zuverlässig der tatsächliche Überweisungsbetrag — je nach
    # Lohnprogramm entweder direkt auf der IBAN-Zeile selbst, oder als letzter
    # Wert auf der Zeile unmittelbar davor (vor den Kontodaten).
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.search(r"\bDE\d{2}[\d\s]{16,22}\b", line):
            amounts_on_line = re.findall(r"(\d{1,3}(?:\.\d{3})*,\d{2})", line)
            if not amounts_on_line and i > 0:
                amounts_on_line = re.findall(r"(\d{1,3}(?:\.\d{3})*,\d{2})", lines[i - 1])
            if amounts_on_line:
                raw = amounts_on_line[-1].replace(".", "").replace(",", ".")
                return float(raw)
            break

    # Letzter Ausweg: größter Eurobetrag im Dokument. Achtung — das trifft bei
    # Brutto-Netto-Abrechnungen oft den Brutto- statt den Nettobetrag, weil
    # Brutto immer die größere Zahl ist; deshalb nur, wenn beide Wege oben
    # nichts gefunden haben.
    amounts = re.findall(r"(\d{1,3}(?:\.\d{3})*,\d{2})", text)
    if not amounts:
        return None
    values = [float(a.replace(".", "").replace(",", ".")) for a in amounts]
    return max(values)


def _extract_month(text: str) -> Optional[str]:
    lower = text.lower()
    match = re.search(r"abrechnungsmonat[:\s]*([a-zäöü]+)\s+(\d{4})", lower)
    if not match:
        match = re.search(r"(" + "|".join(MONTHS) + r")\s+(\d{4})", lower)
    if not match:
        return None
    month_name, year = match.groups()
    month = MONTHS.get(month_name)
    if not month:
        return None
    return f"{year}-{month:02d}"


def _extract_month_from_filename(filename: str) -> Optional[str]:
    """Rückfall, wenn im PDF-Text kein Monat gefunden wurde — z.B. bei einer
    Lohnsteuerbescheinigung, deren Text meist nur ein Kalenderjahr nennt statt
    "Monatsname Jahr". Lohnprogramme benennen Dateien aber oft konsistent
    nach dem Muster "..._JAHR_MONATSZAHL_Monatsname..." oder "..._JAHR_Monatsname...".
    """
    lower = filename.lower().replace("_", " ").replace("-", " ")
    # Jahr + Monatsname im Dateinamen, z.B. "...2022 12 Dezember..." (die
    # Ziffernfolge "12" zwischen Jahr und Monatsname ist normal — deshalb
    # hier bewusst beliebige Zeichen erlaubt, nicht nur \D wie zunächst
    # versucht, sonst hätte genau dieser Fall nicht gegriffen).
    match = re.search(r"(\d{4}).{0,8}?(" + "|".join(MONTHS) + r")", lower)
    if not match:
        # Monatsname vor Jahr, z.B. "...Dezember 2022..."
        match = re.search(r"(" + "|".join(MONTHS) + r").{0,8}?(\d{4})", lower)
        if match:
            month_name, year = match.groups()
        else:
            return None
    else:
        year, month_name = match.groups()
    month = MONTHS.get(month_name)
    if not month:
        return None
    return f"{year}-{month:02d}"


def _extract_employer(text: str) -> Optional[str]:
    # Häufige Metadaten-Kennzeichen auf deutschen Lohnabrechnungen — Zeilen mit
    # diesen Begriffen sind so gut wie nie der Firmenname, sondern Personal-
    # nummer, Kostenstelle, SV-/Steuer-Nummer o.ä. Ohne diesen Filter griff die
    # bisherige "erste nicht-numerische Zeile"-Heuristik oft genau eine solche
    # Metadaten-Kopfzeile statt des tatsächlichen Arbeitgebernamens.
    metadata_markers = [
        "pers.-nr", "personalnr", "abteilung", "kst.-st", "kostenstelle",
        "sv-nummer", "sv-nr", "steuer id", "steuer-id", "steuerid",
        "lohnabrechnung", "gehaltsabrechnung", "abrechnungszeitraum",
    ]
    for line in text.splitlines():
        line = line.strip()
        if len(line) <= 3 or re.match(r"^\d", line):
            continue
        if any(marker in line.lower() for marker in metadata_markers):
            continue
        return line
    return None


def extract_name_candidates(text: str, filename: str = "") -> list:
    """Sammelt mögliche Vornamen-Kandidaten aus Dateiname UND Dokumenttext —
    für die automatische Zuordnung "wessen Gehaltsabrechnung ist das?".
    Der Dateiname ist oft zuverlässiger als der OCR-/PDF-Text (Lohnprogramme
    benennen Dateien meist konsistent nach Person). Der komplette Text wird
    durchsucht (nicht nur der Anfang) — manche Abrechnungsformate haben sehr
    viel Kopfzeilen-/Legenden-Text, bevor der eigentliche Name auftaucht."""
    candidates = re.findall(r"[A-ZÄÖÜ][a-zäöüß]{2,}", filename or "")
    candidates += re.findall(r"[A-ZÄÖÜ][a-zäöüß]{2,}", text or "")
    return candidates


def parse_payslip(pdf_path: Path, password: Optional[str] = None) -> dict:
    text = extract_text(pdf_path, password)
    month = _extract_month(text) or _extract_month_from_filename(pdf_path.name)
    return {
        "raw_text": text,
        "net_amount": _extract_net_amount(text),
        "month": month,
        "employer": _extract_employer(text),
        "name_candidates": extract_name_candidates(text, pdf_path.name),
    }
