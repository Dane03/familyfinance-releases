"""
Family Finance — Backend
Läuft komplett lokal (127.0.0.1 / lokales Netzwerk), keine Cloud-Aufrufe.

Start:
    uvicorn app:app --host 0.0.0.0 --port 8420
"""
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional, List
import re
import json
import io
import hashlib

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Response, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from database import get_connection, init_db
from ocr import extract_receipt_data  # lokale OCR, siehe ocr.py
from chatbot import ask as ask_chatbot  # lokaler Chatbot über Ollama, siehe chatbot.py
from payslip_import import parse_payslip  # Gehaltsabrechnungs-Import, siehe payslip_import.py
from report import generate_report_pdf, generate_energy_report_pdf  # PDF-Export, siehe report.py
import meters  # Energy-Monitor-Berechnungslogik, siehe meters.py
import smart_import  # Intelligenter Datei-Import mit Ollama, siehe smart_import.py
import auth

BASE_DIR = Path(__file__).resolve().parent.parent
RECEIPTS_DIR = BASE_DIR / "data" / "receipts"
PAYSLIPS_DIR = BASE_DIR / "data" / "payslips"

# Monatsäquivalent-Formel, überall identisch verwendet (Betrag * Anteil, umgerechnet auf p.M.)
def monthly_expr(amount_col: str, freq_col: str, split_col: Optional[str] = None) -> str:
    amt = f"{amount_col}*{split_col}" if split_col else amount_col
    return (f"CASE {freq_col} WHEN 'monthly' THEN {amt} "
            f"WHEN 'quarterly' THEN {amt}/3.0 WHEN 'yearly' THEN {amt}/12.0 END")

app = FastAPI(title="Family Finance")

# CORS bewusst NICHT auf "*": Die App arbeitet mit Cookie-Authentifizierung,
# und eine Wildcard-Freigabe würde bedeuten, dass jede beliebige Webseite,
# die im selben Browser geöffnet ist, Anfragen an den lokalen Server stellen
# könnte. Da Frontend und Backend hier ohnehin vom selben Ursprung
# ausgeliefert werden, braucht es gar keine Fremd-Ursprünge — lediglich der
# eigene (z.B. Tailscale-Hostname) wird zugelassen.
_allowed_origins = [auth.ORIGIN] if getattr(auth, "ORIGIN", None) else []
app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Obergrenze für Uploads: ohne Limit könnte eine sehr große Datei den
# Arbeitsspeicher des kleinen Servers füllen, da die Uploads zum Verarbeiten
# komplett eingelesen werden (OCR, PDF-Parsing, Tabellen-Import).
MAX_UPLOAD_BYTES = 25 * 1024 * 1024   # 25 MB — für Einzel-Uploads (1 Datei)
MAX_BULK_UPLOAD_BYTES = 300 * 1024 * 1024  # 300 MB — für Mehrfach-Import (mehrere
    # Dateien auf einmal ist hier ja der ganze Zweck; das alte 25-MB-Limit galt
    # für den GESAMTEN Request und ließ schon 8-9 normal große gescannte PDFs
    # (je ~3 MB) fälschlich scheitern — für den Nutzer wirkte das wie ein
    # Aufhängen der App, da der Server mitten im Hochladen abbricht.


@app.middleware("http")
async def limit_upload_size(request: Request, call_next):
    content_length = request.headers.get("content-length")
    limit = MAX_BULK_UPLOAD_BYTES if "bulk-upload" in request.url.path else MAX_UPLOAD_BYTES
    if content_length and int(content_length) > limit:
        return JSONResponse(
            status_code=413,
            content={"detail": f"Dateien zusammen zu groß (max. {limit // (1024*1024)} MB)."},
        )
    return await call_next(request)


@app.on_event("startup")
def startup():
    init_db()
    RECEIPTS_DIR.mkdir(parents=True, exist_ok=True)
    # Automatisches Aufräumen alter Test-/vergessener Uploads bei jedem Start.
    # Bewusst mit einer Woche Mindestalter, damit ein gestern hochgeladener,
    # noch nicht bestätigter Beleg nicht versehentlich verschwindet.
    conn = get_connection()
    _cleanup_unconfirmed_receipts(conn, max_age_hours=24 * 7)
    conn.close()

    # Ebenso für nie bestätigte intelligente Datei-Importe (analysiert, aber
    # nie mit "Import starten" abgeschlossen) — sonst sammeln sich in
    # data/smart_import_staging/ auf Dauer verwaiste Dateien an.
    import time
    staging_dir = BASE_DIR / "data" / "smart_import_staging"
    if staging_dir.exists():
        cutoff = time.time() - 24 * 3600
        for f in staging_dir.iterdir():
            if f.is_file() and f.stat().st_mtime < cutoff:
                f.unlink()

    _migrate_receipts_person_separation_once()

    import maintenance
    maintenance.backup_database()
    save_networth_snapshot()
    _start_recurring_weather_refresh()


def _start_recurring_weather_refresh():
    """Der Server läuft typischerweise wochenlang durchgehend (launchd hält
    ihn am Leben) — ein reiner Start-Trigger würde also praktisch nie
    erneut greifen, sobald der Rechner einmal länger nicht neu gestartet
    wurde. Deshalb ein dauerhaft laufender Hintergrund-Thread statt nur
    ein einmaliger Aufruf beim Start; die eigentliche Tages-Begrenzung
    steckt bereits in _refresh_actual_temperatures_if_due() selbst, ein
    Aufwachen alle paar Stunden ist also unkritisch, nicht "zu oft"."""
    import threading
    import time as _time

    def _loop():
        while True:
            try:
                _refresh_actual_temperatures_if_due()
            except Exception:
                pass  # ein Fehlschlag hier darf den Hintergrund-Thread nie beenden
            _time.sleep(6 * 3600)  # alle 6 Stunden erneut pruefen (nicht "erneut abrufen" -- die Tages-Sperre entscheidet das)

    threading.Thread(target=_loop, daemon=True).start()


# ---------- Pydantic-Modelle für Schreibzugriffe ----------

class ContractIn(BaseModel):
    label: Optional[str] = ""
    provider: Optional[str] = None
    contract_number: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    amount: float
    frequency: str = "monthly"
    payment_method: Optional[str] = None
    contract_end: Optional[date] = None
    notice_period_days: Optional[int] = None
    auto_renews: bool = True
    note: Optional[str] = None
    person_id: Optional[int] = None
    interest_rate: Optional[float] = None
    remaining_debt: Optional[float] = None
    repayment_rate: Optional[float] = None
    fixed_interest_until: Optional[date] = None
    insurance_type: Optional[str] = None
    insurance_expiry: Optional[date] = None
    insurance_sum: Optional[float] = None
    insurance_sum_type: Optional[str] = None
    bu_monthly_pension: Optional[float] = None


class ContractPatch(BaseModel):
    """Für manuelle Korrekturen — nur gesetzte Felder werden geändert.
    Bleibt so lange gültig, bis ein neues Update (Foto/Import) den Wert überschreibt."""
    label: Optional[str] = None
    provider: Optional[str] = None
    contract_number: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    amount: Optional[float] = None
    frequency: Optional[str] = None
    payment_method: Optional[str] = None
    contract_end: Optional[date] = None
    notice_period_days: Optional[int] = None
    auto_renews: Optional[bool] = None
    status: Optional[str] = None
    link: Optional[str] = None
    sort_order: Optional[int] = None
    note: Optional[str] = None
    person_id: Optional[int] = None
    interest_rate: Optional[float] = None
    remaining_debt: Optional[float] = None
    repayment_rate: Optional[float] = None
    fixed_interest_until: Optional[date] = None
    insurance_type: Optional[str] = None
    insurance_expiry: Optional[date] = None
    insurance_sum: Optional[float] = None
    insurance_sum_type: Optional[str] = None
    bu_monthly_pension: Optional[float] = None


class FamilyMemberIn(BaseModel):
    name: str
    role: str = "kind"           # 'elternteil' | 'kind'
    birth_date: Optional[date] = None


class FamilyMemberPatch(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None
    birth_date: Optional[date] = None
    sort_order: Optional[int] = None
    freistellungsauftrag_used: Optional[float] = None
    sv_nummer: Optional[str] = None
    steuer_id: Optional[str] = None
    steuerklasse: Optional[str] = None
    krankenkasse: Optional[str] = None
    etin: Optional[str] = None
    steuernummer: Optional[str] = None
    finanzamt: Optional[str] = None


class IncomeIn(BaseModel):
    label: str
    category: Optional[str] = None
    amount: float
    frequency: str = "monthly"
    person_id: Optional[int] = None


class IncomePatch(BaseModel):
    label: Optional[str] = None
    category: Optional[str] = None
    amount: Optional[float] = None
    frequency: Optional[str] = None
    active: Optional[bool] = None
    sort_order: Optional[int] = None
    person_id: Optional[int] = None


# ---------- Login: Passwort + Passkey (2FA) ----------

class SetupIn(BaseModel):
    username: str
    password: str


class LoginIn(BaseModel):
    username: str
    password: str


class PasskeyRegisterIn(BaseModel):
    credential: dict
    label: str = "Passkey"


class PasskeyLoginIn(BaseModel):
    credential: dict


@app.get("/api/auth/status")
def auth_status(request: Request):
    session = None
    try:
        session = auth.require_full_auth(request)
    except HTTPException:
        pass
    return {
        "setup_required": not auth.user_exists(),
        "passkey_registered": auth.has_passkey(request),
        "totp_registered": auth.has_totp(),
        "authenticated": session is not None,
    }


@app.post("/api/auth/setup")
def setup(payload: SetupIn, response: Response, request: Request):
    """Einmalig beim allerersten Start: legt den einen Familien-Zugang an."""
    auth.create_user(payload.username, payload.password)
    auth.issue_session(response, stage="password_ok", request=request)
    return {"status": "created", "next": "passkey_registration"}


@app.post("/api/auth/login")
def login(payload: LoginIn, response: Response, request: Request):
    auth.check_login_allowed(request)
    if not auth.verify_password(payload.username, payload.password):
        auth.register_failed_login(request)
        raise HTTPException(401, "Benutzername oder Passwort falsch.")
    auth.reset_failed_logins(request)
    auth.issue_session(response, stage="password_ok", request=request)
    return {"status": "password_ok", "next": "passkey"}


@app.post("/api/auth/logout")
def logout(response: Response):
    auth.clear_session(response)
    return {"status": "logged_out"}


@app.post("/api/auth/totp/setup/begin")
def totp_setup_begin(session=Depends(auth.require_password_stage)):
    """Kann sowohl direkt nach der Ersteinrichtung (als Alternative zum
    Passkey) als auch später aus den Einstellungen heraus aufgerufen werden
    (dort ist die Sitzung ohnehin schon 'full')."""
    return auth.begin_totp_setup()


class TotpSetupCompleteIn(BaseModel):
    secret: str
    code: str


@app.post("/api/auth/totp/setup/complete")
def totp_setup_complete(payload: TotpSetupCompleteIn, response: Response,
                         session=Depends(auth.require_password_stage)):
    if not auth.complete_totp_setup(payload.secret, payload.code):
        raise HTTPException(400, "Code stimmt nicht überein — bitte erneut versuchen.")
    auth.issue_session(response, stage="full")  # direkt vollständig eingeloggt, wie beim Passkey
    return {"status": "ok"}


class TotpLoginIn(BaseModel):
    code: str


@app.post("/api/auth/totp/login")
def totp_login(payload: TotpLoginIn, response: Response, session=Depends(auth.require_password_stage)):
    if not auth.verify_totp_code(payload.code):
        raise HTTPException(401, "Code falsch oder abgelaufen.")
    auth.issue_session(response, stage="full")
    return {"status": "full"}


@app.post("/api/auth/totp/disable")
def totp_disable(session=Depends(auth.require_full_auth)):
    """Nur aus den Einstellungen heraus (volle Anmeldung nötig) -- nicht
    während des Logins, sonst könnte sich jemand mit nur dem Passwort selbst
    den zweiten Faktor abschalten."""
    auth.disable_totp()
    return {"status": "disabled"}


@app.get("/api/auth/totp/qr")
def totp_qr(secret: str, session=Depends(auth.require_password_stage)):
    """Erzeugt den QR-Code lokal auf dem Server statt über einen externen
    QR-Code-Dienst -- das TOTP-Geheimnis (otpauth://-URL) verlässt damit nie
    den eigenen Rechner, auch nicht in Form einer Anfrage an eine fremde
    QR-Generierungs-API."""
    import pyotp
    import qrcode
    import io
    conn = get_connection()
    row = conn.execute("SELECT username FROM app_user WHERE id=1").fetchone()
    conn.close()
    username = row["username"] if row else "Family Finance"
    otpauth_url = pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name="Family Finance")
    img = qrcode.make(otpauth_url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")


@app.post("/api/auth/passkey/register/begin")
def passkey_register_begin(request: Request, session=Depends(auth.require_password_stage)):
    return auth.begin_passkey_registration(username="Familie", request=request)


@app.post("/api/auth/passkey/register/complete")
def passkey_register_complete(payload: PasskeyRegisterIn, response: Response, request: Request,
                               session=Depends(auth.require_password_stage)):
    import json
    result = auth.complete_passkey_registration(json.dumps(payload.credential), payload.label,
                                                 request=request)
    auth.issue_session(response, stage="full", request=request)  # direkt vollständig eingeloggt
    return result


@app.post("/api/auth/passkey/login/begin")
def passkey_login_begin(request: Request, session=Depends(auth.require_password_stage)):
    return auth.begin_passkey_login(request=request)


@app.post("/api/auth/passkey/login/complete")
def passkey_login_complete(payload: PasskeyLoginIn, response: Response, request: Request,
                            session=Depends(auth.require_password_stage)):
    import json
    auth.complete_passkey_login(json.dumps(payload.credential), request=request)
    auth.issue_session(response, stage="full", request=request)
    return {"status": "full"}


# ---------- Übersicht / Dashboard ----------

def _compute_health_check(monthly_income: float, fixed_expenses: float, savings: float,
                           by_category: list) -> list:
    """Bewertet die aktuelle Finanzverteilung anhand verbreiteter, recherchierter
    Faustregeln (Stand 2026). Jede Regel ist bewusst als grobe Orientierung zu
    verstehen, nicht als individuelle Finanzberatung — das wird auch im
    Frontend so kommuniziert.

    Quellen der Richtwerte:
    - Sparquote 10–20 % empfohlen (u.a. Verbraucherzentrale-Modelle, diverse
      Finanzratgeber); Ø Deutschland 2024/25 lag bei rund 10–11 %.
    - Wohnkostenquote: 30-Prozent-Mietregel (Warmmiete/Finanzierung ≤ 30 % des
      Nettoeinkommens), 40 % gilt verbreitet als Schmerzgrenze.
    - 50-30-20-Regel (Elizabeth Warren): 50 % Grundbedürfnisse, 30 % Wünsche,
      20 % Sparen — hier vereinfacht als "max. 80 % Fixkosten ohne Sparen".

    Bewusst nicht enthalten: ein Notgroschen-Check — die App kennt keine
    tatsächlichen Kontostände, nur monatliche Zahlungsströme, und könnte eine
    vorhandene Rücklage daher nicht seriös bewerten.
    """
    if monthly_income <= 0:
        return []

    def fmt_eur_short(v: float) -> str:
        return f"{v:.0f} €"

    checks = []

    # 1) Sparquote
    savings_rate = (savings / monthly_income) * 100
    if savings_rate >= 20:
        status = "green"
    elif savings_rate >= 10:
        status = "yellow"
    else:
        status = "red"
    checks.append({
        "id": "sparquote",
        "title": "Sparquote",
        "value_label": f"{savings_rate:.0f} %",
        "status": status,
        "target_label": "Empfohlen: 10–20 %, ideal ≥ 20 %",
        "message": (
            f"Ihr spart aktuell {savings_rate:.0f} % des Nettoeinkommens. "
            + ("Das liegt über dem empfohlenen Richtwert — starke Basis für Rücklagen und Vorsorge."
               if status == "green" else
               "Das liegt im empfohlenen Korridor, nach oben wäre noch Luft."
               if status == "yellow" else
               "Das liegt unter dem verbreitet empfohlenen Mindestwert von 10 %.")
        ),
    })

    # 2) Wohnkostenquote — NUR reine Wohnkosten (Nebenkosten, Versicherung o.ä.),
    #    OHNE Finanzierung/Tilgung. Die 30-Prozent-Faustregel stammt aus dem
    #    Mietkontext: bei Miete ist die Zahlung ein reiner Verbrauch ohne
    #    Gegenwert. Eine Finanzierungsrate fürs eigene Haus ist das nicht — ein
    #    Teil davon ist Tilgung, also Vermögensaufbau (das Haus gehört einem
    #    ja am Ende). Beides in einen Topf zu werfen würde die Quote künstlich
    #    aufblähen und so tun, als sei Eigentum finanziell "schlechter" als
    #    Miete, obwohl das Gegenteil der Fall sein kann.
    haus_rows = [row for row in by_category if row["category"] == "Haus" and row["monthly_amount"]]
    financing_cost = sum(
        row["monthly_amount"] for row in haus_rows if (row["subcategory"] or "") == "Finanzierung"
    )
    housing_cost = sum(
        row["monthly_amount"] for row in haus_rows if (row["subcategory"] or "") != "Finanzierung"
    )
    if housing_cost > 0:
        housing_rate = (housing_cost / monthly_income) * 100
        if housing_rate <= 30:
            status = "green"
        elif housing_rate <= 40:
            status = "yellow"
        else:
            status = "red"
        checks.append({
            "id": "wohnkosten",
            "title": "Wohnkostenquote",
            "value_label": f"{housing_rate:.0f} %",
            "status": status,
            "target_label": "Faustregel: ≤ 30 %, Schmerzgrenze ~40 % (ohne Finanzierung/Tilgung)",
            "message": (
                f"Reine Wohnkosten (Nebenkosten, Versicherung o.ä. — ohne Finanzierung) "
                f"machen {housing_rate:.0f} % des Nettoeinkommens aus. "
                + ("Das liegt innerhalb der klassischen 30-Prozent-Regel."
                   if status == "green" else
                   "Das liegt über der 30-Prozent-Regel, aber noch unter der Schmerzgrenze — "
                   "in vielen Ballungsräumen inzwischen normal."
                   if status == "yellow" else
                   "Das liegt über der verbreiteten Schmerzgrenze von ~40 % — wenig Puffer für "
                   "andere Ausgaben und Rücklagen.")
                + (f" Die Finanzierungsrate ({fmt_eur_short(financing_cost)}/Mo) ist bewusst "
                   "nicht mit eingerechnet, da sie überwiegend Vermögensaufbau ist, kein reiner "
                   "Verbrauch." if financing_cost > 0 else "")
            ),
        })

    # 2b) Finanzierung/Tilgung separat als Vermögensaufbau ausweisen, statt sie
    #     wie einen "Kostenfaktor" gegen eine Ausgaben-Regel zu bewerten.
    if financing_cost > 0:
        financing_rate = (financing_cost / monthly_income) * 100
        checks.append({
            "id": "finanzierung",
            "title": "Finanzierung (Vermögensaufbau)",
            "value_label": f"{financing_rate:.0f} %",
            "status": "green",
            "target_label": "Kein Richtwert — fließt ins eigene Vermögen, keine Ausgabe im klassischen Sinn",
            "message": (
                f"{financing_rate:.0f} % des Nettoeinkommens ({fmt_eur_short(financing_cost)}/Mo) "
                f"fließen in die Immobilienfinanzierung. Anders als Miete ist das größtenteils "
                f"Tilgung — das Geld bleibt im eigenen Vermögen, nur eben gebunden im Haus statt "
                f"auf dem Konto."
            ),
        })

    # 3) Fixkosten-Quote gesamt (alles außer Sparen), angelehnt an die
    #    50-30-20-Regel: 20 % sollten fürs Sparen übrig bleiben.
    fixed_rate = (fixed_expenses / monthly_income) * 100
    if fixed_rate <= 80:
        status = "green"
    elif fixed_rate <= 95:
        status = "yellow"
    else:
        status = "red"
    checks.append({
        "id": "fixkosten",
        "title": "Fixkosten-Quote",
        "value_label": f"{fixed_rate:.0f} %",
        "status": status,
        "target_label": "Angelehnt an die 50-30-20-Regel: ≤ 80 % (Rest fürs Sparen)",
        "message": (
            f"Alle Ausgaben außer Sparen zusammen machen {fixed_rate:.0f} % des "
            f"Nettoeinkommens aus. "
            + ("Genug Spielraum bleibt fürs Sparen und Unvorhergesehenes."
               if status == "green" else
               "Der Spielraum fürs Sparen wird knapp."
               if status == "yellow" else
               "Kaum bis kein Spielraum mehr übrig — das Einkommen ist nahezu komplett verplant.")
        ),
    })

    return checks


@app.get("/api/dashboard")
def dashboard(session=Depends(auth.require_full_auth)):
    conn = get_connection()

    monthly_income = conn.execute(
        f"SELECT COALESCE(SUM({monthly_expr('amount', 'frequency')}),0) AS v "
        f"FROM income WHERE active=1"
    ).fetchone()["v"]

    # Alle aktiven Fixkosten außer "Sparen" — das ist der klassische
    # "Überschuss nach Fixkosten" wie in deiner bisherigen Excel.
    fixed_expenses = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND (c.name IS NULL OR c.name != 'Sparen')"""
    ).fetchone()["v"]

    savings = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND c.name = 'Sparen'"""
    ).fetchone()["v"]

    surplus_after_fixed = monthly_income - fixed_expenses
    surplus_after_savings = surplus_after_fixed - savings

    by_category = conn.execute(
        f"""SELECT c.name AS category, co.subcategory,
                   SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}) AS monthly_amount
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active'
            GROUP BY c.name, co.subcategory ORDER BY monthly_amount DESC"""
    ).fetchall()

    income_rows = conn.execute(
        f"""SELECT id, label, amount, frequency, active, source, updated_at,
                   {monthly_expr('amount', 'frequency')} AS monthly_amount
            FROM income ORDER BY active DESC, sort_order, label"""
    ).fetchall()

    upcoming = conn.execute(
        """SELECT r.trigger_date, r.reminder_type, r.message, c.label
           FROM reminders r JOIN contracts c ON c.id = r.contract_id
           WHERE r.sent=0 AND r.trigger_date <= date('now', '+28 days')
           ORDER BY r.trigger_date ASC LIMIT 20"""
    ).fetchall()

    conn.close()

    health_check = _compute_health_check(monthly_income, fixed_expenses, savings, by_category)

    return {
        "monthly_income": round(monthly_income, 2),
        "monthly_fixed_expenses": round(fixed_expenses, 2),
        "monthly_savings": round(savings, 2),
        "surplus_after_fixed_costs": round(surplus_after_fixed, 2),
        "surplus_after_savings": round(surplus_after_savings, 2),
        "by_category": [dict(r) for r in by_category],
        "income": [dict(r) for r in income_rows],
        "upcoming_reminders": [dict(r) for r in upcoming],
        "health_check": health_check,
    }


def _sync_reminders(conn, contract_id: int):
    """(Neu) erzeugt die Fälligkeits-Erinnerungen für einen Vertrag, abhängig von
    contract_end/notice_period_days. Bei Haus-Finanzierungen (Baufinanzierung)
    wird die Formulierung passend auf Zinsbindung/Anschlussfinanzierung
    angepasst statt generisch von "Kündigung" zu sprechen. Wird sowohl beim
    Anlegen als auch bei jeder manuellen Korrektur der Termine aufgerufen,
    damit Nachpflegen bestehender (importierter) Verträge genauso Erinnerungen
    erzeugt wie das Neuanlegen."""
    row = conn.execute(
        """SELECT co.label, co.contract_end, co.notice_period_days, co.subcategory,
                  c.name AS category_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.id = ?""",
        (contract_id,),
    ).fetchone()
    if not row:
        return

    # Alte, noch nicht verschickte Erinnerungen für diesen Vertrag verwerfen und neu aufbauen
    conn.execute("DELETE FROM reminders WHERE contract_id=? AND sent=0", (contract_id,))

    if not row["contract_end"]:
        return

    is_financing = row["category_name"] == "Haus" and row["subcategory"] == "Finanzierung"
    contract_end = row["contract_end"]

    if is_financing:
        end_message = f"Zinsbindung von '{row['label']}' endet am {contract_end} — Anschlussfinanzierung nötig."
        notice_message_tpl = (
            f"Jetzt Angebote für die Anschlussfinanzierung von '{row['label']}' vergleichen "
            f"(Zinsbindungsende: {contract_end})."
        )
    else:
        end_message = f"Vertrag '{row['label']}' läuft am {contract_end} aus."
        notice_message_tpl = f"Kündigungsfrist für '{row['label']}' beginnt bald — Laufzeitende: {contract_end}."

    conn.execute(
        "INSERT INTO reminders (contract_id, reminder_type, trigger_date, message) VALUES (?,?,?,?)",
        (contract_id, "contract_end", contract_end, end_message),
    )

    if row["notice_period_days"]:
        notice_date = (date.fromisoformat(contract_end) - timedelta(days=row["notice_period_days"])).isoformat()
        conn.execute(
            "INSERT INTO reminders (contract_id, reminder_type, trigger_date, message) VALUES (?,?,?,?)",
            (contract_id, "notice_period", notice_date, notice_message_tpl),
        )


# ---------- Einstellungen (z.B. manuelle Reihenfolge der Dashboard-Blöcke) ----------

@app.get("/manifest.json")
def dynamic_manifest():
    """Wird dynamisch statt als statische Datei ausgeliefert, damit das
    PWA-Icon zum zuletzt gewählten Theme passt -- ein Betriebssystem liest
    das Manifest nur beim (Neu-)Installieren zum Homescreen, ein späterer
    Theme-Wechsel ändert ein bereits installiertes Icon technisch nicht
    rückwirkend, aber eine Neuinstallation zeigt dann das passende Icon."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='ui_theme'").fetchone()
    conn.close()
    theme = json.loads(row["value"]) if row else "dark"
    if theme not in ("dark", "light", "apple", "nothing", "retro80s"):
        theme = "dark"
    bg_colors = {"dark": "#0f172a", "light": "#f2f2f7", "apple": "#eef1f6", "nothing": "#000000", "retro80s": "#170821"}
    manifest = {
        "name": "Family Finance",
        "short_name": "Finance",
        "start_url": "/",
        "display": "standalone",
        "background_color": bg_colors[theme],
        "theme_color": bg_colors[theme],
        "icons": [
            {"src": f"/icons/icon-{theme}.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any maskable"},
            {"src": f"/icons/icon-{theme}-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
            {"src": f"/icons/icon-{theme}-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"},
        ],
    }
    return JSONResponse(content=manifest)


@app.get("/api/settings/{key}")
def get_setting(key: str, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return {"key": key, "value": json.loads(row["value"]) if row else None}


class SettingIn(BaseModel):
    value: object


@app.put("/api/settings/{key}")
def put_setting(key: str, payload: SettingIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, json.dumps(payload.value)),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


# ---------- PDF-Report-Export ----------

@app.get("/api/report/pdf")
def download_report(session=Depends(auth.require_full_auth)):
    pdf_bytes = generate_report_pdf()
    filename = f"Finanzreport_{datetime.now().strftime('%Y-%m-%d')}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/report/energy-pdf")
def download_energy_report(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    has_data = conn.execute("SELECT 1 FROM meter_readings LIMIT 1").fetchone() is not None
    conn.close()
    if not has_data:
        raise HTTPException(400, "Noch keine Zählerstände erfasst — Report kann noch nicht erstellt werden.")
    pdf_bytes = generate_energy_report_pdf()
    filename = f"Energy-Monitor-Report_{datetime.now().strftime('%Y-%m-%d')}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---------- Kategorien ----------

@app.get("/api/categories")
def list_categories(session=Depends(auth.require_full_auth)):
    from categorize import CATEGORIES
    conn = get_connection()
    db_names = {r["name"] for r in conn.execute("SELECT name FROM categories").fetchall()}
    conn.close()
    all_names = set(CATEGORIES) | db_names
    return sorted(all_names, key=lambda s: s.lower())


# ---------- Familienmitglieder (Stammdaten für Vorsorge/Risikoabsicherung) ----------

@app.get("/api/family-members")
def list_family_members(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM family_members ORDER BY sort_order, name"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/family-members")
def create_family_member(payload: FamilyMemberIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM family_members WHERE name=?", (payload.name,)).fetchone()
    if existing:
        conn.close()
        raise HTTPException(400, "Dieser Name ist schon als Familienmitglied angelegt.")
    max_order = conn.execute("SELECT COALESCE(MAX(sort_order),-1) AS m FROM family_members").fetchone()["m"]
    cur = conn.execute(
        "INSERT INTO family_members (name, role, birth_date, sort_order) VALUES (?,?,?,?)",
        (payload.name, payload.role, payload.birth_date, max_order + 1),
    )
    conn.commit()
    fid = cur.lastrowid
    conn.close()
    return {"id": fid, "status": "created"}


@app.patch("/api/family-members/{member_id}")
def update_family_member(member_id: int, patch: FamilyMemberPatch, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM family_members WHERE id=?", (member_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Familienmitglied nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    if not fields:
        conn.close()
        return {"status": "unchanged"}
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE family_members SET {set_clause} WHERE id=?", (*fields.values(), member_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/family-members/{member_id}")
def delete_family_member(member_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM family_members WHERE id=?", (member_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Familienmitglied nicht gefunden")
    # Verträge/Rentenkonten, die auf diese Person zeigen, bleiben erhalten,
    # verlieren aber die Zuordnung — kein Fremdschlüssel-Fehler beim Löschen.
    conn.execute("UPDATE contracts SET person_id=NULL WHERE person_id=?", (member_id,))
    conn.execute("DELETE FROM family_members WHERE id=?", (member_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


# ---------- Vermögensübersicht: Konten, Depots, Immobilien, Sonstiges ----------

class AssetIn(BaseModel):
    type: str                       # 'konto' | 'immobilie' | 'depot' | 'sonstiges'
    label: str
    provider: Optional[str] = None
    account_number: Optional[str] = None
    account_type: Optional[str] = None   # nur für 'konto': 'giro' | 'tagesgeld' | 'festgeld'
    purpose: Optional[str] = None
    person_id: Optional[int] = None
    current_value: Optional[float] = None
    financing_contract_ids: Optional[List[int]] = None  # mehrere Darlehen möglich (Immobilie)
    note: Optional[str] = None


class AssetPatch(BaseModel):
    label: Optional[str] = None
    provider: Optional[str] = None
    account_number: Optional[str] = None
    account_type: Optional[str] = None
    purpose: Optional[str] = None
    person_id: Optional[int] = None
    current_value: Optional[float] = None
    financing_contract_ids: Optional[List[int]] = None
    note: Optional[str] = None


class AssetHoldingIn(BaseModel):
    isin: Optional[str] = None
    name: str
    current_value: float
    asset_class: Optional[str] = None   # 'aktie' | 'anleihe' | 'cash' | 'rohstoffe' | 'sonstiges'
    region: Optional[str] = None        # 'usa' | 'europa' | 'schwellenlaender' |
                                         # 'sonstige_industrielaender' | 'global' | 'sonstiges'


class AssetHoldingPatch(BaseModel):
    isin: Optional[str] = None
    name: Optional[str] = None
    current_value: Optional[float] = None
    asset_class: Optional[str] = None
    region: Optional[str] = None


def _set_asset_financing_links(conn, asset_id: int, contract_ids: List[int]):
    """Ersetzt die komplette Menge verknüpfter Finanzierungsverträge für
    eine Immobilie durch die übergebene Liste — einfacher und robuster als
    einzelne Verknüpfungen zeilenweise abzugleichen, bei der überschaubaren
    Anzahl an Darlehen pro Immobilie (in der Praxis 1-3)."""
    conn.execute("DELETE FROM asset_financing_links WHERE asset_id=?", (asset_id,))
    for cid in set(contract_ids or []):
        conn.execute(
            "INSERT OR IGNORE INTO asset_financing_links (asset_id, contract_id) VALUES (?,?)",
            (asset_id, cid),
        )


def _asset_financing_details(conn, asset_id: int) -> list:
    rows = conn.execute(
        """SELECT co.id, co.label, co.remaining_debt, co.interest_rate, co.repayment_rate, co.amount
           FROM asset_financing_links afl JOIN contracts co ON co.id = afl.contract_id
           WHERE afl.asset_id = ? AND co.status = 'active'""",
        (asset_id,),
    ).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/assets")
def list_assets(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        """SELECT a.*, fm.name AS person_name
           FROM assets a
           LEFT JOIN family_members fm ON fm.id = a.person_id
           ORDER BY a.type, a.label"""
    ).fetchall()
    result = []
    for r in rows:
        entry = dict(r)
        entry.pop("linked_contract_id", None)  # LEGACY-Feld, nicht mehr nach außen geben
        entry["financing_contracts"] = _asset_financing_details(conn, r["id"]) if r["type"] == "immobilie" else []
        result.append(entry)
    conn.close()
    return result


VALID_ACCOUNT_TYPES = {"giro", "tagesgeld", "festgeld"}


@app.post("/api/assets")
def create_asset(payload: AssetIn, session=Depends(auth.require_full_auth)):
    if payload.account_type and payload.account_type not in VALID_ACCOUNT_TYPES:
        raise HTTPException(400, f"Ungültige Kontoart: {payload.account_type}")
    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO assets (type, label, provider, account_number, account_type, purpose, person_id, current_value, note)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (payload.type, payload.label, payload.provider, payload.account_number, payload.account_type,
         payload.purpose, payload.person_id, payload.current_value, payload.note),
    )
    asset_id = cur.lastrowid
    if payload.financing_contract_ids is not None:
        _set_asset_financing_links(conn, asset_id, payload.financing_contract_ids)
    conn.commit()
    conn.close()
    return {"id": asset_id, "status": "created"}


@app.patch("/api/assets/{asset_id}")
def update_asset(asset_id: int, payload: AssetPatch, session=Depends(auth.require_full_auth)):
    if payload.account_type and payload.account_type not in VALID_ACCOUNT_TYPES:
        raise HTTPException(400, f"Ungültige Kontoart: {payload.account_type}")
    fields = {k: v for k, v in payload.dict(exclude_unset=True).items() if k != "financing_contract_ids"}
    conn = get_connection()
    existing = conn.execute("SELECT id FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")
    if fields:
        fields["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE assets SET {set_clause} WHERE id=?", (*fields.values(), asset_id))
    if payload.financing_contract_ids is not None:
        _set_asset_financing_links(conn, asset_id, payload.financing_contract_ids)
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/assets/{asset_id}")
def delete_asset(asset_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")
    conn.execute("DELETE FROM receipts WHERE asset_id=?", (asset_id,))
    conn.execute("DELETE FROM asset_financing_links WHERE asset_id=?", (asset_id,))
    conn.execute("DELETE FROM asset_holdings WHERE asset_id=?", (asset_id,))
    conn.execute("DELETE FROM assets WHERE id=?", (asset_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.get("/api/assets/{asset_id}/holdings")
def list_asset_holdings(asset_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM asset_holdings WHERE asset_id=? ORDER BY current_value DESC", (asset_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


VALID_ASSET_CLASSES = {"aktie", "anleihe", "cash", "rohstoffe", "sonstiges"}
VALID_REGIONS = {"usa", "europa", "schwellenlaender", "sonstige_industrielaender", "global", "sonstiges"}


def _validate_holding_class_region(asset_class: Optional[str], region: Optional[str]):
    """Unbekannte Werte fallen sonst stillschweigend in eine 'unbekannt'-
    Sammelkategorie bei der Allokations-Auswertung — ein Tippfehler bliebe
    unbemerkt statt eine klare Fehlermeldung zu bekommen."""
    if asset_class and asset_class not in VALID_ASSET_CLASSES:
        raise HTTPException(400, f"Ungültige Asset-Klasse: {asset_class}")
    if region and region not in VALID_REGIONS:
        raise HTTPException(400, f"Ungültige Region: {region}")


@app.post("/api/assets/{asset_id}/holdings")
def create_asset_holding(asset_id: int, payload: AssetHoldingIn, session=Depends(auth.require_full_auth)):
    _validate_holding_class_region(payload.asset_class, payload.region)
    conn = get_connection()
    asset = conn.execute("SELECT id FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not asset:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")
    cur = conn.execute(
        """INSERT INTO asset_holdings (asset_id, isin, name, current_value, asset_class, region)
           VALUES (?,?,?,?,?,?)""",
        (asset_id, payload.isin, payload.name, payload.current_value, payload.asset_class, payload.region),
    )
    conn.commit()
    holding_id = cur.lastrowid
    conn.close()
    return {"id": holding_id, "status": "created"}


@app.patch("/api/asset-holdings/{holding_id}")
def update_asset_holding(holding_id: int, payload: AssetHoldingPatch, session=Depends(auth.require_full_auth)):
    _validate_holding_class_region(payload.asset_class, payload.region)
    fields = {k: v for k, v in payload.dict(exclude_unset=True).items()}
    conn = get_connection()
    existing = conn.execute("SELECT id FROM asset_holdings WHERE id=?", (holding_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Position nicht gefunden")
    if fields:
        fields["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE asset_holdings SET {set_clause} WHERE id=?", (*fields.values(), holding_id))
        conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/asset-holdings/{holding_id}")
def delete_asset_holding(holding_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM asset_holdings WHERE id=?", (holding_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.get("/api/assets/{asset_id}/receipts")
def list_asset_receipts(asset_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT id, original_filename, uploaded_at, detected_amount, detected_date FROM receipts WHERE asset_id=? ORDER BY uploaded_at DESC",
        (asset_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/assets/{asset_id}/bulk-upload-receipts")
async def bulk_upload_asset_receipts(asset_id: int, files: List[UploadFile] = File(...),
                                      session=Depends(auth.require_full_auth)):
    """Mehrere Belege auf einmal zu einem Vermögenswert — für den initialen
    Import einer ganzen Kontoauszugs-/Depotauszugs-Historie. Aktualisiert
    NIE automatisch current_value, auch nicht durch die neueste Datei im
    Stapel — derselbe Grundsatz wie beim Gehalts- und Vertrags-Sammelimport."""
    conn = get_connection()
    asset = conn.execute("SELECT type, label FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not asset:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")

    final_dir = RECEIPTS_DIR / "_vermoegen" / re.sub(r"[^\w\-]", "_", asset["label"])
    final_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        existing = conn.execute(
            "SELECT id FROM receipts WHERE asset_id=? AND file_hash=?", (asset_id, file_hash)
        ).fetchone()
        if existing:
            results.append({"receipt_id": existing["id"], "filename": file.filename, "skipped": True})
            continue

        safe_name = re.sub(r"[^\w.\-]", "_", file.filename or "beleg")
        stored_path = final_dir / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{safe_name}"
        stored_path.write_bytes(content)

        cur = conn.execute(
            """INSERT INTO receipts (original_filename, stored_path, file_hash, asset_id, review_needed)
               VALUES (?,?,?,?,0)""",
            (file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash, asset_id),
        )
        results.append({"receipt_id": cur.lastrowid, "filename": file.filename, "skipped": False})

    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}


@app.post("/api/pension-accounts/{account_id}/bulk-upload-documents")
async def bulk_upload_pension_documents(account_id: int, files: List[UploadFile] = File(...),
                                         session=Depends(auth.require_full_auth)):
    """Mehrere Dokumente auf einmal zu einem Rentenkonto — z.B. mehrere
    Jahre an Renteninformationen auf einen Schlag nachtragen. Gleiches
    Prinzip wie beim Vermögenswerte-Sammelimport: Duplikate (gleicher
    Dateiinhalt, gleiches Rentenkonto) werden übersprungen, nie doppelt
    abgelegt."""
    conn = get_connection()
    account = conn.execute("SELECT id, label FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")

    PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        existing = conn.execute(
            "SELECT id FROM pension_documents WHERE pension_account_id=? AND file_hash=?",
            (account_id, file_hash),
        ).fetchone()
        if existing:
            results.append({"document_id": existing["id"], "filename": file.filename, "skipped": True})
            continue

        safe_name = re.sub(r"[^\w.-]", "_", file.filename or "dokument")[:80]
        stored_name = f"{account_id}_{file_hash[:10]}_{safe_name}"
        stored_path = PENSION_DOCS_DIR / stored_name
        stored_path.write_bytes(content)

        cur = conn.execute(
            "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
            (account_id, file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash),
        )
        results.append({"document_id": cur.lastrowid, "filename": file.filename, "skipped": False})

    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}


def _compute_networth_totals(conn) -> dict:
    """Berechnet nur die vier Kopfzahlen (liquid, pension_capital,
    immobilien_netto, gesamt) — bewusst eigenständige, leichtgewichtige
    Variante der Logik aus vermoegen_overview (ohne Gruppen, Holdings-
    Allokation, Projektion), für den täglichen Snapshot ohne den vollen
    Overhead und ohne die bereits getestete Haupt-Route anzufassen."""
    assets = conn.execute("SELECT * FROM assets").fetchall()
    pension_rows = conn.execute(
        "SELECT current_value FROM pension_accounts WHERE type='privat' AND current_value IS NOT NULL"
    ).fetchall()
    altersvorsorge_contracts = conn.execute(
        """SELECT co.amount FROM contracts co JOIN categories c ON c.id = co.category_id
           WHERE LOWER(c.name) = 'altersvorsorge' AND co.status = 'active'
           AND co.id NOT IN (SELECT linked_contract_id FROM pension_accounts WHERE linked_contract_id IS NOT NULL)"""
    ).fetchall()

    total_liquid = 0.0
    total_immobilien_brutto = 0.0
    total_immobilien_schulden = 0.0
    total_altersvorsorge_assets = 0.0

    for a in assets:
        if a["type"] == "immobilie":
            financing = conn.execute(
                """SELECT co.remaining_debt FROM asset_financing_links afl
                   JOIN contracts co ON co.id = afl.contract_id WHERE afl.asset_id=? AND co.status='active'""",
                (a["id"],),
            ).fetchall()
            total_immobilien_brutto += a["current_value"] or 0
            total_immobilien_schulden += sum(f["remaining_debt"] or 0 for f in financing)
        elif (a["purpose"] or "").lower() == "altersvorsorge":
            total_altersvorsorge_assets += a["current_value"] or 0
        else:
            total_liquid += a["current_value"] or 0

    pension_capital = (
        sum(p["current_value"] or 0 for p in pension_rows)
        + sum(c["amount"] or 0 for c in altersvorsorge_contracts)
        + total_altersvorsorge_assets
    )
    immobilien_netto = total_immobilien_brutto - total_immobilien_schulden
    total_networth = total_liquid + pension_capital + immobilien_netto
    return {
        "liquid": round(total_liquid, 2),
        "pension_capital": round(pension_capital, 2),
        "immobilien_netto": round(immobilien_netto, 2),
        "gesamt": round(total_networth, 2),
    }


def save_networth_snapshot():
    """Schreibt eine Momentaufnahme des Gesamtvermögens für den heutigen Tag
    — überschreibt einen eventuell bereits heute vorhandenen Eintrag statt
    Duplikate anzuhäufen (z.B. bei mehreren Neustarts am selben Tag)."""
    conn = get_connection()
    totals = _compute_networth_totals(conn)
    today = datetime.now().strftime("%Y-%m-%d")
    conn.execute(
        """INSERT INTO networth_snapshots (snapshot_date, total_networth, liquid, pension_capital, immobilien_netto)
           VALUES (?,?,?,?,?)
           ON CONFLICT(snapshot_date) DO UPDATE SET
             total_networth=excluded.total_networth, liquid=excluded.liquid,
             pension_capital=excluded.pension_capital, immobilien_netto=excluded.immobilien_netto""",
        (today, totals["gesamt"], totals["liquid"], totals["pension_capital"], totals["immobilien_netto"]),
    )
    conn.commit()
    conn.close()


class AllocationTargetIn(BaseModel):
    asset_class: str
    target_percent: float


@app.get("/api/vermoegen/allocation-targets")
def get_allocation_targets(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM allocation_targets").fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.put("/api/vermoegen/allocation-targets")
def set_allocation_targets(payload: List[AllocationTargetIn], session=Depends(auth.require_full_auth)):
    """Ersetzt die komplette Soll-Allokation auf einmal — einfacher als
    einzelne Werte abzugleichen, bei einer überschaubaren Anzahl Klassen."""
    conn = get_connection()
    conn.execute("DELETE FROM allocation_targets")
    for t in payload:
        conn.execute(
            "INSERT INTO allocation_targets (asset_class, target_percent) VALUES (?,?)",
            (t.asset_class, t.target_percent),
        )
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.get("/api/vermoegen/history")
def vermoegen_history(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT snapshot_date, total_networth, liquid, pension_capital, immobilien_netto "
        "FROM networth_snapshots ORDER BY snapshot_date ASC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


SPARERPAUSCHBETRAG_PRO_PERSON = 1000.0  # Stand 2026, unverändert seit 2023 (§ 20 Abs. 9 EStG)
RIESTER_GRUNDZULAGE = 175.0             # Stand 2026, unverändert seit 2018
RIESTER_KINDERZULAGE_PRO_KIND = 300.0   # für nach 2008 geborene Kinder


@app.get("/api/steuer/overview")
def steuer_overview(session=Depends(auth.require_full_auth)):
    """Freistellungsauftrag- und Riester-Förderungs-Übersicht. Bewusst
    einfach gehalten: kein Steuerberater-Ersatz, sondern eine grobe
    Orientierung anhand öffentlich bekannter Eckwerte (Stand 2026)."""
    conn = get_connection()
    members = conn.execute(
        "SELECT * FROM family_members WHERE role='elternteil' ORDER BY sort_order"
    ).fetchall()
    kids_count = conn.execute(
        "SELECT COUNT(*) AS n FROM family_members WHERE role='kind'"
    ).fetchone()["n"]

    freistellung = []
    for m in members:
        used = m["freistellungsauftrag_used"] or 0
        freistellung.append({
            "person_name": m["name"],
            "allowance": SPARERPAUSCHBETRAG_PRO_PERSON,
            "used": used,
            "remaining": round(SPARERPAUSCHBETRAG_PRO_PERSON - used, 2),
        })

    riester_accounts = conn.execute(
        """SELECT pa.id, pa.label, pa.provider, fm.name AS person_name
           FROM pension_accounts pa JOIN family_members fm ON fm.id = pa.person_id
           WHERE pa.is_riester = 1"""
    ).fetchall()
    conn.close()

    riester = [{
        "id": r["id"], "label": r["label"], "provider": r["provider"], "person_name": r["person_name"],
        "grundzulage": RIESTER_GRUNDZULAGE,
        "kinderzulage_max": round(kids_count * RIESTER_KINDERZULAGE_PRO_KIND, 2),
        "zulage_gesamt_max": round(RIESTER_GRUNDZULAGE + kids_count * RIESTER_KINDERZULAGE_PRO_KIND, 2),
    } for r in riester_accounts]

    return {
        "freistellungsauftrag": freistellung,
        "riester": riester,
        "riester_note": (
            "Die Kinderzulage fließt automatisch in den Vertrag des Elternteils, "
            "der das Kindergeld bezieht — hier als Maximalbetrag je Riester-Vertrag "
            "gezeigt, nicht automatisch einem Elternteil zugeordnet."
        ),
    }


@app.get("/api/vermoegen/overview")
def vermoegen_overview(session=Depends(auth.require_full_auth)):
    """Aggregiert Vermögenswerte aus mehreren, bereits bestehenden Quellen zu
    EINER Übersicht, statt Daten zu duplizieren:
    - assets (Konten, Depots, sonstige Anlagen, Immobilien) — hier neu erfasst
    - pension_accounts (Altersvorsorge) — bereits unter Vorsorge gepflegt,
      werden hier als EIGENE, sichtbare Einträge geführt (nicht nur als
      stille Summe). Nur die private (kapitalbildende) Vorsorge zählt als
      Vermögen; die gesetzliche Rente ist eine künftige Zahlung, kein heute
      verfügbares Kapital, und fließt daher bewusst NICHT ein.
    - Verträge unter Ausgaben mit Kategorie "Altersvorsorge" — z.B. ein
      Riester-Vertrag, der (noch) nicht formal mit einem Rentenkonto unter
      Vorsorge verknüpft ist. Bereits über pension_accounts.linked_contract_id
      verknüpfte Verträge werden hier ausgeschlossen, um sie nicht doppelt
      zu zählen (einmal über das Rentenkonto, einmal über den Vertrag selbst).
    - Finanzierungsverträge (contracts, subcategory='Finanzierung') — für
      das Netto-Immobilienvermögen (Immobilienwert − Restschuld). Eine
      Immobilie kann mit MEHREREN Verträgen verknüpft sein (z.B. Haupt-
      darlehen + KfW-Förderdarlehen) — deren Restschulden werden summiert.
    """
    conn = get_connection()

    assets = conn.execute(
        """SELECT a.*, fm.name AS person_name
           FROM assets a
           LEFT JOIN family_members fm ON fm.id = a.person_id
           ORDER BY a.type, a.label"""
    ).fetchall()

    pension_rows = conn.execute(
        "SELECT pa.id, pa.current_value, pa.label, pa.provider, pa.person_id, fm.name AS person_name "
        "FROM pension_accounts pa JOIN family_members fm ON fm.id = pa.person_id "
        "WHERE pa.type='privat' AND pa.current_value IS NOT NULL"
    ).fetchall()

    altersvorsorge_contracts = conn.execute(
        """SELECT co.id, co.label, co.provider, co.amount, fm.name AS person_name
           FROM contracts co
           JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE LOWER(c.name) = 'altersvorsorge' AND co.status = 'active'
           AND co.id NOT IN (
               SELECT linked_contract_id FROM pension_accounts WHERE linked_contract_id IS NOT NULL
           )"""
    ).fetchall()

    by_type = {"konto": [], "depot": [], "immobilie": [], "sonstiges": [], "altersvorsorge": []}
    total_liquid = 0.0
    total_immobilien_brutto = 0.0
    total_immobilien_schulden = 0.0
    total_altersvorsorge_assets = 0.0
    real_estate_items = []  # (asset_dict, [financing_contract_dict, ...])
    asset_ids_for_holdings = [a["id"] for a in assets]

    for a in assets:
        entry = dict(a)
        entry.pop("linked_contract_id", None)
        if a["type"] == "immobilie":
            financing = _asset_financing_details(conn, a["id"])
            total_debt = sum(f["remaining_debt"] or 0 for f in financing)
            value = a["current_value"] or 0
            entry["financing_contracts"] = financing
            entry["total_remaining_debt"] = round(total_debt, 2)
            entry["net_value"] = round(value - total_debt, 2)
            total_immobilien_brutto += value
            total_immobilien_schulden += total_debt
            real_estate_items.append((a, financing))
        elif (a["purpose"] or "").lower() == "altersvorsorge":
            # Ein Depot/Konto MIT dem Zweck Altersvorsorge zählt konzeptionell
            # als Altersvorsorge-Vermögen, nicht als generisches liquides
            # Vermögen — unabhängig vom technischen "type". Erscheint daher
            # NUR unter "altersvorsorge", nicht zusätzlich unter seinem
            # technischen Typ (sonst doppelte Anzeige). Der VOLLSTÄNDIGE
            # entry (nicht nur ein paar Felder) wird übernommen, da das
            # Bearbeiten-Formular u.a. "type" und "purpose" braucht.
            entry["source"] = "asset"
            total_altersvorsorge_assets += a["current_value"] or 0
            by_type["altersvorsorge"].append(entry)
            continue
        else:
            total_liquid += a["current_value"] or 0
        by_type.setdefault(a["type"], []).append(entry)

    for p in pension_rows:
        by_type["altersvorsorge"].append({
            "id": p["id"], "source": "pension_account", "label": p["label"],
            "provider": p["provider"], "person_name": p["person_name"], "person_id": p["person_id"],
            "current_value": p["current_value"],
        })
    for c in altersvorsorge_contracts:
        by_type["altersvorsorge"].append({
            "id": c["id"], "source": "contract", "label": c["label"],
            "provider": c["provider"], "person_name": c["person_name"],
            "current_value": c["amount"],
        })

    # Asset-Allokation: über ALLE Positionen (asset_holdings) aller Depots
    # hinweg, gewichtet nach ihrem jeweiligen Wert — unabhängig vom Zweck
    # des Depots, damit die Gesamt-Risikostreuung sichtbar wird.
    allocation_by_class = {}
    allocation_by_region = {}
    total_holdings_value = 0.0
    if asset_ids_for_holdings:
        placeholders = ",".join("?" for _ in asset_ids_for_holdings)
        holdings = conn.execute(
            f"SELECT * FROM asset_holdings WHERE asset_id IN ({placeholders})",
            asset_ids_for_holdings,
        ).fetchall()
        for h in holdings:
            value = h["current_value"] or 0
            total_holdings_value += value
            cls = h["asset_class"] or "unbekannt"
            reg = h["region"] or "unbekannt"
            allocation_by_class[cls] = allocation_by_class.get(cls, 0) + value
            allocation_by_region[reg] = allocation_by_region.get(reg, 0) + value

    # Soll-Allokation zum Abgleich mit der Ist-Verteilung.
    targets = {r["asset_class"]: r["target_percent"] for r in conn.execute("SELECT * FROM allocation_targets").fetchall()}

    # Kuchendiagramm über das GESAMTE Nettovermögen (nicht nur Depot-
    # Positionen) nach sieben Anlageklassen. "Sonstiges" wird bewusst als
    # Restgröße (Gesamt minus alle benannten Kategorien) berechnet statt
    # jede Restquelle einzeln aufzuzählen — so summieren sich die Anteile
    # garantiert immer exakt zum Gesamtvermögen, ohne Doppelzählungsrisiko.
    tagesgeld_total = sum(a["current_value"] or 0 for a in assets if a["type"] == "konto" and a["account_type"] == "tagesgeld")
    festgeld_total = sum(a["current_value"] or 0 for a in assets if a["type"] == "konto" and a["account_type"] == "festgeld")
    liquiditaet_total = sum(a["current_value"] or 0 for a in assets if a["type"] == "konto" and a["account_type"] not in ("tagesgeld", "festgeld"))
    aktien_total = allocation_by_class.get("aktie", 0)
    festverzinsliches_total = allocation_by_class.get("anleihe", 0)

    # Liquiditätsreserve: reichen die liquiden Mittel (Konten) für die
    # empfohlenen 3-6 Monatsausgaben? Nutzt dieselbe Fixkosten-Berechnung
    # wie das Dashboard (alle aktiven Ausgaben außer "Sparen").
    monthly_fixed_expenses = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND (c.name IS NULL OR c.name != 'Sparen')"""
    ).fetchone()["v"]
    total_konten = sum(a["current_value"] or 0 for a in assets if a["type"] == "konto")
    months_covered = round(total_konten / monthly_fixed_expenses, 1) if monthly_fixed_expenses else None

    conn.close()

    pension_capital = (
        sum(p["current_value"] or 0 for p in pension_rows)
        + sum(c["amount"] or 0 for c in altersvorsorge_contracts)
        + total_altersvorsorge_assets
    )
    total_immobilien_netto = total_immobilien_brutto - total_immobilien_schulden
    total_networth = total_liquid + pension_capital + total_immobilien_netto

    # Zukunftsprojektion Netto-Immobilienvermögen: Immobilienwert bleibt
    # laut ausdrücklicher Annahme konstant, die Restschuld folgt dem
    # bestehenden Tilgungsplan-Rechner, über alle verknüpften Verträge einer
    # Immobilie UND über alle Immobilien hinweg summiert — Kernidee des
    # ganzen Features ("Wert bleibt, Darlehen sinkt").
    projection = []
    if real_estate_items:
        from finanzierung import compute_repayment_schedule
        combined_by_year = {}
        for asset, financing in real_estate_items:
            property_value = asset["current_value"] or 0
            any_schedule = False
            for contract in financing:
                if not contract["remaining_debt"] or not contract["interest_rate"]:
                    continue
                result = compute_repayment_schedule(
                    remaining_debt=contract["remaining_debt"],
                    interest_rate=contract["interest_rate"],
                    monthly_payment=contract["amount"],
                    repayment_rate=contract["repayment_rate"],
                )
                if result["error"]:
                    continue
                any_schedule = True
                for point in result["schedule"]:
                    y = point["year"]
                    combined_by_year.setdefault(y, {"year": y, "debt": 0.0, "value": 0.0})
                    combined_by_year[y]["debt"] += point["remaining_debt"]
            if any_schedule:
                # Immobilienwert für jedes Jahr, in dem mindestens ein
                # verknüpfter Vertrag einen Tilgungsplan beisteuert, addieren
                # — unabhängig davon, wie viele Verträge es sind (der Wert
                # der Immobilie selbst zählt nur einmal pro Jahr).
                for y in combined_by_year:
                    combined_by_year[y]["value"] += property_value
        for y in sorted(combined_by_year):
            p = combined_by_year[y]
            projection.append({
                "year": y, "property_value": round(p["value"], 2),
                "remaining_debt": round(p["debt"], 2),
                "net_value": round(p["value"] - p["debt"], 2),
            })

    def _to_percent_list(d: dict, total: float) -> list:
        if total <= 0:
            return []
        return sorted(
            [{"key": k, "value": round(v, 2), "percent": round(v / total * 100, 1)} for k, v in d.items()],
            key=lambda x: -x["value"],
        )

    by_class_list = _to_percent_list(allocation_by_class, total_holdings_value)
    for item in by_class_list:
        if item["key"] in targets:
            item["target_percent"] = targets[item["key"]]
            item["deviation"] = round(item["percent"] - targets[item["key"]], 1)

    # Kuchendiagramm über das GESAMTE Nettovermögen (nicht nur Depot-
    # Positionen) nach sieben Anlageklassen. "Sonstiges" wird bewusst als
    # Restgröße (Gesamt minus alle benannten Kategorien) berechnet statt
    # jede Restquelle einzeln aufzuzählen — so summieren sich die Anteile
    # garantiert immer exakt zum Gesamtvermögen, ohne Doppelzählungsrisiko.
    named_pie_total = tagesgeld_total + festgeld_total + liquiditaet_total + aktien_total + festverzinsliches_total + total_immobilien_netto
    sonstiges_pie = max(total_networth - named_pie_total, 0)
    pie_allocation = _to_percent_list({
        "Aktien": aktien_total,
        "Festverzinsliches": festverzinsliches_total,
        "Immobilien": total_immobilien_netto,
        "Tagesgelder": tagesgeld_total,
        "Festgelder": festgeld_total,
        "Liquidität": liquiditaet_total,
        "Sonstiges": sonstiges_pie,
    }, total_networth) if total_networth > 0 else []

    return {
        "by_type": by_type,
        "totals": {
            "liquid": round(total_liquid, 2),
            "pension_capital": round(pension_capital, 2),
            "immobilien_brutto": round(total_immobilien_brutto, 2),
            "immobilien_schulden": round(total_immobilien_schulden, 2),
            "immobilien_netto": round(total_immobilien_netto, 2),
            "gesamt": round(total_networth, 2),
        },
        "pension_accounts": [dict(p) for p in pension_rows],
        "real_estate_projection": projection,
        "asset_allocation": {
            "total_value": round(total_holdings_value, 2),
            "by_class": by_class_list,
            "by_region": _to_percent_list(allocation_by_region, total_holdings_value),
            "targets_set": len(targets) > 0,
        },
        "pie_allocation": pie_allocation,
        "liquidity_reserve": {
            "total_konten": round(total_konten, 2),
            "monthly_fixed_expenses": round(monthly_fixed_expenses, 2),
            "months_covered": months_covered,
            # Gängige Faustregel: 3-6 Monatsausgaben als Reserve.
            "status": ("gut" if months_covered is not None and months_covered >= 3
                       else "niedrig" if months_covered is not None else "unbekannt"),
        },
    }


class PensionAccountIn(BaseModel):
    person_id: int
    type: str                       # 'gesetzlich' | 'privat'
    label: str
    provider: Optional[str] = None
    current_value: Optional[float] = None
    is_riester: Optional[bool] = False
    monthly_contribution: Optional[float] = None
    linked_contract_id: Optional[int] = None
    projected_monthly_at_67: Optional[float] = None
    disability_pension_monthly: Optional[float] = None
    return_rate_assumption: Optional[float] = None
    note: Optional[str] = None
    document_staging_id: Optional[str] = None
    document_original_filename: Optional[str] = None


class PensionAccountPatch(BaseModel):
    label: Optional[str] = None
    provider: Optional[str] = None
    current_value: Optional[float] = None
    is_riester: Optional[bool] = None
    monthly_contribution: Optional[float] = None
    linked_contract_id: Optional[int] = None
    projected_monthly_at_67: Optional[float] = None
    disability_pension_monthly: Optional[float] = None
    return_rate_assumption: Optional[float] = None
    note: Optional[str] = None


PENSION_DOCS_DIR = BASE_DIR / "data" / "pension_docs"


@app.post("/api/pension-accounts/analyze-document")
async def analyze_pension_document(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    """Liest einen hochgeladenen Beleg (Renteninformation, Depotauszug, ...)
    und schlägt einen monatlichen Rentenwert vor — VOR dem Anlegen eines
    Kontos, damit das Formular direkt vorausgefüllt werden kann. Der
    Vorschlag muss im Formular noch bestätigt werden, wird nie blind
    übernommen."""
    from ocr import extract_pension_document_data
    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    content = await file.read()
    ext = Path(file.filename or "dokument.pdf").suffix or ".pdf"
    staging_id = f"pension_{hashlib.sha256(content).hexdigest()[:16]}{ext}"
    staging_path = SMART_IMPORT_STAGING / staging_id
    staging_path.write_bytes(content)

    result = extract_pension_document_data(staging_path)
    return {
        "staging_id": staging_id,
        "original_filename": file.filename,
        "suggested_monthly_amount": result["suggested_monthly_amount"],
        "all_amounts_found": result["all_amounts_found"],
        "provider": result["provider"],
        "ocr_error": result["ocr_error"],
    }


def _attach_staged_pension_document(conn, account_id: int, staging_id: str, original_filename: Optional[str]):
    """Verschiebt eine per analyze-document zwischengespeicherte Datei zum
    fertig angelegten Rentenkonto — gleiche Idee wie beim Belege-Import:
    erst analysieren/anzeigen, dann erst nach Bestätigung endgültig ablegen.
    Fügt der Dokument-Zeitreihe einen neuen Eintrag hinzu, statt ein
    eventuell vorhandenes Dokument zu ersetzen."""
    if not re.match(r"^pension_[0-9a-f]{16}\.\w+$", staging_id):
        raise HTTPException(400, "Ungültige Zwischenspeicher-Kennung.")
    staging_path = SMART_IMPORT_STAGING / staging_id
    if not staging_path.exists():
        raise HTTPException(404, "Zwischengespeicherte Datei nicht gefunden — bitte erneut hochladen.")
    PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    content = staging_path.read_bytes()
    safe_name = re.sub(r"[^\w.-]", "_", original_filename or "dokument")[:80]
    stored_name = f"{account_id}_{staging_id[8:18]}_{safe_name}"
    stored_path = PENSION_DOCS_DIR / stored_name
    stored_path.write_bytes(content)
    staging_path.unlink(missing_ok=True)
    conn.execute(
        "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
        (account_id, original_filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest()),
    )


@app.get("/api/pension-accounts")
def list_pension_accounts(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        """SELECT pa.*, f.name AS person_name
           FROM pension_accounts pa JOIN family_members f ON f.id = pa.person_id
           ORDER BY f.sort_order, pa.type DESC, pa.label"""
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/pension-accounts")
def create_pension_account(payload: PensionAccountIn, session=Depends(auth.require_full_auth)):
    if payload.type not in ("gesetzlich", "privat"):
        raise HTTPException(400, "type muss 'gesetzlich' oder 'privat' sein.")
    conn = get_connection()
    person = conn.execute("SELECT id FROM family_members WHERE id=?", (payload.person_id,)).fetchone()
    if not person:
        conn.close()
        raise HTTPException(400, "Person nicht gefunden.")
    cur = conn.execute(
        """INSERT INTO pension_accounts
           (person_id, type, label, provider, current_value, is_riester, monthly_contribution, linked_contract_id,
            projected_monthly_at_67, disability_pension_monthly, return_rate_assumption, note)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (payload.person_id, payload.type, payload.label, payload.provider,
         payload.current_value, int(bool(payload.is_riester)), payload.monthly_contribution, payload.linked_contract_id,
         payload.projected_monthly_at_67,
         payload.disability_pension_monthly, payload.return_rate_assumption, payload.note),
    )
    pid = cur.lastrowid
    if payload.document_staging_id:
        _attach_staged_pension_document(conn, pid, payload.document_staging_id, payload.document_original_filename)
    conn.commit()
    conn.close()
    return {"id": pid, "status": "created"}


@app.patch("/api/pension-accounts/{account_id}")
def update_pension_account(account_id: int, patch: PensionAccountPatch,
                            session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    if not fields:
        conn.close()
        return {"status": "unchanged"}
    fields["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE pension_accounts SET {set_clause} WHERE id=?", (*fields.values(), account_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/pension-accounts/{account_id}")
def delete_pension_account(account_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")
    docs = conn.execute(
        "SELECT stored_path FROM pension_documents WHERE pension_account_id=?", (account_id,)
    ).fetchall()
    for d in docs:
        (BASE_DIR / d["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM pension_documents WHERE pension_account_id=?", (account_id,))
    conn.execute("DELETE FROM pension_accounts WHERE id=?", (account_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.post("/api/pension-accounts/{account_id}/document")
async def upload_pension_document(account_id: int, file: UploadFile = File(...),
                                   session=Depends(auth.require_full_auth)):
    """Fügt der Dokument-Zeitreihe dieses Rentenkontos einen neuen Eintrag
    hinzu (z.B. die jährliche Renteninformation) — ersetzt frühere
    Dokumente nicht, damit die Historie erhalten bleibt."""
    conn = get_connection()
    account = conn.execute("SELECT id FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")

    PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    content = await file.read()
    safe_name = re.sub(r"[^\w.-]", "_", file.filename or "dokument")[:80]
    stored_name = f"{account_id}_{hashlib.sha256(content).hexdigest()[:10]}_{safe_name}"
    stored_path = PENSION_DOCS_DIR / stored_name
    stored_path.write_bytes(content)

    cur = conn.execute(
        "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
        (account_id, file.filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest()),
    )
    conn.commit()
    conn.close()
    return {"status": "uploaded", "filename": file.filename, "id": cur.lastrowid}


@app.get("/api/pension-accounts/{account_id}/documents")
def list_pension_documents(account_id: int, session=Depends(auth.require_full_auth)):
    """Die volle Zeitreihe aller Dokumente zu diesem Rentenkonto. Ist das
    Konto mit einem Vertrag unter Ausgaben verknüpft, kommen die Belege
    von DORT (dieselbe Zeitreihe, kein doppeltes Hochladen nötig) statt
    aus einer eigenen pension_documents-Historie."""
    conn = get_connection()
    account = conn.execute(
        "SELECT linked_contract_id FROM pension_accounts WHERE id=?", (account_id,)
    ).fetchone()
    if account and account["linked_contract_id"]:
        rows = conn.execute(
            "SELECT id, original_filename, uploaded_at FROM receipts WHERE contract_id=? ORDER BY uploaded_at DESC",
            (account["linked_contract_id"],),
        ).fetchall()
        conn.close()
        return [{"id": r["id"], "original_filename": r["original_filename"],
                 "uploaded_at": r["uploaded_at"], "source": "contract"} for r in rows]

    rows = conn.execute(
        "SELECT id, original_filename, uploaded_at FROM pension_documents WHERE pension_account_id=? ORDER BY uploaded_at DESC",
        (account_id,),
    ).fetchall()
    conn.close()
    return [{**dict(r), "source": "pension"} for r in rows]


@app.get("/api/pension-documents/{document_id}")
def get_pension_document_by_id(document_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT * FROM pension_documents WHERE id=?", (document_id,)).fetchone()
    conn.close()
    if not doc:
        raise HTTPException(404, "Dokument nicht gefunden")
    file_path = BASE_DIR / doc["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Dokument-Datei fehlt auf der Festplatte")
    # Standardmäßig direkt im Browser anzeigen (inline) statt automatisch
    # herunterzuladen — ein Klick öffnete sonst nur einen leeren Tab, während
    # die Datei im Hintergrund heruntergeladen wurde. Download bewusst als
    # separate Option (?download=true), nicht als Standardverhalten.
    return FileResponse(
        file_path, filename=doc["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


@app.delete("/api/pension-documents/{document_id}")
def delete_pension_document(document_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT stored_path FROM pension_documents WHERE id=?", (document_id,)).fetchone()
    if not doc:
        conn.close()
        raise HTTPException(404, "Dokument nicht gefunden")
    (BASE_DIR / doc["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM pension_documents WHERE id=?", (document_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


PERSON_DOCS_DIR = BASE_DIR / "data" / "person_docs"


@app.post("/api/family-members/{person_id}/documents")
async def upload_person_document(person_id: int, file: UploadFile = File(...),
                                  session=Depends(auth.require_full_auth)):
    """Dokument zu einer Person (z.B. Sozialversicherungsausweis,
    Lohnsteuerbescheinigung) — fügt der Historie hinzu, ersetzt frühere
    Dokumente nicht."""
    conn = get_connection()
    person = conn.execute("SELECT id FROM family_members WHERE id=?", (person_id,)).fetchone()
    if not person:
        conn.close()
        raise HTTPException(404, "Person nicht gefunden")

    PERSON_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    content = await file.read()
    safe_name = re.sub(r"[^\w.-]", "_", file.filename or "dokument")[:80]
    stored_name = f"{person_id}_{hashlib.sha256(content).hexdigest()[:10]}_{safe_name}"
    stored_path = PERSON_DOCS_DIR / stored_name
    stored_path.write_bytes(content)

    cur = conn.execute(
        "INSERT INTO person_documents (person_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
        (person_id, file.filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest()),
    )
    conn.commit()
    conn.close()
    return {"status": "uploaded", "filename": file.filename, "id": cur.lastrowid}


@app.get("/api/family-members/{person_id}/documents")
def list_person_documents(person_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT id, original_filename, uploaded_at FROM person_documents WHERE person_id=? ORDER BY uploaded_at DESC",
        (person_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/api/person-documents/{document_id}")
def get_person_document_by_id(document_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT * FROM person_documents WHERE id=?", (document_id,)).fetchone()
    conn.close()
    if not doc:
        raise HTTPException(404, "Dokument nicht gefunden")
    file_path = BASE_DIR / doc["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Dokument-Datei fehlt auf der Festplatte")
    return FileResponse(
        file_path, filename=doc["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


@app.delete("/api/person-documents/{document_id}")
def delete_person_document(document_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT stored_path FROM person_documents WHERE id=?", (document_id,)).fetchone()
    if not doc:
        conn.close()
        raise HTTPException(404, "Dokument nicht gefunden")
    (BASE_DIR / doc["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM person_documents WHERE id=?", (document_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.get("/api/vorsorge/risiko")
def vorsorge_risiko_overview(session=Depends(auth.require_full_auth)):
    """Übersicht aller Versicherungen, gruppiert nach Typ, mit Sollbereichen
    (nicht nur Ampel) — siehe vorsorge.py für die Faustregeln und deren
    Quellen. Bezieht dabei Daten von anderen Seiten der App mit ein: Anzahl
    Kinder im Haushalt (Familienmitglieder) und eine laufende
    Immobilienfinanzierung (Ausgaben), da beides den Absicherungsbedarf
    erhöht."""
    from vorsorge import compute_bu_assessment, compute_rlv_assessment, compute_bu_em_combination
    conn = get_connection()
    contracts = conn.execute(
        """SELECT co.*, f.name AS person_name
           FROM contracts co LEFT JOIN family_members f ON f.id = co.person_id
           LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.status='active' AND c.name = 'Versicherungen'
           ORDER BY co.insurance_type, f.sort_order, co.label"""
    ).fetchall()

    income_by_person = {}
    for row in conn.execute(
        f"""SELECT person_id, SUM({monthly_expr('amount', 'frequency')}) AS v
            FROM income WHERE active=1 AND person_id IS NOT NULL GROUP BY person_id"""
    ).fetchall():
        income_by_person[row["person_id"]] = row["v"]

    child_count = conn.execute(
        "SELECT COUNT(*) AS n FROM family_members WHERE role='kind'"
    ).fetchone()["n"]
    has_children = child_count > 0

    person_names = {
        row["id"]: row["name"] for row in conn.execute("SELECT id, name FROM family_members").fetchall()
    }

    # Erwerbsminderungsrente je Person aus den gesetzlichen Rentenkonten —
    # relevant für die Deckelungsprüfung zusammen mit der privaten BU-Rente.
    em_by_person = {}
    for row in conn.execute(
        """SELECT person_id, COALESCE(SUM(disability_pension_monthly),0) AS v
           FROM pension_accounts WHERE type='gesetzlich' GROUP BY person_id"""
    ).fetchall():
        em_by_person[row["person_id"]] = row["v"]

    financing_monthly = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND c.name='Haus' AND co.subcategory='Finanzierung'"""
    ).fetchone()["v"]

    conn.close()

    groups = {}
    for c in contracts:
        itype = c["insurance_type"] or "Sonstige Versicherung"
        groups.setdefault(itype, []).append(c)

    result = []
    for itype, items in groups.items():
        entries = []
        for c in items:
            entry = {
                "id": c["id"], "label": c["label"], "provider": c["provider"],
                "person_id": c["person_id"], "person_name": c["person_name"],
                "amount": c["amount"], "frequency": c["frequency"],
            }
            net_income = income_by_person.get(c["person_id"], 0) if c["person_id"] else 0

            if itype == "Berufsunfähigkeitsversicherung":
                entry["bu_monthly_pension"] = c["bu_monthly_pension"]
                entry.update(compute_bu_assessment(c["bu_monthly_pension"], net_income))
                entry["bu_em_combination"] = compute_bu_em_combination(
                    c["bu_monthly_pension"], em_by_person.get(c["person_id"], 0), net_income
                )
            elif itype == "Risikolebensversicherung":
                entry["insurance_sum"] = c["insurance_sum"]
                entry["insurance_expiry"] = c["insurance_expiry"]
                entry["insurance_sum_type"] = c["insurance_sum_type"]
                entry.update(compute_rlv_assessment(c["insurance_sum"], net_income, has_children, financing_monthly))
            else:
                entry["assessment"] = "present"
            entries.append(entry)
        result.append({"insurance_type": itype, "entries": entries})

    # Häufige Standard-Absicherungen, die fehlen könnten (rein informativ).
    # Mit Begründung, damit klar wird, WARUM etwas empfohlen wird — nicht nur
    # eine nackte Liste. Bei Kindern im Haushalt kommt eine Unfallversicherung
    # dazu: die gesetzliche Unfallversicherung über Schule/Kita deckt nur den
    # direkten Schulweg und die Einrichtung selbst ab, nicht die Freizeit —
    # dort passiert der Großteil der Kinderunfälle.
    present_types = set(groups.keys())
    essential_types = [
        ("Haftpflichtversicherung", "Deckt Schäden, die ihr anderen zufügt — mit Kindern im Haushalt besonders relevant, da sie oft für Schäden haften, die die Kinder verursachen."),
        ("Hausratversicherung", "Schützt die gesamte Wohnungseinrichtung bei Feuer, Einbruch oder Leitungswasser."),
        ("Berufsunfähigkeitsversicherung", "Die gesetzliche Absicherung bei Erwerbsunfähigkeit fällt oft deutlich niedriger aus als das bisherige Einkommen."),
        ("Risikolebensversicherung", "Mit Kindern im Haushalt besonders wichtig — sichert den Lebensunterhalt der Familie ab, falls ein Elternteil stirbt."),
    ]
    if has_children:
        essential_types.append((
            "Unfallversicherung",
            "Die gesetzliche Unfallversicherung über Schule/Kita gilt nur auf dem direkten Weg dorthin und vor Ort — Freizeitunfälle, wo die meisten Kinderunfälle passieren, sind nicht mitversichert.",
        ))
    missing_common = [
        {"insurance_type": t, "reason": reason}
        for t, reason in essential_types if t not in present_types
    ]
    essential_total = len(essential_types)
    essential_present = essential_total - len(missing_common)

    # Zusammenfassende Empfehlung je einkommensbeziehender Person, damit man
    # nicht erst durch alle Gruppen suchen muss, um zu sehen, wo man steht.
    persons_summary = []
    for person_id, net_income in income_by_person.items():
        if net_income <= 0:
            continue
        person_name = person_names.get(person_id)
        bu_entries = [
            e for g in result if g["insurance_type"] == "Berufsunfähigkeitsversicherung"
            for e in g["entries"] if e["person_id"] == person_id
        ]
        rlv_entries = [
            e for g in result if g["insurance_type"] == "Risikolebensversicherung"
            for e in g["entries"] if e["person_id"] == person_id
        ]
        best_bu = max(bu_entries, key=lambda e: e.get("bu_monthly_pension") or 0, default=None)
        best_rlv = max(rlv_entries, key=lambda e: e.get("insurance_sum") or 0, default=None)
        bu_assessment = best_bu or compute_bu_assessment(None, net_income)
        rlv_assessment = best_rlv or compute_rlv_assessment(None, net_income, has_children, financing_monthly)
        persons_summary.append({
            "person_id": person_id,
            "person_name": person_name,
            "net_income_monthly": round(net_income, 2),
            "bu_em_combination": compute_bu_em_combination(
                best_bu.get("bu_monthly_pension") if best_bu else None,
                em_by_person.get(person_id, 0), net_income,
            ),
            "bu": bu_assessment,
            "rlv": rlv_assessment,
        })

    return {
        "groups": result,
        "missing_common_types": missing_common,
        "essential_total": essential_total,
        "essential_present": essential_present,
        "household": {
            "child_count": child_count,
            "financing_monthly": round(financing_monthly, 2),
        },
        "persons_summary": persons_summary,
    }


@app.get("/api/vorsorge/rente")
def vorsorge_rente_overview(session=Depends(auth.require_full_auth)):
    """Versorgungslücken-Analyse je Person MIT eigenem Einkommen (wie bisher)
    sowie zusammengefasst für den ganzen Haushalt — im Alter tragen meist
    beide Einkommen gemeinsam den Lebensstandard, insofern ist die
    Haushaltssicht oft aussagekräftiger als die reine Einzelbetrachtung.
    Eine bis zum Renteneintritt abbezahlte Immobilienfinanzierung wird dabei
    als Entlastung der Zielrente berücksichtigt (weniger Ausgaben im Alter =
    selbst eine Form von Vorsorge) — hinterlegt wird das ganz normal über
    das 'Vertragsende' bei der Finanzierung."""
    from vorsorge import (
        years_until_retirement, project_private_pension_capital,
        capital_to_monthly_pension, compute_pension_gap, compute_household_pension_gap,
        DEFAULT_RETURN_RATE, RETIREMENT_AGE, TARGET_REPLACEMENT_RATE,
    )
    conn = get_connection()
    members = conn.execute(
        "SELECT * FROM family_members WHERE role='elternteil' ORDER BY sort_order"
    ).fetchall()

    result = []
    household_net_income = 0.0
    household_statutory = 0.0
    household_private = 0.0
    latest_retirement_date = None
    persons_ages = []
    person_birthdates = []
    today = date.today()

    for person in members:
        net_income = conn.execute(
            f"""SELECT COALESCE(SUM({monthly_expr('amount', 'frequency')}),0) AS v
                FROM income WHERE active=1 AND person_id=?""",
            (person["id"],),
        ).fetchone()["v"]

        accounts = conn.execute(
            """SELECT pa.*, co.amount AS linked_contract_amount, co.label AS linked_contract_label
               FROM pension_accounts pa
               LEFT JOIN contracts co ON co.id = pa.linked_contract_id
               WHERE pa.person_id=? ORDER BY pa.type DESC, pa.label""",
            (person["id"],),
        ).fetchall()

        birth_date = date.fromisoformat(person["birth_date"]) if person["birth_date"] else None
        years_left = years_until_retirement(birth_date)
        if birth_date:
            retirement_date = date(birth_date.year + RETIREMENT_AGE, birth_date.month, birth_date.day)
            if latest_retirement_date is None or retirement_date > latest_retirement_date:
                latest_retirement_date = retirement_date
            age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
            persons_ages.append({"person_name": person["name"], "age": age})
            person_birthdates.append({"person_name": person["name"], "birth_date": birth_date})

        statutory_total = sum(
            (a["projected_monthly_at_67"] or 0) for a in accounts if a["type"] == "gesetzlich"
        )

        private_total = 0.0
        private_accounts_detail = []
        for a in accounts:
            if a["type"] != "privat":
                continue
            # Verknüpftes Konto: der Beitrag kommt live vom Vertrag unter
            # Ausgaben statt aus einem separat gepflegten Wert — so muss er
            # nur an einer Stelle aktuell gehalten werden.
            effective_contribution = a["linked_contract_amount"] if a["linked_contract_id"] else a["monthly_contribution"]
            if a["projected_monthly_at_67"] is not None:
                monthly = a["projected_monthly_at_67"]
                projected_capital = a["current_value"]
            elif years_left is not None:
                rate = a["return_rate_assumption"] if a["return_rate_assumption"] is not None else DEFAULT_RETURN_RATE
                projected_capital = project_private_pension_capital(
                    a["current_value"] or 0, effective_contribution or 0, years_left, rate
                )
                monthly = capital_to_monthly_pension(projected_capital)
            else:
                # Kein Geburtsdatum hinterlegt -> keine Restlaufzeit berechenbar,
                # ohne direkten Prognosewert kann dieses Konto nicht projiziert werden.
                monthly = 0
                projected_capital = a["current_value"]
            private_total += monthly
            private_accounts_detail.append({
                "id": a["id"], "label": a["label"], "provider": a["provider"],
                "current_value": a["current_value"],
                # Für das Bearbeiten-Formular nötig: ohne diese Felder würde das
                # Formular sie leer vorbelegen und beim Speichern überschreiben.
                "monthly_contribution": effective_contribution,
                "is_riester": bool(a["is_riester"]),
                "linked_contract_id": a["linked_contract_id"],
                "linked_contract_label": a["linked_contract_label"],
                "projected_monthly_at_67": a["projected_monthly_at_67"],
                "note": a["note"],
                "projected_capital_at_67": round(projected_capital or 0, 2),
                "projected_monthly": round(monthly, 2),
            })

        gap = compute_pension_gap(net_income, statutory_total, private_total) if net_income > 0 else None

        household_net_income += net_income
        household_statutory += statutory_total
        household_private += private_total

        result.append({
            "person_id": person["id"], "person_name": person["name"],
            "birth_date": person["birth_date"], "years_until_retirement": round(years_left, 1) if years_left is not None else None,
            "net_income_monthly": round(net_income, 2),
            "statutory_accounts": [dict(a) for a in accounts if a["type"] == "gesetzlich"],
            "private_accounts": private_accounts_detail,
            "gap_analysis": gap,
        })

    # Finanzierung(en), die bis zum Renteneintritt des zuletzt in Rente
    # gehenden Elternteils abbezahlt sein werden — deren monatliche Rate
    # entfällt dann als Ausgabe und senkt die benötigte Zielrente.
    from finanzierung import compute_repayment_schedule
    financing_rows = conn.execute(
        f"""SELECT co.amount, co.frequency, co.remaining_debt, co.interest_rate, co.repayment_rate,
                   co.label, co.provider, co.contract_number
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND c.name='Haus' AND co.subcategory='Finanzierung'"""
    ).fetchall()
    financing_details = []
    expense_relief = 0.0
    for f in financing_rows:
        monthly_amt = f["amount"] if f["frequency"] == "monthly" else (
            f["amount"] / 3 if f["frequency"] == "quarterly" else f["amount"] / 12
        )
        # Ob die Finanzierung vor der Rente abbezahlt ist, wird jetzt aus dem
        # echten Zins+Tilgungsrechner ermittelt (Restschuld/Zins/Rate) statt
        # aus einem manuell eingetragenen Datum — das war zuvor mit der
        # Zinsbindung verwechselbar und daher unzuverlässig.
        schedule = compute_repayment_schedule(
            remaining_debt=f["remaining_debt"], interest_rate=f["interest_rate"],
            monthly_payment=monthly_amt, repayment_rate=f["repayment_rate"],
        )
        payoff_year = schedule.get("payoff_year") if not schedule.get("error") else None
        paid_off_before_retirement = bool(
            payoff_year and latest_retirement_date and payoff_year <= latest_retirement_date.year
        )
        if paid_off_before_retirement:
            expense_relief += monthly_amt
        # Alter beider Elternteile IM Tilgungsjahr (nicht das heutige Alter!) —
        # deutlich aussagekräftiger, um einzuschätzen, ob die Finanzierung
        # realistisch vor bzw. erst nach dem Renteneintritt abbezahlt ist.
        ages_at_payoff = None
        if payoff_year:
            ages_at_payoff = [
                {"person_name": pb["person_name"], "age": payoff_year - pb["birth_date"].year}
                for pb in person_birthdates
            ]
        base_label = f["label"] or f["provider"] or "Darlehen"
        # Mehrere Darlehen derselben Bank (z.B. Haupt- + KfW-Darlehen bei
        # derselben Bank) tragen sonst identische, nicht unterscheidbare
        # Labels — die Kontonummer macht sie eindeutig.
        display_label = f"{base_label} ({f['contract_number']})" if f["contract_number"] else base_label
        financing_details.append({
            "label": display_label, "monthly_amount": round(monthly_amt, 2),
            "payoff_year": payoff_year,
            "calculation_error": schedule.get("error"),
            "paid_off_before_retirement": paid_off_before_retirement,
            "ages_at_payoff": ages_at_payoff,
        })

    household_gap = (
        compute_household_pension_gap(household_net_income, household_statutory, household_private, expense_relief)
        if household_net_income > 0 else None
    )

    conn.close()
    return {
        "retirement_age": RETIREMENT_AGE,
        "target_replacement_rate": TARGET_REPLACEMENT_RATE,
        "default_return_rate": DEFAULT_RETURN_RATE,
        "persons": result,
        "household": {
            "net_income_monthly": round(household_net_income, 2),
            "statutory_pension_monthly": round(household_statutory, 2),
            "private_pension_monthly": round(household_private, 2),
            "financing": financing_details,
            "gap_analysis": household_gap,
            "persons_ages": persons_ages,
        },
    }



class CategoryIn(BaseModel):
    name: str


@app.post("/api/categories")
def create_category(payload: CategoryIn, session=Depends(auth.require_full_auth)):
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Bitte einen Namen angeben.")
    conn = get_connection()
    existing = conn.execute("SELECT id FROM categories WHERE name=?", (name,)).fetchone()
    if not existing:
        conn.execute("INSERT INTO categories (name) VALUES (?)", (name,))
        conn.commit()
    conn.close()
    return {"status": "created", "name": name}


@app.get("/api/maintenance/backups")
def get_backups(session=Depends(auth.require_full_auth)):
    import maintenance
    return maintenance.list_backups()


@app.post("/api/maintenance/backup-now")
def trigger_backup_now(session=Depends(auth.require_full_auth)):
    import maintenance
    return maintenance.backup_database()


@app.get("/api/maintenance/outdated-packages")
def get_outdated_packages(session=Depends(auth.require_full_auth)):
    """Live-Check beim Klick auf den Button in den Einstellungen — separat
    vom wöchentlichen Hintergrund-Check (check_dependencies.py), der
    unabhängig von einer offenen App-Sitzung läuft und sein Ergebnis in der
    settings-Tabelle hinterlegt."""
    import maintenance
    return maintenance.check_outdated()


@app.get("/api/maintenance/check-app-update")
def check_app_update_endpoint(session=Depends(auth.require_full_auth)):
    """Prüft das öffentliche Release-Manifest auf eine neuere App-Version
    (nicht zu verwechseln mit den Python-Paket-Updates oben)."""
    import maintenance
    return maintenance.check_app_update()


class ApplyAppUpdateIn(BaseModel):
    download_url: str
    sha256: str


@app.post("/api/maintenance/apply-app-update")
def apply_app_update_endpoint(payload: ApplyAppUpdateIn, session=Depends(auth.require_full_auth)):
    """Lädt die neue Version herunter, prüft sie und spielt sie ein —
    ausschließlich nach explizitem Klick des Nutzers (kein automatischer
    Hintergrund-Download ohne Bestätigung)."""
    import maintenance
    return maintenance.apply_app_update(payload.download_url, payload.sha256)


def _check_all_updates() -> dict:
    import maintenance
    return {"app": maintenance.check_app_update(), "packages": maintenance.check_outdated()}


def _apply_all_updates(payload: "ApplyAllUpdatesIn") -> dict:
    import maintenance
    results = {}

    if payload.apply_packages:
        pkg_result = maintenance.upgrade_all()
        results["packages"] = pkg_result
        if not pkg_result.get("success"):
            return {"status": "error", "results": results}
        conn = get_connection()
        conn.execute("DELETE FROM settings WHERE key='dependency_check_result'")
        conn.commit()
        conn.close()

    if payload.apply_app and payload.download_url:
        app_result = maintenance.apply_app_update(payload.download_url, payload.sha256 or "")
        results["app"] = app_result
        if app_result.get("status") != "applied":
            return {"status": "error", "results": results}
        # apply_app_update startet den Dienst bereits selbst neu
    elif payload.apply_packages:
        maintenance.restart_service()

    return {"status": "applied", "results": results}


@app.get("/api/maintenance/check-all-updates")
def check_all_updates_endpoint(session=Depends(auth.require_full_auth)):
    """Bündelt beide Update-Arten (App-Version + Python-Pakete) in einer
    Antwort — für den kombinierten 'Nach Updates suchen'-Button, der beim
    Start der Seite automatisch und in den Einstellungen manuell aufgerufen
    wird, statt zwei getrennte Prüfungen anzubieten."""
    return _check_all_updates()


class ApplyAllUpdatesIn(BaseModel):
    apply_app: bool = False
    apply_packages: bool = False
    download_url: Optional[str] = None
    sha256: Optional[str] = None


@app.post("/api/maintenance/apply-all-updates")
def apply_all_updates_endpoint(payload: ApplyAllUpdatesIn, session=Depends(auth.require_full_auth)):
    """Spielt genau das ein, was beim Check als verfügbar bestätigt wurde —
    zuerst Python-Pakete (falls angefordert), danach die neue App-Version
    (falls angefordert). Ein einzelner Neustart am Ende reicht in jedem
    Fall, auch wenn nur Pakete aktualisiert wurden."""
    return _apply_all_updates(payload)


@app.get("/api/public/check-updates")
def public_check_updates_endpoint():
    """Bewusst OHNE Login erreichbar -- die Update-Prüfung soll schon vor
    der Anmeldung stattfinden können (z.B. wenn ein Familienmitglied sich
    aus der App ausgesperrt hat, aber dennoch aktualisieren möchte). Rein
    lesend: fragt nur das öffentliche Release-Manifest und lokal
    installierte Paketversionen ab, gibt keine privaten Daten preis."""
    return _check_all_updates()


@app.post("/api/public/apply-updates")
def public_apply_updates_endpoint(payload: ApplyAllUpdatesIn):
    """Bewusst OHNE Login erreichbar, aus demselben Grund wie oben. Die
    Update-Quelle bleibt trotzdem strikt auf die fest einprogrammierte,
    vertrauenswürdige Domain begrenzt (siehe apply_app_update) und jede
    heruntergeladene Datei wird per Prüfsumme verifiziert, bevor sie
    eingespielt wird -- ein fehlender Login ändert daran nichts."""
    return _apply_all_updates(payload)


@app.post("/api/maintenance/restart-service")
def restart_service_endpoint(session=Depends(auth.require_full_auth)):
    import maintenance
    return maintenance.restart_service()


@app.post("/api/maintenance/upgrade-packages")
def upgrade_packages(session=Depends(auth.require_full_auth)):
    import maintenance
    result = maintenance.upgrade_all()
    if result["success"]:
        conn = get_connection()
        conn.execute("DELETE FROM settings WHERE key='dependency_check_result'")
        conn.commit()
        conn.close()
    return result


@app.get("/api/maintenance/last-background-check")
def get_last_background_check(session=Depends(auth.require_full_auth)):
    """Ergebnis des letzten automatischen Wochen-Checks (siehe
    check_dependencies.py) — läuft per launchd auch dann, wenn die App
    gerade nicht offen ist."""
    conn = get_connection()
    row = conn.execute(
        "SELECT value FROM settings WHERE key='dependency_check_result'"
    ).fetchone()
    conn.close()
    if not row:
        return {"checked_at": None, "outdated": []}
    return json.loads(row["value"])


@app.get("/api/insurance-types")
def list_insurance_types_dynamic(session=Depends(auth.require_full_auth)):
    from vorsorge import INSURANCE_TYPES
    conn = get_connection()
    db_names = {r["name"] for r in conn.execute("SELECT name FROM insurance_types").fetchall()}
    conn.close()
    all_names = set(INSURANCE_TYPES) | db_names
    return sorted(all_names, key=lambda s: s.lower())


@app.post("/api/insurance-types")
def create_insurance_type(payload: CategoryIn, session=Depends(auth.require_full_auth)):
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Bitte einen Namen angeben.")
    conn = get_connection()
    existing = conn.execute("SELECT id FROM insurance_types WHERE name=?", (name,)).fetchone()
    if not existing:
        conn.execute("INSERT INTO insurance_types (name) VALUES (?)", (name,))
        conn.commit()
    conn.close()
    return {"status": "created", "name": name}


# ---------- Verträge ----------

@app.put("/api/contracts/reorder")
def reorder_contracts(ids: List[int], session=Depends(auth.require_full_auth)):
    """Setzt sort_order anhand der übergebenen Reihenfolge — wird nach
    Drag & Drop innerhalb einer Kategorie-Gruppe aufgerufen. Nur die
    übergebenen IDs werden angefasst, alle anderen Verträge bleiben
    unverändert (Reihenfolge ist ohnehin nur innerhalb derselben Gruppe
    relevant, siehe ORDER BY in list_contracts)."""
    conn = get_connection()
    for position, contract_id in enumerate(ids):
        conn.execute("UPDATE contracts SET sort_order=? WHERE id=?", (position, contract_id))
    conn.commit()
    conn.close()
    return {"status": "reordered"}


@app.get("/api/contracts")
def list_contracts(category: Optional[str] = None, status: str = "active",
                    needs_review: Optional[bool] = None,
                    session=Depends(auth.require_full_auth)):
    from categorize import derive_contract_label
    conn = get_connection()
    query = f"""SELECT co.*, c.name AS category_name, f.name AS person_name,
                       {monthly_expr('co.amount', 'co.frequency', 'co.split_share')} AS monthly_amount
               FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
                                  LEFT JOIN family_members f ON f.id = co.person_id
               WHERE co.status = ?"""
    params = [status]
    if category:
        query += " AND c.name = ?"
        params.append(category)
    if needs_review is not None:
        query += " AND co.reviewed = ?"
        params.append(0 if needs_review else 1)
    query += " ORDER BY c.name, co.subcategory, co.sort_order, COALESCE(co.provider, co.label)"
    rows = conn.execute(query, params).fetchall()
    conn.close()

    result = []
    for r in rows:
        d = dict(r)
        d["label_is_manual"] = bool(d["label"])
        if not d["label"]:
            d["label"] = derive_contract_label(
                d["category_name"], d["insurance_type"], d["person_name"],
                d["provider"], d["contract_number"],
            )
        result.append(d)
    return result


@app.patch("/api/contracts/{contract_id}")
def update_contract(contract_id: int, patch: ContractPatch,
                     session=Depends(auth.require_full_auth)):
    """Manuelle Korrektur — bleibt gültig, bis ein neues automatisches Update
    (z.B. per Foto-Beleg) den Wert erneut überschreibt."""
    conn = get_connection()
    existing = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")

    fields = patch.dict(exclude_unset=True)
    category_name = fields.pop("category", None)
    category_changed = False
    if category_name:
        cur = conn.execute("SELECT id FROM categories WHERE name=?", (category_name,))
        row = cur.fetchone()
        new_category_id = row["id"] if row else conn.execute(
            "INSERT INTO categories (name) VALUES (?)", (category_name,)
        ).lastrowid
        category_changed = new_category_id != existing["category_id"]
        fields["category_id"] = new_category_id

    # Nur tatsächlich GEÄNDERTE Felder übernehmen — das Formular schickt beim
    # Speichern immer alle Felder mit, auch unveränderte. Ohne diesen
    # Abgleich würde jedes Öffnen+Speichern ohne echte Änderung trotzdem
    # updated_at/source überschreiben.
    def _norm(v):
        if v is None:
            return None
        if isinstance(v, bool):
            return int(v)
        if hasattr(v, "isoformat"):
            return v.isoformat()
        return v

    changed = {
        k: v for k, v in fields.items()
        if k not in existing.keys() or _norm(v) != _norm(existing[k])
    }
    if category_changed:
        # Explizite Kategorie-Wahl gilt als "geprüft" — auch wenn wieder
        # "Sonstiges" gewählt wird, verschwindet die Position dann aus der
        # Review-Liste, weil jetzt bewusst bestätigt statt nur importiert.
        changed["reviewed"] = 1
    fields = changed

    if not fields:
        conn.close()
        return {"status": "unchanged"}

    fields["source"] = "manuell"
    fields["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE contracts SET {set_clause} WHERE id=?",
                 (*fields.values(), contract_id))

    if {"contract_end", "notice_period_days", "category_id", "subcategory"} & fields.keys():
        _sync_reminders(conn, contract_id)

    conn.commit()
    conn.close()
    return {"status": "updated"}


def _contract_folder_parts(category_name: str, subcategory: Optional[str],
                            provider: Optional[str], label: str,
                            person_name: Optional[str] = None) -> list:
    """Die Ordner-Teilpfade für die Ablage eines Vertrags — dieselbe Logik wie
    beim Einsortieren eines bestätigten Belegs, damit Archivieren denselben
    Ordner wiederfindet, den confirm_receipt angelegt hat. Ist der Vertrag
    einer Person zugeordnet (z.B. eine individuelle BU-Versicherung), wird
    dafür eine eigene Ordnerebene eingezogen, damit sich z.B. Annas und
    Toms Versicherungsunterlagen nicht im selben Ordner vermischen.
    Haushaltsweite Verträge ohne Personen-Zuordnung bleiben unverändert."""
    category_slug = re.sub(r"[^\w.-]", "_", category_name or "Sonstiges")
    contract_slug = re.sub(r"[^\w.-]", "_", (provider or label or "Vertrag"))[:60]
    parts = [category_slug]
    if subcategory:
        parts.append(re.sub(r"[^\w.-]", "_", subcategory))
    if person_name:
        parts.append(re.sub(r"[^\w.-]", "_", person_name))
    parts.append(contract_slug)
    return parts


ARCHIVE_DIR = RECEIPTS_DIR / "_archiv"


def _migrate_receipts_person_separation_once():
    """Einmalige Migration: Verträge, die einer Person zugeordnet sind,
    bekommen nachträglich eine eigene Ordnerebene (z.B.
    Versicherungen/Berufsunfähigkeitsversicherung/Anna/... statt alle
    Personen im selben Anbieter-Ordner zu vermischen). Verschiebt bestehende
    Ordner physisch und aktualisiert die gespeicherten Beleg-Pfade
    entsprechend — sowohl für aktive als auch archivierte Verträge."""
    conn = get_connection()
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_receipts_person_separation'"
    ).fetchone()
    if flag:
        conn.close()
        return

    contracts = conn.execute(
        """SELECT co.id, co.status, co.subcategory, co.provider, co.label, co.person_id,
                  c.name AS category_name, fm.name AS person_name
           FROM contracts co
           LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.person_id IS NOT NULL"""
    ).fetchall()

    moved_count = 0
    for contract in contracts:
        if not contract["person_name"]:
            continue
        old_parts = _contract_folder_parts(
            contract["category_name"], contract["subcategory"], contract["provider"], contract["label"]
        )
        new_parts = _contract_folder_parts(
            contract["category_name"], contract["subcategory"], contract["provider"], contract["label"],
            contract["person_name"],
        )
        if old_parts == new_parts:
            continue  # z.B. Provider/Label leer -> beide Pfade zufällig identisch

        if contract["status"] == "cancelled":
            old_dir = ARCHIVE_DIR.joinpath(*(old_parts[:-1] + [f"{old_parts[-1]}_{contract['id']}"]))
            new_dir = ARCHIVE_DIR.joinpath(*(new_parts[:-1] + [f"{new_parts[-1]}_{contract['id']}"]))
        else:
            old_dir = RECEIPTS_DIR.joinpath(*old_parts)
            new_dir = RECEIPTS_DIR.joinpath(*new_parts)

        if not old_dir.exists() or not old_dir.is_dir():
            continue
        if old_dir == new_dir:
            continue

        new_dir.parent.mkdir(parents=True, exist_ok=True)
        if new_dir.exists():
            # Zielordner existiert schon (unwahrscheinlich, aber möglich) —
            # Dateien einzeln verschieben statt zu überschreiben.
            for item in old_dir.iterdir():
                dest = new_dir / item.name
                if not dest.exists():
                    item.rename(dest)
            try:
                old_dir.rmdir()
            except OSError:
                pass
        else:
            old_dir.rename(new_dir)

        # Beleg-Pfade in der DB auf die neue Lage nachziehen, sonst würden
        # "Beleg ansehen"-Links auf nicht mehr existierende Pfade zeigen.
        receipts = conn.execute(
            "SELECT id, stored_path FROM receipts WHERE contract_id=?", (contract["id"],)
        ).fetchall()
        for r in receipts:
            old_path = BASE_DIR / r["stored_path"]
            try:
                rel = old_path.relative_to(old_dir)
            except ValueError:
                continue
            new_path = new_dir / rel
            conn.execute(
                "UPDATE receipts SET stored_path=? WHERE id=?",
                (str(new_path.relative_to(BASE_DIR)), r["id"]),
            )
        moved_count += 1

    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_receipts_person_separation', 'true')"
    )
    conn.commit()
    conn.close()
    if moved_count:
        print(f"Migration: {moved_count} Vertragsordner nach Person getrennt")


@app.delete("/api/contracts/{contract_id}")
def delete_contract(contract_id: int, session=Depends(auth.require_full_auth)):
    """'Löschen' archiviert den Vertrag, statt ihn hart zu entfernen: Status
    wird auf 'cancelled' gesetzt (verschwindet damit aus der aktiven Liste
    und aus allen Kosten-Berechnungen, die nach status='active' filtern),
    und ein eventuell vorhandener Belege-Ordner wird strukturiert ins Archiv
    verschoben. Ein echtes Löschen würde entweder die verknüpften Belege per
    FOREIGN KEY-Fehler blockieren, oder — falls man das stattdessen einfach
    entkoppelt — Dokumente und Historie unwiederbringlich von ihrem
    Vertragskontext trennen. Damit bleiben Dateien und Zuordnung erhalten
    und sind über das Archiv weiterhin auffindbar."""
    conn = get_connection()
    contract = conn.execute(
        """SELECT co.*, c.name AS category_name, fm.name AS person_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.id=?""",
        (contract_id,),
    ).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")

    parts = _contract_folder_parts(
        contract["category_name"], contract["subcategory"], contract["provider"], contract["label"],
        contract["person_name"],
    )
    source_dir = RECEIPTS_DIR.joinpath(*parts)
    if source_dir.exists() and source_dir.is_dir() and any(source_dir.iterdir()):
        archive_parts = parts[:-1] + [f"{parts[-1]}_{contract_id}"]
        target_dir = ARCHIVE_DIR.joinpath(*archive_parts)
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        if not target_dir.exists():
            source_dir.rename(target_dir)
            # Alle Belege, deren Datei im verschobenen Ordner lag, auf den
            # neuen Pfad umbiegen, damit "Beleg ansehen" weiterhin funktioniert.
            receipts = conn.execute(
                "SELECT id, stored_path FROM receipts WHERE contract_id=?", (contract_id,)
            ).fetchall()
            for r in receipts:
                old_path = BASE_DIR / r["stored_path"]
                try:
                    rel = old_path.relative_to(source_dir)
                except ValueError:
                    continue  # Datei lag aus irgendeinem Grund nicht in diesem Ordner
                new_path = target_dir / rel
                if new_path.exists():
                    conn.execute(
                        "UPDATE receipts SET stored_path=? WHERE id=?",
                        (str(new_path.relative_to(BASE_DIR)), r["id"]),
                    )

    # Erinnerungen (Kündigungsfrist etc.) sind für einen archivierten Vertrag
    # irrelevant und würden sonst weiter Benachrichtigungen auslösen.
    conn.execute("DELETE FROM reminders WHERE contract_id=?", (contract_id,))
    conn.execute("UPDATE contracts SET status='cancelled' WHERE id=?", (contract_id,))
    conn.commit()
    conn.close()
    return {"status": "archived"}


@app.post("/api/contracts/{contract_id}/restore")
def restore_contract(contract_id: int, session=Depends(auth.require_full_auth)):
    """Macht das Archivieren rückgängig: Status zurück auf 'active', Belege-
    Ordner (falls vorhanden) zurück an seinen normalen Platz verschoben."""
    conn = get_connection()
    contract = conn.execute(
        """SELECT co.*, c.name AS category_name, fm.name AS person_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.id=?""",
        (contract_id,),
    ).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")
    if contract["status"] != "cancelled":
        conn.close()
        raise HTTPException(400, "Dieser Vertrag ist nicht archiviert.")

    parts = _contract_folder_parts(
        contract["category_name"], contract["subcategory"], contract["provider"], contract["label"],
        contract["person_name"],
    )
    archive_parts = parts[:-1] + [f"{parts[-1]}_{contract_id}"]
    source_dir = ARCHIVE_DIR.joinpath(*archive_parts)
    target_dir = RECEIPTS_DIR.joinpath(*parts)

    if source_dir.exists() and source_dir.is_dir():
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        if target_dir.exists():
            # Es gibt schon wieder einen aktiven Ordner mit demselben Namen
            # (z.B. ein neuer Vertrag beim selben Anbieter) — Dateien werden
            # einzeln hinein verschoben statt den ganzen Ordner umzubenennen,
            # damit dabei nichts überschrieben wird.
            for item in source_dir.iterdir():
                dest = target_dir / item.name
                if not dest.exists():
                    item.rename(dest)
            try:
                source_dir.rmdir()
            except OSError:
                pass  # Ordner nicht leer (Namenskollision) — bleibt als Rest im Archiv liegen
        else:
            source_dir.rename(target_dir)

        receipts = conn.execute(
            "SELECT id, stored_path FROM receipts WHERE contract_id=?", (contract_id,)
        ).fetchall()
        for r in receipts:
            old_path = BASE_DIR / r["stored_path"]
            new_path = target_dir / old_path.name
            if new_path.exists():
                conn.execute(
                    "UPDATE receipts SET stored_path=? WHERE id=?",
                    (str(new_path.relative_to(BASE_DIR)), r["id"]),
                )

    conn.execute("UPDATE contracts SET status='active' WHERE id=?", (contract_id,))
    conn.commit()
    conn.close()
    return {"status": "restored"}


@app.get("/api/contracts/{contract_id}/repayment-schedule")
def get_repayment_schedule(contract_id: int, session=Depends(auth.require_full_auth)):
    """Tilgungsplan für eine Immobilienfinanzierung ab der aktuellen
    Restschuld. Nutzt die monatliche Vertragsrate; ist keine sinnvolle Rate
    hinterlegt, wird auf den Tilgungssatz zurückgegriffen."""
    from finanzierung import compute_repayment_schedule
    conn = get_connection()
    c = conn.execute(
        """SELECT co.*, cat.name AS category_name FROM contracts co
           LEFT JOIN categories cat ON cat.id = co.category_id WHERE co.id=?""",
        (contract_id,),
    ).fetchone()
    conn.close()
    if not c:
        raise HTTPException(404, "Vertrag nicht gefunden")

    monthly = c["amount"] if c["frequency"] == "monthly" else (
        c["amount"] / 3 if c["frequency"] == "quarterly" else c["amount"] / 12
    )
    return compute_repayment_schedule(
        remaining_debt=c["remaining_debt"],
        interest_rate=c["interest_rate"],
        monthly_payment=monthly,
        repayment_rate=c["repayment_rate"],
    )


@app.get("/api/verbindlichkeiten/overview")
def verbindlichkeiten_overview(session=Depends(auth.require_full_auth)):
    """Übersicht über alle laufenden Finanzierungen: gewichteter
    Durchschnittszins, anstehende Zinsbindungsenden, und ein aggregierter
    Tilgungsplan über ALLE Finanzierungen zusammen (Restschuld + kumulierte
    Zinsen pro Jahr summiert) — für den Fall, dass keine einzelne
    Finanzierung ausgewählt ist."""
    from finanzierung import compute_repayment_schedule
    conn = get_connection()
    rows = conn.execute(
        """SELECT co.* FROM contracts co
           LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.subcategory = 'Finanzierung' AND co.status = 'active'"""
    ).fetchall()
    conn.close()

    if not rows:
        return {"average_interest_rate": None, "total_remaining_debt": 0, "upcoming_rate_locks": [],
                "aggregated_schedule": {"error": "Keine laufende Finanzierung unter Ausgaben hinterlegt.", "schedule": []}}

    total_debt = sum(r["remaining_debt"] or 0 for r in rows)
    weighted_rate = (
        sum((r["remaining_debt"] or 0) * (r["interest_rate"] or 0) for r in rows) / total_debt
        if total_debt else None
    )

    upcoming_rate_locks = sorted([
        {"label": r["label"], "contract_end": r["contract_end"], "remaining_debt": r["remaining_debt"]}
        for r in rows if r["contract_end"]
    ], key=lambda x: x["contract_end"])

    per_loan_schedules = []
    total_monthly_payment = 0.0
    max_payoff_year = None
    min_start_year = None
    for r in rows:
        if not r["remaining_debt"] or not r["interest_rate"]:
            continue
        monthly = r["amount"] if r["frequency"] == "monthly" else (
            r["amount"] / 3 if r["frequency"] == "quarterly" else r["amount"] / 12
        )
        result = compute_repayment_schedule(
            remaining_debt=r["remaining_debt"], interest_rate=r["interest_rate"],
            monthly_payment=monthly, repayment_rate=r["repayment_rate"],
        )
        if result.get("error"):
            continue
        total_monthly_payment += monthly
        per_loan_schedules.append({p["year"]: p for p in result["schedule"]})
        years_here = [p["year"] for p in result["schedule"]]
        if max_payoff_year is None or years_here[-1] > max_payoff_year:
            max_payoff_year = years_here[-1]
        if min_start_year is None or years_here[0] < min_start_year:
            min_start_year = years_here[0]

    schedule = []
    if per_loan_schedules and min_start_year is not None:
        # Über den GESAMTEN Zeitraum aller Darlehen hinweg: ein Darlehen, das
        # früher fertig getilgt ist, wird für die restlichen Jahre mit
        # eingefrorener Restschuld (0) und eingefrorenen Gesamtzinsen
        # fortgeschrieben — sonst würde sein bereits gezahlter Zins beim
        # Zusammenzählen später fälschlich aus der Summe herausfallen.
        last_known = [None] * len(per_loan_schedules)
        for y in range(min_start_year, max_payoff_year + 1):
            debt_sum = 0.0
            interest_sum = 0.0
            for i, loan_schedule in enumerate(per_loan_schedules):
                point = loan_schedule.get(y)
                if point is not None:
                    last_known[i] = point
                elif last_known[i] is not None:
                    point = {"remaining_debt": 0.0, "interest_paid_cumulative": last_known[i]["interest_paid_cumulative"]}
                if point is not None:
                    debt_sum += point["remaining_debt"]
                    interest_sum += point["interest_paid_cumulative"]
            schedule.append({"year": y, "remaining_debt": round(debt_sum, 2), "interest_paid_cumulative": round(interest_sum, 2)})

    total_interest_final = schedule[-1]["interest_paid_cumulative"] if schedule else 0
    start_year = schedule[0]["year"] if schedule else None

    aggregated_schedule = {
        "error": None if schedule else "Keine Finanzierung mit vollständigen Angaben (Restschuld, Zinssatz) gefunden.",
        "schedule": schedule,
        "remaining_debt": round(total_debt, 2),
        "interest_rate": round(weighted_rate, 2) if weighted_rate is not None else None,
        "monthly_payment": round(total_monthly_payment, 2),
        "payoff_year": max_payoff_year,
        "years_to_payoff": round(max_payoff_year - start_year, 1) if max_payoff_year and start_year else None,
        "total_interest": round(total_interest_final, 2),
    }

    return {
        "average_interest_rate": round(weighted_rate, 2) if weighted_rate is not None else None,
        "total_remaining_debt": round(total_debt, 2),
        "upcoming_rate_locks": upcoming_rate_locks,
        "aggregated_schedule": aggregated_schedule,
    }


@app.get("/api/contracts/{contract_id}/receipts")
def list_contract_receipts(contract_id: int, session=Depends(auth.require_full_auth)):
    """Alle Belege zu einem Vertrag (aktiv oder archiviert) — für 'alle
    Dateien anzeigen', ohne dafür ins Dateisystem wechseln zu müssen."""
    conn = get_connection()
    contract = conn.execute("SELECT id FROM contracts WHERE id=?", (contract_id,)).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")
    rows = conn.execute(
        """SELECT id, original_filename, detected_amount, detected_date, uploaded_at
           FROM receipts WHERE contract_id=? ORDER BY uploaded_at DESC""",
        (contract_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/api/archive")
def list_archived_contracts(session=Depends(auth.require_full_auth)):
    """Archivierte (gekündigte/gelöschte) Verträge inkl. Beleg-Anzahl, für
    den Archiv-Bereich in der UI."""
    conn = get_connection()
    rows = conn.execute(
        """SELECT co.id, co.label, co.provider, co.subcategory, c.name AS category_name,
                  co.updated_at,
                  (SELECT COUNT(*) FROM receipts WHERE contract_id = co.id) AS receipt_count
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.status = 'cancelled'
           ORDER BY co.updated_at DESC"""
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/contracts")
def create_contract(contract: ContractIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    category_id = None
    if contract.category:
        cur = conn.execute("SELECT id FROM categories WHERE name=?", (contract.category,))
        row = cur.fetchone()
        category_id = row["id"] if row else conn.execute(
            "INSERT INTO categories (name) VALUES (?)", (contract.category,)
        ).lastrowid

    cur = conn.execute(
        """INSERT INTO contracts
           (label, provider, contract_number, category_id, subcategory, amount, frequency,
            payment_method, contract_end, notice_period_days, auto_renews, status, source,
            person_id, interest_rate, remaining_debt, repayment_rate, fixed_interest_until,
            insurance_type, insurance_expiry, insurance_sum, insurance_sum_type, bu_monthly_pension)
           VALUES (?,?,?,?,?,?,?,?,?,?,?, 'active', 'manuell', ?,?,?,?,?,?,?,?,?,?)""",
        (contract.label or "", contract.provider, contract.contract_number, category_id,
         contract.subcategory, contract.amount, contract.frequency, contract.payment_method,
         contract.contract_end, contract.notice_period_days, int(contract.auto_renews),
         contract.person_id, contract.interest_rate, contract.remaining_debt,
         contract.repayment_rate, contract.fixed_interest_until, contract.insurance_type,
         contract.insurance_expiry, contract.insurance_sum, contract.insurance_sum_type,
         contract.bu_monthly_pension),
    )
    contract_id = cur.lastrowid
    conn.commit()

    _sync_reminders(conn, contract_id)
    conn.commit()
    conn.close()
    return {"id": contract_id, "status": "created"}


# ---------- Einnahmen ----------

@app.put("/api/income/reorder")
def reorder_income(ids: List[int], session=Depends(auth.require_full_auth)):
    conn = get_connection()
    for position, income_id in enumerate(ids):
        conn.execute("UPDATE income SET sort_order=? WHERE id=?", (position, income_id))
    conn.commit()
    conn.close()
    return {"status": "reordered"}


@app.get("/api/income")
def list_income(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        f"""SELECT *, {monthly_expr('amount', 'frequency')} AS monthly_amount
            FROM income ORDER BY active DESC, sort_order, label"""
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/income")
def create_income(payload: IncomeIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO income (label, category, amount, frequency, active, source, person_id) VALUES (?,?,?,?,1,'manuell',?)",
        (payload.label, payload.category or "Sonstiges", payload.amount, payload.frequency, payload.person_id),
    )
    conn.commit()
    conn.close()
    return {"id": cur.lastrowid, "status": "created"}


@app.patch("/api/income/{income_id}")
def update_income(income_id: int, patch: IncomePatch, session=Depends(auth.require_full_auth)):
    """Manuelle Korrektur — bleibt gültig, bis die nächste Gehaltsabrechnung importiert wird."""
    conn = get_connection()
    existing = conn.execute("SELECT * FROM income WHERE id=?", (income_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Einnahme nicht gefunden")
    fields = patch.dict(exclude_unset=True)

    # Nur tatsächlich geänderte Felder übernehmen (gleicher Fix wie bei den
    # Verträgen) — sonst würde jedes Öffnen+Speichern ohne echte Änderung
    # trotzdem updated_at/source überschreiben.
    def _norm(v):
        if v is None:
            return None
        if isinstance(v, bool):
            return int(v)
        return v

    changed = {
        k: v for k, v in fields.items()
        if k not in existing.keys() or _norm(v) != _norm(existing[k])
    }
    if not changed:
        conn.close()
        return {"status": "unchanged"}
    changed["source"] = "manuell"
    changed["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in changed)
    conn.execute(f"UPDATE income SET {set_clause} WHERE id=?", (*changed.values(), income_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/income/{income_id}")
def delete_income(income_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM income WHERE id=?", (income_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Einnahme nicht gefunden")
    conn.execute("DELETE FROM income WHERE id=?", (income_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


# ---------- Gehaltsabrechnungen (PDF, teils passwortgeschützt) ----------

@app.post("/api/payslips/bulk-upload")
async def bulk_upload_payslips(income_id: int = Form(...), files: List[UploadFile] = File(...),
                                password: Optional[str] = Form(None),
                                session=Depends(auth.require_full_auth)):
    """Für den initialen Import eines ganzen Stapels alter Gehaltsabrechnungen
    auf einmal. Anders als der Einzel-Upload wird hier NIE der Betrag der
    verknüpften Einnahme aktualisiert — auch nicht durch die zeitlich
    neueste Datei im Stapel. Die Dateien landen direkt (ohne Review-Schritt)
    als bestätigte Zeitreihen-Einträge, der aktuelle Einkommenswert bleibt
    unangetastet, da ein Rückblick-Import keine Aussage über das AKTUELLE
    Gehalt treffen soll."""
    conn = get_connection()
    income = conn.execute("SELECT id FROM income WHERE id=?", (income_id,)).fetchone()
    if not income:
        conn.close()
        raise HTTPException(404, "Einnahme nicht gefunden")

    PAYSLIPS_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        # Byteidentische Datei für dieselbe Einnahme bereits vorhanden? Dann
        # nicht erneut anlegen — verhindert genau die Art von Duplikaten, die
        # z.B. durch zweimaliges versehentliches Auswählen derselben Datei
        # im Dateidialog entstehen.
        existing = conn.execute(
            "SELECT id FROM payslips WHERE income_id=? AND file_hash=?", (income_id, file_hash)
        ).fetchone()
        if existing:
            results.append({"payslip_id": existing["id"], "filename": file.filename, "month": None, "error": "Übersprungen — identische Datei bereits vorhanden."})
            continue

        stored_path = PAYSLIPS_DIR / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{file.filename}"
        stored_path.write_bytes(content)
        try:
            parsed = parse_payslip(stored_path, password)
            net_amount, employer, month = parsed["net_amount"], parsed["employer"], parsed["month"]
            error = None
        except Exception as e:
            # Einzelne nicht lesbare/beschädigte Datei soll den restlichen
            # Stapel nicht abbrechen — sie wird trotzdem archiviert, nur ohne
            # erkannte Werte. parse_payslip kann je nach Fehlerart
            # unterschiedliche Exception-Typen werfen (ungültiges PDF,
            # falsches Passwort, o.ä.), daher hier bewusst breit gefangen.
            net_amount, employer, month = None, None, None
            error = str(e)
        cur = conn.execute(
            """INSERT INTO payslips
               (original_filename, stored_path, file_hash, detected_net_amount,
                detected_employer, detected_month, income_id, review_needed)
               VALUES (?,?,?,?,?,?,?,0)""",
            (file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash, net_amount, employer, month, income_id),
        )
        results.append({"payslip_id": cur.lastrowid, "filename": file.filename, "month": month, "error": error})
    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}


@app.post("/api/payslips/upload")
async def upload_payslip(file: UploadFile = File(...), password: Optional[str] = Form(None),
                          session=Depends(auth.require_full_auth)):
    content = await file.read()
    PAYSLIPS_DIR.mkdir(parents=True, exist_ok=True)
    stored_path = PAYSLIPS_DIR / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{file.filename}"
    stored_path.write_bytes(content)

    try:
        result = parse_payslip(stored_path, password)
    except ValueError as e:
        raise HTTPException(400, str(e))

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO payslips
           (original_filename, stored_path, file_hash, raw_text, detected_net_amount,
            detected_employer, detected_month, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest(),
         result["raw_text"], result["net_amount"], result["employer"], result["month"]),
    )
    payslip_id = cur.lastrowid
    conn.commit()

    matched_income = _find_matching_income(conn, result.get("name_candidates") or [])
    conn.close()

    note = "Bitte kurz bestätigen."
    if matched_income:
        note = f"Automatisch {matched_income['label']!r} zugeordnet — bitte nur kurz bestätigen."
    else:
        note = "Konnte nicht automatisch zugeordnet werden — bitte Einkommens-Eintrag auswählen."

    return {
        "payslip_id": payslip_id,
        "detected": {k: v for k, v in result.items() if k != "raw_text"},
        "matched_income": matched_income,
        "note": note,
    }


class PayslipConfirmIn(BaseModel):
    income_id: Optional[int] = None
    new_income_label: Optional[str] = None
    update_income: bool = True  # False = Beleg nur ablegen/bestätigen, kein Einkommen buchen


@app.post("/api/payslips/{payslip_id}/confirm")
def confirm_payslip(payslip_id: int, payload: PayslipConfirmIn,
                     session=Depends(auth.require_full_auth)):
    conn = get_connection()
    slip = conn.execute("SELECT * FROM payslips WHERE id=?", (payslip_id,)).fetchone()
    if not slip:
        conn.close()
        raise HTTPException(404, "Gehaltsabrechnung nicht gefunden")

    if not payload.update_income:
        # Nur ablegen/als gesichtet markieren, kein Einkommen anlegen oder
        # überschreiben — z.B. bei einem Dokument, das gar keine reguläre
        # Lohnzahlung darstellt (Bonuszusage, Bescheinigung o.ä.).
        conn.execute("UPDATE payslips SET review_needed=0, income_id=? WHERE id=?",
                     (payload.income_id, payslip_id))
        conn.commit()
        conn.close()
        return {"status": "confirmed", "income_id": payload.income_id}

    if not slip["detected_net_amount"]:
        conn.close()
        raise HTTPException(400, "Kein Betrag erkannt — bitte Einkommen manuell nachtragen.")

    if payload.income_id:
        conn.execute(
            "UPDATE income SET amount=?, source='lohnabrechnung', updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (slip["detected_net_amount"], payload.income_id),
        )
        income_id = payload.income_id
    else:
        label = payload.new_income_label or slip["detected_employer"] or slip["original_filename"]
        cur = conn.execute(
            "INSERT INTO income (label, amount, frequency, active, source) "
            "VALUES (?,?, 'monthly', 1, 'lohnabrechnung')",
            (label, slip["detected_net_amount"]),
        )
        income_id = cur.lastrowid

    conn.execute("UPDATE payslips SET review_needed=0, income_id=? WHERE id=?",
                 (income_id, payslip_id))
    conn.commit()
    conn.close()
    return {"status": "confirmed", "income_id": income_id}


@app.get("/api/income/{income_id}/payslips")
def list_income_payslips(income_id: int, session=Depends(auth.require_full_auth)):
    """Die volle Zeitreihe aller Gehaltsabrechnungen zu dieser Einnahme,
    nicht nur die zuletzt hochgeladene. Sortiert nach dem erkannten
    Abrechnungsmonat (steht bei jedem Import mit dabei) statt nach dem
    Hochlade-Zeitpunkt — sonst würde ein nachträglich importierter
    Alt-Beleg (z.B. Januar, aber erst heute hochgeladen) an der falschen
    Stelle der Zeitreihe erscheinen. Einträge ohne erkannten Monat fallen
    auf den Hochlade-Zeitpunkt zurück und landen sortiert am Ende."""
    conn = get_connection()
    rows = conn.execute(
        """SELECT id, original_filename, detected_net_amount, detected_month, detected_employer, uploaded_at
           FROM payslips WHERE income_id=?
           ORDER BY COALESCE(detected_month, '0000-00') DESC, uploaded_at DESC""",
        (income_id,),
    ).fetchall()
    conn.close()

    # Zuletzt gepflegter Arbeitgeber-Wert dieser Einnahme (nach Hochlade-
    # Zeitpunkt, nicht nach Abrechnungsmonat — "zuletzt gepflegt" meint den
    # jüngsten tatsächlichen Dateneingabe-Zeitpunkt) als Rückfallwert für
    # Belege, bei denen der Arbeitgeber nicht automatisch erkannt wurde.
    with_employer = [r for r in rows if r["detected_employer"]]
    last_known_employer = with_employer[0]["detected_employer"] if with_employer else None
    if with_employer:
        last_known_employer = max(with_employer, key=lambda r: r["uploaded_at"] or "")["detected_employer"]

    result = []
    for r in rows:
        d = dict(r)
        d["employer"] = d["detected_employer"] or last_known_employer
        d["employer_is_fallback"] = not d["detected_employer"] and last_known_employer is not None
        result.append(d)
    return result


@app.get("/api/payslips/{payslip_id}/file")
def get_payslip_file(payslip_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    slip = conn.execute("SELECT stored_path, original_filename FROM payslips WHERE id=?", (payslip_id,)).fetchone()
    conn.close()
    if not slip:
        raise HTTPException(404, "Gehaltsabrechnung nicht gefunden")
    file_path = BASE_DIR / slip["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Datei fehlt auf der Festplatte")
    return FileResponse(
        file_path, filename=slip["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


@app.delete("/api/payslips/{payslip_id}")
def delete_payslip(payslip_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    slip = conn.execute("SELECT stored_path FROM payslips WHERE id=?", (payslip_id,)).fetchone()
    if not slip:
        conn.close()
        raise HTTPException(404, "Gehaltsabrechnung nicht gefunden")
    (BASE_DIR / slip["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM payslips WHERE id=?", (payslip_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


# ---------- Belege / Foto-Upload ----------

def _cleanup_unconfirmed_receipts(conn, max_age_hours: Optional[float] = None) -> dict:
    """Räumt nicht bestätigte Belege auf (z.B. Test-Uploads, die nie
    'Bestätigen & übernehmen' durchlaufen haben) — sowohl die Datei in
    data/receipts/_unbestaetigt/ als auch den Datenbankeintrag.

    max_age_hours=None -> alle unbestätigten Belege werden entfernt (für den
    manuellen "Jetzt aufräumen"-Button). Mit einem Wert gesetzt (z.B. 168 für
    eine Woche) werden nur ältere entfernt — so für den automatischen
    Aufräumlauf beim Serverstart, damit ein frisch hochgeladener, noch nicht
    bestätigter Beleg von heute nicht versehentlich verschwindet.
    """
    if max_age_hours is not None:
        rows = conn.execute(
            "SELECT id, stored_path FROM receipts "
            "WHERE review_needed=1 AND uploaded_at < datetime('now', ?)",
            (f"-{max_age_hours} hours",),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, stored_path FROM receipts WHERE review_needed=1"
        ).fetchall()

    deleted_files = 0
    for row in rows:
        file_path = BASE_DIR / row["stored_path"]
        if file_path.exists():
            file_path.unlink()
            deleted_files += 1
    ids = [row["id"] for row in rows]
    if ids:
        placeholders = ",".join("?" * len(ids))
        conn.execute(f"DELETE FROM receipts WHERE id IN ({placeholders})", ids)
        conn.commit()

    # Zusätzlich: Dateien im Zwischenablage-Ordner, die gar keinen
    # Datenbankeintrag mehr haben (z.B. Reste aus manuellen Tests direkt
    # gegen das Backend, ohne über die eigentliche Upload-Route zu laufen).
    orphan_files = 0
    staging_dir = RECEIPTS_DIR / "_unbestaetigt"
    if staging_dir.exists():
        known_paths = {
            str((BASE_DIR / r["stored_path"]).resolve())
            for r in conn.execute("SELECT stored_path FROM receipts").fetchall()
        }
        for f in staging_dir.iterdir():
            if f.is_file() and str(f.resolve()) not in known_paths:
                f.unlink()
                orphan_files += 1

    return {"removed_receipts": len(ids), "removed_files": deleted_files + orphan_files}


def _find_matching_income(conn, name_candidates: list) -> Optional[dict]:
    """Ordnet eine Gehaltsabrechnung automatisch dem passenden Einkommens-
    Eintrag zu — z.B. "Gehalt Anna" bei einer Abrechnung für "Anna".
    Nutzt einen Vorsilben-Abgleich (erste 3 Zeichen), damit auch Kurzformen
    wie "Anna"/"Anna Musterfrau" oder "Tom"/"Tom Mustermann" zueinander passen, ohne
    Namen fest im Code zu hinterlegen."""
    if not name_candidates:
        return None
    rows = conn.execute("SELECT id, label FROM income WHERE active=1").fetchall()
    # Generische Gehaltsabrechnungs-/Finanzbegriffe ausschließen — sonst würde
    # z.B. ein Einkommens-Label wie "Gehalt Anna (Steuerklasse 4)" über das
    # Wort "Steuerklasse" mit "Steuer" matchen, das auf JEDER Abrechnung
    # vorkommt (unabhängig davon, wessen Abrechnung es ist).
    stop_words = {
        "gehalt", "lohn", "einkommen", "salär", "salary", "steuerklasse", "steuer",
        "brutto", "netto", "abrechnung", "beitrag", "beiträge", "konto", "bank",
        "freibetrag", "verdienst", "bezüge", "bezug", "personal", "geburtsdatum",
        "konfession", "auszahlung", "auszahlungsbetrag", "lohnsteuer", "kirchensteuer",
    }
    for row in rows:
        label_words = [
            w for w in re.findall(r"[A-Za-zÄÖÜäöüß]+", row["label"])
            if w.lower() not in stop_words and len(w) >= 3
        ]
        for w in label_words:
            for cand in name_candidates:
                if len(cand) < 3:
                    continue
                if w[:3].lower() != cand[:3].lower():
                    continue
                # Längenverhältnis-Schutz: "Steuer"(6) vs. "Steuerklasse"(12)
                # hätte dieselbe 3-Buchstaben-Vorsilbe, ist aber offensichtlich
                # ein anderes Wort — bei einem echten Namens-Kurzform-Paar wie
                # "Anna"(4)/"Anna Musterfrau"(13) liegen die Längen viel näher beieinander.
                shorter, longer = sorted((len(w), len(cand)))
                if shorter / longer < 0.55:
                    continue
                return {"id": row["id"], "label": row["label"]}
    return None


def _find_matching_contract(conn, provider: Optional[str], contract_number: Optional[str]) -> Optional[dict]:
    """Versucht, einen Beleg automatisch einem bestehenden Vertrag zuzuordnen.
    Eingriff durch den Nutzer soll nur nötig sein, wenn hier nichts Eindeutiges
    gefunden wird — deshalb wird bewusst nur bei klaren Treffern automatisch
    zugeordnet, bei Mehrdeutigkeit lieber gar nicht."""
    rows = conn.execute(
        "SELECT id, label, provider, contract_number, category_id FROM contracts WHERE status='active'"
    ).fetchall()

    # 1. Höchste Sicherheit: Vertragsnummer stimmt exakt überein (Groß-/Kleinschreibung, Leerzeichen egal)
    if contract_number:
        norm_target = re.sub(r"[\s\-./]", "", contract_number).lower()
        matches = [
            r for r in rows
            if r["contract_number"] and re.sub(r"[\s\-./]", "", r["contract_number"]).lower() == norm_target
        ]
        if len(matches) == 1:
            return {"id": matches[0]["id"], "label": matches[0]["label"], "confidence": "vertragsnummer"}

    # 2. Anbieter taucht eindeutig im Vertragspartner oder in der Bezeichnung auf
    if provider:
        provider_key = provider.lower()
        matches = [
            r for r in rows
            if (r["provider"] and r["provider"].lower() in provider_key)
            or (r["label"] and r["label"].lower() in provider_key)
            or (r["provider"] and provider_key in r["provider"].lower())
        ]
        if len(matches) == 1:
            return {"id": matches[0]["id"], "label": matches[0]["label"], "confidence": "anbieter"}

    return None


@app.post("/api/receipts/cleanup")
def cleanup_receipts(session=Depends(auth.require_full_auth)):
    """Löscht alle aktuell unbestätigten Belege (Datei + Datenbankeintrag) —
    z.B. um Test-Uploads aus der Entwicklung/Fehlersuche aufzuräumen."""
    conn = get_connection()
    result = _cleanup_unconfirmed_receipts(conn, max_age_hours=None)
    conn.close()
    return result


@app.get("/api/receipts/duplicates")
def list_receipt_duplicates(session=Depends(auth.require_full_auth)):
    """Findet Gruppen von Belegen mit identischem Dateiinhalt (gleicher Hash) —
    z.B. entstanden durch mehrfaches Hochladen derselben Rechnung mit
    unterschiedlicher Zuordnung beim Testen."""
    conn = get_connection()
    hashes = conn.execute(
        "SELECT file_hash FROM receipts WHERE file_hash IS NOT NULL "
        "GROUP BY file_hash HAVING COUNT(*) > 1"
    ).fetchall()

    groups = []
    for h in hashes:
        rows = conn.execute(
            """SELECT r.id, r.original_filename, r.uploaded_at, r.review_needed,
                      r.detected_amount, r.contract_id,
                      co.label AS contract_label, e.id AS expense_id, e.amount AS expense_amount
               FROM receipts r
               LEFT JOIN contracts co ON co.id = r.contract_id
               LEFT JOIN expenses e ON e.receipt_id = r.id
               WHERE r.file_hash = ?
               ORDER BY r.uploaded_at ASC""",
            (h["file_hash"],),
        ).fetchall()
        groups.append({"file_hash": h["file_hash"], "receipts": [dict(r) for r in rows]})
    conn.close()
    return {"groups": groups}


class DuplicateResolveIn(BaseModel):
    keep_id: int
    remove_ids: list[int]


@app.post("/api/receipts/duplicates/resolve")
def resolve_receipt_duplicates(payload: DuplicateResolveIn, session=Depends(auth.require_full_auth)):
    """Entfernt die angegebenen Duplikate (Datei + Datenbankeintrag + damit
    verknüpfte Ausgaben-Buchung), behält nur den gewählten 'keep_id'-Beleg.
    Prüft vorher, dass alle wirklich zur selben Datei gehören — sonst könnte
    aus Versehen ein eigenständiger, richtiger Beleg mitgelöscht werden."""
    conn = get_connection()
    keep = conn.execute("SELECT file_hash FROM receipts WHERE id=?", (payload.keep_id,)).fetchone()
    if not keep:
        conn.close()
        raise HTTPException(404, "Zu behaltender Beleg nicht gefunden.")

    removed = 0
    for rid in payload.remove_ids:
        row = conn.execute("SELECT * FROM receipts WHERE id=?", (rid,)).fetchone()
        if not row or row["file_hash"] != keep["file_hash"]:
            continue  # gehört nicht zur selben Duplikat-Gruppe -> überspringen, nicht anfassen
        file_path = BASE_DIR / row["stored_path"]
        if file_path.exists():
            file_path.unlink()
        conn.execute("DELETE FROM expenses WHERE receipt_id=?", (rid,))
        conn.execute("UPDATE contracts SET last_receipt_id=NULL WHERE last_receipt_id=?", (rid,))
        conn.execute("DELETE FROM receipts WHERE id=?", (rid,))
        removed += 1
    conn.commit()
    conn.close()
    return {"removed": removed}


@app.post("/api/contracts/{contract_id}/bulk-upload-receipts")
async def bulk_upload_receipts(contract_id: int, files: List[UploadFile] = File(...),
                                session=Depends(auth.require_full_auth)):
    """Für den initialen Import eines ganzen Stapels alter Belege zu EINEM
    bereits ausgewählten Vertrag auf einmal — anders als der Einzel-Upload
    läuft hier keine OCR-basierte Vertragserkennung (der Vertrag steht ja
    schon fest) und der Vertragsbetrag wird NIE aktualisiert, auch nicht
    durch die zeitlich neueste Datei im Stapel. Ein Rückblick-Import soll
    keine Aussage über den AKTUELLEN Betrag treffen (gleiches Prinzip wie
    beim Gehaltsabrechnungs-Sammelimport)."""
    conn = get_connection()
    contract = conn.execute(
        """SELECT co.label, co.provider, co.subcategory, c.name AS category_name, fm.name AS person_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.id = ?""",
        (contract_id,),
    ).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")

    parts = _contract_folder_parts(
        contract["category_name"], contract["subcategory"], contract["provider"],
        contract["label"], contract["person_name"],
    )
    final_dir = RECEIPTS_DIR.joinpath(*parts)
    final_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        existing = conn.execute(
            "SELECT id FROM receipts WHERE contract_id=? AND file_hash=?", (contract_id, file_hash)
        ).fetchone()
        if existing:
            results.append({"receipt_id": existing["id"], "filename": file.filename, "skipped": True})
            continue

        safe_name = re.sub(r"[^\w.\-]", "_", file.filename or "beleg")
        stored_path = final_dir / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{safe_name}"
        stored_path.write_bytes(content)

        cur = conn.execute(
            """INSERT INTO receipts (original_filename, stored_path, file_hash, contract_id, review_needed)
               VALUES (?,?,?,?,0)""",
            (file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash, contract_id),
        )
        results.append({"receipt_id": cur.lastrowid, "filename": file.filename, "skipped": False})

    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}


@app.post("/api/receipts/upload")
async def upload_receipt(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    file_hash = hashlib.sha256(content).hexdigest()

    conn = get_connection()

    # Jeder neue Upload verwirft automatisch alles, was von einem vorherigen
    # Upload noch offen/unbestätigt in der Maske stand — die Beleg-Maske ist
    # ein Zwischenspeicher, kein Ablageort: wer nicht auf "Bestätigen"
    # gedrückt hat, hat es damit implizit verworfen. Kein manueller
    # Aufräum-Knopf nötig, und die eben hochgeladene Datei kann dadurch nie
    # aus Versehen mitgelöscht werden (sie existiert ja noch gar nicht).
    _cleanup_unconfirmed_receipts(conn, max_age_hours=None)

    # Duplikat-Prüfung: wurde exakt diese Datei (byteidentisch) schon einmal
    # BESTÄTIGT importiert? Dann wird der Upload direkt blockiert statt nur
    # gewarnt — ein zweiter, unbestätigter Test-Upload wurde durch die
    # Bereinigung oben ohnehin gerade schon entfernt, kann hier also gar
    # nicht mehr als Duplikat auftauchen.
    existing = conn.execute(
        """SELECT r.id, r.uploaded_at, r.detected_amount, co.label AS contract_label
           FROM receipts r LEFT JOIN contracts co ON co.id = r.contract_id
           WHERE r.file_hash = ? AND r.review_needed = 0
           ORDER BY r.uploaded_at DESC LIMIT 1""",
        (file_hash,),
    ).fetchone()
    if existing:
        conn.close()
        target = f" und {existing['contract_label']!r} zugeordnet" if existing["contract_label"] else ""
        raise HTTPException(
            409,
            f"Diese exakte Datei wurde bereits am {existing['uploaded_at']} importiert{target}. "
            "Falls das wirklich ein zweiter, eigenständiger Beleg ist (z.B. eine neue, andere "
            "Rechnung), kann es nicht dieselbe Datei sein — bitte prüfen, ob die richtige Datei "
            "ausgewählt wurde.",
        )
    conn.close()

    today = datetime.now()
    safe_stem = re.sub(r"[^\w.-]", "_", Path(file.filename or "beleg").stem)[:80] or "beleg"
    suffix = Path(file.filename or "").suffix or ".jpg"
    filename = f"{today.strftime('%Y%m%d%H%M%S')}_{safe_stem}{suffix}"

    # Solange noch kein Vertrag zugeordnet ist (das passiert erst beim Bestätigen),
    # landet die Datei in einem Zwischenablage-Ordner nach bestem Kategorie-Tipp.
    tmp_path = RECEIPTS_DIR / "_unbestaetigt" / filename
    tmp_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)

    # Lokale OCR-Erkennung (kein Cloud-Aufruf, siehe ocr.py). Schlägt sie fehl,
    # wird der Beleg trotzdem gespeichert — nur ohne automatische Erkennung.
    result = extract_receipt_data(tmp_path)

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO receipts
           (original_filename, stored_path, file_hash, ocr_text, detected_amount,
            detected_provider, detected_date, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(tmp_path.relative_to(BASE_DIR)), file_hash, result.get("raw_text"),
         result.get("amount"), result.get("provider"),
         result["date"].isoformat() if result.get("date") else None),
    )
    receipt_id = cur.lastrowid
    conn.commit()

    matched = _find_matching_contract(conn, result.get("provider"), result.get("contract_number"))
    conn.close()

    # Nur dort um Eingriff bitten, wo wirklich etwas unklar ist: fehlender
    # Betrag, oder keine eindeutige automatische Zuordnung möglich.
    needs_attention = []
    if result.get("amount") is None:
        needs_attention.append("Betrag")
    if not matched:
        needs_attention.append("Zuordnung zu einem Vertrag")

    if result.get("ocr_error"):
        note = result["ocr_error"] + " Der Beleg wurde trotzdem gespeichert — bitte Angaben manuell eintragen."
    elif needs_attention:
        note = "Bitte kurz prüfen: " + ", ".join(needs_attention) + "."
    else:
        note = f"Automatisch erkannt und {matched['label']!r} zugeordnet — bitte nur kurz bestätigen."

    return {
        "receipt_id": receipt_id,
        "stored_path": str(tmp_path.relative_to(BASE_DIR)),
        "detected": result,
        "matched_contract": matched,
        "needs_attention": needs_attention,
        "note": note,
    }


class ReceiptConfirmIn(BaseModel):
    contract_id: Optional[int] = None
    asset_id: Optional[int] = None       # Alternative zu contract_id: Beleg gehört zu einem
                                          # Vermögenswert (Kontoauszug, Depotauszug, Immobilie)
    pension_account_id: Optional[int] = None  # Alternative: Beleg gehört zu einem Rentenkonto
                                          # (Vorsorge) — landet dann in pension_documents statt receipts
    amount: Optional[float] = None       # überschreibt den erkannten Betrag, falls OCR falsch lag
    provider: Optional[str] = None
    contract_number: Optional[str] = None
    link: Optional[str] = None
    expense_date: Optional[date] = None
    update_expense: bool = True          # False = Beleg nur ablegen, keine Ausgabe/Betrag buchen
                                          # (z.B. reine Benachrichtigungen ohne Zahlung, wie eine
                                          # Zählerwechsel-Mitteilung)


@app.post("/api/receipts/{receipt_id}/confirm")
def confirm_receipt(receipt_id: int, payload: ReceiptConfirmIn,
                     session=Depends(auth.require_full_auth)):
    if not payload.contract_id and not payload.asset_id and not payload.pension_account_id:
        raise HTTPException(400, "Ein Beleg muss einem Vertrag, Vermögenswert oder Rentenkonto zugeordnet werden.")

    conn = get_connection()
    receipt = conn.execute("SELECT * FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")

    if payload.pension_account_id:
        # Rentenkonto-Dokumente leben in einer eigenen Tabelle
        # (pension_documents), nicht in receipts — die Datei wird dorthin
        # verschoben und die ursprüngliche receipts-Zeile entfernt, statt
        # nur ein Fremdschlüssel-Feld umzubiegen.
        account = conn.execute("SELECT id, current_value FROM pension_accounts WHERE id=?", (payload.pension_account_id,)).fetchone()
        if not account:
            conn.close()
            raise HTTPException(400, "Das zugeordnete Rentenkonto existiert nicht (mehr).")

        final_amount = payload.amount if payload.amount is not None else receipt["detected_amount"]
        old_path = BASE_DIR / receipt["stored_path"]
        PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^\w.-]", "_", receipt["original_filename"] or "dokument")[:80]
        stored_name = f"{payload.pension_account_id}_{receipt['file_hash'][:10] if receipt['file_hash'] else 'x'}_{safe_name}"
        new_path = PENSION_DOCS_DIR / stored_name
        if old_path.exists():
            old_path.rename(new_path)

        conn.execute(
            "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
            (payload.pension_account_id, receipt["original_filename"], str(new_path.relative_to(BASE_DIR)), receipt["file_hash"]),
        )
        conn.execute("DELETE FROM receipts WHERE id=?", (receipt_id,))
        if payload.update_expense and final_amount is not None:
            conn.execute("UPDATE pension_accounts SET current_value=? WHERE id=?", (final_amount, payload.pension_account_id))
        conn.commit()
        conn.close()
        return {"status": "confirmed"}

    if payload.asset_id:
        asset = conn.execute("SELECT type, label FROM assets WHERE id=?", (payload.asset_id,)).fetchone()
        if not asset:
            conn.close()
            raise HTTPException(400, "Der zugeordnete Vermögenswert existiert nicht (mehr).")

        final_amount = payload.amount if payload.amount is not None else receipt["detected_amount"]
        stored_path = receipt["stored_path"]
        final_dir = RECEIPTS_DIR / "_vermoegen" / re.sub(r"[^\w\-]", "_", asset["label"])
        final_dir.mkdir(parents=True, exist_ok=True)
        old_path = BASE_DIR / stored_path
        new_path = final_dir / old_path.name
        if old_path.exists():
            old_path.rename(new_path)
            stored_path = str(new_path.relative_to(BASE_DIR))

        update_fields = {"asset_id": payload.asset_id, "review_needed": 0}
        conn.execute(
            "UPDATE receipts SET stored_path=?, asset_id=?, review_needed=0 WHERE id=?",
            (stored_path, payload.asset_id, receipt_id),
        )
        if payload.update_expense and final_amount is not None:
            conn.execute("UPDATE assets SET current_value=?, updated_at=? WHERE id=?",
                         (final_amount, datetime.now().isoformat(), payload.asset_id))
        conn.commit()
        conn.close()
        return {"status": "confirmed"}

    if not payload.contract_id:
        raise HTTPException(400, "Ein Beleg muss einem Vertrag zugeordnet werden.")

    conn = get_connection()
    receipt = conn.execute("SELECT * FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")

    contract_exists = conn.execute("SELECT 1 FROM contracts WHERE id=?", (payload.contract_id,)).fetchone()
    if not contract_exists:
        conn.close()
        raise HTTPException(400, "Der zugeordnete Vertrag existiert nicht (mehr).")

    final_amount = payload.amount if payload.amount is not None else (receipt["detected_amount"] or 0)
    final_provider = payload.provider or receipt["detected_provider"] or receipt["original_filename"]
    final_date = (payload.expense_date.isoformat() if payload.expense_date
                  else receipt["detected_date"] or date.today().isoformat())
    contract_id = payload.contract_id

    if payload.update_expense:
        conn.execute(
            """INSERT INTO expenses (contract_id, label, amount, date, receipt_id)
               VALUES (?,?,?,?,?)""",
            (contract_id, final_provider, final_amount, final_date, receipt_id),
        )

    stored_path = receipt["stored_path"]

    if contract_id:
        contract = conn.execute(
            """SELECT co.label, co.provider, co.subcategory, c.name AS category_name, fm.name AS person_name
               FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
               LEFT JOIN family_members fm ON fm.id = co.person_id
               WHERE co.id = ?""",
            (contract_id,),
        ).fetchone()

        if contract:
            # Datei aus dem Zwischenablage-Ordner in die endgültige Struktur
            # verschieben: Rubrik (→ Unterrubrik bei Haus, → Person falls
            # zugeordnet) → ein Ordner pro Vertrag. Das passiert IMMER,
            # unabhängig von update_expense — ein Beleg soll beim richtigen
            # Vertrag abgelegt sein, auch wenn er keine Zahlung auslöst
            # (z.B. eine reine Benachrichtigung ohne Rechnungsbetrag).
            # Dieselbe Funktion wie beim Archivieren/Wiederherstellen, damit
            # es nur eine einzige Stelle mit dieser Logik gibt.
            parts = _contract_folder_parts(
                contract["category_name"], contract["subcategory"], contract["provider"],
                contract["label"], contract["person_name"],
            )

            final_dir = RECEIPTS_DIR.joinpath(*parts)
            final_dir.mkdir(parents=True, exist_ok=True)
            old_path = BASE_DIR / stored_path
            new_path = final_dir / old_path.name
            if old_path.exists():
                old_path.rename(new_path)
                stored_path = str(new_path.relative_to(BASE_DIR))

        # Vertragsnummer/Anbieter/Link sind reine Stammdaten-Korrekturen, unabhängig
        # von einer Zahlung — die werden immer übernommen, wenn mitgegeben. Ebenso
        # wird der Beleg immer als "letzter Beleg" hinterlegt (für den "📎 Beleg
        # ansehen"-Link), auch wenn er keine Zahlung auslöst — er soll ja trotzdem
        # auffindbar beim Vertrag liegen. Nur der Betrag selbst wird ausgespart,
        # wenn dieser Beleg keine echte Ausgabe darstellt (update_expense=False) —
        # sonst würde z.B. eine reine Zählerwechsel-Mitteilung ohne Rechnungsbetrag
        # den Vertragsbetrag überschreiben.
        update_fields = {"last_receipt_id": receipt_id}
        if payload.update_expense:
            update_fields["amount"] = final_amount
            update_fields["source"] = "foto"
        if payload.contract_number:
            update_fields["contract_number"] = payload.contract_number
        if payload.link:
            update_fields["link"] = payload.link
        if payload.provider:
            update_fields["provider"] = payload.provider
        update_fields["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k}=?" for k in update_fields)
        conn.execute(f"UPDATE contracts SET {set_clause} WHERE id=?",
                     (*update_fields.values(), contract_id))

    conn.execute("UPDATE receipts SET review_needed=0, contract_id=?, stored_path=? WHERE id=?",
                 (contract_id, stored_path, receipt_id))

    conn.commit()
    conn.close()
    return {"status": "confirmed"}


@app.get("/api/receipts/{receipt_id}/file")
def get_receipt_file(receipt_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    receipt = conn.execute("SELECT stored_path, original_filename FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    conn.close()
    if not receipt:
        raise HTTPException(404, "Beleg nicht gefunden")
    file_path = BASE_DIR / receipt["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Beleg-Datei fehlt auf der Festplatte")
    return FileResponse(
        file_path, filename=receipt["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


class ReceiptReassignIn(BaseModel):
    asset_id: int


@app.patch("/api/receipts/{receipt_id}/reassign-asset")
def reassign_receipt_asset(receipt_id: int, payload: ReceiptReassignIn,
                            session=Depends(auth.require_full_auth)):
    """Ordnet einen bereits hochgeladenen Beleg einem ANDEREN Vermögenswert
    zu — z.B. wenn beim Bestätigen versehentlich der falsche Vermögenswert
    gewählt wurde. Verschiebt auch die physische Datei in den Ordner des
    neuen Vermögenswerts, damit die Ablage konsistent bleibt."""
    conn = get_connection()
    receipt = conn.execute("SELECT stored_path FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")
    asset = conn.execute("SELECT label FROM assets WHERE id=?", (payload.asset_id,)).fetchone()
    if not asset:
        conn.close()
        raise HTTPException(400, "Der Ziel-Vermögenswert existiert nicht (mehr).")

    final_dir = RECEIPTS_DIR / "_vermoegen" / re.sub(r"[^\w\-]", "_", asset["label"])
    final_dir.mkdir(parents=True, exist_ok=True)
    old_path = BASE_DIR / receipt["stored_path"]
    new_path = final_dir / old_path.name
    stored_path = receipt["stored_path"]
    if old_path.exists():
        old_path.rename(new_path)
        stored_path = str(new_path.relative_to(BASE_DIR))

    conn.execute(
        "UPDATE receipts SET asset_id=?, stored_path=? WHERE id=?",
        (payload.asset_id, stored_path, receipt_id),
    )
    conn.commit()
    conn.close()
    return {"status": "reassigned"}


@app.delete("/api/receipts/{receipt_id}")
def delete_receipt(receipt_id: int, session=Depends(auth.require_full_auth)):
    """Entfernt einen einzelnen Beleg aus der 'Alle Belege'-Liste — Datei
    UND Datenbankeintrag. Die verknüpfte Ausgabe bleibt bewusst erhalten
    (der Beleg war nur ihr Nachweis, nicht ihre einzige Existenzgrundlage);
    nur die last_receipt_id-Referenz wird aufgeräumt, falls sie hierher zeigte."""
    conn = get_connection()
    receipt = conn.execute("SELECT stored_path FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")
    file_path = BASE_DIR / receipt["stored_path"]
    file_path.unlink(missing_ok=True)
    conn.execute("UPDATE contracts SET last_receipt_id=NULL WHERE last_receipt_id=?", (receipt_id,))
    conn.execute("UPDATE expenses SET receipt_id=NULL WHERE receipt_id=?", (receipt_id,))
    conn.execute("DELETE FROM receipts WHERE id=?", (receipt_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


# ---------- Chatbot (lokal, über Ollama) ----------

class ChatIn(BaseModel):
    question: str


@app.post("/api/chat")
def chat(payload: ChatIn, session=Depends(auth.require_full_auth)):
    answer = ask_chatbot(payload.question)
    return {"answer": answer}


# ---------- Energy Monitor ----------

def _get_meter_settings(conn, meter_type: str) -> dict:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (f"meter_settings_{meter_type}",)).fetchone()
    defaults = meters.DEFAULT_SETTINGS.get(meter_type, {})
    if not row:
        return dict(defaults)
    saved = json.loads(row["value"])
    return {**defaults, **saved}


def _get_readings(conn, meter_type: str) -> list:
    rows = conn.execute(
        "SELECT id, reading_date, value, is_new_meter, note, receipt_id FROM meter_readings "
        "WHERE meter_type=? ORDER BY reading_date ASC", (meter_type,),
    ).fetchall()
    return [dict(r) for r in rows]


def _validate_meter_type(meter_type: str):
    if meter_type not in meters.METER_TYPES:
        raise HTTPException(404, f"Unbekannter Zählertyp: {meter_type}")


@app.get("/api/meters/overview")
def meters_overview(session=Depends(auth.require_full_auth)):
    """Kompakte Übersicht aller Zähler fürs Energy-Monitor-Dashboard."""
    conn = get_connection()
    result = []
    for meter_type in meters.METER_TYPES:
        readings = _get_readings(conn, meter_type)
        if not readings:
            continue  # Zähler, für die es noch keine einzige Ablesung gibt, nicht anzeigen
        settings_ = _get_meter_settings(conn, meter_type)
        settlement = meters.compute_settlement(meter_type, readings, settings_)
        result.append({
            "meter_type": meter_type,
            "label": meters.METER_META[meter_type]["label"],
            "icon": meters.METER_META[meter_type]["icon"],
            "unit": meters.METER_META[meter_type]["unit"],
            "latest_reading": readings[-1],
            "current_daily_rate": meters.current_daily_rate(readings),
            "settlement": settlement,
        })
    conn.close()
    return {"meters": result}


@app.get("/api/meters/{meter_type}/readings")
def get_meter_readings(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"readings": readings}


class MeterReadingIn(BaseModel):
    reading_date: date
    value: float
    is_new_meter: bool = False
    note: Optional[str] = None
    receipt_id: Optional[int] = None


@app.post("/api/meters/{meter_type}/readings")
def add_meter_reading(meter_type: str, payload: MeterReadingIn, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    existing = conn.execute(
        "SELECT id FROM meter_readings WHERE meter_type=? AND reading_date=?",
        (meter_type, payload.reading_date.isoformat()),
    ).fetchone()
    if existing:
        conn.close()
        raise HTTPException(409, f"Für den {payload.reading_date.isoformat()} liegt bei diesem Zähler bereits eine Ablesung vor.")
    cur = conn.execute(
        """INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note, receipt_id)
           VALUES (?,?,?,?,?,?)""",
        (meter_type, payload.reading_date.isoformat(), payload.value,
         int(payload.is_new_meter), payload.note, payload.receipt_id),
    )
    reading_id = cur.lastrowid
    if payload.receipt_id:
        conn.execute("UPDATE receipts SET review_needed=0 WHERE id=?", (payload.receipt_id,))
    conn.commit()
    conn.close()
    return {"id": reading_id, "status": "created"}


@app.delete("/api/meters/{meter_type}/readings/{reading_id}")
def delete_meter_reading(meter_type: str, reading_id: int, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    conn.execute("DELETE FROM meter_readings WHERE id=? AND meter_type=?", (reading_id, meter_type))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.get("/api/meters/{meter_type}/settings")
def get_meter_settings_endpoint(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    settings_ = _get_meter_settings(conn, meter_type)
    conn.close()
    return settings_


@app.put("/api/meters/{meter_type}/settings")
def put_meter_settings(meter_type: str, payload: dict, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    current = _get_meter_settings(conn, meter_type)
    current.update(payload)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (f"meter_settings_{meter_type}", json.dumps(current)),
    )
    conn.commit()
    conn.close()
    return current


@app.get("/api/meters/{meter_type}/monthly")
def get_meter_monthly(meter_type: str, session=Depends(auth.require_full_auth)):
    """Monatsverbrauch fürs Diagramm — inkl. Prognose fürs laufende Jahr für
    Monate ohne echte Ablesung/Import."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    monthly = meters.get_effective_monthly(meter_type, readings, pv_monthly)
    rate = meters.current_daily_rate(readings)
    today = date.today()
    forecast = meters.forecast_missing_months(
        monthly, rate, date(today.year, 1, 1), date(today.year, 12, 31)
    )
    return {"monthly": monthly, "forecast": forecast, "current_daily_rate": rate}


@app.get("/api/meters/{meter_type}/kpis")
def get_meter_kpis(meter_type: str, session=Depends(auth.require_full_auth)):
    """Die 5 KPI-Chips für die Detailseite (Letzter Stand, Tagesrate,
    optimaler Abschlag, erwartete Differenz, Jahresprognose)."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"chips": meters.compute_kpi_chips(meter_type, readings, settings_, pv_monthly)}


def _refresh_actual_temperatures_if_due():
    """Holt beim Serverstart automatisch aktuelle Monatstemperaturen nach —
    aber höchstens einmal pro Tag, damit ein mehrfacher Neustart am selben
    Tag nicht unnötig oft die (kostenlose, aber fremde) Wetter-API
    beansprucht. Läuft komplett im Hintergrund; ein Fehlschlag (kein
    Standort hinterlegt, kein Netz) darf den App-Start nie verzögern oder
    stören."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        return

    last_row = conn.execute("SELECT value FROM settings WHERE key='weather_last_fetched'").fetchone()
    last_fetched = json.loads(last_row["value"]) if last_row else None
    today_str = date.today().isoformat()
    if last_fetched == today_str:
        conn.close()
        return

    import threading

    def _do_fetch():
        fresh = meters.fetch_actual_monthly_temperatures(location)
        if not fresh:
            return
        c = get_connection()
        existing_row = c.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
        existing = json.loads(existing_row["value"]) if existing_row else {}
        existing.update(fresh)  # neue/aktualisierte Monate überschreiben, ältere bleiben erhalten
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(existing),),
        )
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(today_str),),
        )
        c.commit()
        c.close()

    # Im Hintergrund, damit ein langsamer/fehlender Netzwerkzugriff den
    # eigentlichen Serverstart nicht blockiert.
    threading.Thread(target=_do_fetch, daemon=True).start()
    conn.close()


@app.post("/api/meters/gas/temperature/refresh")
def refresh_gas_temperature(session=Depends(auth.require_full_auth)):
    """Manueller Sofort-Abruf (z.B. nach dem erstmaligen Eintragen eines
    Standorts, ohne auf den nächsten Neustart warten zu müssen)."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        raise HTTPException(400, "Kein Standort in den Einstellungen hinterlegt.")

    fresh = meters.fetch_actual_monthly_temperatures(location)
    if not fresh:
        conn.close()
        return {"status": "error", "error": "Kein Ergebnis — Standort nicht gefunden oder Wetterdienst nicht erreichbar."}

    existing_row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    existing = json.loads(existing_row["value"]) if existing_row else {}
    existing.update(fresh)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(existing),),
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(date.today().isoformat()),),
    )
    conn.commit()
    conn.close()
    return {"status": "ok", "months_updated": len(fresh)}


@app.get("/api/meters/gas/temperature")
def get_gas_temperature(session=Depends(auth.require_full_auth)):
    """Klimamittel (DWD, statisch) + tatsächliche Monatstemperaturen für die
    Temperatur-Kurve auf der Gas-Seite."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    conn.close()
    actual = json.loads(row["value"]) if row else {}
    return {"dwd_climate_avg": meters.DWD_CLIMATE_AVG, "actual": actual}


@app.get("/api/meters/{meter_type}/intervals")
def get_meter_intervals(meter_type: str, session=Depends(auth.require_full_auth)):
    """Ablesungen mit Delta/Tage/Tagesrate für die Detailtabelle."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"intervals": meters.compute_reading_intervals(readings)}


@app.get("/api/meters/{meter_type}/cumulative")
def get_meter_cumulative(meter_type: str, session=Depends(auth.require_full_auth)):
    """Kumulative Ist-Kosten vs. Abschlag vs. optimaler Abschlag übers Jahr —
    nicht sinnvoll für Einspeisung (keine Kosten, sondern Erlös)."""
    _validate_meter_type(meter_type)
    if meter_type == "elec_out":
        raise HTTPException(400, "Kumulativ-Ansicht ist nur für Gas und Strombezug verfügbar.")
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_cumulative_cost(meter_type, readings, settings_, pv_monthly)}


class PVSystemSpecIn(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: date
    note: Optional[str] = None


class PVSystemSpecPatch(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: Optional[date] = None
    note: Optional[str] = None


@app.get("/api/pv/system-specs")
def list_pv_system_specs(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM pv_system_specs ORDER BY valid_from").fetchall()
    conn.close()

    today = date.today().isoformat()
    specs = [dict(r) for r in rows]
    # Aktuell gültigen und (falls vorhanden) als nächstes anstehenden
    # Ausbauschritt markieren — nützlich für die geplante Erweiterung, damit
    # die Oberfläche "ab wann gilt was" nicht selbst nachrechnen muss.
    current = None
    upcoming = []
    for s in specs:
        if s["valid_from"] <= today:
            current = s
        else:
            upcoming.append(s)
    return {"specs": specs, "current": current, "upcoming": upcoming}


@app.post("/api/pv/system-specs")
def create_pv_system_spec(payload: PVSystemSpecIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO pv_system_specs (installed_year, kwp, battery_kwh, valid_from, note)
           VALUES (?,?,?,?,?)""",
        (payload.installed_year, payload.kwp, payload.battery_kwh, payload.valid_from, payload.note),
    )
    conn.commit()
    sid = cur.lastrowid
    conn.close()
    return {"id": sid, "status": "created"}


@app.patch("/api/pv/system-specs/{spec_id}")
def update_pv_system_spec(spec_id: int, patch: PVSystemSpecPatch, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    if not fields:
        conn.close()
        return {"status": "unchanged"}
    fields["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE pv_system_specs SET {set_clause} WHERE id=?", (*fields.values(), spec_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/pv/system-specs/{spec_id}")
def delete_pv_system_spec(spec_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    conn.execute("DELETE FROM pv_system_specs WHERE id=?", (spec_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.get("/api/pv/autarkie")
def get_pv_autarkie(session=Depends(auth.require_full_auth)):
    """Autarkiegrad je Monat (PV-Eigenverbrauchsanteil) — für den
    Autarkie-Chart auf der Strom-Detailseite."""
    conn = get_connection()
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_autarkie_series(pv_monthly)}


@app.get("/api/meters/{meter_type}/settlement")
def get_meter_settlement(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    if not readings:
        raise HTTPException(400, "Noch keine Ablesungen für diesen Zähler erfasst.")
    return meters.compute_settlement(meter_type, readings, settings_, pv_monthly)


# ---------- Energy Monitor Dashboard: vollständige Übersicht ----------

def _all_readings_and_settings(conn) -> tuple:
    readings_by_type = {mt: _get_readings(conn, mt) for mt in meters.METER_TYPES}
    settings_by_type = {mt: _get_meter_settings(conn, mt) for mt in meters.METER_TYPES}
    return readings_by_type, settings_by_type


def _get_pv_monthly(conn) -> list:
    rows = conn.execute(
        "SELECT key, pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_monthly ORDER BY key"
    ).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/energy/overview")
def energy_overview(range: str = "ytd", session=Depends(auth.require_full_auth)):
    """Die vier KPI-Karten (Gas, Bezug, Einspeisung, PV-Ertrag) für den
    Energy-Monitor-Dashboard-Kopf, für den gewählten Zeitraum."""
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    cards = meters.compute_overview_cards(readings_by_type, settings_by_type, pv_monthly, range)
    return {"ranges": meters.RANGES, **cards}


@app.get("/api/energy/cost-trend")
def energy_cost_trend(range: str = "ytd", session=Depends(auth.require_full_auth)):
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_cost_trend(readings_by_type, settings_by_type, pv_monthly, range)}


@app.get("/api/energy/settlement")
def energy_settlement(session=Depends(auth.require_full_auth)):
    """Vollständige Jahresabrechnung — Gas, Strombezug und Einspeisung mit
    Fälligkeits-Countdown, für den Jahresabrechnung-Block im Dashboard."""
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return meters.compute_full_settlement(readings_by_type, settings_by_type, pv_monthly)


class MeterSettlementIn(BaseModel):
    meter_type: str
    settlement_date: date
    note: Optional[str] = None


@app.get("/api/energy/settlements")
def list_meter_settlements(session=Depends(auth.require_full_auth)):
    """Alle manuell erfassten Abrechnungszeitpunkte, je Zählerseite —
    unabhängig von der kalenderjahr-basierten Jahresabrechnung oben. Der
    jeweils letzte Eintrag pro Zählerseite dient als Reset-Basis für
    'Verbrauch seit der Abrechnung'."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/energy/settlements")
def create_meter_settlement(payload: MeterSettlementIn, session=Depends(auth.require_full_auth)):
    if payload.meter_type not in meters.METER_TYPES:
        raise HTTPException(400, f"Ungültiger Zählertyp: {payload.meter_type}")
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO meter_settlements (meter_type, settlement_date, note) VALUES (?,?,?)",
        (payload.meter_type, payload.settlement_date.isoformat(), payload.note),
    )
    conn.commit()
    conn.close()
    return {"id": cur.lastrowid, "status": "created"}


@app.delete("/api/energy/settlements/{settlement_id}")
def delete_meter_settlement(settlement_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM meter_settlements WHERE id=?", (settlement_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Abrechnungszeitpunkt nicht gefunden")
    conn.execute("DELETE FROM meter_settlements WHERE id=?", (settlement_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.get("/api/energy/consumption-since-settlement")
def consumption_since_settlement_overview(session=Depends(auth.require_full_auth)):
    """Verbrauch seit dem jeweils letzten manuell erfassten Abrechnungs-
    zeitpunkt, je Zählerseite — ergänzt die Jahresabrechnung oben um einen
    Reset-Punkt, der nicht an den Kalenderjahreswechsel gebunden ist."""
    conn = get_connection()
    readings_by_type, _ = _all_readings_and_settings(conn)
    settlements = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()

    result = {}
    for mt in meters.METER_TYPES:
        latest_settlement = next((s for s in settlements if s["meter_type"] == mt), None)
        if not latest_settlement:
            result[mt] = None
            continue
        settlement_date = date.fromisoformat(latest_settlement["settlement_date"])
        readings = [dict(r) for r in (readings_by_type.get(mt) or [])]
        since = meters.consumption_since_settlement(readings, settlement_date)
        if since:
            since["settlement_note"] = latest_settlement["note"]
        result[mt] = since
    return result


@app.get("/api/pv/monthly")
def get_pv_monthly(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    data = _get_pv_monthly(conn)
    conn.close()
    return {"months": data, "plant": meters.PV_PLANT_DEFAULTS}


class PVMonthIn(BaseModel):
    key: str
    pv: float = 0
    bezug: float = 0
    einsp: float = 0
    batt_lad: float = 0
    batt_ent: float = 0
    gesamt: float = 0


@app.put("/api/pv/monthly/{key}")
def upsert_pv_month(key: str, payload: PVMonthIn, session=Depends(auth.require_full_auth)):
    if not re.match(r"^\d{4}-\d{2}$", key):
        raise HTTPException(400, "Ungültiger Monatsschlüssel (erwartet YYYY-MM).")
    conn = get_connection()
    conn.execute(
        """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
             einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
             gesamt=excluded.gesamt""",
        (key, payload.pv, payload.bezug, payload.einsp, payload.batt_lad, payload.batt_ent, payload.gesamt),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


@app.delete("/api/pv/monthly/{key}")
def delete_pv_month(key: str, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM pv_monthly WHERE key=?", (key,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@app.post("/api/pv/import")
async def import_pv_sungrow(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    """Sungrow-Jahresbericht (iSolarCloud-Export, XLSX) einlesen — Spalten
    'Zeit', 'PV-Ertrag(kWh)', 'Netzbezug(kWh)', 'Einspeisung(kWh)',
    'Batt.-Ladung(kWh)', 'Batt.-Entladung(kWh)', 'Gesamtverbrauch(kWh)'.
    Bestehende Monate werden aktualisiert, neue Monate ergänzt."""
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    tmp_path = SMART_IMPORT_STAGING / f"pv_{hashlib.sha256(content).hexdigest()[:12]}.xlsx"
    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)
    try:
        import pandas as pd
        df = pd.read_excel(tmp_path, engine="openpyxl")
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise HTTPException(400, f"Datei konnte nicht gelesen werden: {e}")
    tmp_path.unlink(missing_ok=True)

    cols = df.columns.tolist()

    def find_col(fragment):
        return next((c for c in cols if fragment.lower() in str(c).lower()), None)

    zeit_col = find_col("zeit")
    pv_col, bezug_col, einsp_col = find_col("pv-ertrag"), find_col("netzbezug"), find_col("einspeisung")
    batt_lad_col, batt_ent_col = find_col("batt.-ladung"), find_col("batt.-entladung")
    ges_col = find_col("gesamtverbrauch")

    if not zeit_col or not pv_col or not einsp_col:
        raise HTTPException(
            400,
            "Diese Datei sieht nicht wie ein Sungrow-Jahresbericht aus — erwartet werden "
            "Spalten wie 'Zeit', 'PV-Ertrag(kWh)', 'Einspeisung(kWh)', 'Netzbezug(kWh)'.",
        )

    conn = get_connection()
    added, updated = 0, 0
    for _, row in df.iterrows():
        zeit = str(row[zeit_col]).strip()
        m = re.match(r"^(\d{4})-(\d{1,2})$", zeit)
        if not m:
            continue
        key = f"{m.group(1)}-{int(m.group(2)):02d}"

        def num(col):
            if not col or col not in df.columns:
                return 0.0
            try:
                return float(str(row[col]).replace(",", "."))
            except (ValueError, TypeError):
                return 0.0

        existing = conn.execute("SELECT key FROM pv_monthly WHERE key=?", (key,)).fetchone()
        conn.execute(
            """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                 einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
                 gesamt=excluded.gesamt""",
            (key, num(pv_col), num(bezug_col), num(einsp_col), num(batt_lad_col), num(batt_ent_col), num(ges_col)),
        )
        if existing:
            updated += 1
        else:
            added += 1
    conn.commit()
    conn.close()
    return {"added": added, "updated": updated}


@app.post("/api/meters/{meter_type}/upload")
async def upload_meter_bill(meter_type: str, file: UploadFile = File(...),
                             session=Depends(auth.require_full_auth)):
    """Foto/PDF einer Ablesekarte oder Abrechnung einlesen — analog zum
    Beleg-Upload bei den Ausgaben: lokale OCR-Erkennung, Vorschlag zur
    Bestätigung, kein automatisches Speichern eines Zählerstands."""
    _validate_meter_type(meter_type)
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    file_hash = hashlib.sha256(content).hexdigest()
    conn = get_connection()
    existing = conn.execute(
        "SELECT id, uploaded_at FROM receipts WHERE file_hash=? AND review_needed=0",
        (file_hash,),
    ).fetchone()
    if existing:
        conn.close()
        raise HTTPException(409, f"Diese exakte Datei wurde bereits am {existing['uploaded_at']} importiert.")
    _cleanup_unconfirmed_receipts(conn, max_age_hours=None)
    conn.close()

    today = datetime.now()
    safe_stem = re.sub(r"[^\w.-]", "_", Path(file.filename or "zaehlerstand").stem)[:80] or "zaehlerstand"
    suffix = Path(file.filename or "").suffix or ".jpg"
    filename = f"{today.strftime('%Y%m%d%H%M%S')}_{safe_stem}{suffix}"
    tmp_path = RECEIPTS_DIR / "_unbestaetigt" / filename
    tmp_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)

    result = extract_receipt_data(tmp_path)

    # Aus dem erkannten Text zusätzlich nach einem plausiblen Zählerstand
    # suchen (reine Zahl, evtl. mit Tausenderpunkt, in der Nähe von "Zähler-
    # stand"/"Stand"/"m³"/"kWh") — Betrag bleibt die primäre OCR-Info, der
    # Zählerstand ist ein zusätzlicher Bonus-Fund, kein Muss.
    suggested_value = None
    if result.get("raw_text"):
        m = re.search(
            r"(?:z[äa]hlerstand|stand|z[äa]hlerstd)[^\d]{0,15}(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,3})?)",
            result["raw_text"], re.IGNORECASE,
        )
        if m:
            try:
                suggested_value = float(m.group(1).replace(".", "").replace(",", "."))
            except ValueError:
                suggested_value = None

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO receipts
           (original_filename, stored_path, file_hash, ocr_text, detected_amount,
            detected_provider, detected_date, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(tmp_path.relative_to(BASE_DIR)), file_hash, result.get("raw_text"),
         result.get("amount"), result.get("provider"),
         result["date"].isoformat() if result.get("date") else None),
    )
    receipt_id = cur.lastrowid
    conn.commit()
    conn.close()

    return {
        "receipt_id": receipt_id,
        "suggested_value": suggested_value,
        "suggested_date": result["date"].isoformat() if result.get("date") else None,
        "detected": result,
        "note": ("Zählerstand erkannt — bitte prüfen." if suggested_value
                  else "Kein Zählerstand automatisch erkannt — bitte manuell eintragen."),
    }


# ---------- Intelligenter Datei-Import (CSV/XLSX/ODS, Ollama-gestützt) ----------

SMART_IMPORT_STAGING = BASE_DIR / "data" / "smart_import_staging"
SMART_IMPORT_TARGETS = ("expenses", "income", "contracts", "pv_monthly", "meter_readings", "assets")


def _validate_import_target(target: str):
    if target not in SMART_IMPORT_TARGETS:
        raise HTTPException(404, f"Unbekanntes Import-Ziel: {target}")


@app.post("/api/smart-import/{target}/analyze")
async def smart_import_analyze(target: str, file: UploadFile = File(...),
                                session=Depends(auth.require_full_auth)):
    _validate_import_target(target)
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    suffix = Path(file.filename or "").suffix.lower() or ".csv"
    staging_id = hashlib.sha256(content + target.encode()).hexdigest()[:16]
    staging_path = SMART_IMPORT_STAGING / f"{staging_id}{suffix}"
    staging_path.write_bytes(content)

    df, err = smart_import.read_tabular_file(staging_path)
    if err:
        staging_path.unlink(missing_ok=True)
        raise HTTPException(400, err)

    columns = df.columns.tolist()
    sig = smart_import.header_signature(columns)
    sample_rows = json.loads(df.head(5).to_json(orient="records"))

    conn = get_connection()
    learned = conn.execute(
        "SELECT column_mapping FROM import_schemas WHERE target=? AND header_signature=?",
        (target, sig),
    ).fetchone()
    conn.close()

    if learned:
        mapping = json.loads(learned["column_mapping"])
        source = "learned"
    else:
        mapping, source = smart_import.guess_mapping(columns, sample_rows, target)

    return {
        "staging_id": staging_id + suffix,
        "columns": columns,
        "sample_rows": sample_rows,
        "row_count": len(df),
        "mapping": mapping,
        "mapping_source": source,
        "target_fields": smart_import.TARGET_FIELDS[target],
        "required_fields": smart_import.REQUIRED_FIELDS[target],
    }


class SmartImportConfirmIn(BaseModel):
    staging_id: str
    mapping: dict
    save_schema: bool = True
    meter_type: Optional[str] = None  # nur für target='meter_readings' nötig


@app.post("/api/smart-import/{target}/confirm")
def smart_import_confirm(target: str, payload: SmartImportConfirmIn,
                          session=Depends(auth.require_full_auth)):
    _validate_import_target(target)
    if target == "meter_readings":
        if payload.meter_type not in meters.METER_TYPES:
            raise HTTPException(400, "Für Zählerablesungen muss ein gültiger Zählertyp angegeben werden.")
    if not re.match(r"^[0-9a-f]{16}\.(csv|xlsx|xls|ods)$", payload.staging_id):
        raise HTTPException(400, "Ungültige Zwischenspeicher-Kennung.")
    staging_path = SMART_IMPORT_STAGING / payload.staging_id
    if not staging_path.exists():
        raise HTTPException(404, "Zwischengespeicherte Datei nicht gefunden — bitte erneut hochladen.")

    df, err = smart_import.read_tabular_file(staging_path)
    if err:
        raise HTTPException(400, err)

    rows, skipped = smart_import.apply_mapping(df, payload.mapping, target)

    conn = get_connection()

    def _resolve_category(name: Optional[str]) -> Optional[int]:
        if not name:
            return None
        row = conn.execute("SELECT id FROM categories WHERE name=?", (name,)).fetchone()
        if row:
            return row["id"]
        return conn.execute("INSERT INTO categories (name) VALUES (?)", (name,)).lastrowid

    imported = 0
    for item in rows:
        if target == "expenses":
            category_id = _resolve_category(item.get("category"))
            conn.execute(
                "INSERT INTO expenses (label, amount, category_id, date, note) VALUES (?,?,?,?,?)",
                (item["label"], item["amount"], category_id, item["date"], item.get("provider")),
            )
        elif target == "income":
            conn.execute(
                "INSERT INTO income (label, amount, frequency, active, source) VALUES (?,?,?,1,'import')",
                (item["label"], item["amount"], item.get("frequency") or "monthly"),
            )
        elif target == "contracts":
            category_id = _resolve_category(item.get("category"))
            conn.execute(
                """INSERT INTO contracts (label, provider, contract_number, category_id, amount,
                   frequency, contract_end, status) VALUES (?,?,?,?,?,?,?, 'active')""",
                (item["label"], item.get("provider"), item.get("contract_number"), category_id,
                 item["amount"], item.get("frequency") or "monthly", item.get("contract_end")),
            )
        elif target == "pv_monthly":
            # Nicht-destruktiv: Felder, die dieser Import gar nicht mitliefert
            # (z.B. weil "Netzbezug" nicht gemappt wurde), sollen bestehende
            # Werte NICHT auf 0 überschreiben — sonst würde ein reiner
            # PV+Einspeisung-Import versehentlich den Netzbezug löschen und
            # dadurch die Autarkiequote auf fälschlich 100% springen lassen.
            existing_pv = conn.execute(
                "SELECT pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_monthly WHERE key=?",
                (item["key"],),
            ).fetchone()

            def _keep_or_new(field):
                if item.get(field) is not None:
                    return item[field]
                return existing_pv[field] if existing_pv else 0

            conn.execute(
                """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
                   VALUES (?,?,?,?,?,?,?)
                   ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                     einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
                     gesamt=excluded.gesamt""",
                (item["key"], _keep_or_new("pv"), _keep_or_new("bezug"), item["einsp"],
                 _keep_or_new("batt_lad"), _keep_or_new("batt_ent"), _keep_or_new("gesamt")),
            )
        elif target == "meter_readings":
            existing = conn.execute(
                "SELECT id FROM meter_readings WHERE meter_type=? AND reading_date=?",
                (payload.meter_type, item["reading_date"]),
            ).fetchone()
            if existing:
                skipped += 1
                continue
            conn.execute(
                "INSERT INTO meter_readings (meter_type, reading_date, value) VALUES (?,?,?)",
                (payload.meter_type, item["reading_date"], item["value"]),
            )
        elif target == "assets":
            asset_type = (item.get("type") or "sonstiges").strip().lower()
            if asset_type not in ("konto", "depot", "immobilie", "sonstiges"):
                asset_type = "sonstiges"
            conn.execute(
                "INSERT INTO assets (type, label, provider, current_value) VALUES (?,?,?,?)",
                (asset_type, item["label"], item.get("provider"), item["current_value"]),
            )
        imported += 1

    if payload.save_schema:
        columns = df.columns.tolist()
        sig = smart_import.header_signature(columns)
        conn.execute(
            """INSERT INTO import_schemas (target, header_signature, column_mapping, use_count)
               VALUES (?,?,?,1)
               ON CONFLICT(target, header_signature) DO UPDATE SET
                 column_mapping=excluded.column_mapping,
                 use_count=use_count+1,
                 last_used_at=CURRENT_TIMESTAMP""",
            (target, sig, json.dumps(payload.mapping)),
        )

    conn.commit()
    conn.close()
    staging_path.unlink(missing_ok=True)

    return {"imported": imported, "skipped": skipped}


@app.get("/api/smart-import/schemas")
def list_import_schemas(session=Depends(auth.require_full_auth)):
    """Übersicht der gelernten Datei-Zuordnungen — z.B. um sie bei Bedarf zu löschen."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT id, target, header_signature, column_mapping, label, use_count, last_used_at "
        "FROM import_schemas ORDER BY last_used_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.delete("/api/smart-import/schemas/{schema_id}")
def delete_import_schema(schema_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM import_schemas WHERE id=?", (schema_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


# ---------- Statische PWA ausliefern ----------
app.mount("/", StaticFiles(directory=str(BASE_DIR / "frontend"), html=True), name="frontend")
