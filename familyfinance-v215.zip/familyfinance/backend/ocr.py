"""
Lokale Texterkennung für Beleg-Fotos UND PDF-Rechnungen — läuft 100% offline,
kein Cloud-Aufruf, keine Vertragsdaten verlassen den Mac Mini.

Fotos: zuerst das in macOS eingebaute Vision-Framework (sehr gute Qualität,
komplett on-device, braucht `pyobjc-framework-Vision` — siehe README). Ist
das nicht installiert oder schlägt fehl, fällt der Code auf Tesseract zurück
(braucht `brew install tesseract` + `pip install pytesseract`).

PDF-Rechnungen: zuerst direkte Textextraktion (funktioniert bei den meisten
digital erzeugten Rechnungen, z.B. per E-Mail zugeschickte PDFs). Enthält die
PDF kaum Text (z.B. ein eingescanntes Dokument), wird die erste Seite in ein
Bild umgewandelt (braucht `brew install poppler`) und wie ein Foto per
Vision/Tesseract erkannt.

Schlägt am Ende alles fehl, wird der Beleg trotzdem gespeichert — nur ohne
automatische Erkennung, zur manuellen Nachpflege.
"""
import re
import os
from datetime import date
from pathlib import Path
from typing import Optional


def _order_vision_entries(entries: list) -> str:
    """Bringt von Vision erkannte Textzeilen in eine sinnvolle Leserichtung.

    entries: Liste von (y, x_left, x_mid, text) — Vision-Koordinaten, y von
    unten gezählt (0=unten, 1=oben), x von links (0=links, 1=rechts).

    Reines "von oben nach unten, dann links nach rechts" scheitert bei
    zweispaltigen Briefen (links Absender, rechts Ansprechpartner/Kontakt-
    block, wie bei den meisten Behörden-/Firmenschreiben) — das mischt
    dann Zeilen aus beiden Spalten zusammen und zerreißt z.B. "Amt für
    Schule und Bildung" oder "Kundennummer: 12345", weil die rechte Spalte
    zeilenweise dazwischenrutscht.

    Deshalb: prüfen, ob sich die Textzeilen in zwei klar getrennte
    horizontale Gruppen (Spalten) aufteilen lassen (deutliche Lücke in der
    x-Verteilung, ungefähr mittig auf der Seite). Falls ja: erst komplett
    die linke Spalte lesen, dann komplett die rechte — genau wie ein
    Mensch einen zweispaltigen Brief liest. Falls nein (Normalfall,
    einspaltiges Dokument): normale Sortierung oben→unten, links→rechts.
    """
    if not entries:
        return ""

    xs = sorted(e[2] for e in entries)
    best_gap, best_gap_pos = 0.0, None
    for i in range(1, len(xs)):
        gap = xs[i] - xs[i - 1]
        if gap > best_gap:
            best_gap, best_gap_pos = gap, (xs[i - 1] + xs[i]) / 2

    # Nur als Zwei-Spalten-Layout werten, wenn die Lücke deutlich ist (>12%
    # der Seitenbreite) und ungefähr mittig liegt (zwischen 25% und 75%) —
    # sonst könnte es nur ein zufälliger Abstand in einem normalen
    # einspaltigen Text sein.
    is_two_column = best_gap > 0.12 and best_gap_pos is not None and 0.25 < best_gap_pos < 0.75

    def _sort_block(block):
        return sorted(block, key=lambda e: (-e[0], e[1]))

    if is_two_column:
        left = [e for e in entries if e[2] < best_gap_pos]
        right = [e for e in entries if e[2] >= best_gap_pos]
        ordered = _sort_block(left) + _sort_block(right)
    else:
        ordered = _sort_block(entries)

    return "\n".join(e[3] for e in ordered)


def _ocr_with_macos_vision(image_path: Path) -> str:
    """Nutzt PyObjC + Vision.framework — nur auf macOS mit pyobjc verfügbar."""
    import Quartz
    import Vision
    from Foundation import NSURL

    image_url = NSURL.fileURLWithPath_(str(image_path))
    input_image = Quartz.CIImage.imageWithContentsOfURL_(image_url)
    if input_image is None:
        raise ValueError("Bild konnte nicht gelesen werden (nicht unterstütztes Format?)")

    handler = Vision.VNImageRequestHandler.alloc().initWithCIImage_options_(input_image, None)

    results: dict = {"text": "", "error": None}

    def _handler(request, error):
        if error:
            results["error"] = str(error)
            return
        observations = request.results() or []
        entries = []
        for obs in observations:
            candidates = obs.topCandidates_(1)
            if not candidates:
                continue
            box = obs.boundingBox()
            x_mid = box.origin.x + box.size.width / 2
            entries.append((round(box.origin.y, 4), box.origin.x, x_mid, candidates[0].string()))
        results["text"] = _order_vision_entries(entries)

    request = Vision.VNRecognizeTextRequest.alloc().initWithCompletionHandler_(_handler)
    request.setRecognitionLevel_(1)  # 1 = accurate
    request.setRecognitionLanguages_(["de-DE", "en-US"])
    success, err = handler.performRequests_error_([request], None)
    if results["error"]:
        raise RuntimeError(results["error"])
    return results["text"]


def _ocr_with_tesseract(image_path: Path) -> str:
    """Fallback (z.B. zum Testen unter Linux, oder falls pyobjc fehlt)."""
    import pytesseract
    from PIL import Image
    return pytesseract.image_to_string(Image.open(image_path), lang="deu+eng")


def _ocr_image_any_engine(image_path: Path) -> tuple[str, str]:
    """Versucht Vision, dann Tesseract. Gibt (text, engine_name) zurück oder wirft."""
    try:
        return _ocr_with_macos_vision(image_path), "vision"
    except Exception as vision_err:
        # Wird geloggt statt nur still zu wechseln — sonst bleibt ein
        # kaputtes Vision-Setup (wie der .text()/.string()-Bug) unbemerkt,
        # selbst wenn Tesseract als Rückfallebene noch funktioniert.
        print(f"[ocr] Vision fehlgeschlagen, falle auf Tesseract zurück: {vision_err}")
        try:
            return _ocr_with_tesseract(image_path), "tesseract"
        except Exception as tess_err:
            raise RuntimeError(f"Vision={vision_err}; Tesseract={tess_err}")


def _extract_text_from_pdf(pdf_path: Path) -> str:
    """Direkte Textextraktion aus einer PDF (funktioniert bei digital erzeugten
    Rechnungen, nicht bei eingescannten Bildern ohne Textebene)."""
    from pypdf import PdfReader
    reader = PdfReader(str(pdf_path))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def _ocr_scanned_pdf(pdf_path: Path) -> tuple[str, str]:
    """Für PDFs ohne (brauchbare) Textebene: Seiten rendern und wie Fotos per
    Vision/Tesseract erkennen. Braucht poppler (`brew install poppler`).

    Wichtig: nicht nur die erste Seite — bei mehrseitigen Dokumenten (z.B.
    einem Anschreiben auf Seite 1 gefolgt vom eigentlichen Versicherungsschein
    mit Beitrag auf Seite 2) stünden sonst genau die relevanten Zahlen nicht
    im erkannten Text. Aus Zeitgründen auf die ersten paar Seiten begrenzt."""
    from pdf2image import convert_from_path
    MAX_PAGES = 4
    # Höhere Auflösung als vorher (200 -> 300 DPI) — bei bereits leicht
    # unscharfen Scans (Fax/alte Kopien) macht das einen spürbaren Unterschied
    # für die Erkennungsgenauigkeit.
    images = convert_from_path(str(pdf_path), dpi=300, first_page=1, last_page=MAX_PAGES)
    if not images:
        raise RuntimeError("PDF-Seite konnte nicht gerendert werden.")

    texts = []
    engine_used = None
    import tempfile
    for i, image in enumerate(images):
        fd, tmp_name = tempfile.mkstemp(suffix=f"_page{i}.png", prefix="ffz_ocr_")
        os.close(fd)
        tmp_image = Path(tmp_name)
        image.save(tmp_image)
        try:
            page_text, engine_used = _ocr_image_any_engine(tmp_image)
            texts.append(page_text)
        finally:
            tmp_image.unlink(missing_ok=True)

    return "\n\n".join(texts), (engine_used or "unbekannt")


def _parse_de_amount(raw: str) -> float:
    """Wandelt '1.234,56' oder '34,90' oder '34.90' zuverlässig in float um."""
    if "," in raw and "." in raw:
        raw = raw.replace(".", "").replace(",", ".")
    elif "," in raw:
        raw = raw.replace(",", ".")
    return float(raw)


# Reihenfolge wichtig: spezifischere Begriffe zuerst, damit z.B. "Gesamtbetrag"
# nicht von einem allgemeineren Treffer überdeckt wird, und ein per Rabatt
# ermäßigter Beitrag Vorrang vor dem ursprünglichen Beitrag hat. "Beitrag" ist
# bei Versicherungen der übliche Begriff für den zu zahlenden Betrag — nicht zu
# verwechseln mit "Betrag" (ein Buchstabe Unterschied, komplett andere Treffer).
_AMOUNT_KEYWORDS = [
    "ermäßigt sich der beitrag auf", "ermäßigter beitrag",
    "gesamtbetrag", "rechnungsbetrag", "zu zahlen", "zahlbetrag",
    "gesamtsumme", "endbetrag",
    "monatsbeitrag", "versicherungsbeitrag", "jahresbeitrag", "beitrag",
    "festgesetzt", "steuerberechnung",
    "gesamt", "summe", "betrag", "total", "prämie",
]


def _extract_amount(text: str) -> Optional[float]:
    lower = text.lower()
    number = r"\b(\d{1,4}(?:[.,]\d{3})*[.,]\d{2})\b"

    def _is_date_fragment(full_text: str, end_pos: int) -> bool:
        # "27.08.2026" sieht mit unserem Zahlenmuster wie "27.08" (ein
        # scheinbarer Geldbetrag) aus, gefolgt vom Jahr. Direkt danach ein
        # ".JJJJ" -> fast sicher ein abgeschnittenes Datum, kein Betrag.
        return bool(re.match(r"^\.\d{4}\b", full_text[end_pos:]))

    for kw in _AMOUNT_KEYWORDS:
        # Größeres Suchfenster als früher (15 -> 80 Zeichen) — deutsche
        # Formulare trennen Bezeichnung und Betrag oft mit einer langen
        # Punkt-Füllzeile ("...................... 22,00 €").
        window_match = re.search(kw + r"([^\d\-]{0,80}" + number + r"){1,4}", lower)
        if not window_match:
            continue
        # Innerhalb des Fensters können mehrere Zahlen aufeinanderfolgen
        # (z.B. eine Tabellenzeile "Summe: 0,00  28.371,15" mit Geldsaldo
        # UND Depotwert nebeneinander) — dann ist die dem Schlüsselwort NÄCHSTE
        # Zahl oft nicht die gemeinte, sondern die LETZTE im Fenster (üblicher
        # Aufbau: mehrere Spalten, die eigentliche Summe steht rechts).
        numbers_in_window = re.findall(number, window_match.group(0))
        if numbers_in_window and not _is_date_fragment(lower, window_match.end()):
            try:
                return _parse_de_amount(numbers_in_window[-1])
            except ValueError:
                pass
    # Kein Schlüsselwort gefunden -> größter Eurobetrag im Text als bester Tipp
    values = []
    for m in re.finditer(number, text):
        if _is_date_fragment(text, m.end()):
            continue
        try:
            values.append(_parse_de_amount(m.group(1)))
        except ValueError:
            pass
    return max(values) if values else None


_DATE_KEYWORDS = ["rechnungsdatum", "belegdatum", "ausstellungsdatum", "datum"]


def _extract_date(text: str) -> Optional[date]:
    date_pattern = r"(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})"
    lower = text.lower()
    for kw in _DATE_KEYWORDS:
        match = re.search(kw + r"[.:\s]{1,5}" + date_pattern, lower)
        if match:
            d, m, y = match.groups()
            y = int(y) if len(y) == 4 else 2000 + int(y)
            try:
                return date(y, int(m), int(d))
            except ValueError:
                continue
    # Kein Schlüsselwort gefunden -> erstes Datum im Text als bester Tipp
    match = re.search(date_pattern, text)
    if not match:
        return None
    d, m, y = match.groups()
    y = int(y) if len(y) == 4 else 2000 + int(y)
    try:
        return date(y, int(m), int(d))
    except ValueError:
        return None


# Firmenname mit Rechtsform-Endung — ein sehr starkes, eigenständiges Signal
# für den Anbieternamen, das auch bei nur einer einzigen Erwähnung im
# Fließtext trifft (siehe _extract_provider). Bis zu 4 vorangehende
# großgeschriebene Wörter werden mit eingeschlossen (z.B. "Sutor Bank" vor
# "GmbH"), aber nur solange sie durch reine Leerzeichen verbunden sind —
# ein Doppelpunkt oder Ähnliches (z.B. "Ihr Berater: Sutor Bank GmbH")
# bricht die Kette dort ab, sodass nur "Sutor Bank GmbH" übrig bleibt.
_COMPANY_SUFFIX_RE = re.compile(
    r"([A-ZÄÖÜ][\wÄÖÜäöüß&.\-]*(?:\s+[A-ZÄÖÜ][\wÄÖÜäöüß&.\-]*){0,4}\s+"
    r"(?:GmbH(?:\s*&\s*Co\.?\s*KG)?|mbH|AG|SE|KGaA|OHG|eG|e\.G\.|"
    r"Bank|Sparkasse|Bausparkasse|"
    r"Versicherung(?:en)?(?:\s*a\.?\s*G\.?)?|Lebensversicherung)\b)"
)


def _extract_provider(text: str) -> Optional[str]:
    """Der Firmenname taucht auf den meisten Dokumenten mehrfach auf (Kopf-,
    Fußzeile, Unterschrift, Impressum) — auch wenn eine einzelne Stelle durch
    einen OCR-Fehler leicht verfälscht ist (z.B. "NOLKSWOHL" statt
    "VOLKSWOHL"). Deshalb wird nicht blind die erste Zeile genommen, sondern
    ähnliche wiederkehrende Zeilen gruppiert — die häufigste Gruppe gewinnt,
    daraus die kürzeste (meist reinste, ohne Adresszusatz) Zeile.

    VORAB wird zuerst gezielt nach einem Firmennamen mit Rechtsform-Endung
    (GmbH, AG, Bank, Versicherung, ...) gesucht — ein sehr starkes Signal,
    das auch bei nur EINER einzigen Erwähnung zuverlässig trifft (z.B. ein
    Depotauszug, der den Anbieter nur einmal in einer Fließtextzeile nennt,
    "... Ihr Berater: Sutor Bank GmbH" — die Häufigkeits-Heuristik allein
    würde hier mangels Wiederholung ins Leere laufen oder sogar ein
    zufällig öfter vorkommendes, bedeutungsloses Tabellen-Fragment wie
    "in EUR" gewinnen lassen)."""
    from difflib import SequenceMatcher

    suffix_match = _COMPANY_SUFFIX_RE.search(text)
    if suffix_match:
        return suffix_match.group(1).strip()

    def _similar(a: str, b: str) -> float:
        # Nur auf der gemeinsamen (kürzeren) Länge vergleichen — sonst werden
        # "VOLKSWOHL BUND" und "VOLKSWOHL BUND LEBENSVERSICHERUNG a.G." allein
        # wegen der Längendifferenz fälschlich als unähnlich gewertet.
        n = min(len(a), len(b))
        if n == 0:
            return 0.0
        return SequenceMatcher(None, a[:n], b[:n]).ratio()

    candidate_lines = []
    for line in text.splitlines():
        line = line.strip()
        # Mindestlänge deutlich höher als zuvor (2 -> 6): kurze Fragmente wie
        # "ZOLL" oder "FAX" (z.B. aus einem Logo/einer Wappen-Grafik mitgelesen)
        # sollen gar nicht erst als Kandidat für den Firmennamen infrage kommen —
        # sie können sonst, selbst als seltener Ausreißer, die komplette
        # Zeichen-Abstimmung unten auf ihre kurze Länge herunterziehen.
        # Mindestens zwei Wörter verlangt: ein einzelnes, mehrfach im
        # Fließtext vorkommendes Wort (z.B. "Schulkindbetreuung", weil es im
        # Betreff UND zweimal im Text auftaucht) soll nie den eigentlichen,
        # mehrwortigen Absendernamen bei der Häufigkeit überstimmen — echte
        # Organisationsnamen sind in der Praxis immer mehrwortig.
        # Zusätzlich generische Tabellen-/Einheiten-Fragmente ausschließen
        # ("in EUR", "in USD", "in %") — auf Kontoauszügen/Depotübersichten
        # wiederholen sich diese Spaltenköpfe oft öfter als der Firmenname
        # selbst und würden die Häufigkeits-Abstimmung sonst kapern.
        if (len(line) >= 6 and " " in line.strip()
                and not re.match(r"^[\d.,\-/\s€]+$", line)
                and not re.match(r"^in\s+(EUR|USD|US\$|GBP|CHF|%)$", line, re.IGNORECASE)):
            candidate_lines.append(line)

    if not candidate_lines:
        return None

    groups: list[dict] = []
    for line in candidate_lines:
        key = line[:35].upper()
        match = next(
            # Schwelle bewusst hoch (0.88): trennt "derselbe Firmenname mit
            # OCR-Tippfehler" (z.B. NOLKSWOHL/VOLKSWOHL, ~0.93) zuverlässig
            # von "zwei strukturell ähnliche, aber inhaltlich verschiedene
            # Zeilen" (z.B. zwei unterschiedliche Postleitzahlen/Adressen wie
            # Absender- vs. Empfängeradresse, ~0.86) — Letztere dürfen nicht
            # als "wiederholte Zeile" zusammengelegt werden, sonst entsteht
            # aus der Buchstaben-Abstimmung unten reines Kauderwelsch.
            (g for g in groups if _similar(key, g["key"]) > 0.88),
            None,
        )
        if match:
            match["lines"].append(line)
        else:
            groups.append({"key": key, "lines": [line]})

    best = max(groups, key=lambda g: len(g["lines"]))
    if len(best["lines"]) < 2:
        # Keine Wiederholung im Dokument gefunden -> wie bisher die erste Zeile
        return candidate_lines[0]

    # Zeichenweise Mehrheitsentscheidung über alle Zeilen der Gruppe (nicht nur
    # die kürzesten) — auch Zeilen mit Adresszusatz liefern an der passenden
    # Stelle eine "Stimme" für den richtigen Buchstaben. Ausgerichtet wird auf
    # die kürzeste Zeile der Gruppe — das liefert meist den reinen Firmennamen
    # ohne Adresszusatz. Die Mindestlänge oben (6 Zeichen) verhindert bereits,
    # dass kurze Störfragmente wie "ZOLL" die Gruppe überhaupt erreichen.
    shortest_len = min(len(l) for l in best["lines"])
    aligned = [l[:shortest_len] for l in best["lines"]]

    def _majority_char(chars):
        # WICHTIG: kein set() verwenden — dessen Iterationsreihenfolge ist in
        # Python für Strings pro Prozess zufällig (Hash-Randomisierung), bei
        # einem Gleichstand (z.B. 2 von 4 Stimmen für zwei verschiedene
        # Buchstaben) käme sonst bei jedem Programmstart ein anderes Ergebnis
        # heraus. Stattdessen deterministisch: das häufigste Zeichen, bei
        # Gleichstand das zuerst aufgetretene.
        counts = {}
        for c in chars:
            counts[c] = counts.get(c, 0) + 1
        best_count = max(counts.values())
        for c in chars:
            if counts[c] == best_count:
                return c

    consensus = "".join(_majority_char(chars) for chars in zip(*aligned))
    return consensus.strip()


# Reihenfolge wichtig: spezifischere Begriffe zuerst.
_CONTRACT_NUMBER_KEYWORDS = [
    "vertragsnummer", "vertrags-nr", "vertragsnr", "versicherungsschein-nr",
    "versicherungsscheinnummer", "policennummer", "police-nr",
    "kundennummer", "kunden-nr", "kundennr", "kdnr",
    # Depot-/Kontonummer für Bank- und Depotauszüge (z.B. "Depotbestände für
    # Depot 1234567890" auf einem Fondsdepot-Auszug).
    "depotnummer", "depot-nr", "depotkonto", "depot",
    # "steuernummer" passt per Substring-Suche auch auf zusammengesetzte
    # Begriffe wie "Kraftfahrzeugsteuernummer" (Kfz-Steuerbescheid vom Zoll)
    "steuernummer", "mandatsreferenznummer", "aktenzeichen", "geschäftszeichen",
]

# Für Dokumente, bei denen zwischen Schlüsselwort und "Nr. <Code>" ein
# Zeilenumbruch liegt (sehr üblich auf Versicherungsscheinen, z.B.
# "Versicherungsschein\n\nNr. 12345678") — deshalb bewusst über [\s\S] statt
# nur Leerzeichen gesucht, aber mit engem Fenster gegen Fehltreffer.
_CONTRACT_NUMBER_CONTEXT_KEYWORDS = ["versicherungsschein", "versicherung", "vertrag", "police"]


def _extract_contract_number(text: str) -> Optional[str]:
    lower = text.lower()
    # OCR fügt manchmal einen Punkt mitten in ein Wort ein (z.B.
    # "K.undennummer" statt "Kundennummer") — ein Punkt zwischen zwei
    # Kleinbuchstaben ist so gut wie nie beabsichtigt (im Unterschied zu
    # "z.B." o.ä., wo danach ein Großbuchstabe folgt), deshalb hier entfernt,
    # nur für den Stichwort-Abgleich.
    lower_clean = re.sub(r"(?<=[a-zäöüß])\.(?=[a-zäöüß])", "", lower)
    code = r"([A-Z0-9][A-Z0-9\-./]{3,20})"
    for kw in _CONTRACT_NUMBER_KEYWORDS:
        match = re.search(kw + r"[.:\s]{1,5}" + code, lower_clean, re.IGNORECASE)
        if match:
            return match.group(1).strip(".-/ ").upper()
        # Umgekehrte Reihenfolge: Wert steht vor dem Label — kommt vor, wenn
        # die Texterkennung bei mehrspaltigen Dokumenten (Label und Wert in
        # getrennten Spalten) die Lesereihenfolge vertauscht.
        match = re.search(code + r"\s*\n\s*" + kw, lower_clean, re.IGNORECASE)
        if match:
            return match.group(1).strip(".-/ ").upper()
    for kw in _CONTRACT_NUMBER_CONTEXT_KEYWORDS:
        match = re.search(kw + r"[\s\S]{0,20}?\bnr\.?\s*[:\-]?\s*" + code, lower_clean, re.IGNORECASE)
        if match:
            return match.group(1).strip(".-/ ").upper()
    return None


_REAL_TLDS = (
    "de", "com", "net", "org", "eu", "info", "biz", "io", "co",
    "at", "ch", "fr", "it", "es", "nl", "be", "uk", "shop", "app",
)
_WEBSITE_PATTERN = re.compile(
    r"\b((?:https?://)?(?:www\.)?[a-z0-9][a-z0-9\-]*\.(?:" + "|".join(_REAL_TLDS) + r")(?:/[^\s]*)?)\b",
    re.IGNORECASE,
)
# Domains, die auf Belegen häufig vorkommen, aber keine Anbieter-Homepage sind
_WEBSITE_IGNORE = ("gmail.com", "web.de", "gmx.de", "gmx.net", "t-online.de", "outlook.com", "icloud.com")


def _extract_website(text: str, provider: Optional[str] = None) -> Optional[str]:
    candidates = []
    for match in _WEBSITE_PATTERN.finditer(text):
        candidate = match.group(1).rstrip(".,;)")
        domain = candidate.lower().replace("https://", "").replace("http://", "").split("/")[0]
        if any(domain == d or domain.endswith("." + d) for d in _WEBSITE_IGNORE):
            continue
        # Kein Ausschluss mehr für "steht direkt nach einem @" — das ist bei
        # einer E-Mail-Adresse wie "kundendienst@volkswohl-bund.de" genau die
        # Domain, die wir suchen. Dank der TLD-Whitelist oben kann daraus auch
        # kein falscher Treffer mehr aus dem lokalen Teil vor dem @ entstehen.
        if not candidate.startswith("http"):
            candidate = "https://" + candidate
        candidates.append((candidate, domain))

    if not candidates:
        return None
    if len(candidates) == 1 or not provider:
        return candidates[0][0]

    # Mehrere URLs im Dokument (z.B. Anbieter-Homepage UND E-Mail-Domain eines
    # Ansprechpartners) — die nehmen, deren Domain am ehesten zum erkannten
    # Anbieter passt, statt blind die erste zu nehmen (die z.B. im Briefkopf
    # eines Vermittlers stehen kann, nicht des eigentlichen Anbieters).
    provider_key = re.sub(r"[^a-z0-9]", "", provider.lower())
    best = max(
        candidates,
        key=lambda c: sum(1 for token in re.findall(r"[a-z0-9]+", c[1]) if token in provider_key and len(token) > 2),
    )
    return best[0]


def _extract_period(text: str) -> tuple[Optional[date], Optional[date]]:
    """Sucht einen Abrechnungs-/Leistungszeitraum wie '01.06.2026 - 30.06.2026'."""
    match = re.search(
        r"(\d{1,2}[.\-/]\d{1,2}[.\-/]\d{2,4})\s*(?:-|–|bis)\s*(\d{1,2}[.\-/]\d{1,2}[.\-/]\d{2,4})",
        text, re.IGNORECASE,
    )
    if not match:
        return None, None
    start = _extract_date(match.group(1))
    end = _extract_date(match.group(2))
    return start, end


def _guess_category(provider: Optional[str]) -> str:
    from categorize import categorize
    category, _ = categorize(provider or "")
    return category


def _looks_like_real_text(text: str) -> bool:
    """Grobe Qualitätsprüfung für direkt aus der PDF extrahierten Text:
    ein reiner Längen-Schwellwert reicht nicht — gescannte PDFs enthalten
    manchmal ein paar Zeichen "Geistertext" (Formularfelder, Metadaten-Reste),
    der zwar über 20 Zeichen lang, aber inhaltlich nutzlos ist. Deshalb wird
    zusätzlich verlangt, dass eine Mindestanzahl echt aussehender Wörter
    vorkommt, bevor die (schnellere, meist genauere) direkte Textextraktion
    der langsameren Bild-OCR vorgezogen wird."""
    words = re.findall(r"[A-Za-zÄÖÜäöüß]{3,}", text)
    return len(words) >= 6


# Renteninformation-Schreiben nennen oft mehrere Szenarien nebeneinander
# (Regelaltersrente, Erwerbsminderungsrente, mit/ohne weitere Beitragszahlung
# und Rentenanpassung) — wir wollen gezielt die reguläre Regelaltersrente,
# nicht z.B. die (meist niedrigere) Erwerbsminderungsrente.
_PENSION_POSITIVE_KEYWORDS = [
    "regelaltersrente", "regelaltersgrenze", "monatliche rente",
    "voraussichtliche rente", "voraussichtlich erreichen",
]
_PENSION_NEGATIVE_KEYWORDS = ["erwerbsminderung", "erwerbsunfähigkeit"]


def extract_pension_document_data(file_path: Path) -> dict:
    """Sucht in einer Renteninformation (oder einem privaten Vorsorge-Nachweis
    wie einem Depotauszug) nach dem voraussichtlichen monatlichen Rentenwert.
    Liefert IMMER ein Ergebnis-Dict, auch wenn nichts gefunden wird — der Wert
    ist dann nur ein Vorschlag, den man in der Oberfläche noch bestätigen
    oder korrigieren muss, nie eine automatische, ungeprüfte Übernahme."""
    is_pdf = file_path.suffix.lower() == ".pdf"
    raw_text = ""
    engine = None
    error = None

    if is_pdf:
        try:
            raw_text = _extract_text_from_pdf(file_path)
            engine = "pdf-text"
            if not _looks_like_real_text(raw_text):
                raise ValueError("zu wenig brauchbarer Text extrahiert, vermutlich gescannt")
        except Exception:
            try:
                raw_text, engine = _ocr_scanned_pdf(file_path)
            except Exception as scan_err:
                error = f"PDF konnte nicht gelesen werden ({scan_err})"
    else:
        try:
            raw_text, engine = _ocr_image_any_engine(file_path)
        except Exception as img_err:
            error = f"Keine Texterkennung verfügbar ({img_err})"

    suggested_amount = None
    all_amounts = []
    provider = _extract_provider(raw_text) if raw_text else None

    if raw_text:
        number = r"\b(\d{1,3}(?:\.\d{3})*,\d{2})\s*(?:€|EUR)"
        lower = raw_text.lower()
        best_score = None
        for m in re.finditer(number, raw_text):
            try:
                value = _parse_de_amount(m.group(1))
            except ValueError:
                continue
            # Plausible monatliche Rente: realistischer Bereich, keine
            # Beitragssätze (meist < 20 %) oder Versicherungsnummern erfassen.
            if not (30 <= value <= 10000):
                continue
            window = lower[max(0, m.start() - 120):m.start()]
            score = 0
            if any(kw in window for kw in _PENSION_POSITIVE_KEYWORDS):
                score += 3
            if any(kw in window for kw in _PENSION_NEGATIVE_KEYWORDS):
                score -= 5
            if "monatlich" in window:
                score += 1
            all_amounts.append(round(value, 2))
            if best_score is None or score > best_score:
                best_score = score
                suggested_amount = round(value, 2)

    return {
        "raw_text": raw_text or None,
        "suggested_monthly_amount": suggested_amount,
        "all_amounts_found": sorted(set(all_amounts), reverse=True)[:8],
        "provider": provider,
        "ocr_engine": engine,
        "ocr_error": error,
    }


def extract_receipt_data(file_path: Path) -> dict:
    """
    Liefert immer ein Ergebnis-Dict, wirft nie eine Exception weiter nach oben —
    schlägt die Texterkennung komplett fehl, kommen einfach leere Felder zurück
    (inkl. ocr_error), damit der Beleg trotzdem gespeichert und manuell
    nachgepflegt werden kann, statt den ganzen Upload abzubrechen.

    Funktioniert sowohl für Fotos (jpg/png/heic) als auch für PDF-Rechnungen.
    """
    raw_text = ""
    engine = None
    error = None
    is_pdf = file_path.suffix.lower() == ".pdf"

    if is_pdf:
        try:
            raw_text = _extract_text_from_pdf(file_path)
            engine = "pdf-text"
            if not _looks_like_real_text(raw_text):
                # Vermutlich eingescannt (oder nur Formular-/Metadaten-Reste als
                # Text vorhanden) -> OCR auf gerenderte Seite(n)
                raise ValueError("zu wenig brauchbarer Text extrahiert, vermutlich gescannt")
        except Exception:
            try:
                raw_text, engine = _ocr_scanned_pdf(file_path)
            except Exception as scan_err:
                error = (
                    "PDF enthält keinen Text und konnte auch nicht als Bild erkannt werden. "
                    "Für gescannte PDFs installieren: brew install poppler "
                    f"(Details: {scan_err})"
                )
    else:
        try:
            raw_text, engine = _ocr_image_any_engine(file_path)
        except Exception as img_err:
            error = (
                "Keine lokale Texterkennung verfügbar. Für beste Ergebnisse auf dem "
                "Mac Mini installieren: pip install pyobjc-framework-Vision "
                "pyobjc-framework-Quartz pyobjc-framework-Cocoa "
                f"(Details: {img_err})"
            )

    provider = _extract_provider(raw_text) if raw_text else None
    period_start, period_end = _extract_period(raw_text) if raw_text else (None, None)
    return {
        "raw_text": raw_text or None,
        "amount": _extract_amount(raw_text) if raw_text else None,
        "date": _extract_date(raw_text) if raw_text else None,
        "provider": provider,
        "contract_number": _extract_contract_number(raw_text) if raw_text else None,
        "website": _extract_website(raw_text, provider) if raw_text else None,
        "period_start": period_start,
        "period_end": period_end,
        "category": _guess_category(provider) if provider else "Sonstiges",
        "ocr_engine": engine,
        "ocr_error": error,
    }
