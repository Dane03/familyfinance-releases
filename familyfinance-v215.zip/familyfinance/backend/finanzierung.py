"""
Tilgungsplan-Berechnung für Immobilienfinanzierungen (Annuitätendarlehen).

Standard-Annuitätenrechnung: Die monatliche Rate bleibt konstant, aber ihre
Zusammensetzung verschiebt sich — der Zinsanteil sinkt mit der Restschuld,
der Tilgungsanteil steigt entsprechend. Genau das macht den Tilgungsplan
anschaulich.
"""
from typing import Optional
from datetime import date


def compute_repayment_schedule(remaining_debt: float, interest_rate: float,
                                monthly_payment: Optional[float] = None,
                                repayment_rate: Optional[float] = None,
                                start: Optional[date] = None,
                                max_years: int = 50) -> dict:
    """Berechnet den Tilgungsverlauf ab der aktuellen Restschuld.

    Die monatliche Rate kann entweder direkt übergeben werden (aus dem
    Vertragsbetrag) oder aus dem anfänglichen Tilgungssatz abgeleitet werden:
    Jahresrate = Restschuld × (Zinssatz + Tilgungssatz) / 100.

    Gibt Jahres-Stützpunkte zurück (nicht jeden Monat) — für die Darstellung
    als Chart reicht das völlig und hält die Datenmenge klein.
    """
    if not remaining_debt or remaining_debt <= 0:
        return {"error": "Keine Restschuld hinterlegt.", "schedule": []}
    if interest_rate is None:
        return {"error": "Kein Zinssatz hinterlegt.", "schedule": []}

    if not monthly_payment or monthly_payment <= 0:
        if not repayment_rate or repayment_rate <= 0:
            return {"error": "Weder Rate noch Tilgungssatz hinterlegt.", "schedule": []}
        monthly_payment = remaining_debt * (interest_rate + repayment_rate) / 100 / 12

    monthly_interest_rate = interest_rate / 100 / 12
    first_month_interest = remaining_debt * monthly_interest_rate
    if monthly_payment <= first_month_interest:
        # Die Rate deckt nicht einmal die Zinsen — die Schuld würde ewig
        # wachsen. Klar melden statt eine endlose Schleife zu bauen.
        return {
            "error": (
                f"Die Rate ({monthly_payment:.0f} €) liegt unter den monatlichen Zinsen "
                f"({first_month_interest:.0f} €) — so wird nie getilgt. Bitte Rate, "
                f"Zinssatz oder Restschuld prüfen."
            ),
            "schedule": [],
        }

    start = start or date.today()
    balance = remaining_debt
    schedule = [{
        "year": start.year,
        "month_index": 0,
        "remaining_debt": round(balance, 2),
        "interest_paid_cumulative": 0.0,
        "principal_paid_cumulative": 0.0,
    }]

    total_interest = 0.0
    total_principal = 0.0
    month = 0
    max_months = max_years * 12

    while balance > 0 and month < max_months:
        month += 1
        interest = balance * monthly_interest_rate
        principal = monthly_payment - interest
        if principal > balance:  # letzte, kleinere Rate
            principal = balance
        balance -= principal
        total_interest += interest
        total_principal += principal

        if month % 12 == 0 or balance <= 0:
            schedule.append({
                "year": start.year + (start.month - 1 + month) // 12,
                "month_index": month,
                "remaining_debt": round(max(balance, 0), 2),
                "interest_paid_cumulative": round(total_interest, 2),
                "principal_paid_cumulative": round(total_principal, 2),
            })

    payoff_year = start.year + (start.month - 1 + month) // 12
    return {
        "error": None,
        "monthly_payment": round(monthly_payment, 2),
        "interest_rate": interest_rate,
        "remaining_debt": round(remaining_debt, 2),
        "months_to_payoff": month,
        "years_to_payoff": round(month / 12, 1),
        "payoff_year": payoff_year,
        "total_interest": round(total_interest, 2),
        "fully_repaid": balance <= 0,
        "schedule": schedule,
    }
