"""
Abhängigkeits-Wartung: prüft installierte Python-Pakete gegen requirements.txt
auf verfügbare Updates und kann sie bei Bedarf installieren.

Wird von zwei Stellen genutzt:
1. app.py (In-App-Button unter Einstellungen → Wartung)
2. check_dependencies.py (eigenständiges Skript, läuft wöchentlich per launchd
   auch dann, wenn die App gerade nicht offen ist — Ergebnis landet in der
   settings-Tabelle, die App zeigt es beim nächsten Öffnen einfach an)

Bewusst nur die feste Paketliste aus requirements.txt — kein beliebiger
Shell-Befehl von außen ausführbar.
"""
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent.parent
REQUIREMENTS_PATH = Path(__file__).resolve().parent / "requirements.txt"

# ---------- App-Selbst-Update ----------
# Bewusst ein SEPARATES, oeffentliches Repository nur fuer Versions-
# Veroeffentlichungen (kein Quellcode, keine privaten Finanzdaten) --
# damit kein GitHub-Zugangstoken in einer an Freunde weitergegebenen App
# hinterlegt werden muss. Fest einprogrammiert (nicht vom Nutzer
# aenderbar), damit die App niemals ein Update von einer beliebigen,
# potenziell manipulierten Quelle akzeptiert.
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Dane03/familyfinance-releases/main/latest.json"


def _current_app_version() -> str:
    """Liest die aktuell laufende Version aus dem APP_BUILD-String in
    app.js — dieselbe Versionsnummer, die auch oben in der App angezeigt
    wird, keine zweite, separat zu pflegende Quelle."""
    app_js = BASE_DIR / "frontend" / "app.js"
    if not app_js.exists():
        return "v0"
    match = re.search(r"·\s*(v\d+)\"", app_js.read_text(encoding="utf-8"))
    return match.group(1) if match else "v0"


def _version_number(v: str) -> int:
    m = re.search(r"\d+", v or "")
    return int(m.group()) if m else 0


def check_app_update() -> dict:
    """Fragt das oeffentliche Manifest ab und vergleicht mit der laufenden
    Version. Netzwerkfehler werden abgefangen -- kein Update-Check darf
    die App selbst zum Absturz bringen. Das Manifest enthaelt getrennte
    Downloads je Plattform (Mac/Windows) unter demselben Versions-Tag."""
    import urllib.request
    import urllib.error

    current = _current_app_version()
    try:
        req = urllib.request.Request(UPDATE_MANIFEST_URL, headers={"Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            manifest = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as e:
        return {"current_version": current, "error": f"Update-Server nicht erreichbar: {e}"}

    latest = manifest.get("version", current)
    platform_key = "windows" if platform.system() == "Windows" else "mac"
    platform_entry = (manifest.get("platforms") or {}).get(platform_key, {})
    return {
        "current_version": current,
        "latest_version": latest,
        "update_available": _version_number(latest) > _version_number(current),
        "download_url": platform_entry.get("download_url"),
        "sha256": platform_entry.get("sha256"),
        "notes": manifest.get("notes"),
    }


def apply_app_update(download_url: str, expected_sha256: str) -> dict:
    """Laedt das Release-ZIP herunter, prueft die Pruefsumme, entpackt es
    und spielt es ein -- reines Python statt rsync (funktioniert dadurch
    identisch unter macOS UND Windows). Nach erfolgreichem Einspielen
    startet sich der Dienst selbst neu (restart_service ist bereits
    plattformsicher)."""
    import urllib.request
    import hashlib
    import zipfile
    import shutil
    import tempfile

    # Nur von der fest einprogrammierten, oeffentlichen Release-Quelle --
    # verhindert, dass ein manipuliertes Manifest die App auf eine
    # beliebige andere Download-Adresse umlenkt.
    allowed_hosts = ("github.com", "raw.githubusercontent.com", "release-assets.githubusercontent.com",
                      "objects.githubusercontent.com", "codeload.github.com")
    from urllib.parse import urlparse
    host = urlparse(download_url).hostname or ""
    if not any(host == h or host.endswith("." + h) for h in allowed_hosts):
        return {"status": "error", "error": f"Download-Adresse nicht vertrauenswürdig: {host}"}

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        zip_path = tmp_path / "update.zip"
        try:
            with urllib.request.urlopen(download_url, timeout=60) as resp:
                zip_path.write_bytes(resp.read())
        except Exception as e:
            return {"status": "error", "error": f"Download fehlgeschlagen: {e}"}

        actual_hash = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        if expected_sha256 and actual_hash.lower() != expected_sha256.lower():
            return {"status": "error", "error": "Prüfsumme stimmt nicht überein -- Update wurde NICHT eingespielt (möglicherweise beschädigter oder manipulierter Download)."}

        extract_dir = tmp_path / "extracted"
        try:
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(extract_dir)
        except zipfile.BadZipFile:
            return {"status": "error", "error": "Heruntergeladene Datei ist kein gültiges ZIP-Archiv."}

        # Das ZIP enthaelt einen Wurzelordner (z.B. "familyfinance/") --
        # dessen Inhalt ist die eigentliche Quelle.
        entries = list(extract_dir.iterdir())
        source_root = entries[0] if len(entries) == 1 and entries[0].is_dir() else extract_dir

        # Gleiche Ausschlussliste wie update.command: niemals echte Daten,
        # Geheimnisse oder plattformspezifische Skripte ueberschreiben.
        skip_names = {"data", "__pycache__", "scripts", "update.command",
                      "start-windows.ps1", "Start-FamilyFinance.bat", ".git"}
        for item in source_root.iterdir():
            if item.name in skip_names:
                continue
            target = BASE_DIR / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)

    restart_service()
    return {"status": "applied"}


def _package_names() -> list:
    """Nur die reinen Paketnamen aus requirements.txt (ohne Kommentarzeilen,
    ohne Extras wie 'uvicorn[standard]' -> 'uvicorn')."""
    names = []
    for line in REQUIREMENTS_PATH.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name = re.split(r"[\[<>=!~]", line)[0].strip()
        if name:
            names.append(name)
    return names


def check_outdated(timeout: int = 30) -> dict:
    """Fragt pip, welche der in requirements.txt gelisteten Pakete veraltet
    sind. Läuft über 'python -m pip', damit garantiert das pip DIESES
    venvs verwendet wird, nicht versehentlich ein System-pip."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "list", "--outdated", "--format=json"],
            capture_output=True, text=True, timeout=timeout, check=True,
        )
        all_outdated = json.loads(result.stdout)
    except Exception as e:
        return {"checked_at": datetime.now().isoformat(), "error": str(e), "outdated": []}

    our_packages = {n.lower() for n in _package_names()}
    relevant = [
        {"name": p["name"], "current": p["version"], "latest": p["latest_version"]}
        for p in all_outdated
        if p["name"].lower() in our_packages
    ]
    return {"checked_at": datetime.now().isoformat(), "error": None, "outdated": relevant}


def restart_service(delay_seconds: float = 1.5) -> dict:
    """Startet den eigenen Dienst neu (nach einem Paket-Update nötig, damit
    die neuen Versionen tatsächlich geladen werden). Läuft in einem von
    diesem Prozess losgelösten Hintergrundprozess mit kurzer Verzögerung —
    sonst würde der Neustart-Befehl genau den Prozess killen, der gerade
    noch die HTTP-Antwort auf diesen Aufruf senden will.
    Hinweis: Der Secret Key ist pro Prozess zufällig (nicht dateibasiert),
    d.h. nach dem Neustart ist die aktuelle Sitzung ungültig — das Frontend
    muss den Nutzer nach dem Reload neu anmelden lassen.

    Plattform-Unterschied: Unter macOS läuft die App als launchd-Dienst,
    der sich selbst per launchctl neu starten lässt. Unter Windows gibt es
    kein Äquivalent — dort beendet sich der Prozess stattdessen selbst,
    und das Start-Skript (start.bat/.ps1) erkennt das Beenden und startet
    den Server automatisch neu (Supervisor-Schleife)."""
    if platform.system() == "Windows":
        def _delayed_exit():
            time.sleep(delay_seconds)
            os._exit(0)
        threading.Thread(target=_delayed_exit, daemon=True).start()
        return {"status": "restarting"}

    uid = os.getuid()
    cmd = f"sleep {delay_seconds} && launchctl kickstart -k gui/{uid}/com.familyfinance.server"
    try:
        subprocess.Popen(
            ["/bin/sh", "-c", cmd],
            start_new_session=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        return {"status": "restarting"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


def backup_database(keep_last: int = 14) -> dict:
    """Sichert die SQLite-Datenbank über SQLites eigene Backup-API — sicher
    auch dann, wenn gerade geschrieben wird (im Gegensatz zu einer simplen
    Datei-Kopie, die einen inkonsistenten Zwischenzustand erwischen könnte).
    Besonders wichtig, seit die App in einem iCloud-synchronisierten Ordner
    liegt: iCloud selbst ist NICHT SQLite-bewusst und könnte theoretisch
    mitten in einem Schreibvorgang synchronisieren. Behält nur die letzten
    N Sicherungen, ältere werden automatisch entfernt."""
    import sqlite3
    db_path = BASE_DIR / "data" / "finance.db"
    if not db_path.exists():
        return {"success": False, "error": "Keine Datenbank gefunden."}

    backup_dir = BASE_DIR / "data" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    backup_path = backup_dir / f"finance_{timestamp}.db"

    try:
        source = sqlite3.connect(str(db_path))
        dest = sqlite3.connect(str(backup_path))
        source.backup(dest)
        dest.close()
        source.close()
    except Exception as e:
        return {"success": False, "error": str(e)}

    backups = sorted(backup_dir.glob("finance_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[keep_last:]:
        old.unlink()

    return {
        "success": True, "path": str(backup_path.relative_to(BASE_DIR)),
        "created_at": timestamp, "total_backups": min(len(backups), keep_last),
    }


def list_backups() -> list:
    backup_dir = BASE_DIR / "data" / "backups"
    if not backup_dir.exists():
        return []
    backups = sorted(backup_dir.glob("finance_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    return [
        {"filename": p.name, "size_kb": round(p.stat().st_size / 1024, 1),
         "created_at": datetime.fromtimestamp(p.stat().st_mtime).isoformat()}
        for p in backups
    ]


def upgrade_all(timeout: int = 300) -> dict:
    """Aktualisiert alle in requirements.txt gelisteten Pakete auf die
    jeweils neueste Version. Bewusst die GANZE, feste Liste statt einzelner
    vom Aufrufer übergebener Namen — verhindert, dass diese Funktion für
    beliebige Paket-Installationen zweckentfremdet werden könnte."""
    names = _package_names()
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--break-system-packages", *names],
            capture_output=True, text=True, timeout=timeout,
        )
        return {
            "success": result.returncode == 0,
            "output": (result.stdout or "") + (result.stderr or ""),
        }
    except Exception as e:
        return {"success": False, "output": str(e)}
