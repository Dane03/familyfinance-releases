"""
Erinnerungs-Job — täglich per launchd/cron auf dem Mac Mini ausführen.

Prüft fällige Erinnerungen (Kündigungsfristen, Vertragsenden) und verschickt
eine E-Mail. Der Mail-Versand selbst braucht zwangsläufig einen SMTP-Server
(dein normales E-Mail-Konto) — das ist reiner Transport, keine Cloud-KI und
keine Verarbeitung deiner Finanzdaten durch Dritte.

Konfiguration über Umgebungsvariablen (z.B. in ~/.familyfinance.env):
    SMTP_HOST=smtp.mail.me.com
    SMTP_PORT=587
    SMTP_USER=deine@icloud.com
    SMTP_PASSWORD=app-spezifisches-passwort
    NOTIFY_EMAIL=deine@icloud.com,frau@icloud.com
"""
import os
import smtplib
from email.mime.text import MIMEText

from database import get_connection


def send_email(subject: str, body: str):
    host = os.environ.get("SMTP_HOST")
    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ.get("SMTP_USER")
    password = os.environ.get("SMTP_PASSWORD")
    recipients = os.environ.get("NOTIFY_EMAIL", "").split(",")

    if not all([host, user, password]) or not recipients:
        print("SMTP nicht konfiguriert — Erinnerung wird nur in der Konsole ausgegeben:")
        print(subject, "\n", body)
        return

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = ", ".join(recipients)

    with smtplib.SMTP(host, port) as server:
        server.starttls()
        server.login(user, password)
        server.sendmail(user, recipients, msg.as_string())


def run():
    conn = get_connection()
    due = conn.execute(
        """SELECT r.id, r.message, r.reminder_type, c.label
           FROM reminders r JOIN contracts c ON c.id = r.contract_id
           WHERE r.sent = 0 AND r.trigger_date <= date('now')"""
    ).fetchall()

    for r in due:
        subject = f"[Family Finance] Erinnerung: {r['label']}"
        send_email(subject, r["message"])
        conn.execute(
            "UPDATE reminders SET sent=1, sent_at=CURRENT_TIMESTAMP WHERE id=?", (r["id"],)
        )

    conn.commit()
    conn.close()
    print(f"{len(due)} Erinnerung(en) verschickt.")


if __name__ == "__main__":
    run()
