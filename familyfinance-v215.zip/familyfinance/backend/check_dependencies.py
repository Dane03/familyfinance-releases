"""
Wöchentlicher Hintergrund-Check auf veraltete Python-Pakete — läuft
unabhängig davon, ob die App-Sitzung gerade offen ist (per launchd,
siehe scripts/com.familyfinance.dependency-check.plist).

Schreibt das Ergebnis nur in die settings-Tabelle; nimmt selbst NICHT
automatisch ein Update vor — das bleibt bewusst dem Button in den
Einstellungen vorbehalten, damit nichts ungefragt im Hintergrund passiert.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import maintenance
from database import get_connection, init_db


def main():
    init_db()
    result = maintenance.check_outdated(timeout=60)
    conn = get_connection()
    conn.execute("DELETE FROM settings WHERE key='dependency_check_result'")
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('dependency_check_result', ?)",
        (json.dumps(result),),
    )
    conn.commit()
    conn.close()
    if result["outdated"]:
        print(f"{len(result['outdated'])} veraltete Pakete gefunden.")
    else:
        print("Alle Pakete aktuell.")


if __name__ == "__main__":
    main()
