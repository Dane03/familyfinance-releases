#!/bin/bash
# Family Finance — Zugang zurücksetzen (Passwort vergessen / Passkey verloren)
#
# Einfach doppelklicken. Setzt AUSSCHLIESSLICH Benutzername, Passwort und
# alle registrierten Passkeys/TOTP-Codes zurück — alle Finanzdaten bleiben
# unverändert erhalten.

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$HOME/familyfinance-venv"

PLIST_PATH="$HOME/Library/LaunchAgents/com.familyfinance.server.plist"
if [ -f "$PLIST_PATH" ]; then
    WORKDIR="$(plutil -extract WorkingDirectory raw "$PLIST_PATH" 2>/dev/null)"
fi
if [ -n "$WORKDIR" ]; then
    PROJECT_DIR="$(dirname "$WORKDIR")"
else
    PROJECT_DIR="$SOURCE_DIR"
fi

echo "🔐 Family Finance — Zugang zurücksetzen"
echo ""
echo "Projekt: $PROJECT_DIR"
echo ""

# Dienst anhalten, damit kein gleichzeitiger Schreibzugriff auf die
# Datenbank entsteht, während dieses Skript läuft.
if [ -f "$PLIST_PATH" ]; then
    echo "Halte laufenden Dienst kurz an …"
    launchctl bootout "gui/$(id -u)/com.familyfinance.server" 2>/dev/null
fi

"$VENV_DIR/bin/python3" "$PROJECT_DIR/backend/reset_access.py"
RESULT=$?

if [ -f "$PLIST_PATH" ]; then
    echo ""
    echo "Starte Dienst wieder …"
    launchctl bootstrap "gui/$(id -u)" "$PLIST_PATH" 2>/dev/null
    launchctl kickstart -k "gui/$(id -u)/com.familyfinance.server" 2>/dev/null
fi

echo ""
if [ $RESULT -eq 0 ]; then
    echo "Fertig — Family Finance im Browser öffnen und mit dem neuen Passwort anmelden."
fi
echo "Dieses Fenster kann geschlossen werden."
read -p "Drücke Enter zum Beenden..."
