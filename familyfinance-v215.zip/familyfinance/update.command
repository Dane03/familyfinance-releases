#!/bin/bash
# Family Finance — Update-Skript
#
# Einfach nach dem Entpacken eines neuen Zips doppelklicken (egal wo entpackt,
# Downloads/Desktop/etc. — das Skript findet seinen eigenen Ordner selbst).
# Aktualisiert nur den Code, lässt Daten und die venv unberührt, startet den
# Server danach neu — und räumt am Ende den entpackten Download-Ordner auf.

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$HOME/familyfinance-venv"

# Zielordner nicht fest auf ~/familyfinance annehmen — falls der
# Projektordner z.B. nach ~/Documents oder auf den Schreibtisch verschoben
# wurde (für iCloud-Backup), steht der tatsächliche aktuelle Ort in der
# installierten launchd-Plist (WorkingDirectory zeigt auf .../backend,
# daher hier eine Ebene hoch). Das ist die einzige verlässliche Quelle,
# da sie beim Verschieben ohnehin manuell angepasst werden muss.
PLIST_PATH="$HOME/Library/LaunchAgents/com.familyfinance.server.plist"
if [ -f "$PLIST_PATH" ]; then
    WORKDIR="$(plutil -extract WorkingDirectory raw "$PLIST_PATH" 2>/dev/null)"
fi
if [ -n "$WORKDIR" ]; then
    TARGET_DIR="$(dirname "$WORKDIR")"
else
    TARGET_DIR="$HOME/familyfinance"
fi

echo "🔄 Family Finance wird aktualisiert …"
echo ""
echo "Quelle: $SOURCE_DIR"
echo "Ziel:   $TARGET_DIR"
echo ""

if [ ! -d "$TARGET_DIR" ]; then
    echo "❌ $TARGET_DIR existiert noch nicht."
    echo "   Das sieht nach der Ersteinrichtung aus — bitte einmalig manuell"
    echo "   nach der README einrichten, danach funktioniert dieses Skript."
    echo ""
    read -p "Fenster schließen mit Enter … "
    exit 1
fi

echo "📦 Kopiere aktualisierte Dateien (Daten, venv & plist bleiben unberührt) …"
rsync -a \
  --exclude '__pycache__' \
  --exclude 'data' \
  --exclude 'scripts' \
  --exclude 'update.command' \
  "$SOURCE_DIR"/ "$TARGET_DIR"/

if [ -d "$VENV_DIR" ]; then
    echo "📚 Prüfe Python-Abhängigkeiten (still, falls nichts Neues) …"
    "$VENV_DIR/bin/pip" install -q -r "$TARGET_DIR/backend/requirements.txt" \
        || echo "⚠️  pip install hatte Probleme — bei Bedarf manuell prüfen."
fi

echo "🔁 Starte den Server neu …"
launchctl kickstart -k "gui/$(id -u)/com.familyfinance.server" 2>/dev/null

sleep 3

STATUS=$(curl -s -o /dev/null -w '%{http_code}' http://localhost:8420/ 2>/dev/null)
STATUS="${STATUS:-000}"

echo ""
if [ "$STATUS" = "200" ]; then
    echo "✅ Fertig! Server läuft (Status $STATUS)."
    echo "   Browser hart neu laden (Cmd+Shift+R), um die neue Version zu sehen."
else
    echo "⚠️  Server antwortet mit Status $STATUS statt 200."
    echo "   Fehlerprotokoll ansehen mit:"
    echo "   cat /tmp/familyfinance-server-error.log"
fi

echo ""
read -p "Enter drücken, um fertigzustellen und aufzuräumen … "

# Aufräumen: den entpackten Download-Ordner UND die dazugehörige .zip-Datei
# (liegt normalerweise direkt daneben mit demselben Namen, z.B.
# "familyfinance.zip" neben "familyfinance/") wieder entfernen, damit sich in
# Downloads nicht immer mehr alte Kopien ansammeln. Mit Sicherheitsprüfung,
# damit niemals versehentlich der eigentliche Projekt- oder Home-Ordner
# gelöscht wird.
PARENT_DIR="$(dirname "$SOURCE_DIR")"
ZIP_PATH="$PARENT_DIR/$(basename "$SOURCE_DIR").zip"

if [ -n "$SOURCE_DIR" ] \
   && [ "$SOURCE_DIR" != "$HOME" ] \
   && [ "$SOURCE_DIR" != "$TARGET_DIR" ] \
   && [ "$SOURCE_DIR" != "/" ]; then
    cd "$HOME" || exit 0
    rm -rf "$SOURCE_DIR"
    echo "🧹 $SOURCE_DIR wurde entfernt."
fi

if [ -f "$ZIP_PATH" ]; then
    rm -f "$ZIP_PATH"
    echo "🧹 $ZIP_PATH wurde ebenfalls entfernt."
fi
