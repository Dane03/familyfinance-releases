# Family Finance — Einrichtung unter Windows

## Einmalige Einrichtung

1. **Diesen ganzen Ordner** irgendwohin entpacken, z. B. nach `Dokumente\familyfinance`
2. Doppelklick auf **`Start-FamilyFinance.bat`**
3. Beim allerersten Start passiert automatisch Folgendes (dauert je nach
   Internetverbindung 10–30 Minuten, danach nie wieder):
   - Python-Pakete werden installiert
   - Tesseract (Texterkennung für Belege) wird heruntergeladen und installiert
   - Ollama (die KI, die lokal auf diesem PC läuft — nichts wird an
     externe Server geschickt) wird heruntergeladen und installiert
   - Das KI-Modell selbst (ca. 5 GB) wird heruntergeladen
4. Danach öffnet sich automatisch der Browser mit der App

**Wichtig:** Für diesen einmaligen Ersteinrichtungs-Schritt wird eine
Internetverbindung gebraucht. Danach läuft alles komplett offline auf
diesem PC — keine Daten verlassen den Rechner.

## Bei jedem weiteren Start

Einfach wieder auf `Start-FamilyFinance.bat` doppelklicken — das geht dann
in wenigen Sekunden, da alles schon installiert ist.

Das sich öffnende schwarze Fenster **während der Nutzung offen lassen** —
das ist der laufende Server im Hintergrund. Zum Beenden einfach das
Fenster schließen.

## Erster Login

Beim allerersten Öffnen der App im Browser wirst du nach einem
Benutzernamen und einem Passwort gefragt — das legst du selbst frei fest,
das ist nur für diese eine Installation auf diesem PC.

## Eigene Personen anlegen

Die App startet komplett leer — auch ohne vorbelegte Namen. Unter
**Einstellungen → Personen** trägst du eure eigenen Familienmitglieder ein,
bevor du mit Einnahmen/Ausgaben/Vorsorge loslegst.

## Falls etwas nicht klappt

Am häufigsten: Python fehlt noch. Falls das Skript das meldet, einmal
https://www.python.org/downloads/ öffnen, herunterladen, installieren —
**wichtig:** beim Installieren den Haken bei "Add python.exe to PATH"
setzen. Danach `Start-FamilyFinance.bat` erneut starten.
