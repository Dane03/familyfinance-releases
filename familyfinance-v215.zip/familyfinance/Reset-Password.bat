@echo off
REM Family Finance — Zugang zurücksetzen (Passwort vergessen / Passkey verloren)
REM
REM Einfach doppelklicken. Setzt AUSSCHLIESSLICH Benutzername, Passwort und
REM alle registrierten Passkeys/TOTP-Codes zurück — alle Finanzdaten bleiben
REM unveraendert erhalten.

setlocal
set "SCRIPT_DIR=%~dp0"
set "VENV_PYTHON=%SCRIPT_DIR%venv\Scripts\python.exe"

echo.
echo Family Finance - Zugang zuruecksetzen
echo.
echo Projekt: %SCRIPT_DIR%
echo.

REM Laufenden Server-Prozess beenden, damit kein gleichzeitiger
REM Schreibzugriff auf die Datenbank entsteht.
echo Beende laufenden Server (falls aktiv) ...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq Family Finance*" >nul 2>&1

if not exist "%VENV_PYTHON%" (
    echo FEHLER: Python-Umgebung nicht gefunden unter %VENV_PYTHON%
    echo Ist das hier der richtige Ordner ^(mit dem venv-Unterordner^)?
    pause
    exit /b 1
)

"%VENV_PYTHON%" "%SCRIPT_DIR%backend\reset_access.py"

echo.
echo Fertig. Family Finance ueber Start-FamilyFinance.bat neu starten und mit
echo dem neuen Passwort anmelden.
echo.
pause
