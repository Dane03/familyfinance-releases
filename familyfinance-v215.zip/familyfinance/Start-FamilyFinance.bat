@echo off
REM Family Finance -- einfach doppelklicken zum Starten.
REM Beim allerersten Mal dauert es laenger (Python-Pakete, Tesseract,
REM Ollama und das KI-Modell werden automatisch heruntergeladen).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-windows.ps1"
pause
