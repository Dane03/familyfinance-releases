// ---------- Textgrößen-Einstellung (S/M/L): sofort anwenden, noch bevor
// irgendetwas anderes lädt, damit die Seite nicht erst in einer Größe
// aufblitzt und dann umspringt. Der Server-Wert (siehe app.js/bootApp)
// bestätigt/aktualisiert das anschließend — dieser lokale Zwischenspeicher
// ist rein eine Anzeige-Beschleunigung, keine sicherheitsrelevante Angabe.
(function applyCachedUiScale() {
  const cached = localStorage.getItem("ui_scale");
  if (cached && ["s", "m", "l"].includes(cached)) {
    document.documentElement.classList.add(`ui-scale-${cached}`);
  } else {
    document.documentElement.classList.add("ui-scale-m");
  }
})();

// ---------- Basis-Helfer: base64url <-> ArrayBuffer ----------
function b64urlToBuf(b64url) {
  const pad = "=".repeat((4 - (b64url.length % 4)) % 4);
  const b64 = (b64url + pad).replace(/-/g, "+").replace(/_/g, "/");
  const str = atob(b64);
  const buf = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) buf[i] = str.charCodeAt(i);
  return buf.buffer;
}
function bufToB64url(buf) {
  const bytes = new Uint8Array(buf);
  let str = "";
  for (const b of bytes) str += String.fromCharCode(b);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function api(path, body) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
    credentials: "same-origin",
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "Fehler");
  return data;
}

// ---------- Passkey-Voraussetzungen prüfen ----------
function webauthnSupportIssue() {
  if (!window.isSecureContext) {
    return `Diese Seite läuft nicht in einem sicheren Kontext (aktuell: ${location.protocol}//${location.hostname}). ` +
      "Passkeys funktionieren nur über https:// oder http://localhost.";
  }
  if (!window.PublicKeyCredential) {
    return "Dieser Browser unterstützt keine Passkeys (WebAuthn). Bitte einen aktuellen Browser verwenden (Safari, Chrome).";
  }
  return null;
}

function formatWebAuthnError(err) {
  // err.name liefert oft den eigentlich hilfreichen Teil (z.B. "NotAllowedError",
  // "SecurityError", "InvalidStateError") — err.message ist bei WebAuthn-Fehlern
  // im Browser oft generisch/leer.
  console.error("WebAuthn-Fehler:", err);
  const detail = err && err.name ? `${err.name}: ${err.message || "kein Detail"}` : (err.message || String(err));
  return detail;
}

// ---------- Passkey registrieren (nach Setup oder Login mit Passwort) ----------
async function registerPasskey(label) {
  const options = await api("/api/auth/passkey/register/begin");
  options.challenge = b64urlToBuf(options.challenge);
  options.user.id = b64urlToBuf(options.user.id);
  if (options.excludeCredentials) {
    options.excludeCredentials = options.excludeCredentials.map((c) => ({
      ...c, id: b64urlToBuf(c.id),
    }));
  }

  const cred = await navigator.credentials.create({ publicKey: options });

  const credentialJSON = {
    id: cred.id,
    rawId: bufToB64url(cred.rawId),
    type: cred.type,
    response: {
      clientDataJSON: bufToB64url(cred.response.clientDataJSON),
      attestationObject: bufToB64url(cred.response.attestationObject),
    },
  };
  return api("/api/auth/passkey/register/complete", { credential: credentialJSON, label });
}

// ---------- Passkey-Anmeldung (2. Faktor) ----------
async function loginWithPasskey() {
  const options = await api("/api/auth/passkey/login/begin");
  options.challenge = b64urlToBuf(options.challenge);
  if (options.allowCredentials) {
    options.allowCredentials = options.allowCredentials.map((c) => ({
      ...c, id: b64urlToBuf(c.id),
    }));
  }

  const cred = await navigator.credentials.get({ publicKey: options });

  const credentialJSON = {
    id: cred.id,
    rawId: bufToB64url(cred.rawId),
    type: cred.type,
    response: {
      clientDataJSON: bufToB64url(cred.response.clientDataJSON),
      authenticatorData: bufToB64url(cred.response.authenticatorData),
      signature: bufToB64url(cred.response.signature),
      userHandle: cred.response.userHandle ? bufToB64url(cred.response.userHandle) : null,
    },
  };
  return api("/api/auth/passkey/login/complete", { credential: credentialJSON });
}

// ---------- Login-Overlay steuern ----------
const overlay = document.getElementById("auth-overlay");
const authMsg = document.getElementById("auth-message");

function showStep(stepId) {
  document.querySelectorAll(".auth-step").forEach((el) => (el.style.display = "none"));
  document.getElementById(stepId).style.display = "block";
}

function setMessage(text, isError = false) {
  authMsg.textContent = text || "";
  authMsg.style.color = isError ? "var(--bad)" : "var(--muted)";
}

// bootApp() ist in app.js definiert. Unter normalen Umständen ist das
// beim Aufruf hier längst geladen (Skript-Reihenfolge), aber bei einer
// besonders schnellen automatischen Session-Wiederherstellung (z.B. gültiger
// Cookie + Passkey nicht nötig) kann der Aufruf theoretisch minimal vor
// Fertigstellung von app.js erfolgen. Ein einmaliges Fehlschlagen würde die
// App dauerhaft bei "Lade …" hängen lassen, ohne jede Wiederholung — daher
// hier robust: kurz nachfragen statt endgültig aufzugeben.
function safeBootApp(retriesLeft = 20) {
  if (typeof bootApp === "function") {
    bootApp();
  } else if (retriesLeft > 0) {
    setTimeout(() => safeBootApp(retriesLeft - 1), 50);
  } else {
    console.error("bootApp konnte nicht geladen werden — bitte Seite neu laden.");
  }
}

async function checkAuthAndBoot() {
  // Immer sauber starten: alle Overlays (Kategorien-Einstellungen, Ausgabe-
  // Details, Ausgabe-hinzufügen, ...) hart zurücksetzen, unabhängig davon,
  // ob eins davon aus einer vorherigen Sitzung noch offen "hängen geblieben"
  // war — z.B. wenn der Browser die Seite aus dem Hintergrund wiederherstellt,
  // ohne sie wirklich neu zu laden. Das Login-Overlay wird direkt im
  // Anschluss von der eigentlichen Logik unten korrekt gesetzt.
  document.querySelectorAll(".overlay").forEach((el) => (el.style.display = "none"));

  // Update-Check bewusst VOR jeder Anmeldung — auch wer sich aus der App
  // ausgesperrt hat (z.B. Passwort vergessen), soll trotzdem aktualisieren
  // können, ohne sich vorher irgendwie einloggen zu müssen. Ein
  // Fehlschlagen hier (kein Netz, Server down) darf den restlichen
  // Anmelde-Ablauf nicht blockieren.
  try {
    const updateData = await (await fetch("/api/public/check-updates", { cache: "no-store" })).json();
    const hasAppUpdate = !!(updateData.app && updateData.app.update_available);
    const outdatedCount = (updateData.packages && updateData.packages.outdated && updateData.packages.outdated.length) || 0;
    if (hasAppUpdate || outdatedCount > 0) {
      pendingPreLoginUpdate = {
        apply_app: hasAppUpdate, apply_packages: outdatedCount > 0,
        download_url: hasAppUpdate ? updateData.app.download_url : null,
        sha256: hasAppUpdate ? updateData.app.sha256 : null,
      };
      const parts = [];
      if (hasAppUpdate) parts.push(`App-Version ${updateData.app.latest_version}`);
      if (outdatedCount > 0) parts.push(`${outdatedCount} Python-Paket${outdatedCount > 1 ? "e" : ""}`);
      document.getElementById("update-available-message").textContent = `Verfügbar: ${parts.join(" · ")}. Jetzt aktualisieren oder erst anmelden?`;
      overlay.style.display = "flex";
      showStep("step-update-available");
      return;
    }
  } catch (e) {
    // Kein Update-Server erreichbar -- normal weiter zur Anmeldung, das ist
    // kein Grund, den Login zu blockieren.
  }

  await proceedToAuthStep();
}

let pendingPreLoginUpdate = null;

async function proceedToAuthStep() {
  let status;
  try {
    const res = await fetch("/api/auth/status", { credentials: "same-origin", cache: "no-store" });
    if (!res.ok) throw new Error(`Server antwortete mit ${res.status}`);
    status = await res.json();
  } catch (err) {
    // Wichtig: Die App-Oberfläche kann aus dem Service-Worker-Cache geladen worden
    // sein, obwohl der Server gar nicht läuft. Ohne diese Behandlung sähe man eine
    // scheinbar "eingeloggte", aber leere App — deshalb hier klar Bescheid geben.
    overlay.style.display = "flex";
    document.querySelectorAll(".auth-step").forEach((el) => (el.style.display = "none"));
    setMessage(
      "Keine Verbindung zum Server. Die Seite wurde aus dem Zwischenspeicher geladen — " +
      "der Server läuft vermutlich nicht. Bitte den Server starten und diese Seite neu laden. " +
      `(Details: ${err.message})`,
      true,
    );
    return;
  }

  if (status.setup_required) {
    overlay.style.display = "flex";
    showStep("setup-form");
    return;
  }
  if (!status.authenticated) {
    overlay.style.display = "flex";
    showStep("login-form");
    return;
  }
  overlay.style.display = "none";
  safeBootApp(); // definiert in app.js, robust gegen Race Condition
}

document.getElementById("update-login-btn").addEventListener("click", () => proceedToAuthStep());
document.getElementById("update-cancel-btn").addEventListener("click", () => proceedToAuthStep());

document.getElementById("update-now-btn").addEventListener("click", async () => {
  if (!pendingPreLoginUpdate) return;
  const progressEl = document.getElementById("update-progress-message");
  document.querySelectorAll("#step-update-available button").forEach((b) => (b.disabled = true));
  progressEl.textContent = "Aktualisiere … das kann einige Minuten dauern.";
  try {
    const res = await fetch("/api/public/apply-updates", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(pendingPreLoginUpdate),
    });
    const data = await res.json();
    if (data.status === "applied") {
      // Service-Worker mit aktualisieren, damit nach dem Neustart nicht
      // zusätzlich noch die separate "Neue Version verfügbar"-Meldung der
      // PWA selbst erscheint -- beides soll in einem Schritt passieren.
      if ("serviceWorker" in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map((r) => r.unregister()));
      }
      progressEl.textContent = "✅ Aktualisiert — Seite lädt in wenigen Sekunden neu.";
      setTimeout(() => window.location.reload(), 4000);
    } else {
      progressEl.textContent = "❌ Fehlgeschlagen. Details siehe Konsole.";
      console.error("Update fehlgeschlagen:", data);
      document.querySelectorAll("#step-update-available button").forEach((b) => (b.disabled = false));
    }
  } catch (e) {
    progressEl.textContent = `❌ Fehlgeschlagen: ${e.message}`;
    document.querySelectorAll("#step-update-available button").forEach((b) => (b.disabled = false));
  }
});

document.getElementById("setup-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("setup-username").value;
  const password = document.getElementById("setup-password").value;
  try {
    setMessage("Richte Zugang ein …");
    await api("/api/auth/setup", { username, password });
    setMessage("Jetzt Passkey registrieren, um die Einrichtung abzuschließen.");
    showStep("step-register-passkey");
  } catch (err) {
    setMessage(err.message, true);
  }
});

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;
  try {
    setMessage("Prüfe Passwort …");
    await api("/api/auth/login", { username, password });
    const status = await fetch("/api/auth/status", { credentials: "same-origin" }).then((r) => r.json());
    if (status.passkey_registered) {
      setMessage("");
      showStep("step-login-passkey");
    } else if (status.totp_registered) {
      setMessage("");
      showStep("step-login-totp");
    } else {
      setMessage("Für diese Adresse ist noch kein zweiter Faktor eingerichtet — jetzt einrichten:");
      showStep("step-register-passkey");
    }
  } catch (err) {
    setMessage(err.message, true);
  }
});

document.getElementById("register-passkey-btn").addEventListener("click", async () => {
  const issue = webauthnSupportIssue();
  if (issue) return setMessage(issue, true);
  try {
    setMessage("Bitte im Browser-Dialog bestätigen (Face ID / Touch ID / Sicherheitsschlüssel) …");
    await registerPasskey("Mein Gerät");
    overlay.style.display = "none";
    safeBootApp();
  } catch (err) {
    setMessage("Passkey-Registrierung fehlgeschlagen: " + formatWebAuthnError(err), true);
  }
});

document.getElementById("login-passkey-btn").addEventListener("click", async () => {
  const issue = webauthnSupportIssue();
  if (issue) return setMessage(issue, true);
  try {
    setMessage("Bitte im Browser-Dialog bestätigen (Face ID / Touch ID / Sicherheitsschlüssel) … " +
      "(Falls sich nichts tut: prüfe, ob eine Anfrage im Hintergrund wartet, z.B. hinter dem Browser-Fenster.)");
    await loginWithPasskey();
    overlay.style.display = "none";
    safeBootApp();
  } catch (err) {
    setMessage("Passkey-Anmeldung fehlgeschlagen: " + formatWebAuthnError(err), true);
  }
});

// ---------- TOTP (Authenticator-App) als Alternative zum Passkey ----------
document.getElementById("choose-totp-instead-btn").addEventListener("click", async () => {
  await startTotpSetupFlow();
});

async function startTotpSetupFlow() {
  try {
    const data = await api("/api/auth/totp/setup/begin", {});
    pendingTotpSecret = data.secret;
    const qrContainer = document.getElementById("totp-qr-container");
    // QR-Code als extern generiertes Bild waere ein Datenschutz-Bruch (die
    // otpauth-URL wuerde an einen fremden Server geschickt) -- stattdessen
    // eine winzige, rein clientseitige QR-Bibliothek waere Overkill fuer
    // dieses eine Bild. Pragmatischer Mittelweg: Server liefert bereits ein
    // fertiges QR-PNG mit, siehe otpauth_url unten als Text-Fallback.
    qrContainer.innerHTML = `<img src="/api/auth/totp/qr?secret=${encodeURIComponent(data.secret)}" alt="QR-Code" style="width:200px;height:200px" />`;
    document.getElementById("totp-secret-fallback").textContent = `Funktioniert der QR-Code nicht? Manuell eintragen: ${data.secret}`;
    showStep("step-totp-setup");
  } catch (err) {
    setMessage("TOTP-Einrichtung fehlgeschlagen: " + err.message, true);
  }
}

let pendingTotpSecret = null;

document.getElementById("totp-back-to-passkey-btn").addEventListener("click", () => {
  showStep("step-register-passkey");
});

document.getElementById("totp-setup-confirm-btn").addEventListener("click", async () => {
  const code = document.getElementById("totp-setup-code").value.trim();
  if (!pendingTotpSecret || !code) return;
  try {
    await api("/api/auth/totp/setup/complete", { secret: pendingTotpSecret, code });
    overlay.style.display = "none";
    safeBootApp();
  } catch (err) {
    setMessage("Code stimmt nicht überein — bitte erneut versuchen.", true);
  }
});

document.getElementById("step-login-totp").addEventListener("submit", async (e) => {
  e.preventDefault();
  const code = document.getElementById("login-totp-code").value.trim();
  try {
    await api("/api/auth/totp/login", { code });
    overlay.style.display = "none";
    safeBootApp();
  } catch (err) {
    setMessage("Code stimmt nicht überein — bitte erneut versuchen.", true);
  }
});

document.getElementById("logout-btn").addEventListener("click", async () => {
  await api("/api/auth/logout");
  location.reload();
});

checkAuthAndBoot();

// Manche Browser stellen eine Seite aus dem Hintergrund wieder her (z.B. nach
// App-Wechsel oder STRG+Q/erneutem Öffnen), ohne das Skript komplett neu
// auszuführen ("bfcache"). event.persisted erkennt genau diesen Fall — dann
// hier ebenfalls einmal sauber neu prüfen/zurücksetzen, statt den Stand der
// vorherigen Sitzung (inkl. eventuell offener Overlays) einfach anzuzeigen.
window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    checkAuthAndBoot();
  }
});
