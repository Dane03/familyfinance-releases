# Family Finance

Lokale Web-App (PWA) für Mac Mini + Zugriff von Mac & iPhone. Läuft komplett
offline — keine Cloud-APIs, keine Daten verlassen dein Netzwerk.

## Was schon funktioniert (Phase 1 — fertig & getestet)

- ✅ SQLite-Datenbank mit Konten, Einnahmen, Verträgen, Ausgaben, Belegen, Erinnerungen
- ✅ Import deiner bestehenden `Ausgabenübersicht.ods` (`backend/import_ods.py`)
- ✅ FastAPI-Backend mit Dashboard-, Vertrags- und Beleg-Endpunkten
- ✅ Installierbare PWA (Dashboard, Kategorien-Übersicht, Vertragsliste, Erinnerungen)
- ✅ Foto-Upload-Endpunkt mit automatischer Ablage in Ordnerstruktur `data/receipts/JAHR/KATEGORIE/`
- ✅ Erinnerungs-Engine (`backend/reminders.py`) inkl. E-Mail-Versand
- ✅ Chat-Oberfläche + Backend-Anbindung an einen lokalen Chatbot (Ollama)
- ✅ Zugriffsschutz: Passwort + Passkey (WebAuthn/Face ID/Touch ID) als 2FA
- ✅ Feste Kategorien: Versicherungen, Abos, Internet, Mobilfunk, Mitgliedsbeiträge, Sparen, Haus (Finanzierung/Nebenkosten), Sonstiges
- ✅ Übersicht gruppiert nach Kategorie → Vertragspartner, mit Intervall (mtl./quart./jährl.) und automatischer Umrechnung auf p.M.
- ✅ Zwei Überschuss-Kennzahlen wie in deiner Excel: "Überschuss nach Fixkosten" und "Überschuss nach Sparen"
- ✅ Einnahmen-Import aus Gehaltsabrechnungs-PDFs (auch passwortgeschützt), inkl. manueller Nachpflege
- ✅ Manuelles Überschreiben von Verträgen/Einnahmen (✏️-Button) — bleibt gültig, bis ein neues automatisches Update (Foto-Beleg oder Gehaltsabrechnung) den Wert erneut überschreibt
- ✅ Einnahmen jetzt oben in der App, mit Summenzeile, direkt inline editierbar und pro Position löschbar
- ✅ Jede Position (Einnahme, Vertrag) ist inline editierbar (Betrag direkt in der Liste ändern) und über 🗑 löschbar
- ✅ "Noch zu kategorisieren"-Bereich: alle Positionen ohne feste Rubrik werden oben prominent angezeigt, mit Dropdown zur Zuordnung oder 🗑 zum Aussortieren
- ✅ App in Tabs gegliedert: Dashboard · Einnahmen · Verträge · Belege & Chat
- ✅ Dashboard startet mit Fälligkeiten/Vertragsabläufen/Anschlussfinanzierung (statt Zahlen zuerst), inkl. eigener Formulierung für Baufinanzierungen ("Zinsbindung endet" / "Jetzt Anschlussfinanzierung vergleichen")
- ✅ Sichtbarer Versions-Stempel im Header — damit du auf einen Blick siehst, ob dein Browser wirklich die neueste Version geladen hat
- ✅ Dashboard-Blöcke per Drag & Drop umsortierbar (Reihenfolge wird serverseitig gespeichert, gilt für alle Geräte)
- ✅ Verträge innerhalb jeder Rubrik per Drag & Drop umsortierbar, Einnahmen ebenso
- ✅ Vertragsnummer und Link (z.B. Kundenportal) als eigene Felder pro Vertrag
- ✅ Rechtsklick auf einen Vertrag öffnet ein Kontextmenü: Details bearbeiten (Vertragsnummer, Fälligkeit, Zahlungsweise, Link, "Letztes Update" schreibgeschützt) oder Löschen — kein separater Button mehr nötig
- ✅ Nur noch 3 Tabs: Dashboard (inkl. Chatbot ganz unten) · Einnahmen · Verträge (inkl. Beleg-Upload direkt dort)
- ✅ PDF-Export: mehrseitiger Finanz-Report auf Knopfdruck (Überblick, Kategorien, Einnahmen, Ausgaben nach Rubrik, Fälligkeiten) — läuft komplett lokal (reportlab), kein Cloud-Aufruf
- ✅ **Energy Monitor integriert** (bisher eigenständige App): Gas-, Strombezug- und Einspeisungs-Zählerstände, Verbrauchsverlauf, Abrechnungsvergleich (Abschlag vs. tatsächliche Kosten), Ablesekarten-Foto-Upload — als eigener, per Einstellung ein-/ausschaltbarer Bereich in der Sidebar (siehe unten)
- ✅ **Intelligenter Datei-Import** (Einnahmen, Ausgaben, Verträge): beliebige CSV/Excel/ODS-Datei hochladen — Ollama ordnet Spalten automatisch den passenden Feldern zu, Zuordnung ist vor dem Import editierbar, einmal bestätigte Zuordnung wird pro Dateiform gemerkt und beim nächsten Mal automatisch wiederverwendet

## Intelligenter Datei-Import — Details

Zu finden als eigene Karte auf der Einnahmen-Seite (Ziel: Einnahmen) und auf
der Ausgaben-Seite (Ziel wählbar: Verträge/wiederkehrend oder Einzelausgaben,
z.B. ein Kontoauszug-Export).

**Ablauf:**
1. Datei hochladen (CSV, XLSX, ODS — beliebige Spaltenüberschriften)
2. Backend prüft zuerst, ob für genau diese Spaltenkombination schon einmal
   eine Zuordnung bestätigt wurde ("gelerntes Schema") — falls ja, wird sie
   direkt vorgeschlagen, ganz ohne erneuten Ollama-Aufruf
3. Sonst fragt das Backend den lokalen Ollama, welche Spalte zu welchem Feld
   passt (Betrag, Datum, Bezeichnung, Anbieter, …)
4. Läuft Ollama gerade nicht (`ollama serve` nicht aktiv), greift automatisch
   eine einfache Stichwort-Erkennung als Rückfallebene — der Import
   funktioniert dann trotzdem, nur ohne KI-Unterstützung
5. Vorschlag wird angezeigt und ist **vor dem Import** komplett editierbar
6. Erst nach "Import starten" landen die Daten tatsächlich in der Datenbank
   — mit Häkchen "Zuordnung merken" (Standard: an) wird sie fürs nächste Mal
   mit exakt denselben Spaltenüberschriften gespeichert

Alles läuft lokal — die Tabellendaten gehen nur an den lokalen Ollama auf
demselben Mac Mini, nie ins Internet.

## Navigation & Energy Monitor

Seit der Zusammenführung mit dem bisher eigenständigen Energy Monitor gibt es
eine linke Menüleiste statt der vorherigen Reiter oben:

- **Finanzen**: Dashboard · Einnahmen · Ausgaben (unverändert, wie bisher)
- **Energy Monitor** (⚙️ Einstellungen → Häkchen "Energy Monitor anzeigen",
  standardmäßig **aus**): Dashboard · Gas · Strom

Die Zähler-Ablesungen (Gas, Strombezug, Einspeisung) werden genau wie Belege
bei den Ausgaben behandelt: Foto/PDF der Ablesekarte hochladen → lokale OCR
schlägt Zählerstand + Datum vor → kurz bestätigen. Alles läuft direkt auf den
jeweiligen Seiten (Gas/Strom), nicht als separater Upload-Bereich.

**Einmalige Migration der historischen Zählerstände** (nur beim allerersten
Umstieg von der alten Energy-Monitor-App nötig):
```bash
cd ~/familyfinance/backend
source ~/familyfinance-venv/bin/activate
python3 import_energy_monitor.py
```
Sicher mehrfach ausführbar — überspringt bereits vorhandene Ablesungen statt
sie zu duplizieren. Danach im laufenden Betrieb einfach über die
Ablesungen-Formulare auf den Gas-/Strom-Seiten weiterführen.

**Nicht migriert:** Der PV-/Sungrow-Import (iSolarCloud-Solarertrag) aus der
alten App — die Kernfunktionen (Zählerstände, Verbrauch, Abrechnungsvergleich)
sind vollständig übernommen, der PV-Ertragsteil bewusst nicht (sehr
anlagenspezifisch). Kann bei Bedarf ergänzt werden.

## Versions-Stempel — gegen "bei mir sieht's noch alt aus"

Oben im Header steht jetzt z.B. "Build 2026-07-29 · v8". Stimmt die Version
nach dem Update nicht mit der neuesten überein, hilft meist:
1. Sicherstellen, dass wirklich der **komplette** Ordnerinhalt ersetzt wurde
   (macOS legt beim Entpacken in einen bestehenden Ordner gerne einen zweiten
   Ordner wie "familyfinance 2" an — Server dann versehentlich aus dem alten
   Ordner gestartet)
2. Browser hart neu laden (Cmd+Shift+R) bzw. Service Worker in den
   Browser-Entwicklertools löschen ("Application" → "Service Workers" → "Unregister")

## Kategorisierung anpassen

Die Zuordnung von Positionen zu den festen Kategorien steckt in
`backend/categorize.py` — sowohl der Excel-Import als auch die Foto-OCR nutzen
dieselbe Logik. Passt eine automatische Zuordnung nicht, kannst du sie:
1. dauerhaft in `categorize.py` korrigieren (bei neuen wiederkehrenden Anbietern), oder
2. direkt in der App über das ✏️-Symbol am Vertrag manuell umkategorisieren.

## Was noch Handarbeit von dir braucht (Phase 2)

Deine Ursprungsdatei enthielt keine Vertragsnummern, Laufzeitenden oder
Kündigungsfristen — die trägst du einmalig pro Vertrag über `POST /api/contracts`
oder eine kleine Nachpflege-Oberfläche nach (kann ich als nächstes bauen, sobald
das Grundgerüst bei dir läuft).

## Zugriffsschutz: Passwort + Passkey (2FA)

Die App ist jetzt zweistufig abgesichert:

1. **Passwort** — beim allerersten Start richtest du in der App einen Familien-Zugang ein (Benutzername + Passwort, mind. 8 Zeichen, als bcrypt-Hash gespeichert).
2. **Passkey (Face ID / Touch ID / Sicherheitsschlüssel)** als 2. Faktor — direkt im Anschluss registrierst du den ersten Passkey. Ohne diesen zweiten Faktor kommt niemand an die Finanzdaten, selbst mit korrektem Passwort nicht.

Jede Person (du, deine Frau) kann später einen eigenen Passkey auf ihrem eigenen
Gerät registrieren (Button dafür kann ich ergänzen, aktuell über
`POST /api/auth/passkey/register/begin` möglich, sobald man mit Passwort
eingeloggt ist).

### ⚠️ Wichtige technische Einschränkung: Passkeys brauchen HTTPS

Browser erlauben WebAuthn (Passkeys) nur in einem **sicheren Kontext**:
`https://` oder `http://localhost`. Das bedeutet konkret:

- **Am Mac selbst über `http://localhost:8420`**: funktioniert direkt, keine weitere Einrichtung nötig.
- **Vom iPhone im selben WLAN über `http://<Mac-Mini-IP>:8420`**: funktioniert **nicht** — das ist kein sicherer Kontext.
- **Lösung**: Tailscale (siehe komplette Anleitung weiter unten unter "Schöne Adresse + Zugriff vom iPhone").

## Schöne Adresse + Zugriff vom iPhone (auch unterwegs)

Statt `http://localhost:8420` bekommst du mit **Tailscale** eine echte Adresse
wie `https://mac-mini.tailabc123.ts.net` — funktioniert identisch zuhause und
unterwegs, mit gültigem HTTPS-Zertifikat (löst damit auch die
Passkey-Einschränkung oben), ganz ohne eigene Domain, Portfreigabe im Router
oder DynDNS. Tailscale baut dafür ein privates VPN zwischen deinen Geräten auf.

### Einmalige Einrichtung

**1. Tailscale-Konto anlegen** (kostenlos für privaten Gebrauch): auf
[tailscale.com](https://tailscale.com) registrieren.

**2. Auf dem Mac Mini installieren und anmelden:**
```bash
brew install tailscale
sudo tailscale up
```
Öffnet einen Link zum Anmelden im Browser — mit dem gerade erstellten Konto einloggen.

**3. HTTPS-Zertifikate für dein Tailnet aktivieren:**
Im [Tailscale Admin-Konsole](https://login.tailscale.com/admin/dns) unter
"DNS" → "HTTPS Certificates" → aktivieren. Einmalig nötig, danach vergibt
Tailscale automatisch gültige Zertifikate für deine Geräte.

**4. Die App über Tailscale freigeben:**
```bash
tailscale serve --bg --https=443 8420
```
Das leitet `https://<mac-name>.<dein-tailnet>.ts.net` auf deinen lokal
laufenden Server (Port 8420) um — die genaue Adresse zeigt dir:
```bash
tailscale serve status
```

**5. Backend auf diese Adresse einstellen** — in `com.familyfinance.server.plist`
(oder als Umgebungsvariable beim manuellen Start) die per Platzhalter
`mac-mini.tailXXXXX.ts.net` markierten Stellen durch deine echte Adresse aus
Schritt 4 ersetzen:
```
RP_ID=<deine-adresse-ohne-https>
ORIGIN=https://<deine-adresse>
```
Server danach neu starten.

**6. Einmalig einen neuen Passkey registrieren** — Passkeys sind an die exakte
Adresse gebunden. Ein Passkey, der unter `localhost` registriert wurde,
funktioniert unter der neuen Tailscale-Adresse nicht automatisch. Einfach
unter der neuen Adresse einmal neu einloggen (Passwort) und einen Passkey
registrieren.

**7. iPhone einrichten:**
- Tailscale-App aus dem App Store installieren, mit demselben Konto anmelden
- Safari öffnen, zur Tailscale-Adresse aus Schritt 4 navigieren
- Einmalig Passkey registrieren (Face ID)
- Zum Home-Bildschirm hinzufügen (Teilen-Symbol → "Zum Home-Bildschirm") für App-artiges Verhalten

Damit funktioniert der Zugriff vom iPhone **sowohl im Heim-WLAN als auch
unterwegs über Mobilfunk** identisch — Tailscale muss auf beiden Geräten
einfach nur aktiv sein (läuft im Hintergrund, keine manuelle VPN-Verbindung
nötig).

### Läuft das dauerhaft?

Damit die Freigabe (Schritt 4) auch nach einem Mac-Neustart aktiv bleibt:
```bash
tailscale serve --bg --https=443 8420
```
Das `--bg`-Flag merkt sich die Konfiguration dauerhaft im Hintergrund, auch
über Neustarts hinweg (solange Tailscale selbst läuft, was es standardmäßig
tut).

## Beleg-Ordnerstruktur

Belege liegen jetzt so, dass sie 1:1 der Kategorisierung folgen und pro
Vertrag ein eigener Ordner entsteht:

```
data/receipts/
├── _unbestaetigt/                        # frisch hochgeladen, noch nicht bestätigt
├── Haus/
│   ├── Finanzierung/
│   │   └── BBBank_Baufinanzierung/       # ein Ordner pro Vertrag
│   └── Nebenkosten/
│       └── Gas_octopus/
├── Versicherungen/
│   └── Autoversicherung_VHV/
├── Abos/
└── ...
```

Solange ein Beleg noch keinem Vertrag zugeordnet wurde, liegt er in
`_unbestaetigt/`. Sobald du ihn im Bestätigungs-Formular einem Vertrag
zuordnest, verschiebt die App die Datei automatisch in den passenden
Rubrik-/Vertrags-Ordner. Der jeweils letzte bestätigte Beleg ist direkt am
Vertrag hinterlegt — in der Oberfläche erscheint dafür bei jedem Vertrag ein
"📎 Beleg ansehen"-Link, der die Originaldatei öffnet.

## Beleg-Upload: auch als PDF

Der Beleg-Upload akzeptiert jetzt neben Fotos auch PDF-Rechnungen (z.B. per
E-Mail zugeschickte Rechnungen):
- **Digital erzeugte PDFs** (die meisten E-Mail-Rechnungen): Text wird direkt
  aus der PDF gelesen, ganz ohne Bilderkennung — am zuverlässigsten.
- **Eingescannte PDFs** (ohne Textebene): die erste Seite wird automatisch in
  ein Bild umgewandelt und wie ein Foto per Vision/Tesseract erkannt. Dafür
  zusätzlich nötig: `brew install poppler`.

Alles läuft weiterhin komplett lokal, kein Cloud-Aufruf.

## Beleg-Upload: was jetzt anders ist

Der Foto-Upload lief bisher ins Leere, weil nach dem Hochladen keine
Möglichkeit bestand, den Beleg zu bestätigen. Das ist jetzt behoben:

1. Foto hochladen → lokale Texterkennung läuft (macOS Vision, sonst Tesseract)
2. Erkannter Betrag und Anbieter erscheinen **editierbar** — falsch erkannte
   Werte einfach korrigieren
3. Per Dropdown dem passenden Vertrag zuordnen (optional)
4. "Bestätigen & übernehmen" — landet in der Ausgabenübersicht, und falls ein
   Vertrag zugeordnet wurde, wird dessen Betrag direkt aktualisiert

**Bleibt garantiert lokal:** Die Texterkennung läuft komplett auf dem Mac Mini
(macOS Vision Framework oder Tesseract), es gibt keinen Cloud-Aufruf im
gesamten Beleg-Pfad. Schlägt beide Erkennungswege fehl (z.B. weil
`pyobjc-framework-Vision` noch nicht installiert ist), wird der Beleg trotzdem
gespeichert — du trägst Betrag/Anbieter dann einfach manuell im Formular ein,
nichts geht verloren.

## Sitzungsverhalten (Login)

Bewusst strikt eingestellt:
- **Server-Neustart** → alle angemeldeten Sitzungen werden ungültig, jeder muss sich neu anmelden (Passwort + Passkey). Der Signier-Schlüssel für Sitzungen wird bei jedem Start neu zufällig erzeugt und nirgendwo gespeichert.
- **Browser/App schließen** → ebenfalls ausgeloggt. Es gibt kein "eingeloggt bleiben" über einen Neustart der App hinaus — das Cookie ist ein reines Sitzungs-Cookie ohne Ablaufdatum, das der Browser beim Schließen selbst verwirft.

Innerhalb einer laufenden Browser-Sitzung (Tab offen, Server läuft durch) bleibt man angemeldet, ohne bei jedem Klick erneut Passwort/Passkey eingeben zu müssen.

## Setup auf dem Mac Mini

```bash
# 1. Projekt aufs Mac Mini kopieren, dann:
cd familyfinance/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 2. Für lokale OCR (macOS Vision Framework) zusätzlich:
pip install pyobjc-framework-Vision pyobjc-framework-Quartz pyobjc-framework-Cocoa

# 3. Bestehende Excel-Daten einmalig importieren:
python3 import_ods.py /pfad/zu/deiner/Ausgabenuebersicht.ods

# 4. Server starten (Test):
uvicorn app:app --host 0.0.0.0 --port 8420
# -> Browser: http://localhost:8420  (am Mac)
# -> iPhone im selben WLAN: http://<Mac-Mini-IP>:8420
```

### Dauerhaft laufen lassen (launchd)

```bash
cp scripts/com.familyfinance.server.plist ~/Library/LaunchAgents/
# Pfad /Users/DEIN_BENUTZERNAME/... in der Datei anpassen, dann:
launchctl load ~/Library/LaunchAgents/com.familyfinance.server.plist
```

### Tägliche Erinnerungen (Kündigungsfristen, Vertragsenden)

```bash
cp scripts/com.familyfinance.reminders.plist ~/Library/LaunchAgents/
# SMTP-Zugangsdaten (App-Passwort deines Mail-Anbieters) und Pfad eintragen:
launchctl load ~/Library/LaunchAgents/com.familyfinance.reminders.plist
```

Diese Erinnerungen brauchen einen normalen SMTP-Mail-Versand (dein E-Mail-Konto) —
das ist reiner Transport, keine KI-Verarbeitung deiner Daten durch Dritte.

### Von unterwegs aufs iPhone zugreifen & Zum Home-Bildschirm hinzufügen

Die vollständige Anleitung dafür steht weiter oben unter "Schöne Adresse +
Zugriff vom iPhone (auch unterwegs)". Kurzfassung fürs Hinzufügen zum
Home-Bildschirm, sobald Tailscale eingerichtet ist:

- **iPhone:** Safari → Seite öffnen → Teilen-Symbol → "Zum Home-Bildschirm"
- **Mac:** Safari → Ablage → "Zum Dock hinzufügen" (oder Chrome: App installieren)

### Lokaler Chatbot (Phase 4 — Grundgerüst steht, Modell musst du installieren)

```bash
brew install ollama
ollama serve &
ollama pull llama3.1:8b
```

**Dauerhaft im Hintergrund (Autostart nach Neustart):** Da Ollama über Homebrew
installiert ist, übernimmt Homebrew den Autostart automatisch — kein eigenes
`launchd`-Skript nötig:
```bash
brew services start ollama
brew services list | grep ollama   # sollte "started" zeigen
```

Danach beantwortet der Chat-Reiter in der App Fragen wie "Wann läuft die
Gasversicherung aus?" oder "Wie viel geben wir für Abos aus?" — komplett
offline, basierend auf euren tatsächlichen Daten. Genau das, was deine Frau im
Ernstfall braucht: keine Cloud, kein Login, einfach fragen.

## Roadmap — was als Nächstes drankommt

1. **Nachpflege-Oberfläche** in der PWA, um Vertragsnummern/Laufzeitenden/
   Kündigungsfristen bequem einzutragen (aktuell nur per API möglich)
2. **OCR-Feintuning**: Beleg-Erkennung an eure tatsächlichen Rechnungsformate
   (Octopus, Naturwerke, etc.) anpassen — je mehr Beispielbelege, desto besser
   die Zuordnung
3. **Konten-Verteilung**: eigene Ansicht, wie viel auf welchem Konto liegt/
   abgebucht wird (Datenmodell ist schon vorbereitet, `accounts`-Tabelle)
4. **Backup**: `data/finance.db` regelmäßig sichern (z.B. Time Machine deckt
   das automatisch ab, da alles lokal auf dem Mac Mini liegt)

## Projektstruktur

```
familyfinance/
├── backend/
│   ├── app.py           # FastAPI-Server, alle API-Endpunkte
│   ├── database.py      # SQLite-Verbindung
│   ├── schema.sql       # Datenbankschema
│   ├── import_ods.py    # Einmal-Import deiner bestehenden Excel-Datei
│   ├── import_energy_monitor.py  # Einmal-Import der historischen Zählerstände
│   ├── meters.py         # Energy-Monitor-Berechnungslogik (Verbrauch, Abrechnung)
│   ├── ocr.py            # Lokale Texterkennung (Vision/Tesseract)
│   ├── auth.py           # Passwort + Passkey (2FA) Zugriffsschutz
│   ├── chatbot.py        # Lokaler Chatbot über Ollama
│   ├── reminders.py      # Täglicher Erinnerungs-Check + E-Mail
│   └── requirements.txt
├── frontend/             # PWA (Sidebar: Finanzen + Energy Monitor)
├── data/
│   ├── finance.db        # SQLite-Datenbank (entsteht beim ersten Start)
│   └── receipts/         # Automatisch abgelegte Belegfotos
└── scripts/               # launchd-Konfiguration für Autostart
```
