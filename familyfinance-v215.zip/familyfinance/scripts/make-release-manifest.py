#!/usr/bin/env python3
"""
Erstellt aus den fertigen ZIP-Dateien (Mac + Windows) die passende
latest.json für das öffentliche Releases-Repo.

Nutzung:
    python3 make-release-manifest.py v205 \
        --mac /pfad/zu/familyfinance.zip \
        --windows /pfad/zu/familyfinance-windows.zip \
        --notes "Kurze Beschreibung"

Mindestens eine der beiden Plattformen muss angegeben werden. Gibt den
fertigen Inhalt aus UND schreibt ihn direkt in latest.json im aktuellen
Ordner -- die dann zusammen mit beiden ZIPs auf das öffentliche
familyfinance-releases-Repo hochgeladen wird.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

# WICHTIG: An deinen tatsächlichen GitHub-Nutzernamen und Repo-Namen
# anpassen, falls du etwas anderes als "familyfinance-releases" gewählt
# hast.
REPO = "Dane03/familyfinance-releases"
BRANCH = "main"


def sha256_of(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("version", help="z.B. v205")
    parser.add_argument("--mac", type=Path, help="Pfad zu familyfinance.zip (Mac)")
    parser.add_argument("--windows", type=Path, help="Pfad zu familyfinance-windows.zip")
    parser.add_argument("--notes", default="", help="Kurze Beschreibung, in der App sichtbar")
    args = parser.parse_args()

    if not args.mac and not args.windows:
        print("Mindestens --mac oder --windows angeben.")
        sys.exit(1)
    if not args.version.startswith("v"):
        print("Versionsnummer sollte mit 'v' beginnen, z.B. v205")
        sys.exit(1)

    platforms = {}
    for key, path, asset_name in [("mac", args.mac, f"familyfinance-{args.version}.zip"),
                                    ("windows", args.windows, f"familyfinance-windows-{args.version}.zip")]:
        if not path:
            continue
        if not path.exists():
            print(f"Datei nicht gefunden: {path}")
            sys.exit(1)
        print(f"Berechne Prüfsumme von {path.name} ({key}) ...")
        platforms[key] = {
            "download_url": f"https://raw.githubusercontent.com/{REPO}/{BRANCH}/{asset_name}",
            "sha256": sha256_of(path),
            "upload_as": asset_name,
        }

    manifest = {"version": args.version, "notes": args.notes, "platforms": platforms}
    manifest_path = Path("latest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    # Kopien mit dem versionierten Dateinamen anlegen, damit man die
    # richtigen Dateien direkt zum Hochladen parat hat -- wichtig, damit
    # jede Version ihre eigene, dauerhaft erreichbare Adresse hat (sonst
    # könnte GitHubs Zwischenspeicher kurzzeitig eine alte Version ausliefern).
    renamed = []
    for key, path in [("mac", args.mac), ("windows", args.windows)]:
        if not path:
            continue
        upload_as = platforms[key]["upload_as"]
        renamed_path = path.parent / upload_as
        renamed_path.write_bytes(path.read_bytes())
        renamed.append(renamed_path)

    print()
    print("=== Fertig ===")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))
    print()
    print(f"latest.json wurde geschrieben nach: {manifest_path.resolve()}")
    print()
    print("Passende, umbenannte Dateien zum Hochladen:")
    for p in renamed:
        print(f"  {p.resolve()}")
    print()
    print(f"Nächster Schritt -- im Browser auf github.com/{REPO}:")
    print("1. 'Add file' -> 'Upload files'")
    print("2. Die oben genannten umbenannten ZIP-Dateien UND latest.json hochziehen")
    print("3. Commit direkt in den 'main'-Branch")
    print()
    print("(Alte Versions-ZIPs im Repo können bei Bedarf gelöscht werden, müssen aber nicht --")
    print(" latest.json zeigt ohnehin immer nur auf die neueste.)")


if __name__ == "__main__":
    main()
