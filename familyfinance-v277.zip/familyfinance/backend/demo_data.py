"""
Erzeugt einen komplett erfundenen, aber strukturell realistischen Demo-
Datensatz ("Familie Mustermann") in einer eigenen SQLite-Datei
(database.DEMO_DB_PATH). Wird über PUT /api/demo-mode (erstes Aktivieren)
bzw. POST /api/demo-mode/regenerate aufgerufen.

WICHTIG: Diese Datei hat KEINE Verbindung zu echten Nutzerdaten -- nichts
hier wird aus der echten Datenbank abgeleitet, alles ist frei erfunden. Das
ist bewusst so gewählt (siehe Projektnotizen): zuverlässiger als jeder
Versuch, echte Werte zu verfremden, weil dadurch nie ein echter Wert
durchrutschen kann.

Reale Belege/Dokumente (Fotos, PDFs) kann ein synthetischer Datensatz nicht
nachbilden -- der Demo-Datensatz hat deshalb bewusst keine angehängten
Dateien, nur die Datenstruktur drumherum.
"""
import json
from datetime import date, timedelta

import database


def _month_key(d: date) -> str:
    return f"{d.year}-{d.month:02d}"


def _months_back(n: int, from_date: date = None) -> list:
    """Liste von n Monatsersten, endend beim aktuellen Monat, älteste zuerst."""
    from_date = from_date or date.today()
    months = []
    y, m = from_date.year, from_date.month
    for _ in range(n):
        months.append(date(y, m, 1))
        m -= 1
        if m == 0:
            m, y = 12, y - 1
    return list(reversed(months))


def _last_day(d: date) -> date:
    ny, nm = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
    return date(ny, nm, 1) - timedelta(days=1)


def generate_demo_db():
    if database.DEMO_DB_PATH.exists():
        database.DEMO_DB_PATH.unlink()

    token = database.set_demo_context(True)
    try:
        database.init_db()
        conn = database.get_connection()
        try:
            _fill(conn)
        finally:
            conn.close()
    finally:
        database.reset_demo_context(token)


def _fill(conn):
    today = date.today()

    # ---------- Personen ----------
    conn.execute("INSERT INTO family_members (name, role, birth_date, steuerklasse) VALUES "
                 "('Max Mustermann', 'elternteil', '1984-03-12', 'IV')")
    conn.execute("INSERT INTO family_members (name, role, birth_date, steuerklasse) VALUES "
                 "('Erika Mustermann', 'elternteil', '1986-07-22', 'IV')")
    conn.execute("INSERT INTO family_members (name, role, birth_date) VALUES ('Ben Mustermann', 'kind', '2015-05-02')")
    conn.execute("INSERT INTO family_members (name, role, birth_date) VALUES ('Mia Mustermann', 'kind', '2018-09-14')")
    conn.commit()
    persons = {r["name"]: r["id"] for r in conn.execute("SELECT id, name FROM family_members")}

    # ---------- Kategorien & Versicherungsarten ----------
    for i, name in enumerate(["Haus", "Versicherungen", "Abos", "Internet", "Mobilfunk",
                               "Auto", "Kids", "Mitgliedsbeiträge", "Altersvorsorge", "Sonstiges"]):
        conn.execute("INSERT INTO categories (name, sort_order) VALUES (?, ?)", (name, i))
    for i, name in enumerate(["Haftpflicht", "Hausrat", "Risikolebensversicherung",
                               "Berufsunfähigkeit", "Rechtsschutz", "KFZ"]):
        conn.execute("INSERT INTO insurance_types (name, sort_order) VALUES (?, ?)", (name, i))
    conn.commit()
    cats = {r["name"]: r["id"] for r in conn.execute("SELECT id, name FROM categories")}

    # ---------- Konten ----------
    conn.execute("INSERT INTO accounts (name, owner, iban) VALUES "
                 "('Gemeinschaftskonto Musterbank', 'Gemeinsam', 'DE00 1000 0000 0012 3400 00')")
    conn.execute("INSERT INTO accounts (name, owner, iban) VALUES "
                 "('Tagesgeld Musterbank', 'Gemeinsam', 'DE00 1000 0000 0056 7800 00')")
    conn.commit()
    acc_id = conn.execute("SELECT id FROM accounts LIMIT 1").fetchone()["id"]

    # ---------- Verträge ----------
    contracts = [
        ("Baufinanzierung Eigenheim", "Musterbank", cats["Haus"], "Finanzierung", 1200.0, "monthly",
         dict(interest_rate=3.2, remaining_debt=185000.0, repayment_rate=2.0, fixed_interest_until="2031-06-30")),
        ("Hausratversicherung", "Sicher Hausrat AG", cats["Versicherungen"], None, 11.90, "monthly",
         dict(insurance_type="Hausrat")),
        ("Haftpflichtversicherung Familie", "Blitz Versicherung AG", cats["Versicherungen"], None, 7.50, "monthly",
         dict(insurance_type="Haftpflicht")),
        ("Risikolebensversicherung Max", "Vorsorge Leben AG", cats["Versicherungen"], None, 18.20, "monthly",
         dict(person_id=persons["Max Mustermann"], insurance_type="Risikolebensversicherung",
              insurance_sum=250000.0, insurance_sum_type="fallend", insurance_expiry="2046-03-12")),
        ("StreamFlix", "StreamFlix GmbH", cats["Abos"], None, 12.99, "monthly", {}),
        ("MusikPlus", "MusikPlus Ltd.", cats["Abos"], None, 9.99, "monthly", {}),
        ("Internet & Festnetz", "NetzWerk Internet GmbH", cats["Internet"], None, 44.90, "monthly", {}),
        ("Mobilfunk Max", "MegaMobil", cats["Mobilfunk"], None, 19.99, "monthly", dict(person_id=persons["Max Mustermann"])),
        ("Mobilfunk Erika", "MegaMobil", cats["Mobilfunk"], None, 19.99, "monthly", dict(person_id=persons["Erika Mustermann"])),
        ("KFZ-Versicherung", "MusterAuto Versicherung", cats["Auto"], None, 42.30, "monthly", {}),
        ("Schwimmverein", "SV Musterstadt e.V.", cats["Kids"], None, 15.00, "monthly", dict(person_id=persons["Ben Mustermann"])),
        ("Musikschule Blockflöte", "Musikschule Musterstadt", cats["Kids"], None, 22.00, "monthly", dict(person_id=persons["Mia Mustermann"])),
        ("Riester-Rente Max", "Riester Musterbank", cats["Altersvorsorge"], None, 40.00, "monthly", dict(person_id=persons["Max Mustermann"])),
    ]
    for label, provider, cat_id, subcat, amount, freq, extra in contracts:
        cols = ["label", "provider", "category_id", "subcategory", "account_id", "amount", "frequency",
                "contract_start", "source"] + list(extra.keys())
        vals = [label, provider, cat_id, subcat, acc_id, amount, freq,
                (today - timedelta(days=400)).isoformat(), "manuell"] + list(extra.values())
        placeholders = ",".join("?" * len(vals))
        conn.execute(f"INSERT INTO contracts ({','.join(cols)}) VALUES ({placeholders})", vals)
    conn.commit()

    # ---------- Einkommen ----------
    conn.execute("INSERT INTO income (label, category, amount, frequency, account_id) VALUES "
                 "('Gehalt Max', 'Gehalt', 4200.0, 'monthly', ?)", (acc_id,))
    conn.execute("INSERT INTO income (label, category, amount, frequency, account_id) VALUES "
                 "('Gehalt Erika', 'Gehalt', 2850.0, 'monthly', ?)", (acc_id,))
    conn.execute("INSERT INTO income (label, category, amount, frequency, account_id) VALUES "
                 "('Kindergeld', 'Kindergeld', 500.0, 'monthly', ?)", (acc_id,))
    conn.commit()

    # ---------- Vermögen ----------
    conn.execute("INSERT INTO assets (type, label, provider, current_value, account_type) VALUES "
                 "('konto', 'Gemeinschaftskonto', 'Musterbank', 4200.0, 'giro')")
    conn.execute("INSERT INTO assets (type, label, provider, current_value, account_type) VALUES "
                 "('konto', 'Tagesgeld Rücklage', 'Musterbank', 18500.0, 'tagesgeld')")
    conn.execute("INSERT INTO assets (type, label, provider, current_value, purpose) VALUES "
                 "('depot', 'Wertpapierdepot', 'Muster Direkt Bank', NULL, 'Vermögensaufbau')")
    depot_id = conn.execute("SELECT id FROM assets WHERE label='Wertpapierdepot'").fetchone()["id"]
    for isin, name, value, klass, region in [
        ("IE00B4L5Y983", "Muster World ETF", 32000.0, "aktie", "global"),
        ("IE00B3RBWM25", "Muster Schwellenländer ETF", 8500.0, "aktie", "schwellenlaender"),
        ("LU0290358497", "Muster Anleihen ETF", 6200.0, "anleihe", "europa"),
    ]:
        conn.execute("INSERT INTO asset_holdings (asset_id, isin, name, current_value, asset_class, region) "
                     "VALUES (?,?,?,?,?,?)", (depot_id, isin, name, value, klass, region))
    conn.execute("INSERT INTO assets (type, label, current_value, note) VALUES "
                 "('immobilie', 'Eigenheim Musterstadt', 480000.0, 'Marktwertschätzung')")
    conn.commit()

    for cls, pct in [("aktie", 65), ("anleihe", 15), ("cash", 15), ("rohstoffe", 5)]:
        conn.execute("INSERT INTO allocation_targets (asset_class, target_percent) VALUES (?, ?)", (cls, pct))
    conn.commit()

    # Vermögens-Verlauf: 12 Monate stetiges Wachstum
    networth_start = 165000.0
    for i, m in enumerate(_months_back(12, today)):
        d = min(_last_day(m), today)
        conn.execute("INSERT OR REPLACE INTO networth_snapshots (snapshot_date, total_networth, liquid, pension_capital, immobilien_netto) "
                     "VALUES (?,?,?,?,?)",
                     (d.isoformat(), round(networth_start + i * 1400 + (i % 3) * 300, 2),
                      round(20000 + i * 250, 2), round(9000 + i * 180, 2), round(480000 - 185000 + i * 600, 2)))
    conn.commit()

    # ---------- Vorsorge ----------
    conn.execute("INSERT INTO pension_accounts (person_id, type, label, provider, projected_monthly_at_67) "
                 "VALUES (?, 'gesetzlich', 'Deutsche Rentenversicherung', 'DRV', 1450.0)", (persons["Max Mustermann"],))
    conn.execute("INSERT INTO pension_accounts (person_id, type, label, provider, projected_monthly_at_67) "
                 "VALUES (?, 'gesetzlich', 'Deutsche Rentenversicherung', 'DRV', 1180.0)", (persons["Erika Mustermann"],))
    riester_contract_id = conn.execute("SELECT id FROM contracts WHERE label='Riester-Rente Max'").fetchone()["id"]
    conn.execute("INSERT INTO pension_accounts (person_id, type, label, provider, current_value, is_riester, "
                 "linked_contract_id, return_rate_assumption) VALUES (?, 'privat', 'Riester-Rente', 'Riester Musterbank', "
                 "9800.0, 1, ?, 3.0)", (persons["Max Mustermann"], riester_contract_id))
    conn.commit()

    # ---------- Energie: Tarife + Module aktivieren ----------
    conn.execute("INSERT INTO settings (key, value) VALUES ('energy_monitor_enabled', 'true')")
    conn.execute("INSERT INTO settings (key, value) VALUES ('vorsorge_enabled', 'true')")
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?)", ("meter_settings_gas", json.dumps(
        {"abschlag": 145.0, "arbeitspreis": 0.11, "grundpreis": 13.5, "brennwert": 10.4, "anbieter": "Muster Energie"})))
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?)", ("meter_settings_water", json.dumps(
        {"abschlag": 35.0, "arbeitspreis": 2.35, "grundpreis": 6.0, "entwaesserung_preis": 2.10, "anbieter": "Stadtwerke Musterstadt"})))
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?)", ("meter_settings_elec_in", json.dumps(
        {"abschlag": 165.0, "arbeitspreis": 0.32, "grundpreis": 12.0, "anbieter": "Muster Energie"})))
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?)", ("meter_settings_elec_out", json.dumps(
        {"abschlag": 0.0, "einspeisepreis": 0.082, "anbieter": "Netzbetreiber Musterstadt"})))
    conn.commit()

    # ---------- Zählerstände: 13 Monate (12 echte Deltas), realistischer
    # Jahresverlauf (Gas/Heizung im Winter hoch, PV im Sommer hoch) ----------
    gas_profile_m3 = [220, 200, 160, 100, 55, 25, 20, 22, 50, 110, 170, 210]   # Jan..Dez
    water_profile_m3 = [9, 8, 9, 9, 10, 11, 12, 12, 10, 9, 9, 9]
    pv_profile_kwh = [280, 420, 780, 1150, 1450, 1550, 1580, 1400, 1000, 620, 320, 220]
    consumption_profile_kwh = [520, 480, 460, 420, 380, 400, 430, 410, 400, 440, 480, 520]  # Haushalt

    months = _months_back(13, today)  # ältester zuerst, letzter = aktueller Monat (teilweise)
    gas_total = water_total = elecin_total = elecout_total = 500.0
    ev_total = 0.0
    for idx, m in enumerate(months):
        d = min(_last_day(m), today)
        month_idx = (m.month - 1)
        gas_total += gas_profile_m3[month_idx]
        water_total += water_profile_m3[month_idx]
        pv = pv_profile_kwh[month_idx]
        cons = consumption_profile_kwh[month_idx]
        # Eigenverbrauch = min(PV, Verbrauch), Rest wird bezogen/eingespeist
        eigen = min(pv, cons)
        elecin_total += max(0.0, cons - eigen)
        elecout_total += max(0.0, pv - eigen)
        conn.execute("INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note) "
                     "VALUES ('gas', ?, ?, ?, 'Demo-Daten')", (d.isoformat(), round(gas_total, 1), 1 if idx == 0 else 0))
        conn.execute("INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note) "
                     "VALUES ('water', ?, ?, ?, 'Demo-Daten')", (d.isoformat(), round(water_total, 1), 1 if idx == 0 else 0))
        conn.execute("INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note) "
                     "VALUES ('elec_in', ?, ?, ?, 'Demo-Daten')", (d.isoformat(), round(elecin_total, 1), 1 if idx == 0 else 0))
        conn.execute("INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note) "
                     "VALUES ('elec_out', ?, ?, ?, 'Demo-Daten')", (d.isoformat(), round(elecout_total, 1), 1 if idx == 0 else 0))
        # PV-Monatswerte (Produktion & Einspeisung je Monat)
        if idx > 0:
            key = _month_key(months[idx - 1] if d == today else m)
            conn.execute("INSERT OR REPLACE INTO pv_monthly (key, pv, bezug, einsp, gesamt) VALUES (?,?,?,?,?)",
                         (_month_key(m), pv, max(0.0, cons - eigen), max(0.0, pv - eigen), cons))
        # Wallbox: erst in den letzten 4 Monaten "installiert" (realistisches Beispiel für die Auto/Haus-Aufteilung)
        if idx >= len(months) - 4:
            ev_total += 60.0 if idx < len(months) - 1 else 25.0
            conn.execute("INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note) "
                         "VALUES ('ev_charging', ?, ?, ?, 'Demo-Daten')",
                         (d.isoformat(), round(ev_total, 1), 1 if idx == len(months) - 4 else 0))
    conn.commit()

    conn.execute("INSERT INTO pv_system_specs (installed_year, kwp, battery_kwh, valid_from, note) "
                 "VALUES (?, 9.8, 10.0, ?, 'Demo-Anlage')", (today.year - 2, date(today.year - 2, 4, 1).isoformat()))
    conn.commit()
