"""
Bankanbindung per FinTS (BBBank, ING, ...) über die Bibliothek easy-fints
(MIT, Aufsatz auf "fints" von Raphael Michel), exakt versioniert in
requirements.txt.

SICHERHEIT -- vor dem Einbau geprüft (siehe Projektnotizen):
- easy-fints baut keine Verbindungen zu Zielen außer der Bank auf und
  protokolliert die PIN nicht.
- ABER: Die Bibliothek schreibt bei jedem Schritt JSONL-Protokolle in einen
  Ordner "logs/" im AKTUELLEN Arbeitsverzeichnis -- bei uns der backend-Ordner
  im iCloud-synchronisierten Projektverzeichnis. Zusätzlich gibt es ein
  unmaskiertes Debug-Protokoll (Gegenkonto, IBAN, Verwendungszweck), das über
  die Umgebungsvariable FINTS_DEBUG_LEVEL einschaltbar ist. Beides wird hier
  beim Import hart abgeschaltet: Debug-Stufe erzwungen "off", beide
  Schreibfunktionen in allen easy_fints-Modulen durch No-ops ersetzt.

ABLAUF ÜBER MEHRERE HTTP-ANFRAGEN: Verlangt die Bank eine Freigabe (TAN bzw.
Bestätigung in der Banking-App = "decoupled"), bleibt die Bankverbindung im
Speicher dieses (dauerhaft laufenden) Server-Prozesses offen, bis der Nutzer
bestätigt hat oder die Sitzung nach SESSION_TTL_SECONDS verfällt.
"""
import dataclasses
import hashlib
import importlib
import os
import pkgutil
import re
import secrets
import threading
import time
from typing import Optional

os.environ["FINTS_DEBUG_LEVEL"] = "off"   # unmaskiertes Debug-Protokoll nie zulassen
os.environ["FINTS_DEBUG_FAIL_ONLY"] = "1"

SESSION_TTL_SECONDS = 6 * 60

# Bekannte Banken als Vorgabe (vor dem Eintragen recherchiert, siehe Notizen):
# BBBank (Karlsruhe) ist eine ehemalige Fiducia-Bank -> fints2, NICHT fints1.
KNOWN_BANKS = {
    "bbbank": {"label": "BBBank", "blz": "66090800",
               "server": "https://fints2.atruvia.de/cgi-bin/hbciservlet",
               "user_hint": "VR-NetKey oder Alias",
               "tan_hint": "Freigabe in der App VR SecureGo plus"},
    "ing": {"label": "ING", "blz": "50010517",
            "server": "https://fints.ing.de/fints",
            "user_hint": "Zugangsnummer (10-stellig)",
            "tan_hint": "Freigabe in der ING-App; FinTS ist bei ING nur lesend und setzt eine Anmeldung im Online-Banking innerhalb der letzten 90 Tage voraus"},
}

# Achtung: KEIN product_name an easy-fints geben -- set_product() wuerde sonst die
# Registrierungsnummer (product_id) im Anmeldesegment ueberschreiben (Bank: 9078).
PRODUCT_NAME = "FamilyFinance"
PRODUCT_VERSION = "1.0"


class BankError(Exception):
    """Vorübergehender Fehler (Netz, Bank nicht erreichbar) -- darf später erneut versucht werden."""


class BankLoginError(BankError):
    """PIN/Kennung abgelehnt oder Zugang gesperrt -- NIE automatisch wiederholen."""


class BankConfigError(BankError):
    """Fehlende Angaben (z.B. Produkt-Registrierungsnummer)."""


# ---------- Protokollierung der Bibliothek abschalten ----------

def _noop_log(*_args, **_kwargs):
    return None


_LOG_FUNCS = ("append_operation_step_log", "append_debug_step_log")
_library_neutralized = False


def _neutralize_library_logging():
    """Ersetzt die Datei-Protokollfunktionen in ALLEN easy_fints-Modulen. Die
    Module importieren die Funktionen per 'from .helpers import ...', daher
    reicht es nicht, nur helpers zu patchen -- jede Kopie muss ersetzt werden."""
    global _library_neutralized
    import easy_fints
    for info in pkgutil.walk_packages(easy_fints.__path__, prefix="easy_fints."):
        if info.name.endswith(".api") or info.name.endswith(".cli"):
            continue  # REST-Server/CLI der Bibliothek nutzen wir nicht
        try:
            importlib.import_module(info.name)
        except Exception:
            pass
    import sys
    for name, mod in list(sys.modules.items()):
        if name == "easy_fints" or name.startswith("easy_fints."):
            for fn in _LOG_FUNCS:
                if hasattr(mod, fn):
                    setattr(mod, fn, _noop_log)
    _library_neutralized = True


def library_installed() -> bool:
    import importlib.util
    return importlib.util.find_spec("easy_fints") is not None


# ---------- Rückmeldungen der Bank mitschreiben (nur im Speicher) ----------
# Beim ersten Verbindungsaufbau (Bootstrap) wirft python-fints bei Bank-
# Fehlercodes bewusst KEINEN Fehler -- die Rückmeldung (z.B. "Kennung
# unbekannt", "Produkt nicht registriert") geht verloren, sichtbar wird nur
# die Folge-Meldung "Could not find system_id". Alle Rückmeldungen laufen aber
# durch _process_response; dort wird je Abruf mitgeschrieben (thread-lokal,
# nie in eine Datei) und im Fehlerfall an die Meldung angehängt.
_bank_msgs = threading.local()
_capture_installed = False


def _install_response_capture():
    global _capture_installed
    if _capture_installed:
        return
    import fints.client as fc
    for cls in (fc.FinTS3Client, fc.FinTS3PinTanClient):
        if "_process_response" not in cls.__dict__:
            continue
        orig = cls.__dict__["_process_response"]

        def capture(self, dialog, segment, response, _orig=orig):
            items = getattr(_bank_msgs, "items", None)
            if items is not None:
                entry = (str(getattr(response, "code", "")), str(getattr(response, "text", "")))
                if not items or items[-1] != entry:
                    items.append(entry)
            return _orig(self, dialog, segment, response)
        setattr(cls, "_process_response", capture)
    _capture_installed = True


def _start_capture():
    _bank_msgs.items = []


def _bank_messages_text() -> str:
    """Warnungen (3xxx) und Fehler (9xxx) der Bank, ohne Erfolgsmeldungen."""
    items = getattr(_bank_msgs, "items", None) or []
    relevant = [f"{c} {t}".strip() for c, t in items if c[:1] in ("3", "9")]
    return " | ".join(dict.fromkeys(relevant))


_last_product_diag = ""


def _with_bank_messages(exc: Exception) -> Exception:
    msgs = _bank_messages_text()
    if not msgs:
        return exc
    if "9078" in msgs and _last_product_diag:
        msgs = f"{msgs} | Diagnose: {_last_product_diag}"
    try:
        new = type(exc)(f"{exc} — Bank meldet: {msgs}")
    except Exception:
        new = Exception(f"{exc} — Bank meldet: {msgs}")
    new.__cause__ = exc.__cause__ or exc.__context__
    return new


def _lib():
    if not library_installed():
        raise BankConfigError("Die Bank-Bibliothek (easy-fints) ist nicht installiert — "
                              "unter Integrationen „Bank-Bibliothek jetzt installieren“ wählen.")
    if not _library_neutralized:
        _neutralize_library_logging()
    _install_response_capture()
    from easy_fints.library import FinTS
    from easy_fints.exceptions import TanRequiredError
    return FinTS, TanRequiredError


# ---------- Hilfsfunktionen ----------

def _to_dict(obj) -> dict:
    if obj is None:
        return {}
    if dataclasses.is_dataclass(obj):
        return dataclasses.asdict(obj)
    if isinstance(obj, dict):
        return dict(obj)
    return {k: v for k, v in vars(obj).items() if not k.startswith("_")}


_NUM_RE = re.compile(r"[-−+]?\d[\d.,]*")


def parse_amount(value) -> Optional[float]:
    """Beträge kommen als Text, je nach Bank '1234.56', '1.234,56', '-12,30 EUR'."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace("−", "-")
    m = _NUM_RE.search(text)
    if not m:
        return None
    num = m.group(0)
    if "," in num and "." in num:
        num = num.replace(".", "").replace(",", ".") if num.rfind(",") > num.rfind(".") else num.replace(",", "")
    elif "," in num:
        num = num.replace(",", ".")
    try:
        return float(num)
    except ValueError:
        return None


# FinTS-Rückmeldecodes, die auf falsche Zugangsdaten bzw. Sperre hindeuten.
_LOGIN_ERROR_CODES = ("9931", "9942", "9340", "9930", "3938", "9910")
_LOGIN_ERROR_WORDS = ("pin falsch", "pin ungültig", "falsche pin", "gesperrt",
                      "invalid pin", "wrong pin", "pin incorrect")


def _exception_chain(exc: Exception) -> list:
    chain, cur, seen = [], exc, set()
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        chain.append(cur)
        cur = cur.__cause__ or cur.__context__
    return chain


def classify_error(exc: Exception) -> BankError:
    """Unterscheidet Anmeldefehler (-> automatische Versuche pausieren) von
    reinen Netzwerkfehlern (-> später erneut versuchen).

    VORSICHT, im Test gefunden: Bei einem bloßen Netzwerkfehler meldet fints
    "Couldn't establish dialog with bank, Authentication data wrong?" -- dieser
    Text allein taugt also nicht zur Unterscheidung. Maßgeblich ist die
    Ausnahme-Kette: Ein echter Verbindungsfehler steckt darin als
    requests.ConnectionError/Timeout bzw. OSError.

    Im Zweifel wird als ANMELDEFEHLER gewertet: Ein fälschlich pausierter
    Abruf kostet den Nutzer einen Klick, ein fälschlich wiederholter
    PIN-Versuch im schlimmsten Fall den gesperrten Bankzugang."""
    import fints.exceptions as fe
    import requests
    chain = _exception_chain(exc)
    text = str(exc)
    low = text.lower()
    if any(isinstance(c, (fe.FinTSClientPINError, fe.FinTSClientTemporaryAuthError)) for c in chain):
        return BankLoginError(text or "Anmeldung von der Bank abgelehnt.")
    if any(code in text for code in _LOGIN_ERROR_CODES) or any(w in low for w in _LOGIN_ERROR_WORDS):
        return BankLoginError(text or "Anmeldung von der Bank abgelehnt.")
    network = (requests.exceptions.ConnectionError, requests.exceptions.Timeout,
               fe.FinTSConnectionError, fe.FinTSNoResponseError, ConnectionError, TimeoutError)
    if any(isinstance(c, network) for c in chain):
        return BankError("Bank nicht erreichbar: " + (str(chain[-1]) or text))
    if any(isinstance(c, fe.FinTSDialogInitError) for c in chain):
        return BankLoginError("Die Bank hat den Verbindungsaufbau abgelehnt (Zugangsdaten prüfen): " + text)
    return BankError(text or type(exc).__name__)


def challenge_to_dict(ch) -> dict:
    d = _to_dict(ch)
    return {
        "message": d.get("message"),
        "decoupled": bool(d.get("decoupled")),
        "image_mime_type": d.get("image_mime_type"),
        "image_base64": d.get("image_base64"),
    }


def tx_hashes(transactions: list, account_ref: str) -> list:
    """Stabile Kennung je Umsatz. Zwei identische Umsätze am selben Tag (z.B.
    zweimal derselbe Kaffee) unterscheiden sich nur durch ihre Reihenfolge --
    deshalb fließt ein laufender Zähler gleicher Grunddaten mit ein. Ein
    erneuter Abruf liefert dieselbe Reihenfolge und damit dieselben Kennungen."""
    seen = {}
    out = []
    for t in transactions:
        base = "|".join(str(t.get(k) or "") for k in
                        ("booking_date", "value_date", "amount", "counterparty_iban", "counterparty_name", "purpose"))
        base = f"{account_ref}|{base}"
        n = seen.get(base, 0)
        seen[base] = n + 1
        out.append(hashlib.sha256(f"{base}|{n}".encode("utf-8")).hexdigest())
    return out


# ---------- Sitzungen (offene Bankverbindung während einer Freigabe) ----------

_sessions = {}
_lock = threading.Lock()


def _cleanup_sessions():
    now = time.time()
    for token in [t for t, s in _sessions.items() if now - s["created"] > SESSION_TTL_SECONDS]:
        _close_quietly(_sessions.pop(token)["fints"])


def _close_quietly(fints):
    try:
        fints.close()
    except Exception:
        pass


def _new_session(fints, conn_key: str, days: int) -> str:
    token = secrets.token_urlsafe(24)
    with _lock:
        _cleanup_sessions()
        for t in [t for t, s in _sessions.items() if s["conn_key"] == conn_key]:
            _close_quietly(_sessions.pop(t)["fints"])   # nur eine offene Freigabe je Verbindung
        _sessions[token] = {"fints": fints, "conn_key": conn_key, "days": days, "created": time.time()}
    return token


def session_conn_key(token: str) -> Optional[str]:
    with _lock:
        _cleanup_sessions()
        s = _sessions.get(token)
    return s["conn_key"] if s else None


def cancel_session(token: str):
    with _lock:
        s = _sessions.pop(token, None)
    if s:
        _close_quietly(s["fints"])


# ---------- Abruf ----------

def _fetch(fints, days: int) -> dict:
    overview = fints.account_overview()
    grouped = fints.transactions_by_account(days=days)
    accounts = [_to_dict(a) for a in overview]
    tx_by_account = []
    for group in grouped:
        g = _to_dict(group)
        tx_by_account.append({
            "account": g.get("account") or {},
            "transactions": [t if isinstance(t, dict) else _to_dict(t) for t in (g.get("transactions") or [])],
        })
    return {"status": "ok", "accounts": accounts, "transactions_by_account": tx_by_account}


def start_sync(conn_key: str, creds: dict, product_id: str, days: int = 90,
               allow_tan: bool = True) -> dict:
    """Ein Abrufversuch. Ergebnis:
      {"status": "ok", ...Daten}
      {"status": "tan_required", "session": token, "challenge": {...}}
    allow_tan=False (Hintergrund-Abruf): verlangt die Bank eine Freigabe, wird
    sofort abgebrochen (BankError mit .needs_manual), statt eine Push-Anfrage
    aufs Handy offen stehen zu lassen."""
    if not product_id:
        raise BankConfigError("FinTS-Produkt-Registrierungsnummer fehlt (Einstellung unter Integrationen).")
    for field in ("server", "blz", "user", "pin"):
        if not creds.get(field):
            raise BankConfigError(f"Angabe fehlt: {field}")
    FinTS, TanRequiredError = _lib()
    _start_capture()
    global _last_product_diag
    _last_product_diag = (f"gesendete Produkt-ID beginnt mit {product_id[:4]}… und endet auf …{product_id[-2:]} "
                          f"({len(product_id)} Zeichen), Produktversion {PRODUCT_VERSION}, Backend v304")
    try:
        fints = FinTS(product_id=product_id, bank=creds["blz"], user=creds["user"], pin=creds["pin"],
                      server=creds["server"], product_version=PRODUCT_VERSION,
                      tan_mechanism=creds.get("tan_mechanism") or None)
    except Exception as e:
        raise classify_error(_with_bank_messages(e))
    try:
        result = _fetch(fints, days)
        _close_quietly(fints)
        return result
    except TanRequiredError as e:
        if not allow_tan:
            _close_quietly(fints)
            err = BankError("Die Bank verlangt eine Freigabe -- bitte einmal manuell synchronisieren.")
            err.needs_manual = True
            raise err
        return {"status": "tan_required", "session": _new_session(fints, conn_key, days),
                "challenge": challenge_to_dict(e.challenge)}
    except Exception as e:
        _close_quietly(fints)
        raise classify_error(_with_bank_messages(e))


def resume(token: str, tan: str = "") -> dict:
    """Nach Bestätigung in der App (tan leer) bzw. Eingabe einer TAN.
    Ergebnis wie start_sync, zusätzlich {"status": "pending"} solange die
    App-Freigabe noch aussteht."""
    _, TanRequiredError = _lib()
    with _lock:
        _cleanup_sessions()
        s = _sessions.get(token)
    if not s:
        raise BankError("Die Freigabe-Sitzung ist abgelaufen -- bitte erneut synchronisieren.")
    fints = s["fints"]
    _start_capture()
    try:
        challenge, _vop, _result = fints.confirm_pending(tan)
    except TanRequiredError as e:
        return {"status": "pending", "session": token, "challenge": challenge_to_dict(e.challenge)}
    except Exception as e:
        cancel_session(token)
        raise classify_error(_with_bank_messages(e))
    if challenge is not None:
        return {"status": "pending", "session": token, "challenge": challenge_to_dict(challenge)}
    # Freigabe erteilt -- die Leseaufträge in derselben, jetzt freigegebenen Verbindung erneut ausführen.
    try:
        result = _fetch(fints, s["days"])
    except TanRequiredError as e:
        with _lock:
            s["created"] = time.time()
        return {"status": "tan_required", "session": token, "challenge": challenge_to_dict(e.challenge)}
    except Exception as e:
        cancel_session(token)
        raise classify_error(_with_bank_messages(e))
    with _lock:
        _sessions.pop(token, None)
    _close_quietly(fints)
    return result
