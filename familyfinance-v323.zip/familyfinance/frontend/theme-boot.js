// Sofortige Anwendung des zuletzt bekannten Themes aus localStorage, NOCH VOR
// dem ersten Rendern -- verhindert ein kurzes Aufblitzen des Standard-Themes,
// bevor die eigentliche App (nach Login) das serverseitig gespeicherte Theme
// abgleicht. Als eigene Datei (statt Inline-<script>), damit die
// Content-Security-Policy Inline-Skripte komplett verbieten kann. Wird im
// <head> synchron geladen und blockiert dort wie zuvor das Rendern.
(function () {
  try {
    var t = localStorage.getItem("ui_theme") || "dark";
    document.documentElement.setAttribute("data-theme", t);
    window.__cachedUiTheme = t;
  } catch (e) {}
})();
