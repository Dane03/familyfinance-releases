const APP_BUILD = "Build 2026-10-10 · v323";

const fmt = (n) => new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(n || 0);
const freqLabel = (f) => (f === "monthly" ? "mtl." : f === "yearly" ? "jährl." : "quart.");
const sourceLabel = (s) => ({ import: "Import", manuell: "manuell geändert", foto: "per Foto aktualisiert", lohnabrechnung: "aus Gehaltsabrechnung" }[s] || s);
const reminderIcon = (t) => (t === "contract_end" ? "📅" : t === "notice_period" ? "🔔" : "⏰");

document.getElementById("build-version").textContent = APP_BUILD;

// ---------- Sidebar-Navigation ----------
const TAB_LOADERS = {
  "tab-vorsorge-dashboard": () => loadVorsorgeDashboard(),
  "tab-vorsorge-aufbau": () => loadAufbauTab(),
  "tab-vorsorge-absicherung": () => loadAbsicherungTab(),
  "tab-vermoegen": () => loadVermoegenOverview(),
  "tab-energy-dashboard": () => loadEnergyOverview(),
  "tab-energy-gas": () => loadMeterPage("gas", "meter-page-gas", "🔥 Gas"),
  "tab-energy-water": () => loadMeterPage("water", "meter-page-water", "💧 Wasser"),
  "tab-energy-verbrauch": () => loadVerbrauchTab(),
  "tab-energy-produktion": () => loadProduktionTab(),
};

function loadVerbrauchTab() {
  loadMeterPage("elec_in", "meter-page-elec_in", "⚡ Strombezug");
}

function loadProduktionTab() {
  loadMeterPage("elec_out", "meter-page-elec_out", "↑ Einspeisung");
  loadPvSystemSpecs();
}

document.querySelectorAll(".sidebar-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".sidebar-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => (p.style.display = "none"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).style.display = "block";
    TAB_LOADERS[btn.dataset.tab]?.();
  });
});

// ---------- Zahlen im deutschen Format robust parsen ----------
// Naives ".replace(',', '.')" scheitert an Tausenderpunkten: "73.412" würde
// als 73.412 (also ~73) statt als 73412 gelesen. Diese Funktion erkennt:
// - Komma + Punkt zusammen -> Punkte sind Tausendertrenner, Komma ist Dezimal
// - nur Komma -> Dezimaltrennzeichen
// - mehrere Punkte -> garantiert Tausendertrenner (Dezimalzahlen haben nie 2 Punkte)
// - genau ein Punkt mit exakt 3 Nachkommastellen -> Tausendertrenner (z.B. "1.200")
// - genau ein Punkt mit 1-2 Nachkommastellen -> Dezimaltrennzeichen (z.B. "3.45")
// Formatiert einen Betrag fürs EDITIERBARE Eingabefeld (kein Währungssymbol,
// aber mit Tausendertrenner) -- ohne das zeigten Inline-Beträge über 999 den
// rohen JS-Zahlwert mit Punkt als Dezimaltrenner (z.B. "205836.02" statt
// "205.836,02"), obwohl der Rest der App durchgängig das deutsche Schema
// nutzt. parseGermanNumber() versteht dieses Format beim Zurückspeichern.
function formatAmountForInput(n) {
  const num = Number(n) || 0;
  return num.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function parseGermanNumber(str) {
  if (str === null || str === undefined) return null;
  str = String(str).trim();
  if (!str) return null;
  const hasComma = str.includes(",");
  const hasDot = str.includes(".");
  if (hasComma && hasDot) {
    str = str.replace(/\./g, "").replace(",", ".");
  } else if (hasComma) {
    str = str.replace(",", ".");
  } else if (hasDot) {
    const dotCount = (str.match(/\./g) || []).length;
    if (dotCount > 1) {
      str = str.replace(/\./g, "");
    } else {
      const afterDot = str.split(".")[1] || "";
      if (afterDot.length === 3) {
        str = str.replace(".", "");
      }
    }
  }
  const n = parseFloat(str);
  return Number.isNaN(n) ? null : n;
}

async function authedFetch(url, options = {}) {
  let res;
  try {
    res = await fetch(url, { ...options, credentials: "same-origin" });
  } catch (networkErr) {
    // Netzwerk weg / Server nicht erreichbar: ohne diese Behandlung würde der
    // Aufrufer an res.json() scheitern und die Oberfläche bliebe stumm bei
    // "Lade …" stehen, ohne dass klar wird, woran es liegt.
    showToast("Keine Verbindung zum Server. Läuft er noch?", true);
    throw networkErr;
  }
  if (res.status === 401) {
    location.reload(); // Session abgelaufen -> zurück zum Login
    throw new Error("Nicht angemeldet");
  }
  if (res.status >= 500) {
    showToast(`Serverfehler (${res.status}) — Details im Server-Log.`, true);
  }
  return res;
}

// ---------- Kurze Einblendung für Fehler/Hinweise ----------
// Bewusst kein alert(): das blockiert die ganze Oberfläche und muss
// weggeklickt werden, was bei Hintergrund-Ladefehlern nur nervt.
let toastTimer = null;
function showToast(message, isError = false) {
  let el = document.getElementById("app-toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "app-toast";
    el.className = "app-toast";
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.toggle("app-toast-error", isError);
  el.classList.add("app-toast-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("app-toast-visible"), 5000);
}

async function patchJSON(url, body) {
  return authedFetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

// ---------- Generisches Drag & Drop für Listen/Blöcke ----------
function enableDragReorder(container, itemSelector, onReorder) {
  let dragEl = null;
  container.querySelectorAll(itemSelector).forEach((item) => {
    item.setAttribute("draggable", "true");
    item.addEventListener("dragstart", () => {
      dragEl = item;
      item.classList.add("dragging");
    });
    item.addEventListener("dragend", () => {
      item.classList.remove("dragging");
      dragEl = null;
    });
    item.addEventListener("dragover", (e) => {
      e.preventDefault();
      if (!dragEl || item === dragEl) return;
      const rect = item.getBoundingClientRect();
      const putAfter = (e.clientY - rect.top) / rect.height > 0.5;
      item.parentNode.insertBefore(dragEl, putAfter ? item.nextSibling : item);
    });
    item.addEventListener("drop", (e) => {
      e.preventDefault();
      const ids = Array.from(container.querySelectorAll(itemSelector)).map((el) => el.dataset.dragId);
      onReorder(ids);
    });
  });
}

// ---------- Block-Reihenfolge per Drag & Drop, serverseitig gespeichert --
// Generalisiert aus der ursprünglich Dashboard-spezifischen Lösung, damit
// jeder Tab-Bereich (nicht nur das Dashboard) seine Kacheln in eigener
// Reihenfolge merken kann -- ein eigener settingsKey pro Bereich, damit
// sich die Sortierungen nicht gegenseitig überschreiben.
async function applyBlockOrder(tabId, settingsKey) {
  const res = await authedFetch(`/api/settings/${settingsKey}`);
  const { value } = await res.json();
  if (!value) return;
  const tab = document.getElementById(tabId);
  if (!tab) return;
  value.forEach((blockId) => {
    const el = tab.querySelector(`#block-${blockId}, [data-block-id="${blockId}"]`);
    if (el) tab.appendChild(el);
  });
}

function setupBlockDragReorder(tabId, settingsKey) {
  const tab = document.getElementById(tabId);
  if (!tab) return;
  tab.querySelectorAll(".draggable-block").forEach((el) => {
    el.dataset.dragId = el.dataset.blockId;
  });
  enableDragReorder(tab, ".draggable-block", async (ids) => {
    await authedFetch(`/api/settings/${settingsKey}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: ids }),
    });
  });
}

async function applyDashboardOrder() {
  await applyBlockOrder("tab-dashboard", "dashboard_order");
}

function setupDashboardDragReorder() {
  setupBlockDragReorder("tab-dashboard", "dashboard_order");
}

// ---------- Theme-bewusste Chart-Farben ----------
// Jedes Theme bekommt dieselben benannten Rollen (primary/accent/warn/...),
// damit alle Charts der App automatisch zum gewählten Design passen, ohne
// dass jede einzelne Chart-Funktion das Theme selbst kennen müsste.
function chartPalette() {
  const theme = document.documentElement.getAttribute("data-theme") || "dark";
  const palettes = {
    // Jede Rolle bewusst auf einen eigenen Farbton geprüft -- vorher gab es
    // in mehreren Themes exakte oder fast-identische Duplikate (z.B. warn ===
    // orange), wodurch benachbarte Chart-Serien/Kreissegmente kaum zu
    // unterscheiden waren.
    dark: { primary: "#4ade80", accent: "#22d3ee", warn: "#fbbf24", purple: "#a855f7", orange: "#fb923c", bad: "#f87171", neutral: "#94a3b8", teal: "#2dd4bf", info: "#60a5fa", onColor: "#1a1a2e" },
    light: { primary: "#34c759", accent: "#007aff", warn: "#ffcc00", purple: "#af52de", orange: "#ff9500", bad: "#ff3b30", neutral: "#8e8e93", teal: "#30b0c7", info: "#5ac8fa", onColor: "#1c1c1e" },
    apple: { primary: "#30d158", accent: "#0a84ff", warn: "#ffd60a", purple: "#bf5af2", orange: "#ff9f0a", bad: "#ff453a", neutral: "#98989f", teal: "#64d2ff", info: "#5ac8fa", onColor: "#1c1c1e" },
    // Nothing bleibt bewusst nahezu monochrom -- aber jetzt mit einer
    // echten Graustufen-Rampe statt versehentlich mehrfach demselben Grau/
    // Rot, damit z.B. eine Ausgaben-Kreisgrafik mit vielen Kategorien nicht
    // mehrere kaum unterscheidbare Rottöne nebeneinander zeigt.
    nothing: { primary: "#ffffff", accent: "#ff0000", warn: "#8a8a8a", purple: "#b8b8b8", orange: "#5c5c5c", bad: "#8b1a1a", teal: "#3d3d3d", neutral: "#707070", info: "#a0a0a0", onColor: "#000000" },
    retro80s: { primary: "#00f0ff", accent: "#ff2e97", warn: "#ffe83d", purple: "#c77dff", orange: "#ffb020", bad: "#ff5555", neutral: "#c9a8e0", teal: "#00b8d4", info: "#7dd3fc", onColor: "#170821" },
  };
  return palettes[theme] || palettes.dark;
}

function hexToRgba(hex, alpha) {
  const h = hex.replace("#", "");
  const r = parseInt(h.substring(0, 2), 16), g = parseInt(h.substring(2, 4), 16), b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// Zeitraum-Optionen — EINMAL zentral definiert, damit alle Chart-Selektoren
// garantiert dieselben Optionen anbieten. Die zugehörige Auflösung (Tage /
// Wochen / Monate) steuert resolutionForRange() weiter unten.
const CHART_RANGES = [
  { id: "1m", label: "1 Mo" },
  { id: "3m", label: "3 Mo" },
  { id: "12m", label: "12 Mo" },
  { id: "ytd", label: "YTD" },
  { id: "all", label: "Gesamt" },
];

// Kurze Zeiträume feiner auflösen — sonst zeigt "1 Monat" nur einen
// einzigen Balken und lässt keinerlei Verlauf erkennen. Spiegelt exakt
// resolution_for_range() im Backend (meters.py).
// Alle Charts arbeiten auf MONATSbasis. Feinere Auflösungen (Tage/Wochen)
// wurden bewusst wieder entfernt: Ohne engmaschige Ablesungen entstehen dabei
// nur interpolierte Werte, die mehr Genauigkeit vortäuschen als vorhanden ist.
// Die Zeitraum-Auswahl steuert weiterhin, WIE VIELE Monate gezeigt werden.
function resolutionForRange(rangeId) {
  return "month";
}

// Einheitliche Chart-Überschrift: benennt die TATSÄCHLICH gezeigte Auflösung.
// "effective" kann von der angefragten abweichen, wenn für den Zeitraum keine
// feineren Daten vorliegen (z.B. nur monatlicher PV-Import) — dann steht das
// auch so in der Überschrift, statt eine Genauigkeit vorzutäuschen.
function chartTitleWithResolution(baseTitle) {
  return `${baseTitle} je Monat`;
}

function chartColorsList() {
  const p = chartPalette();
  return [p.accent, p.warn, p.primary, p.purple, p.bad, p.teal, p.orange, p.neutral];
}

// ---------- Diagramme (reines SVG, keine externe Bibliothek nötig) ----------

function renderBarChart(income, fixed, savings) {
  const expensesTotal = fixed + savings;
  const max = Math.max(income, expensesTotal, 1);
  const W = 220, H = 170, padBottom = 34, padTop = 24, barW = 64, gap = 40;
  const chartH = H - padBottom - padTop;

  const incomeH = Math.max((income / max) * chartH, income > 0 ? 2 : 0);
  const incomeX = 16;
  const incomeY = H - padBottom - incomeH;

  // Ausgaben-Balken: Fixkosten + Sparen gestapelt, auf derselben Skala wie
  // Einnahmen — so ist auf einen Blick vergleichbar, wie die Ausgaben
  // (zusammen) im Verhältnis zu den Einnahmen stehen, und wie sie sich
  // intern aufteilen.
  const expensesH = Math.max((expensesTotal / max) * chartH, expensesTotal > 0 ? 2 : 0);
  const expensesX = incomeX + barW + gap;
  const expensesY = H - padBottom - expensesH;
  const fixedShare = expensesTotal > 0 ? fixed / expensesTotal : 0;
  const savingsShare = expensesTotal > 0 ? savings / expensesTotal : 0;
  const fixedH = expensesH * fixedShare;
  const savingsH = expensesH * savingsShare;
  const fixedPct = Math.round(fixedShare * 100);
  const savingsPct = Math.round(savingsShare * 100);

  const cpBars = chartPalette();
  const segmentLabel = (h, y, pct, text) =>
    h >= 18 ? `<text x="${expensesX + barW / 2}" y="${y + h / 2 + 4}" text-anchor="middle" font-size="10" font-weight="700" fill="${cpBars.onColor}">${pct}%</text>` : "";

  document.getElementById("chart-bars").innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block" role="img" aria-label="Einnahmen im Vergleich zu Ausgaben, Ausgaben aufgeteilt in Fixkosten und Sparen" style="overflow:visible">
      <defs>
        <linearGradient id="grad-income" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${cpBars.primary}" />
          <stop offset="100%" stop-color="${hexToRgba(cpBars.primary, 0.75)}" />
        </linearGradient>
        <linearGradient id="grad-fixed" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${cpBars.bad}" />
          <stop offset="100%" stop-color="${hexToRgba(cpBars.bad, 0.75)}" />
        </linearGradient>
        <linearGradient id="grad-savings" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${cpBars.primary}" />
          <stop offset="100%" stop-color="${hexToRgba(cpBars.primary, 0.75)}" />
        </linearGradient>
        <filter id="bar-shadow" x="-40%" y="-40%" width="180%" height="180%">
          <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.2" />
        </filter>
      </defs>
      <line x1="10" y1="${H - padBottom}" x2="${W - 10}" y2="${H - padBottom}" stroke="rgba(255,255,255,0.12)" />

      <rect x="${incomeX}" y="${incomeY}" width="${barW}" height="${incomeH}" rx="6" fill="url(#grad-income)" filter="url(#bar-shadow)" />
      <text x="${incomeX + barW / 2}" y="${incomeY - 6}" text-anchor="middle" font-size="10" fill="var(--text)">${fmt(income)}</text>
      <text x="${incomeX + barW / 2}" y="${H - padBottom + 15}" text-anchor="middle" font-size="11" fill="var(--muted)">Einnahmen</text>

      <clipPath id="clip-expenses-bar"><rect x="${expensesX}" y="${expensesY}" width="${barW}" height="${expensesH}" rx="6" /></clipPath>
      <g clip-path="url(#clip-expenses-bar)" filter="url(#bar-shadow)">
        <rect x="${expensesX}" y="${expensesY}" width="${barW}" height="${fixedH}" fill="url(#grad-fixed)">
          <title>Fixkosten: ${fmt(fixed)} (${fixedPct}%)</title>
        </rect>
        <rect x="${expensesX}" y="${expensesY + fixedH}" width="${barW}" height="${savingsH}" fill="url(#grad-savings)">
          <title>Sparen: ${fmt(savings)} (${savingsPct}%)</title>
        </rect>
      </g>
      ${segmentLabel(fixedH, expensesY, fixedPct, "Fixkosten")}
      ${segmentLabel(savingsH, expensesY + fixedH, savingsPct, "Sparen")}
      <text x="${expensesX + barW / 2}" y="${expensesY - 6}" text-anchor="middle" font-size="10" fill="var(--text)">${fmt(expensesTotal)}</text>
      <text x="${expensesX + barW / 2}" y="${H - padBottom + 15}" text-anchor="middle" font-size="11" fill="var(--muted)">Ausgaben</text>
    </svg>
    <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:0.75rem;color:var(--muted);margin-top:4px;justify-content:center">
      <span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpBars.bad};border-radius:2px;display:inline-block"></span>Fixkosten ${fmt(fixed)}</span>
      <span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpBars.primary};border-radius:2px;display:inline-block"></span>Sparen ${fmt(savings)}</span>
    </div>`;
}

function renderPieChart(categories, containerId = "chart-pie") {
  const data = categories
    .filter((c) => c.monthly_amount > 0)
    .sort((a, b) => b.monthly_amount - a.monthly_amount);

  if (data.length === 0) {
    document.getElementById(containerId).innerHTML =
      '<p class="muted">Noch keine Ausgaben erfasst</p>';
    return;
  }

  // Sehr kleine Kategorien zusammenfassen, sonst wird der Kuchen unleserlich
  const MAX = 8;
  let slices = data.slice(0, MAX).map((c) => ({
    label: c.subcategory ? `${c.category} · ${escHtml(c.subcategory)}` : (c.category || "Ohne Kategorie"),
    value: c.monthly_amount,
  }));
  if (data.length > MAX) {
    slices.push({
      label: "Weitere",
      value: data.slice(MAX).reduce((s, c) => s + c.monthly_amount, 0),
    });
  }

  const total = slices.reduce((s, c) => s + c.value, 0) || 1;
  const cx = 95, cy = 95, r = 82;
  let angle = -Math.PI / 2; // oben starten
  const colors = chartColorsList();

  const paths = slices.map((s, i) => {
    const slice = (s.value / total) * Math.PI * 2;
    const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
    angle += slice;
    const x2 = cx + r * Math.cos(angle), y2 = cy + r * Math.sin(angle);
    const largeArc = slice > Math.PI ? 1 : 0;
    // Vollkreis-Sonderfall: ein einzelner Wert würde sonst als leerer Pfad enden
    const d = slices.length === 1
      ? `M ${cx} ${cy - r} A ${r} ${r} 0 1 1 ${cx - 0.01} ${cy - r} Z`
      : `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;
    return `<path class="pie-slice" d="${d}" fill="${colors[i % colors.length]}"
                  stroke="var(--card)" stroke-width="2.5" style="transform-origin:${cx}px ${cy}px;transition:transform 0.15s ease" />`;
  }).join("");

  const legend = slices.map((s, i) => `
    <li class="legend-item">
      <span class="legend-dot" style="background:${colors[i % colors.length]}"></span>
      <span class="legend-label">${escHtml(s.label)}</span>
      <span class="legend-value">${fmt(s.value)} · ${Math.round((s.value / total) * 100)} %</span>
    </li>`).join("");

  document.getElementById(containerId).innerHTML = `
    <div class="pie-wrap">
      <svg viewBox="0 0 190 190" width="180" height="180" role="img" style="overflow:visible"
           aria-label="Verteilung der Ausgaben nach Kategorie">
        <defs>
          <filter id="pie-shadow-${containerId}" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.22" />
          </filter>
        </defs>
        <g filter="url(#pie-shadow-${containerId})">${paths}</g>
      </svg>
      <ul class="legend">${legend}</ul>
    </div>`;

  document.getElementById(containerId).querySelectorAll(".pie-slice").forEach((slice) => {
    slice.addEventListener("mouseenter", () => { slice.style.transform = "scale(1.035)"; });
    slice.addEventListener("mouseleave", () => { slice.style.transform = "scale(1)"; });
  });
}

// ---------- Finanz-Check (Health Check) ----------
const HEALTHCHECK_ICON = { green: "✅", yellow: "⚠️", red: "🔴", info: "ℹ️" };

function renderHealthCheck(checks) {
  const container = document.getElementById("healthcheck-list");
  if (!container) return;
  if (checks.length === 0) {
    container.innerHTML = '<p class="muted">Noch keine Einnahmen erfasst — Finanz-Check startet, sobald Zahlen da sind.</p>';
    return;
  }
  container.innerHTML = checks.map((c) => `
    <div class="healthcheck-item healthcheck-${c.status}">
      <div class="healthcheck-row">
        <span class="healthcheck-icon">${HEALTHCHECK_ICON[c.status] || ""}</span>
        <span class="healthcheck-title">${escHtml(c.title)}</span>
        <span class="healthcheck-value">${c.value_label}</span>
      </div>
      <p class="healthcheck-message">${escHtml(c.message)}</p>
      <p class="healthcheck-target">${c.target_label}</p>
    </div>
  `).join("");
}

// ---------- Dashboard: Überblick + Kategorien + Fälligkeiten ----------
async function loadDashboard() {
  const res = await authedFetch("/api/dashboard");
  const data = await res.json();

  document.getElementById("stat-income").textContent = fmt(data.monthly_income);
  document.getElementById("stat-fixed").textContent = fmt(data.monthly_fixed_expenses);
  document.getElementById("stat-savings").textContent = fmt(data.monthly_savings);

  const s1 = document.getElementById("stat-surplus-fixed");
  s1.textContent = fmt(data.surplus_after_fixed_costs);
  s1.style.color = data.surplus_after_fixed_costs >= 0 ? "var(--good)" : "var(--bad)";

  const s2 = document.getElementById("stat-surplus-savings");
  s2.textContent = fmt(data.surplus_after_savings);
  s2.style.color = data.surplus_after_savings >= 0 ? "var(--good)" : "var(--bad)";

  // Sammelkarte: alle Hinweise der App (Kostenbeteiligung, Bankumsätze, zu
  // kategorisieren) plus Fälligkeiten -- jeweils mit Sprung an die Stelle,
  // an der der ausführliche Hinweis steht und sich erledigen lässt.
  const reminderList = document.getElementById("duedates-list");
  const hints = data.hints || [];
  const goBtn = (tab, label, anchor) => `<button type="button" class="ghost-btn hint-btn duedate-go" data-go-tab="${escHtml(tab)}" data-go-anchor="${escHtml(anchor || "")}">→ ${escHtml(label)}</button>`;
  const dismissBtn = (key, title) => key ? `<button type="button" class="ghost-btn hint-btn duedate-dismiss" data-hint-dismiss="${escHtml(key)}" data-hint-title="${escHtml(title || "")}" title="Ablehnen – erscheint erst wieder, wenn sich etwas ändert" aria-label="Ablehnen">✕</button>` : "";
  const rows = hints.map((h) => `<li class="duedate-hint duedate-${escHtml(h.severity || "info")}"><span>${escHtml(h.icon || "ℹ️")} ${escHtml(h.text)}</span><span class="duedate-actions">${goBtn(h.tab, h.tab_label, h.anchor)}${dismissBtn(h.key, h.title)}</span></li>`)
    .concat(data.upcoming_reminders.map(
      (r) => `<li><span>${reminderIcon(r.reminder_type)} ${escHtml(r.message)} <span class="tag">${escHtml(r.trigger_date)}</span></span><span class="duedate-actions">${goBtn("tab-contracts", "Ausgaben", "contracts")}${dismissBtn(r.key, r.message)}</span></li>`
    ));
  const dismissed = data.dismissed_hints || [];
  reminderList.innerHTML = (rows.length ? rows.join("")
    : '<li class="muted">Keine Hinweise und keine Fälligkeiten in den nächsten 4 Wochen 🎉</li>')
    + (dismissed.length ? `<li class="duedate-dismissed"><details class="hint-dismissed"><summary>Abgelehnte Hinweise (${dismissed.length})</summary>
        ${dismissed.map((d) => `<div class="hint-dismissed-row"><span>${escHtml(d.title || d.hint_key)}</span>
          <button type="button" class="ghost-btn hint-btn" data-hint-restore="${escHtml(d.hint_key)}">Wiederherstellen</button></div>`).join("")}
      </details></li>` : "");
  reminderList.querySelectorAll("[data-go-tab]").forEach((b) => b.addEventListener("click", () => goToHint(b.dataset.goTab, b.dataset.goAnchor)));
  reminderList.querySelectorAll("[data-hint-dismiss]").forEach((b) => b.addEventListener("click", () => dismissHint(b.dataset.hintDismiss, b.dataset.hintTitle)));
  reminderList.querySelectorAll("[data-hint-restore]").forEach((b) => b.addEventListener("click", async () => {
    await authedFetch("/api/hints/restore", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ hint_key: b.dataset.hintRestore }) });
    showToast("Hinweis wiederhergestellt");
    loadDashboard(); loadIncomeHints();
    if (typeof loadBankInsights === "function") loadBankInsights();
  }));

  renderBarChart(data.monthly_income, data.monthly_fixed_expenses, data.monthly_savings);
  renderPieChart(data.by_category || []);
  renderHealthCheck(data.health_check || []);
}

// Hinweis ablehnen (Dashboard-Sammelkarte und Detailkarten nutzen denselben Speicher).
async function dismissHint(key, title) {
  const res = await authedFetch("/api/hints/dismiss", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ hint_key: key, title: title || "" }) });
  if (!res.ok) { showToast("Ablehnen fehlgeschlagen"); return; }
  showToast("Hinweis abgelehnt");
  loadDashboard(); loadIncomeHints();
  if (typeof loadBankInsights === "function") loadBankInsights();
}

// Wechselt zum Tab eines Hinweises und scrollt zur ausführlichen Stelle.
function goToHint(tab, anchor) {
  const btn = document.querySelector(`.sidebar-btn[data-tab="${CSS.escape(tab)}"]`);
  if (btn && !btn.classList.contains("active")) btn.click();
  if (!anchor) return;
  let tries = 0;
  const tryScroll = () => {
    const el = document.getElementById(anchor);
    if (el && el.offsetParent !== null) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
      el.classList.remove("hint-flash"); void el.offsetWidth; el.classList.add("hint-flash");
    } else if (tries++ < 20) setTimeout(tryScroll, 150);   // Karte wird ggf. erst nachgeladen
  };
  tryScroll();
}

// ---------- Einnahmen: Hinweise zur Kostenbeteiligung ----------
async function loadIncomeHints() {
  const card = document.getElementById("income-hints-card");
  if (!card) return;
  const checks = await (await authedFetch("/api/cost-share-check")).json().catch(() => []);
  const open = (checks || []).filter((c) => (!c.ok || c.archived_contracts.length) && !c.dismissed);
  if (!open.length) { card.style.display = "none"; return; }
  card.style.display = "block";
  const pct = (x) => `${Math.round(x * 1000) / 10} %`.replace(".", ",");
  document.getElementById("income-hints-list").innerHTML = open.map((c) => {
    const under = c.diff_monthly < 0;
    const rows = c.items.map((it) => `<tr${it.active ? "" : ' class="muted"'}>
        <td>${escHtml(it.label)}${it.active ? "" : " (archiviert)"}</td>
        <td style="text-align:right">${fmt(it.contract_monthly)}</td>
        <td style="text-align:right">${pct(it.share)}</td>
        <td style="text-align:right"><strong>${fmt(it.part_monthly)}</strong></td></tr>`).join("");
    const freqNote = c.frequency && c.frequency !== "monthly" ? ` (${freqLabel(c.frequency)} ${fmt(c.suggested_amount)})` : "";
    return `<div class="hint">
      <div class="hint-head">🏠 <strong>${escHtml(c.income_label)}</strong> <span class="tag">Kostenbeteiligung</span></div>
      ${c.ok ? "" : `<div class="hint-main">Erhalten ${fmt(c.actual_monthly)}/Mon., laut Anteilen <strong>${fmt(c.expected_monthly)}</strong>/Mon.
        <span style="color:var(--${under ? "bad" : "accent"})">· ${fmt(Math.abs(c.diff_monthly))} ${under ? "zu wenig" : "zu viel"}</span></div>`}
      ${c.archived_contracts.length ? `<div class="muted hint-meta">Archivierter Vertrag verknüpft: ${escHtml(c.archived_contracts.join(", "))} – bitte den Nachfolger verknüpfen.</div>` : ""}
      <div class="table-scroll"><table class="mini-table" style="width:100%;font-size:0.8rem;margin-top:6px">
        <thead><tr><th style="text-align:left">Vertrag</th><th style="text-align:right">Betrag/Mon.</th><th style="text-align:right">Anteil</th><th style="text-align:right">ergibt</th></tr></thead>
        <tbody>${rows}</tbody></table></div>
      <div class="hint-actions">
        ${c.ok ? "" : `<button type="button" class="ghost-btn hint-btn" data-share-apply="${c.income_id}" data-share-amount="${c.suggested_amount}">Betrag auf ${fmt(c.suggested_amount)}${freqNote ? "" : "/Mon."} setzen</button>`}
        <button type="button" class="ghost-btn hint-btn" data-share-edit="${c.income_id}">Verknüpfte Verträge bearbeiten</button>
        <button type="button" class="ghost-btn hint-btn" data-share-dismiss="${escHtml(c.hint_key)}" data-share-title="${escHtml(c.income_label)}">Ablehnen</button>
      </div>
    </div>`;
  }).join("");
  const list = document.getElementById("income-hints-list");
  list.querySelectorAll("[data-share-apply]").forEach((b) => b.addEventListener("click", async () => {
    if (!confirm(`Betrag der Einnahme auf ${fmt(Number(b.dataset.shareAmount))} setzen?`)) return;
    const res = await authedFetch("/api/banks/insights/apply-amount", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: "income", target_id: Number(b.dataset.shareApply), amount: Number(b.dataset.shareAmount) }) });
    if (!res.ok) { showToast("Übernehmen fehlgeschlagen"); return; }
    showToast("Betrag angepasst");
    loadIncome(); loadDashboard();
  }));
  list.querySelectorAll("[data-share-dismiss]").forEach((b) => b.addEventListener("click", () => dismissHint(b.dataset.shareDismiss, b.dataset.shareTitle)));
  list.querySelectorAll("[data-share-edit]").forEach((b) => b.addEventListener("click", async () => {
    await openIncomeForm(b.dataset.shareEdit);
    document.getElementById("income-show-costshare-btn").click();
  }));
}

// Detail-Dialog einer Einnahme: verknüpfte Verträge + Anteil (Toggle, lädt erst beim Klick)
document.getElementById("income-show-costshare-btn")?.addEventListener("click", async () => {
  const section = document.getElementById("income-costshare-section");
  if (section.style.display !== "none") { section.style.display = "none"; return; }
  const incomeId = document.getElementById("income-form").dataset.incomeId;
  if (!incomeId) return;
  section.style.display = "block";
  section.innerHTML = '<p class="muted">Lade …</p>';
  const data = await (await authedFetch(`/api/income/${incomeId}/cost-shares`)).json();
  const linked = Object.fromEntries((data.items || []).map((i) => [String(i.contract_id), i.share]));
  const shareVal = (id) => Math.round((linked[id] ?? 0.5) * 100);
  section.innerHTML = `
    <p class="muted" style="font-size:0.78rem;margin:0 0 6px">Welche Ausgaben deckt diese Einnahme anteilig? Abweichungen erscheinen als Hinweis im Dashboard.</p>
    <div class="doc-list-scroll" style="overflow-x:auto"><table class="cs-table">
      <thead><tr><th></th><th style="text-align:left">Vertrag</th><th style="text-align:right">€/Mon.</th><th style="text-align:right">%</th></tr></thead>
      <tbody>${(data.candidates || []).map((c) => `<tr>
        <td><input type="checkbox" data-cs-contract="${c.contract_id}" ${String(c.contract_id) in linked ? "checked" : ""}></td>
        <td>${escHtml(c.label)} <span class="muted">${escHtml(c.category || "")}</span></td>
        <td style="text-align:right">${fmt(c.contract_monthly)}</td>
        <td style="text-align:right;white-space:nowrap"><input type="text" inputmode="decimal" class="cs-share" data-cs-share="${c.contract_id}" value="${shareVal(String(c.contract_id))}"></td>
      </tr>`).join("")}</tbody></table></div>
    <div id="income-costshare-sum" class="muted" style="font-size:0.8rem;margin-top:6px"></div>
    <button type="button" id="income-costshare-save" class="ghost-btn" style="width:100%;margin-top:6px">Verknüpfung speichern</button>`;
  const amountOf = Object.fromEntries((data.candidates || []).map((c) => [String(c.contract_id), c.contract_monthly]));
  const collect = () => Array.from(section.querySelectorAll("[data-cs-contract]:checked")).map((cb) => {
    const id = cb.dataset.csContract;
    const pctVal = parseGermanNumber(section.querySelector(`[data-cs-share="${id}"]`).value);
    return { contract_id: Number(id), share: Math.min(Math.max(pctVal, 0), 100) / 100 };
  }).filter((x) => x.share > 0);
  const updateSum = () => {
    const sum = collect().reduce((s, x) => s + (amountOf[String(x.contract_id)] || 0) * x.share, 0);
    document.getElementById("income-costshare-sum").textContent = collect().length ? `Erwartet: ${fmt(sum)} pro Monat` : "Keine Verträge verknüpft.";
  };
  section.querySelectorAll("input").forEach((i) => i.addEventListener("input", updateSum));
  updateSum();
  document.getElementById("income-costshare-save").addEventListener("click", async () => {
    const res = await authedFetch(`/api/income/${incomeId}/cost-shares`, { method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: collect() }) });
    if (!res.ok) { const e = await res.json().catch(() => ({})); showToast(e.detail || "Speichern fehlgeschlagen"); return; }
    showToast("Verknüpfung gespeichert");
    loadIncomeHints(); loadDashboard();
  });
});

// ---------- PDF-Export ----------
document.getElementById("export-pdf-btn").addEventListener("click", async (e) => {
  const btn = e.target;
  const originalText = btn.textContent;
  btn.textContent = "Wird erstellt …";
  btn.disabled = true;
  try {
    const res = await authedFetch("/api/report/pdf");
    if (!res.ok) throw new Error("Export fehlgeschlagen");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Finanzreport_${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (err) {
    alert("PDF-Export fehlgeschlagen: " + err.message);
  } finally {
    btn.textContent = originalText;
    btn.disabled = false;
  }
});

document.getElementById("export-energy-pdf-btn").addEventListener("click", async (e) => {
  const btn = e.target;
  const originalText = btn.textContent;
  btn.textContent = "Wird erstellt …";
  btn.disabled = true;
  try {
    const res = await authedFetch("/api/report/energy-pdf");
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || "Export fehlgeschlagen");
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Energy-Monitor-Report_${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (err) {
    alert("PDF-Export fehlgeschlagen: " + err.message);
  } finally {
    btn.textContent = originalText;
    btn.disabled = false;
  }
});

// ---------- Einnahmen ----------
async function loadIncome() {
  loadIncomeHints();
  const res = await authedFetch("/api/income");
  const rows = await res.json();
  allIncome = rows;
  const container = document.getElementById("income-groups");
  if (rows.length === 0) {
    container.innerHTML = '<p class="muted">Noch keine Einnahmen erfasst</p>';
    return;
  }

  // Aufgeklappte Gruppen merken, damit eine Aktualisierung (z.B. Betrag
  // bearbeiten) nicht alle Gruppen wieder einklappt — gleiches Muster wie
  // bei den Ausgaben.
  const expandedGroups = new Set(
    Array.from(container.querySelectorAll(".contract-list:not(.collapsed)"))
      .map((ul) => ul.dataset.group)
  );

  const groups = {};
  for (const r of rows) {
    const key = r.category || "Sonstiges";
    (groups[key] = groups[key] || []).push(r);
  }
  // Immer wertbasiert sortiert -- höchster Betrag zuerst, sowohl je Gruppe
  // als auch innerhalb einer Gruppe. Keine manuelle Sortierung mehr.
  Object.values(groups).forEach((items) => items.sort((a, b) => b.monthly_amount - a.monthly_amount));

  const sortedGroups = Object.entries(groups)
    .map(([groupName, items]) => [groupName, items, items.reduce((sum, r) => sum + (r.active ? r.monthly_amount : 0), 0)])
    .sort((a, b) => b[2] - a[2]);

  const total = rows.filter((r) => r.active).reduce((sum, r) => sum + r.monthly_amount, 0);

  container.innerHTML = sortedGroups.map(([groupName, items, groupSum]) => {
    const isExpanded = expandedGroups.has(groupName);
    return `
    <div class="contract-group">
      <h3 class="group-toggle">
        <span class="chevron">${isExpanded ? "▾" : "▸"}</span> ${escHtml(groupName)}
        <span class="group-sum">${fmt(groupSum)}/Mon.</span>
      </h3>
      <ul class="contract-list${isExpanded ? "" : " collapsed"}" data-group="${escHtml(groupName)}">
        ${items.map((r) => `
          <li class="contract-row income-item" data-income-row="${r.id}" data-drag-id="${r.id}" style="${r.active ? "" : "opacity:0.5"}">
            <div class="contract-main">
              ${rowMenuButtonHTML("income", r.id)}
              <span class="contract-label">${escHtml(r.label)}</span>
              <span class="tag">${sourceLabel(r.source)}</span>
              ${!r.active ? '<span class="tag">inaktiv</span>' : ""}
            </div>
            <div class="contract-amount row-actions">
              <input type="text" class="inline-amount" data-income-id="${r.id}" value="${formatAmountForInput(r.amount)}" inputmode="decimal" />
              <span class="muted" style="font-size:0.75rem">€/${freqLabel(r.frequency)} · ${fmt(r.monthly_amount)}/Mon.</span>
            </div>
          </li>`).join("")}
      </ul>
    </div>`;
  }).join("") + `
    <ul><li class="total-row"><span>Summe / Monat</span><span>${fmt(total)}</span></li></ul>`;

  container.querySelectorAll(".group-toggle").forEach((h3) => {
    h3.addEventListener("click", () => {
      const ul = h3.nextElementSibling;
      ul.classList.toggle("collapsed");
      h3.querySelector(".chevron").textContent = ul.classList.contains("collapsed") ? "▸" : "▾";
    });
  });

  container.querySelectorAll("[data-income-id]").forEach((input) => {
    input.addEventListener("change", async () => {
      const amount = parseGermanNumber(input.value);
      if (Number.isNaN(amount)) return alert("Ungültiger Betrag");
      await patchJSON(`/api/income/${input.dataset.incomeId}`, { amount });
      loadIncome();
      loadDashboard();
      // Die Versorgungslücken-Berechnung in Vorsorge hängt direkt am
      // Nettoeinkommen -- ohne dies zu invalidieren, zeigte Vorsorge bis zum
      // nächsten Neuladen weiterhin die Zahlen mit dem alten Einkommen.
      vorsorgeLastRenteData = null;
      vorsorgeLastRisikoData = null;
    });
  });

  container.querySelectorAll("[data-income-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuIncomeId = row.dataset.incomeRow;
      showIncomeContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(container, "income", (id, x, y) => {
    contextMenuIncomeId = id;
    showIncomeContextMenu(x, y);
  });

  const bulkSelect = document.getElementById("payslip-bulk-income");
  if (bulkSelect) {
    const previousValue = bulkSelect.value;
    bulkSelect.innerHTML = rows.map((r) => `<option value="${r.id}">${escHtml(r.label)}${r.category ? ` (${escHtml(r.category)})` : ""}</option>`).join("");
    if (previousValue) bulkSelect.value = previousValue;
  }
}

let allIncome = [];
let contextMenuIncomeId = null;
const incomeContextMenu = document.getElementById("income-context-menu");
const incomeFormOverlay = document.getElementById("income-form-overlay");

function showIncomeContextMenu(x, y) {
  incomeContextMenu.style.left = `${x}px`;
  incomeContextMenu.style.top = `${y}px`;
  incomeContextMenu.style.display = "block";
}

function hideIncomeContextMenu() {
  incomeContextMenu.style.display = "none";
  contextMenuIncomeId = null;
}

document.addEventListener("click", (e) => {
  if (!incomeContextMenu.contains(e.target)) hideIncomeContextMenu();
});

incomeContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuIncomeId;
  hideIncomeContextMenu();
  if (id) openIncomeForm(id);
});

incomeContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuIncomeId;
  hideIncomeContextMenu();
  if (!id || !confirm("Diese Einnahme wirklich löschen?")) return;
  await authedFetch(`/api/income/${id}`, { method: "DELETE" });
  loadIncome();
  loadDashboard();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
});

async function openIncomeForm(incomeId) {
  const form = document.getElementById("income-form");
  form.reset();
  form.dataset.incomeId = incomeId || "";
  document.getElementById("income-form-title").textContent = incomeId ? "✏️ Einnahme bearbeiten" : "➕ Neue Einnahme";

  const personSelect = document.getElementById("income-person");
  if (personSelect.options.length <= 1) {
    const members = await (await authedFetch("/api/family-members")).json();
    members.forEach((m) => {
      const opt = document.createElement("option");
      opt.value = m.id; opt.textContent = m.name;
      personSelect.appendChild(opt);
    });
  }

  if (incomeId) {
    const row = allIncome.find((r) => String(r.id) === String(incomeId));
    if (row) {
      document.getElementById("income-label").value = row.label;
      document.getElementById("income-category").value = row.category || "";
      document.getElementById("income-amount").value = row.amount;
      document.getElementById("income-frequency").value = row.frequency;
      personSelect.value = row.person_id || "";
    }
  }

  const payslipsSection = document.getElementById("income-payslips-section");
  const showPayslipsBtn = document.getElementById("income-show-payslips-btn");
  payslipsSection.style.display = "none";
  payslipsSection.innerHTML = "";
  const costShareSection = document.getElementById("income-costshare-section");
  costShareSection.style.display = "none";
  costShareSection.innerHTML = "";
  document.getElementById("income-show-costshare-btn").style.display = incomeId ? "block" : "none";
  const paymentsSection = document.getElementById("income-payments-section");
  paymentsSection.style.display = "none";
  paymentsSection.dataset.incomeId = incomeId || "";
  document.getElementById("income-show-payments-btn").style.display = incomeId ? "block" : "none";
  incomeFormPayslipsCache = null;

  if (incomeId) {
    showPayslipsBtn.style.display = "block";
    incomeFormPayslipsCache = await (await authedFetch(`/api/income/${incomeId}/payslips`)).json();
  } else {
    // Eine noch nicht gespeicherte, neue Einnahme hat zwangsläufig keine
    // Gehaltsabrechnungs-Historie — der Button wäre hier nur eine leere Sackgasse.
    showPayslipsBtn.style.display = "none";
  }

  incomeFormOverlay.style.display = "flex";
}

let incomeFormPayslipsCache = null;

document.getElementById("income-show-payslips-btn").addEventListener("click", () => {
  const section = document.getElementById("income-payslips-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) {
    section.style.display = "none";
    return;
  }
  const incomeId = document.getElementById("income-form").dataset.incomeId;
  section.style.display = "block";
  const slips = incomeFormPayslipsCache || [];
  if (slips.length === 0) {
    section.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Gehaltsabrechnungen hinterlegt.</p>';
    return;
  }
  section.innerHTML = '<div id="income-payslips-list"></div>';
  setupScrollableDocList("income-payslips-list", slips, (s) => s.detected_month || s.uploaded_at, (filtered, ul) => {
    // Wie oft kommt derselbe Monat in der aktuell angezeigten (ggf.
    // jahresgefilterten) Liste vor? Nur dann lohnt sich eine
    // Unterscheidungshilfe — im Normalfall (1 Beleg/Monat) reicht "Jul 2026".
    const monthCounts = {};
    filtered.forEach((s) => {
      const key = s.detected_month || s.uploaded_at || "?";
      monthCounts[key] = (monthCounts[key] || 0) + 1;
    });
    ul.innerHTML = filtered.map((s) => {
      const monthKey = s.detected_month || s.uploaded_at || "?";
      const monthLabel = s.detected_month ? formatPayslipMonth(s.detected_month) : (s.uploaded_at ? `hochgeladen ${s.uploaded_at.slice(0, 10)}` : "Datum unbekannt");
      const needsDisambiguation = monthCounts[monthKey] > 1;
      return `
      <li data-payslip-row="${s.id}">
        <a href="/api/payslips/${s.id}/file" rel="noopener" data-view-doc-url="/api/payslips/${s.id}/file" data-view-doc-title="${monthLabel}">
          📄 ${monthLabel}${needsDisambiguation ? ` — ${escHtml(s.original_filename || "Beleg " + s.id)}` : ""}
        </a>
        <span class="row-actions">
          ${s.detected_net_amount ? `<span class="muted" style="font-size:0.72rem">${fmt(s.detected_net_amount)}</span>` : ""}
          <a href="/api/payslips/${s.id}/file?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
          <button type="button" class="del-btn" data-delete-payslip="${s.id}" title="Löschen">🗑</button>
        </span>
      </li>`;
    }).join("");
    wireDocumentViewerLinks(ul);
    ul.querySelectorAll("[data-delete-payslip]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        if (!confirm("Diese Gehaltsabrechnung wirklich löschen?")) return;
        await authedFetch(`/api/payslips/${btn.dataset.deletePayslip}`, { method: "DELETE" });
        await openIncomeForm(incomeId);
        document.getElementById("income-show-payslips-btn").click();
      });
    });
  });
});

document.getElementById("add-income-btn").addEventListener("click", () => openIncomeForm(null));
document.getElementById("income-form-cancel-btn").addEventListener("click", () => {
  incomeFormOverlay.style.display = "none";
});

document.getElementById("income-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const incomeId = e.target.dataset.incomeId;
  const label = document.getElementById("income-label").value.trim();
  if (!label) return alert("Bitte eine Bezeichnung angeben.");
  const amount = parseGermanNumber(document.getElementById("income-amount").value);
  if (amount === null || Number.isNaN(amount)) return alert("Ungültiger Betrag.");
  const personVal = document.getElementById("income-person").value;

  const payload = {
    label,
    category: document.getElementById("income-category").value.trim() || "Sonstiges",
    amount,
    frequency: document.getElementById("income-frequency").value,
    person_id: personVal ? parseInt(personVal, 10) : null,
  };

  const res = incomeId
    ? await authedFetch(`/api/income/${incomeId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      })
    : await authedFetch("/api/income", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Speichern.");
  }
  incomeFormOverlay.style.display = "none";
  loadIncome();
  loadDashboard();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
});

document.getElementById("payslip-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("payslip-input");
  const password = document.getElementById("payslip-password").value;
  const resultDiv = document.getElementById("payslip-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst eine PDF auswählen.";
    return;
  }
  resultDiv.textContent = "Wird gelesen …";
  const formData = new FormData();
  formData.append("file", input.files[0]);
  if (password) formData.append("password", password);

  const res = await authedFetch("/api/payslips/upload", { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) {
    resultDiv.textContent = data.detail || "Fehler beim Lesen der PDF.";
    return;
  }
  const d = data.detected;
  const incomeRows = await (await authedFetch("/api/income")).json();
  const incomeOptions = incomeRows.map((r) => `<option value="${r.id}">${escHtml(r.label)}</option>`).join("");

  resultDiv.innerHTML = `
    <p style="margin:0 0 8px">Erkannt: <b>${fmt(d.net_amount)}</b> · ${escHtml(d.month || "Monat unbekannt")} · ${escHtml(d.employer || "?")}</p>
    <label class="muted" style="font-size:0.8rem">Wem gehört diese Abrechnung?</label>
    <select id="payslip-income-select"${data.matched_income ? "" : ' class="needs-attention"'}>
      <option value="">– neue Einnahme anlegen –</option>
      ${incomeOptions}
    </select>
    ${data.matched_income ? `<p class="muted" style="margin:4px 0 0;font-size:0.75rem">✅ automatisch zugeordnet (Name erkannt)</p>` : ""}
    <label class="checkbox-label">
      <input type="checkbox" id="payslip-update-income" checked />
      <span>Einkommen aktualisieren (bei reinen Mitteilungen ohne Gehaltszahlung abwählen)</span>
    </label>
    <button id="payslip-confirm-btn" style="margin-top:10px">Übernehmen</button>
  `;

  if (data.matched_income) {
    document.getElementById("payslip-income-select").value = String(data.matched_income.id);
  }

  document.getElementById("payslip-confirm-btn").addEventListener("click", async () => {
    const update_income = document.getElementById("payslip-update-income").checked;
    const selected = document.getElementById("payslip-income-select").value;
    let income_id = selected ? parseInt(selected, 10) : null;
    let new_income_label = null;
    if (update_income && !income_id) {
      new_income_label = prompt("Bezeichnung für diese neue Einnahme:", d.employer || "Gehalt");
      if (!new_income_label) return;
    }
    await authedFetch(`/api/payslips/${data.payslip_id}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ income_id, new_income_label, update_income }),
    });
    resultDiv.innerHTML += "<br>Übernommen ✅";
    loadIncome();
    loadDashboard();
  });
});

document.getElementById("payslip-bulk-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("payslip-bulk-input");
  const incomeSelect = document.getElementById("payslip-bulk-income");
  const password = document.getElementById("payslip-bulk-password").value;
  const resultDiv = document.getElementById("payslip-bulk-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst eine oder mehrere PDFs auswählen.";
    return;
  }
  if (!incomeSelect.value) {
    resultDiv.textContent = "Bitte zuerst eine Einnahme anlegen, der die Abrechnungen zugeordnet werden.";
    return;
  }
  resultDiv.textContent = `Importiere ${input.files.length} Dateien …`;
  const formData = new FormData();
  formData.append("income_id", incomeSelect.value);
  for (const file of input.files) formData.append("files", file);
  if (password) formData.append("password", password);

  const res = await authedFetch("/api/payslips/bulk-upload", { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) {
    resultDiv.textContent = data.detail || "Fehler beim Import.";
    return;
  }
  const failed = data.results.filter((r) => r.error);
  resultDiv.innerHTML = `
    <p style="margin:4px 0 0">✅ ${data.count} Datei${data.count === 1 ? "" : "en"} importiert${failed.length ? `, davon ${failed.length} ohne erkannte Werte (trotzdem archiviert)` : ""}.</p>
    <p class="muted" style="font-size:0.75rem;margin:2px 0 0">Der aktuelle Betrag der Einnahme wurde dabei bewusst nicht verändert.</p>`;
  input.value = "";
});

document.getElementById("bulk-receipt-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("bulk-receipt-input");
  const contractSelect = document.getElementById("bulk-receipt-contract");
  const resultDiv = document.getElementById("bulk-receipt-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst eine oder mehrere Dateien auswählen.";
    return;
  }
  if (!contractSelect.value) {
    resultDiv.textContent = "Bitte zuerst einen Vertrag anlegen, dem die Belege zugeordnet werden.";
    return;
  }
  resultDiv.textContent = `Importiere ${input.files.length} Dateien …`;
  const formData = new FormData();
  for (const file of input.files) formData.append("files", file);

  const res = await authedFetch(`/api/contracts/${contractSelect.value}/bulk-upload-receipts`, {
    method: "POST", body: formData,
  });
  const data = await res.json();
  if (!res.ok) {
    resultDiv.textContent = data.detail || "Fehler beim Import.";
    return;
  }
  const skipped = data.results.filter((r) => r.skipped);
  resultDiv.innerHTML = `
    <p style="margin:4px 0 0">✅ ${data.count} Datei${data.count === 1 ? "" : "en"} verarbeitet${skipped.length ? `, davon ${skipped.length} bereits vorhanden (übersprungen)` : ""}.</p>
    <p class="muted" style="font-size:0.75rem;margin:2px 0 0">Der aktuelle Vertragsbetrag wurde dabei bewusst nicht verändert.</p>`;
  input.value = "";
});

// ---------- Kategorie-Dropdown-Helfer: "Haus" nur mit Unterkategorie wählbar ----------
function categoryOptionsHTML() {
  const entries = allCategories.flatMap((cat) => {
    if (cat === "Haus") {
      return [
        { value: "Haus::Finanzierung", label: "Haus · Finanzierung" },
        { value: "Haus::Nebenkosten", label: "Haus · Nebenkosten" },
      ];
    }
    return [{ value: cat, label: cat }];
  });
  entries.sort((a, b) => a.label.localeCompare(b.label, "de"));
  return entries.map((e) => `<option value="${escHtml(e.value)}">${escHtml(e.label)}</option>`).join("");
}

function categoryValueFor(categoryName, subcategory) {
  return categoryName === "Haus" ? `Haus::${subcategory || "Nebenkosten"}` : (categoryName || "Sonstiges");
}

function parseCategoryValue(value) {
  if (value.includes("::")) {
    const [category, subcategory] = value.split("::");
    return { category, subcategory };
  }
  return { category: value, subcategory: null };
}

// ---------- Admin-Ebene: Kategorien verwalten ----------
const manageCategoriesOverlay = document.getElementById("manage-categories-overlay");
const categoriesOverlay = document.getElementById("categories-overlay");

async function loadManageCategoriesList() {
  allCategories = await (await authedFetch("/api/categories")).json();
  const list = document.getElementById("manage-categories-list");
  list.innerHTML = allCategories.map((cat) => `<li><span>${escHtml(cat)}</span></li>`).join("");
}

document.getElementById("manage-categories-btn").addEventListener("click", async () => {
  const toggleRes = await authedFetch("/api/settings/energy_monitor_enabled");
  const { value } = await toggleRes.json();
  document.getElementById("toggle-energy-monitor").checked = !!value;
  const vorsorgeToggleRes = await authedFetch("/api/settings/vorsorge_enabled");
  const { value: vorsorgeValue } = await vorsorgeToggleRes.json();
  document.getElementById("toggle-vorsorge").checked = !!vorsorgeValue;
  manageCategoriesOverlay.style.display = "flex";
  loadBackupStatus();
  loadSecurityStatus();
  const versionMatch = APP_BUILD.match(/·\s*(v\d+)/);
  document.getElementById("app-version-current").textContent = versionMatch ? versionMatch[1] : "–";
});

async function loadSecurityStatus() {
  const statusEl = document.getElementById("security-2fa-status");
  const setupBtn = document.getElementById("security-setup-totp-btn");
  const disableBtn = document.getElementById("security-disable-totp-btn");
  const status = await (await authedFetch("/api/auth/status")).json();
  const parts = [];
  if (status.passkey_registered) parts.push("Passkey aktiv");
  if (status.totp_registered) parts.push("Authenticator-App (TOTP) aktiv");
  statusEl.textContent = parts.length ? `Zweiter Faktor: ${parts.join(" · ")}.` : "Kein zweiter Faktor aktiv.";
  setupBtn.style.display = status.totp_registered ? "none" : "";
  disableBtn.style.display = status.totp_registered ? "" : "none";
  document.getElementById("security-totp-setup-area").style.display = "none";
}

document.getElementById("security-add-passkey-btn").addEventListener("click", async () => {
  const issue = webauthnSupportIssue();
  if (issue) return alert(issue);
  try {
    await registerPasskey("Weiteres Gerät");
    alert("Passkey hinzugefügt.");
    loadSecurityStatus();
  } catch (err) {
    alert("Fehlgeschlagen: " + formatWebAuthnError(err));
  }
});

let securityPendingTotpSecret = null;

document.getElementById("security-setup-totp-btn").addEventListener("click", async () => {
  const res = await authedFetch("/api/auth/totp/setup/begin", { method: "POST" });
  const data = await res.json();
  securityPendingTotpSecret = data.secret;
  document.getElementById("security-totp-qr").innerHTML =
    `<img src="/api/auth/totp/qr?secret=${encodeURIComponent(data.secret)}" alt="QR-Code" style="width:180px;height:180px" />`;
  document.getElementById("security-totp-secret-fallback").textContent = `Manuell eintragen: ${data.secret}`;
  document.getElementById("security-totp-setup-area").style.display = "block";
});

document.getElementById("security-totp-confirm-btn").addEventListener("click", async () => {
  const code = document.getElementById("security-totp-code").value.trim();
  if (!securityPendingTotpSecret || !code) return;
  const res = await authedFetch("/api/auth/totp/setup/complete", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ secret: securityPendingTotpSecret, code }),
  });
  if (res.ok) {
    alert("Authenticator-App eingerichtet.");
    loadSecurityStatus();
  } else {
    alert("Code stimmt nicht überein — bitte erneut versuchen.");
  }
});

document.getElementById("security-disable-totp-btn").addEventListener("click", async () => {
  if (!confirm("Authenticator-App (TOTP) wirklich deaktivieren?")) return;
  await authedFetch("/api/auth/totp/disable", { method: "POST" });
  loadSecurityStatus();
});

function renderBackupStatus(backups) {
  const el = document.getElementById("backup-status");
  if (!backups || backups.length === 0) {
    el.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Sicherung vorhanden.</p>';
    return;
  }
  const latest = backups[0];
  const date = new Date(latest.created_at);
  el.innerHTML = `<p style="font-size:0.78rem;color:var(--good)">✅ Letzte Sicherung: ${date.toLocaleString("de-DE")} (${backups.length} insgesamt, ${latest.size_kb} KB)</p>`;
}

async function loadBackupStatus() {
  document.getElementById("backup-status").innerHTML = '<p class="muted" style="font-size:0.78rem">Lade …</p>';
  const backups = await (await authedFetch("/api/maintenance/backups")).json();
  renderBackupStatus(backups);
}

document.getElementById("backup-now-btn").addEventListener("click", async () => {
  const btn = document.getElementById("backup-now-btn");
  btn.disabled = true;
  document.getElementById("backup-status").innerHTML = '<p class="muted" style="font-size:0.78rem">Sichere …</p>';
  const res = await authedFetch("/api/maintenance/backup-now", { method: "POST" });
  const data = await res.json();
  btn.disabled = false;
  if (data.success) {
    loadBackupStatus();
  } else {
    document.getElementById("backup-status").innerHTML = `<p style="color:var(--bad);font-size:0.78rem">❌ Fehlgeschlagen: ${escHtml(data.error)}</p>`;
  }
});

let pendingCombinedUpdate = null;

function renderCombinedUpdateCheck(data) {
  const statusEl = document.getElementById("combined-update-status");
  const applyBtn = document.getElementById("apply-all-updates-btn");
  document.getElementById("app-version-current").textContent = (data.app && data.app.current_version) || "–";

  const hasAppUpdate = !!(data.app && data.app.update_available);
  const outdated = (data.packages && data.packages.outdated) || [];
  const hasPackages = outdated.length > 0;

  if (!hasAppUpdate && !hasPackages) {
    const appNote = data.app && data.app.error ? ` (App-Check: ${escHtml(data.app.error)})` : "";
    statusEl.innerHTML = `<p style="font-size:0.78rem;color:var(--good)">✅ Alles aktuell${appNote}.</p>`;
    applyBtn.style.display = "none";
    pendingCombinedUpdate = null;
    return;
  }

  let html = '<p style="font-size:0.78rem;color:var(--accent);margin-bottom:4px">Folgendes wird aktualisiert:</p><ul style="margin:0;font-size:0.75rem">';
  if (hasAppUpdate) {
    html += `<li>App: ${escHtml(data.app.current_version)} → ${escHtml(data.app.latest_version)}${data.app.notes ? ` — ${escHtml(data.app.notes)}` : ""}</li>`;
  }
  if (hasPackages) {
    html += `<li>${outdated.length} Python-Paket${outdated.length > 1 ? "e" : ""}: ${outdated.map((p) => `${escHtml(p.name)} ${p.current}→${p.latest}`).join(", ")}</li>`;
  }
  html += "</ul>";
  statusEl.innerHTML = html;

  pendingCombinedUpdate = {
    apply_app: hasAppUpdate, apply_packages: hasPackages,
    download_url: hasAppUpdate ? data.app.download_url : null,
    sha256: hasAppUpdate ? data.app.sha256 : null,
  };
  applyBtn.style.display = "";
}

document.getElementById("check-all-updates-btn").addEventListener("click", async () => {
  document.getElementById("combined-update-status").innerHTML = '<p class="muted" style="font-size:0.78rem">Prüfe …</p>';
  document.getElementById("apply-all-updates-btn").style.display = "none";
  const data = await (await authedFetch("/api/maintenance/check-all-updates")).json();
  renderCombinedUpdateCheck(data);
});

document.getElementById("apply-all-updates-btn").addEventListener("click", async () => {
  if (!pendingCombinedUpdate) return;
  if (!confirm("Jetzt aktualisieren? Der Dienst startet danach automatisch neu, eine erneute Anmeldung ist nötig. Das kann einige Minuten dauern.")) return;
  const btn = document.getElementById("apply-all-updates-btn");
  const resultEl = document.getElementById("combined-update-result");
  btn.disabled = true;
  resultEl.innerHTML = '<p class="muted">Aktualisiere … das kann einige Minuten dauern.</p>';
  const res = await authedFetch("/api/maintenance/apply-all-updates", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(pendingCombinedUpdate),
  });
  const data = await res.json();
  if (data.status === "applied") {
    if ("serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister()));
    }
    resultEl.innerHTML = '<p style="color:var(--good)">✅ Aktualisiert — Dienst wird neu gestartet, Seite lädt in wenigen Sekunden neu. Danach ist eine erneute Anmeldung nötig.</p>';
    setTimeout(() => window.location.reload(), 4000);
  } else {
    btn.disabled = false;
    resultEl.innerHTML = '<p style="color:var(--bad)">❌ Fehlgeschlagen — Details siehe Konsole.</p>';
    console.error("Update fehlgeschlagen:", data);
  }
});

// Beim Start der Seite automatisch und still im Hintergrund prüfen (App-
// Version + Python-Pakete zusammen) — bei Fund einen Hinweis-Banner
// zeigen, der direkt zur Bestätigung in den Einstellungen führt, statt den
// Nutzer ungefragt irgendetwas herunterladen zu lassen.
async function checkAllUpdatesOnBoot() {
  try {
    const data = await (await authedFetch("/api/maintenance/check-all-updates")).json();
    const hasAppUpdate = !!(data.app && data.app.update_available);
    const outdatedCount = (data.packages && data.packages.outdated && data.packages.outdated.length) || 0;
    if (!hasAppUpdate && outdatedCount === 0) return;

    const parts = [];
    if (hasAppUpdate) parts.push(`App ${data.app.latest_version}`);
    if (outdatedCount > 0) parts.push(`${outdatedCount} Paket${outdatedCount > 1 ? "e" : ""}`);

    const banner = document.createElement("div");
    banner.textContent = `🔄 Update verfügbar: ${parts.join(" · ")} — zum Prüfen klicken`;
    banner.style.cssText = `position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:var(--accent);color:${chartPalette().onColor};padding:10px 16px;border-radius:10px;font-size:0.85rem;font-weight:600;z-index:200;cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,0.3)`;
    banner.addEventListener("click", () => {
      banner.remove();
      document.getElementById("manage-categories-btn").click();
      renderCombinedUpdateCheck(data);
    });
    document.body.appendChild(banner);
  } catch (e) {
    // Update-Check ist rein informativ -- ein Fehler hier darf den
    // restlichen Seitenstart nicht stoeren.
  }
}

document.getElementById("manage-categories-btn-inner").addEventListener("click", async () => {
  await loadManageCategoriesList();
  categoriesOverlay.style.display = "flex";
});

document.getElementById("categories-overlay-close-btn").addEventListener("click", () => {
  categoriesOverlay.style.display = "none";
});

document.getElementById("toggle-energy-monitor").addEventListener("change", async (e) => {
  await authedFetch("/api/settings/energy_monitor_enabled", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ value: e.target.checked }),
  });
  applyEnergyMonitorToggle();
});

document.getElementById("toggle-vorsorge").addEventListener("change", async (e) => {
  await authedFetch("/api/settings/vorsorge_enabled", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ value: e.target.checked }),
  });
  applyVorsorgeToggle();
});

document.getElementById("manage-categories-close-btn").addEventListener("click", () => {
  manageCategoriesOverlay.style.display = "none";
});

document.getElementById("add-category-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("new-category-name");
  const name = input.value.trim();
  if (!name) return;
  const res = await authedFetch("/api/categories", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Anlegen.");
  }
  input.value = "";
  await loadManageCategoriesList();
});

const insuranceTypesOverlay = document.getElementById("insurance-types-overlay");
const integrationsOverlay = document.getElementById("integrations-overlay");

document.getElementById("open-integrations-btn").addEventListener("click", async () => {
  await loadIntegrationsAdmin();
  integrationsOverlay.style.display = "flex";
});

document.getElementById("integrations-overlay-close-btn").addEventListener("click", () => {
  integrationsOverlay.style.display = "none";
});

async function loadManageInsuranceTypesList() {
  allInsuranceTypes = await (await authedFetch("/api/insurance-types")).json();
  const list = document.getElementById("manage-insurance-types-list");
  list.innerHTML = allInsuranceTypes.map((t) => `<li><span>${escHtml(t)}</span></li>`).join("");
}

document.getElementById("manage-insurance-types-btn").addEventListener("click", async () => {
  await loadManageInsuranceTypesList();
  insuranceTypesOverlay.style.display = "flex";
});

document.getElementById("insurance-types-overlay-close-btn").addEventListener("click", () => {
  insuranceTypesOverlay.style.display = "none";
});

document.getElementById("add-insurance-type-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("new-insurance-type-name");
  const name = input.value.trim();
  if (!name) return;
  const res = await authedFetch("/api/insurance-types", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Anlegen.");
  }
  input.value = "";
  await loadManageInsuranceTypesList();
});

// ---------- Verträge & Abos, gruppiert nach Kategorie ----------
let allContracts = [];
let allCategories = [];
let contextMenuContractId = null;

async function loadContracts() {
  const res = await authedFetch("/api/contracts");
  const contracts = await res.json();
  allContracts = contracts;
  const container = document.getElementById("contract-groups");
  if (contracts.length === 0) {
    container.innerHTML = '<p class="muted">Noch keine Verträge erfasst</p>';
    return;
  }

  // Welche Gruppen waren gerade aufgeklappt? Sonst würde jede Änderung
  // (z.B. Betrag bearbeiten) alle Gruppen wieder einklappen, obwohl sich
  // nur die Sortierung aktualisiert — das wirkt dann wie ein Reset statt
  // einer nahtlosen Neusortierung.
  const expandedGroups = new Set(
    Array.from(container.querySelectorAll(".contract-list:not(.collapsed)"))
      .map((ul) => ul.dataset.group)
  );

  const groups = {};
  for (const c of contracts) {
    const key = c.category_name ? (c.subcategory ? `${escHtml(c.category_name)} · ${escHtml(c.subcategory)}` : c.category_name) : "Ohne Kategorie";
    (groups[key] = groups[key] || []).push(c);
  }
  // Immer wertbasiert sortiert -- höchster Betrag zuerst, sowohl je Gruppe
  // als auch innerhalb einer Gruppe. Keine manuelle Sortierung mehr.
  Object.values(groups).forEach((items) => items.sort((a, b) => b.monthly_amount - a.monthly_amount));

  const sortedGroups = Object.entries(groups)
    .map(([groupName, items]) => [groupName, items, items.reduce((sum, c) => sum + c.monthly_amount, 0)])
    .sort((a, b) => b[2] - a[2]);

  container.innerHTML = sortedGroups.map(([groupName, items, groupSum]) => {
    const isExpanded = expandedGroups.has(groupName);
    return `
    <div class="contract-group">
      <h3 class="group-toggle">
        <span class="chevron">${isExpanded ? "▾" : "▸"}</span> ${escHtml(groupName)}
        <span class="group-sum">${fmt(groupSum)}/Mon.</span>
      </h3>
      <ul class="contract-list${isExpanded ? "" : " collapsed"}" data-group="${escHtml(groupName)}">
        ${items.map((c) => `
          <li class="contract-row" data-drag-id="${c.id}" data-contract-row="${c.id}">
            <div class="contract-main">
              ${rowMenuButtonHTML("contract", c.id)}
              <span class="contract-label">${escHtml(c.label)}${!c.label_is_manual ? ' <span class="tag" style="opacity:0.6" title="Automatisch abgeleitet">✨</span>' : ""}</span>
              ${c.contract_end ? `<span class="tag">bis ${c.contract_end}</span>` : ""}
              <span class="tag">${sourceLabel(c.source)}</span>
            </div>
            <div class="contract-amount row-actions">
              <input type="text" class="inline-amount" data-contract-id="${c.id}" value="${formatAmountForInput(c.amount)}" inputmode="decimal" />
              <span class="muted" style="font-size:0.75rem">€/${freqLabel(c.frequency)} · ${fmt(c.monthly_amount)}/Mon.</span>
            </div>
          </li>`).join("")}
      </ul>
    </div>`;
  }).join("") + `
    <ul><li class="total-row"><span>Summe / Monat</span><span>${fmt(contracts.reduce((sum, c) => sum + c.monthly_amount, 0))}</span></li></ul>`;

  container.querySelectorAll(".group-toggle").forEach((h3) => {
    h3.addEventListener("click", () => {
      const ul = h3.nextElementSibling;
      ul.classList.toggle("collapsed");
      h3.querySelector(".chevron").textContent = ul.classList.contains("collapsed") ? "▸" : "▾";
    });
  });

  container.querySelectorAll("[data-contract-id]").forEach((input) => {
    input.addEventListener("change", async () => {
      const amount = parseGermanNumber(input.value);
      if (Number.isNaN(amount)) return alert("Ungültiger Betrag");
      await patchJSON(`/api/contracts/${input.dataset.contractId}`, { amount });
      loadContracts();
      loadDashboard();
    });
  });

  // Rechtsklick öffnet das Kontextmenü statt eines separaten Lösch-Buttons
  container.querySelectorAll("[data-contract-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuContractId = row.dataset.contractRow;
      showContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(container, "contract", (id, x, y) => {
    contextMenuContractId = id;
    showContextMenu(x, y);
  });

  const bulkReceiptSelect = document.getElementById("bulk-receipt-contract");
  if (bulkReceiptSelect) {
    const previousValue = bulkReceiptSelect.value;
    bulkReceiptSelect.innerHTML = contracts.map((c) => {
      const parts = [
        c.category_name ? (c.subcategory ? `${c.category_name} · ${c.subcategory}` : c.category_name) : "?",
        c.label, c.provider || null,
      ].filter(Boolean);
      return `<option value="${c.id}">${escHtml(parts.join(" — "))}</option>`;
    }).join("");
    if (previousValue) bulkReceiptSelect.value = previousValue;
  }
}

// ---------- Neue Ausgabe manuell anlegen ----------
const addExpenseOverlay = document.getElementById("add-expense-overlay");

function updateExpenseConditionalFields() {
  const { category, subcategory } = parseCategoryValue(document.getElementById("expense-category").value);
  const isFinanzierung = category === "Haus" && subcategory === "Finanzierung";
  const isVersicherung = category === "Versicherungen";
  document.getElementById("expense-interest-rate-group").style.display = isFinanzierung ? "block" : "none";
  document.getElementById("expense-insurance-type-group").style.display = isVersicherung ? "block" : "none";

  const insType = document.getElementById("expense-insurance-type").value;
  document.getElementById("expense-insurance-life-group").style.display =
    (isVersicherung && insType === "Risikolebensversicherung") ? "block" : "none";
  document.getElementById("expense-bu-group").style.display =
    (isVersicherung && insType === "Berufsunfähigkeitsversicherung") ? "block" : "none";
}

document.getElementById("expense-category").addEventListener("change", updateExpenseConditionalFields);
document.getElementById("expense-insurance-type").addEventListener("change", updateExpenseConditionalFields);

function updateExpenseLabelDerivedHint() {
  const category = parseCategoryValue(document.getElementById("expense-category").value).category;
  const provider = document.getElementById("expense-provider").value.trim() || null;
  const contractNumber = document.getElementById("expense-contract-number").value.trim() || null;
  const insuranceType = document.getElementById("expense-insurance-type").value || null;
  const personSelect = document.getElementById("expense-person");
  const personName = personSelect.value
    ? allFamilyMembers.find((m) => String(m.id) === personSelect.value)?.name
    : null;

  const hasManualLabel = document.getElementById("expense-label").value.trim() !== "";
  const hint = document.getElementById("expense-label-derived-hint");
  if (hasManualLabel) {
    hint.style.display = "none";
    return;
  }
  let preview;
  if (category === "Versicherungen") {
    preview = [personName ? `${personName}:` : "", provider || "", insuranceType || "Versicherung"].filter(Boolean).join(" ");
  } else {
    preview = [provider || "Vertrag", contractNumber || ""].filter(Boolean).join(" ");
  }
  document.getElementById("expense-label-derived-preview").textContent = preview;
  hint.style.display = "block";
}

["expense-label", "expense-category", "expense-provider", "expense-contract-number", "expense-insurance-type", "expense-person"].forEach((id) => {
  document.getElementById(id).addEventListener("input", updateExpenseLabelDerivedHint);
  document.getElementById(id).addEventListener("change", updateExpenseLabelDerivedHint);
});

async function openAddExpenseForm(presetCategoryValue) {
  if (allCategories.length === 0) {
    allCategories = await (await authedFetch("/api/categories")).json();
  }
  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  if (allInsuranceTypes.length === 0) {
    allInsuranceTypes = await (await authedFetch("/api/insurance-types")).json();
  }
  const select = document.getElementById("expense-category");
  select.innerHTML = categoryOptionsHTML();
  document.getElementById("expense-person").innerHTML = personOptionsHTML(null);
  document.getElementById("expense-insurance-type").innerHTML = insuranceTypeOptionsHTML(null);
  document.getElementById("add-expense-form").reset();
  if (presetCategoryValue) select.value = presetCategoryValue;
  expenseEndDateToggle.setInitial(false); // Neuanlage startet ohne Fälligkeit, Feld sichtbar
  updateExpenseConditionalFields();
  updateExpenseLabelDerivedHint();
  addExpenseOverlay.style.display = "flex";
}

document.getElementById("add-expense-btn").addEventListener("click", () => openAddExpenseForm());

document.getElementById("add-expense-cancel-btn").addEventListener("click", () => {
  addExpenseOverlay.style.display = "none";
});

document.getElementById("add-expense-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const label = document.getElementById("expense-label").value.trim();
  const { category, subcategory } = parseCategoryValue(document.getElementById("expense-category").value);
  const provider = document.getElementById("expense-provider").value.trim() || null;
  const contract_number = document.getElementById("expense-contract-number").value.trim() || null;
  const amount = parseGermanNumber(document.getElementById("expense-amount").value);
  const frequency = document.getElementById("expense-frequency").value;
  const noEndDate = document.getElementById("expense-no-enddate").checked;
  const contract_end = noEndDate ? null : (document.getElementById("expense-contract-end").value || null);
  if (Number.isNaN(amount)) return alert("Bitte einen gültigen Betrag angeben.");

  const num = (id) => {
    return parseGermanNumber(document.getElementById(id).value);
  };
  const personVal = document.getElementById("expense-person").value;
  const payload = {
    label, provider, contract_number, category, subcategory, amount, frequency, contract_end,
    person_id: personVal ? parseInt(personVal, 10) : null,
    interest_rate: category === "Haus" && subcategory === "Finanzierung" ? num("expense-interest-rate") : null,
    insurance_type: category === "Versicherungen" ? document.getElementById("expense-insurance-type").value : null,
  };
  if (payload.insurance_type === "Risikolebensversicherung") {
    payload.insurance_expiry = document.getElementById("expense-insurance-expiry").value || null;
    payload.insurance_sum = num("expense-insurance-sum");
    payload.insurance_sum_type = document.getElementById("expense-insurance-sum-type").value;
  } else if (payload.insurance_type === "Berufsunfähigkeitsversicherung") {
    payload.bu_monthly_pension = num("expense-bu-pension");
  }

  const res = await authedFetch("/api/contracts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Anlegen.");
  }
  addExpenseOverlay.style.display = "none";
  loadContracts();
  loadDashboard();
  loadReview();
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
    if (document.getElementById("vermoegen-subtab-verbindlichkeiten").style.display !== "none") {
      loadVerbindlichkeiten();
    }
  }
});

// ---------- Kontextmenü ----------
const contextMenu = document.getElementById("context-menu");

function showContextMenu(x, y) {
  contextMenu.style.left = `${x}px`;
  contextMenu.style.top = `${y}px`;
  contextMenu.style.display = "block";
}

function hideContextMenu() {
  contextMenu.style.display = "none";
  contextMenuContractId = null;
}

document.addEventListener("click", (e) => {
  if (!contextMenu.contains(e.target)) hideContextMenu();
});

contextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuContractId;
  hideContextMenu();
  if (!id || !confirm("Diesen Vertrag archivieren? Er verschwindet aus der aktiven Liste, Belege bleiben im Archiv erhalten.")) return;
  const res = await authedFetch(`/api/contracts/${id}`, { method: "DELETE" });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.detail || "Fehler beim Archivieren.");
    return;
  }
  loadContracts();
  loadDashboard();
  loadReview();
});

contextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuContractId;
  hideContextMenu();
  if (!id) return;
  openDetailsModal(id);
});

// ---------- Kontextmenü für Rentenkonten (gleiche UX wie bei Ausgaben) ----------
let contextMenuPensionId = null;
const pensionContextMenu = document.getElementById("pension-context-menu");

function showPensionContextMenu(x, y) {
  pensionContextMenu.style.left = `${x}px`;
  pensionContextMenu.style.top = `${y}px`;
  pensionContextMenu.style.display = "block";
}

function hidePensionContextMenu() {
  pensionContextMenu.style.display = "none";
  contextMenuPensionId = null;
}

document.addEventListener("click", (e) => {
  if (!pensionContextMenu.contains(e.target)) hidePensionContextMenu();
});

pensionContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuPensionId;
  hidePensionContextMenu();
  if (!id) return;
  openPensionForm(id);
});

pensionContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuPensionId;
  hidePensionContextMenu();
  if (!id || !confirm("Dieses Rentenkonto wirklich löschen?")) return;
  await authedFetch(`/api/pension-accounts/${id}`, { method: "DELETE" });
  loadHaushaltSummary();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
  loadAufbauTab();
  loadAbsicherungTab();
});

// ---------- Alle Belege zu einem Vertrag anzeigen (aktiv oder archiviert) ----------
const receiptsListOverlay = document.getElementById("receipts-list-overlay");

async function showReceiptsList(contractId, contractLabel) {
  const title = document.getElementById("receipts-list-title");
  const content = document.getElementById("receipts-list-content");
  title.textContent = `🗂 Belege — ${contractLabel}`;
  content.innerHTML = '<p class="muted">Lade …</p>';
  receiptsListOverlay.style.display = "flex";
  await refreshReceiptsList(contractId, "receipts-list-content");
}

async function refreshReceiptsList(contractId, targetId = "receipts-list-content") {
  const content = document.getElementById(targetId);
  const receipts = await (await authedFetch(`/api/contracts/${contractId}/receipts`)).json();
  if (!receipts.length) {
    content.innerHTML = '<p class="muted">Noch keine Belege für diesen Vertrag hochgeladen.</p>';
    return;
  }
  content.innerHTML = `<div id="${targetId}-scroll"></div>`;
  setupScrollableDocList(`${targetId}-scroll`, receipts, (r) => resolveDocDate(r), (filtered, ul) => {
    ul.className = "receipt-list";
    ul.innerHTML = filtered.map((r) => {
      const dateStr = resolveDocDate(r) || "–";
      return `
      <li class="receipt-row">
        <a href="/api/receipts/${r.id}/file" rel="noopener" class="receipt-link" data-view-doc-url="/api/receipts/${r.id}/file" data-view-doc-title="${escHtml(r.original_filename || "Beleg")}">
          <span class="receipt-date">${dateStr}</span>
          <span class="receipt-filename muted">${escHtml(r.original_filename || "Beleg")}${r.detected_amount ? ` · ${fmt(r.detected_amount)}` : ""}</span>
        </a>
        <a href="/api/receipts/${r.id}/file?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
        <button type="button" class="del-btn" data-delete-receipt="${r.id}" title="Löschen">🗑</button>
      </li>`;
    }).join("");
    wireDocumentViewerLinks(ul);
    ul.querySelectorAll("[data-delete-receipt]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Diesen Beleg wirklich löschen?")) return;
        await authedFetch(`/api/receipts/${btn.dataset.deleteReceipt}`, { method: "DELETE" });
        refreshReceiptsList(contractId, targetId);
        loadContracts();
      });
    });
  });
}

document.getElementById("receipts-list-close-btn").addEventListener("click", () => {
  receiptsListOverlay.style.display = "none";
});

// ---------- Ablesungen-Zeitreihe: kompakte Liste + Verlauf per Rechtsklick/Menü ----------
const readingsHistoryOverlay = document.getElementById("readings-history-overlay");
let readingsHistoryContext = null;
function openReadingsHistory(title, tableHtml, meterType, containerId) {
  readingsHistoryContext = { meterType, containerId, title };
  document.getElementById("readings-history-title").textContent = title;
  document.getElementById("readings-history-content").innerHTML = tableHtml;
  readingsHistoryOverlay.style.display = "flex";
}
document.getElementById("readings-history-close-btn").addEventListener("click", () => {
  readingsHistoryOverlay.style.display = "none";
});
// Event-Delegation statt direkter Bindung: der Inhalt wird bei jedem
// Öffnen komplett neu gesetzt (siehe openReadingsHistory), eine direkte
// Bindung würde also bei jedem erneuten Öffnen ins Leere laufen.
document.getElementById("readings-history-content").addEventListener("click", async (e) => {
  if (!readingsHistoryContext) return;
  const { meterType, containerId, title } = readingsHistoryContext;
  const readingBtn = e.target.closest("[data-delete-reading]");
  if (readingBtn) {
    if (!confirm("Diese Ablesung wirklich löschen?")) return;
    await authedFetch(`/api/meters/${meterType}/readings/${readingBtn.dataset.deleteReading}`, { method: "DELETE" });
    readingsHistoryOverlay.style.display = "none";
    loadMeterPage(meterType, containerId, title);
    return;
  }
  const pvBtn = e.target.closest("[data-delete-pv]");
  if (pvBtn) {
    if (!confirm(`PV-Daten für ${pvBtn.dataset.deletePv} wirklich löschen?`)) return;
    await authedFetch(`/api/pv/monthly/${pvBtn.dataset.deletePv}`, { method: "DELETE" });
    readingsHistoryOverlay.style.display = "none";
    loadMeterPage(meterType, containerId, title);
  }
});

// ---------- Archiv: archivierte Verträge durchsuchen, ohne ins Dateisystem zu wechseln ----------
document.getElementById("open-archive-btn").addEventListener("click", async () => {
  const title = document.getElementById("receipts-list-title");
  const content = document.getElementById("receipts-list-content");
  title.textContent = "🗂 Archiv";
  content.innerHTML = '<p class="muted">Lade …</p>';
  receiptsListOverlay.style.display = "flex";

  const archived = await (await authedFetch("/api/archive")).json();
  if (!archived.length) {
    content.innerHTML = '<p class="muted">Noch keine archivierten Verträge — rechtsklick auf einen Vertrag → Archivieren.</p>';
    return;
  }
  content.innerHTML = `<div id="archive-list-scroll"></div>`;
  setupScrollableDocList("archive-list-scroll", archived, (c) => c.updated_at, (filtered, ul) => {
    ul.innerHTML = filtered.map((c) => `
        <li>
          <button type="button" data-archived-contract="${c.id}" data-archived-label="${escHtml(c.label)}"
                  style="background:none;border:none;color:var(--text);cursor:pointer;text-align:left;padding:0;font-size:0.9rem;flex:1;min-width:0">
            ${c.category_name ? `${escHtml(c.category_name)}${c.subcategory ? " · " + escHtml(c.subcategory) : ""} — ` : ""}${escHtml(c.provider || c.label)}
            <div class="muted" style="font-size:0.72rem">${c.receipt_count} Beleg(e)${c.updated_at ? " · archiviert " + c.updated_at.slice(0, 10) : ""}</div>
          </button>
          <button type="button" class="ghost-btn" style="width:auto;padding:6px 10px;font-size:0.75rem" data-restore-contract="${c.id}">↩️ Wiederherstellen</button>
        </li>
      `).join("");
    ul.querySelectorAll("[data-archived-contract]").forEach((btn) => {
      btn.addEventListener("click", () => {
        showReceiptsList(btn.dataset.archivedContract, btn.dataset.archivedLabel);
      });
    });
  });
  content.querySelectorAll("[data-restore-contract]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diesen Vertrag wiederherstellen? Er erscheint danach wieder in der aktiven Liste.")) return;
      const res = await authedFetch(`/api/contracts/${btn.dataset.restoreContract}/restore`, { method: "POST" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        return alert(err.detail || "Fehler beim Wiederherstellen.");
      }
      document.getElementById("open-archive-btn").click();
      loadContracts();
      loadDashboard();
    });
  });
});

// ---------- Fälligkeitsdatum <-> "Unbefristet"-Checkbox: garantiert gegenseitig exklusiv ----------
// Native <input type="date"> zeigen leer manchmal das heutige Datum blass als Platzhalter an —
// das sah wie ein gesetzter Wert aus, obwohl keiner da war. Deshalb wird das Feld bei
// "Unbefristet" komplett ausgeblendet statt nur deaktiviert, das ist eindeutig.
function wireEndDateToggle(dateId, checkboxId) {
  const dateInput = document.getElementById(dateId);
  const checkbox = document.getElementById(checkboxId);

  function apply(unbefristet) {
    checkbox.checked = unbefristet;
    dateInput.style.display = unbefristet ? "none" : "block";
    dateInput.disabled = unbefristet;
    if (unbefristet) dateInput.value = "";
  }

  checkbox.addEventListener("change", () => apply(checkbox.checked));
  // Datum eingetragen -> "Unbefristet" automatisch abwählen (andere Richtung der Exklusivität)
  dateInput.addEventListener("input", () => {
    if (dateInput.value) apply(false);
  });

  return { setInitial: (hasDate) => apply(!hasDate) };
}

const detailsEndDateToggle = wireEndDateToggle("details-contract-end", "details-no-enddate");
const expenseEndDateToggle = wireEndDateToggle("expense-contract-end", "expense-no-enddate");

// ---------- Details-Formular ----------
const detailsOverlay = document.getElementById("details-overlay");

let allFamilyMembers = [];
let allInsuranceTypes = [];

function personOptionsHTML(selectedId) {
  return `<option value="">– haushaltsweit –</option>` + allFamilyMembers.map((m) =>
    `<option value="${m.id}" ${String(m.id) === String(selectedId) ? "selected" : ""}>${escHtml(m.name)}</option>`
  ).join("");
}

function insuranceTypeOptionsHTML(selected) {
  return allInsuranceTypes.map((t) =>
    `<option value="${escHtml(t)}" ${t === selected ? "selected" : ""}>${escHtml(t)}</option>`
  ).join("");
}

function updateDetailsConditionalFields() {
  const { category, subcategory } = parseCategoryValue(document.getElementById("details-category").value);
  const isFinanzierung = category === "Haus" && subcategory === "Finanzierung";
  const isVersicherung = category === "Versicherungen";
  document.getElementById("details-interest-rate-group").style.display = isFinanzierung ? "block" : "none";
  document.getElementById("details-insurance-type-group").style.display = isVersicherung ? "block" : "none";

  const insType = document.getElementById("details-insurance-type").value;
  document.getElementById("details-insurance-life-group").style.display =
    (isVersicherung && insType === "Risikolebensversicherung") ? "block" : "none";
  document.getElementById("details-bu-group").style.display =
    (isVersicherung && insType === "Berufsunfähigkeitsversicherung") ? "block" : "none";
}

document.getElementById("details-category").addEventListener("change", updateDetailsConditionalFields);
document.getElementById("details-insurance-type").addEventListener("change", updateDetailsConditionalFields);

function updateDetailsLabelDerivedHint() {
  const category = parseCategoryValue(document.getElementById("details-category").value).category;
  const provider = document.getElementById("details-provider").value.trim() || null;
  const contractNumber = document.getElementById("details-contract-number").value.trim() || null;
  const insuranceType = document.getElementById("details-insurance-type").value || null;
  const personSelect = document.getElementById("details-person");
  const personName = personSelect.value
    ? allFamilyMembers.find((m) => String(m.id) === personSelect.value)?.name
    : null;

  const hasManualLabel = document.getElementById("details-label").value.trim() !== "";
  const hint = document.getElementById("details-label-derived-hint");
  if (hasManualLabel) {
    hint.style.display = "none";
    return;
  }
  let preview;
  if (category === "Versicherungen") {
    preview = [personName ? `${personName}:` : "", provider || "", insuranceType || "Versicherung"].filter(Boolean).join(" ");
  } else {
    preview = [provider || "Vertrag", contractNumber || ""].filter(Boolean).join(" ");
  }
  document.getElementById("details-label-derived-preview").textContent = preview;
  hint.style.display = "block";
}

["details-category", "details-provider", "details-contract-number", "details-insurance-type", "details-person"].forEach((id) => {
  document.getElementById(id).addEventListener("input", updateDetailsLabelDerivedHint);
  document.getElementById(id).addEventListener("change", updateDetailsLabelDerivedHint);
});
document.getElementById("details-label").addEventListener("input", updateDetailsLabelDerivedHint);

document.getElementById("details-label-clear-btn").addEventListener("click", () => {
  document.getElementById("details-label").value = "";
  updateDetailsLabelDerivedHint();
});

document.getElementById("details-show-receipts-btn").addEventListener("click", async () => {
  const section = document.getElementById("details-receipts-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) {
    section.style.display = "none";
    return;
  }
  const contractId = document.getElementById("details-form").dataset.contractId;
  section.style.display = "block";
  section.innerHTML = '<p class="muted">Lade …</p>';
  await refreshReceiptsList(contractId, "details-receipts-section");
});

// ---------- Tilgungsplan (Restschuld-Verlauf + kumulierte Zinsen) ----------
// ---------- Gemeinsamer, wiederverwendbarer Mehrlinien-Chart mit
// klickbarer Legende (Linie ein-/ausblenden) und Hover-Tooltips (Wert +
// Bezeichnung) — von allen Verlaufs-Charts der App genutzt, damit sich
// diese Interaktion nicht mehrfach unterschiedlich verhält. ----------
let chartInstanceCounter = 0;

// Wandelt eine Punktfolge in einen sanft geglätteten SVG-Pfad um (Catmull-Rom
// zu kubischen Bezier-Kurven) statt scharfer Eckpunkte zwischen geraden
// Liniensegmenten — der Hauptunterschied zwischen "Excel-Diagramm" und
// modernem Look.
function smoothLinePath(pts) {
  if (pts.length < 2) return "";
  if (pts.length === 2) return `M ${pts[0][0]} ${pts[0][1]} L ${pts[1][0]} ${pts[1][1]}`;
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i === 0 ? 0 : i - 1];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2 < pts.length ? i + 2 : i + 1];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2[0]} ${p2[1]}`;
  }
  return d;
}

function renderInteractiveMultiLineChart(container, points, series, opts = {}) {
  const W = opts.width || 700, H = opts.height || 260;
  const padL = opts.padL || 60, padR = opts.padR || 10, padT = opts.padT || 15, padB = opts.padB || 30;
  const chartW = W - padL - padR, chartH = H - padT - padB;
  const yFormat = opts.yFormat || fmt;
  const xLabel = opts.xLabel || ((p) => String(p.year ?? ""));
  const instanceId = `chart${++chartInstanceCounter}`;

  const maxVal = Math.max(...points.flatMap((p) => series.map((s) => p[s.key] || 0))) * 1.05 || 1;
  const x = (i) => padL + (i / (points.length - 1 || 1)) * chartW;
  const y = (v) => padT + chartH - ((v || 0) / maxVal) * chartH;
  const seriesPoints = (key) => points.map((p, i) => [x(i), y(p[key])]);
  const linePath = (key) => smoothLinePath(seriesPoints(key));
  // Flaeche unter der Linie bis zur x-Achse, fuer den Gradient-Fuellungs-Effekt.
  const areaPath = (key) => `${linePath(key)} L ${x(points.length - 1)} ${padT + chartH} L ${x(0)} ${padT + chartH} Z`;

  // Nur ein paar dezente horizontale Gitterlinien statt eines Kastens —
  // wirkt deutlich weniger "Tabellenkalkulation".
  const gridLines = [0.33, 0.66, 1].map((f) =>
    `<line x1="${padL}" y1="${padT + chartH * (1 - f)}" x2="${W - padR}" y2="${padT + chartH * (1 - f)}" stroke="rgba(255,255,255,0.06)" stroke-dasharray="2,4" />`
  ).join("");

  // Nur eine begrenzte Anzahl X-Achsen-Beschriftungen, sonst überlappen sie
  // bei langen Zeitreihen.
  const fitLabels = Math.max(2, Math.floor((W - padL - padR) / 70));   // ~70 Einheiten je Datum (YYYY-MM-DD)
  const labelEvery = Math.max(1, Math.ceil(points.length / Math.min(opts.maxXLabels || 8, fitLabels)));
  const xLabelsHtml = points.map((p, i) => {
    if (i !== 0 && i !== points.length - 1 && i % labelEvery !== 0) return "";
    // Mittlere Beschriftung nicht direkt neben der letzten (sonst überlappen sie am rechten Rand).
    if (i !== 0 && i !== points.length - 1 && (points.length - 1 - i) < labelEvery) return "";
    const anchor = i === 0 ? "start" : i === points.length - 1 ? "end" : "middle";
    return `<text x="${x(i)}" y="${H - 8}" text-anchor="${anchor}" font-size="10" fill="var(--muted)">${xLabel(p, i)}</text>`;
  }).join("");

  // Pro Punkt und Serie ein unsichtbarer, aber gut treffbarer Kreis mit
  // nativem Tooltip (Browser-eigenes <title>) — zeigt Bezeichnung + Wert
  // beim Hovern, ganz ohne eigenes Tooltip-Positionierungs-JS.
  const dotsHtml = series.map((s) => points.map((p, i) => `
      <circle cx="${x(i)}" cy="${y(p[s.key])}" r="7" fill="transparent" data-series-dot="${s.key}">
        <title>${xLabel(p, i)} — ${escHtml(s.label)}: ${yFormat(p[s.key] || 0)}</title>
      </circle>`).join("")).join("");

  const gradientDefs = series.map((s) => `
    <linearGradient id="${instanceId}-grad-${s.key}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${s.color}" stop-opacity="0.14" />
      <stop offset="100%" stop-color="${s.color}" stop-opacity="0" />
    </linearGradient>`).join("");

  container.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block" id="${instanceId}">
      <defs>${gradientDefs}</defs>
      ${gridLines}
      <line x1="${padL}" y1="${padT + chartH}" x2="${W - padR}" y2="${padT + chartH}" stroke="rgba(255,255,255,0.15)" />
      <text x="${padL}" y="12" font-size="10" fill="var(--muted)">${yFormat(maxVal).replace(/,\d+/, "")}</text>
      ${series.map((s) => s.fill === false ? "" : `<path data-series-area="${s.key}" d="${areaPath(s.key)}" fill="url(#${instanceId}-grad-${s.key})" stroke="none" />`).join("")}
      ${series.map((s) => `<path data-series-line="${s.key}" d="${linePath(s.key)}" fill="none" stroke="${s.color}" stroke-width="${s.width || 2}" stroke-linecap="round" stroke-linejoin="round" ${s.dashed ? 'stroke-dasharray="4,3"' : ""} />`).join("")}
      ${dotsHtml}
      ${xLabelsHtml}
    </svg>
    <div class="row-actions" style="justify-content:center;gap:14px;font-size:0.72rem;margin-top:4px;flex-wrap:wrap">
      ${series.map((s) => `<span data-legend-toggle="${s.key}" style="cursor:pointer;user-select:none"><span style="color:${s.color}">●</span> ${escHtml(s.label)}</span>`).join("")}
    </div>`;

  const svg = container.querySelector(`#${instanceId}`);
  container.querySelectorAll("[data-legend-toggle]").forEach((legendItem) => {
    legendItem.addEventListener("click", () => {
      const key = legendItem.dataset.legendToggle;
      const line = svg.querySelector(`[data-series-line="${key}"]`);
      const area = svg.querySelector(`[data-series-area="${key}"]`);
      const hidden = line.style.display === "none";
      line.style.display = hidden ? "" : "none";
      if (area) area.style.display = hidden ? "" : "none";
      svg.querySelectorAll(`[data-series-dot="${key}"]`).forEach((dot) => { dot.style.display = hidden ? "" : "none"; });
      legendItem.style.opacity = hidden ? "1" : "0.35";
      legendItem.style.textDecoration = hidden ? "none" : "line-through";
    });
  });
}

function renderRepaymentChart(containerId, data) {
  const el = document.getElementById(containerId);
  if (data.error) {
    el.innerHTML = `<p class="muted" style="font-size:0.8rem">${escHtml(data.error)}</p>`;
    return;
  }
  const pts = data.schedule;
  if (pts.length < 2) {
    el.innerHTML = '<p class="muted" style="font-size:0.8rem">Zu wenig Daten für einen Verlauf.</p>';
    return;
  }

  el.innerHTML = `
    <p class="muted" style="font-size:0.78rem;margin:0 0 8px">
      ${fmtEur0(data.remaining_debt)} Restschuld bei ${data.interest_rate}% · ${fmtEur0(data.monthly_payment)}/Mo
      → abbezahlt <b>${data.payoff_year}</b> (${data.years_to_payoff} Jahre), dabei ${fmtEur0(data.total_interest)} Zinsen.
    </p>
    <div id="${containerId}-chart-inner"></div>`;

  const cp1 = chartPalette();
  renderInteractiveMultiLineChart(
    document.getElementById(`${containerId}-chart-inner`),
    pts,
    [
      { key: "remaining_debt", label: "Restschuld", color: cp1.orange, width: 2.5 },
      { key: "interest_paid_cumulative", label: "Gezahlte Zinsen (kumuliert)", color: cp1.purple, width: 2, dashed: true, fill: false },
    ],
    { height: 190, yFormat: fmtEur0, xLabel: (p) => p.year }
  );
}

async function loadRepaymentSchedule(contractId) {
  const section = document.getElementById("details-repayment-section");
  const chart = document.getElementById("details-repayment-chart");
  section.style.display = "block";
  chart.innerHTML = '<p class="muted">Lade …</p>';
  const res = await authedFetch(`/api/contracts/${contractId}/repayment-schedule`);
  if (!res.ok) {
    chart.innerHTML = '<p class="muted" style="font-size:0.8rem">Tilgungsplan konnte nicht geladen werden.</p>';
    return;
  }
  renderRepaymentChart("details-repayment-chart", await res.json());
}

async function openDetailsModal(contractId) {
  const c = allContracts.find((x) => String(x.id) === String(contractId));
  if (!c) return;
  if (allCategories.length === 0) {
    allCategories = await (await authedFetch("/api/categories")).json();
  }
  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  if (allInsuranceTypes.length === 0) {
    allInsuranceTypes = await (await authedFetch("/api/insurance-types")).json();
  }
  const catSelect = document.getElementById("details-category");
  catSelect.innerHTML = categoryOptionsHTML();
  catSelect.value = categoryValueFor(c.category_name, c.subcategory);

  document.getElementById("details-person").innerHTML = personOptionsHTML(c.person_id);
  document.getElementById("details-insurance-type").innerHTML = insuranceTypeOptionsHTML(c.insurance_type);
  document.getElementById("details-interest-rate").value = c.interest_rate ?? "";
  document.getElementById("details-remaining-debt").value = c.remaining_debt != null ? formatAmountForInput(c.remaining_debt) : "";
  document.getElementById("details-repayment-rate").value = c.repayment_rate ?? "";
  document.getElementById("details-fixed-interest-until").value = c.fixed_interest_until || "";
  document.getElementById("details-insurance-expiry").value = c.insurance_expiry || "";
  document.getElementById("details-insurance-sum").value = c.insurance_sum != null ? formatAmountForInput(c.insurance_sum) : "";
  document.getElementById("details-insurance-sum-type").value = c.insurance_sum_type || "fix";
  document.getElementById("details-bu-pension").value = c.bu_monthly_pension ?? "";

  document.getElementById("details-form").dataset.contractId = contractId;
  // Nur den TATSÄCHLICH manuell gesetzten Namen ins Feld schreiben — bei
  // Ableitung ist c.label bereits der berechnete Anzeigename, den man sonst
  // fälschlich als "manuell gesetzt" ins Feld übernehmen würde.
  document.getElementById("details-label").value = c.label_is_manual ? c.label : "";
  document.getElementById("details-provider").value = c.provider || "";
  document.getElementById("details-contract-number").value = c.contract_number || "";
  document.getElementById("details-contract-end").value = c.contract_end || "";
  detailsEndDateToggle.setInitial(!!c.contract_end);
  document.getElementById("details-frequency").value = c.frequency || "monthly";
  document.getElementById("details-link").value = c.link || "";
  document.getElementById("details-updated-at").textContent = c.updated_at || "–";
  document.getElementById("details-receipts-section").style.display = "none";
  document.getElementById("details-payments-section").style.display = "none";
  // Tilgungsplan nur bei Finanzierungen mit hinterlegter Restschuld — sonst
  // gäbe es nichts zu rechnen und der Abschnitt bliebe leer.
  const isFinanzierung = c.category_name === "Haus" && c.subcategory === "Finanzierung";
  if (isFinanzierung && c.remaining_debt) {
    loadRepaymentSchedule(contractId);
  } else {
    document.getElementById("details-repayment-section").style.display = "none";
  }
  updateDetailsConditionalFields();
  updateDetailsLabelDerivedHint();
  detailsOverlay.style.display = "flex";
}

document.getElementById("details-cancel-btn").addEventListener("click", () => {
  detailsOverlay.style.display = "none";
});

document.getElementById("details-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const contractId = e.target.dataset.contractId;
  // Bewusst OHNE Rückfall auf den alten Namen: wird das Feld absichtlich
  // leer gelassen, soll das auch leer beim Server ankommen (= Ableitung
  // einschalten), nicht stillschweigend beim vorherigen Namen bleiben.
  const newLabel = document.getElementById("details-label").value.trim();
  const { category, subcategory } = parseCategoryValue(document.getElementById("details-category").value);
  const noEndDate = document.getElementById("details-no-enddate").checked;
  const num = (id) => {
    return parseGermanNumber(document.getElementById(id).value);
  };
  const personVal = document.getElementById("details-person").value;
  const payload = {
    label: newLabel,
    provider: document.getElementById("details-provider").value.trim() || null,
    category,
    subcategory,
    contract_number: document.getElementById("details-contract-number").value || null,
    contract_end: noEndDate ? null : (document.getElementById("details-contract-end").value || null),
    frequency: document.getElementById("details-frequency").value,
    link: document.getElementById("details-link").value || null,
    person_id: personVal ? parseInt(personVal, 10) : null,
    interest_rate: category === "Haus" && subcategory === "Finanzierung" ? num("details-interest-rate") : null,
    remaining_debt: category === "Haus" && subcategory === "Finanzierung" ? num("details-remaining-debt") : null,
    repayment_rate: category === "Haus" && subcategory === "Finanzierung" ? num("details-repayment-rate") : null,
    fixed_interest_until: category === "Haus" && subcategory === "Finanzierung" ? (document.getElementById("details-fixed-interest-until").value || null) : null,
    insurance_type: category === "Versicherungen" ? document.getElementById("details-insurance-type").value : null,
  };
  if (payload.insurance_type === "Risikolebensversicherung") {
    payload.insurance_expiry = document.getElementById("details-insurance-expiry").value || null;
    payload.insurance_sum = num("details-insurance-sum");
    payload.insurance_sum_type = document.getElementById("details-insurance-sum-type").value;
  } else if (payload.insurance_type === "Berufsunfähigkeitsversicherung") {
    payload.bu_monthly_pension = num("details-bu-pension");
  }

  await patchJSON(`/api/contracts/${contractId}`, payload);
  detailsOverlay.style.display = "none";
  loadContracts();
  loadDashboard();
  loadReview();
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
    if (document.getElementById("vermoegen-subtab-verbindlichkeiten").style.display !== "none") {
      loadVerbindlichkeiten();
    }
  }
});

// ---------- Noch zu kategorisieren ----------
async function loadReview() {
  if (allCategories.length === 0) {
    allCategories = await (await authedFetch("/api/categories")).json();
  }
  const res = await authedFetch("/api/contracts?needs_review=true");
  const items = await res.json();
  const section = document.getElementById("block-review");
  const list = document.getElementById("review-list");

  if (items.length === 0) {
    section.style.display = "none";
    return;
  }
  section.style.display = "block";

  const categoryOptions = categoryOptionsHTML();

  list.innerHTML = items.map((c) => `
    <li>
      <span>${escHtml(c.provider || c.label)} <span class="tag">${fmt(c.amount)}/${freqLabel(c.frequency)}</span></span>
      <span class="row-actions">
        <select data-recategorize="${c.id}">
          <option value="">Kategorie wählen …</option>
          ${categoryOptions}
        </select>
        <button class="del-btn" data-delete-review="${c.id}" title="Löschen">🗑</button>
      </span>
    </li>`).join("");

  list.querySelectorAll("[data-recategorize]").forEach((select) => {
    select.addEventListener("change", async () => {
      if (!select.value) return;
      const { category, subcategory } = parseCategoryValue(select.value);
      await patchJSON(`/api/contracts/${select.dataset.recategorize}`, { category, subcategory });
      loadReview();
      loadContracts();
      loadDashboard();
    });
  });

  list.querySelectorAll("[data-delete-review]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diese Position wirklich löschen?")) return;
      await authedFetch(`/api/contracts/${btn.dataset.deleteReview}`, { method: "DELETE" });
      loadReview();
      loadContracts();
      loadDashboard();
    });
  });
}

// ---------- Beleg-Upload ----------
document.getElementById("upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("receipt-input");
  const resultDiv = document.getElementById("upload-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst ein Foto auswählen.";
    return;
  }
  resultDiv.textContent = "Wird lokal erkannt …";
  const formData = new FormData();
  formData.append("file", input.files[0]);

  let res, data;
  try {
    res = await authedFetch("/api/receipts/upload", { method: "POST", body: formData });
    data = await res.json();
  } catch (err) {
    resultDiv.textContent = "Upload fehlgeschlagen: " + err.message;
    return;
  }
  if (!res.ok) {
    resultDiv.innerHTML = `<div class="healthcheck-item healthcheck-yellow">
      <p style="margin:0;font-size:0.85rem">${escHtml(data.detail || "Fehler beim Hochladen.")}</p>
    </div>`;
    input.value = "";
    return;
  }

  const d = data.detected;
  const attention = data.needs_attention || [];
  const engineLabel = d.ocr_engine === "vision" ? "macOS Vision (lokal)"
    : d.ocr_engine === "tesseract" ? "Tesseract (lokal)"
    : d.ocr_engine === "pdf-text" ? "PDF-Text (direkt)" : "keine Erkennung";

  const contractOptions = allContracts.map((c) => {
    const parts = [
      c.category_name ? (c.subcategory ? `${c.category_name} · ${c.subcategory}` : c.category_name) : "?",
      c.label,
      c.provider || null,
      c.contract_number || null,
    ].filter(Boolean);
    return `<option value="${c.id}">${escHtml(parts.join(" — "))}</option>`;
  }).join("");

  const flag = (name) => (attention.includes(name) ? ' class="needs-attention"' : "");
  const periodText = d.period_start && d.period_end ? `Zeitraum: ${d.period_start} – ${d.period_end}` : "";

  resultDiv.innerHTML = `
    <p class="muted" style="margin:8px 0 4px">Erkennung: ${engineLabel}${d.ocr_error ? " – " + escHtml(d.ocr_error) : ""}</p>
    ${periodText ? `<p class="muted" style="margin:0 0 8px;font-size:0.75rem">${periodText}</p>` : ""}

    <label class="muted" style="font-size:0.8rem">Betrag (€)</label>
    <input type="text" id="confirm-amount"${flag("Betrag")} value="${d.amount != null ? formatAmountForInput(d.amount) : ""}" placeholder="z.B. 34,90" />

    <label class="muted" style="font-size:0.8rem">Anbieter</label>
    <input type="text" id="confirm-provider" value="${escHtml(d.provider ?? "")}" placeholder="z.B. octopus energy" />

    <label class="muted" style="font-size:0.8rem">Vertragsnummer</label>
    <input type="text" id="confirm-contract-number" value="${escHtml(d.contract_number ?? "")}" placeholder="z.B. K-123456" />

    <label class="muted" style="font-size:0.8rem">Homepage / Link</label>
    <input type="text" id="confirm-website" value="${escHtml(d.website ?? "")}" placeholder="https://…" />

    <label class="muted" style="font-size:0.8rem">Zu welchem Vertrag gehört das? *</label>
    ${allContracts.length === 0
      ? `<p class="muted" style="margin:4px 0 8px;font-size:0.78rem">Noch keine Verträge angelegt — bitte zuerst einen Vertrag anlegen, dann kann dieser Beleg zugeordnet werden.</p>`
      : `<select id="confirm-contract"${flag("Zuordnung zu einem Vertrag")}>
      <option value="" disabled selected>– bitte auswählen –</option>
      ${contractOptions}
    </select>`}
    ${data.matched_contract ? `<p class="muted" style="margin:4px 0 0;font-size:0.75rem">✅ automatisch zugeordnet (${data.matched_contract.confidence === "vertragsnummer" ? "Vertragsnummer" : "Anbieter"})</p>` : ""}

    <label class="checkbox-label">
      <input type="checkbox" id="confirm-update-expense" checked />
      <span>Ausgabe/Vertragsbetrag aktualisieren (bei reinen Mitteilungen ohne Rechnungsbetrag abwählen)</span>
    </label>

    <button id="confirm-receipt-btn" style="margin-top:10px"${allContracts.length === 0 ? " disabled" : ""}>Bestätigen &amp; übernehmen</button>
  `;

  if (data.matched_contract) {
    document.getElementById("confirm-contract").value = String(data.matched_contract.id);
  }

  const applyContractDataToForm = (contractId) => {
    const contract = allContracts.find((c) => String(c.id) === String(contractId));
    if (!contract) return;
    // Anbieter/Vertragsnummer/Link sind Eigenschaften des Vertrags selbst
    // und ändern sich praktisch nie — hier gewinnt immer der bekannte
    // Vertragswert. Der Betrag dagegen ändert sich naturgemäß von Rechnung
    // zu Rechnung (neue Abrechnungsperiode) — ein bereits korrekt per OCR
    // erkannter neuer Betrag darf hier nie durch den alten Vertragswert
    // überschrieben werden, deshalb nur dort auffüllen, wenn das Feld noch leer ist.
    const amountEl = document.getElementById("confirm-amount");
    if (!amountEl.value) amountEl.value = contract.amount != null ? formatAmountForInput(contract.amount) : "";
    document.getElementById("confirm-provider").value = contract.provider || "";
    document.getElementById("confirm-contract-number").value = contract.contract_number || "";
    document.getElementById("confirm-website").value = contract.link || "";
  };
  const contractSelect = document.getElementById("confirm-contract");
  if (contractSelect) {
    contractSelect.addEventListener("change", () => applyContractDataToForm(contractSelect.value));
    if (data.matched_contract) applyContractDataToForm(data.matched_contract.id);
  }

  document.getElementById("confirm-receipt-btn").addEventListener("click", async () => {
    const contractSelectEl = document.getElementById("confirm-contract");
    if (!contractSelectEl || !contractSelectEl.value) {
      if (contractSelectEl) contractSelectEl.classList.add("needs-attention");
      alert("Bitte einen Vertrag zuordnen — eine Ausgabe ohne Zuordnung kann nicht übernommen werden.");
      return;
    }

    const amount = parseGermanNumber(document.getElementById("confirm-amount").value);
    const provider = document.getElementById("confirm-provider").value || null;
    const contract_number = document.getElementById("confirm-contract-number").value || null;
    const link = document.getElementById("confirm-website").value || null;
    const contract_id = parseInt(contractSelectEl.value, 10);
    const update_expense = document.getElementById("confirm-update-expense").checked;

    const confirmRes = await authedFetch(`/api/receipts/${data.receipt_id}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contract_id, amount, provider, contract_number, link, update_expense }),
    });
    if (confirmRes.ok) {
      resultDiv.innerHTML = "Übernommen ✅";
      input.value = "";
      loadContracts();
      loadDashboard();
    } else {
      const err = await confirmRes.json().catch(() => ({}));
      alert(err.detail || "Fehler beim Bestätigen.");
    }
  });
});

// ---------- Chatbot ----------
document.getElementById("chat-btn").addEventListener("click", async () => {
  const input = document.getElementById("chat-input");
  const log = document.getElementById("chat-log");
  const question = input.value.trim();
  if (!question) return;

  log.innerHTML += `<div class="q">Du: ${question}</div><div class="a">Denke nach …</div>`;
  log.scrollTop = log.scrollHeight;
  input.value = "";

  const res = await authedFetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question }),
  });
  const data = await res.json();
  log.lastElementChild.textContent = data.answer;
  log.scrollTop = log.scrollHeight;
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/service-worker.js").then((registration) => {
    // Eine als PWA installierte/im Dock liegende App bekommt neue Dateien
    // sonst oft erst nach einem vollständigen Beenden+Neustart zu sehen —
    // ein einfaches "in den Vordergrund holen" reicht bei einer PWA anders
    // als bei einem Browser-Tab meist NICHT für einen echten Reload. Daher
    // hier aktiv nachfragen, sobald die App wieder sichtbar wird, statt nur
    // auf die (bei ruhenden PWAs seltene) automatische Browser-Prüfung zu
    // warten.
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") registration.update();
    });

    navigator.serviceWorker.addEventListener("controllerchange", () => {
      // Ein offener, unbestätigter Dialog (z.B. mitten in einer Bearbeitung)
      // soll nicht durch einen automatischen Reload weggerissen werden —
      // dann lieber ein dezenter Hinweis, der beim Fertigwerden Zeit lässt.
      const openOverlay = [...document.querySelectorAll(".overlay")]
        .some((o) => getComputedStyle(o).display !== "none");
      if (openOverlay) {
        showUpdateAvailableBanner();
      } else {
        window.location.reload();
      }
    });
  });
}

function showUpdateAvailableBanner() {
  if (document.getElementById("update-available-banner")) return;
  const banner = document.createElement("div");
  banner.id = "update-available-banner";
  banner.style.cssText = `position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:var(--accent);color:${chartPalette().onColor};padding:10px 16px;border-radius:10px;font-size:0.85rem;font-weight:600;z-index:200;cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,0.3)`;
  banner.textContent = "🔄 Neue Version verfügbar — zum Aktualisieren klicken";
  banner.addEventListener("click", () => window.location.reload());
  document.body.appendChild(banner);
}

function applyUiScale() {
  // Bewusst NICHT vom Server geladen: die Textgröße ist eine reine
  // Geräte-Einstellung (z.B. am Mac "Groß", am iPhone "Klein") — ein
  // geräteübergreifend geteilter Wert würde die Wahl eines Geräts beim
  // nächsten Laden auf einem anderen Gerät überschreiben.
  const cached = localStorage.getItem("ui_scale");
  const scale = ["s", "m", "l"].includes(cached) ? cached : "m";
  document.documentElement.classList.remove("ui-scale-s", "ui-scale-m", "ui-scale-l");
  document.documentElement.classList.add(`ui-scale-${scale}`);
  document.querySelectorAll("#ui-scale-selector [data-ui-scale]").forEach((btn) => {
    btn.classList.toggle("active-scale", btn.dataset.uiScale === scale);
  });
  updateHeaderHeightVar();
}

document.querySelectorAll("#ui-scale-selector [data-ui-scale]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const scale = btn.dataset.uiScale;
    document.documentElement.classList.remove("ui-scale-s", "ui-scale-m", "ui-scale-l");
    document.documentElement.classList.add(`ui-scale-${scale}`);
    localStorage.setItem("ui_scale", scale);
    document.querySelectorAll("#ui-scale-selector [data-ui-scale]").forEach((b) => {
      b.classList.toggle("active-scale", b === btn);
    });
    updateHeaderHeightVar();
  });
});

function applyUiTheme(theme) {
  const valid = ["dark", "light", "apple", "nothing", "retro80s"];
  const t = valid.includes(theme) ? theme : "dark";
  document.documentElement.setAttribute("data-theme", t);
  localStorage.setItem("ui_theme", t);
  document.querySelectorAll("#ui-theme-selector [data-ui-theme]").forEach((btn) => {
    btn.classList.toggle("active-scale", btn.dataset.uiTheme === t);
  });
  const headerIcon = document.getElementById("app-header-icon");
  if (headerIcon) headerIcon.src = `/icons/icon-${t}.svg`;
  const touchIcon = document.getElementById("apple-touch-icon-link");
  if (touchIcon) touchIcon.href = `/icons/icon-${t}-180.png`;
  const favicon = document.getElementById("favicon-link");
  if (favicon) favicon.href = `/icons/icon-${t}.svg`;
}

async function syncUiThemeFromServer() {
  // Sofort das lokal zwischengespeicherte Theme anzeigen (kein Warten auf
  // das Netzwerk nötig, das <head>-Skript hat es ohnehin schon gesetzt),
  // danach mit dem geräteübergreifend gespeicherten Wert abgleichen — falls
  // auf einem anderen Gerät ein anderes Theme gewählt wurde.
  applyUiTheme(localStorage.getItem("ui_theme"));
  const res = await authedFetch("/api/settings/ui_theme");
  const { value } = await res.json();
  if (value) applyUiTheme(value);
}

document.querySelectorAll("#ui-theme-selector [data-ui-theme]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    applyUiTheme(btn.dataset.uiTheme);
    await authedFetch("/api/settings/ui_theme", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: btn.dataset.uiTheme }),
    });
    // Bereits gerenderte Charts nutzen sonst weiter die Farben des vorher
    // aktiven Themes, bis die jeweilige Seite das nächste Mal geladen wird
    // — hier die naheliegendsten, chart-lastigen Ansichten sofort neu
    // zeichnen, damit der Wechsel unmittelbar sichtbar wird.
    loadDashboard();
    if (document.getElementById("tab-vermoegen").style.display !== "none") loadVermoegenOverview();
    if (document.getElementById("tab-contracts").style.display !== "none") loadContracts();
  });
});

function bootApp() {
  loadDashboard();
  loadIncome();
  loadContracts();
  loadReview();
  applyDashboardOrder();
  setupDashboardDragReorder();
  applyBlockOrder("tab-contracts", "ausgaben_order").then(() => setupBlockDragReorder("tab-contracts", "ausgaben_order"));
  applyBlockOrder("tab-income", "einnahmen_order").then(() => setupBlockDragReorder("tab-income", "einnahmen_order"));
  applyBlockOrder("tab-energy-dashboard", "energy_dashboard_order").then(() => setupBlockDragReorder("tab-energy-dashboard", "energy_dashboard_order"));
  applyEnergyMonitorToggle();
  applyVorsorgeToggle();
  applyUiScale();
  syncUiThemeFromServer();
  applyDemoModeUi();
  loadBankInsights();
  checkAllUpdatesOnBoot();
}

// ═══════════════════════════════════════════════════════════════
// DEMO-MODUS: zeigt eine komplett separate, frei erfundene Datenbank
// (siehe backend/demo_data.py) statt der echten -- z.B. wenn jemand beim
// Vorführen der App mitschaut. Serverseitig steckt der Zustand im Session-
// Cookie (siehe auth.set_session_demo_flag); hier wird nur die Oberfläche
// (Banner, Umschalter, Knopf-Beschriftung) dem aktuellen Stand angepasst.
// ═══════════════════════════════════════════════════════════════

async function applyDemoModeUi() {
  const status = await (await authedFetch("/api/auth/status")).json();
  const active = !!status.demo_mode;
  document.getElementById("demo-mode-banner").style.display = active ? "block" : "none";
  document.getElementById("toggle-demo-mode").checked = active;
  document.getElementById("demo-mode-regenerate-btn").style.display = active ? "block" : "none";
  document.getElementById("demo-mode-quick-btn").classList.toggle("demo-active", active);
  document.getElementById("demo-mode-quick-btn").title = active ? "Demo-Modus beenden" : "Demo-Modus starten";
}

async function setDemoMode(enabled) {
  if (enabled && !confirm(
    "Demo-Modus zeigt ab jetzt frei erfundene Beispieldaten (Familie Mustermann) statt deiner echten Daten. " +
    "Deine echten Daten bleiben dabei unverändert und unberührt. Jetzt starten?")) {
    document.getElementById("toggle-demo-mode").checked = false;
    return;
  }
  await authedFetch("/api/demo-mode", {
    method: "PUT", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ enabled }),
  });
  // Volles Neuladen statt Teil-Refresh: an sehr vielen Stellen im Code hält
  // die Seite bereits geladene Werte in JS-Variablen (Charts, Kacheln,
  // Formulare) -- ein Neuladen ist die einzige Art, garantiert überall die
  // neue (oder wieder die echte) Datenbank widerzuspiegeln, ohne Gefahr,
  // dass irgendwo noch eine alte Zahl stehen bleibt.
  location.reload();
}

document.getElementById("toggle-demo-mode").addEventListener("change", (e) => setDemoMode(e.target.checked));
document.getElementById("demo-mode-quick-btn").addEventListener("click", () => {
  setDemoMode(!document.getElementById("demo-mode-quick-btn").classList.contains("demo-active"));
});
document.getElementById("demo-mode-banner-off-btn").addEventListener("click", () => setDemoMode(false));
document.getElementById("demo-mode-regenerate-btn").addEventListener("click", async () => {
  if (!confirm("Demo-Daten neu erzeugen? Alle Änderungen, die im Demo-Modus gemacht wurden, gehen dabei verloren.")) return;
  await authedFetch("/api/demo-mode/regenerate", { method: "POST" });
  location.reload();
});

// ═══════════════════════════════════════════════════════════════
// ENERGY MONITOR
// ═══════════════════════════════════════════════════════════════

async function applyEnergyMonitorToggle() {
  const res = await authedFetch("/api/settings/energy_monitor_enabled");
  const { value } = await res.json();
  const enabled = !!value;
  const display = enabled ? "flex" : "none";
  document.getElementById("energy-section-title").style.display = enabled ? "flex" : "none";
  ["nav-energy-dashboard", "nav-energy-gas", "energy-strom-subtitle", "nav-energy-verbrauch", "nav-energy-produktion", "nav-energy-water"].forEach((id) => {
    document.getElementById(id).style.display = display;
  });
  // Falls das Modul gerade deaktiviert wurde, während eine Energy-Seite
  // offen war: zurück zum Finanz-Dashboard, statt eine unsichtbar
  // gewordene Seite anzuzeigen.
  const activeEnergyPanel = ["tab-energy-dashboard", "tab-energy-gas", "tab-energy-verbrauch", "tab-energy-produktion", "tab-energy-water"]
    .find((id) => document.getElementById(id).style.display !== "none");
  if (!enabled && activeEnergyPanel) {
    document.querySelector('.sidebar-btn[data-tab="tab-dashboard"]').click();
  }
}

async function applyVorsorgeToggle() {
  const res = await authedFetch("/api/settings/vorsorge_enabled");
  const { value } = await res.json();
  const enabled = !!value;
  const display = enabled ? "flex" : "none";
  document.getElementById("vorsorge-section-title").style.display = display;
  ["nav-vorsorge-dashboard", "nav-vorsorge-aufbau", "nav-vorsorge-absicherung"].forEach((id) => {
    document.getElementById(id).style.display = display;
  });
  // Wie beim Energy Monitor: bei Deaktivierung während offener Ansicht
  // zurück zum Finanz-Dashboard, statt eine unsichtbar gewordene Seite zu zeigen.
  const activeVorsorgePanel = ["tab-vorsorge-dashboard", "tab-vorsorge-aufbau", "tab-vorsorge-absicherung"]
    .find((id) => document.getElementById(id).style.display !== "none");
  if (!enabled && activeVorsorgePanel) {
    document.querySelector('.sidebar-btn[data-tab="tab-dashboard"]').click();
  }
}

function fmtUnit(value, unit) {
  if (value == null) return "–";
  return `${value.toLocaleString("de-DE", { maximumFractionDigits: 1 })} ${unit}`;
}

// ---------- Energy Monitor: Übersicht ----------
// ---------- Energy Monitor: Zeitraum-Filter (1 Mo / 3 Mo / YTD / Gesamt) ----------
let energyRange = "ytd";

function fmtDE0(v) { return Math.round(v).toLocaleString("de-DE"); }
function fmtDE1(v) { return v.toLocaleString("de-DE", { minimumFractionDigits: 1, maximumFractionDigits: 1 }); }
function fmtDE2(v) { return v.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

async function initEnergyRangeSelector() {
  const el = document.getElementById("energy-range-sel");
  const ranges = CHART_RANGES;
  el.innerHTML = ranges.map((r) =>
    `<button class="range-btn${r.id === energyRange ? " active" : ""}" data-range="${r.id}">${escHtml(r.label)}</button>`
  ).join("");
  el.querySelectorAll(".range-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      energyRange = btn.dataset.range;
      el.querySelectorAll(".range-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      loadEnergyCards();
      loadEnergyTrend();
      loadEnergyCostPie();
    });
  });
}

async function loadEnergyOverview() {
  await initEnergyRangeSelector();
  await loadEnergyCards();
  await loadEnergyTrend();
  await loadEnergyCostPie();
  await loadEnergySettlement();
}

async function loadEnergyCards() {
  const container = document.getElementById("energy-overview-cards");
  const res = await authedFetch(`/api/energy/overview?range=${energyRange}`);
  const d = await res.json();

  const noData = d.gas.daily_rate == null && d.elec_in.daily_rate == null && d.elec_out.daily_rate == null && d.pv.months === 0 && !d.water.has_data;
  if (noData) {
    container.innerHTML = '<p class="muted">Noch keine Zählerstände erfasst — auf den Seiten Gas/Strom die erste Ablesung eintragen.</p>';
    return;
  }

  const cards = [
    { cls: "gas", icon: "🔥", name: `Gas · ${d.gas.anbieter}`, val: `${fmtDE1(d.gas.kwh)} kWh`,
      unit: `${fmtDE1(d.gas.m3)} m<sup>3</sup> · ${fmtDE2(d.gas.kosten)} €`,
      sub: d.gas.daily_rate != null ? `${d.gas.daily_rate.toLocaleString("de-DE")} m<sup>3</sup>/Tag aktuell` : "" },
    { cls: "elec", icon: "⚡", name: `Bezug · ${d.elec_in.anbieter}`, val: `${fmtDE0(d.elec_in.kwh)} kWh`,
      unit: `${fmtDE2(d.elec_in.kosten)} € Kosten`,
      sub: d.elec_in.daily_rate != null ? `${d.elec_in.daily_rate.toFixed(1)} kWh/Tag aktuell` : "" },
    { cls: "feed", icon: "↑", name: `Einspeisung · ${d.elec_out.anbieter}`, val: `${fmtDE0(d.elec_out.kwh)} kWh`,
      unit: `${fmtDE2(d.elec_out.erloes)} € Erlös`,
      sub: d.elec_out.daily_rate != null ? `${d.elec_out.daily_rate.toFixed(1)} kWh/Tag aktuell` : (d.elec_out.source === "pv" ? "iSolarCloud-Daten" : "") },
  ];
  // Wasser nur anzeigen, sobald tatsächlich Ablesungen erfasst sind — sonst
  // würde eine leere/nullige Karte nur verwirren, bevor der Nutzer die
  // Wasser-Seite überhaupt zum ersten Mal befüllt hat.
  if (d.water.has_data) {
    cards.push({ cls: "water", icon: "💧", name: `Wasser${d.water.anbieter ? ` · ${d.water.anbieter}` : ""}`, val: `${fmtDE1(d.water.m3)} m³`,
      unit: `${fmtDE2(d.water.kosten)} € Kosten`,
      sub: d.water.daily_rate != null ? `${d.water.daily_rate.toFixed(2)} m³/Tag aktuell` : "" });
  }

  container.innerHTML = `
    <div class="overview-grid">
      ${cards.map((c) => `
        <div class="ov-card ${c.cls}">
          <div class="ov-icon">${c.icon}</div>
          <div class="ov-name">${escHtml(c.name)}</div>
          <div class="ov-val">${c.val}</div>
          <div class="ov-sub" style="margin-top:2px">${c.unit}</div>
          <div class="ov-sub" style="margin-top:6px">${c.sub}</div>
        </div>
      `).join("")}
    </div>`;
}

// ---------- Kostentrend: SVG-Balken (gemessen/Prognose) + Linie (Gesamt) ----------
async function loadEnergyCostPie() {
  const container = document.getElementById("energy-cost-pie-chart");
  const res = await authedFetch(`/api/energy/overview?range=${energyRange}`);
  const d = await res.json();

  // Netto-Stromkosten (Bezug minus Einspeisungserlös), wie im Kostentrend
  // schon gehandhabt — negative Werte (Erlös übersteigt Bezugskosten)
  // würden im Pie-Chart keinen Sinn ergeben, daher bei 0 gedeckelt.
  const netElec = Math.max(d.elec_in.kosten - d.elec_out.erloes, 0);
  const slices = [
    { category: "Gas", monthly_amount: d.gas.kosten },
    { category: "Strom (netto)", monthly_amount: netElec },
  ];
  if (d.water.has_data) {
    slices.push({ category: "Wasser", monthly_amount: d.water.kosten });
  }
  const total = slices.reduce((s, c) => s + c.monthly_amount, 0);
  if (total <= 0) {
    container.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Kosten im gewählten Zeitraum.</p>';
    return;
  }
  renderPieChart(slices, "energy-cost-pie-chart");
}

async function loadEnergyTrend() {
  const container = document.getElementById("energy-trend-chart");
  const res = await authedFetch(`/api/energy/cost-trend?range=${energyRange}`);
  const { months } = await res.json();
  if (!months.length) {
    container.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Ablesungen für einen Kostentrend.</p>';
    return;
  }

  const W = 720, H = 260, padL = 40, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const hasWater = months.some((m) => m.water_measured > 0 || m.water_forecast > 0);
  const subtitleEl = document.getElementById("energy-trend-subtitle");
  if (subtitleEl) subtitleEl.textContent = hasWater ? "Gas + Strom netto + Wasser · monatlich" : "Gas + Strom netto · monatlich";
  const maxVal = Math.max(...months.map((m) => m.gas_measured + m.gas_forecast + m.elec_measured + m.elec_forecast + m.water_measured + m.water_forecast), 1);
  const minVal = Math.min(0, ...months.map((m) => m.total));
  const range = maxVal - minVal || 1;
  const barW = chartW / months.length;
  const y0 = padT + chartH * (maxVal / range); // y-Position der 0-Linie

  const yScale = (v) => padT + chartH * ((maxVal - v) / range);
  const cp = chartPalette();

  const bars = months.map((m, i) => {
    const x = padL + i * barW + barW * 0.12;
    const w = barW * 0.76;
    let cum = 0;
    const seg = (val, color, label) => {
      if (!val) return "";
      const yTop = yScale(cum + val);
      const yBot = yScale(cum);
      cum += val;
      return `<rect x="${x}" y="${yTop}" width="${w}" height="${Math.max(yBot - yTop, 0)}" fill="${color}"><title>${monthLabel(m.key)} — ${label}: ${fmtDE0(val)} €</title></rect>`;
    };
    return seg(m.gas_measured, cp.purple, "Gas (gemessen)") + seg(m.gas_forecast, hexToRgba(cp.purple, 0.35), "Gas (Prognose)")
         + seg(m.elec_measured, cp.teal, "Strom netto (gemessen)") + seg(m.elec_forecast, hexToRgba(cp.teal, 0.35), "Strom netto (Prognose)")
         + seg(m.water_measured, cp.info, "Wasser (gemessen)") + seg(m.water_forecast, hexToRgba(cp.info, 0.35), "Wasser (Prognose)");
  }).join("");

  const linePoints = months.map((m, i) => {
    const x = padL + i * barW + barW / 2;
    const y = yScale(m.total);
    return `${x},${y}`;
  }).join(" ");

  const dots = months.map((m, i) => {
    const x = padL + i * barW + barW / 2;
    const y = yScale(m.total);
    return `<circle cx="${x}" cy="${y}" r="3" fill="${cp.orange}"><title>${monthLabel(m.key)} — Gesamt: ${fmtDE0(m.total)} €</title></circle>`;
  }).join("");

  const xLabels = months.map((m, i) => {
    const x = padL + i * barW + barW / 2;
    const [y, mo] = m.key.split("-");
    const monthNames = ["", "Jan", "Feb", "Mrz", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
    return `<text x="${x}" y="${H - 6}" text-anchor="middle" font-size="9" fill="var(--muted)">${monthNames[parseInt(mo, 10)]} '${y.slice(2)}</text>`;
  }).join("");

  const gridLines = [0, 0.25, 0.5, 0.75, 1].map((f) => {
    const val = minVal + range * f;
    const y = yScale(val);
    return `<line x1="${padL}" y1="${y}" x2="${W - 10}" y2="${y}" stroke="rgba(255,255,255,0.06)" />
            <text x="${padL - 6}" y="${y + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${Math.round(val).toLocaleString("de-DE")}€</text>`;
  }).join("");

  container.innerHTML = `
    <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:0.7rem;color:var(--muted);margin-bottom:8px">
      <span><span style="display:inline-block;width:8px;height:8px;background:${cp.purple};border-radius:2px;margin-right:4px"></span>Gas gemessen</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${hexToRgba(cp.purple, 0.35)};border-radius:2px;margin-right:4px"></span>Gas Prognose</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${cp.teal};border-radius:2px;margin-right:4px"></span>Strom gemessen</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${hexToRgba(cp.teal, 0.35)};border-radius:2px;margin-right:4px"></span>Strom Prognose</span>
      ${hasWater ? `
      <span><span style="display:inline-block;width:8px;height:8px;background:${cp.info};border-radius:2px;margin-right:4px"></span>Wasser gemessen</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${hexToRgba(cp.info, 0.35)};border-radius:2px;margin-right:4px"></span>Wasser Prognose</span>` : ""}
      <span><span style="display:inline-block;width:12px;height:2px;background:${cp.orange};margin-right:4px;vertical-align:middle"></span>Gesamt</span>
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block" role="img" aria-label="Kostentrend">
      ${gridLines}
      ${bars}
      <polyline points="${linePoints}" fill="none" stroke="${cp.orange}" stroke-width="2" />
      ${dots}
      ${xLabels}
    </svg>`;
}

// ---------- Jahresabrechnung ----------
async function loadEnergySettlement() {
  const container = document.getElementById("energy-settlement-content");
  const s = await (await authedFetch("/api/energy/settlement")).json();

  function settleRow(icon, label, sub, diff, note, settleLbl, daysUntil) {
    const cls = diff >= 0 ? "settle-ok" : "settle-red";
    return `<div class="settle-row">
      <div style="flex:1;min-width:0">
        <div class="settle-lbl">${icon} ${label}</div>
        <div class="settle-sub">${sub}</div>
        ${note ? `<div class="settle-sub">${note}</div>` : ""}
        <div class="settle-sub" style="font-style:italic">Abrechnung: ${settleLbl}${daysUntil != null ? ` (in ${daysUntil} Tagen)` : ""}</div>
      </div>
      <div class="settle-val ${cls}">${diff >= 0 ? "+" : ""}${Math.round(diff).toLocaleString("de-DE")} €</div>
    </div>`;
  }

  const fmtDate = (iso) => new Date(iso).toLocaleDateString("de-DE", { day: "numeric", month: "long", year: "numeric" });

  container.innerHTML = `
    <div class="settle-lbl" style="font-size:1rem;margin-bottom:8px">⚖️ Jahresabrechnung ${s.year}</div>

    ${settleRow("🔥", "Gas", `${fmtDE0(s.gas.abschlaege)} € gezahlt — ${fmtDE0(s.gas.jahr_kosten)} € progn. Jahreskosten`,
      s.gas.diff, "", fmtDate(s.gas.settle_date), s.gas.days_until_settle)}

    ${settleRow("⚡", "Strombezug", `${fmtDE0(s.elec_in.abschlaege)} € gezahlt — ${fmtDE0(s.elec_in.jahr_kosten)} € progn. Jahreskosten`,
      s.elec_in.diff, `${fmtDE0(s.elec_in.monthly_cost)} €/Mo tatsächl. Bezugskosten`, fmtDate(s.elec_in.settle_date), s.elec_in.days_until_settle)}

    ${s.water.has_data ? settleRow("💧", "Wasser", `${fmtDE0(s.water.abschlaege)} € gezahlt — ${fmtDE0(s.water.jahr_kosten)} € progn. Jahreskosten`,
      s.water.diff, "", fmtDate(s.water.settle_date), s.water.days_until_settle) : ""}

    <div class="settle-row" style="flex-direction:column;align-items:stretch;gap:8px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">
        <div style="flex:1;min-width:0">
          <div class="settle-lbl">☀️ Einspeisung</div>
          <div class="settle-sub">${fmtDE0(s.elec_out.bezahlt)} € erhalten (${s.elec_out.m_seit_januar}× ${fmtDE0(s.elec_out.abschlag)} €/Mo) — ${fmtDE0(s.elec_out.jahr_erloes)} € progn. Jahresvergütung</div>
          <div class="settle-sub" style="font-style:italic">Abrechnung: ${fmtDate(s.elec_out.settle_date)} (in ${s.elec_out.days_until_settle} Tagen)</div>
        </div>
        <div class="settle-val ${s.elec_out.diff >= 0 ? "settle-ok" : "settle-red"}">${s.elec_out.diff >= 0 ? "+" : ""}${Math.round(s.elec_out.diff).toLocaleString("de-DE")} €</div>
      </div>
      <div class="pv-breakdown-grid">
        <div>
          <div class="pv-bd-label">Gemessen (${s.elec_out.gemessene_monate} Mo.)</div>
          <div class="pv-bd-val" style="color:var(--good)">${fmtDE0(s.elec_out.bisher_kwh)} kWh</div>
          <div class="ov-sub">${fmtDE0(s.elec_out.erloes_bisher)} € Erlös bisher</div>
        </div>
        <div>
          <div class="pv-bd-label">Prognose (${s.elec_out.prognose_monate} Mo. · Vorjahr)</div>
          <div class="pv-bd-val" style="color:var(--warn)">${fmtDE0(s.elec_out.prognose_kwh)} kWh</div>
          <div class="ov-sub">${s.elec_out.laufender_monat_label || ""}</div>
        </div>
        <div>
          <div class="pv-bd-label">Jahresgesamt</div>
          <div class="pv-bd-val">${fmtDE0(s.elec_out.jahr_gesamt_kwh)} kWh</div>
          <div class="ov-sub">${fmtDE0(s.elec_out.jahres_abschlaege)} € erhalten vs. ${fmtDE0(s.elec_out.jahr_erloes)} € erwartet</div>
        </div>
      </div>
    </div>

    <div class="settle-row" style="border-top:1px solid rgba(255,255,255,0.12);padding-top:14px">
      <div>
        <div class="settle-lbl" style="font-size:1.05rem">Gesamt ${s.year}</div>
        <div class="settle-sub">Gas + Bezug${s.water.has_data ? " + Wasser" : ""} − Einspeisungserlös</div>
      </div>
      <div class="settle-val ${s.total_diff >= 0 ? "settle-ok" : "settle-red"}" style="font-size:1.4rem">${s.total_diff >= 0 ? "+" : ""}${Math.round(s.total_diff).toLocaleString("de-DE")} €</div>
    </div>`;
}


// ---------- Energy Monitor: Zähler-Detailseite (Gas / Strombezug / Einspeisung) ----------
// ---------- Zeitraum-Filterung (clientseitig, pro Chart unabhängig) ----------
const meterChartRange = {};

// Startdatum eines Zeitraums — spiegelt range_start_date() im Backend.
function rangeStartDate(rangeId) {
  if (rangeId === "all" || !rangeId) return null;
  const today = new Date();
  if (rangeId === "ytd") return new Date(today.getFullYear(), 0, 1);
  const monthsBack = { "1m": 1, "3m": 3, "12m": 12 }[rangeId];
  if (monthsBack === undefined) return null;
  return rangeId === "12m"
    ? new Date(today.getFullYear(), today.getMonth() - 12, 1)
    : new Date(today.getFullYear(), today.getMonth() - monthsBack, today.getDate());
}

// Versteht alle drei Schlüsselformate: Tag "2026-07-15", Woche "2026-W29",
// Monat "2026-07" — damit greift dieselbe Funktion unabhängig davon, wie fein
// der jeweilige Chart gerade aufgelöst ist.
function filterPeriodKeysByRange(keys, rangeId) {
  if (rangeId === "all" || !rangeId) return keys.slice().sort();
  const cutoff = rangeStartDate(rangeId);
  if (!cutoff) return keys.slice().sort();
  const today = new Date();
  return keys.filter((k) => {
    const parts = k.split("-").map(Number);
    if (parts.length >= 3) {
      // Echter Tages-Schlüssel "YYYY-MM-DD" -- taggenauer Vergleich statt
      // (wie zuvor) nur die Monatsgrenze zu prüfen, die bei "1 Mo" sonst
      // fälschlich den kompletten Monat statt der letzten 30 Tage einschließen würde.
      const [y, m, d] = parts;
      const day = new Date(y, m - 1, d);
      return day >= cutoff && day <= today;
    }
    const [y, m] = parts;
    const monthStart = new Date(y, m - 1, 1);
    // Der ganze Monat zählt, wenn sein ENDE nach dem Stichtag liegt — sonst
    // fiele z.B. der laufende Monat bei "1 Mo" heraus.
    const monthEnd = new Date(y, m, 0);
    // Zukunft (Prognosewerte) bei kurzen Zeiträumen ausblenden.
    const noFuture = rangeId === "ytd" || monthStart <= today;
    return monthEnd >= cutoff && noFuture;
  }).sort();
}

// Alter Name bleibt als Hülle bestehen, damit vorhandene Aufrufer unverändert
// weiterlaufen.
function filterMonthKeysByRange(keys, rangeId) {
  return filterPeriodKeysByRange(keys, rangeId);
}

function filterIntervalsByRange(intervals, rangeId) {
  if (rangeId === "all") return intervals;
  const cutoff = rangeStartDate(rangeId);
  if (!cutoff) return intervals;
  return intervals.filter((iv) => new Date(iv.reading_date) >= cutoff);
}

function renderChartRangeSelector(stateKey, containerId, defaultRange, onChange) {
  meterChartRange[stateKey] = meterChartRange[stateKey] || defaultRange;
  const el = document.getElementById(containerId);
  const ranges = CHART_RANGES;
  el.innerHTML = ranges.map((r) =>
    `<button class="range-btn${r.id === meterChartRange[stateKey] ? " active" : ""}" data-range="${r.id}">${escHtml(r.label)}</button>`
  ).join("");
  el.querySelectorAll(".range-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      meterChartRange[stateKey] = btn.dataset.range;
      el.querySelectorAll(".range-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      onChange(btn.dataset.range);
    });
  });
  return meterChartRange[stateKey];
}

// ---------- Umschalter Monatsansicht <-> Jahresvergleich -- dieselbe
// Logik wie renderChartRangeSelector, nur mit fest zwei Optionen. Die
// Monats-Zeitraumauswahl (YTD/12M/...) bleibt für "Monatlich" bestehen;
// "Jährlich" ignoriert sie bewusst und gruppiert IMMER über alle
// vorhandenen Jahre, da man für einen Jahresvergleich ja gerade mehrere
// Jahre gleichzeitig sehen will. ----------
const meterChartViewMode = {};
function renderViewModeToggle(stateKey, containerId, onChange, extraOptions = []) {
  meterChartViewMode[stateKey] = meterChartViewMode[stateKey] || "monthly";
  const el = document.getElementById(containerId);
  const options = [{ id: "monthly", label: "📊 Monatlich" }, ...extraOptions, { id: "yearly", label: "📅 Jahresvergleich" }];
  el.innerHTML = options.map((o) =>
    `<button class="range-btn${o.id === meterChartViewMode[stateKey] ? " active" : ""}" data-mode="${o.id}">${escHtml(o.label)}</button>`
  ).join("");
  el.querySelectorAll(".range-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      meterChartViewMode[stateKey] = btn.dataset.mode;
      el.querySelectorAll(".range-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      onChange(btn.dataset.mode);
    });
  });
  return meterChartViewMode[stateKey];
}

// ---------- Umschalter zum Isolieren EINER Komponente (z.B. nur
// "Auto laden" statt gestapelt mit "Sonstiges") -- nur sichtbar/sinnvoll,
// wenn tatsächlich mehr als eine Serie existiert. ----------
const meterChartSeriesFilter = {};
function renderSeriesFilterToggle(stateKey, containerId, series, onChange) {
  const el = document.getElementById(containerId);
  if (series.length < 2) { el.innerHTML = ""; return "all"; }
  meterChartSeriesFilter[stateKey] = meterChartSeriesFilter[stateKey] || "all";
  const options = [{ id: "all", label: "Gestapelt" }, ...series.map((sr) => ({ id: sr.key, label: sr.label }))];
  el.innerHTML = options.map((o) =>
    `<button class="range-btn${o.id === meterChartSeriesFilter[stateKey] ? " active" : ""}" data-series="${o.id}">${escHtml(o.label)}</button>`
  ).join("");
  el.querySelectorAll(".range-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      meterChartSeriesFilter[stateKey] = btn.dataset.series;
      el.querySelectorAll(".range-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      onChange(btn.dataset.series);
    });
  });
  return meterChartSeriesFilter[stateKey];
}

// Wendet die Serien-Isolation an: "all" liefert alle Serien unverändert
// (gestapelte Ansicht), eine konkrete Serien-ID liefert NUR diese eine
// Serie -- renderStackedBarChart stapelt dann automatisch nichts mehr,
// da nur noch eine Komponente übrig ist (isolierte Zeitreihe).
function applySeriesFilter(series, filterId) {
  return filterId === "all" ? series : series.filter((sr) => sr.key === filterId);
}

// Fasst eine nach Monaten vorliegende Liste ([{key: "YYYY-MM", values}])
// zu Kalenderjahres-Summen zusammen ([{key: "YYYY", values}]) -- für den
// echten Jahr-für-Jahr-Vergleich, unabhängig von der Monats-Zeitraumwahl.
function groupIntoYears(monthsData, series) {
  const byYear = {};
  monthsData.forEach((m) => {
    const year = m.key.slice(0, 4);
    if (!byYear[year]) {
      byYear[year] = { key: year, values: {} };
      series.forEach((sr) => { byYear[year].values[sr.key] = 0; });
    }
    series.forEach((sr) => { byYear[year].values[sr.key] += (m.values[sr.key] || 0); });
  });
  return Object.keys(byYear).sort().map((y) => byYear[y]);
}

// ---------- Jahresvergleichs-Chart: wie renderStackedBarChart, aber mit
// eigener Achsenbeschriftung (reine Jahreszahlen statt "Monat 'Jahr" --
// monthLabel() würde bei einem reinen "YYYY"-Schlüssel scheitern, da es
// zwingend einen Monatsteil erwartet). ----------
function renderYearlyBarChart(containerId, years, series, unit) {
  const el = document.getElementById(containerId);
  if (!years.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Daten.</p>'; return; }

  const W = 700, H = 230, padL = 42, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const totals = years.map((y) => series.reduce((s, sr) => s + (y.values[sr.key] || 0), 0));
  const maxVal = Math.max(...totals, 1);
  const barW = chartW / years.length;
  const yScale = (v) => padT + chartH * (1 - v / maxVal);

  const bars = years.map((y, i) => {
    const x = padL + i * barW + barW * 0.15;
    const w = barW * 0.7;
    let cum = 0;
    return series.map((sr) => {
      const val = y.values[sr.key] || 0;
      const yTop = yScale(cum + val);
      const yBot = yScale(cum);
      cum += val;
      if (val <= 0) return "";
      return `<rect x="${x}" y="${yTop}" width="${w}" height="${Math.max(yBot - yTop, 1)}" fill="${sr.color}"><title>${y.key} — ${escHtml(sr.label)}: ${fmtDE1(val)} ${unit}</title></rect>`;
    }).join("");
  }).join("");

  const yearLabels = years.map((y, i) =>
    `<text x="${padL + i * barW + barW / 2}" y="${H - 6}" text-anchor="middle" font-size="9" fill="var(--muted)">${y.key}</text>`
  ).join("");
  const yLabels = [0, 0.5, 1].map((f) => `<text x="${padL - 6}" y="${padT + chartH * (1 - f) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${axisNumber(maxVal * f, maxVal)}</text>`).join("");

  el.innerHTML = `
    <div style="font-size:0.7rem;color:var(--muted);margin-bottom:6px">
      ${series.map((sr) => `<span style="display:inline-block;width:8px;height:8px;background:${sr.color};border-radius:2px;margin-right:4px"></span>${escHtml(sr.label)}`).join(" &nbsp; ")}
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${yLabels}${bars}${yearLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Ein Balken je Kalenderjahr · Zahlen bei Mouse-over</p>`;
}

// ---------- Wiederverwendbare Dokument-Liste: Scroll-Container ab ~10
// Zeilen statt unbegrenzter Höhe, plus Jahres-Filter bei mehreren Jahren.
// Verhindert, dass eine Liste mit vielen Einträgen (z.B. nach einem
// Sammel-Import) den Dialog so hoch macht, dass die Buttons unerreichbar
// aus dem Fenster laufen. ----------
// ---------- Zeilen-Menü-Button: sichtbare Alternative zum Rechtsklick.
// Auf iOS gibt es als PWA kein Rechtsklick und Long-Press ist unzuverlässig/
// nicht entdeckbar — ein fest sichtbarer "⋯"-Button funktioniert dagegen auf
// Maus UND Touch gleichermaßen und öffnet dasselbe Kontextmenü an derselben
// Stelle. Rechtsklick bleibt für Maus-Nutzer zusätzlich erhalten. ----------
function rowMenuButtonHTML(dataAttr, id) {
  return `<button type="button" class="row-menu-btn" data-row-menu-trigger="${dataAttr}" data-row-menu-id="${id}" title="Menü" aria-label="Menü öffnen">⋯</button>`;
}

function wireRowMenuButtons(container, dataAttr, onOpen) {
  container.querySelectorAll(`[data-row-menu-trigger="${dataAttr}"]`).forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const rect = btn.getBoundingClientRect();
      // Die Kontextmenüs sind position:absolute (Dokument-Koordinaten, wie pageX/pageY beim
      // Rechtsklick) -- daher Scrollposition addieren, sonst landet das Menü auf einer
      // gescrollten Seite an der falschen Stelle.
      onOpen(btn.dataset.rowMenuId, rect.left + window.scrollX, rect.bottom + window.scrollY + 4);
    });
  });
}

function setupScrollableDocList(containerId, items, dateExtractor, renderListCallback) {
  const container = document.getElementById(containerId);
  // Neuester Beleg immer ganz oben — zentral hier sortiert, damit das
  // konsistent für alle Beleg-Listen gilt (Gehaltsabrechnungen, Renten-
  // dokumente, Verträge, Archiv), die diese gemeinsame Funktion nutzen.
  // Einträge ohne erkennbares Datum rutschen ans Ende statt die Reihenfolge
  // der übrigen, datierten Einträge zu verfälschen.
  items = [...items].sort((a, b) => {
    const da = dateExtractor(a) || "";
    const db = dateExtractor(b) || "";
    if (!da && !db) return 0;
    if (!da) return 1;
    if (!db) return -1;
    return db < da ? -1 : db > da ? 1 : 0;
  });
  const years = [...new Set(items.map(dateExtractor).filter(Boolean).map((d) => String(d).slice(0, 4)))].sort().reverse();
  let selectedYear = "all";

  const filterHtml = years.length > 1 ? `
    <div class="doc-list-filter">
      <label class="muted" style="font-size:0.75rem">Jahr:</label>
      <select id="${containerId}-year-filter">
        <option value="all">Alle (${items.length})</option>
        ${years.map((y) => `<option value="${y}">${y} (${items.filter((i) => String(dateExtractor(i) || "").slice(0, 4) === y).length})</option>`).join("")}
      </select>
    </div>` : "";

  container.innerHTML = `${filterHtml}<div class="doc-list-scroll"><ul id="${containerId}-ul" style="margin:0"></ul></div>`;

  function doRender() {
    const filtered = selectedYear === "all" ? items : items.filter((i) => String(dateExtractor(i) || "").slice(0, 4) === selectedYear);
    renderListCallback(filtered, document.getElementById(`${containerId}-ul`));
  }

  const yearSelect = document.getElementById(`${containerId}-year-filter`);
  if (yearSelect) {
    yearSelect.addEventListener("change", () => {
      selectedYear = yearSelect.value;
      doRender();
    });
  }
  doRender();
}

const MONTH_NAMES = ["", "Jan", "Feb", "Mrz", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
// ---------- Datum für Beleg-Anzeige ermitteln: Dateiname zuerst (z.B.
// "15.10.2025 Depotauszug per 30.09.2025.pdf" trägt ein weit aussage-
// kräftigeres Datum als das reine Scan-/Upload-Datum), dann ein per OCR
// erkanntes Datum aus dem Dokumentinhalt, erst ganz zuletzt das
// Scan-Datum als Rückfall, falls gar nichts anderes zu finden ist. ----------
function extractDateFromFilename(filename) {
  if (!filename) return null;
  // Deutsches Format TT.MM.JJJJ (auch mit - oder _ statt .)
  let m = filename.match(/\b(\d{1,2})[.\-_](\d{1,2})[.\-_](\d{4})\b/);
  if (m) {
    const [, d, mo, y] = m;
    if (+mo >= 1 && +mo <= 12 && +d >= 1 && +d <= 31) {
      return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
    }
  }
  // ISO-Format JJJJ-MM-TT im Dateinamen
  m = filename.match(/\b(\d{4})[.\-_](\d{1,2})[.\-_](\d{1,2})\b/);
  if (m) {
    const [, y, mo, d] = m;
    if (+mo >= 1 && +mo <= 12 && +d >= 1 && +d <= 31) {
      return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
    }
  }
  return null;
}

function resolveDocDate(item) {
  return extractDateFromFilename(item.original_filename)
    || item.detected_date
    || (item.uploaded_at || "").slice(0, 10)
    || null;
}

function formatPayslipMonth(key) {
  const [y, m] = key.split("-");
  const idx = parseInt(m, 10);
  return idx >= 1 && idx <= 12 ? `${MONTH_NAMES[idx]} ${y}` : key;
}
// Y-Achsen-Zahl: bei kleinen Wertebereichen (z.B. 1,7 m³ pro Tag) würde
// reines Runden "1, 1, 0" ergeben — dann eine Nachkommastelle zeigen.
function axisNumber(value, maxVal) {
  if (maxVal < 10) return value.toFixed(1).replace(".", ",");
  return String(Math.round(value));
}

// Beschriftet Monats-, Wochen- UND Tagesschlüssel korrekt — ohne das würde
// z.B. "2026-09-07" als "Sep '20" beschriftet (Jahr aus dem falschen Teil).
function monthLabel(key) {
  const [y, m] = key.split("-");
  return `${MONTH_NAMES[parseInt(m, 10)]} '${y.slice(2)}`;
}

// Kurzform für die X-Achse bei feiner Auflösung: bei Tagen reicht die reine
// Tageszahl, der Monat wird nur beim Monatswechsel (und am ersten Punkt)
// dazugeschrieben — sonst steht auf jedem Balken redundant derselbe Monat.
function axisLabel(key) {
  return monthLabel(key);
}

// Für Tages-Schlüssel "YYYY-MM-DD" -- monthLabel() würde hier pro Tag
// dieselbe "Monat 'Jahr"-Beschriftung liefern, da es den Tagesteil ignoriert.
function dayLabel(key) {
  const [, m, d] = key.split("-").map(Number);
  return `${d}.${m}.`;
}

// Zeichnet die X-Achsen-Beschriftung und DÜNNT SIE AUS, wenn zu wenig Platz
// ist. Ohne das überlappen sich bei Tagesauflösung (30+ Balken) die Texte zu
// unlesbarem Matsch. Es wird immer der erste und letzte Punkt beschriftet,
// dazwischen in gleichmäßigen Abständen. labelFn austauschbar (Standard:
// Monatsbeschriftung), damit z.B. Tages-Charts dayLabel() nutzen können,
// ohne dass bestehende Aufrufer sich ändern müssen.
function renderXAxisLabels(keys, padL, barW, y, minSpacingPx = 34, labelFn = axisLabel) {
  const step = Math.max(1, Math.ceil(minSpacingPx / Math.max(barW, 1)));
  return keys.map((k, i) => {
    const isLast = i === keys.length - 1;
    if (i % step !== 0 && !isLast) return "";
    // Ganz am Ende nicht zeichnen, wenn es mit dem vorletzten kollidieren würde.
    if (isLast && keys.length > 1 && (keys.length - 1) % step !== 0 && step > 1
        && (keys.length - 1 - Math.floor((keys.length - 1) / step) * step) * barW < minSpacingPx) return "";
    return `<text x="${padL + i * barW + barW / 2}" y="${y}" text-anchor="middle" font-size="8" fill="var(--muted)">${labelFn(k)}</text>`;
  }).join("");
}

// ---------- Hauptchart: Balken (gemessen/Prognose) + optionale PV-Linie ----------
function renderMeterMainChart(containerId, monthly, forecast, unit, temps) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  // Ist-Werte UND Prognose zusammenführen: Die Prognose füllt nur fehlende
  // KALENDERmonate und ist bei Tages-/Wochenauflösung leer — ohne das
  // Zusammenführen bliebe der Chart dort komplett leer.
  const values = { ...monthly, ...forecast };
  const months = filterPeriodKeysByRange(Object.keys(values), meterChartRange[stateKey] || "ytd");
  if (!months.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Ablesungen.</p>'; return; }

  const W = 700, H = 220, padL = 42, padR = temps ? 32 : 10, padB = 26, padT = 10;
  const barVals = months.map((m) => values[m] || 0);
  const maxVal = Math.max(...barVals, 1);
  const chartW = W - padL - padR, chartH = H - padT - padB;
  const barW = chartW / months.length;
  const yScale = (v) => padT + chartH * (1 - v / maxVal);
  const cp = chartPalette();

  const bars = months.map((m, i) => {
    // Prognose nur dort, wo tatsächlich eine vorliegt. Bei Tages-/Wochen-
    // auflösung ist 'forecast' leer -- ohne diese Prüfung gälten dann ALLE
    // Balken fälschlich als Prognose und würden blass gezeichnet.
    const isForecast = !(m in monthly) && (m in forecast);
    const h = Math.max((barVals[i] / maxVal) * chartH, 1);
    const x = padL + i * barW + barW * 0.15;
    const w = barW * 0.7;
    // Laufender Monat: unten der bisher gemessene Teil kräftig, darüber hell
    // die Hochrechnung der restlichen Tage.
    const isPartial = (m in monthly) && (m in forecast) && forecast[m] > monthly[m] + 0.01;
    if (isPartial) {
      const hActual = Math.max((monthly[m] / maxVal) * chartH, 1);
      const tip = `${monthLabel(m)}: ${fmtDE1(barVals[i])} ${unit} — davon ${fmtDE1(monthly[m])} bisher gemessen, ${fmtDE1(barVals[i] - monthly[m])} hochgerechnet`;
      return `<rect x="${x}" y="${padT + chartH - h}" width="${w}" height="${h}" rx="2" fill="${hexToRgba(cp.purple, 0.28)}"><title>${tip}</title></rect>`
        + `<rect x="${x}" y="${padT + chartH - hActual}" width="${w}" height="${hActual}" rx="2" fill="${cp.purple}"><title>${tip}</title></rect>`;
    }
    return `<rect x="${x}" y="${padT + chartH - h}" width="${w}" height="${h}" rx="2" fill="${isForecast ? hexToRgba(cp.purple, 0.28) : cp.purple}"><title>${monthLabel(m)}: ${fmtDE1(barVals[i])} ${unit}${isForecast ? " (Prognose)" : ""}</title></rect>`;
  }).join("");

  const xLabels = renderXAxisLabels(months, padL, barW, H - 6);
  const yLabels = [0, 0.5, 1].map((f) => `<text x="${padL - 6}" y="${padT + chartH * (1 - f) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${axisNumber(maxVal * f, maxVal)}</text>`).join("");

  let tempLayer = "";
  if (temps) {
    // Skala aus den TATSÄCHLICH vorkommenden Werten ableiten statt fest
    // -5..25°C zu verdrahten -- sonst schneidet die Linie bei jedem Wert
    // außerhalb dieses Bereichs ab (z.B. ein heißer Sommertag über 25°C,
    // in Freiburg keine Seltenheit). Etwas Rand oben/unten, damit Punkte
    // nicht direkt am Kartenrand kleben.
    const allTempVals = [
      ...Object.values(temps.dwd_climate_avg || {}),
      ...months.map((m) => temps.actual[m]).filter((v) => v != null),
    ];
    const rawMin = allTempVals.length ? Math.min(...allTempVals) : -5;
    const rawMax = allTempVals.length ? Math.max(...allTempVals) : 25;
    const span = Math.max(rawMax - rawMin, 1);
    const tMin = Math.floor((rawMin - span * 0.1) / 5) * 5;
    const tMax = Math.ceil((rawMax + span * 0.1) / 5) * 5;
    const tScale = (t) => padT + chartH * (1 - (t - tMin) / (tMax - tMin));
    const xOf = (i) => padL + i * barW + barW / 2;
    const climPts = months.map((m, i) => {
      const mo = parseInt(m.split("-")[1], 10);
      const t = temps.dwd_climate_avg[String(mo)];
      return t != null ? `${xOf(i)},${tScale(t)}` : null;
    }).filter(Boolean).join(" ");
    const actualPts = months.map((m, i) => temps.actual[m] != null ? `${xOf(i)},${tScale(temps.actual[m])}` : null).filter(Boolean).join(" ");
    const actualDots = months.map((m, i) => {
      const t = temps.actual[m];
      if (t == null) return "";
      return `<circle cx="${xOf(i)}" cy="${tScale(t)}" r="3" fill="${cp.orange}"><title>${monthLabel(m)}: ${t.toFixed(1)}°C (Ist)</title></circle>`;
    }).join("");
    const tempYLabels = [tMin, (tMin + tMax) / 2, tMax].map((t) =>
      `<text x="${W - padR + 6}" y="${tScale(t) + 3}" text-anchor="start" font-size="8" fill="${cp.orange}">${Math.round(t)}°</text>`
    ).join("");
    tempLayer = `
      ${climPts ? `<polyline points="${climPts}" fill="none" stroke="${cp.neutral}" stroke-width="1.5" stroke-dasharray="4,3" />` : ""}
      ${actualPts ? `<polyline points="${actualPts}" fill="none" stroke="${cp.orange}" stroke-width="2" />` : ""}
      ${actualDots}
      ${tempYLabels}`;
  }

  el.innerHTML = `
    ${temps ? `<div style="font-size:0.7rem;color:var(--muted);margin-bottom:6px">
      <span style="display:inline-block;width:8px;height:8px;background:${cp.purple};border-radius:2px;margin-right:4px"></span>${unit === "m³" ? "Verbrauch" : "Wert"}
      &nbsp; <span style="display:inline-block;width:12px;height:2px;background:${cp.orange};margin-right:4px;vertical-align:middle"></span>Temperatur (Ist)
      &nbsp; <span style="display:inline-block;width:12px;height:2px;background:${cp.neutral};border-top:2px dashed;margin-right:4px;vertical-align:middle"></span>Klimamittel
    </div>` : ""}
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${yLabels}${bars}${tempLayer}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Helle Balken = Prognose · laufender Monat: kräftig = bisher gemessen, hell = Hochrechnung · Zahlen bei Mouse-over</p>`;
}

// ---------- Gestapelter Balkenchart: mehrere Komponenten je Monat (z.B.
// Eigenverbrauch + Netzbezug = Gesamtverbrauch, oder Eigenverbrauch +
// Einspeisung = PV-Ertrag) ----------
function renderStackedBarChart(containerId, months, series, unit, extraNote, labelFn = monthLabel) {
  const el = document.getElementById(containerId);
  if (!months.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Daten.</p>'; return; }

  const W = 700, H = 230, padL = 42, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const totals = months.map((m) => series.reduce((s, sr) => s + (m.values[sr.key] || 0), 0));
  const maxVal = Math.max(...totals, 1);
  const barW = chartW / months.length;
  const yScale = (v) => padT + chartH * (1 - v / maxVal);

  const anyForecast = months.some((m) => m.isForecast || m.actualValues);
  const bars = months.map((m, i) => {
    const x = padL + i * barW + barW * 0.15;
    const w = barW * 0.7;
    let cum = 0;
    if (m.actualValues) {
      // Laufender Monat: erst alle gemessenen Anteile kräftig, darüber die
      // Hochrechnung der Resttage je Serie hell.
      const segs = [];
      series.forEach((sr) => {
        const val = m.actualValues[sr.key] || 0;
        if (val > 0) segs.push(`<rect x="${x}" y="${yScale(cum + val)}" width="${w}" height="${Math.max(yScale(cum) - yScale(cum + val), 1)}" fill="${sr.color}"><title>${labelFn(m.key)} — ${escHtml(sr.label)}: ${fmtDE1(val)} ${unit} bisher gemessen</title></rect>`);
        cum += val;
      });
      series.forEach((sr) => {
        const rest = Math.max(0, (m.values[sr.key] || 0) - (m.actualValues[sr.key] || 0));
        if (rest > 0) segs.push(`<rect x="${x}" y="${yScale(cum + rest)}" width="${w}" height="${Math.max(yScale(cum) - yScale(cum + rest), 1)}" fill="${hexToRgba(sr.color, 0.35)}"><title>${labelFn(m.key)} — ${escHtml(sr.label)}: +${fmtDE1(rest)} ${unit} hochgerechnet</title></rect>`);
        cum += rest;
      });
      return segs.join("");
    }
    return series.map((sr) => {
      const val = m.values[sr.key] || 0;
      const yTop = yScale(cum + val);
      const yBot = yScale(cum);
      cum += val;
      if (val <= 0) return "";
      const fill = m.isForecast ? hexToRgba(sr.color, 0.35) : sr.color;
      return `<rect x="${x}" y="${yTop}" width="${w}" height="${Math.max(yBot - yTop, 1)}" fill="${fill}"><title>${labelFn(m.key)} — ${escHtml(sr.label)}: ${fmtDE1(val)} ${unit}${m.isForecast ? " (Prognose)" : ""}</title></rect>`;
    }).join("");
  }).join("");

  const xLabels = renderXAxisLabels(months.map((m) => m.key), padL, barW, H - 6, 34, labelFn);
  const yLabels = [0, 0.5, 1].map((f) => `<text x="${padL - 6}" y="${padT + chartH * (1 - f) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${axisNumber(maxVal * f, maxVal)}</text>`).join("");

  el.innerHTML = `
    <div style="font-size:0.7rem;color:var(--muted);margin-bottom:6px">
      ${series.map((sr) => `<span style="display:inline-block;width:8px;height:8px;background:${sr.color};border-radius:2px;margin-right:4px"></span>${escHtml(sr.label)}`).join(" &nbsp; ")}
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${yLabels}${bars}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">${anyForecast ? "Helle Balken = Prognose · laufender Monat: kräftig = bisher gemessen, hell = Hochrechnung · " : ""}Zahlen bei Mouse-over${extraNote ? ` · ${extraNote}` : ""}</p>`;
}

// ---------- Tagesverbrauch je Ableseintervall (nur Gas) ----------
function renderDailyRateChart(containerId, intervals, currentRate, unit) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  let ivals = intervals.filter((iv) => iv.rate != null);
  ivals = filterIntervalsByRange(ivals, meterChartRange[stateKey] || "ytd");
  // Bewusst KEINE feste Obergrenze mehr: Bei "Gesamt" sollen auch ältere
  // Ablesungen sichtbar sein. Die Achsenbeschriftung dünnt sich bei vielen
  // Einträgen ohnehin selbst aus, und wer weniger sehen will, wählt einen
  // kürzeren Zeitraum.
  if (!ivals.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Ablesungen.</p>'; return; }

  const W = 700, H = 180, padL = 36, padB = 34, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const maxVal = Math.max(...ivals.map((iv) => iv.rate), currentRate || 0, 0.1);
  const barW = chartW / ivals.length;
  const yScale = (v) => padT + chartH * (1 - v / maxVal);
  const cpRate = chartPalette();

  const bars = ivals.map((iv, i) => {
    const h = Math.max((iv.rate / maxVal) * chartH, 1);
    const x = padL + i * barW + barW * 0.15;
    return `<rect x="${x}" y="${padT + chartH - h}" width="${barW * 0.7}" height="${h}" rx="2" fill="${cpRate.purple}"><title>${iv.reading_date}: ${iv.rate.toFixed(2)} ${unit}/Tag</title></rect>`;
  }).join("");

  const refY = currentRate ? yScale(currentRate) : null;
  const refLine = refY != null ? `<line x1="${padL}" y1="${refY}" x2="${W - 10}" y2="${refY}" stroke="${cpRate.orange}" stroke-width="2" stroke-dasharray="5,3"><title>Aktuelle Tagesrate: ${currentRate.toFixed(2)} ${unit}/Tag</title></line>` : "";

  // Auch hier ausdünnen: Ohne die frühere 20er-Begrenzung können deutlich
  // mehr Balken auftreten. Gedrehte Beschriftungen brauchen weniger Abstand
  // als waagerechte, daher ein kleinerer Mindestabstand.
  const labelStep = Math.max(1, Math.ceil(16 / Math.max(barW, 1)));
  const xLabels = ivals.map((iv, i) => {
    if (i % labelStep !== 0 && i !== ivals.length - 1) return "";
    const d = new Date(iv.reading_date);
    const lbl = `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")}`;
    return `<text x="${padL + i * barW + barW / 2}" y="${H - 8}" text-anchor="middle" font-size="7" fill="var(--muted)" transform="rotate(45 ${padL + i * barW + barW / 2} ${H - 8})">${lbl}</text>`;
  }).join("");

  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${bars}${refLine}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Gestrichelte Linie = aktuelle Tagesrate (${currentRate != null ? currentRate.toFixed(2) : "–"} ${unit}/Tag) · Zahlen bei Mouse-over</p>`;
}


// ---------- Kumulativ-Chart: Ist-Kosten vs. Abschlag vs. optimaler Abschlag ----------
function renderCumulativeChart(containerId, months) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  const filtered = months.filter((m) => filterMonthKeysByRange([m.key], meterChartRange[stateKey] || "ytd").length);
  const use = filtered.length ? filtered : months;
  if (!use.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Daten.</p>'; return; }

  // Auto/Sonstiges nur zeigen, wenn das Backend sie mitliefert (Strombezug
  // mit vorhandenen Zappi-Ablesungen) -- als Ergänzung zur unverändert
  // bleibenden Gesamtansicht (Ist-Kosten/Abschlag/Opt. Abschlag), nicht als
  // Ersatz dafür.
  const hasAutoSplit = use.some((m) => m.auto_cost != null);

  const W = 700, H = 200, padL = 44, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const maxValKeys = ["cost", "abschlag", "opt_abschlag"];
  const maxVal = Math.max(...use.flatMap((m) => maxValKeys.map((k) => m[k])), 1);
  const stepX = chartW / (use.length - 1 || 1);
  const yScale = (v) => padT + chartH * (1 - v / maxVal);
  const cpCum = chartPalette();

  const line = (key, color, dash) => {
    const pts = use.map((m, i) => `${padL + i * stepX},${yScale(m[key])}`).join(" ");
    return `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" ${dash ? `stroke-dasharray="${dash}"` : ""} />`;
  };
  const dots = (key, color, label) => use.map((m, i) =>
    `<circle cx="${padL + i * stepX}" cy="${yScale(m[key])}" r="3" fill="${color}"><title>${monthLabel(m.key)} — ${label}: ${fmtDE0(m[key])} €</title></circle>`
  ).join("");

  const xLabels = renderXAxisLabels(use.map((m) => m.key), padL - stepX / 2, stepX, H - 6);
  const yLabels = [0, 0.5, 1].map((f) => `<text x="${padL - 6}" y="${padT + chartH * (1 - f) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${Math.round(maxVal * f).toLocaleString("de-DE")}€</text>`).join("");

  const autoLegend = hasAutoSplit ? `
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.primary};margin:0 4px 0 12px;vertical-align:middle"></span>davon Auto (Einkauf)
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.info};margin:0 4px 0 12px;vertical-align:middle"></span>davon Haushalt (Einkauf)` : "";
  const autoGraphics = hasAutoSplit
    ? `${line("auto_cost", cpCum.primary, "2,2")}${line("sonstiges_cost", cpCum.info, "2,2")}${dots("auto_cost", cpCum.primary, "davon Auto (Einkauf)")}${dots("sonstiges_cost", cpCum.info, "davon Haushalt (Einkauf)")}`
    : "";

  el.innerHTML = `
    <div style="font-size:0.7rem;color:var(--muted);margin-bottom:6px">
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.orange};margin-right:4px;vertical-align:middle"></span>Ist-Kosten
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.purple};border-top:2px dashed;margin:0 4px 0 12px;vertical-align:middle"></span>Abschlag
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.teal};margin:0 4px 0 12px;vertical-align:middle"></span>Optimaler Abschlag${autoLegend}
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${yLabels}${line("abschlag", cpCum.purple, "6,3")}${line("opt_abschlag", cpCum.teal, "3,3")}${line("cost", cpCum.orange)}${autoGraphics}${dots("abschlag", cpCum.purple, "Abschlag")}${dots("opt_abschlag", cpCum.teal, "Optimaler Abschlag")}${dots("cost", cpCum.orange, "Ist-Kosten")}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Zahlen bei Mouse-over</p>`;
}

// ---------- Autarkie-Chart (nur Einspeisung/PV) ----------
function renderAutarkieChart(containerId, months) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  const filtered = months.filter((m) => filterMonthKeysByRange([m.key], meterChartRange[stateKey] || "ytd").length);
  const use = filtered.length ? filtered : months;
  if (!use.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine PV-Daten importiert.</p>'; return; }

  const W = 700, H = 200, padL = 32, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const stepX = chartW / (use.length - 1 || 1);

  // Skala an die tatsächliche Datenspanne anpassen (mit etwas Puffer), statt
  // immer starr 0–100% zu zeigen — sonst sind z.B. 90–98% optisch kaum von
  // 100% zu unterscheiden, obwohl es ein echter Unterschied ist.
  const values = use.map((m) => m.autarkie);
  const dataMin = Math.min(...values), dataMax = Math.max(...values);
  const yMin = Math.max(0, Math.floor((dataMin - 8) / 10) * 10);
  const yMax = Math.min(100, Math.ceil((dataMax + 8) / 10) * 10);
  const yRange = (yMax - yMin) || 1;
  const yScale = (v) => padT + chartH * (1 - (v - yMin) / yRange);
  const cpAut = chartPalette();

  const pts = use.map((m, i) => `${padL + i * stepX},${yScale(m.autarkie)}`).join(" ");
  const dots = use.map((m, i) => {
    const color = m.autarkie >= 90 ? cpAut.teal : m.autarkie >= 70 ? cpAut.orange : cpAut.purple;
    return `<circle cx="${padL + i * stepX}" cy="${yScale(m.autarkie)}" r="3.5" fill="${color}"><title>${monthLabel(m.key)}: ${m.autarkie}% autark</title></circle>`;
  }).join("");
  const xLabels = renderXAxisLabels(use.map((m) => m.key), padL - stepX / 2, stepX, H - 6);
  const yTicks = [yMin, Math.round((yMin + yMax) / 2), yMax];
  const yLabels = yTicks.map((v) => `<text x="${padL - 6}" y="${yScale(v) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${v}%</text>`).join("");

  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
    ${yLabels}
    <polyline points="${pts}" fill="none" stroke="${cpAut.teal}" stroke-width="2.5" />
    <polygon points="${padL},${yScale(yMin)} ${pts} ${padL + (use.length - 1) * stepX},${yScale(yMin)}" fill="${hexToRgba(cpAut.teal, 0.08)}" />
    ${dots}${xLabels}
  </svg>
  <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Skala ${yMin}–${yMax}% (an Datenspanne angepasst) · Zahlen bei Mouse-over</p>`;
}

async function loadMeterPage(meterType, containerId, title) {
  const container = document.getElementById(containerId);
  container.innerHTML = '<p class="muted">Lade …</p>';
  const unit = meterType === "gas" || meterType === "water" ? "m³" : "kWh";
  const isEinspeisung = meterType === "elec_out";
  const isElecIn = meterType === "elec_in";

  const [readingsRes, monthlyRes, settingsRes, kpisRes, intervalsRes] = await Promise.all([
    authedFetch(`/api/meters/${meterType}/readings`),
    authedFetch(`/api/meters/${meterType}/monthly`),
    authedFetch(`/api/meters/${meterType}/settings`),
    authedFetch(`/api/meters/${meterType}/kpis`),
    authedFetch(`/api/meters/${meterType}/intervals`),
  ]);
  const { readings } = await readingsRes.json();
  const { monthly, forecast } = await monthlyRes.json();
  const settings_ = await settingsRes.json();
  const { chips } = await kpisRes.json();
  const { intervals: rawIntervals } = await intervalsRes.json();
  // Verknüpfung mit Ausgaben/Einnahmen: der Abschlag kommt live aus dem Vertrag (siehe Backend resolve_settings)
  const linkCandidates = await (await authedFetch(`/api/meters/${meterType}/link-candidates`)).json().catch(() => []);
  const link = settings_.link || null;
  const linkSelected = settings_.link_id === 0 ? "0" : (settings_.link_id ? String(settings_.link_id) : "");
  const linkWhat = isEinspeisung ? "Einnahme" : "Ausgabe";

  // Bei Gas rechnen wir eigentlich in kWh (Brennwert-Umrechnung) -- nur der
  // Zählerstand selbst (was tatsächlich am Zähler abzulesen ist) bleibt in
  // m³, alle daraus abgeleiteten Verbrauchszahlen (Delta, Tagesrate,
  // Chart-Werte) werden für die Anzeige umgerechnet.
  const gasBrennwert = meterType === "gas" ? (settings_.brennwert || 10) : 1;
  const chartUnit = meterType === "gas" ? "kWh" : unit;
  const toChartUnit = (v, decimals = 2) => (v == null ? v : Math.round(v * gasBrennwert * 10 ** decimals) / 10 ** decimals);
  const intervals = meterType === "gas"
    ? rawIntervals.map((iv) => ({
        ...iv,
        delta: (iv.delta != null && iv.delta !== "meter_switch") ? toChartUnit(iv.delta, 1) : iv.delta,
        rate: iv.rate != null ? toChartUnit(iv.rate, 2) : iv.rate,
      }))
    : rawIntervals;

  let pvMonthly = [];
  if (isElecIn || isEinspeisung) {
    pvMonthly = (await (await authedFetch("/api/pv/monthly")).json()).months;
  }
  let autarkieMonths = [];
  if (isEinspeisung) {
    autarkieMonths = (await (await authedFetch("/api/pv/autarkie")).json()).months;
  }
  let cumMonths = [];
  if (!isEinspeisung) {
    cumMonths = (await (await authedFetch(`/api/meters/${meterType}/cumulative`)).json()).months;
  }

  const contractBadge = settings_.anbieter ? `
    <div class="contract-badge">
      <span>${title.split(" ")[0]} <strong>${escHtml(settings_.anbieter)}</strong></span>
      ${!isEinspeisung ? `<span class="muted">${(settings_.arbeitspreis || 0).toFixed(4)} €/${unit} · ${(settings_.grundpreis || 0).toFixed(2)} €/Mo</span>` : `<span class="muted">${(settings_.einspeisepreis || 0).toFixed(4)} €/kWh</span>`}
    </div>` : "";

  const chipsHtml = `
    <div class="kpi-chip-row">
      ${chips.map((c) => `
        <div class="kpi-chip">
          <div class="kpi-chip-lbl">${escHtml(c.label)}</div>
          <div class="kpi-chip-val${c.status ? ` ${c.status === "ok" ? "settle-ok" : "settle-red"}` : ""}">${c.value}</div>
          <div class="kpi-chip-sub">${c.sub}</div>
        </div>`).join("")}
    </div>`;

  // Volle Zeitreihe -- wird NICHT mehr inline gezeigt, sondern nur im
  // "Verlauf"-Modal (per Klick/Rechtsklick auf "Ablesungen" erreichbar),
  // damit die Seite nicht durch lange Ablesungslisten aufgebläht wird.
  const readingsHistoryTableHtml = isElecIn ? `
    <div style="overflow-x:auto">
      <table class="meter-table">
        <thead><tr><th>Datum</th><th class="r">Verbrauchszähler</th><th></th></tr></thead>
        <tbody>
          ${intervals.length === 0 ? '<tr><td colspan="3" class="muted">Noch keine Ablesungen</td></tr>' : intervals.slice().reverse().map((iv) => `
            <tr>
              <td>${iv.reading_date}${iv.is_new_meter ? ' <span class="tag">neuer Zähler</span>' : ""}</td>
              <td class="r">${fmtUnit(iv.value, unit)}</td>
              <td><button class="del-btn" data-delete-reading="${iv.id}" title="Löschen">🗑</button></td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>` : `
    <div style="overflow-x:auto">
      <table class="meter-table">
        <thead><tr><th>Datum</th><th class="r">Stand (${unit})</th><th class="r">Delta (${chartUnit})</th><th class="r">Tage</th><th class="r">Rate/Tag (${chartUnit})</th><th></th></tr></thead>
        <tbody>
          ${intervals.length === 0 ? '<tr><td colspan="6" class="muted">Noch keine Ablesungen</td></tr>' : intervals.slice().reverse().map((iv) => `
            <tr>
              <td>${iv.reading_date}${iv.is_new_meter ? ' <span class="tag">neuer Zähler</span>' : ""}</td>
              <td class="r">${fmtUnit(iv.value, unit)}</td>
              <td class="r muted">${iv.delta === "meter_switch" ? "↺ Wechsel" : (iv.delta != null ? iv.delta : "–")}</td>
              <td class="r muted">${iv.days != null ? iv.days : "–"}</td>
              <td class="r">${iv.rate != null ? iv.rate : "–"}</td>
              <td><button class="del-btn" data-delete-reading="${iv.id}" title="Löschen">🗑</button></td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`;
  const lastInterval = intervals.length ? intervals[intervals.length - 1] : null;

  const pvHistoryTableHtml = `
    <div style="overflow-x:auto">
      <table class="meter-table">
        <thead><tr><th>Monat</th><th class="r">Produktion</th><th class="r">Eigenverbrauch</th><th class="r">Einspeisung</th><th></th></tr></thead>
        <tbody>
          ${pvMonthly.length === 0 ? '<tr><td colspan="5" class="muted">Noch keine PV-Daten importiert</td></tr>' : pvMonthly.slice().reverse().map((m) => `
            <tr>
              <td>${monthLabel(m.key)}</td>
              <td class="r">${fmtUnit(m.pv, "kWh")}</td>
              <td class="r muted">${fmtUnit(Math.max(0, m.pv - m.einsp), "kWh")}</td>
              <td class="r">${fmtUnit(m.einsp, "kWh")}</td>
              <td><button class="del-btn" data-delete-pv="${m.key}" title="Löschen">🗑</button></td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`;
  const lastPvMonth = pvMonthly.length ? pvMonthly[pvMonthly.length - 1] : null;

  container.innerHTML = `
    <section class="card">
      <h2>${title}</h2>
      ${contractBadge}
      ${chipsHtml}
    </section>

    <section class="card">
      <h3 style="margin:0 0 10px;font-size:0.95rem;color:var(--accent)">Tarif &amp; Abschlag</h3>
      <form id="${containerId}-settings-form">
        <label class="muted" style="font-size:0.8rem">Anbieter</label>
        <input type="text" id="${containerId}-s-anbieter" value="${settings_.anbieter || ""}" />

        ${!isEinspeisung ? `
          <label class="muted" style="font-size:0.8rem">Vertragsablauf (optional)</label>
          <input type="date" id="${containerId}-s-vertragsende" value="${settings_.vertragsende || ""}" />
        ` : ""}

        <label class="muted" style="font-size:0.8rem">Verknüpfung mit ${isEinspeisung ? "Einnahmen" : "Ausgaben"}</label>
        <select id="${containerId}-s-link">
          <option value="" ${linkSelected === "" ? "selected" : ""}>Automatisch erkennen</option>
          <option value="0" ${linkSelected === "0" ? "selected" : ""}>Keine – Abschlag von Hand</option>
          ${(linkCandidates || []).map((c) => `<option value="${c.id}" ${linkSelected === String(c.id) ? "selected" : ""}>${c.likely ? "★ " : ""}${escHtml(c.label)} — ${fmtEur2(c.monthly)}/Mo</option>`).join("")}
        </select>
        <p class="muted" style="font-size:0.72rem;margin:2px 0 8px">${link
          ? `🔗 Der Abschlag kommt live aus der ${linkWhat} „${escHtml(link.label)}“ (${fmtEur2(link.monthly)}/Mo)${link.auto ? " · automatisch erkannt" : ""} — Änderungen dort gelten hier sofort.`
          : `⚠ Mit keiner ${linkWhat} verknüpft — der Abschlag muss von Hand gepflegt werden. Wähle oben den passenden Eintrag, damit er immer stimmt.`}</p>

        <label class="muted" style="font-size:0.8rem">Monatlicher Abschlag (€)${link ? ` — aus ${linkWhat === "Einnahme" ? "der Einnahme" : "den Ausgaben"}` : ""}</label>
        <input type="text" id="${containerId}-s-abschlag" inputmode="decimal" value="${settings_.abschlag || 0}" ${link ? "readonly style=\"opacity:0.6\"" : ""} />

        ${isEinspeisung ? `
          <label class="muted" style="font-size:0.8rem">Einspeisevergütung (€/kWh)</label>
          <input type="text" id="${containerId}-s-einspeisepreis" inputmode="decimal" value="${settings_.einspeisepreis || 0}" />
        ` : `
          <label class="muted" style="font-size:0.8rem">Arbeitspreis (€/${chartUnit})</label>
          <input type="text" id="${containerId}-s-arbeitspreis" inputmode="decimal" value="${settings_.arbeitspreis || 0}" />

          <label class="muted" style="font-size:0.8rem">Grundpreis (€/Monat)</label>
          <input type="text" id="${containerId}-s-grundpreis" inputmode="decimal" value="${settings_.grundpreis || 0}" />

          ${meterType === "water" ? `
            <label class="muted" style="font-size:0.8rem">Entwässerung / Schmutzwasser (€/${unit})</label>
            <input type="text" id="${containerId}-s-entwaesserung" inputmode="decimal" value="${settings_.entwaesserung_preis || 0}" />
            <p class="muted" style="font-size:0.72rem;margin:2px 0 0">Wird zum Trinkwasserpreis addiert — die Kosten basieren auf demselben verbrauchten Kubikmeter, es gibt in der Regel keinen eigenen Abwasserzähler.</p>
          ` : ""}

          ${meterType === "gas" ? `
            <label class="muted" style="font-size:0.8rem">Brennwert (kWh/m³)</label>
            <input type="text" id="${containerId}-s-brennwert" inputmode="decimal" value="${settings_.brennwert || 10}" />
          ` : ""}
        `}

        <button type="submit" style="margin-top:12px">Speichern</button>
      </form>
    </section>

    <section class="card">
      <h3 style="margin:0 0 4px;font-size:0.95rem;color:var(--accent)">📅 Abrechnungszeitpunkte</h3>
      <p class="muted" style="margin:0 0 10px;font-size:0.75rem">Wann eine echte Abrechnung eingegangen ist — dient als Reset-Basis für "Verbrauch seit der Abrechnung", unabhängig vom Kalenderjahr.</p>
      <div id="${containerId}-settlement-since"></div>
      <div class="row-actions" style="margin-top:10px">
        <input type="date" id="${containerId}-settlement-date" style="flex:1" />
        <input type="text" id="${containerId}-settlement-note" placeholder="Notiz (optional)" style="flex:1" />
      </div>
      <button type="button" id="${containerId}-settlement-add-btn" class="ghost-btn" style="width:100%;margin-top:8px">+ Abrechnungszeitpunkt erfassen</button>
      <div id="${containerId}-settlement-list" style="margin-top:10px"></div>
    </section>

    ${meterType === "gas" ? `
    <section class="card">
      <h3 style="margin:0 0 4px;font-size:0.95rem;color:var(--accent)">🌡️ Wetter-Standort</h3>
      <p class="muted" style="margin:0 0 10px;font-size:0.75rem">Für die "Temperatur (Ist)"-Linie im Chart unten — wird automatisch beim Start der App aktualisiert (höchstens einmal pro Tag). Ohne Standort bleibt nur die Klimamittel-Linie sichtbar.</p>
      <div class="row-actions">
        <input type="text" id="gas-weather-location" placeholder="z.B. Ort oder Postleitzahl" style="flex:1" />
        <button type="button" id="gas-weather-refresh-btn" class="ghost-btn" style="width:auto">🔄 Jetzt abrufen</button>
      </div>
      <div id="gas-weather-status" style="margin-top:8px;font-size:0.75rem"></div>
    </section>
    ` : ""}

    <div class="chart-grid">
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 id="${containerId}-main-title" style="margin:0;font-size:0.95rem;color:var(--accent)">${isEinspeisung ? "Produktion" : isElecIn ? "Hausverbrauch" : meterType === "gas" ? "Verbrauch & Temperatur" : "Verbrauch"}</h3>
          <div id="${containerId}-main-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-main-viewmode" class="range-sel" style="margin-bottom:8px"></div>
        <div id="${containerId}-main-seriesfilter" class="range-sel" style="margin-bottom:8px"></div>
        <div id="${containerId}-main-chart"></div>
      </section>

      ${isElecIn ? `
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Strom-Einkauf je Monat</h3>
          <div id="${containerId}-einkauf-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-einkauf-viewmode" class="range-sel" style="margin-bottom:8px"></div>
        <div id="${containerId}-einkauf-chart"></div>
        <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Netzbezug — allein dieser Strom geht in Abschlag und Jahresabrechnung ein; PV und Speicher kosten nichts.</p>
      </section>
      ` : ""}

      ${meterType === "gas" ? `
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Tagesverbrauch je Ableseintervall</h3>
          <div id="${containerId}-daily-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-daily-chart"></div>
      </section>` : ""}

      ${isEinspeisung ? `
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Autarkiegrad</h3>
          <div id="${containerId}-aut-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-aut-chart"></div>
      </section>` : `
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Kumulative Kosten</h3>
          <div id="${containerId}-cum-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-cum-chart"></div>
      </section>`}
    </div>

    <section class="card">
      <h2 style="margin-bottom:10px">📥 Ablesung hinzufügen</h2>
      <div class="mode-toggle">
        <button type="button" class="mode-btn active" data-mode="manual">✏️ Manuell</button>
        <button type="button" class="mode-btn" data-mode="smart">🧠 Intelligenter Import</button>
      </div>

      <div id="${containerId}-mode-manual">
        <form id="${containerId}-add-form" class="row-actions" style="flex-wrap:wrap;gap:8px;margin-top:12px">
          <input type="date" id="${containerId}-date" required style="flex:1;min-width:130px" />
          <input type="text" id="${containerId}-value" required inputmode="decimal" placeholder="Zählerstand (${unit})" style="flex:1;min-width:130px" />
          <button type="submit" style="width:auto">Speichern</button>
        </form>
        <label class="checkbox-label">
          <input type="checkbox" id="${containerId}-new-meter" />
          <span>Erster Stand nach einem Zählerwechsel (neuer Zähler)</span>
        </label>

        <div class="divider"></div>
        <p class="muted" style="margin:0 0 6px;font-size:0.8rem">Oder Foto der Ablesekarte/Abrechnung einlesen:</p>
        <input type="file" id="${containerId}-photo" accept="image/*,application/pdf" />
        <button type="button" id="${containerId}-photo-btn" class="ghost-btn" style="width:100%;margin-top:6px">Einlesen</button>
        <div id="${containerId}-photo-result"></div>
      </div>

      <div id="${containerId}-mode-smart" style="display:none;margin-top:12px">
        <p class="muted" style="margin:0 0 8px;font-size:0.75rem">CSV/Excel-Datei mit Datum + Zählerstand hochladen — Spalten werden automatisch erkannt.</p>
        <input type="file" id="${containerId}-smart-file" accept=".csv,.xlsx,.xls,.ods" />
        <button type="button" id="${containerId}-smart-analyze-btn" class="ghost-btn" style="width:100%;margin-top:8px">Datei analysieren</button>
        <div id="${containerId}-smart-result"></div>
      </div>
    </section>

    <section class="card">
      ${isEinspeisung ? `
        <h3 id="${containerId}-pv-heading" style="margin:0 0 10px;font-size:0.95rem;color:var(--accent);cursor:context-menu" title="Klick oder Rechtsklick für den vollen Verlauf">Produktion &amp; Einspeisung je Monat (${pvMonthly.length}) <span class="muted" style="font-size:0.75rem;font-weight:400">📜 Verlauf</span></h3>
        ${lastPvMonth ? `
        <div class="row-actions" style="justify-content:space-between;align-items:baseline">
          <span class="muted" style="font-size:0.85rem">${monthLabel(lastPvMonth.key)}</span>
          <div style="text-align:right">
            <div class="muted" style="font-size:0.8rem">Eigenverbrauch: ${fmtUnit(Math.max(0, lastPvMonth.pv - lastPvMonth.einsp), "kWh")} · Einspeisung: ${fmtUnit(lastPvMonth.einsp, "kWh")}</div>
            <div style="font-weight:600">${fmtUnit(lastPvMonth.pv, "kWh")} Produktion</div>
          </div>
        </div>` : '<p class="muted" style="font-size:0.85rem">Noch keine PV-Daten importiert</p>'}
        <p class="muted" style="margin:8px 0 0;font-size:0.7rem">Eigenverbrauch = Produktion − Einspeisung. Zählerablesungen der Einspeisung fließen zusätzlich in Tagesrate/Kennzahlen oben ein, sind hier aber nicht separat aufgeführt.</p>
      ` : isElecIn ? `
        <h3 id="${containerId}-ablesungen-heading" style="margin:0 0 10px;font-size:0.95rem;color:var(--accent);cursor:context-menu" title="Klick oder Rechtsklick für den vollen Verlauf">Ablesungen (${readings.length}) <span class="muted" style="font-size:0.75rem;font-weight:400">📜 Verlauf</span></h3>
        ${lastInterval ? `
        <div class="row-actions" style="justify-content:space-between;align-items:baseline">
          <span class="muted" style="font-size:0.85rem">Letzte Ablesung${lastInterval.is_new_meter ? ' <span class="tag">neuer Zähler</span>' : ""}</span>
          <div style="text-align:right">
            <div class="muted" style="font-size:0.8rem">${lastInterval.reading_date}</div>
            <div style="font-weight:600">${fmtUnit(lastInterval.value, unit)}</div>
          </div>
        </div>` : '<p class="muted" style="font-size:0.85rem">Noch keine Ablesungen</p>'}
      ` : `
        <h3 id="${containerId}-ablesungen-heading" style="margin:0 0 10px;font-size:0.95rem;color:var(--accent);cursor:context-menu" title="Klick oder Rechtsklick für den vollen Verlauf">Ablesungen (${readings.length}) <span class="muted" style="font-size:0.75rem;font-weight:400">📜 Verlauf</span></h3>
        ${lastInterval ? `
        <div class="row-actions" style="justify-content:space-between;align-items:baseline">
          <span class="muted" style="font-size:0.85rem">Letzte Ablesung${lastInterval.is_new_meter ? ' <span class="tag">neuer Zähler</span>' : ""}</span>
          <div style="text-align:right">
            <div class="muted" style="font-size:0.8rem">${lastInterval.reading_date} · Rate/Tag: ${lastInterval.rate != null ? `${lastInterval.rate} ${chartUnit}` : "–"}</div>
            <div style="font-weight:600">${fmtUnit(lastInterval.value, unit)}</div>
          </div>
        </div>` : '<p class="muted" style="font-size:0.85rem">Noch keine Ablesungen</p>'}
      `}
    </section>
  `;

  // "Ablesungen"-Ueberschrift oeffnet den vollen Verlauf -- per Klick UND
  // per Rechtsklick, da ein reiner Rechtsklick auf einem Telefon (das
  // primaere Geraet hier) nicht auslösbar ist.
  const ablesungenHeading = document.getElementById(`${containerId}-ablesungen-heading`);
  if (ablesungenHeading) {
    const openHistory = (e) => { e.preventDefault(); openReadingsHistory(`Ablesungen — ${title}`, readingsHistoryTableHtml, meterType, containerId); };
    ablesungenHeading.addEventListener("click", openHistory);
    ablesungenHeading.addEventListener("contextmenu", openHistory);
  }
  const pvHeading = document.getElementById(`${containerId}-pv-heading`);
  if (pvHeading) {
    const openPvHistory = (e) => { e.preventDefault(); openReadingsHistory(`Produktion & Einspeisung — ${title}`, pvHistoryTableHtml, meterType, containerId); };
    pvHeading.addEventListener("click", openPvHistory);
    pvHeading.addEventListener("contextmenu", openPvHistory);
  }

  // ---- Manuell / Intelligenter Import umschalten ----
  container.querySelectorAll(".mode-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      container.querySelectorAll(".mode-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`${containerId}-mode-manual`).style.display = btn.dataset.mode === "manual" ? "block" : "none";
      document.getElementById(`${containerId}-mode-smart`).style.display = btn.dataset.mode === "smart" ? "block" : "none";
    });
  });

  // ---- Charts mit je eigenem Zeitraum-Filter ----
  const cp4 = chartPalette();

  if (isElecIn || isEinspeisung) {
    const series = isElecIn
      ? [
          { key: "auto", label: "Auto laden", color: cp4.purple },
          { key: "sonstiges", label: "Haushalt", color: cp4.teal },
        ]
      : [
          { key: "eigenverbrauch", label: "Eigenverbrauch (PV)", color: cp4.teal },
          { key: "einspeisung", label: "Einspeisung", color: cp4.purple },
        ];

    // Für Produktion NICHT die Zähler-eigene Prognose nutzen (nur 2 Ablesungen
    // vorhanden → ohne jede Saisonalität, extrapoliert sonst z.B. die hohe
    // Sommer-Tagesrate fälschlich auf den ganzen Winter). Stattdessen dieselbe
    // echte PV-Monatsdatenquelle wie die Tabelle darunter verwenden.
    const einspeisungByKey = isEinspeisung ? Object.fromEntries(pvMonthly.map((d) => [d.key, d.einsp])) : null;
    const eigenverbrauchByKey = {};
    if (isEinspeisung) {
      pvMonthly.forEach((d) => { eigenverbrauchByKey[d.key] = Math.max(0, d.pv - d.einsp); });
    }

    const baseTitle = isEinspeisung ? "Produktion" : "Hausverbrauch";
    const renderStacked = async (rangeId) => {
      rangeId = rangeId || meterChartRange[`${containerId}-main`] || "ytd";
      const viewMode = meterChartViewMode[`${containerId}-main`];
      const isYearly = viewMode === "yearly";
      const isDaily = viewMode === "daily";
      const pvRes = await (await authedFetch("/api/pv/monthly")).json();
      const pvSeries = pvRes.months || [];
      const titleEl = document.getElementById(`${containerId}-main-title`);
      if (titleEl) titleEl.textContent = chartTitleWithResolution(baseTitle);

      let monthsData;
      if (isDaily) {
        // Echte Tageswerte statt Monats-Schätzung -- nur möglich für den
        // Zeitraum, in dem der automatische Sungrow-Sync bereits lief (siehe
        // /api/pv/daily); anders als bei Monatlich/Jahresvergleich gibt es
        // hier bewusst KEINE Hochrechnung fehlender Tage.
        const pvDaily = (await (await authedFetch("/api/pv/daily")).json()).days || [];
        const filteredDays = filterPeriodKeysByRange(pvDaily.map((d) => d.key), rangeId)
          .map((k) => pvDaily.find((d) => d.key === k));
        if (isElecIn) {
          const evReadings = (await (await authedFetch("/api/meters/ev_charging/readings")).json()).readings || [];
          const evByDay = {};
          const sortedEv = evReadings.slice().sort((a, b) => a.reading_date.localeCompare(b.reading_date));
          // Zappi-Stand vom Tag X = Ladung DES Tages X; der erste Stand zählt
          // voll (der Sync beginnt bei 0) -- wie ev_daily_charge im Backend.
          for (let i = 0; i < sortedEv.length; i++) {
            evByDay[sortedEv[i].reading_date] = Math.max(0, sortedEv[i].value - (i ? sortedEv[i - 1].value : 0));
          }
          monthsData = filteredDays.map((d) => {
            const gesamt = d.gesamt || 0;
            const auto = Math.min(evByDay[d.key] || 0, gesamt);
            return { key: d.key, values: { auto, sonstiges: Math.max(0, gesamt - auto) } };
          });
        } else {
          monthsData = filteredDays.map((d) => ({
            key: d.key,
            values: { eigenverbrauch: Math.max(0, (d.pv || 0) - (d.einsp || 0)), einspeisung: d.einsp || 0 },
          }));
        }
      } else if (isElecIn) {
        // "Gesamtverbrauch" laut Sungrow läuft über denselben Hausanschluss
        // wie die Zappi-Wallbox und enthält das Laden deshalb zwangsläufig
        // mit -- hier direkt aufgeschlüsselt in Auto laden vs. Sonstiges,
        // statt wie zuvor nur als Fußnoten-Hinweis neben Eigenverbrauch/
        // Netzbezug. "Sonstiges" ist damit alles, was NICHT ans Auto ging
        // (Haushalt, unabhängig davon ob aus PV oder Netz).
        const evRes = await (await authedFetch("/api/meters/ev_charging/monthly")).json().catch(() => ({}));
        // Ladewerte: echte Monate + dieselbe installationsdatum-bewusste
        // Hochrechnung wie in der Jahreskosten-Kachel/im Kosten-Chart
        // (ev_monthly_with_forecast-Äquivalent auf Backend-Seite) -- nie vor
        // der Installation der Wallbox erfunden.
        const autoByKey = { ...(evRes.monthly || {}), ...(evRes.forecast || {}) };
        // Gesamtverbrauch: echte Sungrow-Monate + serverseitige Hochrechnung
        // für fehlende Monate (dieselbe saisonale Logik wie Gas/Wasser) --
        // vorher zeigte dieser Chart nur echte Monate, keine Prognose.
        const gesamtRealByKey = Object.fromEntries(pvSeries.map((d) => [d.key, d.gesamt || 0]));
        const gesamtForecastByKey = pvRes.forecast?.gesamt || {};
        // Laufender Monat: die Prognose enthält bereits die Hochrechnung der
        // Resttage -- sie muss hier den Teilwert ersetzen, nicht umgekehrt.
        const curKey = localMonthKey();
        const gesamtByKey = { ...gesamtForecastByKey, ...gesamtRealByKey };
        if (gesamtForecastByKey[curKey] > (gesamtRealByKey[curKey] || 0)) gesamtByKey[curKey] = gesamtForecastByKey[curKey];
        const autoRealByKey = { ...(evRes.monthly || {}) };
        const allKeys = new Set([...Object.keys(gesamtByKey), ...Object.keys(autoByKey)]);
        // Jahresvergleich ignoriert bewusst die Monats-Zeitraumwahl -- für
        // "Jahr für Jahr" will man ja gerade ALLE vorhandenen Jahre sehen,
        // nicht nur z.B. die letzten 12 Monate.
        const filteredKeys = isYearly ? [...allKeys].sort() : filterPeriodKeysByRange([...allKeys], rangeId);
        monthsData = filteredKeys.map((key) => {
          const gesamt = gesamtByKey[key] || 0;
          const auto = Math.min(autoByKey[key] || 0, gesamt);
          const entry = { key, values: { auto, sonstiges: Math.max(0, gesamt - auto) }, isForecast: !(key in gesamtRealByKey) };
          if (key === curKey && key in gesamtRealByKey && gesamt > gesamtRealByKey[key] + 0.01) {
            const gReal = gesamtRealByKey[key];
            const aReal = Math.min(autoRealByKey[key] || 0, gReal);
            entry.actualValues = { auto: aReal, sonstiges: Math.max(0, gReal - aReal) };
          }
          return entry;
        });
      } else {
        // Wie bei Gesamtverbrauch: echte PV-Monate + serverseitige Prognose
        // für fehlende Monate (vorher zeigte auch die Produktions-Ansicht
        // ausschließlich echte Monate, ohne Hochrechnung).
        const pvRealByKey = Object.fromEntries(pvSeries.map((d) => [d.key, d.pv || 0]));
        const einspRealByKey = Object.fromEntries(pvSeries.map((d) => [d.key, d.einsp || 0]));
        const pvByKey = { ...(pvRes.forecast?.pv || {}), ...pvRealByKey };
        const einspByKey = { ...(pvRes.forecast?.einsp || {}), ...einspRealByKey };
        const curKeyP = localMonthKey();
        if ((pvRes.forecast?.pv || {})[curKeyP] > (pvRealByKey[curKeyP] || 0)) pvByKey[curKeyP] = pvRes.forecast.pv[curKeyP];
        if ((pvRes.forecast?.einsp || {})[curKeyP] > (einspRealByKey[curKeyP] || 0)) einspByKey[curKeyP] = pvRes.forecast.einsp[curKeyP];
        const allKeys = new Set([...Object.keys(pvByKey), ...Object.keys(einspByKey)]);
        const filteredKeys = isYearly ? [...allKeys].sort() : filterPeriodKeysByRange([...allKeys], rangeId);
        monthsData = filteredKeys.map((key) => ({
          key,
          values: { eigenverbrauch: Math.max(0, (pvByKey[key] || 0) - (einspByKey[key] || 0)), einspeisung: einspByKey[key] || 0 },
          isForecast: !(key in pvRealByKey),
          ...(key === curKeyP && key in pvRealByKey && (pvByKey[key] || 0) > pvRealByKey[key] + 0.01
            ? { actualValues: { eigenverbrauch: Math.max(0, pvRealByKey[key] - (einspRealByKey[key] || 0)), einspeisung: einspRealByKey[key] || 0 } }
            : {}),
        }));
      }

      const seriesFilterId = renderSeriesFilterToggle(`${containerId}-main`, `${containerId}-main-seriesfilter`, series, () => renderStacked());
      const activeSeries = applySeriesFilter(series, seriesFilterId);
      if (isYearly) {
        renderYearlyBarChart(`${containerId}-main-chart`, groupIntoYears(monthsData, activeSeries), activeSeries, unit);
      } else if (isDaily) {
        renderStackedBarChart(`${containerId}-main-chart`, monthsData, activeSeries, unit,
          "nur echte Tageswerte, keine Hochrechnung", dayLabel);
      } else {
        renderStackedBarChart(`${containerId}-main-chart`, monthsData, activeSeries, unit);
      }
    };
    renderChartRangeSelector(`${containerId}-main`, `${containerId}-main-range`, "ytd", renderStacked);
    renderViewModeToggle(`${containerId}-main`, `${containerId}-main-viewmode`, () => renderStacked(),
      [{ id: "daily", label: "📆 Täglich" }]);
    renderStacked();
    if (isElecIn) {
      // STROM-EINKAUF (Netzbezug) als eigener Chart -- dieselben Werte, auf
      // denen Abschlag und Jahresabrechnung beruhen, getrennt vom
      // Hausverbrauch (der auch PV und Speicher enthält).
      const einkaufSeries = [{ key: "bezug", label: "Strom-Einkauf", color: chartPalette().orange }];
      const renderEinkauf = async (rangeId) => {
        rangeId = rangeId || meterChartRange[`${containerId}-einkauf`] || "ytd";
        const mode = meterChartViewMode[`${containerId}-einkauf`];
        const target = `${containerId}-einkauf-chart`;
        if (mode === "daily") {
          const days = (await (await authedFetch("/api/pv/daily")).json()).days || [];
          const byKey = Object.fromEntries(days.map((d) => [d.key, d.bezug || 0]));
          const keys = filterPeriodKeysByRange(Object.keys(byKey), rangeId);
          renderStackedBarChart(target, keys.map((k) => ({ key: k, values: { bezug: byKey[k] } })), einkaufSeries, unit,
            "nur echte Tageswerte, keine Hochrechnung", dayLabel);
          return;
        }
        const res = await (await authedFetch("/api/meters/elec_in/monthly")).json();
        const real = res.monthly || {};
        const fc = res.forecast || {};
        const all = { ...real, ...fc };   // Prognose enthält auch die Hochrechnung des laufenden Monats
        if (mode === "yearly") {
          const monthsData = Object.keys(all).sort().map((k) => ({ key: k, values: { bezug: all[k] || 0 } }));
          renderYearlyBarChart(target, groupIntoYears(monthsData, einkaufSeries), einkaufSeries, unit);
          return;
        }
        const curKey = localMonthKey();
        const monthsData = filterPeriodKeysByRange(Object.keys(all), rangeId).map((k) => {
          const entry = { key: k, values: { bezug: all[k] || 0 }, isForecast: !(k in real) };
          if (k === curKey && k in real && (fc[k] || 0) > real[k] + 0.01) entry.actualValues = { bezug: real[k] };
          return entry;
        });
        renderStackedBarChart(target, monthsData, einkaufSeries, unit);
      };
      renderChartRangeSelector(`${containerId}-einkauf`, `${containerId}-einkauf-range`, "ytd", renderEinkauf);
      renderViewModeToggle(`${containerId}-einkauf`, `${containerId}-einkauf-viewmode`, () => renderEinkauf(),
        [{ id: "daily", label: "📆 Täglich" }]);
      renderEinkauf();
    }
  } else {
    let gasTemps = null;
    if (meterType === "gas") {
      gasTemps = await (await authedFetch("/api/meters/gas/temperature")).json();
    }
    const baseTitle = isEinspeisung ? "Produktion" : isElecIn ? "Gesamtverbrauch"
                      : meterType === "gas" ? "Verbrauch & Temperatur" : "Verbrauch";
    // Bei Zeitraumwechsel die Daten in der passenden Auflösung NACHLADEN --
    // ein kurzer Zeitraum braucht Tages-/Wochenwerte, sonst bliebe nur ein
    // einzelner Balken übrig.
    const loadAndRender = async (rangeId) => {
      const res = await (await authedFetch(`/api/meters/${meterType}/monthly`)).json();
      const titleEl = document.getElementById(`${containerId}-main-title`);
      if (titleEl) {
        titleEl.textContent = chartTitleWithResolution(baseTitle);
      }
      // Rohwerte vom Server sind bei Gas immer m³ (die Kostenberechnung
      // dort braucht das) -- fürs Chart wird auf kWh umgerechnet, konsistent
      // mit den KPI-Kacheln und der Ablesungen-Tabelle oben.
      const convMonthly = Object.fromEntries(Object.entries(res.monthly || {}).map(([k, v]) => [k, toChartUnit(v, 1)]));
      const convForecast = Object.fromEntries(Object.entries(res.forecast || {}).map(([k, v]) => [k, toChartUnit(v, 1)]));
      renderSeriesFilterToggle(`${containerId}-main`, `${containerId}-main-seriesfilter`, [{ key: "verbrauch", label: baseTitle, color: chartPalette().teal }], () => {});
      if (meterChartViewMode[`${containerId}-main`] === "yearly") {
        const values = { ...convMonthly, ...convForecast };
        const monthsData = Object.keys(values).sort().map((key) => ({ key, values: { verbrauch: values[key] || 0 } }));
        const oneSeries = [{ key: "verbrauch", label: baseTitle, color: chartPalette().teal }];
        renderYearlyBarChart(`${containerId}-main-chart`, groupIntoYears(monthsData, oneSeries), oneSeries, chartUnit);
        return;
      }
      // Temperatur-Linie nur bei Monatsauflösung — die Klimamittel-Referenz
      // liegt ausschließlich als Monatswert vor.
      const temps = (res.effective_resolution === "month") ? gasTemps : null;
      renderMeterMainChart(`${containerId}-main-chart`, convMonthly, convForecast, chartUnit, temps);
    };
    renderChartRangeSelector(`${containerId}-main`, `${containerId}-main-range`, "ytd", loadAndRender);
    renderViewModeToggle(`${containerId}-main`, `${containerId}-main-viewmode`, () => loadAndRender());
    loadAndRender(meterChartRange[`${containerId}-main`] || "ytd");
  }

  if (meterType === "gas") {
    const currentRate = intervals.length ? intervals[intervals.length - 1].rate : null;
    renderChartRangeSelector(`${containerId}-daily`, `${containerId}-daily-range`, "ytd", () => renderDailyRateChart(`${containerId}-daily-chart`, intervals, currentRate, chartUnit));
    renderDailyRateChart(`${containerId}-daily-chart`, intervals, currentRate, chartUnit);
  }

  if (isEinspeisung) {
    renderChartRangeSelector(`${containerId}-aut`, `${containerId}-aut-range`, "ytd", () => renderAutarkieChart(`${containerId}-aut-chart`, autarkieMonths));
    renderAutarkieChart(`${containerId}-aut-chart`, autarkieMonths);
  } else {
    renderChartRangeSelector(`${containerId}-cum`, `${containerId}-cum-range`, "ytd", () => renderCumulativeChart(`${containerId}-cum-chart`, cumMonths));
    renderCumulativeChart(`${containerId}-cum-chart`, cumMonths);
  }

  document.getElementById(`${containerId}-date`).value = new Date().toISOString().slice(0, 10);

  // ---- Ablesung speichern ----
  document.getElementById(`${containerId}-add-form`).addEventListener("submit", async (e) => {
    e.preventDefault();
    const reading_date = document.getElementById(`${containerId}-date`).value;
    const value = parseGermanNumber(document.getElementById(`${containerId}-value`).value);
    const is_new_meter = document.getElementById(`${containerId}-new-meter`).checked;
    if (Number.isNaN(value)) return alert("Bitte einen gültigen Zählerstand eingeben.");
    const res = await authedFetch(`/api/meters/${meterType}/readings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reading_date, value, is_new_meter }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return alert(err.detail || "Fehler beim Speichern.");
    }
    loadMeterPage(meterType, containerId, title);
  });

  // Hinweis: Das direkte Loeschen einzelner Ablesungen laeuft jetzt ueber
  // die Event-Delegation im Verlaufs-Modal (siehe openReadingsHistory) --
  // die Buttons existieren nicht mehr inline auf dieser Seite selbst.

  // ---- Foto/PDF einlesen ----
  document.getElementById(`${containerId}-photo-btn`).addEventListener("click", async () => {
    const input = document.getElementById(`${containerId}-photo`);
    const resultDiv = document.getElementById(`${containerId}-photo-result`);
    if (!input.files.length) return (resultDiv.textContent = "Bitte zuerst eine Datei auswählen.");
    resultDiv.textContent = "Wird gelesen …";
    const formData = new FormData();
    formData.append("file", input.files[0]);
    const res = await authedFetch(`/api/meters/${meterType}/upload`, { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) {
      resultDiv.innerHTML = `<div class="healthcheck-item healthcheck-yellow"><p style="margin:0;font-size:0.85rem">${escHtml(data.detail || "Fehler beim Einlesen.")}</p></div>`;
      return;
    }
    resultDiv.innerHTML = `
      <p class="muted" style="margin:8px 0 4px">${escHtml(data.note)}</p>
      <label class="muted" style="font-size:0.8rem">Datum</label>
      <input type="date" id="${containerId}-photo-date" value="${data.suggested_date || new Date().toISOString().slice(0, 10)}" />
      <label class="muted" style="font-size:0.8rem">Zählerstand (${unit})</label>
      <input type="text" id="${containerId}-photo-value" inputmode="decimal" value="${data.suggested_value ?? ""}" placeholder="manuell eintragen" />
      <button type="button" id="${containerId}-photo-confirm" style="margin-top:8px">Als Ablesung übernehmen</button>
    `;
    document.getElementById(`${containerId}-photo-confirm`).addEventListener("click", async () => {
      const reading_date = document.getElementById(`${containerId}-photo-date`).value;
      const valueStr = document.getElementById(`${containerId}-photo-value`).value;
      const value = parseGermanNumber(valueStr);
      if (Number.isNaN(value)) return alert("Bitte einen gültigen Zählerstand eingeben.");
      const confirmRes = await authedFetch(`/api/meters/${meterType}/readings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reading_date, value, receipt_id: data.receipt_id }),
      });
      if (!confirmRes.ok) {
        const err = await confirmRes.json().catch(() => ({}));
        return alert(err.detail || "Fehler beim Speichern.");
      }
      input.value = "";
      loadMeterPage(meterType, containerId, title);
    });
  });

  // ---- Tarif-Einstellungen speichern ----
  document.getElementById(`${containerId}-settings-form`).addEventListener("submit", async (e) => {
    e.preventDefault();
    const num = (id) => parseGermanNumber(document.getElementById(id)?.value) || 0;
    const linkVal = document.getElementById(`${containerId}-s-link`).value;
    const payload = {
      anbieter: document.getElementById(`${containerId}-s-anbieter`).value || null,
      link_id: linkVal === "" ? null : Number(linkVal),
    };
    // Bei bestehender Verknüpfung kommt der Abschlag aus dem Vertrag -- nicht überschreiben
    if (!document.getElementById(`${containerId}-s-abschlag`).readOnly) payload.abschlag = num(`${containerId}-s-abschlag`);
    if (isEinspeisung) {
      payload.einspeisepreis = num(`${containerId}-s-einspeisepreis`);
    } else {
      payload.vertragsende = document.getElementById(`${containerId}-s-vertragsende`).value || null;
      payload.arbeitspreis = num(`${containerId}-s-arbeitspreis`);
      payload.grundpreis = num(`${containerId}-s-grundpreis`);
      if (meterType === "water") payload.entwaesserung_preis = num(`${containerId}-s-entwaesserung`);
      if (meterType === "gas") payload.brennwert = num(`${containerId}-s-brennwert`);
    }
    await authedFetch(`/api/meters/${meterType}/settings`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    loadMeterPage(meterType, containerId, title);
  });

  // Hinweis: Das Loeschen einzelner PV-Monate laeuft jetzt ebenfalls ueber
  // die Event-Delegation im Verlaufs-Modal (siehe openReadingsHistory) --
  // die Buttons existieren nicht mehr inline auf dieser Seite selbst.

  // ---- Viele Ablesungen auf einmal (intelligenter Import) ----
  initSmartImport(
    `${containerId}-smart`,
    () => "meter_readings",
    () => ({ meter_type: meterType }),
    () => loadMeterPage(meterType, containerId, title),
  );

  loadMeterSettlements(meterType, containerId, title);
  if (meterType === "gas") initGasWeatherLocation();
}

// ---------- Wetter-Standort für die Ist-Temperatur-Linie (Gas) ----------
async function initGasWeatherLocation() {
  const input = document.getElementById("gas-weather-location");
  const statusEl = document.getElementById("gas-weather-status");
  const refreshBtn = document.getElementById("gas-weather-refresh-btn");
  if (!input) return;

  const res = await authedFetch("/api/settings/weather_location");
  const { value } = await res.json();
  if (value) input.value = value;

  input.addEventListener("change", async () => {
    await authedFetch("/api/settings/weather_location", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: input.value.trim() || null }),
    });
    statusEl.innerHTML = '<p class="muted">Gespeichert — beim nächsten App-Start automatisch abgerufen, oder jetzt direkt per "Jetzt abrufen".</p>';
  });

  refreshBtn.addEventListener("click", async () => {
    if (!input.value.trim()) { statusEl.innerHTML = '<p style="color:var(--bad)">Bitte zuerst einen Standort eintragen.</p>'; return; }
    await authedFetch("/api/settings/weather_location", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: input.value.trim() }),
    });
    statusEl.innerHTML = '<p class="muted">Rufe Wetterdaten ab …</p>';
    const r = await authedFetch("/api/meters/gas/temperature/refresh", { method: "POST" });
    const data = await r.json();
    if (data.status === "ok") {
      statusEl.innerHTML = `<p style="color:var(--good)">✅ ${data.months_updated} Monat${data.months_updated === 1 ? "" : "e"} aktualisiert.</p>`;
      setTimeout(() => loadMeterPage("gas", "meter-page-gas", "🔥 Gas"), 1500);
    } else {
      statusEl.innerHTML = `<p style="color:var(--bad)">❌ ${escHtml(data.error || "Fehlgeschlagen.")}</p>`;
    }
  });
}

// ---------- Zappi/myenergi: Zugangsdaten & Sync (Auto laden) ----------
async function initZappiSettings() {
  if (document.getElementById("zappi-save-btn")?.dataset.wired) return;
  document.getElementById("zappi-save-btn").dataset.wired = "1";

  const serialInput = document.getElementById("zappi-hub-serial");
  const passwordInput = document.getElementById("zappi-hub-password");
  const zappiSerialInput = document.getElementById("zappi-serial");
  const statusEl = document.getElementById("zappi-status");
  if (!serialInput) return;

  const creds = await (await authedFetch("/api/zappi/credentials")).json();
  serialInput.value = creds.hub_serial || "";
  zappiSerialInput.value = creds.zappi_serial || "";
  if (creds.has_password) passwordInput.placeholder = "•••••••• (gespeichert, unverändert lassen zum Behalten)";

  const save = async () => {
    if (!passwordInput.value && !creds.has_password) {
      statusEl.innerHTML = '<p style="color:var(--bad)">Bitte ein Passwort eingeben.</p>';
      return;
    }
    await authedFetch("/api/zappi/credentials", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        hub_serial: serialInput.value.trim(),
        hub_password: passwordInput.value || "",
        zappi_serial: zappiSerialInput.value.trim(),
      }),
    });
    statusEl.innerHTML = '<p class="muted">Gespeichert.</p>';
    renderIntegrationsCardList();
  };

  document.getElementById("zappi-save-btn").addEventListener("click", save);

  document.getElementById("zappi-test-btn").addEventListener("click", async () => {
    statusEl.innerHTML = '<p class="muted">Teste Verbindung …</p>';
    const r = await authedFetch("/api/zappi/test-connection", { method: "POST" });
    const data = await r.json().catch(() => ({}));
    statusEl.innerHTML = r.ok
      ? `<p style="color:var(--good)">✅ Verbindung erfolgreich (Server: ${escHtml(data.server)}).</p>`
      : `<p style="color:var(--bad)">❌ ${escHtml(data.detail || "Verbindung fehlgeschlagen.")}</p>`;
  });

  const lastSyncEl = document.getElementById("zappi-last-sync");
  async function renderLastSync() {
    const info = await (await authedFetch("/api/zappi/last-sync")).json().catch(() => ({}));
    if (!info.timestamp) { lastSyncEl.textContent = ""; return; }
    const dt = new Date(info.timestamp);
    const formatted = dt.toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" });
    const icon = info.status === "error" ? "⚠️" : "✅";
    lastSyncEl.textContent = `${icon} Zuletzt synchronisiert: ${formatted}`;
  }
  renderLastSync();

  document.getElementById("zappi-sync-btn").addEventListener("click", async () => {
    statusEl.innerHTML = '<p class="muted">Synchronisiere …</p>';
    const r = await authedFetch("/api/zappi/sync", { method: "POST" });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      statusEl.innerHTML = `<p style="color:var(--bad)">❌ ${escHtml(data.detail || "Fehlgeschlagen.")}</p>`;
      renderLastSync();
      return;
    }
    statusEl.innerHTML = data.status === "nothing_to_sync"
      ? '<p class="muted">Bereits aktuell — keine neuen Tage.</p>'
      : `<p style="color:var(--good)">✅ ${data.added_days} Tag${data.added_days === 1 ? "" : "e"} aktualisiert, Gesamt: ${data.total_kwh} kWh.</p>`;
    renderLastSync();
  });
}

// ---------- Sungrow/iSolarCloud: Zugangsdaten, Verbindungstest, Rohdaten-Vorschau ----------
// ---------- Integrationen (Admin): Kartenuebersicht + "+"-Hinzufuegen-Fluss ----------
// Datengetriebene Liste, damit weitere Integrationen (laut Ankuendigung
// "hier kommen ggf. noch weitere") sich einfach ergaenzen lassen, ohne die
// Kartenlogik jedes Mal neu zu schreiben.
const INTEGRATION_TYPES = [
  {
    id: "zappi", icon: "🚗", name: "Zappi-Wallbox", category: "Wallbox",
    formId: "integration-form-zappi", credsUrl: "/api/zappi/credentials", statusField: "has_password",
    initFn: () => initZappiSettings(),
    countedInHousehold: true,
  },
  {
    id: "fronius", icon: "🔆", name: "Fronius (lokal)", category: "PV-Wechselrichter",
    formId: "integration-form-fronius", credsUrl: "/api/fronius/settings", statusField: "configured",
    initFn: () => initFroniusSettings(),
    countedInHousehold: false,
  },
  {
    id: "sungrow", icon: "☁️", name: "Sungrow / iSolarCloud", category: "PV-Wechselrichter",
    formId: "integration-form-sungrow", credsUrl: "/api/sungrow/v1/credentials", statusField: "has_password",
    initFn: () => initSungrowSettings(),
    countedInHousehold: false,
  },
];
// Vom Klick-Handler bei Bedarf frisch gelesen (siehe Kommentar dort) --
// nicht in der Closure des einmalig verdrahteten Listeners einfrieren,
// sonst zeigte "+" nach dem Hinzufuegen einer Integration weiterhin den
// veralteten Stand von vor dem allerersten Verdrahten.
let integrationTypesNotConfigured = [];

async function renderIntegrationsCardList() {
  const listEl = document.getElementById("integrations-list");
  const statuses = await Promise.all(
    INTEGRATION_TYPES.map((t) => authedFetch(t.credsUrl).then((r) => r.json()).catch(() => ({ has_password: false })))
  );

  const statusById = Object.fromEntries(INTEGRATION_TYPES.map((t, i) => [t.id, statuses[i]]));
  const configured = INTEGRATION_TYPES.filter((t, i) => statuses[i][t.statusField || "has_password"]);
  // Ehrlicher Status statt pauschal "Verbunden": liefert der Endpunkt ein
  // 'connected'-Feld (Sungrow), wird zwischen verbunden / pausiert /
  // nur eingerichtet unterschieden.
  const statusBadge = (t) => {
    const st = statusById[t.id] || {};
    if (st.login_blocked) return '<span style="color:var(--bad);font-size:0.78rem;margin-left:6px">⏸ Pausiert</span>';
    if ("connected" in st && !st.connected) return '<span class="muted" style="font-size:0.78rem;margin-left:6px">○ Eingerichtet, noch nicht verbunden</span>';
    return '<span style="color:var(--good);font-size:0.78rem;margin-left:6px">✅ Verbunden</span>';
  };
  integrationTypesNotConfigured = INTEGRATION_TYPES.filter((t, i) => !statuses[i][t.statusField || "has_password"]);

  listEl.innerHTML = configured.length === 0
    ? '<p class="muted" style="font-size:0.85rem">Noch keine Integration eingerichtet.</p>'
    : configured.map((t) => `
      <div class="contract-main" data-open-integration="${t.formId}" style="cursor:pointer">
        <span style="font-size:1.1rem">${t.icon}</span>
        <span class="contract-label">${escHtml(t.name)}</span>
        <span class="muted" style="font-size:0.78rem"> · ${t.category}</span>
        ${statusBadge(t)}
        ${t.countedInHousehold ? '<span style="color:var(--good);font-size:0.72rem;margin-left:6px">· Eingerechnet im Hausverbrauch</span>' : ""}
      </div>`).join("");

  listEl.querySelectorAll("[data-open-integration]").forEach((row) => {
    row.addEventListener("click", () => showIntegrationForm(row.dataset.openIntegration));
  });
  renderSecretsStatus();
  renderBankConnections();
}

// Wo liegen die Zugangsdaten wirklich? Ehrlich anzeigen statt annehmen.
async function renderSecretsStatus() {
  const el = document.getElementById("secrets-status");
  const installBtn = document.getElementById("secrets-install-btn");
  if (!el) return;
  const st = await (await authedFetch("/api/secrets/status")).json().catch(() => null);
  if (!st) { el.style.display = "none"; installBtn.style.display = "none"; return; }
  const missingModule = (st.error || "").includes("No module named 'keyring'");
  installBtn.style.display = missingModule ? "block" : "none";
  const nice = (k) => (k === "zappi_credentials" ? "Zappi" : "Sungrow");
  const names = (keys) => [...new Set(keys.map(nice))].join(", ");
  const anything = st.secured.length || st.in_database_plaintext.length || st.missing_on_this_device.length;
  if (!anything) { el.style.display = "none"; return; }
  let html, color = "var(--muted)";
  if (st.missing_on_this_device.length) {
    html = `⚠️ Auf diesem Gerät fehlen gespeicherte Zugangsdaten (${names(st.missing_on_this_device)}) — bitte in der jeweiligen Integration neu eingeben. Sie werden bewusst nicht mit der Datenbank mitkopiert.`;
    color = "var(--bad)";
  } else if (!st.available) {
    html = `⚠️ Kein Schlüsselbund verfügbar — Zugangsdaten (${names(st.in_database_plaintext)}) liegen in der Datenbank und damit auch im iCloud-Backup.`
      + (st.error ? `<br><span style="font-size:0.68rem;opacity:0.85">Grund: ${escHtml(st.error)}${st.python_version ? ` · Python ${escHtml(st.python_version)}` : ""}</span>` : "");
    color = "var(--bad)";
  } else if (st.in_database_plaintext.length) {
    html = `⚠️ Einige Zugangsdaten (${names(st.in_database_plaintext)}) konnten nicht ins Schlüsselbund verschoben werden und liegen noch in der Datenbank.`;
    color = "var(--bad)";
  } else {
    html = `🔒 Zugangsdaten liegen im ${st.keychain} — nicht in der Datenbank und nicht im iCloud-Backup.`;
  }
  el.style.color = color;
  el.innerHTML = html;
  el.style.display = "block";
}

async function loadIntegrationsAdmin() {
  await renderIntegrationsCardList();

  // Alle Formulare zunaechst verstecken -- nur per Klick (Karte oder
  // "+ Hinzufuegen"-Auswahl) eingeblendet, damit die Seite bei mehreren
  // Integrationen nicht sofort mit allen Formularen ueberladen ist.
  INTEGRATION_TYPES.forEach((t) => { document.getElementById(t.formId).style.display = "none"; });
  document.getElementById("integration-chooser").style.display = "none";

  const addBtn = document.getElementById("integration-add-btn");
  if (!addBtn.dataset.wired) {
    addBtn.dataset.wired = "1";
    addBtn.addEventListener("click", () => {
      const chooser = document.getElementById("integration-chooser");
      const optionsEl = document.getElementById("integration-chooser-options");
      const stillAvailable = integrationTypesNotConfigured;
      if (stillAvailable.length === 0) {
        optionsEl.innerHTML = '<p class="muted" style="font-size:0.8rem">Alle verfügbaren Integrationen sind bereits eingerichtet.</p>';
      } else {
        optionsEl.innerHTML = stillAvailable.map((t) =>
          `<button type="button" class="ghost-btn" data-choose-integration="${t.formId}">${t.icon} ${escHtml(t.name)}</button>`
        ).join("");
        optionsEl.querySelectorAll("[data-choose-integration]").forEach((btn) => {
          btn.addEventListener("click", () => showIntegrationForm(btn.dataset.chooseIntegration));
        });
      }
      chooser.style.display = chooser.style.display === "none" ? "block" : "none";
    });
  }

  // Formular-Logik einmalig verdrahten (Speichern/Testen/Sync) -- das
  // Ein-/Ausblenden selbst passiert unabhaengig davon in showIntegrationForm.
  INTEGRATION_TYPES.forEach((t) => t.initFn());
}

function showIntegrationForm(formId) {
  document.getElementById("integration-chooser").style.display = "none";
  INTEGRATION_TYPES.forEach((t) => {
    document.getElementById(t.formId).style.display = t.formId === formId ? "block" : "none";
  });
  document.getElementById(formId).scrollIntoView({ behavior: "smooth", block: "nearest" });
}

async function initSungrowSettings() {
  // Statisches HTML -- nur einmal verdrahten, sonst doppelte Listener bei
  // jedem erneuten Öffnen der Integrationen.
  if (document.getElementById("sungrow-save-btn")?.dataset.wired) return;
  document.getElementById("sungrow-save-btn").dataset.wired = "1";

  const $ = (id) => document.getElementById(id);
  const statusEl = $("sungrow-status");
  const lastSyncEl = $("sungrow-last-sync");

  async function loadCreds() {
    const c = await (await authedFetch("/api/sungrow/v1/credentials")).json();
    $("sungrow-appkey").value = c.appkey || "";
    $("sungrow-account").value = c.account || "";
    $("sungrow-ps-id").value = c.ps_id || "";
    if (c.has_access_key) $("sungrow-access-key").placeholder = "•••••••• (gespeichert, unverändert lassen zum Behalten)";
    if (c.has_rsa) $("sungrow-rsa").placeholder = "•••••••• (gespeichert, unverändert lassen zum Behalten)";
    if (c.has_password) $("sungrow-password").placeholder = "•••••••• (gespeichert, unverändert lassen zum Behalten)";
    if (c.login_blocked) {
      statusEl.innerHTML = '<p style="color:var(--bad)">⏸ Automatischer Abruf pausiert (Anmeldung abgelehnt). Zugangsdaten prüfen, dann „Verbindung testen".</p>';
    }
    return c;
  }
  async function renderLastSync() {
    const info = await (await authedFetch("/api/sungrow/v1/last-sync")).json().catch(() => ({}));
    if (!info.timestamp) { lastSyncEl.textContent = ""; return; }
    const formatted = new Date(info.timestamp).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" });
    lastSyncEl.textContent = `${info.status === "error" ? "⚠️" : "✅"} Zuletzt synchronisiert: ${formatted}${info.status === "error" ? ` — ${info.message}` : ""}`;
  }
  const todayHtml = (t) => `<p style="color:var(--good)">✅ Heute laut Sungrow: <strong>${fmtUnit(t.pv, "kWh")}</strong> PV · ${fmtUnit(t.einsp, "kWh")} Einspeisung · ${fmtUnit(t.bezug, "kWh")} Netzbezug · <strong>${fmtUnit(t.gesamt, "kWh")}</strong> Hausverbrauch ${t.gesamt_source === "sungrow" ? "(von Sungrow gemeldet)" : "(errechnet, ohne Batterie — Sungrow liefert den Wert für diese Anlage nicht)"}</p>
    <p class="muted" style="font-size:0.72rem;margin:2px 0 0">Zum Gegencheck mit den Tageswerten in der iSolarCloud-App vergleichen.</p>`;

  await loadCreds();
  renderLastSync();

  $("sungrow-save-btn").addEventListener("click", async () => {
    const r = await authedFetch("/api/sungrow/v1/credentials", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        appkey: $("sungrow-appkey").value.trim(),
        access_key: $("sungrow-access-key").value,
        rsa_public: $("sungrow-rsa").value,
        account: $("sungrow-account").value.trim(),
        password: $("sungrow-password").value,
        ps_id: $("sungrow-ps-id").value.trim(),
      }),
    });
    statusEl.innerHTML = r.ok ? '<p class="muted">Gespeichert. Jetzt „Verbindung testen".</p>' : '<p style="color:var(--bad)">Speichern fehlgeschlagen.</p>';
    $("sungrow-access-key").value = ""; $("sungrow-rsa").value = ""; $("sungrow-password").value = "";
    await loadCreds();
    renderIntegrationsCardList();
  });

  $("sungrow-test-btn").addEventListener("click", async () => {
    statusEl.innerHTML = '<p class="muted">Melde an (ein einzelner Versuch) …</p>';
    const r = await authedFetch("/api/sungrow/v1/test-connection", { method: "POST" });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      statusEl.innerHTML = `<p style="color:var(--bad)">❌ ${escHtml(data.detail || "Anmeldung fehlgeschlagen.")}</p>`;
      renderLastSync();
      return;
    }
    let html = '<p style="color:var(--good)">✅ Anmeldung erfolgreich.</p>';
    if (data.ps_id_saved) { $("sungrow-ps-id").value = data.ps_id_saved; html += `<p class="muted">Anlage erkannt (ID ${data.ps_id_saved}).</p>`; }
    if (data.plant_error) html += `<p style="color:var(--bad)">${escHtml(data.plant_error)}</p>`;
    if (data.today) html += todayHtml(data.today);
    if (data.today_error) html += `<p style="color:var(--bad)">${escHtml(data.today_error)}</p>`;
    statusEl.innerHTML = html;
    renderLastSync();
    renderIntegrationsCardList();
  });

  $("sungrow-repair-btn").addEventListener("click", async () => {
    if (!confirm("Hausverbrauch der bisher gespeicherten Tage mit dem Sungrow-Wert korrigieren? Je Tag ein Abruf bei Sungrow.")) return;
    statusEl.innerHTML = '<p class="muted">Frage die Tageswerte bei Sungrow ab …</p>';
    const r = await authedFetch("/api/sungrow/v1/repair-history", { method: "POST" });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { statusEl.innerHTML = `<p style="color:var(--bad)">❌ ${escHtml(d.detail || "Fehlgeschlagen.")}</p>`; return; }
    const list = (d.changes || []).slice(-10).map((c) => `${escHtml(c.day)}: ${fmtUnit(c.old, "kWh")} → ${fmtUnit(c.new, "kWh")}`).join("<br>");
    statusEl.innerHTML = `<p style="color:var(--good)">✅ ${d.fixed} Tag(e) korrigiert${d.missing?.length ? `, ${d.missing.length} ohne Sungrow-Wert unverändert` : ""}.</p>`
      + (list ? `<p class="muted" style="font-size:0.72rem;margin:2px 0 0">${list}</p>` : "");
  });

  $("sungrow-sync-btn").addEventListener("click", async () => {
    statusEl.innerHTML = '<p class="muted">Synchronisiere …</p>';
    const r = await authedFetch("/api/sungrow/v1/sync", { method: "POST" });
    const data = await r.json().catch(() => ({}));
    statusEl.innerHTML = r.ok ? todayHtml(data) : `<p style="color:var(--bad)">❌ ${escHtml(data.detail || "Fehlgeschlagen.")}</p>`;
    renderLastSync();
  });
}

// ---------- Manuell erfasste Abrechnungszeitpunkte je Zählerseite ----------
async function loadMeterSettlements(meterType, containerId, title) {
  const [allSettlements, sinceOverview] = await Promise.all([
    (await authedFetch("/api/energy/settlements")).json(),
    (await authedFetch("/api/energy/consumption-since-settlement")).json(),
  ]);
  const entries = allSettlements.filter((s) => s.meter_type === meterType);
  const since = sinceOverview[meterType];
  const unit = meterType === "elec_in" || meterType === "elec_out" ? "kWh" : "m³";

  const sinceEl = document.getElementById(`${containerId}-settlement-since`);
  if (since) {
    sinceEl.innerHTML = `
      <div class="stats"><div>
        <span class="label">Verbrauch seit ${new Date(since.since_date).toLocaleDateString("de-DE")}${since.settlement_note ? ` (${escHtml(since.settlement_note)})` : ""}</span>
        <span>${fmt(since.consumption).replace("€", unit)} · ${since.days} Tage</span>
      </div></div>`;
  } else if (entries.length > 0) {
    sinceEl.innerHTML = '<p class="muted" style="font-size:0.78rem">Verbrauch seit der letzten Abrechnung lässt sich gerade nicht berechnen (z.B. wegen eines dazwischenliegenden Zählerwechsels).</p>';
  } else {
    sinceEl.innerHTML = "";
  }

  const listEl = document.getElementById(`${containerId}-settlement-list`);
  if (!entries.length) {
    listEl.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Abrechnungszeitpunkte erfasst.</p>';
  } else {
    listEl.innerHTML = `<ul class="contract-list">${entries.map((s) => `
      <li>
        <div class="contract-main">
          <span class="contract-label">${new Date(s.settlement_date).toLocaleDateString("de-DE")}</span>
          ${s.note ? `<span class="muted" style="font-size:0.78rem">${escHtml(s.note)}</span>` : ""}
        </div>
        <button type="button" class="del-btn" data-delete-settlement="${s.id}" title="Löschen">🗑</button>
      </li>`).join("")}</ul>`;
    listEl.querySelectorAll("[data-delete-settlement]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Diesen Abrechnungszeitpunkt wirklich löschen?")) return;
        await authedFetch(`/api/energy/settlements/${btn.dataset.deleteSettlement}`, { method: "DELETE" });
        loadMeterSettlements(meterType, containerId, title);
      });
    });
  }

  document.getElementById(`${containerId}-settlement-add-btn`).addEventListener("click", async () => {
    const dateInput = document.getElementById(`${containerId}-settlement-date`);
    const noteInput = document.getElementById(`${containerId}-settlement-note`);
    if (!dateInput.value) { alert("Bitte ein Datum wählen."); return; }
    await authedFetch("/api/energy/settlements", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ meter_type: meterType, settlement_date: dateInput.value, note: noteInput.value || null }),
    });
    dateInput.value = "";
    noteInput.value = "";
    loadMeterSettlements(meterType, containerId, title);
  }, { once: true });
}

// ═══════════════════════════════════════════════════════════════
// INTELLIGENTER DATEI-IMPORT (Ollama-gestützt, lernt Spalten-Zuordnungen)
// ═══════════════════════════════════════════════════════════════

const SMART_IMPORT_FIELD_LABELS = {
  label: "Bezeichnung", amount: "Betrag", date: "Datum", provider: "Anbieter",
  category: "Kategorie", frequency: "Häufigkeit", contract_number: "Vertragsnummer",
  contract_end: "Vertragsende", current_value: "Aktueller Wert", type: "Art",
};

const SMART_IMPORT_SOURCE_LABELS = {
  learned: "✅ Gelerntes Schema (schon mal so importiert)",
  ai: "🧠 KI-Vorschlag",
  heuristic: "📋 Stichwort-Erkennung (kein Ollama erreichbar oder unsicher)",
};

function initSmartImport(prefix, getTarget, getExtraPayload = () => ({}), onImported = null) {
  const fileInput = document.getElementById(`${prefix}-file`);
  const resultDiv = document.getElementById(`${prefix}-result`);
  const analyzeBtn = document.getElementById(`${prefix}-analyze-btn`);
  if (!fileInput || !resultDiv || !analyzeBtn) return; // Abschnitt auf dieser Seite nicht vorhanden

  analyzeBtn.addEventListener("click", async () => {
    if (!fileInput.files.length) return (resultDiv.textContent = "Bitte zuerst eine Datei auswählen.");
    const target = getTarget();
    resultDiv.innerHTML = '<p class="muted">Datei wird analysiert …</p>';
    const formData = new FormData();
    formData.append("file", fileInput.files[0]);
    const res = await authedFetch(`/api/smart-import/${target}/analyze`, { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) {
      resultDiv.innerHTML = `<div class="healthcheck-item healthcheck-yellow"><p style="margin:0;font-size:0.85rem">${escHtml(data.detail || "Fehler beim Einlesen.")}</p></div>`;
      return;
    }
    renderSmartImportMapping(prefix, target, data, getExtraPayload, onImported);
  });
}

function renderSmartImportMapping(prefix, target, data, getExtraPayload = () => ({}), onImported = null) {
  const resultDiv = document.getElementById(`${prefix}-result`);
  const reverseMapping = {}; // Zielfeld -> Quellspalte, fürs Vorbelegen der Dropdowns
  Object.entries(data.mapping).forEach(([col, field]) => { reverseMapping[field] = col; });

  const fieldOptions = (selectedCol) => `
    <option value="">– ignorieren –</option>
    ${data.columns.map((col) => `<option value="${escHtml(col)}" ${col === selectedCol ? "selected" : ""}>${escHtml(col)}</option>`).join("")}
  `;

  resultDiv.innerHTML = `
    <p class="muted" style="margin:8px 0 4px;font-size:0.78rem">${SMART_IMPORT_SOURCE_LABELS[data.mapping_source] || ""}</p>
    <p class="muted" style="margin:0 0 10px;font-size:0.78rem">${data.row_count} Zeile(n) erkannt. Beispiel: ${escHtml(JSON.stringify(data.sample_rows[0] || {}))}</p>

    <div id="${prefix}-field-mapping">
      ${Object.entries(data.target_fields).map(([field, desc]) => `
        <label class="muted" style="font-size:0.78rem">${SMART_IMPORT_FIELD_LABELS[field] || field}${data.required_fields.includes(field) ? " *" : ""}</label>
        <select data-field="${field}">${fieldOptions(reverseMapping[field])}</select>
      `).join("")}
    </div>

    <label class="checkbox-label">
      <input type="checkbox" id="${prefix}-save-schema" checked />
      <span>Diese Zuordnung für künftige gleiche Dateien merken</span>
    </label>

    <button type="button" id="${prefix}-confirm-btn" style="margin-top:10px">Import starten</button>
  `;

  document.getElementById(`${prefix}-confirm-btn`).addEventListener("click", async () => {
    const mapping = {};
    resultDiv.querySelectorAll(`#${prefix}-field-mapping select`).forEach((sel) => {
      if (sel.value) mapping[sel.value] = sel.dataset.field;
    });
    const missing = data.required_fields.filter((f) => !Object.values(mapping).includes(f));
    if (missing.length > 0) {
      return alert(`Bitte noch zuordnen: ${missing.map((f) => SMART_IMPORT_FIELD_LABELS[f] || f).join(", ")}`);
    }
    const save_schema = document.getElementById(`${prefix}-save-schema`).checked;
    const res = await authedFetch(`/api/smart-import/${target}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ staging_id: data.staging_id, mapping, save_schema, ...getExtraPayload() }),
    });
    const result = await res.json();
    if (!res.ok) {
      alert(result.detail || "Fehler beim Import.");
      return;
    }
    resultDiv.innerHTML = `<p style="margin:0">✅ ${result.imported} importiert${result.skipped ? `, ${result.skipped} übersprungen` : ""}.</p>`;
    if (onImported) {
      onImported();
    } else {
      loadIncome();
      loadContracts();
      loadDashboard();
    }
  });
}

initSmartImport("smart-import-income", () => "income");
initSmartImport("smart-import-contracts", () => document.getElementById("smart-import-contracts-target").value);
initSmartImport("smart-import-pv", () => "pv_monthly", () => ({}), () => {
  loadMeterPage("elec_out", "meter-page-elec_out", "↑ Einspeisung");
  loadEnergyOverview();
});

// ═══════════════════════════════════════════════════════════════
// VORSORGE: RENTE
// ═══════════════════════════════════════════════════════════════

function fmtEur0(v) { return `${Math.round(v).toLocaleString("de-DE")} €`; }

function renderPensionGapChart(containerId, gap, showFinancingRelief = false) {
  const el = document.getElementById(containerId);
  // Deutlich flacher als zuvor und mit Rand oben/rechts, damit die
  // Ziel-Beschriftung nicht mehr aus dem Diagramm herausragt. Die
  // Schriftgrößen sind relativ zur viewBox — bei 700px Breite und dieser
  // Höhe entspricht font-size 13 ungefähr normaler Fließtextgröße.
  const W = 700, H = 52, padL = 4, padR = 4, barH = 22, barY = 22;
  const chartW = W - padL - padR;
  const statutory = gap.statutory_pension_monthly || 0;
  const priv = gap.private_pension_monthly_projected || 0;
  // Die Finanzierungs-Entlastung erscheint nur auf Haushalts-Ebene als
  // eigenes Segment — bei Einzelpersonen macht sie keinen Sinn, da sie ein
  // gemeinsamer Haushaltseffekt ist, keiner Person allein zurechenbar.
  const relief = showFinancingRelief ? (gap.expense_relief_monthly || 0) : 0;
  const target = gap.target_pension_monthly || 0;
  // Summe aus den Einzelteilen berechnen statt auf ein separates Gesamtfeld
  // zu vertrauen — sonst kippt die ganze Skalierung auf NaN, sobald das Feld
  // einmal fehlt, und das Diagramm bleibt leer.
  const maxVal = Math.max(target, statutory + priv + relief, 1);
  const scale = (v) => (v / maxVal) * chartW;

  const statutoryW = scale(statutory);
  const privateW = scale(priv);
  const reliefW = scale(relief);
  const targetX = padL + scale(target);
  const reachedW = statutoryW + privateW + reliefW;

  // Ziel-Beschriftung am Rand festhalten, damit sie bei einem Ziel ganz
  // rechts nicht abgeschnitten wird (genau das passierte vorher).
  const labelText = `Ziel ${fmtEur0(target)}`;
  const approxLabelHalfWidth = labelText.length * 3.4;
  const labelX = Math.min(Math.max(targetX, padL + approxLabelHalfWidth), W - padR - approxLabelHalfWidth);

  const cpGap = chartPalette();
  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
      <rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="5" fill="rgba(255,255,255,0.06)" />
      ${reachedW > 0 ? `
        <clipPath id="clip-${containerId}"><rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="5" /></clipPath>
        <g clip-path="url(#clip-${containerId})">
          <rect x="${padL}" y="${barY}" width="${statutoryW}" height="${barH}" fill="${cpGap.accent}">
            <title>Gesetzliche Rente: ${fmtEur0(statutory)}/Monat</title>
          </rect>
          <rect x="${padL + statutoryW}" y="${barY}" width="${privateW}" height="${barH}" fill="${cpGap.teal}">
            <title>Private Vorsorge: ${fmtEur0(priv)}/Monat</title>
          </rect>
          ${relief > 0 ? `
          <rect x="${padL + statutoryW + privateW}" y="${barY}" width="${reliefW}" height="${barH}" fill="${cpGap.warn}">
            <title>Abbezahlte Finanzierung: ${fmtEur0(relief)}/Monat</title>
          </rect>` : ""}
        </g>` : ""}
      <line x1="${targetX}" y1="${barY - 4}" x2="${targetX}" y2="${barY + barH + 4}" stroke="var(--text)" stroke-width="1.5" stroke-dasharray="3,2" />
      <text x="${labelX}" y="${barY - 8}" text-anchor="middle" font-size="13" fill="var(--text)">${labelText}</text>
    </svg>`;
}

function pensionLegendHTML(gap, showFinancingRelief = false) {
  const cpLegend = chartPalette();
  const parts = [
    `<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpLegend.accent};border-radius:2px;display:inline-block"></span>Gesetzlich ${fmtEur0(gap.statutory_pension_monthly)}</span>`,
  ];
  if (gap.private_pension_monthly_projected > 0) {
    parts.push(`<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpLegend.teal};border-radius:2px;display:inline-block"></span>Privat ${fmtEur0(gap.private_pension_monthly_projected)}</span>`);
  } else {
    parts.push(`<span class="muted">Privat: noch nichts hinterlegt</span>`);
  }
  if (showFinancingRelief && gap.expense_relief_monthly > 0) {
    parts.push(`<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpLegend.warn};border-radius:2px;display:inline-block"></span>Abbezahlte Finanzierung ${fmtEur0(gap.expense_relief_monthly)}</span>`);
  }
  if (gap.gap_monthly > 0) {
    parts.push(`<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:rgba(255,255,255,0.12);border-radius:2px;display:inline-block"></span>Lücke ${fmtEur0(gap.gap_monthly)}</span>`);
  }
  return `<div style="display:flex;gap:14px;flex-wrap:wrap;font-size:0.78rem;color:var(--muted);margin-top:6px">${parts.join("")}</div>`;
}

let vorsorgeActivePersonId = null;

async function loadVorsorgeDashboard() {
  await loadHaushaltSummary();
  await renderVorsorgeSummaryCards();
}

async function renderVorsorgeSummaryCards() {
  const el = document.getElementById("vorsorge-summary-cards");
  const data = await (await authedFetch("/api/vorsorge/rente")).json();
  const h = data.household;
  if (!h.gap_analysis) {
    el.innerHTML = '<p class="muted">Noch keine Berechnungsgrundlage — Einkommen mit Personen verknüpfen.</p>';
    return;
  }
  const g = h.gap_analysis;
  // Gesamtkapital heute UND zum Renteneintritt über alle Personen und all
  // ihre privaten Konten hinweg -- macht sichtbar, wie viel bereits
  // vorhanden ist und wohin es sich entwickelt, nicht nur die reine Lücke.
  let capitalToday = 0, capitalAtRetirement = 0;
  for (const p of data.persons) {
    for (const a of p.private_accounts) capitalToday += a.current_value || 0;
    if (p.capital_projection && p.capital_projection.length) {
      capitalAtRetirement += p.capital_projection[p.capital_projection.length - 1].capital;
    }
  }
  el.innerHTML = `
    <div><span class="label">Deckungsgrad</span><span style="color:${g.status === "green" ? "var(--good)" : g.status === "yellow" ? "var(--warn)" : "var(--bad)"}">${g.coverage_rate}%</span></div>
    <div><span class="label">Rente gesamt (gesetzl. + privat)</span><span>${fmtEur0(g.statutory_pension_monthly + g.private_pension_monthly_projected)}/Mo</span></div>
    <div><span class="label">Privates Kapital heute</span><span>${fmtEur0(capitalToday)}</span></div>
    <div><span class="label">Prognose bei Rente</span><span>${fmtEur0(capitalAtRetirement)}</span></div>
  `;
}

function cssVarToRgba(varName, alpha) {
  const hex = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
  return hex.startsWith("#") ? hexToRgba(hex, alpha) : hex;
}

async function loadHaushaltSummary() {
  const container = document.getElementById("vorsorge-haushalt-content");
  container.innerHTML = '<p class="muted">Lade …</p>';
  const data = await (await authedFetch("/api/vorsorge/rente")).json();
  const h = data.household;

  if (!h.gap_analysis) {
    container.innerHTML = `
      <section class="card">
        <h3 style="margin:0 0 4px;font-size:0.95rem;color:var(--accent)">Familieneinkommen</h3>
        <p class="muted" style="margin:0;font-size:0.82rem">Noch kein Einkommen mit Personen verknüpft — die Haushaltsübersicht braucht mindestens eine Person mit Einkommen.</p>
      </section>`;
    return;
  }

  const g = h.gap_analysis;
  const statusColor = g.status === "green" ? "var(--good)" : g.status === "yellow" ? "var(--warn)" : "var(--bad)";
  const financingWithPayoff = h.financing.filter((f) => f.paid_off_before_retirement);
  const financingWithoutPayoff = h.financing.filter((f) => !f.paid_off_before_retirement);
  // Alter IM jeweiligen Tilgungsjahr (nicht das heutige Alter!) — jede
  // Finanzierung kann ein anderes Tilgungsjahr haben, deshalb pro Eintrag
  // statt einmal gemeinsam für alle.
  const agesAtPayoffLabel = (f) => f.ages_at_payoff && f.ages_at_payoff.length
    ? ` (Alter ${f.payoff_year}: ${f.ages_at_payoff.map((p) => `${escHtml(p.person_name)} ${p.age}`).join(", ")})`
    : "";

  container.innerHTML = `
    <section class="card">
      <div class="row-actions" style="justify-content:space-between;align-items:baseline;flex-wrap:wrap">
        <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Familieneinkommen zusammen</h3>
        <span style="font-size:1.15rem;font-weight:700;color:${statusColor}">${g.coverage_rate}% gedeckt</span>
      </div>
      <p class="muted" style="margin:2px 0 12px;font-size:0.78rem">${fmtEur0(h.net_income_monthly)}/Mo Netto gemeinsam · Zielrente ${fmtEur0(g.target_pension_monthly)}/Mo (80% davon)</p>

      <div id="haushalt-gap-chart"></div>
      ${pensionLegendHTML(g, true)}
      <p class="settle-sub" style="margin:10px 0 0">
        ${g.gap_monthly > 0
          ? `Es fehlen <b class="settle-red">${fmtEur0(g.gap_monthly)}/Monat</b> bis zur Zielrente.`
          : `<b class="settle-ok">Ziel erreicht</b> — ${fmtEur0(-g.gap_monthly)}/Monat Puffer.`}
      </p>

      ${financingWithPayoff.length ? `
        <div style="background:${cssVarToRgba("--good", 0.08)};border-radius:8px;padding:8px 10px;margin-top:10px;font-size:0.78rem">
          🏠 ${financingWithPayoff.map((f) => `${escHtml(f.label)} ist laut Tilgungsplan ${f.payoff_year} abbezahlt${agesAtPayoffLabel(f)}`).join(", ")} — zählt oben als ${fmtEur0(g.expense_relief_monthly)}/Mo zusätzliche "Einnahme", da diese Rate dann wegfällt.
        </div>` : ""}
      ${financingWithoutPayoff.length ? `
        <div style="background:${cssVarToRgba("--warn", 0.08)};border-radius:8px;padding:8px 10px;margin-top:8px;font-size:0.78rem">
          💡 ${financingWithoutPayoff.map((f) => f.calculation_error ? `${escHtml(f.label)}: ${escHtml(f.calculation_error)}` : `${escHtml(f.label)}: laut Tilgungsplan erst ${f.payoff_year || "nach der Rente"} abbezahlt${agesAtPayoffLabel(f)}`).join(" · ")}
        </div>` : ""}
    </section>`;
  renderPensionGapChart("haushalt-gap-chart", g, true);
}

async function fetchVorsorgeDataOnce() {
  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  if (!vorsorgeLastRenteData || !vorsorgeLastRisikoData) {
    const [renteData, risikoData] = await Promise.all([
      authedFetch("/api/vorsorge/rente").then((r) => r.json()),
      authedFetch("/api/vorsorge/risiko").then((r) => r.json()),
    ]);
    vorsorgeLastRenteData = renteData;
    vorsorgeLastRisikoData = risikoData;
  }
  return { renteData: vorsorgeLastRenteData, risikoData: vorsorgeLastRisikoData };
}

function wirePersonTabs(tabsEl, persons, onSwitch) {
  if (!vorsorgeActivePersonId || !persons.some((p) => p.person_id === vorsorgeActivePersonId)) {
    vorsorgeActivePersonId = persons[0].person_id;
  }
  tabsEl.innerHTML = persons.map((p) => `
    <button type="button" class="mode-btn${p.person_id === vorsorgeActivePersonId ? " active" : ""}" data-person-tab="${p.person_id}">${escHtml(p.person_name)}</button>
  `).join("");
  tabsEl.querySelectorAll("[data-person-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      vorsorgeActivePersonId = parseInt(btn.dataset.personTab, 10);
      tabsEl.querySelectorAll("[data-person-tab]").forEach((b) => b.classList.toggle("active", b === btn));
      onSwitch();
    });
  });
}

async function loadAufbauTab() {
  const tabsEl = document.getElementById("vorsorge-aufbau-person-tabs");
  const contentEl = document.getElementById("vorsorge-aufbau-content");
  contentEl.innerHTML = '<p class="muted">Lade …</p>';
  const { renteData } = await fetchVorsorgeDataOnce();

  if (renteData.persons.length === 0) {
    tabsEl.innerHTML = "";
    contentEl.innerHTML = '<section class="card"><p class="muted">Noch keine Elternteile als Personen angelegt. Über "👪 Personen verwalten" oben anlegen (Rolle "Elternteil").</p></section>';
    return;
  }
  wirePersonTabs(tabsEl, renteData.persons, () => renderAufbauPersonCard(vorsorgeLastRenteData));
  renderAufbauPersonCard(renteData);
}

async function loadAbsicherungTab() {
  const tabsEl = document.getElementById("vorsorge-absicherung-person-tabs");
  const contentEl = document.getElementById("vorsorge-absicherung-person-content");
  contentEl.innerHTML = '<p class="muted">Lade …</p>';
  const { renteData, risikoData } = await fetchVorsorgeDataOnce();
  renderVorsorgeAbsicherungSummaryCards(risikoData);

  if (renteData.persons.length === 0) {
    tabsEl.innerHTML = "";
    contentEl.innerHTML = "";
    renderRiskSharedContent(risikoData);
    return;
  }
  wirePersonTabs(tabsEl, renteData.persons, () => renderAbsicherungPersonCard(vorsorgeLastRenteData, vorsorgeLastRisikoData));
  renderAbsicherungPersonCard(renteData, risikoData);
  renderRiskSharedContent(risikoData);
}

function renderVorsorgeAbsicherungSummaryCards(risikoData) {
  const el = document.getElementById("vorsorge-absicherung-summary-cards");
  const toMonthly = (amount, freq) => freq === "yearly" ? amount / 12 : freq === "quarterly" ? amount / 3 : amount;
  let totalMonthly = 0, count = 0;
  for (const g of risikoData.groups) {
    for (const e of g.entries) {
      totalMonthly += toMonthly(e.amount, e.frequency);
      count++;
    }
  }
  el.innerHTML = `
    <div><span class="label">Versicherungen gesamt</span><span>${count}</span></div>
    <div><span class="label">Prämien gesamt</span><span>${fmtEur0(totalMonthly)}/Mo</span></div>
    <div><span class="label">Häufig empfohlene vorhanden</span><span style="color:${risikoData.essential_present === risikoData.essential_total ? "var(--good)" : "var(--warn)"}">${risikoData.essential_present}/${risikoData.essential_total}</span></div>
  `;
}

let vorsorgeLastRenteData = null;
let vorsorgeLastRisikoData = null;

function renderAufbauPersonCard(renteData) {
  const contentEl = document.getElementById("vorsorge-aufbau-content");
  const p = renteData.persons.find((x) => x.person_id === vorsorgeActivePersonId);
  if (!p) return;

  // Private Vorsorge nach Variante gruppieren statt einer flachen Liste —
  // Riester hat eigene Zulagen-Logik und unterscheidet sich grundlegend von
  // sonstiger privater Vorsorge (ETF-Sparplan, klassische Rentenversicherung
  // etc.), das verdient eine eigene Überschrift statt nur eines Tags.
  const riesterAccounts = p.private_accounts.filter((a) => a.is_riester);
  const otherPrivateAccounts = p.private_accounts.filter((a) => !a.is_riester);

  const accountRow = (a, typeLabel) => `
    <li data-pension-row="${a.id}" style="cursor:context-menu;flex-direction:column;align-items:stretch;gap:4px">
      <div class="row-actions" style="justify-content:space-between">
        <span>${rowMenuButtonHTML("pension", a.id)} <b>${escHtml(a.label)}</b>${a.provider && a.provider !== a.label ? ` · ${escHtml(a.provider)}` : ""}</span>
        <span style="font-weight:600">${fmtEur0(typeLabel === "Gesetzlich" ? (a.projected_monthly_at_67 || 0) : a.projected_monthly)}/Mo</span>
      </div>
      <div class="row-actions muted" style="font-size:0.72rem;justify-content:space-between;flex-wrap:wrap">
        <span>
          ${typeLabel !== "Gesetzlich" ? `Angespart: ${fmtEur0(a.current_value || 0)} · Prognose 67: ${fmtEur0(a.projected_capital_at_67)}` : ""}
          ${a.linked_contract_id ? " · verknüpft mit Vertrag" : (a.monthly_contribution ? ` · ${fmtEur0(a.monthly_contribution)}/Mo Beitrag` : "")}
          ${a.return_rate_assumption ? ` · ${(a.return_rate_assumption * 100).toLocaleString("de-DE", { maximumFractionDigits: 2 })}% p.a. angenommen` : ""}
        </span>
        ${a.disability_pension_monthly ? `<span>+ ${fmtEur0(a.disability_pension_monthly)}/Mo Erwerbsminderungsrente</span>` : ""}
      </div>
    </li>`;

  const accountsSection = (title, accounts, typeLabel, addKey, icon) => `
    <h4 style="margin:16px 0 8px;font-size:0.85rem;color:var(--accent)">${icon} ${title}</h4>
    ${accounts.length === 0 ? '<p class="muted" style="font-size:0.8rem">Noch nichts hinterlegt.</p>' : `<ul>${accounts.map((a) => accountRow(a, typeLabel)).join("")}</ul>`}
    <button type="button" class="ghost-btn" style="width:100%;margin-top:4px" data-add-pension="${addKey}" data-add-pension-person="${p.person_id}">+ ${title === "Gesetzliche Rente" ? "Gesetzliche Rente" : "Private Vorsorge"} hinzufügen</button>`;

  contentEl.innerHTML = `
    <section class="card" data-person-card="${p.person_id}">
      <div class="row-actions" style="justify-content:space-between;flex-wrap:wrap;align-items:baseline">
        <h3 style="margin:0">${escHtml(p.person_name)}${p.gap_analysis ? ` <span style="font-size:1rem;font-weight:700;color:${p.gap_analysis.status === "green" ? "var(--good)" : p.gap_analysis.status === "yellow" ? "var(--warn)" : "var(--bad)"}">${p.gap_analysis.coverage_rate}% gedeckt</span>` : ""}</h3>
        <div class="row-actions" style="gap:8px">
          <label class="muted" style="font-size:0.75rem">Geburtsdatum</label>
          <input type="date" data-birth-date="${p.person_id}" value="${p.birth_date || ""}" style="width:auto" />
        </div>
      </div>
      <p class="muted" style="font-size:0.78rem;margin:4px 0 12px">
        ${fmtEur0(p.net_income_monthly)}/Mo Netto
        ${p.years_until_retirement != null ? ` · noch ${Math.round(p.years_until_retirement)} Jahre bis 67` : " · Geburtsdatum fehlt (private Vorsorge kann nicht hochgerechnet werden)"}
      </p>

      <h4 style="margin:0 0 8px;font-size:0.85rem;color:var(--accent)">👴 Versorgungslücke gesamt</h4>
      ${p.gap_analysis ? `
        <div id="gap-chart-${p.person_id}"></div>
        <div class="row-actions" style="justify-content:space-between;flex-wrap:wrap;margin-top:6px">
          ${pensionLegendHTML(p.gap_analysis)}
          <p class="settle-sub" style="margin:0">
            ${p.gap_analysis.gap_monthly > 0
              ? `Es fehlen <b class="settle-red">${fmtEur0(p.gap_analysis.gap_monthly)}/Monat</b>.`
              : `<b class="settle-ok">Ziel erreicht</b> — ${fmtEur0(-p.gap_analysis.gap_monthly)}/Monat Puffer.`}
          </p>
        </div>
      ` : '<p class="muted" style="font-size:0.8rem">Kein Nettoeinkommen hinterlegt — Versorgungslücke kann nicht berechnet werden.</p>'}

      ${accountsSection("Gesetzliche Rente", p.statutory_accounts, "Gesetzlich", "gesetzlich", "🏛️")}
      ${accountsSection("Riester-Rente", riesterAccounts, "Privat", "privat", "🎁")}
      ${accountsSection("Sonstige private Vorsorge", otherPrivateAccounts, "Privat", "privat", "💰")}

      ${p.capital_projection && p.capital_projection.length > 1 ? `
        <h4 style="margin:16px 0 8px;font-size:0.85rem;color:var(--accent)">📈 Kapitalverlauf bis zur Rente</h4>
        <p class="muted" style="font-size:0.72rem;margin:0 0 8px">Zinseszins auf den heutigen Bestand plus laufende Beiträge, angenommene Rendite je Konto — grobe Hochrechnung, keine Garantie.</p>
        <div id="capital-projection-chart-${p.person_id}"></div>
      ` : ""}

      <p class="muted" style="font-size:0.72rem;margin:12px 0 0">Rechtsklick oder ⋯ auf einen Eintrag für Details, Beleg &amp; Löschen.</p>
    </section>
  `;

  if (p.gap_analysis) renderPensionGapChart(`gap-chart-${p.person_id}`, p.gap_analysis);
  if (p.capital_projection && p.capital_projection.length > 1) {
    const cpProj = chartPalette();
    renderInteractiveMultiLineChart(
      document.getElementById(`capital-projection-chart-${p.person_id}`),
      p.capital_projection,
      [{ key: "capital", label: "Privates Kapital", color: cpProj.primary, width: 2.5 }],
      { height: 170, yFormat: fmtEur0, xLabel: (pt) => pt.year }
    );
  }

  contentEl.querySelectorAll("[data-birth-date]").forEach((input) => {
    input.addEventListener("change", async () => {
      await authedFetch(`/api/family-members/${input.dataset.birthDate}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ birth_date: input.value || null }),
      });
      vorsorgeLastRenteData = null;
      vorsorgeLastRisikoData = null;
      loadHaushaltSummary();
      loadAufbauTab();
    });
  });
  contentEl.querySelectorAll("[data-add-pension]").forEach((btn) => {
    btn.addEventListener("click", () => openPensionForm(null, btn.dataset.addPension, btn.dataset.addPensionPerson));
  });
  contentEl.querySelectorAll("[data-pension-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuPensionId = row.dataset.pensionRow;
      showPensionContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(contentEl, "pension", (id, x, y) => {
    contextMenuPensionId = id;
    showPensionContextMenu(x, y);
  });
}

function renderAbsicherungPersonCard(renteData, risikoData) {
  const contentEl = document.getElementById("vorsorge-absicherung-person-content");
  const p = renteData.persons.find((x) => x.person_id === vorsorgeActivePersonId);
  if (!p) return;
  const riskByPerson = {};
  (risikoData.persons_summary || []).forEach((x) => { riskByPerson[x.person_id] = x; });
  const risk = riskByPerson[p.person_id];

  contentEl.innerHTML = `
    <section class="card">
      <h3 style="margin:0 0 10px">${escHtml(p.person_name)}</h3>
      ${risk ? `
        ${renderRiskAssessmentLine("Berufsunfähigkeit", risk.bu, "monthly", risk.bu_em_combination)}
        ${renderRiskAssessmentLine("Risikoleben", risk.rlv, "sum")}
      ` : '<p class="muted" style="font-size:0.8rem">Keine Einkommensdaten hinterlegt — Absicherungsbedarf kann nicht berechnet werden.</p>'}
    </section>
  `;
  pendingRiskCharts.forEach((fn) => fn());
  pendingRiskCharts = [];
}

// ---------- Rentenkonto anlegen/bearbeiten (richtiges Formular-Overlay) ----------
const pensionFormOverlay = document.getElementById("pension-form-overlay");

function updatePensionDirectValueVisibility() {
  const useDirect = document.getElementById("pension-use-direct-value").checked;
  document.getElementById("pension-direct-value-group").style.display = useDirect ? "block" : "none";
}

document.getElementById("pension-use-direct-value").addEventListener("change", updatePensionDirectValueVisibility);

function updatePensionContributionLockState() {
  const linkedId = document.getElementById("pension-linked-contract").value;
  const contributionInput = document.getElementById("pension-contribution");
  const hint = document.getElementById("pension-linked-contract-hint");
  const documentGroup = document.getElementById("pension-document-group");
  if (linkedId) {
    const contract = allContracts.find((c) => String(c.id) === linkedId);
    contributionInput.value = contract ? contract.monthly_amount : "";
    contributionInput.disabled = true;
    hint.style.color = "var(--accent)";
    if (documentGroup) documentGroup.style.display = "none";
  } else {
    contributionInput.disabled = false;
    hint.style.color = "";
    if (documentGroup) documentGroup.style.display = "block";
  }
}

document.getElementById("pension-linked-contract").addEventListener("change", updatePensionContributionLockState);

document.getElementById("pension-analyze-document-btn").addEventListener("click", async () => {
  const fileInput = document.getElementById("pension-document");
  const suggestionBox = document.getElementById("pension-document-suggestion");
  if (!fileInput.files.length) {
    alert("Bitte zuerst eine Datei auswählen.");
    return;
  }
  suggestionBox.style.display = "block";
  suggestionBox.innerHTML = '<span class="muted">Lese Beleg …</span>';

  const fd = new FormData();
  fd.append("file", fileInput.files[0]);
  const res = await authedFetch("/api/pension-accounts/analyze-document", { method: "POST", body: fd });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    suggestionBox.innerHTML = `<span class="settle-red">${escHtml(err.detail || "Beleg konnte nicht gelesen werden.")}</span>`;
    return;
  }
  const result = await res.json();
  const form = document.getElementById("pension-form");
  form.dataset.documentStagingId = result.staging_id;
  form.dataset.documentOriginalFilename = result.original_filename;

  if (result.ocr_error) {
    suggestionBox.innerHTML = `<span class="settle-red">${escHtml(result.ocr_error)}</span> — Datei wird trotzdem beim Speichern angehängt, Werte bitte manuell eintragen.`;
    return;
  }
  if (result.suggested_monthly_amount == null) {
    suggestionBox.innerHTML = 'Kein Rentenbetrag im Beleg gefunden. Datei wird beim Speichern trotzdem angehängt — bitte Werte manuell eintragen.';
    return;
  }

  const isStatutory = form.dataset.type === "gesetzlich";
  const applyBtnId = "pension-apply-suggestion-btn";
  suggestionBox.innerHTML = `
    ✨ Gefunden: <b>${fmtEur0(result.suggested_monthly_amount)}/Monat</b>${result.provider ? ` bei ${escHtml(result.provider)}` : ""}
    ${result.all_amounts_found.length > 1 ? `<br><span class="muted">Weitere gefundene Beträge: ${result.all_amounts_found.filter((a) => a !== result.suggested_monthly_amount).map(fmtEur0).join(", ")}</span>` : ""}
    <br><button type="button" id="${applyBtnId}" class="ghost-btn" style="width:100%;margin-top:6px;font-size:0.75rem">✅ Übernehmen</button>
  `;
  document.getElementById(applyBtnId).addEventListener("click", () => {
    if (isStatutory) {
      document.getElementById("pension-projected").value = result.suggested_monthly_amount;
    } else {
      document.getElementById("pension-use-direct-value").checked = true;
      updatePensionDirectValueVisibility();
      document.getElementById("pension-projected-private").value = result.suggested_monthly_amount;
    }
    if (result.provider && !document.getElementById("pension-provider").value) {
      document.getElementById("pension-provider").value = result.provider;
    }
  });
});

document.getElementById("pension-form-cancel-btn").addEventListener("click", () => {
  pensionFormOverlay.style.display = "none";
});

let pensionFormDocsCache = null;

document.getElementById("pension-show-documents-btn").addEventListener("click", () => {
  const section = document.getElementById("pension-documents-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) {
    section.style.display = "none";
    return;
  }
  const accountId = document.getElementById("pension-form").dataset.accountId;
  section.style.display = "block";
  const docs = pensionFormDocsCache || [];
  if (docs.length === 0) {
    section.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Dokumente hinterlegt.</p>';
    return;
  }
  section.innerHTML = '<div id="pension-documents-list"></div>';
  setupScrollableDocList("pension-documents-list", docs, (d) => resolveDocDate(d), (filtered, ul) => {
    ul.innerHTML = filtered.map((d) => {
      const isFromContract = d.source === "contract";
      const baseUrl = isFromContract ? `/api/receipts/${d.id}/file` : `/api/pension-documents/${d.id}`;
      return `
      <li data-pension-doc-row="${d.id}">
        <a href="${baseUrl}" rel="noopener" data-view-doc-url="${baseUrl}" data-view-doc-title="${escHtml(d.original_filename || "Dokument")}">📎 ${escHtml(d.original_filename || "Dokument")}</a>
        <span class="row-actions">
          <span class="muted" style="font-size:0.72rem">${resolveDocDate(d) || ""}</span>
          <a href="${baseUrl}?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
          ${isFromContract
            ? '<span class="tag" title="Wird über den verknüpften Vertrag unter Ausgaben verwaltet">Vertrag</span>'
            : `<button type="button" class="del-btn" data-delete-pension-doc="${d.id}" title="Löschen">🗑</button>`}
        </span>
      </li>`;
    }).join("");
    wireDocumentViewerLinks(ul);
    ul.querySelectorAll("[data-delete-pension-doc]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        if (!confirm("Dieses Dokument wirklich löschen?")) return;
        await authedFetch(`/api/pension-documents/${btn.dataset.deletePensionDoc}`, { method: "DELETE" });
        const form = document.getElementById("pension-form");
        const type = form.dataset.type;
        const personId = form.dataset.personId;
        await openPensionForm(accountId, type, personId);
        document.getElementById("pension-show-documents-btn").click();
      });
    });
  });
});

async function openPensionForm(accountId, type, personId) {
  let account = null;
  document.getElementById("pension-is-riester").checked = false;
  if (accountId) {
    const all = await (await authedFetch("/api/vorsorge/rente")).json();
    for (const p of all.persons) {
      const stat = p.statutory_accounts.find((a) => String(a.id) === String(accountId));
      const priv = p.private_accounts.find((a) => String(a.id) === String(accountId));
      if (stat) { account = stat; type = "gesetzlich"; personId = p.person_id; break; }
      if (priv) { account = priv; type = "privat"; personId = p.person_id; break; }
    }
  }

  const isStatutory = type === "gesetzlich";
  const form = document.getElementById("pension-form");
  form.reset();
  form.dataset.accountId = accountId || "";
  form.dataset.type = type;
  form.dataset.personId = personId;
  form.dataset.documentStagingId = "";
  form.dataset.documentOriginalFilename = "";
  document.getElementById("pension-document-suggestion").style.display = "none";

  document.getElementById("pension-form-title").textContent =
    `${accountId ? "Bearbeiten" : "Neu"}: ${isStatutory ? "Gesetzliche Rente" : "Private Vorsorge"}`;
  document.getElementById("pension-statutory-fields").style.display = isStatutory ? "block" : "none";
  document.getElementById("pension-private-fields").style.display = isStatutory ? "none" : "block";

  const docLabel = document.getElementById("pension-document-label");
  const showDocsBtn = document.getElementById("pension-show-documents-btn");
  const docsSection = document.getElementById("pension-documents-section");
  docsSection.style.display = "none";
  docsSection.innerHTML = "";
  pensionFormDocsCache = null;

  if (accountId) {
    showDocsBtn.style.display = "block";
    const docs = await (await authedFetch(`/api/pension-accounts/${accountId}/documents`)).json();
    pensionFormDocsCache = docs;
    docLabel.textContent = docs.length > 0 ? "Weiteres Dokument hinzufügen" : "Dokument (optional, z.B. Renteninformation)";
  } else {
    // Ein noch nicht gespeichertes, neues Konto hat zwangsläufig keine
    // Dokument-Historie — der Button wäre hier nur eine leere Sackgasse.
    showDocsBtn.style.display = "none";
    docLabel.textContent = "Dokument (optional, z.B. Renteninformation)";
  }

  if (account) {
    document.getElementById("pension-label").value = account.label || "";
    document.getElementById("pension-provider").value = account.provider || "";
    document.getElementById("pension-note").value = account.note || "";
    if (isStatutory) {
      document.getElementById("pension-projected").value = account.projected_monthly_at_67 != null ? formatAmountForInput(account.projected_monthly_at_67) : "";
      document.getElementById("pension-disability").value = account.disability_pension_monthly != null ? formatAmountForInput(account.disability_pension_monthly) : "";
    } else {
      document.getElementById("pension-current-value").value = account.current_value != null ? formatAmountForInput(account.current_value) : "";
      document.getElementById("pension-contribution").value = account.monthly_contribution != null ? formatAmountForInput(account.monthly_contribution) : "";
      document.getElementById("pension-is-riester").checked = !!account.is_riester;
      // Wurde das Konto mit einem direkt eingetragenen Prognosewert angelegt,
      // muss der Schalter beim Bearbeiten auch wieder gesetzt sein — sonst
      // würde beim Speichern stillschweigend auf Hochrechnung umgestellt.
      if (account.projected_monthly_at_67 != null) {
        document.getElementById("pension-use-direct-value").checked = true;
        document.getElementById("pension-projected-private").value = formatAmountForInput(account.projected_monthly_at_67);
      }
    }
  }

  if (!isStatutory) {
    if (allContracts.length === 0) {
      allContracts = await (await authedFetch("/api/contracts")).json();
    }
    const linkedSelect = document.getElementById("pension-linked-contract");
    linkedSelect.innerHTML = '<option value="">– kein Vertrag verknüpft –</option>' +
      allContracts.map((c) => `<option value="${c.id}">${escHtml(c.label)}${c.provider ? ` · ${escHtml(c.provider)}` : ""} (${fmt(c.monthly_amount)}/Mon.)</option>`).join("");
    linkedSelect.value = account && account.linked_contract_id ? String(account.linked_contract_id) : "";
    updatePensionContributionLockState();
  }
  updatePensionDirectValueVisibility();
  pensionFormOverlay.style.display = "flex";
}

document.getElementById("pension-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const accountId = form.dataset.accountId;
  const type = form.dataset.type;
  const num = (id) => {
    return parseGermanNumber(document.getElementById(id).value);
  };

  const label = document.getElementById("pension-label").value.trim();
  if (!label) return alert("Bitte eine Bezeichnung angeben.");

  const payload = {
    label,
    provider: document.getElementById("pension-provider").value.trim() || null,
    note: document.getElementById("pension-note").value.trim() || null,
  };

  if (type === "gesetzlich") {
    const projected = num("pension-projected");
    if (projected === null) return alert("Bitte die voraussichtliche Rente mit 67 angeben.");
    payload.projected_monthly_at_67 = projected;
    payload.disability_pension_monthly = num("pension-disability");
  } else {
    const useDirect = document.getElementById("pension-use-direct-value").checked;
    payload.current_value = num("pension-current-value");
    payload.is_riester = document.getElementById("pension-is-riester").checked;
    const linkedContractId = document.getElementById("pension-linked-contract").value;
    payload.linked_contract_id = linkedContractId ? parseInt(linkedContractId, 10) : null;
    if (useDirect) {
      payload.projected_monthly_at_67 = num("pension-projected-private");
    } else {
      // Bei Verknüpfung kommt der Beitrag live vom Vertrag — hier nur
      // mitsenden, wenn NICHT verknüpft, sonst würde ein (gesperrter, aber
      // theoretisch noch im DOM vorhandener) Wert versehentlich überschreiben.
      if (!linkedContractId) {
        payload.monthly_contribution = num("pension-contribution");
      }
      payload.projected_monthly_at_67 = null;
    }
  }

  let targetId = accountId;
  if (accountId) {
    // Wurde der Beleg vorher analysiert (Knopf "Werte übernehmen"), auch
    // beim BEARBEITEN eines bestehenden Kontos mit anhängen -- vorher ging
    // das nur beim Neuanlegen.
    if (form.dataset.documentStagingId) {
      payload.document_staging_id = form.dataset.documentStagingId;
      payload.document_original_filename = form.dataset.documentOriginalFilename;
    }
    const res = await authedFetch(`/api/pension-accounts/${accountId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return alert(err.detail || "Fehler beim Speichern.");
    }
  } else {
    payload.person_id = parseInt(form.dataset.personId, 10);
    payload.type = type;
    // Wurde der Beleg vorher analysiert (Knopf "Werte übernehmen"), liegt die
    // Datei schon zwischengespeichert — direkt mit anhängen, statt sie nach
    // dem Anlegen ein zweites Mal hochzuladen.
    if (form.dataset.documentStagingId) {
      payload.document_staging_id = form.dataset.documentStagingId;
      payload.document_original_filename = form.dataset.documentOriginalFilename;
    }
    const res = await authedFetch("/api/pension-accounts", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return alert(err.detail || "Fehler beim Anlegen.");
    }
    targetId = (await res.json()).id;
  }

  // Datei manuell ausgewählt (egal ob neu angelegt oder bearbeitet), aber
  // "Werte übernehmen" nie geklickt (kein Analyse-Durchlauf) -> Datei
  // trotzdem ganz normal anhängen (ersetzt ein evtl. vorhandenes Dokument).
  const fileInput = document.getElementById("pension-document");
  if (!form.dataset.documentStagingId && fileInput.files.length && targetId) {
    const fd = new FormData();
    fd.append("file", fileInput.files[0]);
    await authedFetch(`/api/pension-accounts/${targetId}/document`, { method: "POST", body: fd });
  }

  pensionFormOverlay.style.display = "none";
  loadHaushaltSummary();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
  loadAufbauTab();
  loadAbsicherungTab();
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
  }
});

// ═══════════════════════════════════════════════════════════════
// VORSORGE: RISIKOABSICHERUNG
// ═══════════════════════════════════════════════════════════════

const ASSESSMENT_LABELS = {
  green: { text: "Gut abgesichert", cls: "settle-ok" },
  yellow: { text: "Prüfen", cls: "" },
  red: { text: "Lücke", cls: "settle-red" },
  present: { text: "Vorhanden", cls: "settle-ok" },
  unknown: { text: "Keine Bewertung möglich", cls: "" },
};

let pendingRiskCharts = [];

function renderRiskSharedContent(data) {
  const container = document.getElementById("risiko-shared-content");
  if (data.groups.length === 0 && data.missing_common_types.length === 0) {
    container.innerHTML = "";
    return;
  }

  // Sammelt alle Chart-Render-Aufrufe, die erst NACH dem Einfügen des HTML
  // in den DOM ausgeführt werden dürfen — hier unabhängig von der
  // Personen-Karte, deshalb eigener Reset/Flush.
  pendingRiskCharts = [];

  const householdNote = [];
  if (data.household.child_count > 0) {
    householdNote.push(`${data.household.child_count} Kind${data.household.child_count > 1 ? "er" : ""} im Haushalt — deshalb gilt der höhere Richtwert (5-8x statt 3-5x Jahresnetto) für die Risikolebensversicherung.`);
  }
  if (data.household.financing_monthly > 0) {
    householdNote.push(`Immobilienfinanzierung mit ${fmtEur0(data.household.financing_monthly)}/Monat läuft zusätzlich — im Ernstfall muss diese Rate weiter bezahlt werden können (nicht als Restschuld eingerechnet).`);
  }
  const noteHtml = householdNote.length
    ? `<p class="muted" style="font-size:0.75rem;margin:0 0 12px">💡 ${householdNote.join(" ")}</p>` : "";

  const missingHtml = data.missing_common_types.length ? `
    <section class="card">
      <div class="row-actions" style="align-items:flex-start;gap:16px;flex-wrap:wrap">
        <div id="essential-coverage-pie" style="flex-shrink:0"></div>
        <div style="flex:1;min-width:200px">
          <h3 style="margin:0 0 8px;font-size:0.9rem;color:var(--warn)">⚠️ Häufig empfohlen, aber nicht gefunden</h3>
          <ul>
            ${data.missing_common_types.map((m) => `
              <li style="flex-direction:column;align-items:flex-start;gap:2px">
                <span style="font-weight:600">${escHtml(m.insurance_type)}</span>
                <span class="muted" style="font-size:0.78rem">${m.reason}</span>
              </li>`).join("")}
          </ul>
        </div>
      </div>
    </section>` : "";
  if (data.essential_total > 0) {
    pendingRiskCharts.push(() => renderYesNoPieChart("essential-coverage-pie", data.essential_present, data.essential_total));
  }

  const groupsHtml = data.groups.map((g) => `
    <section class="card">
      <h3 style="margin:0 0 10px;font-size:0.95rem;color:var(--accent)">${escHtml(g.insurance_type)}</h3>
      <ul>
        ${g.entries.map((e) => {
          const a = ASSESSMENT_LABELS[e.assessment];
          let detail = "";
          if (e.income_replacement_rate != null) {
            detail = `${fmtEur0(e.bu_monthly_pension)}/Mo · ${e.income_replacement_rate}% des Nettos`;
          } else if (e.years_of_income_covered != null) {
            detail = `${fmtEur0(e.insurance_sum)} · deckt ${e.years_of_income_covered} Jahre Nettoeinkommen`;
          }
          return `
            <li>
              <span>${escHtml(e.label)}${e.person_name ? ` <span class="tag">${escHtml(e.person_name)}</span>` : ""}</span>
              <span class="row-actions">
                ${detail ? `<span class="muted" style="font-size:0.75rem">${detail}</span>` : ""}
                <span class="${a.cls}" style="font-size:0.8rem;font-weight:600">${a.text}</span>
              </span>
            </li>`;
        }).join("")}
      </ul>
    </section>
  `).join("");

  container.innerHTML = noteHtml + missingHtml + groupsHtml;
  pendingRiskCharts.forEach((fn) => fn());
  pendingRiskCharts = [];
}

function renderBuEmLine(combo) {
  if (!combo || combo.status === "unknown") return "";
  if (!combo.em_monthly) {
    return `<div class="settle-sub" style="margin:0 0 6px">Erwerbsminderungsrente noch nicht hinterlegt — steht auf der Renteninformation und lässt sich beim gesetzlichen Rentenkonto eintragen.</div>`;
  }
  const excess = combo.combined_monthly - combo.cap_hard;
  const warn = combo.status === "over"
    ? `<span class="settle-red">${fmtEur0(excess)}/Mo über dem Nettoeinkommen — das ist Überversicherung. Der Versicherer zahlt im Leistungsfall maximal das bisherige Netto, der Rest wird gekappt. Ihr zahlt also vermutlich Beiträge für eine Absicherung, die im Ernstfall gar nicht in voller Höhe ausgezahlt würde — lohnt sich, die BU-Rente mit dem Versicherer zu prüfen und ggf. zu reduzieren.</span>`
    : combo.status === "near_cap"
      ? `<span style="color:var(--warn)">nahe der üblichen Obergrenze (~80% des Nettos) — bei einer Erhöhung der BU-Rente prüft der Versicherer das genau.</span>`
      : `noch ${fmtEur0(combo.headroom_to_soft_cap)} Luft bis zur üblichen Obergrenze (~80% des Nettos).`;
  return `
    <div class="settle-sub" style="margin:0 0 6px">
      BU ${fmtEur0(combo.bu_monthly)} + Erwerbsminderungsrente ${fmtEur0(combo.em_monthly)}
      = <b>${fmtEur0(combo.combined_monthly)}/Mo</b> (${combo.combined_rate}% des Nettos) — ${warn}
    </div>`;
}

// ---------- Einheitlicher Deckungs-Balken: Ist-Wert vs. Sollbereich, Lücke sichtbar ----------
// Derselbe visuelle Grundtyp wie renderPensionGapChart bei der Rente — hier
// mit einem Sollbereich (Band) statt eines einzelnen Zielwerts, da BU/RLV
// als Spanne statt fixem Punkt empfohlen werden.
// ---------- BU-Deckungs-Chart: BU (voll) + Erwerbsminderungsrente
// (schraffiert) gestapelt, Sollbereich als Band, harte Obergrenze (Netto)
// als Linie — Überversicherung ist damit direkt sichtbar, ohne dass ein
// Kommentartext das erst erklären müsste. ----------
function renderBuCoverageChart(containerId, buAmount, emAmount, targetMin, targetMax, hardCap, status) {
  const el = document.getElementById(containerId);
  const W = 700, H = 50, padL = 4, padR = 4, padT = 20, barH = 20, barY = padT;
  const chartW = W - padL - padR;
  const total = buAmount + emAmount;
  const maxVal = Math.max(hardCap, total, targetMax, 1) * 1.08;
  const scale = (v) => (v / maxVal) * chartW;
  const cpBu = chartPalette();
  const color = status === "green" ? cpBu.primary : status === "yellow" ? cpBu.warn : cpBu.bad;
  const buW = Math.max(scale(buAmount), 0);
  const emW = Math.max(scale(emAmount), 0);
  const minX = padL + scale(targetMin);
  const maxX = padL + scale(targetMax);
  const capX = padL + scale(hardCap);
  const patternId = `hatch-${containerId}`;
  // Beschriftung an den rechten Rand klammern, damit sie bei einer Max-Linie
  // ganz rechts nicht seitlich abgeschnitten wird (gleiches Prinzip wie bei
  // der Ziel-Beschriftung im Vorsorge-Chart).
  const capLabel = "Max (100% Netto)";
  const approxHalfWidth = capLabel.length * 2.4;
  const capLabelX = Math.min(Math.max(capX, padL + approxHalfWidth), W - padR - approxHalfWidth);

  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
      <defs>
        <pattern id="${patternId}" width="6" height="6" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
          <rect width="6" height="6" fill="${color}" opacity="0.55" />
          <line x1="0" y1="0" x2="0" y2="6" stroke="${cpBu.onColor}" stroke-width="2.5" />
        </pattern>
      </defs>
      <rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="4" fill="rgba(255,255,255,0.06)" />
      <rect x="${minX}" y="${barY}" width="${Math.max(maxX - minX, 1)}" height="${barH}" fill="rgba(255,255,255,0.10)">
        <title>Sollbereich BU: ${fmtEur0(targetMin)} – ${fmtEur0(targetMax)}/Mo (60-80% des Nettos)</title>
      </rect>
      <rect x="${padL}" y="${barY}" width="${buW}" height="${barH}" rx="4" fill="${color}">
        <title>BU-Rente: ${fmtEur0(buAmount)}/Mo</title>
      </rect>
      ${emAmount > 0 ? `
      <rect x="${padL + buW}" y="${barY}" width="${emW}" height="${barH}" fill="url(#${patternId})">
        <title>+ Erwerbsminderungsrente: ${fmtEur0(emAmount)}/Mo (fließt bei einer BU-Prüfung mit ein)</title>
      </rect>` : ""}
      <line x1="${minX}" y1="${barY - 3}" x2="${minX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1" stroke-dasharray="2,2" opacity="0.6" />
      <line x1="${maxX}" y1="${barY - 3}" x2="${maxX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1.5" stroke-dasharray="2,2" />
      <line x1="${capX}" y1="${barY - 6}" x2="${capX}" y2="${barY + barH + 6}" stroke="${cpBu.bad}" stroke-width="1.5" />
      <text x="${capLabelX}" y="${padT - 8}" text-anchor="middle" font-size="10" fill="${cpBu.bad}">${capLabel}</text>
    </svg>`;
}

function renderCoverageBarChart(containerId, current, targetMin, targetMax, status) {
  const el = document.getElementById(containerId);
  const W = 700, H = 34, padL = 4, padR = 4, barH = 18, barY = 8;
  const chartW = W - padL - padR;
  const maxVal = Math.max(targetMax, current, 1) * 1.05;
  const scale = (v) => (v / maxVal) * chartW;
  const cpCov = chartPalette();
  const color = status === "green" ? cpCov.primary : status === "yellow" ? cpCov.warn : cpCov.bad;
  const currentW = Math.max(scale(current), 0);
  const minX = padL + scale(targetMin);
  const maxX = padL + scale(targetMax);

  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
      <rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="4" fill="rgba(255,255,255,0.06)" />
      <rect x="${minX}" y="${barY}" width="${Math.max(maxX - minX, 1)}" height="${barH}" fill="rgba(255,255,255,0.10)">
        <title>Sollbereich: ${fmtEur0(targetMin)} – ${fmtEur0(targetMax)}</title>
      </rect>
      <rect x="${padL}" y="${barY}" width="${currentW}" height="${barH}" rx="4" fill="${color}">
        <title>Aktuell: ${fmtEur0(current)}</title>
      </rect>
      <line x1="${minX}" y1="${barY - 3}" x2="${minX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1" stroke-dasharray="2,2" opacity="0.6" />
      <line x1="${maxX}" y1="${barY - 3}" x2="${maxX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1.5" stroke-dasharray="2,2" />
    </svg>`;
}

// ---------- Ja/Nein-Pie-Chart für boolesche Absicherungsfragen ----------
function renderYesNoPieChart(containerId, yesCount, totalCount) {
  const el = document.getElementById(containerId);
  const pct = totalCount > 0 ? (yesCount / totalCount) * 100 : 0;
  const radius = 42, stroke = 16, circumference = 2 * Math.PI * radius;
  const yesArc = (pct / 100) * circumference;
  const cpYn = chartPalette();
  const color = pct >= 100 ? cpYn.primary : pct >= 50 ? cpYn.warn : cpYn.bad;

  el.innerHTML = `
    <svg viewBox="0 0 120 120" width="130" height="130">
      <circle cx="60" cy="60" r="${radius}" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="${stroke}" />
      <circle cx="60" cy="60" r="${radius}" fill="none" stroke="${color}" stroke-width="${stroke}"
        stroke-dasharray="${yesArc} ${circumference}" stroke-linecap="round" transform="rotate(-90 60 60)">
        <title>${yesCount} von ${totalCount} vorhanden</title>
      </circle>
      <text x="60" y="56" text-anchor="middle" font-size="24" font-weight="700" fill="var(--text)">${yesCount}/${totalCount}</text>
      <text x="60" y="75" text-anchor="middle" font-size="10" fill="var(--muted)">vorhanden</text>
    </svg>`;
}

function renderRiskAssessmentLine(label, a, kind, emCombo) {
  if (a.assessment === "unknown") {
    return `<div class="settle-sub" style="margin-bottom:4px">${label}: kein Nettoeinkommen hinterlegt — keine Bewertung möglich.</div>`;
  }
  const chartId = `coverage-chart-${label.replace(/[^a-zA-Z0-9]/g, "")}-${Math.random().toString(36).slice(2, 8)}`;
  if (kind === "monthly") {
    const buAmount = a.bu_monthly_pension || 0;
    const emAmount = (emCombo && emCombo.em_monthly) || 0;
    const hardCap = (emCombo && emCombo.cap_hard) || a.target_max_monthly;
    pendingRiskCharts.push(() => renderBuCoverageChart(chartId, buAmount, emAmount, a.target_min_monthly, a.target_max_monthly, hardCap, a.assessment));
    return `
      <div style="margin-bottom:10px">
        <div class="settle-sub">${label}${emAmount > 0 ? " (schraffiert: + Erwerbsminderungsrente)" : ""}</div>
        <div id="${chartId}" style="margin:4px 0"></div>
      </div>`;
  }
  const current = a.insurance_sum || 0;
  const color = a.assessment === "green" ? "settle-ok" : a.assessment === "yellow" ? "" : "settle-red";
  pendingRiskCharts.push(() => renderCoverageBarChart(chartId, current, a.target_min_sum, a.target_max_sum, a.assessment));
  return `
    <div style="margin-bottom:6px">
      <div class="settle-sub">${label} — Soll ${fmtEur0(a.target_min_sum)}–${fmtEur0(a.target_max_sum)} (${a.target_multiple_min}-${a.target_multiple_max}x Jahresnetto)</div>
      <div id="${chartId}" style="margin:4px 0"></div>
      <div class="${color}" style="font-size:0.82rem;font-weight:600">
        Aktuell ${fmtEur0(current)} (${a.years_of_income_covered} Jahre)${a.assessment !== "green" ? ` — fehlen mind. ${fmtEur0(a.gap_to_min_sum)}` : " — im Sollbereich"}
      </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PERSONEN VERWALTEN (Stammdaten)
// ═══════════════════════════════════════════════════════════════

const familyMembersOverlay = document.getElementById("family-members-overlay");

async function loadFamilyMembersList() {
  allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  const list = document.getElementById("family-members-list");
  list.innerHTML = `
    <ul>
      ${allFamilyMembers.map((m) => `
        <li>
          <span style="flex:1"><b>${escHtml(m.name)}</b> <span class="tag">${m.role === "elternteil" ? "Elternteil" : "Kind"}</span></span>
          <span class="row-actions">
            <button type="button" class="ghost-btn" style="width:auto;padding:6px 12px;font-size:0.8rem" data-edit-member="${m.id}">✏️ Bearbeiten</button>
            <button class="del-btn" data-delete-member="${m.id}" title="Löschen">🗑</button>
          </span>
        </li>`).join("")}
    </ul>`;

  list.querySelectorAll("[data-edit-member]").forEach((btn) => {
    btn.addEventListener("click", () => openPersonDetailForm(btn.dataset.editMember));
  });

  list.querySelectorAll("[data-delete-member]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diese Person wirklich löschen? Verträge bleiben erhalten, verlieren aber die Zuordnung.")) return;
      const delRes = await authedFetch(`/api/family-members/${btn.dataset.deleteMember}`, { method: "DELETE" });
      if (!delRes.ok) { const err = await delRes.json().catch(() => ({})); alert(err.detail || "Löschen fehlgeschlagen."); return; }
      allFamilyMembers = [];
      loadFamilyMembersList();
    });
  });
}

document.getElementById("manage-family-members-btn").addEventListener("click", () => {
  familyMembersOverlay.style.display = "flex";
  loadFamilyMembersList();
});

document.getElementById("family-members-close-btn").addEventListener("click", () => {
  familyMembersOverlay.style.display = "none";
  if (document.getElementById("tab-vorsorge-dashboard").style.display !== "none") loadVorsorgeDashboard();
  if (document.getElementById("tab-vorsorge-aufbau").style.display !== "none") loadAufbauTab();
  if (document.getElementById("tab-vorsorge-absicherung").style.display !== "none") loadAbsicherungTab();
});

document.getElementById("add-family-member-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("new-member-name").value.trim();
  const role = document.getElementById("new-member-role").value;
  if (!name) return;
  const res = await authedFetch("/api/family-members", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, role }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.detail || "Fehler beim Anlegen.");
    return;
  }
  document.getElementById("add-family-member-form").reset();
  allFamilyMembers = [];
  loadFamilyMembersList();
});

// ═══════════════════════════════════════════════════════════════
// PV-ANLAGENDATEN (Strom → Produktion)
// ═══════════════════════════════════════════════════════════════

async function loadPvSystemSpecs() {
  const container = document.getElementById("pv-system-specs-content");
  container.innerHTML = '<p class="muted">Lade …</p>';
  const data = await (await authedFetch("/api/pv/system-specs")).json();

  if (data.specs.length === 0) {
    container.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Anlagendaten hinterlegt.</p>';
    return;
  }

  const currentId = data.current ? data.current.id : null;
  const upcomingIds = new Set(data.upcoming.map((s) => s.id));

  container.innerHTML = `
    <ul>
      ${data.specs.map((s) => {
        const isCurrent = s.id === currentId;
        const isUpcoming = upcomingIds.has(s.id);
        const badge = isCurrent ? `<span class="tag" style="background:${cssVarToRgba("--good", 0.15)};color:var(--good)">aktuell</span>`
          : isUpcoming ? `<span class="tag" style="background:${cssVarToRgba("--warn", 0.15)};color:var(--warn)">🔜 geplant</span>`
          : '<span class="muted" style="font-size:0.72rem">bis zur nächsten Änderung</span>';
        const specParts = [];
        if (s.kwp) specParts.push(`${s.kwp} kWp`);
        if (s.battery_kwh) specParts.push(`${s.battery_kwh} kWh Speicher`);
        if (s.installed_year) specParts.push(`Baujahr ${s.installed_year}`);
        return `
          <li data-pv-spec-row="${s.id}" style="cursor:context-menu;${isUpcoming ? "opacity:0.85" : ""}">
            <span>
              <b>ab ${s.valid_from}</b> — ${specParts.join(" · ") || "keine Werte hinterlegt"}
              ${s.note ? `<br><span class="muted" style="font-size:0.75rem">${escHtml(s.note)}</span>` : ""}
            </span>
            <span class="row-actions">
              ${badge}
              ${rowMenuButtonHTML("pvspec", s.id)}
            </span>
          </li>`;
      }).join("")}
    </ul>
    <p class="muted" style="font-size:0.72rem;margin:6px 0 0">Rechtsklick oder ⋯ auf einen Eintrag zum Bearbeiten oder Löschen.</p>`;

  container.querySelectorAll("[data-pv-spec-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuPvSpecId = row.dataset.pvSpecRow;
      showPvSpecContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(container, "pvspec", (id, x, y) => {
    contextMenuPvSpecId = id;
    showPvSpecContextMenu(x, y);
  });
}

let contextMenuPvSpecId = null;
const pvSpecContextMenu = document.getElementById("pv-spec-context-menu");

document.getElementById("pv-add-spec-btn").addEventListener("click", () => openPvSpecForm(null));

const pvSpecFormOverlay = document.getElementById("pv-spec-form-overlay");

async function openPvSpecForm(specId) {
  const form = document.getElementById("pv-spec-form");
  form.reset();
  form.dataset.specId = specId || "";
  document.getElementById("pv-spec-form-title").textContent = specId ? "🔧 Ausbauschritt bearbeiten" : "🔧 Ausbauschritt hinzufügen";

  if (specId) {
    const data = await (await authedFetch("/api/pv/system-specs")).json();
    const spec = data.specs.find((s) => String(s.id) === String(specId));
    if (spec) {
      document.getElementById("pv-spec-valid-from").value = spec.valid_from || "";
      document.getElementById("pv-spec-installed-year").value = spec.installed_year ?? "";
      document.getElementById("pv-spec-kwp").value = spec.kwp ?? "";
      document.getElementById("pv-spec-battery").value = spec.battery_kwh ?? "";
      document.getElementById("pv-spec-note").value = spec.note || "";
    }
  }
  pvSpecFormOverlay.style.display = "flex";
}

document.getElementById("pv-spec-form-cancel-btn").addEventListener("click", () => {
  pvSpecFormOverlay.style.display = "none";
});

document.getElementById("pv-spec-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const specId = e.target.dataset.specId;
  const validFrom = document.getElementById("pv-spec-valid-from").value;
  if (!validFrom) return alert("Bitte ein Gültig-ab-Datum angeben.");

  const yearStr = document.getElementById("pv-spec-installed-year").value.trim();
  const payload = {
    valid_from: validFrom,
    installed_year: yearStr ? parseInt(yearStr, 10) : null,
    kwp: parseGermanNumber(document.getElementById("pv-spec-kwp").value),
    battery_kwh: parseGermanNumber(document.getElementById("pv-spec-battery").value),
    note: document.getElementById("pv-spec-note").value.trim() || null,
  };

  const res = specId
    ? await authedFetch(`/api/pv/system-specs/${specId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      })
    : await authedFetch("/api/pv/system-specs", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Speichern.");
  }
  pvSpecFormOverlay.style.display = "none";
  loadPvSystemSpecs();
});

function showPvSpecContextMenu(x, y) {
  pvSpecContextMenu.style.left = `${x}px`;
  pvSpecContextMenu.style.top = `${y}px`;
  pvSpecContextMenu.style.display = "block";
}

function hidePvSpecContextMenu() {
  pvSpecContextMenu.style.display = "none";
  contextMenuPvSpecId = null;
}

document.addEventListener("click", (e) => {
  if (!pvSpecContextMenu.contains(e.target)) hidePvSpecContextMenu();
});

pvSpecContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuPvSpecId;
  hidePvSpecContextMenu();
  if (id) openPvSpecForm(id);
});

pvSpecContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuPvSpecId;
  hidePvSpecContextMenu();
  if (!id || !confirm("Diesen Ausbauschritt wirklich löschen?")) return;
  await authedFetch(`/api/pv/system-specs/${id}`, { method: "DELETE" });
  loadPvSystemSpecs();
});

// ---------- Sticky Header: reale Höhe messen und als CSS-Variable
// bereitstellen, damit die Sidebar exakt darunter andockt statt sie zu
// überlappen oder eine Lücke zu lassen. Header-Höhe variiert je nach Gerät
// (env(safe-area-inset-top) bei Notch) und Textgrößen-Einstellung, daher
// nicht fest verdrahtet, sondern gemessen. ResizeObserver statt nur
// load/resize-Events, da ein einmaliges Messen bei manchen Browsern
// (insbesondere Safari) zu früh greifen kann, bevor der Header seine
// endgültige Höhe erreicht hat — der Observer reagiert zuverlässig auf
// jede tatsächliche Größenänderung. ----------
function updateHeaderHeightVar() {
  const header = document.querySelector("header");
  if (header) {
    document.documentElement.style.setProperty("--header-height", `${header.offsetHeight}px`);
  }
}
window.addEventListener("resize", updateHeaderHeightVar);
window.addEventListener("load", updateHeaderHeightVar);
updateHeaderHeightVar();

const headerEl = document.querySelector("header");
if (headerEl && typeof ResizeObserver !== "undefined") {
  new ResizeObserver(updateHeaderHeightVar).observe(headerEl);
}

// ==================== VERMÖGENSÜBERSICHT ====================
let allAssets = [];
let archivedAssets = [];
let contextMenuAssetId = null;
const ASSET_TYPE_LABELS = { konto: "Konten", depot: "Depots", immobilie: "Immobilien", altersvorsorge: "Altersvorsorge", sonstiges: "Sonstiges" };
const ASSET_TYPE_ICONS = { konto: "🏦", depot: "📈", immobilie: "🏠", altersvorsorge: "👴", sonstiges: "💼" };

async function loadVermoegenOverview() {
  await loadBankAccounts();
  const data = await (await authedFetch("/api/vermoegen/overview")).json();
  allAssets = Object.entries(data.by_type)
    .flatMap(([type, items]) => (type === "altersvorsorge" ? items.filter((i) => i.source === "asset") : items));
  renderVermoegenSummaryCards(data.totals);
  renderVermoegenGroups(data.by_type);
  loadArchivedAssets();
  renderVermoegenRealEstateChart(data.real_estate_projection);
  renderVermoegenPieChart(data.pie_allocation);
  renderVermoegenAllocation(data.asset_allocation);
  renderVermoegenLiquidity(data.liquidity_reserve);
  populateVermoegenBulkDropdown(allAssets);
  loadVermoegenHistory();
  loadSteuerOverview();
  await applyBlockOrder("vermoegen-subtab-uebersicht", "vermoegen_uebersicht_order");
  setupBlockDragReorder("vermoegen-subtab-uebersicht", "vermoegen_uebersicht_order");
}

// ---------- Archiv: archivierte Vermögenskonten (Belege & Umsätze bleiben zugänglich) ----------
async function loadArchivedAssets() {
  const box = document.getElementById("vermoegen-archive");
  if (!box) return;
  archivedAssets = await (await authedFetch("/api/assets?archived=true")).json().catch(() => []);
  if (!archivedAssets.length) { box.style.display = "none"; return; }
  box.style.display = "block";
  document.getElementById("vermoegen-archive-count").textContent = archivedAssets.length;
  const list = document.getElementById("vermoegen-archive-list");
  list.innerHTML = archivedAssets.map((a) => {
    const bank = (a.type === "konto" || a.type === "depot") ? bankAccountsOfAsset(a.id)[0] : null;
    return `
    <div class="row-actions" style="justify-content:space-between;align-items:center;padding:6px 0;flex-wrap:wrap;gap:6px">
      <span><strong>${escHtml(a.label)}</strong>
        ${a.provider ? `<span class="muted" style="font-size:0.72rem">${escHtml(a.provider)}</span>` : ""}
        ${a.person_name ? `<span class="tag">${escHtml(a.person_name)}</span>` : ""}
        <span class="muted" style="font-size:0.72rem">${a.archived_at ? "archiviert " + a.archived_at.slice(0, 10) : ""}</span></span>
      <span class="row-actions" style="gap:6px">
        ${bank ? `<button type="button" class="ghost-btn" data-archive-tx="${bank.id}" style="width:auto;font-size:0.75rem">📜 Umsätze</button>` : ""}
        <button type="button" class="ghost-btn" data-archive-docs="${a.id}" style="width:auto;font-size:0.75rem">🗂 Details &amp; Belege</button>
        <button type="button" class="ghost-btn" data-archive-restore="${a.id}" style="width:auto;font-size:0.75rem">↩ Wiederherstellen</button>
      </span>
    </div>`;
  }).join("");
  list.querySelectorAll("[data-archive-tx]").forEach((b) => b.addEventListener("click", () => {
    const acc = bankAccountsAll.find((x) => String(x.id) === String(b.dataset.archiveTx));
    if (acc) openBankTransactions(acc.id, bankAccountTitle(acc));
  }));
  list.querySelectorAll("[data-archive-docs]").forEach((b) => b.addEventListener("click", () => {
    const asset = archivedAssets.find((x) => String(x.id) === String(b.dataset.archiveDocs));
    if (asset) openAssetForm(asset.id, asset.type);
  }));
  list.querySelectorAll("[data-archive-restore]").forEach((b) => b.addEventListener("click", async () => {
    const res = await authedFetch(`/api/assets/${b.dataset.archiveRestore}/restore`, { method: "POST" });
    if (!res.ok) { const err = await res.json().catch(() => ({})); showToast(err.detail || "Wiederherstellen fehlgeschlagen"); return; }
    showToast("Wiederhergestellt");
    loadVermoegenOverview();
  }));
}

function renderVermoegenSummaryCards(totals) {
  const el = document.getElementById("vermoegen-summary-cards");
  el.className = "stats";
  el.innerHTML = `
    <div><span class="label">Gesamtvermögen</span><span>${fmt(totals.gesamt)}</span></div>
    <div><span class="label">Liquide Mittel &amp; Depots</span><span>${fmt(totals.liquid)}</span></div>
    <div><span class="label">Private Altersvorsorge</span><span>${fmt(totals.pension_capital)}</span></div>
    <div><span class="label">Immobilien netto</span><span>${fmt(totals.immobilien_netto)}</span></div>`;
}

function renderVermoegenGroups(byType) {
  const el = document.getElementById("vermoegen-groups");
  // Wie bei Ausgaben: aktuell aufgeklappte Gruppen merken, statt bei jeder
  // Aktualisierung (z.B. nach einem Beleg-Import) wieder alles einzuklappen.
  // Beim allerersten Laden ist damit automatisch alles eingeklappt.
  const expandedGroups = new Set(
    Array.from(el.querySelectorAll(".contract-list:not(.collapsed)")).map((ul) => ul.dataset.group)
  );
  const order = ["konto", "depot", "immobilie", "altersvorsorge", "sonstiges"];
  el.innerHTML = order.map((type) => {
    const items = byType[type] || [];
    const sum = items.reduce((s, a) => s + (a.current_value || 0), 0);
    const isAltersvorsorge = type === "altersvorsorge";
    const isExpanded = expandedGroups.has(type);
    return `
    <div class="contract-group">
      <h3 class="group-toggle" data-group="${type}">
        <span class="chevron">${isExpanded ? "▾" : "▸"}</span> ${ASSET_TYPE_ICONS[type]} ${ASSET_TYPE_LABELS[type]}
        <span class="group-sum">${fmt(sum)}</span>
      </h3>
      <ul class="contract-list${isExpanded ? "" : " collapsed"}" data-group="${type}">
        ${items.length === 0 ? `<li class="muted" style="padding:8px 0">${isAltersvorsorge ? "Noch nichts unter Vorsorge oder als Vertrag (Kategorie „Altersvorsorge“) hinterlegt." : "Noch nichts hinterlegt."}</li>` : items.map((a) => (isAltersvorsorge && a.source !== "asset") ? `
          <li data-external-row="${a.source}:${a.id}:${a.person_id || ""}" style="cursor:context-menu">
            <div class="contract-main">
              ${rowMenuButtonHTML("external", `${a.source}:${a.id}:${a.person_id || ""}`)}
              <span class="contract-label">${escHtml(a.label)}</span>
              ${a.provider ? `<span class="muted" style="font-size:0.78rem">${escHtml(a.provider)}</span>` : ""}
              ${a.person_name ? `<span class="tag">${escHtml(a.person_name)}</span>` : ""}
              <span class="tag" style="opacity:0.7" title="${a.source === "pension_account" ? "Rentenkonto unter Vorsorge" : "Vertrag unter Ausgaben"}">${a.source === "pension_account" ? "Vorsorge" : "Ausgaben"}</span>
            </div>
            <div class="contract-amount row-actions">
              <b>${fmt(a.current_value)}</b>
            </div>
          </li>` : `
          <li data-asset-row="${a.id}" style="cursor:context-menu">
            <div class="contract-main">
              ${rowMenuButtonHTML("asset", a.id)}
              <span class="contract-label">${escHtml(a.label)}</span>
              ${a.provider ? `<span class="muted" style="font-size:0.78rem">${escHtml(a.provider)}${a.account_number ? ` · ${escHtml(a.account_number)}` : ""}</span>` : (a.account_number ? `<span class="muted" style="font-size:0.78rem">${escHtml(a.account_number)}</span>` : "")}
              ${a.person_name ? `<span class="tag">${escHtml(a.person_name)}</span>` : ""}
              ${isAltersvorsorge ? '<span class="tag" style="opacity:0.7">Depot</span>' : ""}
              ${(a.financing_contracts || []).map((f) => `<span class="tag" title="Verknüpfter Finanzierungsvertrag">🔗 ${escHtml(f.label)}</span>`).join("")}
              ${(() => { const bl = (a.type === "konto" || a.type === "depot") ? bankAccountsOfAsset(a.id) : [];
                if (!bl.length) return "";
                const ts = bl.map((b) => b.balance_updated_at).filter(Boolean).sort().pop();
                const when = ts ? ` · ${new Date(ts).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}` : "";
                return `<span class="tag" title="Mit Bankkonto verbunden — Stand kommt von der Bank. Umsätze und Zuordnung über ⋯">🏦 Bank${when}</span>`; })()}
            </div>
            <div class="contract-amount row-actions">
              ${a.type === "immobilie" && a.total_remaining_debt > 0
                ? `<span class="muted" style="font-size:0.72rem" title="Restschuld unter Verbindlichkeiten">${fmt(a.total_remaining_debt)} Restschuld</span> <b>${fmt(a.current_value)}</b>`
                : (a.type === "konto" && !bankAccountsOfAsset(a.id).length)
                ? `<b class="inline-editable-value" data-inline-edit-id="${a.id}" data-raw-value="${a.current_value ?? 0}" title="Klicken zum Bearbeiten">${fmt(a.current_value)}</b>`
                : `<b>${fmt(a.current_value)}</b>`}
            </div>
          </li>`).join("")}
      </ul>
    </div>`;
  }).join("");

  el.querySelectorAll(".group-toggle").forEach((h3) => {
    h3.addEventListener("click", () => {
      const ul = el.querySelector(`.contract-list[data-group="${h3.dataset.group}"]`);
      ul.classList.toggle("collapsed");
      h3.querySelector(".chevron").textContent = ul.classList.contains("collapsed") ? "▸" : "▾";
    });
  });
  el.querySelectorAll("[data-asset-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuAssetId = row.dataset.assetRow;
      showAssetContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(el, "asset", (id, x, y) => {
    contextMenuAssetId = id;
    showAssetContextMenu(x, y);
  });
  wireInlineAssetValueEdit(el);

  el.querySelectorAll("[data-external-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuExternalKey = row.dataset.externalRow;
      showExternalContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(el, "external", (key, x, y) => {
    contextMenuExternalKey = key;
    showExternalContextMenu(x, y);
  });
}

let contextMenuExternalKey = null;
const externalContextMenu = document.getElementById("external-context-menu");

// Darlehen (Haus · Finanzierung) werden hier wie Konten behandelt: ⋯ → Umsätze / Bankkonto zuordnen / lösen.
function financingContractOfKey(key) {
  const m = /^contract:(\d+)$/.exec(key || "");
  const c = m && allContracts.find((x) => String(x.id) === m[1]);
  return c && c.subcategory === "Finanzierung" ? c : null;
}
function bankAccountsOfContract(contractId) {
  return bankAccountsAll.filter((b) => String(b.contract_id) === String(contractId));
}
function showExternalContextMenu(x, y) {
  const fin = financingContractOfKey(contextMenuExternalKey);
  const linked = fin ? bankAccountsOfContract(fin.id) : [];
  const show = (action, on) => { const b = externalContextMenu.querySelector(`[data-action="${action}"]`); if (b) b.style.display = on ? "" : "none"; };
  show("bank-tx", linked.length > 0);
  show("bank-link", !!fin && linked.length === 0);
  show("bank-unlink", linked.length > 0);
  externalContextMenu.style.left = `${x}px`;
  externalContextMenu.style.top = `${y}px`;
  externalContextMenu.style.display = "block";
}
function hideExternalContextMenu() {
  externalContextMenu.style.display = "none";
  contextMenuExternalKey = null;
}
document.addEventListener("click", (e) => {
  if (!externalContextMenu.contains(e.target)) hideExternalContextMenu();
});

externalContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const key = contextMenuExternalKey;
  hideExternalContextMenu();
  if (!key) return;
  openExternalAltersvorsorgeEntry(key);
});

externalContextMenu.querySelector('[data-action="bank-tx"]').addEventListener("click", () => {
  const fin = financingContractOfKey(contextMenuExternalKey);
  hideExternalContextMenu();
  const b = fin && bankAccountsOfContract(fin.id)[0];
  if (b) openBankTransactions(b.id, bankAccountTitle(b));
});
externalContextMenu.querySelector('[data-action="bank-link"]').addEventListener("click", () => {
  const fin = financingContractOfKey(contextMenuExternalKey);
  hideExternalContextMenu();
  if (!fin) return;
  const rows = bankAccountsAll.filter((b) => !b.asset_id && !b.contract_id && !b.ignored).map((b) => ({
    id: b.id, title: bankAccountTitle(b), sub: `${maskIban(b.iban || b.account_number)} · Kontostand laut Bank ${fmtEur2(b.balance)} · Restschuld in der App ${fmtEur2(fin.remaining_debt)}`,
  }));
  openBankPicker("Bankkonto zuordnen", rows, async (r) => {
    if (await linkBankAccountContract(r.id, fin.id)) { allContracts = []; await loadBankAccounts(); loadVerbindlichkeiten(); }
  });
});
externalContextMenu.querySelector('[data-action="bank-unlink"]').addEventListener("click", async () => {
  const fin = financingContractOfKey(contextMenuExternalKey);
  hideExternalContextMenu();
  const linked = fin ? bankAccountsOfContract(fin.id) : [];
  if (!linked.length || !confirm("Die Verknüpfung mit dem Bankkonto lösen? Die letzte Restschuld bleibt stehen und kann dann wieder von Hand geändert werden.")) return;
  for (const b of linked) await linkBankAccountContract(b.id, null);
  allContracts = []; await loadBankAccounts(); loadVerbindlichkeiten();
});

externalContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const key = contextMenuExternalKey;
  hideExternalContextMenu();
  if (!key) return;
  const [source, id] = key.split(":");
  if (source === "pension_account") {
    if (!confirm("Dieses Rentenkonto wirklich löschen?")) return;
    await authedFetch(`/api/pension-accounts/${id}`, { method: "DELETE" });
    loadHaushaltSummary();
    vorsorgeLastRenteData = null;
    vorsorgeLastRisikoData = null;
    loadAufbauTab();
    loadAbsicherungTab();
  } else {
    // "contract" (Altersvorsorge-Vertrag) und "financing" (Verbindlichkeiten)
    // sind beide derselbe zugrunde liegende Vertrag — dieselbe Archivieren-Logik.
    if (!confirm("Diesen Vertrag archivieren? Er verschwindet aus der aktiven Liste, Belege bleiben im Archiv erhalten.")) return;
    const res = await authedFetch(`/api/contracts/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(err.detail || "Fehler beim Archivieren.");
      return;
    }
    loadContracts();
    loadDashboard();
    loadReview();
  }
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
    if (document.getElementById("vermoegen-subtab-verbindlichkeiten").style.display !== "none") {
      loadVerbindlichkeiten();
    }
  }
});

function openExternalAltersvorsorgeEntry(key) {
  const [source, id, personId] = key.split(":");
  if (source === "pension_account") {
    openPensionForm(id, "privat", personId || null);
  } else if (source === "contract") {
    openDetailsModal(id);
  }
}

const assetContextMenu = document.getElementById("asset-context-menu");
function showAssetContextMenu(x, y) {
  const asset = allAssets.find((a) => String(a.id) === String(contextMenuAssetId));
  const bankable = !!asset && (asset.type === "konto" || asset.type === "depot");
  const linked = bankable ? bankAccountsOfAsset(asset.id) : [];
  const show = (action, on) => { const b = assetContextMenu.querySelector(`[data-action="${action}"]`); if (b) b.style.display = on ? "" : "none"; };
  show("bank-tx", linked.length > 0);
  show("bank-link", bankable && linked.length === 0);
  show("bank-unlink", linked.length > 0);
  assetContextMenu.style.left = `${x}px`;
  assetContextMenu.style.top = `${y}px`;
  assetContextMenu.style.display = "block";
}
document.addEventListener("click", (e) => {
  if (!assetContextMenu.contains(e.target)) assetContextMenu.style.display = "none";
});
assetContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  assetContextMenu.style.display = "none";
  const asset = allAssets.find((a) => String(a.id) === String(contextMenuAssetId));
  if (asset) openAssetForm(asset.id, asset.type);
});
assetContextMenu.querySelector('[data-action="bank-tx"]').addEventListener("click", () => {
  assetContextMenu.style.display = "none";
  const b = bankAccountsOfAsset(contextMenuAssetId)[0];
  if (b) openBankTransactions(b.id, bankAccountTitle(b));
});
assetContextMenu.querySelector('[data-action="bank-link"]').addEventListener("click", () => {
  assetContextMenu.style.display = "none";
  const assetId = Number(contextMenuAssetId);
  const rows = bankAccountsAll.filter((b) => !b.asset_id && !b.contract_id && !b.ignored).map((b) => ({
    id: b.id, title: bankAccountTitle(b), sub: `${maskIban(b.iban || b.account_number)} · Kontostand laut Bank ${fmtEur2(b.balance)}`,
  }));
  openBankPicker("Bankkonto zuordnen", rows.length ? rows : [], async (r) => {
    if (await linkBankAccount(r.id, assetId)) loadVermoegenOverview();
  });
});
assetContextMenu.querySelector('[data-action="bank-unlink"]').addEventListener("click", async () => {
  assetContextMenu.style.display = "none";
  const linked = bankAccountsOfAsset(contextMenuAssetId);
  if (!linked.length || !confirm("Die Verknüpfung mit dem Bankkonto lösen? Der letzte Saldo bleibt stehen und kann dann wieder von Hand geändert werden.")) return;
  for (const b of linked) await linkBankAccount(b.id, null);
  loadVermoegenOverview();
});
assetContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  assetContextMenu.style.display = "none";
  if (!confirm("Diesen Vermögenswert archivieren? Er verschwindet aus Übersicht und Summen; Belege und Umsätze bleiben erhalten und er lässt sich im Archiv wiederherstellen.")) return;
  await authedFetch(`/api/assets/${contextMenuAssetId}`, { method: "DELETE" });
  loadVermoegenOverview();
});

document.querySelectorAll("[data-add-asset]").forEach((btn) => {
  btn.addEventListener("click", () => openAssetForm(null, btn.dataset.addAsset));
});

const assetFormOverlay = document.getElementById("asset-form-overlay");
let assetFormDocsCache = null;

async function openAssetForm(assetId, type) {
  const form = document.getElementById("asset-form");
  form.reset();
  form.dataset.assetId = assetId || "";
  form.dataset.type = type;
  document.getElementById("asset-form-title").textContent = `${ASSET_TYPE_ICONS[type]} ${type === "konto" ? "Konto" : type === "depot" ? "Depot" : type === "immobilie" ? "Immobilie" : "Sonstiger Vermögenswert"}`;
  document.getElementById("asset-value-label").textContent = type === "immobilie" ? "Aktueller Immobilienwert (€)" : "Aktueller Wert / Saldo (€)";

  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  const personSelect = document.getElementById("asset-person");
  personSelect.innerHTML = '<option value="">– gemeinsam/Haushalt –</option>' +
    allFamilyMembers.map((p) => `<option value="${p.id}">${escHtml(p.name)}</option>`).join("");

  const financingGroup = document.getElementById("asset-financing-link-group");
  let asset = null;
  if (assetId) asset = allAssets.find((a) => String(a.id) === String(assetId)) || archivedAssets.find((a) => String(a.id) === String(assetId));
  const linkedIds = new Set((asset?.financing_contracts || []).map((f) => f.id));

  if (type === "immobilie") {
    financingGroup.style.display = "block";
    if (allContracts.length === 0) allContracts = await (await authedFetch("/api/contracts")).json();
    const financingContracts = allContracts.filter((c) => c.subcategory === "Finanzierung");
    const checkboxContainer = document.getElementById("asset-financing-checkboxes");
    if (financingContracts.length === 0) {
      checkboxContainer.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch kein Finanzierungsvertrag unter Ausgaben angelegt.</p>';
    } else {
      checkboxContainer.innerHTML = financingContracts.map((c) => `
        <label class="checkbox-label">
          <input type="checkbox" value="${c.id}" data-financing-checkbox ${linkedIds.has(c.id) ? "checked" : ""} />
          <span>${escHtml(c.label)} (Restschuld ${fmt(c.remaining_debt || 0)})</span>
        </label>`).join("");
    }
  } else {
    financingGroup.style.display = "none";
  }

  const purposeGroup = document.getElementById("asset-purpose-group");
  purposeGroup.style.display = type === "immobilie" ? "none" : "block";

  document.getElementById("asset-account-type-group").style.display = type === "konto" ? "block" : "none";

  const holdingsGroup = document.getElementById("asset-holdings-group");
  holdingsGroup.style.display = (type === "depot" && assetId) ? "block" : "none";
  if (type === "depot" && assetId) {
    await loadAssetHoldings(assetId);
  } else {
    document.getElementById("asset-holdings-list").innerHTML = "";
  }

  const showDocsBtn = document.getElementById("asset-show-documents-btn");
  const docsSection = document.getElementById("asset-documents-section");
  docsSection.style.display = "none";
  docsSection.innerHTML = "";
  assetFormDocsCache = null;

  if (assetId) {
    document.getElementById("asset-label").value = asset.label || "";
    document.getElementById("asset-provider").value = asset.provider || "";
    document.getElementById("asset-account-number").value = asset.account_number || "";
    document.getElementById("asset-account-type").value = asset.account_type || "";
    document.getElementById("asset-purpose").value = asset.purpose || "";
    document.getElementById("asset-person").value = asset.person_id || "";
    document.getElementById("asset-current-value").value = asset.current_value != null ? formatAmountForInput(asset.current_value) : "";
    document.getElementById("asset-note").value = asset.note || "";

    showDocsBtn.style.display = "block";
    assetFormDocsCache = await (await authedFetch(`/api/assets/${assetId}/receipts`)).json();
  } else {
    showDocsBtn.style.display = "none";
  }

  assetFormOverlay.style.display = "flex";
}

document.getElementById("asset-form-cancel-btn").addEventListener("click", () => {
  assetFormOverlay.style.display = "none";
});

document.getElementById("asset-show-documents-btn").addEventListener("click", () => {
  const section = document.getElementById("asset-documents-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) { section.style.display = "none"; return; }
  section.style.display = "block";
  const docs = assetFormDocsCache || [];
  if (docs.length === 0) {
    section.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Belege hinterlegt.</p>';
    return;
  }
  section.innerHTML = '<div id="asset-documents-list"></div>';
  setupScrollableDocList("asset-documents-list", docs, (d) => resolveDocDate(d), (filtered, ul) => {
    ul.innerHTML = filtered.map((d) => `
      <li data-asset-doc-row="${d.id}">
        <a href="/api/receipts/${d.id}/file" rel="noopener" data-view-doc-url="/api/receipts/${d.id}/file" data-view-doc-title="${escHtml(d.original_filename || "Beleg")}">📎 ${escHtml(d.original_filename || "Beleg")}</a>
        <span class="row-actions">
          <span class="muted" style="font-size:0.72rem">${resolveDocDate(d) || ""}${d.detected_amount ? ` · ${fmt(d.detected_amount)}` : ""}</span>
          <a href="/api/receipts/${d.id}/file?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
          <button type="button" class="ghost-btn" data-reassign-receipt="${d.id}" title="Zu anderem Vermögenswert verschieben" style="padding:2px 6px;font-size:0.85rem">🔀</button>
          <button type="button" class="del-btn" data-delete-asset-receipt="${d.id}" title="Löschen">🗑</button>
        </span>
      </li>`).join("");
    wireDocumentViewerLinks(ul);

    ul.querySelectorAll("[data-delete-asset-receipt]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        if (!confirm("Diesen Beleg wirklich löschen?")) return;
        await authedFetch(`/api/receipts/${btn.dataset.deleteAssetReceipt}`, { method: "DELETE" });
        const form = document.getElementById("asset-form");
        await openAssetForm(form.dataset.assetId, form.dataset.type);
        document.getElementById("asset-show-documents-btn").click();
      });
    });

    ul.querySelectorAll("[data-reassign-receipt]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const li = btn.closest("li");
        if (li.querySelector(".reassign-inline")) return; // schon offen
        const currentAssetId = document.getElementById("asset-form").dataset.assetId;
        const options = allAssets.filter((a) => String(a.id) !== String(currentAssetId));
        const inline = document.createElement("div");
        inline.className = "reassign-inline";
        inline.style.cssText = "margin-top:6px;display:flex;gap:6px;width:100%";
        inline.innerHTML = `
          <select style="flex:1">${options.map((a) => `<option value="${a.id}">${ASSET_TYPE_ICONS[a.type]} ${escHtml(a.label)}</option>`).join("")}</select>
          <button type="button" class="ghost-btn" style="flex-shrink:0">Verschieben</button>`;
        li.appendChild(inline);
        inline.querySelector("button").addEventListener("click", async () => {
          const newAssetId = parseInt(inline.querySelector("select").value, 10);
          await authedFetch(`/api/receipts/${btn.dataset.reassignReceipt}/reassign-asset`, {
            method: "PATCH", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ asset_id: newAssetId }),
          });
          const form = document.getElementById("asset-form");
          await openAssetForm(form.dataset.assetId, form.dataset.type);
          document.getElementById("asset-show-documents-btn").click();
          loadVermoegenOverview();
        });
      });
    });
  });
});

document.getElementById("asset-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const assetId = form.dataset.assetId;
  const type = form.dataset.type;
  const payload = {
    type,
    label: document.getElementById("asset-label").value.trim(),
    provider: document.getElementById("asset-provider").value.trim() || null,
    account_number: document.getElementById("asset-account-number").value.trim() || null,
    account_type: document.getElementById("asset-account-type").value || null,
    purpose: document.getElementById("asset-purpose").value || null,
    person_id: document.getElementById("asset-person").value ? parseInt(document.getElementById("asset-person").value, 10) : null,
    current_value: parseGermanNumber(document.getElementById("asset-current-value").value),
    note: document.getElementById("asset-note").value.trim() || null,
  };
  if (type === "immobilie") {
    payload.financing_contract_ids = [...document.querySelectorAll("[data-financing-checkbox]:checked")]
      .map((cb) => parseInt(cb.value, 10));
  }
  if (assetId) {
    await authedFetch(`/api/assets/${assetId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
  } else {
    await authedFetch("/api/assets", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
  }
  assetFormOverlay.style.display = "none";
  loadVermoegenOverview();
});

async function populateVermoegenBulkDropdown(assets) {
  const select = document.getElementById("vermoegen-bulk-asset");
  if (!select) return;
  const previousValue = select.value;
  const pensionAccounts = await (await authedFetch("/api/pension-accounts")).json();

  const assetOptions = assets.map((a) => `<option value="asset:${a.id}">${ASSET_TYPE_ICONS[a.type]} ${escHtml(a.label)}</option>`).join("");
  const pensionOptions = pensionAccounts.map((p) =>
    `<option value="pension:${p.id}">🛡️ ${escHtml(p.label)}${p.person_name ? ` (${escHtml(p.person_name)})` : ""}</option>`
  ).join("");

  select.innerHTML = `
    ${assetOptions ? `<optgroup label="Vermögenswerte">${assetOptions}</optgroup>` : ""}
    ${pensionOptions ? `<optgroup label="Vorsorge / Rentenkonten">${pensionOptions}</optgroup>` : ""}`;
  if (previousValue) select.value = previousValue;
}

document.getElementById("vermoegen-bulk-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("vermoegen-bulk-input");
  const targetSelect = document.getElementById("vermoegen-bulk-asset");
  const resultDiv = document.getElementById("vermoegen-bulk-result");
  if (!input.files.length) { resultDiv.textContent = "Bitte zuerst eine oder mehrere Dateien auswählen."; return; }
  if (!targetSelect.value) { resultDiv.textContent = "Bitte zuerst einen Vermögenswert oder ein Rentenkonto anlegen."; return; }
  const [kind, id] = targetSelect.value.split(":");
  resultDiv.textContent = `Importiere ${input.files.length} Dateien …`;
  const formData = new FormData();
  for (const file of input.files) formData.append("files", file);
  const endpoint = kind === "pension"
    ? `/api/pension-accounts/${id}/bulk-upload-documents`
    : `/api/assets/${id}/bulk-upload-receipts`;
  const res = await authedFetch(endpoint, { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) { resultDiv.textContent = data.detail || "Fehler beim Import."; return; }
  const skipped = data.results.filter((r) => r.skipped);
  resultDiv.innerHTML = `
    <p style="margin:4px 0 0">✅ ${data.count} Datei${data.count === 1 ? "" : "en"} verarbeitet${skipped.length ? `, davon ${skipped.length} bereits vorhanden (übersprungen)` : ""}.</p>
    <p class="muted" style="font-size:0.75rem;margin:2px 0 0">Der aktuelle Wert wurde dabei bewusst nicht verändert.</p>`;
  input.value = "";
});

// ---------- Einzel-Beleg-Upload mit OCR, Zuordnung zu einem Vermögenswert ----------
document.getElementById("vermoegen-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("vermoegen-receipt-input");
  const resultDiv = document.getElementById("vermoegen-upload-result");
  if (!input.files.length) { resultDiv.textContent = "Bitte zuerst eine Datei auswählen."; return; }
  resultDiv.innerHTML = '<p class="muted">Lade hoch und lese aus …</p>';
  const formData = new FormData();
  formData.append("file", input.files[0]);
  const res = await authedFetch("/api/receipts/upload", { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) { resultDiv.textContent = data.detail || "Fehler beim Hochladen."; return; }

  const detected = data.detected;
  const pensionAccounts = await (await authedFetch("/api/pension-accounts")).json();
  const assetOptions = allAssets.map((a) => `<option value="asset:${a.id}">${ASSET_TYPE_ICONS[a.type]} ${escHtml(a.label)}</option>`).join("");
  const pensionOptions = pensionAccounts.map((p) =>
    `<option value="pension:${p.id}">🛡️ ${escHtml(p.label)}${p.person_name ? ` (${escHtml(p.person_name)})` : ""}</option>`
  ).join("");

  resultDiv.innerHTML = `
    <p class="muted" style="font-size:0.78rem">Erkannt: ${escHtml(detected.provider || "kein Anbieter")}${detected.amount != null ? ` · ${fmt(detected.amount)}` : ""}</p>
    <label class="muted" style="font-size:0.8rem">Betrag / Wert (€)</label>
    <input type="text" id="vermoegen-confirm-amount" inputmode="decimal" value="${detected.amount != null ? formatAmountForInput(detected.amount) : ""}" />
    <label class="muted" style="font-size:0.8rem">Zu welchem Vermögenswert oder Rentenkonto gehört das?</label>
    <select id="vermoegen-confirm-asset">
      ${assetOptions ? `<optgroup label="Vermögenswerte">${assetOptions}</optgroup>` : ""}
      ${pensionOptions ? `<optgroup label="Vorsorge / Rentenkonten">${pensionOptions}</optgroup>` : ""}
    </select>
    <label class="checkbox-label">
      <input type="checkbox" id="vermoegen-confirm-update-value" checked />
      <span>Aktuellen Wert aktualisieren</span>
    </label>
    <button type="button" id="vermoegen-confirm-btn" class="ghost-btn" style="width:100%;margin-top:8px">Bestätigen &amp; übernehmen</button>`;

  document.getElementById("vermoegen-confirm-btn").addEventListener("click", async () => {
    const targetValue = document.getElementById("vermoegen-confirm-asset").value;
    if (!targetValue) { alert("Bitte zuerst einen Vermögenswert oder ein Rentenkonto anlegen."); return; }
    const [kind, id] = targetValue.split(":");
    const amount = parseGermanNumber(document.getElementById("vermoegen-confirm-amount").value);
    const updateValue = document.getElementById("vermoegen-confirm-update-value").checked;
    const payload = { amount, update_expense: updateValue };
    if (kind === "pension") payload.pension_account_id = parseInt(id, 10);
    else payload.asset_id = parseInt(id, 10);
    await authedFetch(`/api/receipts/${data.receipt_id}/confirm`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    resultDiv.innerHTML = '<p style="color:var(--good)">✅ Übernommen.</p>';
    input.value = "";
    loadVermoegenOverview();
  });
});

// ---------- Intelligenter Datei-Import für Vermögenswerte — nutzt dieselbe
// generische Spalten-Zuordnungs-Infrastruktur wie Ausgaben/Einnahmen/Verträge. ----------
initSmartImport("smart-import-vermoegen", () => "assets", () => ({}), () => loadVermoegenOverview());

function renderVermoegenRealEstateChart(projection) {
  const card = document.getElementById("vermoegen-real-estate-chart-card");
  if (!projection || projection.length === 0) {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-real-estate-chart");
  const cp2 = chartPalette();
  renderInteractiveMultiLineChart(el, projection, [
    { key: "property_value", label: "Immobilienwert", color: cp2.neutral, width: 2, dashed: true, fill: false },
    { key: "remaining_debt", label: "Restschuld", color: cp2.bad, width: 2, fill: false },
    { key: "net_value", label: "Nettovermögen", color: cp2.primary, width: 2.5 },
  ], { xLabel: (p) => p.year });
}

// ---------- Depot-Positionen (Holdings) ----------
const ASSET_CLASS_LABELS = { aktie: "Aktie", anleihe: "Anleihe", cash: "Cash", rohstoffe: "Rohstoffe", sonstiges: "Sonstiges" };
const REGION_LABELS = {
  usa: "USA", europa: "Europa", schwellenlaender: "Schwellenländer",
  sonstige_industrielaender: "Sonstige Industrieländer", global: "Global", sonstiges: "Sonstiges",
};

async function loadAssetHoldings(assetId) {
  const holdings = await (await authedFetch(`/api/assets/${assetId}/holdings`)).json();
  renderAssetHoldings(assetId, holdings);
}

function renderAssetHoldings(assetId, holdings) {
  const el = document.getElementById("asset-holdings-list");
  if (holdings.length === 0) {
    el.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Positionen erfasst.</p>';
    return;
  }
  const total = holdings.reduce((s, h) => s + (h.current_value || 0), 0);
  el.innerHTML = holdings.map((h) => `
    <div class="row-actions" style="justify-content:space-between;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.06)">
      <span style="font-size:0.82rem">
        ${escHtml(h.name)}${h.isin ? ` <span class="muted" style="font-size:0.7rem">${escHtml(h.isin)}</span>` : ""}<br>
        <span class="muted" style="font-size:0.72rem">${h.asset_class ? escHtml(ASSET_CLASS_LABELS[h.asset_class] || h.asset_class) : "Klasse?"} · ${h.region ? escHtml(REGION_LABELS[h.region] || h.region) : "Region?"}</span>
      </span>
      <span style="text-align:right;font-size:0.82rem">
        ${fmt(h.current_value)}<br>
        <span class="muted" style="font-size:0.72rem">${total > 0 ? Math.round((h.current_value / total) * 100) : 0}%</span>
        <button type="button" class="del-btn" data-delete-holding="${h.id}" title="Löschen" style="margin-left:4px">🗑</button>
      </span>
    </div>`).join("");

  el.querySelectorAll("[data-delete-holding]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diese Position wirklich löschen?")) return;
      await authedFetch(`/api/asset-holdings/${btn.dataset.deleteHolding}`, { method: "DELETE" });
      loadAssetHoldings(assetId);
    });
  });
}

document.getElementById("asset-add-holding-btn").addEventListener("click", async () => {
  const assetId = document.getElementById("asset-form").dataset.assetId;
  if (!assetId) return;
  const name = document.getElementById("asset-holding-name").value.trim();
  const value = parseGermanNumber(document.getElementById("asset-holding-value").value);
  if (!name || value == null || Number.isNaN(value)) {
    alert("Bitte mindestens Name und Wert angeben.");
    return;
  }
  await authedFetch(`/api/assets/${assetId}/holdings`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name,
      isin: document.getElementById("asset-holding-isin").value.trim() || null,
      current_value: value,
      asset_class: document.getElementById("asset-holding-class").value || null,
      region: document.getElementById("asset-holding-region").value || null,
    }),
  });
  document.getElementById("asset-holding-name").value = "";
  document.getElementById("asset-holding-isin").value = "";
  document.getElementById("asset-holding-value").value = "";
  document.getElementById("asset-holding-class").value = "";
  document.getElementById("asset-holding-region").value = "";
  loadAssetHoldings(assetId);
});

// ---------- Asset-Allokation (Vermögensübersicht) ----------
function renderVermoegenAllocation(allocation) {
  const card = document.getElementById("vermoegen-allocation-card");
  if (!allocation || !allocation.total_value) {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-allocation-charts");

  const renderBar = (title, items) => `
    <div>
      <h3 style="font-size:0.85rem;margin:0 0 8px">${title}</h3>
      ${items.map((item) => `
        <div style="margin-bottom:6px">
          <div class="row-actions" style="justify-content:space-between;font-size:0.78rem">
            <span>${ASSET_CLASS_LABELS[item.key] || REGION_LABELS[item.key] || item.key}</span>
            <span>${item.percent}%${item.target_percent != null ? ` <span class="muted">(Soll ${item.target_percent}%${item.deviation ? `, ${item.deviation > 0 ? "+" : ""}${item.deviation}` : ""})</span>` : ""}</span>
          </div>
          <div style="background:rgba(255,255,255,0.08);border-radius:4px;height:6px;overflow:hidden;position:relative">
            <div style="background:${item.deviation != null && Math.abs(item.deviation) > 10 ? "var(--warn)" : "var(--accent)"};height:100%;width:${item.percent}%"></div>
            ${item.target_percent != null ? `<div style="position:absolute;top:0;bottom:0;left:${item.target_percent}%;width:2px;background:var(--text)"></div>` : ""}
          </div>
        </div>`).join("")}
    </div>`;

  el.innerHTML = renderBar("Nach Anlageklasse", allocation.by_class) + renderBar("Nach Region", allocation.by_region);
}

// ---------- Ziel-Allokation festlegen ----------
const allocationTargetsOverlay = document.getElementById("allocation-targets-overlay");
const ALLOCATION_TARGET_FIELDS = ["aktie", "anleihe", "cash", "rohstoffe", "sonstiges"];

document.getElementById("vermoegen-set-targets-btn").addEventListener("click", async () => {
  const current = await (await authedFetch("/api/vermoegen/allocation-targets")).json();
  const currentMap = Object.fromEntries(current.map((t) => [t.asset_class, t.target_percent]));
  for (const cls of ALLOCATION_TARGET_FIELDS) {
    document.getElementById(`target-${cls}`).value = currentMap[cls] ?? "";
  }
  allocationTargetsOverlay.style.display = "flex";
});

document.getElementById("allocation-targets-cancel-btn").addEventListener("click", () => {
  allocationTargetsOverlay.style.display = "none";
});

document.getElementById("allocation-targets-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const values = [];
  for (const cls of ALLOCATION_TARGET_FIELDS) {
    const raw = document.getElementById(`target-${cls}`).value.trim();
    if (raw === "") continue;
    const num = parseGermanNumber(raw);
    if (num != null && !Number.isNaN(num)) values.push({ asset_class: cls, target_percent: num });
  }
  await authedFetch("/api/vermoegen/allocation-targets", {
    method: "PUT", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(values),
  });
  allocationTargetsOverlay.style.display = "none";
  loadVermoegenOverview();
});

// ---------- Liquiditätsreserve ----------
function renderVermoegenLiquidity(reserve) {
  const card = document.getElementById("vermoegen-liquidity-card");
  if (!reserve || reserve.status === "unbekannt") {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-liquidity-content");
  const color = reserve.status === "gut" ? "var(--good)" : "var(--warn)";
  const icon = reserve.status === "gut" ? "✅" : "⚠️";
  const hint = reserve.status === "niedrig"
    ? '<p class="muted" style="font-size:0.78rem;margin:4px 0 0">Unter der empfohlenen 3-Monats-Grenze.</p>'
    : reserve.status === "zu_viel"
    ? '<p class="muted" style="font-size:0.78rem;margin:4px 0 0">Deutlich über den empfohlenen 3–6 Monaten — das überschüssige Kapital arbeitet auf dem Konto nicht, eine Anlage außerhalb der Reserve könnte sich lohnen.</p>'
    : "";
  el.innerHTML = `
    <p style="font-size:0.95rem;margin:0 0 6px">${icon} <b style="color:${color}">${reserve.months_covered} Monate</b> auf Konten verfügbar</p>
    <p class="muted" style="font-size:0.78rem;margin:0">${fmt(reserve.total_konten)} Kontostand ÷ ${fmt(reserve.monthly_fixed_expenses)} monatliche Fixkosten</p>
    ${hint}`;
}

// ---------- Vermögens-Historie ----------
async function loadVermoegenHistory() {
  const history = await (await authedFetch("/api/vermoegen/history")).json();
  renderVermoegenHistory(history);
}

function renderVermoegenHistory(history) {
  const card = document.getElementById("vermoegen-history-chart-card");
  card.style.display = "block";
  const el = document.getElementById("vermoegen-history-chart");

  if (!history || history.length < 2) {
    const count = history ? history.length : 0;
    el.innerHTML = `<p class="muted" style="font-size:0.85rem">Noch nicht genug Verlaufsdaten (${count} von mindestens 2 Tagen vorhanden). Es wird täglich ein Datenpunkt gespeichert — ab morgen erscheint hier der Verlauf.</p>`;
    return;
  }

  const cp3 = chartPalette();
  renderInteractiveMultiLineChart(el, history, [
    { key: "total_networth", color: cp3.primary, label: "Gesamtvermögen", width: 2.5 },
    { key: "liquid", color: cp3.accent, label: "Liquide Mittel & Depots", width: 2, fill: false },
    { key: "pension_capital", color: cp3.warn, label: "Private Altersvorsorge", width: 2, fill: false },
    { key: "immobilien_netto", color: cp3.purple, label: "Immobilien netto", width: 2, fill: false },
  ], { xLabel: (p) => p.snapshot_date });
}

// ---------- Steuer & Förderung ----------
async function loadSteuerOverview() {
  const data = await (await authedFetch("/api/steuer/overview")).json();
  renderSteuerOverview(data);
}

function renderSteuerOverview(data) {
  const el = document.getElementById("steuer-content");
  let html = "";

  if (data.freistellungsauftrag.length > 0) {
    html += `<h3 style="font-size:0.85rem;margin:0 0 8px">Freistellungsauftrag (Sparerpauschbetrag 2026: 1.000 €/Person)</h3>`;
    html += data.freistellungsauftrag.map((f) => `
      <div class="row-actions" style="justify-content:space-between;font-size:0.85rem;padding:4px 0">
        <span>${escHtml(f.person_name)}</span>
        <span>${fmt(f.used)} genutzt · <b style="color:${f.remaining >= 0 ? "var(--good)" : "var(--bad)"}">${fmt(f.remaining)} frei</b></span>
      </div>`).join("");
    html += `<p class="muted" style="font-size:0.72rem;margin:6px 0 0">Genutzten Betrag unter Einstellungen → Personen pflegen.</p>`;
  } else {
    html += '<p class="muted" style="font-size:0.85rem">Keine Elternteile hinterlegt.</p>';
  }

  html += `<div class="divider"></div><h3 style="font-size:0.85rem;margin:0 0 8px">Riester-Förderung</h3>`;
  if (data.riester.length > 0) {
    html += data.riester.map((r) => `
      <div style="padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.06)">
        <div class="row-actions" style="justify-content:space-between;font-size:0.85rem">
          <span>${escHtml(r.label)}${r.provider ? ` · ${escHtml(r.provider)}` : ""} <span class="tag">${escHtml(r.person_name)}</span></span>
          <b>${fmt(r.zulage_gesamt_max)}/Jahr</b>
        </div>
        <p class="muted" style="font-size:0.72rem;margin:2px 0 0">${fmt(r.grundzulage)} Grundzulage + bis zu ${fmt(r.kinderzulage_max)} Kinderzulage</p>
      </div>`).join("");
    html += `<p class="muted" style="font-size:0.72rem;margin:6px 0 0">${data.riester_note}</p>`;
  } else {
    html += '<p class="muted" style="font-size:0.85rem">Kein Riester-Vertrag als solcher markiert (unter Vorsorge → Rentenkonto bearbeiten).</p>';
  }

  el.innerHTML = html;
}

document.getElementById("secrets-install-btn")?.addEventListener("click", async (e) => {
  const btn = e.target;
  btn.disabled = true; btn.textContent = "Installiere …";
  const r = await authedFetch("/api/secrets/install-keyring", { method: "POST" });
  const data = await r.json().catch(() => ({}));
  btn.disabled = false; btn.textContent = "🔧 keyring jetzt installieren";
  if (!r.ok) {
    alert("Installation fehlgeschlagen:\n\n" + (data.detail || "Unbekannter Fehler"));
    return;
  }
  const moved = data.moved || {};
  alert(moved.moved
    ? `✅ keyring installiert und ${moved.moved} Zugangsdaten sofort in den ${moved.keychain} verschoben. Kein Neustart nötig.`
    : "✅ keyring installiert.");
  await renderSecretsStatus();
});

// ---------- Vermögen: Unter-Reiter (Übersicht / Vermögen / Verbindlichkeiten) ----------
document.querySelectorAll(".vermoegen-subtab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".vermoegen-subtab-btn").forEach((b) => b.classList.toggle("active-scale", b === btn));
    document.querySelectorAll(".vermoegen-subtab-panel").forEach((panel) => {
      panel.style.display = panel.id === `vermoegen-subtab-${btn.dataset.vsubtab}` ? "block" : "none";
    });
    if (btn.dataset.vsubtab === "verbindlichkeiten") loadVerbindlichkeiten();
  });
});

let verbindlichkeitenSelectedId = null;

document.getElementById("add-financing-btn").addEventListener("click", () => openAddExpenseForm("Haus::Finanzierung"));

async function loadVerbindlichkeiten() {
  // Bankverknüpfungen für das ⋯-Menü und die "Bank"-Markierung (auch wenn Vermögen noch nicht geöffnet wurde)
  const accs = await (await authedFetch("/api/banks/accounts")).json().catch(() => []);
  if (Array.isArray(accs)) bankAccountsAll = accs;
  if (allContracts.length === 0) allContracts = await (await authedFetch("/api/contracts")).json();
  const data = await (await authedFetch("/api/verbindlichkeiten/overview")).json();
  renderVerbindlichkeitenSummary(data);
  renderVerbindlichkeitenList();
  renderVerbindlichkeitenChart(data);
}

function renderVerbindlichkeitenSummary(data) {
  const stats = document.getElementById("verbindlichkeiten-summary-stats");
  stats.innerHTML = `
    <div><span class="label">Gesamte Restschuld</span><span>${fmt(data.total_remaining_debt)}</span></div>
    <div><span class="label">Ø Zinssatz (gewichtet)</span><span>${data.average_interest_rate != null ? data.average_interest_rate + " %" : "–"}</span></div>`;

  const locksEl = document.getElementById("verbindlichkeiten-rate-locks");
  if (!data.upcoming_rate_locks || data.upcoming_rate_locks.length === 0) {
    locksEl.innerHTML = "";
    return;
  }
  locksEl.innerHTML = `
    <div class="divider"></div>
    <h3 style="font-size:0.85rem;margin:0 0 8px">Anstehende Zinsbindungsenden</h3>
    ${data.upcoming_rate_locks.map((l) => `
      <div class="row-actions" style="justify-content:space-between;font-size:0.85rem;padding:3px 0">
        <span>${escHtml(l.label)}</span>
        <span>${l.contract_end} <span class="muted">(${fmt(l.remaining_debt)})</span></span>
      </div>`).join("")}`;
}

function renderVerbindlichkeitenList() {
  const el = document.getElementById("verbindlichkeiten-list");
  const financings = allContracts.filter((c) => c.subcategory === "Finanzierung" && c.status === "active");

  if (financings.length === 0) {
    el.innerHTML = '<p class="muted">Keine laufende Finanzierung unter Ausgaben hinterlegt.</p>';
    return;
  }

  el.innerHTML = `<ul class="contract-list">${financings.map((f) => {
    // Manche Nutzer tragen den Anbieter bereits als Teil des Labels ein
    // (z.B. "BBBank e.G. DE70...") -- den Anbieter dann NICHT nochmal
    // separat anzeigen, sonst erscheint er doppelt und ohne sichtbaren
    // Abstand (Flex-Gap zwischen den Elementen ist bewusst klein).
    const showProvider = f.provider && !f.label.includes(f.provider);
    const fixedUntil = f.fixed_interest_until
      ? new Date(f.fixed_interest_until).toLocaleDateString("de-DE", { month: "2-digit", year: "numeric" })
      : null;
    return `
    <li data-financing-row="${f.id}" style="cursor:pointer;flex-wrap:wrap;${String(f.id) === String(verbindlichkeitenSelectedId) ? `background:${cssVarToRgba("--accent", 0.08)}` : ""}">
      <div class="contract-main">
        ${rowMenuButtonHTML("financing", f.id)}
        <span class="contract-label">${escHtml(f.label)}</span>
        ${showProvider ? `<span class="muted" style="font-size:0.78rem"> · ${escHtml(f.provider)}</span>` : ""}
        ${(() => { const bl = bankAccountsOfContract(f.id);
          if (!bl.length) return "";
          const ts = bl.map((b) => b.balance_updated_at).filter(Boolean).sort().pop();
          const when = ts ? ` · ${new Date(ts).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}` : "";
          return `<span class="tag" title="Mit Bankkonto verbunden — Restschuld kommt von der Bank. Umsätze und Zuordnung über ⋯">🏦 Bank${when}</span>`; })()}
      </div>
      <div class="contract-amount row-actions" style="justify-content:flex-end;flex-wrap:wrap;gap:4px 10px;width:100%">
        <b class="inline-editable-value" data-inline-edit-id="${f.id}" data-raw-value="${f.remaining_debt ?? 0}" title="Klicken zum Bearbeiten">${fmt(f.remaining_debt)}</b>
        <span class="muted" style="font-size:0.75rem;white-space:nowrap">${f.interest_rate || 0}% Zins${fixedUntil ? ` · Bindung bis ${fixedUntil}` : ""}</span>
      </div>
    </li>`;
  }).join("")}</ul>`;

  wireInlineValueEdit(el, "[data-inline-edit-id]", {
    endpoint: (id) => `/api/contracts/${id}`,
    field: "remaining_debt",
    reload: () => { allContracts = []; loadVerbindlichkeiten(); },
  });

  el.querySelectorAll("[data-financing-row]").forEach((row) => {
    row.addEventListener("click", (e) => {
      if (e.target.closest("[data-row-menu-trigger]")) return;
      const id = row.dataset.financingRow;
      verbindlichkeitenSelectedId = (String(verbindlichkeitenSelectedId) === String(id)) ? null : id;
      renderVerbindlichkeitenList();
      loadVerbindlichkeitenChartForSelection();
    });
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuExternalKey = `contract:${row.dataset.financingRow}`;
      showExternalContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(el, "financing", (id, x, y) => {
    contextMenuExternalKey = `contract:${id}`;
    showExternalContextMenu(x, y);
  });
}

async function renderVerbindlichkeitenChart(overviewData) {
  const title = document.getElementById("verbindlichkeiten-chart-title");
  const container = document.getElementById("verbindlichkeiten-chart");
  if (verbindlichkeitenSelectedId) {
    const financing = allContracts.find((c) => String(c.id) === String(verbindlichkeitenSelectedId));
    title.textContent = `📈 Tilgungsplan — ${financing ? financing.label : ""}`;
    const res = await authedFetch(`/api/contracts/${verbindlichkeitenSelectedId}/repayment-schedule`);
    renderRepaymentChart("verbindlichkeiten-chart", await res.json());
  } else {
    title.textContent = "📈 Tilgungsplan — alle Finanzierungen zusammen";
    renderRepaymentChart("verbindlichkeiten-chart", overviewData.aggregated_schedule);
  }
}

async function loadVerbindlichkeitenChartForSelection() {
  const data = await (await authedFetch("/api/verbindlichkeiten/overview")).json();
  renderVerbindlichkeitenChart(data);
}


// ---------- Kuchendiagramm: Verteilung nach Anlageklassen (gesamtes Nettovermögen) ----------
// PIE_COLORS entfernt zugunsten von chartColorsList() (theme-bewusst)

function renderVermoegenPieChart(pieAllocation) {
  const card = document.getElementById("vermoegen-pie-card");
  if (!pieAllocation || pieAllocation.length === 0) {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-pie-chart");

  const size = 220, cx = size / 2, cy = size / 2, r = 90;
  let cumulativeAngle = -90; // oben beginnen, im Uhrzeigersinn

  const polarToXY = (angleDeg, radius) => {
    const rad = (angleDeg * Math.PI) / 180;
    return [cx + radius * Math.cos(rad), cy + radius * Math.sin(rad)];
  };
  const pieColors = chartColorsList();

  const slices = pieAllocation.map((item, i) => {
    const angle = (item.percent / 100) * 360;
    const startAngle = cumulativeAngle;
    const endAngle = cumulativeAngle + angle;
    cumulativeAngle = endAngle;
    const [x1, y1] = polarToXY(startAngle, r);
    const [x2, y2] = polarToXY(endAngle, r);
    const largeArc = angle > 180 ? 1 : 0;
    const color = pieColors[i % pieColors.length];
    // Ein Vollkreis (100% eine einzige Kategorie) laesst sich nicht als
    // einzelner Arc-Pfad zeichnen (Start=Ende) -> als Kreis behandeln.
    const path = item.percent >= 99.95
      ? `M ${cx - r} ${cy} A ${r} ${r} 0 1 1 ${cx + r} ${cy} A ${r} ${r} 0 1 1 ${cx - r} ${cy}`
      : `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;
    return { path, color, item };
  });

  el.innerHTML = `
    <div style="display:flex;gap:20px;flex-wrap:wrap;align-items:center;justify-content:center">
      <svg viewBox="0 0 ${size} ${size}" width="180" height="180" style="overflow:visible;max-width:100%;flex-shrink:0">
        <defs>
          <filter id="pie-shadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="2" stdDeviation="4" flood-opacity="0.25" />
          </filter>
        </defs>
        <g filter="url(#pie-shadow)">
          ${slices.map((s) => `<path class="pie-slice" d="${s.path}" fill="${s.color}" stroke="var(--bg)" stroke-width="2.5" style="transform-origin:${cx}px ${cy}px;transition:transform 0.15s ease"><title>${s.item.key}: ${fmt(s.item.value)} (${s.item.percent}%)</title></path>`).join("")}
        </g>
      </svg>
      <div style="flex:1;min-width:180px">
        ${slices.map((s) => `
          <div class="row-actions" style="justify-content:space-between;font-size:0.82rem;padding:3px 0">
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:${s.color};vertical-align:middle;margin-right:6px"></span>${s.item.key}</span>
            <span>${s.item.percent}% <span class="muted">(${fmt(s.item.value)})</span></span>
          </div>`).join("")}
      </div>
    </div>`;

  el.querySelectorAll(".pie-slice").forEach((slice) => {
    slice.addEventListener("mouseenter", () => { slice.style.transform = "scale(1.035)"; });
    slice.addEventListener("mouseleave", () => { slice.style.transform = "scale(1)"; });
  });
}

// ---------- Inline-Bearbeitung eines Geldwerts (ohne das volle Formular zu
// oeffnen) -- generalisiert, damit Vermoegen UND Verbindlichkeiten exakt
// dasselbe Verhalten zeigen: in Ruhe steht der Wert fett formatiert da,
// ein Klick macht ihn editierbar, Enter/Blur speichert, Escape verwirft. ----------
function wireInlineValueEdit(container, selector, { endpoint, field, reload }) {
  container.querySelectorAll(selector).forEach((el) => {
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      if (el.querySelector("input")) return; // bereits im Bearbeiten-Modus
      const id = el.dataset.inlineEditId;
      const rawValue = el.dataset.rawValue;
      el.innerHTML = `<input type="text" inputmode="decimal" value="${formatAmountForInput(rawValue)}" style="width:110px;text-align:right;font-weight:600" />`;
      const input = el.querySelector("input");
      input.focus();
      input.select();

      let settled = false;
      const commit = async () => {
        if (settled) return;
        settled = true;
        const newValue = parseGermanNumber(input.value);
        if (newValue == null || Number.isNaN(newValue)) {
          reload();
          return;
        }
        await authedFetch(endpoint(id), {
          method: "PATCH", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ [field]: newValue }),
        });
        reload();
      };
      const cancel = () => {
        if (settled) return;
        settled = true;
        reload();
      };

      input.addEventListener("blur", commit);
      input.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") { ev.preventDefault(); input.blur(); }
        if (ev.key === "Escape") { ev.preventDefault(); cancel(); }
      });
    });
  });
}

function wireInlineAssetValueEdit(container) {
  wireInlineValueEdit(container, "[data-inline-edit-id]", {
    endpoint: (id) => `/api/assets/${id}`,
    field: "current_value",
    reload: loadVermoegenOverview,
  });
}

// ---------- Dokument-/Beleg-Betrachter (In-App, mit garantiertem
// Schließen-Button) — ersetzt target="_blank"-Links für Belege, da diese
// in der auf dem iOS-Homescreen installierten Standalone-App oft ohne
// jede Browser-Oberfläche (und damit ohne Zurueck-Moeglichkeit) geoeffnet
// werden. ----------
const documentViewerOverlay = document.getElementById("document-viewer-overlay");
const documentViewerFrame = document.getElementById("document-viewer-frame");
let documentViewerBlobUrl = null; // zum Aufräumen beim Schließen, siehe unten

function openDocumentViewer(url, title, blob) {
  document.getElementById("document-viewer-title").textContent = title || "";
  documentViewerOverlay.style.display = "flex";
  const isPdf = blob && (blob.type === "application/pdf" || /\.pdf$/i.test(title || ""));
  if (isPdf) {
    // Eigenes Rendering: ganze Seite passt auf den Bildschirm. Schlägt es fehl -> wie bisher nativer Viewer.
    documentViewerFrame.src = "about:blank";
    openPdfViewer(blob).catch((err) => { console.warn("PDF.js-Anzeige fehlgeschlagen, nutze nativen Viewer:", err); closePdfViewer(); documentViewerFrame.src = url; });
  } else {
    documentViewerFrame.src = url;
  }
  // Seiten-weites Pinch-Zoom deaktivieren, solange der Betrachter offen ist:
  // iOS hält "position:fixed"-Elemente (wie die Kopfzeile mit dem
  // Schließen-Knopf) beim Zoomen NICHT am sichtbaren Bereich fest, sondern
  // nur am Layout-Viewport -- beim Zoomen kann der Knopf dadurch aus dem
  // sichtbaren Bereich rutschen, besonders bei mehrseitigen PDFs (z.B.
  // Gehaltsabrechnungen), die eher zum Hineinzoomen einladen. Zoomen INNERHALB
  // der PDF bleibt über den eingebetteten PDF-Viewer im iframe möglich, der
  // von dieser Einstellung nicht betroffen ist.
  const viewport = document.querySelector('meta[name="viewport"]');
  if (viewport) {
    viewport.dataset.prevContent = viewport.content;
    viewport.content = "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover";
  }
}
function closeDocumentViewer() {
  closePdfViewer();
  documentViewerOverlay.style.display = "none";
  documentViewerFrame.src = "about:blank"; // Laufende Wiedergabe/Ladevorgänge stoppen
  if (documentViewerBlobUrl) {
    URL.revokeObjectURL(documentViewerBlobUrl); // sonst sammelt sich mit jedem geöffneten Beleg Speicher an
    documentViewerBlobUrl = null;
  }
  const viewport = document.querySelector('meta[name="viewport"]');
  if (viewport && viewport.dataset.prevContent) {
    viewport.content = viewport.dataset.prevContent;
    delete viewport.dataset.prevContent;
  }
}

// ---- PDF-Anzeige mit eigenem Rendering (PDF.js): jede Seite wird so skaliert, dass eine GANZE Seite
// (Breite UND Höhe) auf den Bildschirm passt -- unabhängig von der in der Datei hinterlegten Seitengröße.
// Der native iOS-Viewer im <iframe> zeigt große Scans in Originalgröße und lässt sich nicht einpassen.
// Zoom: Knöpfe (− ⤢ ＋), Pinch, Doppeltippen, Strg+Mausrad. 1 = ganze Seite sichtbar.
const pdfView = { doc: null, zoom: 1, token: 0, sizes: [], el: null, inner: null };
const PDF_ZOOM_MIN = 0.5, PDF_ZOOM_MAX = 6;

function pdfFitScale(i) {
  const w = pdfView.el.clientWidth - 16, h = pdfView.el.clientHeight - 16;
  const s = pdfView.sizes[i];
  return Math.max(0.05, Math.min(w / s.width, h / s.height)) * pdfView.zoom;
}

function pdfLayout() {
  pdfView.inner.querySelectorAll("canvas").forEach((c, i) => {
    const sc = pdfFitScale(i), s = pdfView.sizes[i];
    c.style.width = `${s.width * sc}px`;
    c.style.height = `${s.height * sc}px`;
  });
}

async function pdfRenderAll() {
  const token = ++pdfView.token;
  const dpr = window.devicePixelRatio || 1;
  const canvases = [...pdfView.inner.querySelectorAll("canvas")];
  for (let i = 0; i < canvases.length; i++) {
    if (token !== pdfView.token || !pdfView.doc) return;   // neuerer Zoom/Schließen hat übernommen
    const page = await pdfView.doc.getPage(i + 1);
    const sc = pdfFitScale(i);
    // Pixelzahl begrenzen (sonst sprengen große Scans bei hohem Zoom den Speicher von iOS)
    const cssW = pdfView.sizes[i].width * sc, cssH = pdfView.sizes[i].height * sc;
    const ratio = Math.min(dpr, Math.sqrt(12e6 / (cssW * cssH)));
    const viewport = page.getViewport({ scale: sc * ratio });
    const c = canvases[i];
    const off = document.createElement("canvas");   // erst offscreen zeichnen, dann tauschen: kein Flackern
    off.width = Math.floor(viewport.width); off.height = Math.floor(viewport.height);
    await page.render({ canvasContext: off.getContext("2d"), viewport }).promise;
    if (token !== pdfView.token) return;
    c.width = off.width; c.height = off.height;
    c.getContext("2d").drawImage(off, 0, 0);
  }
}

function pdfSetZoom(newZoom, fx, fy) {
  const el = pdfView.el;
  newZoom = Math.min(PDF_ZOOM_MAX, Math.max(PDF_ZOOM_MIN, newZoom));
  if (Math.abs(newZoom - pdfView.zoom) < 0.001) return;
  fx = fx ?? el.clientWidth / 2; fy = fy ?? el.clientHeight / 2;
  const ratio = newZoom / pdfView.zoom;
  const cx = el.scrollLeft + fx, cy = el.scrollTop + fy;   // Fixpunkt im Dokument bleibt unter dem Finger
  pdfView.zoom = newZoom;
  pdfLayout();
  el.scrollLeft = cx * ratio - fx;
  el.scrollTop = cy * ratio - fy;
  pdfRenderAll();
}

async function openPdfViewer(blob) {
  const pdfjsLib = await import("/vendor/pdfjs/pdf.min.mjs");
  pdfjsLib.GlobalWorkerOptions.workerSrc = "/vendor/pdfjs/pdf.worker.min.mjs";
  const doc = await pdfjsLib.getDocument({ data: new Uint8Array(await blob.arrayBuffer()) }).promise;
  pdfView.el = document.getElementById("document-viewer-pages");
  pdfView.inner = document.getElementById("document-viewer-pages-inner");
  documentViewerFrame.style.display = "none";
  pdfView.el.style.display = "block";
  document.getElementById("document-viewer-zoom").style.display = "flex";
  pdfView.doc = doc; pdfView.zoom = 1; pdfView.sizes = [];
  pdfView.inner.innerHTML = "";
  for (let i = 1; i <= doc.numPages; i++) {
    const v = (await doc.getPage(i)).getViewport({ scale: 1 });
    pdfView.sizes.push({ width: v.width, height: v.height });
    const c = document.createElement("canvas");
    c.style.cssText = "display:block;margin:8px auto;background:#fff;box-shadow:0 1px 6px rgba(0,0,0,0.4)";
    pdfView.inner.appendChild(c);
  }
  pdfView.el.scrollTop = 0; pdfView.el.scrollLeft = 0;
  pdfLayout();
  pdfRenderAll();
}

function closePdfViewer() {
  pdfView.token++;
  if (pdfView.doc) { try { pdfView.doc.destroy(); } catch (e) { /* egal */ } }
  pdfView.doc = null;
  if (pdfView.inner) pdfView.inner.innerHTML = "";
  if (pdfView.el) { pdfView.el.style.display = "none"; pdfView.inner.style.transform = ""; }
  document.getElementById("document-viewer-zoom").style.display = "none";
  documentViewerFrame.style.display = "";
}

(function wirePdfViewerGestures() {
  const el = document.getElementById("document-viewer-pages");
  const inner = document.getElementById("document-viewer-pages-inner");
  const zoomBy = (f) => pdfSetZoom(pdfView.zoom * f);
  document.getElementById("document-viewer-zoom-in").addEventListener("click", () => zoomBy(1.4));
  document.getElementById("document-viewer-zoom-out").addEventListener("click", () => zoomBy(1 / 1.4));
  document.getElementById("document-viewer-zoom-fit").addEventListener("click", () => {
    pdfSetZoom(1); el.scrollLeft = 0;
  });
  el.addEventListener("wheel", (e) => {
    if (!e.ctrlKey) return;
    e.preventDefault();
    const r = el.getBoundingClientRect();
    pdfSetZoom(pdfView.zoom * Math.exp(-e.deltaY * 0.01), e.clientX - r.left, e.clientY - r.top);
  }, { passive: false });
  // Pinch (zwei Finger): während der Geste nur skalierte Vorschau, danach einmal scharf neu rendern.
  let pinch = null, lastTap = 0, moved = false;
  const dist = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  el.addEventListener("touchstart", (e) => {
    moved = false;
    if (e.touches.length === 2) {
      const r = el.getBoundingClientRect();
      pinch = { d0: dist(e.touches), ratio: 1,
        fx: (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left,
        fy: (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top };
      inner.style.transformOrigin = `${el.scrollLeft + pinch.fx}px ${el.scrollTop + pinch.fy}px`;
    }
  }, { passive: true });
  el.addEventListener("touchmove", (e) => {
    moved = true;
    if (pinch && e.touches.length === 2) {
      e.preventDefault();
      const target = pdfView.zoom * (dist(e.touches) / pinch.d0);
      pinch.ratio = Math.min(PDF_ZOOM_MAX, Math.max(PDF_ZOOM_MIN, target)) / pdfView.zoom;
      inner.style.transform = `scale(${pinch.ratio})`;
    }
  }, { passive: false });
  el.addEventListener("touchend", (e) => {
    if (pinch && e.touches.length < 2) {
      const p = pinch; pinch = null;
      inner.style.transform = "";
      pdfSetZoom(pdfView.zoom * p.ratio, p.fx, p.fy);
      return;
    }
    // Doppeltippen: zwischen ganzer Seite und 2,5-fach wechseln
    if (!moved && e.changedTouches.length === 1 && e.touches.length === 0) {
      const now = Date.now();
      if (now - lastTap < 300) {
        const r = el.getBoundingClientRect(), t = e.changedTouches[0];
        pdfSetZoom(pdfView.zoom > 1.2 ? 1 : 2.5, t.clientX - r.left, t.clientY - r.top);
        lastTap = 0;
      } else lastTap = now;
    }
  }, { passive: true });
  window.addEventListener("resize", () => { if (pdfView.doc) { pdfLayout(); pdfRenderAll(); } });
})();
document.getElementById("document-viewer-close-btn").addEventListener("click", closeDocumentViewer);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && documentViewerOverlay.style.display !== "none") closeDocumentViewer();
});

function wireDocumentViewerLinks(container) {
  container.querySelectorAll("[data-view-doc-url]").forEach((link) => {
    link.addEventListener("click", async (e) => {
      e.preventDefault();
      const url = link.dataset.viewDocUrl;
      const title = link.dataset.viewDocTitle;
      // Passwortgeschützte PDFs vorab erkennen: der In-App-Betrachter nutzt
      // ein <iframe>, das unter iOS/Safari keinen Passwort-Dialog anzeigen
      // kann -- die Datei bliebe darin einfach leer, mit einem "Inhalt
      // fehlt"-Symbol statt einer Passwortabfrage. Für diesen Fall wird eine
      // eigene Wrapper-Seite mit garantiert erreichbarem Schließen-Knopf
      // geöffnet (NICHT die rohe PDF-URL direkt) -- eine reine PDF-Datei hat
      // keinerlei eigene Bedienelemente, und in der als Homescreen-App
      // installierten PWA fehlt dabei auch die normale Browser-Oberfläche
      // mit Zurück-Knopf komplett, was genau in eine Sackgasse ohne jeden
      // Ausweg führte.
      try {
        const res = await authedFetch(url);
        if (res.headers.get("X-Document-Encrypted") === "true") {
          window.open(`/api/documents/pdf-viewer?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title || "Dokument")}`, "_blank");
          return;
        }
        const blob = await res.blob();
        if (documentViewerBlobUrl) URL.revokeObjectURL(documentViewerBlobUrl);
        documentViewerBlobUrl = URL.createObjectURL(blob);
        openDocumentViewer(documentViewerBlobUrl, title, blob);
      } catch (err) {
        // Vorab-Prüfung fehlgeschlagen (z.B. Netzwerkfehler) -- trotzdem
        // versuchen, normal zu öffnen, statt den Beleg komplett zu verwehren.
        openDocumentViewer(url, title);
      }
    });
  });
}

// ---------- Person-Details: Steuer-/SV-Daten + Dokumente ----------
const personDetailOverlay = document.getElementById("person-detail-overlay");
let personDetailCurrentId = null;

function openPersonDetailForm(personId) {
  const person = allFamilyMembers.find((m) => String(m.id) === String(personId));
  if (!person) return;
  personDetailCurrentId = person.id;

  document.getElementById("person-detail-name").value = person.name;
  document.getElementById("person-detail-role").value = person.role;
  document.getElementById("person-detail-freistellung-group").style.display = person.role === "elternteil" ? "block" : "none";
  document.getElementById("person-detail-freistellung").value = person.freistellungsauftrag_used ?? "";
  document.getElementById("person-detail-sv-nummer").value = person.sv_nummer || "";
  document.getElementById("person-detail-steuer-id").value = person.steuer_id || "";
  document.getElementById("person-detail-steuerklasse").value = person.steuerklasse || "";
  document.getElementById("person-detail-krankenkasse").value = person.krankenkasse || "";
  document.getElementById("person-detail-etin").value = person.etin || "";
  document.getElementById("person-detail-steuernummer").value = person.steuernummer || "";
  document.getElementById("person-detail-finanzamt").value = person.finanzamt || "";
  document.getElementById("person-detail-documents").style.display = "none";
  document.getElementById("person-detail-documents-list").innerHTML = "";

  personDetailOverlay.style.display = "flex";
}

document.getElementById("person-detail-role").addEventListener("change", (e) => {
  document.getElementById("person-detail-freistellung-group").style.display = e.target.value === "elternteil" ? "block" : "none";
});

document.getElementById("person-detail-cancel-btn").addEventListener("click", () => {
  personDetailOverlay.style.display = "none";
});

document.getElementById("person-detail-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById("person-detail-name").value.trim(),
    role: document.getElementById("person-detail-role").value,
    sv_nummer: document.getElementById("person-detail-sv-nummer").value.trim() || null,
    steuer_id: document.getElementById("person-detail-steuer-id").value.trim() || null,
    steuerklasse: document.getElementById("person-detail-steuerklasse").value.trim() || null,
    krankenkasse: document.getElementById("person-detail-krankenkasse").value.trim() || null,
    etin: document.getElementById("person-detail-etin").value.trim() || null,
    steuernummer: document.getElementById("person-detail-steuernummer").value.trim() || null,
    finanzamt: document.getElementById("person-detail-finanzamt").value.trim() || null,
  };
  if (payload.role === "elternteil") {
    payload.freistellungsauftrag_used = parseGermanNumber(document.getElementById("person-detail-freistellung").value);
  }
  await authedFetch(`/api/family-members/${personDetailCurrentId}`, {
    method: "PATCH", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  personDetailOverlay.style.display = "none";
  allFamilyMembers = [];
  loadFamilyMembersList();
});

document.getElementById("person-detail-show-documents-btn").addEventListener("click", async () => {
  const panel = document.getElementById("person-detail-documents");
  const isHidden = panel.style.display === "none";
  panel.style.display = isHidden ? "block" : "none";
  if (isHidden) await loadPersonDocumentsList();
});

async function loadPersonDocumentsList() {
  const listEl = document.getElementById("person-detail-documents-list");
  listEl.innerHTML = '<p class="muted">Lade …</p>';
  const docs = await (await authedFetch(`/api/family-members/${personDetailCurrentId}/documents`)).json();
  if (!docs.length) {
    listEl.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Dokumente hinterlegt.</p>';
    return;
  }
  listEl.innerHTML = `<ul>${docs.map((d) => `
    <li>
      <a href="/api/person-documents/${d.id}" rel="noopener" data-view-doc-url="/api/person-documents/${d.id}" data-view-doc-title="${escHtml(d.original_filename || "Dokument")}">📎 ${escHtml(d.original_filename || "Dokument")}</a>
      <span class="row-actions">
        <span class="muted" style="font-size:0.72rem">${(d.uploaded_at || "").slice(0, 10)}</span>
        <a href="/api/person-documents/${d.id}?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
        <button type="button" class="del-btn" data-delete-person-doc="${d.id}" title="Löschen">🗑</button>
      </span>
    </li>`).join("")}</ul>`;
  wireDocumentViewerLinks(listEl);
  listEl.querySelectorAll("[data-delete-person-doc]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Dieses Dokument wirklich löschen?")) return;
      await authedFetch(`/api/person-documents/${btn.dataset.deletePersonDoc}`, { method: "DELETE" });
      loadPersonDocumentsList();
    });
  });
}

document.getElementById("person-detail-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("person-detail-upload-input");
  if (!input.files.length) { alert("Bitte zuerst eine Datei auswählen."); return; }
  const formData = new FormData();
  formData.append("file", input.files[0]);
  await authedFetch(`/api/family-members/${personDetailCurrentId}/documents`, { method: "POST", body: formData });
  input.value = "";
  loadPersonDocumentsList();
});

// ═══════════════════════════════════════════════════════════════
// BANKANBINDUNG (FinTS) -- Verbindungen unter Integrationen, Konten und
// Umsätze unter Vermögen. Serverlogik: backend/bank_routes.py + bank_client.py.
// ═══════════════════════════════════════════════════════════════

// Empfängernamen und Verwendungszwecke sind FREMDER Text (jeder, der eine
// Überweisung schickt, bestimmt ihn) -- nie ungeprüft als HTML einfügen.
// Aktueller Monat in LOKALER Zeit -- toISOString() rechnet in UTC und wäre
// kurz nach Mitternacht am Monatsersten in Deutschland noch der Vormonat.
function localMonthKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function escHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtEur2(v) {
  return v == null ? "–" : v.toLocaleString("de-DE", { style: "currency", currency: "EUR" });
}
function maskIban(iban) {
  const s = String(iban || "").replace(/\s/g, "");
  return s.length > 8 ? `${s.slice(0, 4)} •••• ${s.slice(-4)}` : s;
}

let knownBanks = null;
async function ensureKnownBanks() {
  if (!knownBanks) knownBanks = await (await authedFetch("/api/banks/known")).json();
  return knownBanks;
}

async function renderBankConnections() {
  const listEl = document.getElementById("bank-connections-list");
  if (!listEl) return;
  const st = await (await authedFetch("/api/banks/settings")).json().catch(() => ({}));
  document.getElementById("fints-product-status").textContent = st.product_id_set
    ? `✅ Registrierungsnummer hinterlegt (${st.product_id_hint})`
    : "⚠️ Noch keine Registrierungsnummer — ohne sie lehnen die Banken den Zugriff ab.";
  document.getElementById("bank-install-lib-btn").style.display = st.library_installed === false ? "block" : "none";
  const conns = await (await authedFetch("/api/banks/connections")).json().catch(() => []);
  if (!conns.length) { listEl.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Bank verbunden.</p>'; return; }
  listEl.innerHTML = conns.map((c) => {
    let badge;
    if (c.login_blocked) badge = '<span style="color:var(--bad)">⏸ Pausiert (Anmeldung abgelehnt)</span>';
    else if (c.needs_manual) badge = '<span style="color:var(--warn)">🔐 Freigabe nötig — bitte synchronisieren</span>';
    else if (c.last_status === "ok") badge = `<span style="color:var(--good)">✅ ${escHtml(c.last_message)}</span>`;
    else if (c.last_status === "error") badge = `<span style="color:var(--bad)">⚠️ ${escHtml(c.last_message)}</span>`;
    else badge = '<span class="muted">○ Noch nicht synchronisiert</span>';
    const when = c.last_sync ? new Date(c.last_sync).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" }) : "";
    return `
      <div class="card" style="padding:10px;margin:6px 0">
        <div class="row-actions" style="justify-content:space-between;align-items:baseline">
          <strong>${escHtml(c.label)}</strong><span class="muted" style="font-size:0.72rem">${escHtml(c.user)}</span>
        </div>
        <div style="font-size:0.75rem;margin:4px 0">${badge}${when ? ` <span class="muted">· ${when}</span>` : ""}</div>
        <div class="row-actions">
          <button type="button" class="ghost-btn" data-bank-sync="${escHtml(c.key)}" style="flex:2">🔄 Synchronisieren</button>
          <button type="button" class="ghost-btn" data-bank-edit="${escHtml(c.key)}" style="flex:1">✏️</button>
          <button type="button" class="ghost-btn" data-bank-delete="${escHtml(c.key)}" style="flex:1">🗑</button>
        </div>
      </div>`;
  }).join("");
  listEl.querySelectorAll("[data-bank-sync]").forEach((b) => b.addEventListener("click", () => syncBank(b.dataset.bankSync, b)));
  listEl.querySelectorAll("[data-bank-edit]").forEach((b) => b.addEventListener("click", () => openBankForm(conns.find((c) => c.key === b.dataset.bankEdit))));
  listEl.querySelectorAll("[data-bank-delete]").forEach((b) => b.addEventListener("click", async () => {
    if (!confirm("Bankverbindung löschen? Abgerufene Konten und Umsätze werden entfernt, die PIN wird aus dem Schlüsselbund gelöscht.")) return;
    await authedFetch(`/api/banks/connections/${encodeURIComponent(b.dataset.bankDelete)}`, { method: "DELETE" });
    renderBankConnections();
  }));
}

async function openBankForm(conn) {
  const banks = await ensureKnownBanks();
  const $ = (id) => document.getElementById(id);
  $("bank-connection-form").style.display = "block";
  $("bank-form-key").value = conn ? conn.key : "";
  $("bank-form-bank").value = conn ? (conn.bank || "custom") : "bbbank";
  $("bank-form-label").value = conn?.label || "";
  $("bank-form-blz").value = conn?.blz || "";
  $("bank-form-server").value = conn?.server || "";
  $("bank-form-user").value = conn?.user || "";
  $("bank-form-pin").value = "";
  $("bank-form-pin").placeholder = conn?.has_pin ? "•••••••• (gespeichert, unverändert lassen zum Behalten)" : "PIN";
  const applyBank = () => {
    const b = banks[$("bank-form-bank").value];
    $("bank-form-custom").style.display = b ? "none" : "block";
    $("bank-form-user-label").textContent = b ? `Anmeldename (${b.user_hint})` : "Anmeldename";
    $("bank-form-hint").textContent = b ? b.tan_hint : "BLZ und FinTS-Adresse findest du auf der Website deiner Bank.";
  };
  $("bank-form-bank").onchange = applyBank;
  applyBank();
}

document.getElementById("bank-add-btn")?.addEventListener("click", () => openBankForm(null));
document.getElementById("bank-form-cancel-btn")?.addEventListener("click", () => {
  document.getElementById("bank-connection-form").style.display = "none";
});
document.getElementById("bank-form-save-btn")?.addEventListener("click", async () => {
  const $ = (id) => document.getElementById(id);
  const key = $("bank-form-key").value;
  const body = {
    bank: $("bank-form-bank").value, label: $("bank-form-label").value, blz: $("bank-form-blz").value,
    server: $("bank-form-server").value, user: $("bank-form-user").value.trim(), pin: $("bank-form-pin").value,
  };
  if (!body.user) return alert("Bitte den Anmeldenamen eingeben.");
  const r = await authedFetch(key ? `/api/banks/connections/${encodeURIComponent(key)}` : "/api/banks/connections", {
    method: key ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) return alert(data.detail || "Speichern fehlgeschlagen.");
  $("bank-form-pin").value = "";
  $("bank-connection-form").style.display = "none";
  renderBankConnections();
});
document.getElementById("fints-product-save-btn")?.addEventListener("click", async () => {
  const el = document.getElementById("fints-product-id");
  if (!el.value.trim()) return;
  await authedFetch("/api/banks/settings", { method: "PUT", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ product_id: el.value.trim() }) });
  el.value = "";
  renderBankConnections();
});

// ---------- Synchronisieren & Freigabe-Dialog ----------
let bankTanSession = null;
let bankTanTimer = null;
let bankTanStarted = 0;
const BANK_TAN_POLL_MS = 3000;
const BANK_TAN_MAX_MS = 6 * 60 * 1000;   // = Sitzungsdauer auf dem Server

async function syncBank(key, btn) {
  if (btn) { btn.disabled = true; btn.textContent = "Verbinde …"; }
  try {
    const r = await authedFetch(`/api/banks/connections/${encodeURIComponent(key)}/sync`, { method: "POST" });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) { alert(data.detail || "Abruf fehlgeschlagen."); return; }
    handleBankResult(data);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "🔄 Synchronisieren"; }
    renderBankConnections();
  }
}

function handleBankResult(data) {
  if (data.status === "ok") {
    closeBankTan(false);
    showToast(`Bank synchronisiert: ${data.accounts} Konto/Konten, ${data.new_transactions} neue Umsätze`);
    renderBankConnections();
    loadBankAccounts();
    loadBankInsights();
    return;
  }
  if (data.status === "tan_required" || data.status === "pending") openBankTan(data);
}

function openBankTan(data) {
  const $ = (id) => document.getElementById(id);
  const ch = data.challenge || {};
  const isNew = bankTanSession !== data.session;
  bankTanSession = data.session;
  if (isNew) bankTanStarted = Date.now();
  $("bank-tan-overlay").style.display = "flex";
  $("bank-tan-message").textContent = ch.message || (ch.decoupled ? "Bitte in deiner Banking-App bestätigen." : "Bitte TAN eingeben.");
  if (ch.image_base64) { $("bank-tan-image").src = `data:${ch.image_mime_type || "image/png"};base64,${ch.image_base64}`; $("bank-tan-image").style.display = "block"; }
  else $("bank-tan-image").style.display = "none";
  $("bank-tan-input-wrap").style.display = ch.decoupled ? "none" : "block";
  clearTimeout(bankTanTimer);
  if (ch.decoupled) {
    $("bank-tan-status").textContent = "⏳ Warte auf deine Bestätigung in der App …";
    bankTanTimer = setTimeout(pollBankTan, BANK_TAN_POLL_MS);
  } else {
    $("bank-tan-status").textContent = "";
    $("bank-tan-input").value = "";
    $("bank-tan-input").focus();
  }
}

async function pollBankTan(tan = "") {
  if (!bankTanSession) return;
  if (Date.now() - bankTanStarted > BANK_TAN_MAX_MS) {
    document.getElementById("bank-tan-status").textContent = "⌛ Zeit abgelaufen — bitte erneut synchronisieren.";
    await authedFetch(`/api/banks/sessions/${encodeURIComponent(bankTanSession)}/cancel`, { method: "POST" });
    bankTanSession = null;
    return;
  }
  const r = await authedFetch(`/api/banks/sessions/${encodeURIComponent(bankTanSession)}/poll`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tan }),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    document.getElementById("bank-tan-status").textContent = `❌ ${data.detail || "Freigabe fehlgeschlagen."}`;
    bankTanSession = null;
    renderBankConnections();
    return;
  }
  handleBankResult(data);
}

function closeBankTan(cancelOnServer) {
  clearTimeout(bankTanTimer);
  if (cancelOnServer && bankTanSession) {
    authedFetch(`/api/banks/sessions/${encodeURIComponent(bankTanSession)}/cancel`, { method: "POST" });
  }
  bankTanSession = null;
  document.getElementById("bank-tan-overlay").style.display = "none";
}
document.getElementById("bank-tan-cancel-btn")?.addEventListener("click", () => closeBankTan(true));
document.getElementById("bank-tan-submit-btn")?.addEventListener("click", () => {
  const tan = document.getElementById("bank-tan-input").value.trim();
  if (tan) pollBankTan(tan);
});

// ---------- Konten & Umsätze unter Vermögen ----------
let bankAccountsAll = [];
async function loadBankAccounts() {
  const card = document.getElementById("bank-accounts-card");
  bankAccountsAll = await (await authedFetch("/api/banks/accounts")).json().catch(() => []);
  if (!Array.isArray(bankAccountsAll)) bankAccountsAll = [];
  if (!card) return;
  // Zugeordnete Bankkonten stehen direkt bei ihrem Konto/Depot (⋯-Menü).
  // Hier bleiben nur Bankkonten übrig, die noch keinem Vermögenseintrag zugeordnet sind.
  const accounts = bankAccountsAll.filter((a) => !a.asset_id && !a.contract_id && !a.ignored);
  const ignoredAccounts = bankAccountsAll.filter((a) => a.ignored);
  renderIgnoredBankAccounts(card, ignoredAccounts);
  if (!accounts.length && !ignoredAccounts.length) { card.style.display = "none"; return; }
  document.getElementById("bank-accounts-open").style.display = accounts.length ? "" : "none";
  const usedAssetIds = new Set(bankAccountsAll.filter((b) => b.asset_id).map((b) => b.asset_id));
  const assets = (await (await authedFetch("/api/assets")).json().catch(() => []))
    .filter((a) => (a.type === "konto" || a.type === "depot") && !usedAssetIds.has(a.id));
  const loanTargets = accounts.length ? await (await authedFetch("/api/banks/loan-targets")).json().catch(() => []) : [];
  card.style.display = "block";
  document.getElementById("bank-accounts-list").innerHTML = accounts.map((a) => `
    <div style="padding:8px 0;border-bottom:1px solid var(--border, rgba(255,255,255,0.08))">
      <div class="row-actions" style="justify-content:space-between;align-items:baseline">
        <span><strong>${escHtml(a.label || "Konto")}</strong> <span class="muted" style="font-size:0.72rem">${escHtml(maskIban(a.iban || a.account_number))}</span></span>
        <strong>${fmtEur2(a.balance)}</strong>
      </div>
      <div class="row-actions" style="margin-top:4px;gap:6px">
        <select data-bank-link="${a.id}" style="flex:1;font-size:0.75rem">
          <option value="">— zuordnen oder neu anlegen —</option>
          <optgroup label="Neu anlegen">
            <option value="new:konto">＋ Als neues Konto anlegen</option>
            <option value="new:depot">＋ Als neues Depot anlegen</option>
          </optgroup>
          ${[["konto", "Bestehende Konten"], ["depot", "Bestehende Depots"]].map(([typ, title]) => {
            const opts = assets.filter((s) => s.type === typ);
            return opts.length ? `<optgroup label="${title} (Kontostand in der App)">${opts.map((s) => `<option value="${s.id}">${escHtml(s.label)} — ${fmtEur2(s.current_value)}</option>`).join("")}</optgroup>` : "";
          }).join("")}
          ${Array.isArray(loanTargets) && loanTargets.length ? `<optgroup label="Darlehen (Restschuld kommt künftig von der Bank)">${loanTargets.map((l) => `<option value="loan:${l.id}">${escHtml(l.label)} — Restschuld ${l.remaining_debt != null ? fmtEur2(l.remaining_debt) : "nicht hinterlegt"}</option>`).join("")}</optgroup>` : ""}
        </select>
        <button type="button" class="ghost-btn" data-bank-tx="${a.id}" data-bank-tx-label="${escHtml(a.label || "Konto")}" style="width:auto;font-size:0.75rem">📜 Umsätze (${a.tx_count})</button>
        <button type="button" class="ghost-btn" data-bank-ignore="${a.id}" data-bank-ignore-label="${escHtml(a.label || "Konto")}" data-bank-ignore-tx="${a.tx_count}" title="Gehört nicht uns (z. B. Vollmachtskonto): Saldo und Umsätze werden nicht mehr abgerufen" style="width:auto;font-size:0.75rem">🚫 Ignorieren</button>
      </div>
    </div>`).join("");
  card.querySelectorAll("[data-bank-ignore]").forEach((b) => b.addEventListener("click", async () => {
    const n = Number(b.dataset.bankIgnoreTx) || 0;
    if (!confirm(`„${b.dataset.bankIgnoreLabel}“ ignorieren?\n\nSaldo und Umsätze dieses Kontos werden künftig nicht mehr abgerufen oder angezeigt.` +
                 (n ? `\nDie bereits gespeicherten ${n} Umsätze werden entfernt.` : "") + "\nDu kannst das Konto jederzeit wiederherstellen.")) return;
    if (await setBankAccountIgnored(b.dataset.bankIgnore, true)) loadBankAccounts();
  }));
  card.querySelectorAll("[data-bank-link]").forEach((sel) => sel.addEventListener("change", async () => {
    if (!sel.value) return;
    if (sel.value.startsWith("loan:")) {
      if (!(await linkBankAccountContract(sel.dataset.bankLink, Number(sel.value.slice(5))))) { sel.value = ""; return; }
    } else if (sel.value.startsWith("new:")) {
      const res = await authedFetch(`/api/banks/accounts/${sel.dataset.bankLink}/create-asset`, { method: "POST",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: sel.value.slice(4) }) });
      if (!res.ok) { const err = await res.json().catch(() => ({})); showToast(err.detail || "Anlegen fehlgeschlagen"); sel.value = ""; return; }
      showToast(sel.value === "new:depot" ? "Depot angelegt" : "Konto angelegt");
    } else if (!(await linkBankAccount(sel.dataset.bankLink, Number(sel.value)))) { sel.value = ""; return; }
    loadVermoegenOverview();   // aus zwei Zeilen wird eine
  }));
  card.querySelectorAll("[data-bank-tx]").forEach((b) => b.addEventListener("click", () => openBankTransactions(b.dataset.bankTx, b.dataset.bankTxLabel)));
}

async function linkBankAccountContract(accountId, contractId) {
  const res = await authedFetch(`/api/banks/accounts/${accountId}/link-contract`, { method: "PUT",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contract_id: contractId }) });
  if (!res.ok) { const err = await res.json().catch(() => ({})); showToast(err.detail || "Verknüpfung fehlgeschlagen"); return false; }
  showToast(contractId ? "Darlehen verknüpft — Restschuld übernommen" : "Verknüpfung gelöst");
  return true;
}

function renderIgnoredBankAccounts(card, ignoredAccounts) {
  const box = document.getElementById("bank-accounts-ignored");
  if (!box) return;
  if (!ignoredAccounts.length) { box.style.display = "none"; return; }
  box.style.display = "block";
  document.getElementById("bank-accounts-ignored-count").textContent = ignoredAccounts.length;
  document.getElementById("bank-accounts-ignored-list").innerHTML = ignoredAccounts.map((a) => `
    <div class="row-actions" style="justify-content:space-between;align-items:center;padding:6px 0">
      <span><strong>${escHtml(a.label || "Konto")}</strong> <span class="muted" style="font-size:0.72rem">${escHtml(maskIban(a.iban || a.account_number))}</span></span>
      <button type="button" class="ghost-btn" data-bank-restore="${a.id}" style="width:auto;font-size:0.75rem">↩ Wiederherstellen</button>
    </div>`).join("");
  box.querySelectorAll("[data-bank-restore]").forEach((b) => b.addEventListener("click", async () => {
    if (await setBankAccountIgnored(b.dataset.bankRestore, false)) loadBankAccounts();
  }));
}

async function setBankAccountIgnored(accountId, ignored) {
  const res = await authedFetch(`/api/banks/accounts/${accountId}/ignore`, { method: "PUT",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ignored }) });
  if (!res.ok) { const err = await res.json().catch(() => ({})); showToast(err.detail || "Aktion fehlgeschlagen"); return false; }
  showToast(ignored ? "Konto wird ignoriert" : "Konto wiederhergestellt — Umsätze kommen beim nächsten Abruf");
  return true;
}

async function linkBankAccount(accountId, assetId) {
  const res = await authedFetch(`/api/banks/accounts/${accountId}/link`, { method: "PUT",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify({ asset_id: assetId }) });
  if (!res.ok) { const err = await res.json().catch(() => ({})); showToast(err.detail || "Verknüpfung fehlgeschlagen"); return false; }
  showToast(assetId ? "Verknüpfung gespeichert" : "Verknüpfung gelöst");
  return true;
}

// Auswahl-Dialog (Bankkonto zuordnen / Umsätze eines von mehreren Bankkonten)
function openBankPicker(title, rows, onPick) {
  const ov = document.getElementById("bank-picker-overlay");
  document.getElementById("bank-picker-title").textContent = title;
  const list = document.getElementById("bank-picker-list");
  list.innerHTML = rows.length ? rows.map((r, i) => `
    <button type="button" class="ghost-btn" data-pick="${i}" style="width:100%;text-align:left;margin-bottom:6px">
      <strong>${escHtml(r.title)}</strong><br><span class="muted" style="font-size:0.72rem;white-space:normal;overflow-wrap:anywhere">${escHtml(r.sub || "")}</span>
    </button>`).join("") : '<p class="muted">Keine freien Bankkonten vorhanden. Erst unter Einstellungen → Integrationen eine Bank verbinden und synchronisieren.</p>';
  list.querySelectorAll("[data-pick]").forEach((b) => b.addEventListener("click", () => {
    ov.style.display = "none";
    onPick(rows[Number(b.dataset.pick)]);
  }));
  ov.style.display = "flex";
}
document.getElementById("bank-picker-close-btn")?.addEventListener("click", () => {
  document.getElementById("bank-picker-overlay").style.display = "none";
});

function bankAccountsOfAsset(assetId) {
  return bankAccountsAll.filter((b) => String(b.asset_id) === String(assetId));
}
function bankAccountTitle(b) { return b.label || "Konto"; }

let bankTxAccountId = null;
let bankTxSearchTimer = null;
async function openBankTransactions(accountId, label) {
  bankTxAccountId = accountId;
  document.getElementById("bank-tx-title").textContent = `Umsätze — ${label}`;
  document.getElementById("bank-tx-search").value = "";
  document.getElementById("bank-tx-overlay").style.display = "flex";
  renderBankTransactions("");
}
async function renderBankTransactions(q) {
  const el = document.getElementById("bank-tx-content");
  const url = `/api/banks/accounts/${bankTxAccountId}/transactions${q ? `?q=${encodeURIComponent(q)}` : ""}`;
  const txs = await (await authedFetch(url)).json().catch(() => []);
  if (!txs.length) { el.innerHTML = '<p class="muted">Keine Umsätze gefunden.</p>'; return; }
  el.innerHTML = txs.map((t) => `
    <div class="tx-row">
      <div class="tx-date">${escHtml(t.booking_date || "")}</div>
      <div class="tx-amount" style="color:${(t.amount || 0) < 0 ? "var(--bad)" : "var(--good)"}">${fmtEur2(t.amount)}</div>
      <div class="tx-main"><div class="tx-payee">${escHtml(t.counterparty_name || (t.counterparty_iban ? "Empfänger ohne Namen" : "—"))}</div>${t.counterparty_iban ? `<div class="muted tx-iban">IBAN ${escHtml(maskIban(t.counterparty_iban))}</div>` : ""}<div class="muted tx-purpose">${escHtml(t.purpose || "")}</div>
        <button type="button" class="ghost-btn tx-assign" data-tx-assign="${t.id}">${
          t.contract_label ? `🔗 ${escHtml(t.contract_label)}` : t.income_label ? `🔗 ${escHtml(t.income_label)}` : "＋ zuordnen"}${t.match_source === "rule" ? " · automatisch" : ""}</button></div>
    </div>`).join("");
  bankTxCache = Object.fromEntries(txs.map((t) => [String(t.id), t]));
  el.querySelectorAll("[data-tx-assign]").forEach((b) => b.addEventListener("click", () => openAssignDialog(bankTxCache[b.dataset.txAssign])));
}
let bankTxCache = {};
document.getElementById("bank-tx-search")?.addEventListener("input", (e) => {
  clearTimeout(bankTxSearchTimer);
  bankTxSearchTimer = setTimeout(() => renderBankTransactions(e.target.value.trim()), 250);
});
document.getElementById("bank-tx-close-btn")?.addEventListener("click", () => {
  document.getElementById("bank-tx-overlay").style.display = "none";
});

document.getElementById("bank-install-lib-btn")?.addEventListener("click", async (e) => {
  const btn = e.target;
  btn.disabled = true; btn.textContent = "Installiere …";
  const r = await authedFetch("/api/banks/install-library", { method: "POST" });
  const data = await r.json().catch(() => ({}));
  btn.disabled = false; btn.textContent = "🔧 Bank-Bibliothek jetzt installieren";
  alert(r.ok ? "✅ Bank-Bibliothek installiert. Kein Neustart nötig." : "Installation fehlgeschlagen:\n\n" + (data.detail || ""));
  renderBankConnections();
});


// ═══════════════════════════════════════════════════════════════
// UMSATZ-ZUORDNUNG (Vertrag / Einnahme) und daraus erkannte Hinweise.
// Serverlogik: backend/bank_matching.py. Werte im Auswahlfeld sind
// "contract:ID" bzw. "income:ID" -- Vertrag und Einnahme können dieselbe ID
// haben (verschiedene Tabellen), nur Art + ID zusammen ist eindeutig.
// ═══════════════════════════════════════════════════════════════
let assignTx = null;

async function openAssignDialog(tx) {
  if (!tx) return;
  assignTx = tx;
  const $ = (id) => document.getElementById(id);
  $("bank-assign-tx").innerHTML = `<strong>${escHtml(tx.counterparty_name || "—")}</strong> · ${fmtEur2(tx.amount)} · ${escHtml(tx.booking_date || "")}`
    + (tx.counterparty_iban ? `<div class="muted" style="font-size:0.72rem">IBAN ${escHtml(maskIban(tx.counterparty_iban))}</div>` : "")
    + (tx.purpose ? `<div class="muted" style="font-size:0.72rem;overflow-wrap:anywhere">${escHtml(tx.purpose)}</div>` : "");
  const [contracts, income, sugs] = await Promise.all([
    authedFetch("/api/contracts").then((r) => r.json()).catch(() => []),
    authedFetch("/api/income").then((r) => r.json()).catch(() => []),
    authedFetch(`/api/banks/transactions/${tx.id}/suggestions`).then((r) => r.json()).catch(() => []),
  ]);
  const activeContracts = (Array.isArray(contracts) ? contracts : []).filter((c) => (c.status || "active") === "active");
  const incomeList = Array.isArray(income) ? income : [];
  const current = tx.contract_id ? `contract:${tx.contract_id}` : tx.income_id ? `income:${tx.income_id}` : "";
  const sel = $("bank-assign-target");
  sel.innerHTML = '<option value="">— bitte wählen —</option>'
    + `<optgroup label="Ausgaben">${activeContracts.map((c) => `<option value="contract:${c.id}">${escHtml(c.label)} (${fmtEur2(c.amount)})</option>`).join("")}</optgroup>`
    + `<optgroup label="Einnahmen">${incomeList.map((i) => `<option value="income:${i.id}">${escHtml(i.label)} (${fmtEur2(i.amount)})</option>`).join("")}</optgroup>`;
  sel.value = current || (sugs[0] ? `${sugs[0].kind}:${sugs[0].id}` : "");
  $("bank-assign-suggestions").innerHTML = sugs.length && !current
    ? `<p class="muted" style="font-size:0.75rem;margin:0 0 4px">Vorschläge:</p>${sugs.map((g) =>
        `<button type="button" class="ghost-btn" data-sug="${g.kind}:${g.id}" style="width:auto;margin:0 6px 6px 0;font-size:0.75rem">${escHtml(g.label)} · ${fmtEur2(g.amount)}</button>`).join("")}`
    : "";
  $("bank-assign-suggestions").querySelectorAll("[data-sug]").forEach((b) => b.addEventListener("click", () => { sel.value = b.dataset.sug; }));
  $("bank-assign-learn").checked = true;
  $("bank-assign-forget").checked = false;
  $("bank-assign-remove-wrap").style.display = current ? "block" : "none";
  $("bank-assign-overlay").style.display = "flex";
}

async function afterAssignmentChange() {
  document.getElementById("bank-assign-overlay").style.display = "none";
  if (bankTxAccountId) renderBankTransactions(document.getElementById("bank-tx-search").value.trim());
  loadBankInsights();
}

document.getElementById("bank-assign-save-btn")?.addEventListener("click", async () => {
  const val = document.getElementById("bank-assign-target").value;
  if (!val || !assignTx) return alert("Bitte einen Vertrag oder eine Einnahme wählen.");
  const [kind, id] = val.split(":");
  const r = await authedFetch(`/api/banks/transactions/${assignTx.id}/assign`, {
    method: "PUT", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ kind, target_id: Number(id), learn: document.getElementById("bank-assign-learn").checked }),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) return alert(data.detail || "Zuordnung fehlgeschlagen.");
  showToast(data.also_assigned ? `Zugeordnet — ${data.also_assigned} weitere gleiche Umsätze automatisch mit zugeordnet` : "Zugeordnet");
  afterAssignmentChange();
});
document.getElementById("bank-assign-remove-btn")?.addEventListener("click", async () => {
  if (!assignTx) return;
  const forget = document.getElementById("bank-assign-forget").checked;
  await authedFetch(`/api/banks/transactions/${assignTx.id}/assign?forget_rule=${forget ? 1 : 0}`, { method: "DELETE" });
  showToast("Zuordnung entfernt");
  afterAssignmentChange();
});
document.getElementById("bank-assign-cancel-btn")?.addEventListener("click", () => {
  document.getElementById("bank-assign-overlay").style.display = "none";
});

// ---------- Zahlungen in den Detail-Dialogen (Muster wie "Belege anzeigen") ----------
async function renderPaymentsSection(section, url) {
  section.style.display = "block";
  section.innerHTML = '<p class="muted">Lade …</p>';
  const rows = await (await authedFetch(url)).json().catch(() => []);
  if (!rows.length) {
    section.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine zugeordneten Bankumsätze. Zuordnen kannst du unter Vermögen → Bankkonten → Umsätze.</p>';
    return;
  }
  section.innerHTML = `<div class="doc-list-scroll"><table class="meter-table"><tbody>${rows.map((t) => `
    <tr>
      <td style="white-space:nowrap">${escHtml(t.booking_date || "")}</td>
      <td><div>${escHtml(t.counterparty_name || "—")}</div><div class="muted" style="font-size:0.7rem">${escHtml(t.account_label || "")}${t.match_source === "rule" ? " · automatisch zugeordnet" : ""}</div></td>
      <td class="r" style="white-space:nowrap">${fmtEur2(t.amount)}</td>
    </tr>`).join("")}</tbody></table></div>`;
}
document.getElementById("details-show-payments-btn")?.addEventListener("click", () => {
  const section = document.getElementById("details-payments-section");
  if (section.style.display !== "none") { section.style.display = "none"; return; }
  renderPaymentsSection(section, `/api/contracts/${document.getElementById("details-form").dataset.contractId}/payments`);
});
document.getElementById("income-show-payments-btn")?.addEventListener("click", () => {
  const section = document.getElementById("income-payments-section");
  if (section.style.display !== "none") { section.style.display = "none"; return; }
  if (!section.dataset.incomeId) return;
  renderPaymentsSection(section, `/api/income/${section.dataset.incomeId}/payments`);
});

// ---------- Hinweise: Preisänderung, ausbleibende Zahlung, neue Abbuchung ----------
async function loadBankInsights() {
  const card = document.getElementById("bank-insights-card");
  if (!card) return;
  const ins = await (await authedFetch("/api/banks/insights")).json().catch(() => null);
  if (!ins) { card.style.display = "none"; return; }
  const kindLabel = (k) => (k === "income" ? "Einnahme" : "Vertrag");
  const deDate = (iso) => { const m = String(iso || "").match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? `${m[3]}.${m[2]}.${m[1]}` : escHtml(iso || ""); };
  const rhythm = (d) => (d == null ? "" : d <= 9 ? "wöchentlich" : d >= 26 && d <= 35 ? "monatlich" : d >= 85 && d <= 100 ? "vierteljährlich" : d >= 350 && d <= 380 ? "jährlich" : `etwa alle ${d} Tage`);
  const bookingsHtml = (list) => !list || !list.length ? "" : `
    <details class="hint-details"><summary>Alle Buchungen (${list.length})</summary>
      ${list.map((x) => `<div class="hint-booking">
        <div class="hint-booking-top"><span>${deDate(x.date)}</span><strong>${fmtEur2(x.amount)}</strong></div>
        ${x.purpose ? `<div class="muted hint-booking-purpose">${escHtml(x.purpose)}</div>` : ""}
      </div>`).join("")}
    </details>`;
  const metaHtml = (o, extra) => {
    const bits = [];
    if (o.last_date) bits.push(`Letzte Buchung ${deDate(o.last_date)}`);
    if (extra) bits.push(extra);
    const r = rhythm(o.interval_days); if (r) bits.push(r);
    if (o.account_label) bits.push(`Konto ${escHtml(o.account_label)}`);
    return `<div class="muted hint-meta">${bits.join(" · ")}</div>`
      + (o.counterparty_name && o.label && o.counterparty_name !== o.label ? `<div class="muted hint-meta">Empfänger: ${escHtml(o.counterparty_name)}</div>` : "")
      + (o.iban ? `<div class="muted hint-meta">IBAN ${escHtml(maskIban(o.iban))}</div>` : "")
      + (o.purpose ? `<div class="muted hint-purpose">Verwendungszweck: ${escHtml(o.purpose)}</div>` : "");
  };
  const dismissBtn = (key, kind, title) => `<button type="button" class="ghost-btn hint-btn" data-dismiss-key="${escHtml(key)}" data-dismiss-kind="${kind}" data-dismiss-title="${escHtml(title)}">Ablehnen</button>`;
  const parts = [];
  ins.price_changes.forEach((p) => parts.push(`
    <div class="hint">
      <div class="hint-head">💶 <strong>${escHtml(p.label)}</strong> <span class="tag">${kindLabel(p.kind)}</span></div>
      <div class="hint-main">Betrag ${fmtEur2(p.expected)} → <strong>${fmtEur2(p.actual)}</strong> <span class="muted">· zweimal in Folge abgebucht</span></div>
      ${metaHtml(p)}${bookingsHtml(p.bookings)}
      <div class="hint-actions">
        <button type="button" class="ghost-btn hint-btn" data-apply-kind="${p.kind}" data-apply-id="${p.id}" data-apply-amount="${p.actual}">Neuen Betrag übernehmen</button>
        ${dismissBtn(p.hint_key, "price", p.label)}
      </div>
    </div>`));
  ins.missing.forEach((m) => parts.push(`
    <div class="hint">
      <div class="hint-head">⏳ <strong>${escHtml(m.label)}</strong> <span class="tag">${kindLabel(m.kind)}</span></div>
      <div class="hint-main">Letzte Zahlung vor ${m.days_since} Tagen <span class="muted">· erwartet ${fmtEur2(m.expected)}</span></div>
      ${metaHtml(m)}${bookingsHtml(m.bookings)}
      <div class="hint-actions">${dismissBtn(m.hint_key, "missing", m.label)}</div>
    </div>`));
  ins.recurring_unmapped.forEach((r) => {
    const name = r.counterparty_name || "Unbekannter Empfänger";
    const range = r.amount_min !== r.amount_max ? `${fmtEur2(r.amount_min)}–${fmtEur2(r.amount_max)}` : fmtEur2(r.amount);
    parts.push(`
    <div class="hint">
      <div class="hint-head">🆕 <strong>${escHtml(name)}</strong></div>
      <div class="hint-main">${range} <span class="muted">· ${r.count}× in ${r.months} Monaten, noch keiner Ausgabe zugeordnet</span></div>
      ${metaHtml({ ...r, label: name }, `Erste Buchung ${deDate(r.first_date)}`)}${bookingsHtml(r.bookings)}
      <div class="hint-actions">
        <button type="button" class="ghost-btn hint-btn" data-new-expense="${r.transaction_id}">Als Ausgabe anlegen</button>
        <button type="button" class="ghost-btn hint-btn" data-assign-tx="${r.transaction_id}">Zuordnen</button>
        ${dismissBtn(r.hint_key, "recurring", name)}
      </div>
    </div>`);
  });
  // Einmalige Abweichungen (ins.deviations) werden bewusst nicht angezeigt -- erst ein wiederholter neuer Betrag wird zum Hinweis.
  const dismissedHtml = (ins.dismissed || []).length ? `
    <details class="hint-dismissed"><summary>Abgelehnte Hinweise (${ins.dismissed.length})</summary>
      ${ins.dismissed.map((d) => `<div class="hint-dismissed-row"><span>${escHtml(d.title || d.hint_key)}</span>
        <button type="button" class="ghost-btn hint-btn" data-restore-key="${escHtml(d.hint_key)}">Wiederherstellen</button></div>`).join("")}
    </details>` : "";
  if (!parts.length && !dismissedHtml) { card.style.display = "none"; return; }
  card.style.display = "block";
  const list = document.getElementById("bank-insights-list");
  list.innerHTML = parts.join("") + dismissedHtml;
  const recurringById = Object.fromEntries(ins.recurring_unmapped.map((r) => [String(r.transaction_id), r]));
  list.querySelectorAll("[data-apply-id]").forEach((b) => b.addEventListener("click", async () => {
    if (!confirm(`Neuen Betrag ${fmtEur2(Number(b.dataset.applyAmount))} übernehmen?`)) return;
    await authedFetch("/api/banks/insights/apply-amount", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: b.dataset.applyKind, target_id: Number(b.dataset.applyId), amount: Number(b.dataset.applyAmount) }) });
    showToast("Betrag übernommen");
    loadBankInsights(); loadContracts(); loadIncome(); loadDashboard();
  }));
  list.querySelectorAll("[data-dismiss-key]").forEach((b) => b.addEventListener("click", async () => {
    const res = await authedFetch("/api/banks/insights/dismiss", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ hint_key: b.dataset.dismissKey, kind: b.dataset.dismissKind, title: b.dataset.dismissTitle }) });
    if (!res.ok) { showToast("Ablehnen fehlgeschlagen"); return; }
    showToast("Hinweis abgelehnt");
    loadBankInsights();
  }));
  list.querySelectorAll("[data-restore-key]").forEach((b) => b.addEventListener("click", async () => {
    await authedFetch("/api/banks/insights/restore", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ hint_key: b.dataset.restoreKey }) });
    showToast("Hinweis wiederhergestellt");
    loadBankInsights();
  }));
  list.querySelectorAll("[data-assign-tx]").forEach((b) => b.addEventListener("click", () => {
    const r = recurringById[b.dataset.assignTx];
    openAssignDialog({ id: Number(b.dataset.assignTx), counterparty_name: r.counterparty_name, counterparty_iban: r.iban,
      purpose: r.purpose, amount: -r.amount, booking_date: r.last_date || "" });
  }));
  list.querySelectorAll("[data-new-expense]").forEach((b) => b.addEventListener("click", () => {
    const r = recurringById[b.dataset.newExpense];
    document.getElementById("add-expense-btn").click();   // nutzt die bestehende Formular-Logik inkl. Zurücksetzen
    setTimeout(() => {
      document.getElementById("expense-provider").value = r.counterparty_name || "";
      document.getElementById("expense-amount").value = String(r.amount).replace(".", ",");
      document.getElementById("expense-frequency").value = "monthly";
    }, 50);
  }));
}


// ═══════════════════════════════════════════════════════════════
// FRONIUS (lokale Solar API) -- Serverlogik: fronius_client.py / fronius_routes.py
// ═══════════════════════════════════════════════════════════════
async function initFroniusSettings() {
  if (document.getElementById("fronius-save-btn")?.dataset.wired) { froniusRefresh(); return; }
  document.getElementById("fronius-save-btn").dataset.wired = "1";
  const $ = (id) => document.getElementById(id);
  const status = $("fronius-status");
  const kwhOrDash = (wh) => (wh == null ? "–" : fmtUnit(wh / 1000, "kWh"));

  $("fronius-save-btn").addEventListener("click", async () => {
    const r = await authedFetch("/api/fronius/settings", { method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ host: $("fronius-host").value.trim(), meter_id: $("fronius-meter-id").value.trim() }) });
    const d = await r.json().catch(() => ({}));
    status.innerHTML = r.ok ? '<p class="muted">Gespeichert. Jetzt „Verbindung testen".</p>' : `<p style="color:var(--bad)">❌ ${escHtml(d.detail || "Speichern fehlgeschlagen.")}</p>`;
    if (r.ok) $("fronius-host").value = d.host;
    froniusRefresh(); renderIntegrationsCardList();
  });
  $("fronius-test-btn").addEventListener("click", async () => {
    status.innerHTML = '<p class="muted">Frage den Wechselrichter ab …</p>';
    const r = await authedFetch("/api/fronius/test", { method: "POST" });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { status.innerHTML = `<p style="color:var(--bad)">❌ ${escHtml(d.detail || "Nicht erreichbar.")}</p>`; return; }
    status.innerHTML = `<p style="color:var(--good)">✅ Verbunden — Gesamtzähler: ${kwhOrDash(d.pv_total)} erzeugt${d.has_meter
      ? ` · Smart Meter: ${kwhOrDash(d.import_total)} Bezug, ${kwhOrDash(d.export_total)} Einspeisung`
      : " · <strong>kein Smart Meter gefunden</strong> (nur Erzeugung verfügbar)"}</p>
      <p class="muted" style="font-size:0.72rem;margin:2px 0 0">Tageswerte entstehen aus den Zählerständen — der erste vollständige Tag ist morgen.</p>`;
  });
  $("fronius-sync-btn").addEventListener("click", async () => {
    status.innerHTML = '<p class="muted">Synchronisiere …</p>';
    const r = await authedFetch("/api/fronius/sync", { method: "POST" });
    const d = await r.json().catch(() => ({}));
    status.innerHTML = r.ok ? `<p style="color:var(--good)">✅ Heute bisher: ${fmtUnit(d.today?.pv || 0, "kWh")} PV${
      d.today?.verbrauch != null ? ` · ${fmtUnit(d.today.einsp, "kWh")} Einspeisung · ${fmtUnit(d.today.bezug, "kWh")} Bezug · ${fmtUnit(d.today.verbrauch, "kWh")} Hausverbrauch` : " (ohne Smart Meter nur Erzeugung)"}</p>`
      : `<p style="color:var(--bad)">❌ ${escHtml(d.detail || "Fehlgeschlagen.")}</p>`;
    froniusRefresh();
  });
  $("fronius-delete-btn").addEventListener("click", async () => {
    if (!confirm("Fronius-Verbindung entfernen? Bereits übernommene Tageswerte bleiben erhalten.")) return;
    await authedFetch("/api/fronius/settings", { method: "DELETE" });
    $("fronius-host").value = ""; $("fronius-meter-id").value = ""; status.innerHTML = "";
    froniusRefresh(); renderIntegrationsCardList();
  });
  froniusRefresh();
}

async function froniusRefresh() {
  const $ = (id) => document.getElementById(id);
  const s = await (await authedFetch("/api/fronius/settings")).json().catch(() => ({}));
  if (s.host && !$("fronius-host").value) $("fronius-host").value = s.host;
  if (s.meter_id && !$("fronius-meter-id").value) $("fronius-meter-id").value = s.meter_id;
  const info = await (await authedFetch("/api/fronius/last-sync")).json().catch(() => ({}));
  const el = $("fronius-last-sync");
  if (s.conflict_with_sungrow) {
    el.innerHTML = '<span style="color:var(--bad)">⚠️ Sungrow ist ebenfalls eingerichtet — beide Abrufe pausieren, bis eine der beiden PV-Quellen entfernt ist.</span>';
  } else if (info.timestamp) {
    const t = new Date(info.timestamp).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" });
    el.textContent = `${info.status === "error" ? "⚠️" : "✅"} Zuletzt synchronisiert: ${t} — ${info.message || ""}`;
  } else el.textContent = "";
}

// ---------- Komfort & Robustheit (Review-Runde v301) ----------

// Kontextmenüs immer vollständig im sichtbaren Bereich halten (iPhone: Menü am unteren
// Rand wurde sonst abgeschnitten). Greift zentral für alle .context-menu-Elemente.
(function setupContextMenuClamp() {
  const place = (m) => {
    if (m.style.display !== "block") return;
    const r = m.getBoundingClientRect();
    const pad = 8;
    let left = parseFloat(m.style.left) || 0, top = parseFloat(m.style.top) || 0, changed = false;
    if (r.right > window.innerWidth - pad) { left -= r.right - (window.innerWidth - pad); changed = true; }
    if (r.left < pad) { left += pad - r.left; changed = true; }
    if (r.bottom > window.innerHeight - pad) {
      // erst nach oben klappen, wenn dort Platz ist, sonst bündig an den unteren Rand
      const flipped = top - r.height - 36;
      top = flipped >= window.scrollY + pad ? flipped : top - (r.bottom - (window.innerHeight - pad));
      changed = true;
    }
    if (changed) { m.style.left = `${Math.max(left, window.scrollX + pad)}px`; m.style.top = `${Math.max(top, window.scrollY + pad)}px`; }
  };
  document.querySelectorAll(".context-menu").forEach((m) => {
    new MutationObserver(() => place(m)).observe(m, { attributes: true, attributeFilter: ["style"] });
  });
})();

// Esc schließt zuerst offene Kontextmenüs, dann den obersten Dialog. Ausgenommen sind die
// Anmeldung und die laufende Bank-Freigabe (TAN) -- die sollen nie versehentlich abbrechen.
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape" || e.isComposing) return;
  const menus = [...document.querySelectorAll(".context-menu")].filter((m) => m.style.display === "block");
  if (menus.length) { menus.forEach((m) => { m.style.display = "none"; }); return; }
  const open = [...document.querySelectorAll(".overlay")]
    .filter((o) => getComputedStyle(o).display !== "none" && !["auth-overlay", "bank-tan-overlay"].includes(o.id));
  if (!open.length) return;
  const top = open.sort((a, b) => (parseInt(getComputedStyle(a).zIndex) || 0) - (parseInt(getComputedStyle(b).zIndex) || 0)).pop();
  const closer = top.querySelector('[id$="close-btn"], [id$="cancel-btn"], [data-close]')
    || [...top.querySelectorAll("button")].find((b) => /^(schließen|abbrechen|abbruch)$/i.test(b.textContent.trim().replace(/^\W+/, "")));
  if (closer) closer.click(); else top.style.display = "none";
});

// Enter im Chat-Eingabefeld sendet die Frage (wie der Knopf "Fragen").
document.getElementById("chat-input")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); document.getElementById("chat-btn")?.click(); }
});

// Ersetzt ein früheres onclick-Attribut im HTML (Content-Security-Policy
// erlaubt keine Inline-Handler).
document.getElementById("sungrow-pointer-open-integrations")?.addEventListener("click", (e) => {
  e.preventDefault();
  document.getElementById("open-integrations-btn")?.click();
});
