// Direkt nach dem Header-Icon geladen (nicht erst in app.js), damit auch die
// Icons ohne sichtbares Umspringen sofort im richtigen Theme erscheinen.
// Eigene Datei statt Inline-<script> wegen der Content-Security-Policy.
(function () {
  var t = window.__cachedUiTheme || "dark";
  var icon = document.getElementById("app-header-icon");
  if (icon) icon.src = "/icons/icon-" + t + ".svg";
  var touchIcon = document.getElementById("apple-touch-icon-link");
  if (touchIcon) touchIcon.href = "/icons/icon-" + t + "-180.png";
  var favicon = document.getElementById("favicon-link");
  if (favicon) favicon.href = "/icons/icon-" + t + ".svg";
})();
