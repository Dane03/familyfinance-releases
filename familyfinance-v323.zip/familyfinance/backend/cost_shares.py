"""Kostenbeteiligungen: eine Einnahme deckt einen Anteil bestimmter Verträge.

Beispiel: Ein Familienmitglied außerhalb des Haushalts zahlt die Hälfte von
Gas, Wasser und Strom (nicht Grundsteuer/Müll). Die Einnahme ist dann mit
diesen Verträgen und dem Anteil 0,5 verknüpft; der Check vergleicht den
monatlichen Eingang mit der Summe der Anteile und meldet jede Abweichung
(nach oben wie nach unten) -- z.B. nach einer Abschlags-Erhöhung.

Verträge werden mit ihrem vollen Betrag (Rechnungs-/Abschlagsbetrag)
gerechnet, unabhängig vom eigenen Anteil `split_share`.
"""
import re
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import auth
from database import get_connection

router = APIRouter()

TOLERANCE_EUR = 1.0   # Rundungsdifferenzen unter 1 €/Monat sind kein Hinweis wert
_PER_MONTH = {"monthly": 1.0, "quarterly": 1 / 3, "yearly": 1 / 12}


def _monthly(amount, frequency) -> float:
    return abs(amount or 0) * _PER_MONTH.get(frequency or "monthly", 1.0)


def _contract_names(conn) -> dict:
    try:
        import bank_matching
        return bank_matching.contract_labels(conn)
    except Exception:
        return {}


def shares_for_income(conn, income_id: int) -> list:
    names = _contract_names(conn)
    rows = conn.execute(
        "SELECT s.contract_id, s.share, co.label, co.provider, co.amount, co.frequency, co.status "
        "FROM income_cost_shares s JOIN contracts co ON co.id = s.contract_id "
        "WHERE s.income_id=? ORDER BY co.label", (income_id,)).fetchall()
    out = []
    for r in rows:
        monthly = _monthly(r["amount"], r["frequency"])
        active = (r["status"] or "active") == "active"
        out.append({
            "contract_id": r["contract_id"],
            "label": (names.get(r["contract_id"]) or r["label"] or r["provider"] or "Vertrag").strip(),
            "share": r["share"],
            "contract_monthly": round(monthly, 2),
            "part_monthly": round(monthly * r["share"], 2) if active else 0.0,
            "active": active,
        })
    return out


def check_all(conn) -> list:
    """Ein Eintrag je Einnahme mit Kostenbeteiligung."""
    incomes = conn.execute(
        "SELECT DISTINCT i.id, i.label, i.amount, i.frequency, COALESCE(i.active,1) AS active "
        "FROM income i JOIN income_cost_shares s ON s.income_id = i.id").fetchall()
    result = []
    for inc in incomes:
        if not inc["active"]:
            continue
        items = shares_for_income(conn, inc["id"])
        expected = round(sum(x["part_monthly"] for x in items), 2)
        actual = round(_monthly(inc["amount"], inc["frequency"]), 2)
        diff = round(actual - expected, 2)
        factor = _PER_MONTH.get(inc["frequency"] or "monthly", 1.0)
        result.append({
            "income_id": inc["id"], "income_label": inc["label"], "frequency": inc["frequency"],
            "actual_monthly": actual, "expected_monthly": expected, "diff_monthly": diff,
            "ok": abs(diff) <= TOLERANCE_EUR,
            "suggested_amount": round(expected / factor, 2) if factor else expected,
            "archived_contracts": [x["label"] for x in items if not x["active"]],
            "items": items,
        })
        r = result[-1]
        r["hint_key"] = (f"costshare:{inc['id']}:{actual:.2f}:{expected:.2f}:{len(r['archived_contracts'])}")
    return result


# ---------- Einmalige Einrichtung für die bestehende Nebenkosten-Beteiligung ----------

_UTILITY = re.compile(r"\b(gas|strom|wasser|abwasser)", re.IGNORECASE)
_NOT_UTILITY = re.compile(r"grundsteuer|abfall|m[üu]ll|einspeis|finanzierung|versicherung|geb[äa]ude", re.IGNORECASE)


def setup_house_share_once(conn):
    """Verknüpft die Einnahme "Anteil Haus …" einmalig mit den aktiven Verträgen
    für Gas, Wasser und Strom (je 1/2). Läuft erneut, solange es die Einnahme
    noch nicht gibt; danach nie wieder (auch nicht, wenn die Verknüpfungen
    später bewusst geändert oder entfernt werden)."""
    if conn.execute("SELECT 1 FROM settings WHERE key='migration_house_cost_share'").fetchone():
        return
    incomes = conn.execute("SELECT id FROM income WHERE lower(label) LIKE 'anteil haus%'").fetchall()
    if len(incomes) != 1:
        return
    income_id = incomes[0]["id"]
    if not conn.execute("SELECT 1 FROM income_cost_shares WHERE income_id=?", (income_id,)).fetchone():
        names = _contract_names(conn)
        for c in conn.execute("SELECT id, label, provider, subcategory FROM contracts "
                              "WHERE COALESCE(status,'active')='active'").fetchall():
            text = " ".join(filter(None, [names.get(c["id"]), c["label"], c["provider"], c["subcategory"]]))
            if _UTILITY.search(text) and not _NOT_UTILITY.search(text):
                conn.execute("INSERT OR IGNORE INTO income_cost_shares (income_id, contract_id, share) "
                             "VALUES (?,?,0.5)", (income_id, c["id"]))
    conn.execute("INSERT INTO settings (key, value) VALUES ('migration_house_cost_share', 'true')")
    conn.commit()


_INTERNET = re.compile(r"internet|telekom|dsl|glasfaser", re.IGNORECASE)
_NOT_INTERNET = re.compile(r"mobil|handy|o2|prepaid", re.IGNORECASE)


def add_house_internet_share_once(conn):
    """Nachtrag (v323): Die Beteiligung "Anteil Haus …" deckt zusätzlich 1/2 des
    Telekom-Internetanschlusses. Einmalig; spätere Änderungen nur im Dialog."""
    if conn.execute("SELECT 1 FROM settings WHERE key='migration_house_cost_share_internet'").fetchone():
        return
    incomes = conn.execute("SELECT id FROM income WHERE lower(label) LIKE 'anteil haus%'").fetchall()
    if len(incomes) != 1:
        return
    income_id = incomes[0]["id"]
    names = _contract_names(conn)
    for c in conn.execute("SELECT co.id, co.label, co.provider, c.name AS category FROM contracts co "
                          "LEFT JOIN categories c ON c.id = co.category_id "
                          "WHERE COALESCE(co.status,'active')='active'").fetchall():
        text = " ".join(filter(None, [names.get(c["id"]), c["label"], c["provider"], c["category"]]))
        if (c["category"] == "Internet" or _INTERNET.search(text)) and not _NOT_INTERNET.search(text) \
                and c["category"] not in ("Mobilfunk", "Abos"):
            conn.execute("INSERT OR IGNORE INTO income_cost_shares (income_id, contract_id, share) "
                         "VALUES (?,?,0.5)", (income_id, c["id"]))
    conn.execute("INSERT INTO settings (key, value) VALUES ('migration_house_cost_share_internet', 'true')")
    conn.commit()


# ---------- API ----------

@router.get("/api/income/{income_id}/cost-shares")
def get_cost_shares(income_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        if not conn.execute("SELECT 1 FROM income WHERE id=?", (income_id,)).fetchone():
            raise HTTPException(404, "Einnahme nicht gefunden")
        names = _contract_names(conn)
        candidates = [{
            "contract_id": r["id"],
            "label": (names.get(r["id"]) or r["label"] or r["provider"] or "Vertrag").strip(),
            "category": r["category"],
            "contract_monthly": round(_monthly(r["amount"], r["frequency"]), 2),
        } for r in conn.execute(
            "SELECT co.id, co.label, co.provider, co.amount, co.frequency, c.name AS category "
            "FROM contracts co LEFT JOIN categories c ON c.id = co.category_id "
            "WHERE COALESCE(co.status,'active')='active' ORDER BY c.name, co.label").fetchall()]
        check = next((c for c in check_all(conn) if c["income_id"] == income_id), None)
        return {"items": shares_for_income(conn, income_id), "candidates": candidates, "check": check}
    finally:
        conn.close()


class ShareItem(BaseModel):
    contract_id: int
    share: float


class SharesIn(BaseModel):
    items: List[ShareItem]


@router.put("/api/income/{income_id}/cost-shares")
def put_cost_shares(income_id: int, payload: SharesIn, session=Depends(auth.require_full_auth)):
    for it in payload.items:
        if not (0 < it.share <= 1):
            raise HTTPException(400, "Anteil muss zwischen 0 und 100 % liegen.")
    conn = get_connection()
    try:
        if not conn.execute("SELECT 1 FROM income WHERE id=?", (income_id,)).fetchone():
            raise HTTPException(404, "Einnahme nicht gefunden")
        conn.execute("DELETE FROM income_cost_shares WHERE income_id=?", (income_id,))
        for it in payload.items:
            if conn.execute("SELECT 1 FROM contracts WHERE id=?", (it.contract_id,)).fetchone():
                conn.execute("INSERT OR REPLACE INTO income_cost_shares (income_id, contract_id, share) "
                             "VALUES (?,?,?)", (income_id, it.contract_id, it.share))
        conn.commit()
        return {"status": "saved", "items": shares_for_income(conn, income_id)}
    finally:
        conn.close()


@router.get("/api/cost-share-check")
def get_cost_share_check(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        import bank_matching
        conn.execute(bank_matching._DISMISS_DDL)
        dismissed = {r[0] for r in conn.execute("SELECT hint_key FROM bank_dismissed_hints").fetchall()}
        out = check_all(conn)
        for c in out:
            c["dismissed"] = c["hint_key"] in dismissed
        return out
    finally:
        conn.close()
