"""
Zugriffsschutz: Passwort (1. Faktor) + Passkey/WebAuthn (2. Faktor).

Wichtig zum Passkey-Teil: Browser erlauben WebAuthn nur in einem "sicheren
Kontext" — also unter https:// oder auf localhost. Für den Zugriff vom
Mac aus http://localhost funktioniert das direkt. Fürs iPhone im selben
Netz reicht ein bloßes http://<Mac-Mini-IP> NICHT aus — dafür brauchst du
HTTPS, z.B. über "tailscale serve" (siehe README). RP_ID/ORIGIN unten per
Umgebungsvariable auf deine echte Adresse einstellen, sobald du die hast.
"""
import os
import threading
import hmac
import time
import secrets
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import bcrypt
import webauthn
from webauthn.helpers.structs import (
    AuthenticatorSelectionCriteria, UserVerificationRequirement,
    PublicKeyCredentialDescriptor,
)
from fastapi import Request, HTTPException, Response
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

from database import get_real_connection as get_connection

BASE_DIR = Path(__file__).resolve().parent.parent
COOKIE_NAME = "ffz_session"
# Harte Obergrenze für die Signaturprüfung -- der eigentliche "Auto Logout"
# ist als reines Session-Cookie gedacht (siehe issue_session unten), das
# beim Schließen von Browser/App verschwindet. In der Praxis hält sich
# insbesondere iOS bei installierten PWAs aber nicht zuverlässig daran: Beim
# Schließen über den App-Switcher wird der WebView-Prozess oft nur
# PAUSIERT statt beendet, wodurch das Cookie und damit die Anmeldung
# unbemerkt tagelang bestehen bleiben kann. Diese Obergrenze ist deshalb
# bewusst kurz gehalten -- sie ist die tatsächlich wirksame Absicherung,
# nicht nur ein theoretisches Maximum.
SESSION_MAX_AGE = 60 * 60 * 12  # 12 Stunden

# Fallback-Werte, falls die Adresse nicht aus der Anfrage ermittelt werden kann.
# Im Normalbetrieb werden RP_ID/ORIGIN pro Anfrage aus der tatsächlich
# aufgerufenen Adresse abgeleitet (siehe rp_id_for / origin_for) — dadurch
# funktioniert die App gleichzeitig über localhost UND über die
# Tailscale-Adresse, ohne dass Umgebungsvariablen umgestellt werden müssen.
RP_ID = os.environ.get("RP_ID", "localhost")
RP_NAME = "Family Finance"
ORIGIN = os.environ.get("ORIGIN", "http://localhost:8420")


def rp_id_for(request: Optional["Request"]) -> str:
    """Die RP-ID ist immer der reine Hostname der aufgerufenen Adresse.
    WebAuthn verlangt, dass sie exakt zur Adresse in der Browser-Leiste passt."""
    if request is None:
        return RP_ID
    return request.url.hostname or RP_ID


def origin_for(request: Optional["Request"]) -> str:
    """Der Origin muss inkl. Schema und ggf. Port exakt dem entsprechen, was der
    Browser sendet. Hinter einem Proxy (z.B. `tailscale serve`) steht die vom
    Browser genutzte Adresse im Origin-Header — der hat deshalb Vorrang."""
    if request is None:
        return ORIGIN
    header_origin = request.headers.get("origin")
    if header_origin:
        return header_origin
    return f"{request.url.scheme}://{request.url.netloc}"


# Ausstehende WebAuthn-Challenges, je SITZUNG und Vorgang ('register'/'login').
# Früher gab es nur eine globale Challenge pro Vorgang: eine zweite, parallele
# Anmeldung überschrieb sie, und eine Challenge war nicht an die Sitzung
# gebunden, die sie angefordert hat. Jetzt: an die Sitzungskennung gebunden,
# nach 5 Minuten verfallen, und nur EINMAL verwendbar (auch bei Fehlschlag).
CHALLENGE_TTL_SECONDS = 300
_pending_challenges: dict[tuple, tuple] = {}


def _challenge_key(request: Optional["Request"], kind: str) -> tuple:
    session = _read_session(request) if request is not None else None
    return ((session or {}).get("sid") or "-", kind)


def _store_challenge(request, kind: str, challenge: bytes):
    now = time.time()
    for k in [k for k, (_, ts) in _pending_challenges.items() if now - ts > CHALLENGE_TTL_SECONDS]:
        _pending_challenges.pop(k, None)
    _pending_challenges[_challenge_key(request, kind)] = (challenge, now)


def _take_challenge(request, kind: str) -> Optional[bytes]:
    entry = _pending_challenges.pop(_challenge_key(request, kind), None)
    if not entry or time.time() - entry[1] > CHALLENGE_TTL_SECONDS:
        return None
    return entry[0]


# Abgemeldete Sitzungen. Die Sitzungen selbst sind signierte Cookies ohne
# Server-Speicher -- ein abgemeldetes Cookie blieb deshalb bisher bis zum
# Ablauf gültig, wenn es jemand kopiert hatte. Jetzt trägt jede Sitzung eine
# Zufallskennung, die beim Abmelden (und beim Ersetzen durch eine neue
# Sitzung) gesperrt wird. Im Speicher genügt: Ein Neustart macht ohnehin alle
# Sitzungen ungültig (neuer Schlüssel, siehe unten).
_revoked_sids: set = set()

# WICHTIG: bewusst NICHT auf Festplatte gespeichert, sondern bei jedem
# Prozessstart neu zufällig erzeugt. Dadurch werden alle Sessions bei jedem
# Server-Neustart ungültig — wie gewünscht ein automatischer Logout.
_secret_key = secrets.token_hex(32)
_serializer = URLSafeTimedSerializer(_secret_key)


# ---------------- Setup / Passwort ----------------

def user_exists() -> bool:
    conn = get_connection()
    row = conn.execute("SELECT 1 FROM app_user WHERE id=1").fetchone()
    conn.close()
    return row is not None


# ---------- Schutz gegen Passwort-Durchprobieren ----------
# Bewusst im Arbeitsspeicher gehalten (kein DB-Schreibzugriff bei jedem
# Fehlversuch) — passt zur Single-User-Installation, und ein Serverneustart
# setzt die Sperre ohnehin zurück, was hier akzeptabel ist.
_FAILED_LOGINS: dict = {}
_MAX_ATTEMPTS = 8
_LOCKOUT_MINUTES = 15


def _client_key(request: Optional[Request], scope: str = "") -> str:
    # scope trennt die Zähler (z.B. "totp"), damit ein erfolgreicher
    # Passwort-Login die TOTP-Fehlversuche NICHT wieder auf null setzt.
    host = "unknown" if request is None or request.client is None else request.client.host
    return f"{scope}:{host}" if scope else host


def check_login_allowed(request: Optional[Request], scope: str = ""):
    """Wirft 429, wenn zu viele Fehlversuche von derselben Adresse kamen."""
    key = _client_key(request, scope)
    entry = _FAILED_LOGINS.get(key)
    if not entry:
        return
    count, blocked_until = entry
    if blocked_until and datetime.utcnow() < blocked_until:
        remaining = int((blocked_until - datetime.utcnow()).total_seconds() / 60) + 1
        raise HTTPException(
            429, f"Zu viele Fehlversuche. Bitte in etwa {remaining} Minuten erneut versuchen."
        )
    if blocked_until and datetime.utcnow() >= blocked_until:
        _FAILED_LOGINS.pop(key, None)


def register_failed_login(request: Optional[Request], scope: str = ""):
    key = _client_key(request, scope)
    count, _ = _FAILED_LOGINS.get(key, (0, None))
    count += 1
    blocked_until = datetime.utcnow() + timedelta(minutes=_LOCKOUT_MINUTES) if count >= _MAX_ATTEMPTS else None
    _FAILED_LOGINS[key] = (count, blocked_until)


def reset_failed_logins(request: Optional[Request], scope: str = ""):
    _FAILED_LOGINS.pop(_client_key(request, scope), None)


def create_user(username: str, password: str):
    if user_exists():
        raise HTTPException(400, "Es existiert bereits ein Zugang.")
    if len(password) < 8:
        raise HTTPException(400, "Passwort muss mindestens 8 Zeichen haben.")
    password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    conn = get_connection()
    conn.execute(
        "INSERT INTO app_user (id, username, password_hash) VALUES (1, ?, ?)",
        (username, password_hash),
    )
    conn.commit()
    conn.close()


def verify_password(username: str, password: str) -> bool:
    conn = get_connection()
    row = conn.execute("SELECT * FROM app_user WHERE id=1").fetchone()
    conn.close()
    if not row or row["username"] != username:
        return False
    return bcrypt.checkpw(password.encode(), row["password_hash"].encode())


def has_passkey(request: Optional[Request] = None) -> bool:
    rp_id = rp_id_for(request)
    conn = get_connection()
    row = conn.execute("SELECT 1 FROM passkeys WHERE rp_id=? LIMIT 1", (rp_id,)).fetchone()
    conn.close()
    return row is not None


# ---------------- TOTP: Alternative zum Passkey als zweiter Faktor ----------
# Bewusst als GLEICHWERTIGE Alternative, nicht als Ergänzung zum Passkey --
# wer TOTP eingerichtet hat, meldet sich damit an, wer einen Passkey hat, mit
# diesem. Für Geräte/Situationen, in denen Passkeys unpraktisch sind (z.B.
# älterer Windows-PC ohne Windows Hello), oder als bewusste Alternative.

def has_totp() -> bool:
    conn = get_connection()
    row = conn.execute("SELECT totp_secret FROM app_user WHERE id=1").fetchone()
    conn.close()
    return bool(row and row["totp_secret"])


def begin_totp_setup() -> dict:
    """Erzeugt ein neues Geheimnis -- wird erst nach erfolgreicher Bestätigung
    eines Codes tatsächlich gespeichert (complete_totp_setup), damit sich der
    Nutzer nicht mit einem falsch gescannten QR-Code aussperrt."""
    import pyotp
    secret = pyotp.random_base32()
    conn = get_connection()
    row = conn.execute("SELECT username FROM app_user WHERE id=1").fetchone()
    conn.close()
    username = row["username"] if row else "Family Finance"
    otpauth_url = pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name="Family Finance")
    return {"secret": secret, "otpauth_url": otpauth_url}


def complete_totp_setup(secret: str, code: str) -> bool:
    import pyotp
    global _last_totp_counter
    totp = pyotp.TOTP(secret)
    code = (code or "").strip()
    now = time.time()
    current = totp.timecode(datetime.fromtimestamp(now))
    matched = next((current + o for o in (0, -1, 1) if hmac.compare_digest(totp.at(now, o), code)), None)
    if matched is None:
        return False
    with _totp_lock:
        # Der zur Einrichtung benutzte Code gilt danach als verbraucht.
        _last_totp_counter = max(_last_totp_counter, matched)
    conn = get_connection()
    conn.execute("UPDATE app_user SET totp_secret=? WHERE id=1", (secret,))
    conn.commit()
    conn.close()
    return True


_last_totp_counter = -1
_totp_lock = threading.Lock()


def verify_totp_code(code: str) -> bool:
    import pyotp
    conn = get_connection()
    row = conn.execute("SELECT totp_secret FROM app_user WHERE id=1").fetchone()
    conn.close()
    if not row or not row["totp_secret"]:
        return False
    totp = pyotp.TOTP(row["totp_secret"])
    # Wie zuvor ±1 Zeitfenster Toleranz (Uhrabweichung), aber jeder Code nur
    # EINMAL: Ein mitgelesener Code (Schulterblick, Proxy-Log) ließ sich
    # bisher innerhalb seiner Gültigkeit erneut für eine Anmeldung verwenden.
    global _last_totp_counter
    code = (code or "").strip()
    now = time.time()
    current = totp.timecode(datetime.fromtimestamp(now))
    for offset in (0, -1, 1):
        if hmac.compare_digest(totp.at(now, offset), code):
            counter = current + offset
            with _totp_lock:
                if counter <= _last_totp_counter:
                    return False
                _last_totp_counter = counter
            return True
    return False


def disable_totp():
    conn = get_connection()
    conn.execute("UPDATE app_user SET totp_secret=NULL WHERE id=1")
    conn.commit()
    conn.close()


# ---------------- Session-Cookie ----------------

def issue_session(response: Response, stage: str, request: Optional[Request] = None):
    """stage: 'password_ok' (Faktor 1 bestanden) oder 'full' (Faktor 2 bestanden).
    Bewusst OHNE max_age/expires gesetzt -> ein echtes Browser-Session-Cookie,
    das verschwindet, sobald der Browser/die App komplett geschlossen wird.
    Zusammen mit dem pro Prozessstart neuen Schlüssel (siehe oben) heißt das:
    Server-Neustart ODER App/Browser schließen -> erneute Anmeldung nötig.

    Das Secure-Flag richtet sich nach der TATSÄCHLICHEN Verbindung, nicht nach
    der ORIGIN-Einstellung: Sonst würde bei ORIGIN=https..., aber Zugriff über
    http://localhost, der Browser das Cookie verwerfen — der Login wäre
    scheinbar erfolgreich, der nächste Aufruf käme aber als 401 zurück."""
    if request is not None:
        old_session = _read_session(request)
        if old_session and old_session.get("sid"):
            # Neue Sitzung (z.B. nach dem 2. Faktor) ersetzt die alte vollständig --
            # das alte Cookie taugt danach nicht mehr (Schutz vor Session-Fixation).
            _revoked_sids.add(old_session["sid"])
    token = _serializer.dumps({"stage": stage, "iat": datetime.utcnow().isoformat(),
                               "sid": secrets.token_urlsafe(16)})
    is_https = request.url.scheme == "https" if request is not None else ORIGIN.startswith("https")
    response.set_cookie(
        COOKIE_NAME, token, httponly=True,
        samesite="lax", secure=is_https,
    )


def set_session_demo_flag(request: Request, response: Response, enabled: bool):
    """Stellt das Session-Cookie mit gesetztem/entferntem 'demo'-Feld neu aus,
    bei ansonsten unverändertem Stage -- dieselbe Session bleibt bestehen
    (kein erneuter Login nötig), nur die Middleware in app.py liest ab jetzt
    'demo': true/false daraus und schaltet database.py entsprechend um."""
    session = _read_session(request) or {}
    payload = {"stage": session.get("stage", "full"), "iat": datetime.utcnow().isoformat(),
               "sid": session.get("sid") or secrets.token_urlsafe(16)}
    if enabled:
        payload["demo"] = True
    token = _serializer.dumps(payload)
    is_https = request.url.scheme == "https"
    response.set_cookie(COOKIE_NAME, token, httponly=True, samesite="lax", secure=is_https)


def _read_session(request: Request) -> Optional[dict]:
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return None
    try:
        data = _serializer.loads(token, max_age=SESSION_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None
    if isinstance(data, dict) and data.get("sid") in _revoked_sids:
        return None
    return data


def require_password_stage(request: Request) -> dict:
    """Für Endpunkte, die nach Faktor 1 (Passwort) aber vor Faktor 2 laufen,
    z.B. den Passkey selbst registrieren/abfragen."""
    session = _read_session(request)
    if not session or session.get("stage") not in ("password_ok", "full"):
        raise HTTPException(401, "Bitte zuerst einloggen.")
    return session


def require_full_auth(request: Request) -> dict:
    """Für alle eigentlichen Finanzdaten-Endpunkte: Passwort UND Passkey nötig."""
    session = _read_session(request)
    if not session or session.get("stage") != "full":
        raise HTTPException(401, "Anmeldung (Passwort + Passkey) erforderlich.")
    return session


def has_any_second_factor() -> bool:
    """True, sobald IRGENDEIN zweiter Faktor existiert -- Passkey für egal
    welche Adresse oder TOTP. Bewusst adressunabhängig: RP-ID und Origin werden
    aus Host-/Origin-Header der Anfrage abgeleitet, die ein Angreifer frei
    wählen kann."""
    conn = get_connection()
    row = conn.execute("SELECT 1 FROM passkeys LIMIT 1").fetchone()
    conn.close()
    return row is not None or has_totp()


def require_factor_enrollment(request: Request) -> dict:
    """Für das Einrichten eines zweiten Faktors (Passkey registrieren, TOTP
    einrichten). Nur mit dem Passwort ('password_ok') ist das ausschließlich
    bei der Ersteinrichtung erlaubt, solange noch GAR KEIN zweiter Faktor
    existiert. Sonst könnte jemand, der nur das Passwort kennt, einfach einen
    eigenen Passkey/TOTP-Code anlegen und hätte damit vollen Zugriff --
    die Zwei-Faktor-Anmeldung wäre wirkungslos. Weitere Geräte/Adressen
    werden deshalb nach vollständiger Anmeldung (Einstellungen) ergänzt."""
    session = require_password_stage(request)
    if session.get("stage") == "full":
        return session
    if has_any_second_factor():
        raise HTTPException(
            403,
            "Für diese Adresse ist noch kein Passkey eingerichtet. Aus Sicherheitsgründen "
            "kann ein weiterer zweiter Faktor nur nach vollständiger Anmeldung hinzugefügt "
            "werden: Bitte an einem bereits eingerichteten Gerät anmelden (z. B. "
            "http://localhost:8420 am Mac) und unter Einstellungen einen Authenticator-Code "
            "(TOTP) einrichten. Damit kannst du dich dann auch hier anmelden und anschließend "
            "einen Passkey für diese Adresse hinzufügen.",
        )
    return session


def clear_session(response: Response, request: Optional[Request] = None):
    """Abmelden: Cookie löschen UND die Sitzungskennung sperren -- eine
    kopierte Kopie des Cookies ist danach ebenfalls wertlos."""
    if request is not None:
        session = _read_session(request)
        if session and session.get("sid"):
            _revoked_sids.add(session["sid"])
    response.delete_cookie(COOKIE_NAME)


# ---------------- WebAuthn: Registrierung eines neuen Passkeys ----------------

def begin_passkey_registration(username: str, request: Optional[Request] = None) -> dict:
    import json
    rp_id = rp_id_for(request)
    conn = get_connection()
    existing = conn.execute("SELECT credential_id, rp_id FROM passkeys").fetchall()
    conn.close()

    exclude = [
        PublicKeyCredentialDescriptor(id=webauthn.base64url_to_bytes(r["credential_id"]))
        for r in existing
        if r["rp_id"] == rp_id
    ]
    options = webauthn.generate_registration_options(
        rp_id=rp_id, rp_name=RP_NAME, user_name=username,
        authenticator_selection=AuthenticatorSelectionCriteria(
            user_verification=UserVerificationRequirement.PREFERRED,
        ),
        exclude_credentials=exclude,
    )
    _store_challenge(request, "register", options.challenge)
    return json.loads(webauthn.options_to_json(options))


def complete_passkey_registration(credential_json: str, label: str,
                                   request: Optional[Request] = None) -> dict:
    challenge = _take_challenge(request, "register")
    if not challenge:
        raise HTTPException(400, "Keine Registrierung angefordert.")
    rp_id = rp_id_for(request)
    origin = origin_for(request)
    try:
        verification = webauthn.verify_registration_response(
            credential=credential_json, expected_challenge=challenge,
            expected_rp_id=rp_id, expected_origin=origin,
        )
    except Exception as e:
        raise HTTPException(
            400,
            f"Passkey-Registrierung von Browser-Seite abgelehnt ({type(e).__name__}: {e}). "
            f"Erwartete Adresse war RP_ID={rp_id!r}, ORIGIN={origin!r} — "
            "stimmt das exakt mit der Adresse in der Browser-Leiste überein?",
        )
    conn = get_connection()
    conn.execute(
        "INSERT INTO passkeys (label, credential_id, public_key, sign_count, rp_id) VALUES (?,?,?,?,?)",
        (label, webauthn.helpers.bytes_to_base64url(verification.credential_id),
         webauthn.helpers.bytes_to_base64url(verification.credential_public_key),
         verification.sign_count, rp_id),
    )
    conn.commit()
    conn.close()
    return {"status": "registered"}


# ---------------- WebAuthn: Anmeldung mit Passkey (2. Faktor) ----------------

def begin_passkey_login(request: Optional[Request] = None) -> dict:
    import json
    rp_id = rp_id_for(request)
    conn = get_connection()
    creds = conn.execute("SELECT credential_id FROM passkeys WHERE rp_id=?", (rp_id,)).fetchall()
    conn.close()
    if not creds:
        raise HTTPException(400, "Noch kein Passkey für diese Adresse registriert.")

    allow = [
        PublicKeyCredentialDescriptor(id=webauthn.base64url_to_bytes(r["credential_id"]))
        for r in creds
    ]
    options = webauthn.generate_authentication_options(
        rp_id=rp_id, allow_credentials=allow,   # früher fest RP_ID (localhost) -- über die Tailscale-Adresse unpassend
        user_verification=UserVerificationRequirement.PREFERRED,
    )
    _store_challenge(request, "login", options.challenge)
    return json.loads(webauthn.options_to_json(options))


def complete_passkey_login(credential_json: str, request: Optional[Request] = None) -> bool:
    challenge = _take_challenge(request, "login")
    if not challenge:
        raise HTTPException(400, "Keine Anmeldung angefordert.")

    import json
    raw = json.loads(credential_json) if isinstance(credential_json, str) else credential_json
    cred_id_b64 = raw["id"] if "id" in raw else raw["rawId"]
    rp_id = rp_id_for(request)
    origin = origin_for(request)

    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM passkeys WHERE credential_id=?", (cred_id_b64,)
    ).fetchone()
    if not row:
        conn.close()
        raise HTTPException(401, "Unbekannter Passkey.")

    try:
        verification = webauthn.verify_authentication_response(
            credential=credential_json, expected_challenge=challenge,
            expected_rp_id=rp_id, expected_origin=origin,
            credential_public_key=webauthn.base64url_to_bytes(row["public_key"]),
            credential_current_sign_count=row["sign_count"],
        )
    except Exception as e:
        conn.close()
        raise HTTPException(
            400,
            f"Passkey-Anmeldung von Browser-Seite abgelehnt ({type(e).__name__}: {e}). "
            f"Erwartete Adresse war RP_ID={rp_id!r}, ORIGIN={origin!r} — "
            "stimmt das exakt mit der Adresse in der Browser-Leiste überein?",
        )
    conn.execute(
        "UPDATE passkeys SET sign_count=? WHERE id=?",
        (verification.new_sign_count, row["id"]),
    )
    conn.commit()
    conn.close()
    return True
