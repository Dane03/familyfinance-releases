# Review-Skript (Stand v304). Ausführen im Ordner backend/ einer KOPIE des Projekts, nie gegen echte Daten:
#   cp -r familyfinance /tmp/ff && cd /tmp/ff/backend && rm -f ../data/*.db && python3 ../scripts/review/design.py
# Braucht: pip install playwright (+ playwright install chromium). Nutzt die Demo-Datenbank und Port 8420.
import sys, threading, time, json
sys.path.insert(0,'.')
import database, auth, demo_data
database.init_db(); demo_data.generate_demo_db()
import uvicorn, app as appmod
from fastapi.testclient import TestClient
print('setup:',TestClient(appmod.app).post('/api/auth/setup',json={'username':'tester','password':'testtest123'}).status_code)
srv=uvicorn.Server(uvicorn.Config(appmod.app,host="127.0.0.1",port=8420,log_level="error"))
threading.Thread(target=srv.run,daemon=True).start(); time.sleep(3)
from playwright.sync_api import sync_playwright
tok=auth._serializer.dumps({'stage':'full','iat':'x','demo':True})
JS_AUDIT="""
() => {
  const vw=window.innerWidth, out={};
  out.scrollW=document.documentElement.scrollWidth; out.vw=vw;
  const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&e.offsetParent!==null};
  const sel=e=>e.tagName.toLowerCase()+(e.id?'#'+e.id:'')+(e.className&&typeof e.className==='string'?'.'+e.className.trim().split(/\\s+/).slice(0,2).join('.'):'');
  const panel=document.querySelector('.tab-panel:not([style*="display: none"])')||document.body;
  const over=[...panel.querySelectorAll('*')].filter(e=>vis(e)&&e.getBoundingClientRect().right>vw+2&&!e.closest('.doc-list-scroll,[style*="overflow"],svg,table,pre,.chart-scroll'));
  out.overflow=[...new Set(over.map(sel))].slice(0,4);
  const tap=[...panel.querySelectorAll('button,a[href],select,input:not([type=hidden]),[role=button]')].filter(vis).filter(e=>{const r=e.getBoundingClientRect();return Math.min(r.width,r.height)<40});
  out.smallTaps=tap.length; out.smallTapEx=[...new Set(tap.map(e=>sel(e)+':'+Math.round(e.getBoundingClientRect().height)+'px'))].slice(0,4);
  const fs=[...panel.querySelectorAll('input:not([type=checkbox]):not([type=radio]):not([type=hidden]),select,textarea')].filter(vis).filter(e=>parseFloat(getComputedStyle(e).fontSize)<16);
  out.smallFont=fs.length; out.smallFontEx=[...new Set(fs.map(e=>sel(e)+':'+getComputedStyle(e).fontSize))].slice(0,3);
  return out;
}"""
res={}
with sync_playwright() as p:
    b=p.chromium.launch()
    for name,vp,mobile in (("iPhone",{'width':390,'height':844},True),("Mac",{'width':1280,'height':800},False)):
        ctx=b.new_context(viewport=vp,is_mobile=mobile,has_touch=mobile,device_scale_factor=2 if mobile else 1,
                          user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1" if mobile else None)
        ctx.add_cookies([{'name':'ffz_session','value':tok,'url':'http://localhost:8420'}])
        pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)[:120])); pg.on("console",lambda m:errs.append("console:"+m.text[:100]) if m.type=="error" else None)
        pg.goto("http://localhost:8420"); pg.wait_for_timeout(2500)
        tabs=pg.evaluate("[...document.querySelectorAll('[data-tab]')].map(b=>b.dataset.tab)")
        res[name]={}
        for t in tabs:
            pg.evaluate(f"document.querySelector('[data-tab=\"{t}\"]').click()"); pg.wait_for_timeout(900)
            pg.evaluate("document.querySelectorAll('.group-toggle').forEach(h=>h.click())")
            r=pg.evaluate(JS_AUDIT); res[name][t]=r
            if t in("tab-dashboard","tab-vermoegen","tab-contracts"): pg.screenshot(path=f"/tmp/{name}_{t}.png")
        res[name]["_errors"]=sorted(set(errs))[:6]
        ctx.close()
    b.close()
json.dump(res,open('/tmp/design.json','w'),ensure_ascii=False,indent=1)
for dev,d in res.items():
    print("=====",dev)
    for t,r in d.items():
        if t=="_errors": print("Fehler:",r); continue
        flag=[]
        if r['scrollW']>r['vw']+2: flag.append(f"SEITE SCROLLT SEITLICH {r['scrollW']}>{r['vw']}")
        if r['overflow']: flag.append(f"überlaufend:{r['overflow']}")
        if dev=="iPhone" and r['smallTaps']: flag.append(f"{r['smallTaps']} kleine Tippflächen {r['smallTapEx']}")
        if dev=="iPhone" and r['smallFont']: flag.append(f"{r['smallFont']} Felder <16px (iOS-Zoom) {r['smallFontEx']}")
        print(f"{t}: {'OK' if not flag else ' | '.join(flag)}")
