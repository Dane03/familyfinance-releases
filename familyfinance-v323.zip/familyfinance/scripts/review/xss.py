# Review-Skript (Stand v304). Ausführen im Ordner backend/ einer KOPIE des Projekts, nie gegen echte Daten:
#   cp -r familyfinance /tmp/ff && cd /tmp/ff/backend && rm -f ../data/*.db && python3 ../scripts/review/xss.py
# Braucht: pip install playwright (+ playwright install chromium). Nutzt die Demo-Datenbank und Port 8420.
import sys, threading, time, sqlite3
sys.path.insert(0,'.')
import database, auth
database.init_db()
X='<img src=x onerror="window.__pwned=1">'
c=sqlite3.connect(database.DB_PATH)
c.execute("INSERT INTO assets(type,label,provider,account_number,current_value) VALUES ('konto',?,?,?,5)",(X+'Giro',X,X))
c.execute("INSERT INTO bank_accounts(connection_key,iban,account_number,label,balance,asset_id) VALUES ('k','DE1','1',?,1,1)",(X,))
c.execute("INSERT INTO bank_transactions(bank_account_id,booking_date,amount,counterparty_name,purpose,tx_hash) VALUES (1,'2026-10-05',-1,?,?,'h')",(X,X))
c.execute("INSERT INTO categories(name) VALUES (?)",(X,))
c.execute("INSERT INTO contracts(label,provider,amount,frequency,status,category_id,source) VALUES (?,?,10,'monthly','active',1,'manuell')",(X+'Vertrag',X))
c.commit(); c.close()
import uvicorn, app as appmod
srv=uvicorn.Server(uvicorn.Config(appmod.app,host="127.0.0.1",port=8420,log_level="error"))
threading.Thread(target=srv.run,daemon=True).start(); time.sleep(3)
from playwright.sync_api import sync_playwright
tok=auth._serializer.dumps({'stage':'full','iat':'x'})
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844})
    ctx.add_cookies([{'name':'ffz_session','value':tok,'url':'http://localhost:8420'}])
    pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto("http://localhost:8420"); pg.wait_for_timeout(2000)
    pg.evaluate("loadVermoegenOverview()"); pg.wait_for_timeout(1500)
    pg.evaluate("document.querySelectorAll('.group-toggle').forEach(h=>h.click())")
    pg.evaluate("openBankTransactions(1,'x')"); pg.wait_for_timeout(1200)
    for fn in ("loadContracts","loadDashboard","loadArchivedContracts"):
        try: pg.evaluate(f"typeof {fn}==='function' && {fn}()"); pg.wait_for_timeout(600)
        except Exception as e: print(fn,"-",str(e)[:60])
    print("XSS ausgelöst (window.__pwned):", pg.evaluate("window.__pwned===1"))
    print("<img>-Elemente aus Fremdtext im DOM:", pg.evaluate("document.querySelectorAll('img[src=x]').length"))
    print("Fehler:",errs)
    b.close()
