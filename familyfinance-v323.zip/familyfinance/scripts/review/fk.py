# Review-Skript (Stand v304). Ausführen im Ordner backend/ einer KOPIE des Projekts, nie gegen echte Daten:
#   cp -r familyfinance /tmp/ff && cd /tmp/ff/backend && rm -f ../data/*.db && python3 ../scripts/review/fk.py
# Braucht: pip install playwright (+ playwright install chromium). Nutzt die Demo-Datenbank und Port 8420.
import sys, shutil, re, sqlite3, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0,'.')
import database, auth, demo_data
database.init_db(); demo_data.generate_demo_db()
# Zusätzliche Verknüpfungen, die im echten Betrieb vorkommen (Bank, Zuordnung)
c=sqlite3.connect(database.DEMO_DB_PATH)
c.execute("INSERT INTO bank_accounts(connection_key,iban,account_number,label,balance,asset_id) VALUES ('k','DE9','9','G',1,(SELECT id FROM assets LIMIT 1))")
c.execute("INSERT INTO bank_transactions(bank_account_id,booking_date,amount,counterparty_name,purpose,tx_hash,contract_id,income_id) VALUES (1,'2026-10-01',-5,'X','Y','hh',(SELECT id FROM contracts LIMIT 1),(SELECT id FROM income LIMIT 1))")
c.commit(); c.close()
import app as a
from fastapi.testclient import TestClient
from fastapi.routing import APIRoute
cl=TestClient(a.app, raise_server_exceptions=False)
ck={'ffz_session':auth._serializer.dumps({'stage':'full','iat':'x','demo':True})}
backup=str(database.DEMO_DB_PATH)+".bak"; shutil.copy(database.DEMO_DB_PATH,backup)
paths=a.app.openapi()['paths']
routes=[p for p,m in paths.items() if 'delete' in m and len(re.findall(r'\{\w+\}',p))==1 and not any(x in p for x in ('connections','fronius','pv/monthly','assign'))]
bad=[]; n=0; ok=0
for pth in routes:
    for i in (1,2,3):
        shutil.copy(backup,database.DEMO_DB_PATH)
        url=re.sub(r'\{\w+\}',str(i),pth)
        try: resp=cl.delete(url,cookies=ck)
        except Exception as e: bad.append((url,'EXC',str(e)[:60])); continue
        n+=1
        if resp.status_code>=500: bad.append((url,resp.status_code,resp.text[:90]))
        elif resp.status_code<300: ok+=1
shutil.copy(backup,database.DEMO_DB_PATH)
print(len(routes),"DELETE-Routen,",n,"Aufrufe,",ok,"erfolgreich, Serverfehler:",len(bad))
for b in bad[:20]: print(b)
