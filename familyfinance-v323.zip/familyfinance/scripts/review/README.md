# Review-Skripte

Wiederholbare Prüfungen aus der Review-Runde (v301–v304). Immer in einer **Kopie** des Projekts laufen lassen
(sie legen Testdaten an und starten einen Server auf Port 8420).

| Skript | Prüft |
|---|---|
| `design.py` | Alle Tabs auf iPhone- (390 px) und Mac-Breite (1280 px): seitlicher Überlauf, Tippflächen < 40 px, Eingabefelder < 16 px (iOS-Zoom), JS-Fehler |
| `users.py` | Zwei Anwender-Szenarien (Benjamin/iPhone, Raphaela/Mac): Bankkonto zuordnen/neu anlegen, ⋯-Menü, Umsatzliste, Suche, Esc, Chat |
| `xss.py` | Bösartige Namen (`<img onerror>`) in Vermögen, Bankumsatz, Vertrag, Kategorie dürfen nie als HTML ankommen |
| `hints.py` | Karte „Erkannt aus Bankumsätzen“: Name/IBAN getrennt, Details, Ablehnen/Wiederherstellen, Überlauf auf dem iPhone |
| `fk.py` | Alle Lösch-Endpunkte mit Demodaten: kein Serverfehler durch Fremdschlüssel |

Kniffe: Routen über `app.openapi()['paths']` auflisten (nicht `app.routes`); Zugang vorab per `POST /api/auth/setup`
einrichten, sonst verdeckt der Ersteinrichtungs-Dialog alles; Demo-Sitzung = Cookie mit `'demo': True`.

**Wichtig:** zwischen zwei Skriptläufen ca. 4 Sekunden warten, sonst ist Port 8420 noch belegt und das Skript spricht mit dem alten Server.
