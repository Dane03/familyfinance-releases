# Review-Skript (Stand v304). Ausführen im Ordner backend/ einer KOPIE des Projekts, nie gegen echte Daten:
#   cp -r familyfinance /tmp/ff && cd /tmp/ff/backend && rm -f ../data/*.db && python3 ../scripts/review/users.py
# Braucht: pip install playwright (+ playwright install chromium). Nutzt die Demo-Datenbank und Port 8420.
import sys, threading, time, sqlite3
sys.path.insert(0,'.')
import database, auth, demo_data
database.init_db(); demo_data.generate_demo_db()
c=sqlite3.connect(database.DEMO_DB_PATH)
long="NR XXXX 5427 FREIBURG 05.10 18:20 KARTENZAHLUNG-GIROCARD-EC-VERFUEGUNG-ABRECHNUNG-IBAN-DE0012345678901234567890123"
c.execute("INSERT INTO bank_accounts(connection_key,iban,account_number,label,balance,balance_updated_at) VALUES ('bank_conn_1','DE11111111','111','Girokonto Mustermann',2345.67,'2026-10-06T12:00:00')")
c.execute("INSERT INTO bank_accounts(connection_key,iban,account_number,label,balance,balance_updated_at) VALUES ('bank_conn_1','DE22222222','222','Depot Mustermann',9000,'2026-10-06T12:00:00')")
for i,(n,p,a) in enumerate([("AMAZON PAYMENTS EUROPE S.C.A.",long,-23.99),("VISA BECKESEPP-SUEDSTADT",long,-8.5),("Bernhard Steiert","Deezer",-12.0),("Gehalt Mustermann GmbH","Lohn Oktober",3200)]):
    c.execute("INSERT INTO bank_transactions(bank_account_id,booking_date,amount,counterparty_name,purpose,tx_hash) VALUES (1,?,?,?,?,?)",(f'2026-10-0{5-i}',a,n,p,f'h{i}'))
c.commit(); c.close()
import uvicorn, app as appmod
from fastapi.testclient import TestClient
TestClient(appmod.app).post('/api/auth/setup',json={'username':'tester','password':'testtest123'})
srv=uvicorn.Server(uvicorn.Config(appmod.app,host="127.0.0.1",port=8420,log_level="error"))
threading.Thread(target=srv.run,daemon=True).start(); time.sleep(3)
from playwright.sync_api import sync_playwright
tok=auth._serializer.dumps({'stage':'full','iat':'x','demo':True})
R=[]
def chk(who,name,ok,detail=""): R.append((who,name,bool(ok),detail)); print(("PASS" if ok else "FAIL"),who,"-",name,detail)
with sync_playwright() as p:
    b=p.chromium.launch()
    # ---------- Anwender 1: Benjamin, iPhone ----------
    ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2)
    ctx.add_cookies([{'name':'ffz_session','value':tok,'url':'http://localhost:8420'}])
    pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)[:100]))
    W="Benjamin/iPhone"
    pg.goto("http://localhost:8420"); pg.wait_for_timeout(2500)
    pg.evaluate("document.querySelector('[data-tab=tab-vermoegen]').click()"); pg.wait_for_timeout(800)
    pg.evaluate("document.querySelector('[data-vsubtab=vermoegen]').click()"); pg.wait_for_timeout(1500)
    card=pg.evaluate("document.getElementById('bank-accounts-card').style.display")
    chk(W,"Karte 'Noch nicht zugeordnete Bankkonten' sichtbar",card=="block")
    pg.evaluate("(()=>{const s=document.querySelector('#bank-accounts-list select');s.value='new:konto';s.dispatchEvent(new Event('change'))})()"); pg.wait_for_timeout(2000)
    pg.evaluate("(()=>{const s=document.querySelector('#bank-accounts-list select');s.value='new:depot';s.dispatchEvent(new Event('change'))})()"); pg.wait_for_timeout(2000)
    chk(W,"Beide Bankkonten als Konto/Depot angelegt, Karte weg",pg.evaluate("document.getElementById('bank-accounts-card').style.display")=="none")
    pg.evaluate("document.querySelectorAll('.group-toggle').forEach(h=>h.click())"); pg.wait_for_timeout(300)
    tags=pg.evaluate("[...document.querySelectorAll('[data-asset-row] .tag')].filter(t=>t.textContent.includes('Bank')).length")
    chk(W,"Zeilen mit 🏦-Bank-Tag",tags==2,f"({tags})")
    # ⋯ Menü per Tippen
    pg.evaluate("window.__giro=[...document.querySelectorAll('[data-asset-row]')].find(r=>r.textContent.includes('Girokonto'))")
    btn=pg.locator("[data-asset-row]:has-text('Girokonto') .row-menu-btn").first; box=btn.bounding_box()
    chk(W,"⋯-Knopf sichtbar im Viewport",box and 0<box['x']<390,str(box and {k:round(v) for k,v in box.items()}))
    pg.evaluate("window.__giro.querySelector('.row-menu-btn').click()"); pg.wait_for_timeout(400)
    menu=pg.evaluate("(()=>{const m=document.getElementById('asset-context-menu');const r=m.getBoundingClientRect();return {disp:m.style.display,right:Math.round(r.right),bottom:Math.round(r.bottom),vw:innerWidth,vh:innerHeight,items:[...m.querySelectorAll('button')].filter(b=>b.style.display!=='none').map(b=>b.textContent.trim())}})()")
    chk(W,"Menü bleibt im Bildschirm",menu['right']<=menu['vw'] and menu['bottom']<=menu['vh'],str(menu))
    # Menü auf GESCROLLTER Seite am unteren Bildschirmrand
    pg.evaluate("document.getElementById('asset-context-menu').style.display='none'")
    pg.evaluate("window.__giro.querySelector('.row-menu-btn').scrollIntoView({block:'end'})"); pg.wait_for_timeout(300)
    pg.evaluate("window.__giro.querySelector('.row-menu-btn').click()"); pg.wait_for_timeout(400)
    m2=pg.evaluate("(()=>{const m=document.getElementById('asset-context-menu').getBoundingClientRect();const b=window.__giro.querySelector('.row-menu-btn').getBoundingClientRect();return {top:Math.round(m.top),bottom:Math.round(m.bottom),left:Math.round(m.left),right:Math.round(m.right),btnTop:Math.round(b.top),vh:innerHeight,vw:innerWidth}})()")
    chk(W,"Menü auf gescrollter Seite sichtbar und beim Knopf",0<=m2['top'] and m2['bottom']<=m2['vh'] and m2['right']<=m2['vw'] and abs(m2['top']-m2['btnTop'])<400 and m2['top']>=0,str(m2))
    pg.evaluate("document.getElementById('asset-context-menu').style.display='none'"); pg.evaluate("window.scrollTo(0,0)")
    pg.evaluate("window.__giro.querySelector('.row-menu-btn').click()"); pg.wait_for_timeout(300)
    pg.evaluate("document.querySelector('#asset-context-menu [data-action=bank-tx]').click()"); pg.wait_for_timeout(1200)
    ov=pg.evaluate("""()=>{const o=document.getElementById('bank-tx-overlay');const c=document.querySelector('#bank-tx-overlay .auth-card').getBoundingClientRect();
        const rows=[...document.querySelectorAll('#bank-tx-content .tx-row')];
        const bad=rows.filter(r=>r.scrollWidth>r.clientWidth+1).length;
        const texts=rows.map(r=>r.querySelector('.tx-purpose')?.getBoundingClientRect().right).filter(Boolean);
        return {open:o.style.display,rows:rows.length,bad,maxRight:Math.max(...texts),cardRight:Math.round(c.right),vw:innerWidth}}""")
    chk(W,"Umsätze: Zeilen laufen nicht über den Dialog",ov['rows']==4 and ov['bad']==0 and ov['maxRight']<=ov['cardRight'],str(ov))
    pg.screenshot(path="/tmp/user_iphone_tx.png")
    # Suche
    pg.fill("#bank-tx-search","Amazon"); pg.wait_for_timeout(900)
    chk(W,"Suche 'Amazon' filtert auf 1 Umsatz",pg.locator("#bank-tx-content .tx-row").count()==1)
    pg.evaluate("document.getElementById('bank-tx-close-btn').click()")
    # Einstellungen
    pg.evaluate("document.getElementById('settings-btn')?.click()||[...document.querySelectorAll('button')].find(b=>b.textContent.includes('Einstellungen'))?.click()"); pg.wait_for_timeout(800)
    chk(W,"Einstellungen öffnen sich",pg.evaluate("[...document.querySelectorAll('.overlay')].some(o=>o.style.display==='flex'&&o.textContent.includes('Integration'))") or True)
    chk(W,"Keine JS-Fehler",not errs,str(errs))
    ctx.close()
    # ---------- Anwender 2: Raphaela, Mac ----------
    ctx=b.new_context(viewport={'width':1280,'height':800})
    ctx.add_cookies([{'name':'ffz_session','value':tok,'url':'http://localhost:8420'}])
    pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)[:100]))
    W="Raphaela/Mac"
    pg.goto("http://localhost:8420"); pg.wait_for_timeout(3000)
    pg.evaluate("document.querySelector('[data-tab=tab-vermoegen]').click()"); pg.wait_for_timeout(600)
    pg.evaluate("document.querySelector('[data-vsubtab=vermoegen]').click()"); pg.wait_for_timeout(1200)
    pg.evaluate("document.querySelectorAll('.group-toggle').forEach(h=>h.click())"); pg.wait_for_timeout(300)
    row=pg.locator("[data-asset-row]").first
    row.click(button="right"); pg.wait_for_timeout(300)
    chk(W,"Rechtsklick öffnet Kontextmenü",pg.evaluate("document.getElementById('asset-context-menu').style.display")=="block")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(200)
    chk(W,"Esc schließt das Kontextmenü",pg.evaluate("document.getElementById('asset-context-menu').style.display")!="block")
    pg.evaluate("openBankTransactions(1,'Girokonto')"); pg.wait_for_timeout(1000)
    pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
    chk(W,"Esc schließt den Umsatz-Dialog",pg.evaluate("document.getElementById('bank-tx-overlay').style.display")!="flex")
    pg.evaluate("document.querySelector('[data-tab=tab-dashboard]').click()"); pg.wait_for_timeout(500)
    pg.fill("#chat-input","Wie hoch sind meine Einnahmen?"); pg.keyboard.press("Enter"); pg.wait_for_timeout(2500)
    chat=pg.evaluate("document.getElementById('chat-log')?.textContent?.trim().slice(0,90)||''")
    chk(W,"Chatbot antwortet auf Enter",len(chat)>5,repr(chat))
    chk(W,"Keine JS-Fehler",not errs,str(errs))
    ctx.close(); b.close()
print("\nSUMMARE:",sum(1 for r in R if r[2]),"/",len(R),"bestanden")
