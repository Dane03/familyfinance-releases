# Review-Skript (Stand v305). In einer KOPIE des Projekts im Ordner backend/ ausführen; zwischen zwei Läufen ~4 s warten (Port 8420).
import sys, threading, time, sqlite3, warnings
warnings.filterwarnings("ignore"); sys.path.insert(0,'.')
import database, auth, demo_data, bank_routes as br
database.init_db(); demo_data.generate_demo_db()
import database as d
d._use_demo_db.set(True)
conn=d.get_connection()
G="DE51500105175421587394Benjamin Moecklin"
acc={"iban":"DE0011112222333344","account_number":"123","label":"Girokonto","balance":"1"}
def tx(dt,a,n,p): return {"booking_date":dt,"value_date":dt,"amount":a,"counterparty_name":n,"purpose":p,"currency":"EUR"}
res={"status":"ok","accounts":[acc],"transactions_by_account":[{"account":acc,"transactions":[
 tx("2026-08-01","-200.00",G,"Dauerauftrag Sparen Oktober Kinderkonto"),tx("2026-09-01","-200.00",G,"Dauerauftrag Sparen September"),
 tx("2026-07-02","-21.42","VISA ANTHROPIC* CLAUDE SUB","CLAUDE.AI SUBSCRIPTION 1234567890 ANTHROPIC.COM"),tx("2026-08-02","-21.42","VISA ANTHROPIC* CLAUDE SUB","CLAUDE.AI SUBSCRIPTION"),tx("2026-09-02","-21.42","VISA ANTHROPIC* CLAUDE SUB","CLAUDE.AI SUBSCRIPTION"),
 tx("2026-08-05","-16.99","DeezerEUROPE","Deezer Premium"),tx("2026-09-05","-16.99","DeezerEUROPE","Deezer Premium"),
 tx("2026-06-01","-15.99","Netflix International B.V.","NETFLIX"),tx("2026-07-01","-15.99","Netflix International B.V.","NETFLIX"),tx("2026-08-01","-15.99","Netflix International B.V.","NETFLIX")]}]}
br.store_sync_result(conn,"bank_conn_1",res)
conn.execute("INSERT INTO contracts(label,amount,frequency,status,source) VALUES ('',99.95,'monthly','active','manuell')")
conn.execute("UPDATE bank_transactions SET contract_id=1, match_source='manual' WHERE counterparty_name LIKE 'Netflix%' OR counterparty_name LIKE 'Deezer%'")
conn.commit(); conn.close()
import uvicorn, app as appmod
from fastapi.testclient import TestClient
TestClient(appmod.app).post('/api/auth/setup',json={'username':'tester','password':'testtest123'})
srv=uvicorn.Server(uvicorn.Config(appmod.app,host="127.0.0.1",port=8420,log_level="error"))
threading.Thread(target=srv.run,daemon=True).start(); time.sleep(3)
from playwright.sync_api import sync_playwright
tok=auth._serializer.dumps({'stage':'full','iat':'x','demo':True})
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2)
    ctx.add_cookies([{'name':'ffz_session','value':tok,'url':'http://localhost:8420'}])
    pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)[:100]))
    pg.goto("http://localhost:8420"); pg.wait_for_timeout(2500)
    pg.evaluate("loadBankInsights()"); pg.wait_for_timeout(1200)
    tabid=pg.evaluate("document.getElementById('bank-insights-card').closest('.tab-panel').id"); print("Karte liegt im Tab:",tabid)
    pg.evaluate(f"document.querySelector('[data-tab={tabid}]').click()"); pg.wait_for_timeout(800)
    el=pg.locator("#bank-insights-card")
    print("Hinweise:",pg.locator(".hint").count(),"| Karte sichtbar:",pg.evaluate("document.getElementById('bank-insights-card').style.display"))
    txt=pg.evaluate("document.getElementById('bank-insights-list').innerText")
    print("IBAN klebt am Namen:", "DE51500105175421587394Benjamin" in txt or "7394Benjamin" in txt, "| IBAN separat sichtbar:", "IBAN DE51 •••• 7394" in txt)
    print("Überlauf:",pg.evaluate("[...document.querySelectorAll('#bank-insights-list *')].filter(e=>e.getBoundingClientRect().right>innerWidth+1).length"))
    pg.evaluate("document.querySelectorAll('.hint-details').forEach(d=>d.open=true)")
    pg.evaluate("document.getElementById('bank-insights-card').scrollIntoView()"); pg.wait_for_timeout(300)
    el.screenshot(path="/tmp/hints_open.png")
    n=pg.locator(".hint").count()
    pg.locator("[data-dismiss-key]").first.click(); pg.wait_for_timeout(1200)
    print("Nach Ablehnen:",pg.locator(".hint").count(),"(vorher",n,") | Abgelehnt-Bereich:",pg.locator(".hint-dismissed summary").inner_text() if pg.locator(".hint-dismissed").count() else "fehlt")
    pg.evaluate("document.querySelector('.hint-dismissed').open=true"); pg.locator("[data-restore-key]").first.click(); pg.wait_for_timeout(1200)
    print("Nach Wiederherstellen:",pg.locator(".hint").count())
    # Zuordnen-Dialog mit Details
    pg.locator("[data-assign-tx]").first.click(); pg.wait_for_timeout(1200)
    print("Zuordnen-Dialog:",pg.evaluate("document.getElementById('bank-assign-tx').innerText.replace(/\\n/g,' | ')"))
    print("Fehler:",errs); b.close()
