#!/usr/bin/env python3
"""
Erstellt aus den fertigen ZIP-Dateien (Mac + Windows) die passende
latest.json für das öffentliche Releases-Repo.

Nutzung:
    python3 make-release-manifest.py v205 \
        --mac /pfad/zu/familyfinance.zip \
        --windows /pfad/zu/familyfinance-windows.zip \
        --notes "Kurze Beschreibung"

Mindestens eine der beiden Plattformen muss angegeben werden. Gibt den
fertigen Inhalt aus UND schreibt ihn direkt in latest.json im aktuellen
Ordner -- die dann zusammen mit beiden ZIPs auf das öffentliche
familyfinance-releases-Repo hochgeladen wird.

Zusätzlich (wenn --mac angegeben ist) wird der Inhalt des Mac-ZIPs als
"Stand vXXX" auf master des Code-Repos Dane03/familyfinance gepusht, damit
die nächtlichen Prüfläufe immer auf dem ausgelieferten Stand arbeiten.
Abschalten mit --no-sync. Braucht git mit Push-Zugang zu GitHub; klappt der
Push nicht, ist das kein Abbruch -- latest.json ist trotzdem fertig.

Schutz: Enthält master Änderungen, die seit dem letzten "Stand vXXX"-Commit
hinzugekommen sind (z.B. gemergte Nachtlauf-PRs) und die im ZIP fehlen, wird
NICHT überschrieben -- stattdessen kommt eine Liste der betroffenen Dateien.
"""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

# WICHTIG: An deinen tatsächlichen GitHub-Nutzernamen und Repo-Namen
# anpassen, falls du etwas anderes als "familyfinance-releases" gewählt
# hast.
REPO = "Dane03/familyfinance-releases"
BRANCH = "main"

# Code-Repo, das bei jedem Release auf den ausgelieferten Stand gebracht wird
CODE_REPO_URL = "https://github.com/Dane03/familyfinance.git"
CODE_REPO_BRANCH = "master"
SYNC_MARKER = "Stand "  # Präfix der Abgleich-Commits ("Stand v316 ...")

# Darf nie im Code-Repo landen, auch wenn es versehentlich im ZIP steckt
FORBIDDEN = [re.compile(p) for p in (
    r"^data/(?!\.gitkeep$)", r"\.db(-journal|-wal|-shm)?$", r"\.key$",
    r"(^|/)\.env(\..*)?$", r"(^|/)backups/", r"\.(ods|rtf)$",
)]


def sha256_of(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git(repo: Path, *args, check=True) -> str:
    r = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} fehlgeschlagen:\n{r.stderr.strip()}")
    return r.stdout


def _safe_extract(zip_path: Path, dest: Path) -> Path:
    """Entpackt das ZIP (mit Schutz gegen ../-Pfade) und liefert den Projekt-Ordner."""
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            p = PurePosixPath(name)
            if p.is_absolute() or ".." in p.parts:
                raise RuntimeError(f"Unsicherer Pfad im ZIP: {name}")
        zf.extractall(dest)
        # extractall verliert die Unix-Rechte (z.B. ausführbares update.command)
        for info in zf.infolist():
            mode = (info.external_attr >> 16) & 0o777
            if mode and not info.is_dir():
                (dest / info.filename).chmod(mode)
    entries = [e for e in dest.iterdir() if e.name not in ("__MACOSX", ".DS_Store")]
    if len(entries) == 1 and entries[0].is_dir():
        return entries[0]
    return dest


def sync_code_repo(mac_zip: Path, version: str, notes: str) -> None:
    print()
    print(f"=== Code-Repo abgleichen ({CODE_REPO_URL}, {CODE_REPO_BRANCH}) ===")
    if not shutil.which("git"):
        print("git nicht gefunden -- Abgleich übersprungen.")
        return

    with tempfile.TemporaryDirectory(prefix="ff-sync-") as tmp:
        tmp = Path(tmp)
        repo, unpacked = tmp / "repo", tmp / "zip"
        unpacked.mkdir()
        try:
            r = subprocess.run(["git", "clone", "-q", "--depth", "200", "-b", CODE_REPO_BRANCH,
                                CODE_REPO_URL, str(repo)], capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError(f"Klonen fehlgeschlagen:\n{r.stderr.strip()}")
            src = _safe_extract(mac_zip, unpacked)

            # Plausibilität: Versionsnummer im ZIP muss zur angegebenen passen
            app_js = src / "frontend" / "app.js"
            if app_js.exists() and f"· {version}" not in app_js.read_text(encoding="utf-8"):
                raise RuntimeError(f"frontend/app.js im ZIP trägt nicht die Version {version} -- "
                                   "falsches ZIP? Abgleich abgebrochen.")

            # Schutz: Änderungen seit dem letzten Abgleich, die im ZIP fehlen würden
            last_sync = _git(repo, "log", "--format=%H", "-1", "--fixed-strings",
                             f"--grep={SYNC_MARKER}v").strip()
            changed_since = []
            if last_sync:
                changed_since = [f for f in _git(repo, "diff", "--name-only",
                                                 f"{last_sync}..HEAD").splitlines() if f]

            # Arbeitsbaum durch ZIP-Inhalt ersetzen
            tracked = [f for f in _git(repo, "ls-files", "-z").split("\0")
                       if f and f != "data/.gitkeep"]
            if tracked:
                subprocess.run(["git", "-C", str(repo), "rm", "-q", "--", *tracked],
                               check=True, capture_output=True)
            shutil.copytree(src, repo, dirs_exist_ok=True)
            (repo / "data").mkdir(exist_ok=True)
            (repo / "data" / ".gitkeep").touch()
            _git(repo, "add", "-A")

            staged = _git(repo, "diff", "--cached", "--name-only").splitlines()
            bad = [f for f in staged if any(p.search(f) for p in FORBIDDEN)]
            if bad:
                raise RuntimeError("Abgebrochen -- diese Dateien dürfen nie ins Repo:\n  "
                                   + "\n  ".join(bad))

            lost = sorted(set(changed_since) & set(staged))
            if lost:
                print("NICHT abgeglichen: master enthält seit dem letzten Release-Abgleich")
                print("Änderungen (z.B. gemergte Nachtlauf-PRs), die in diesem ZIP fehlen:")
                for f in lost:
                    print(f"  {f}")
                print("Bitte diese Änderungen zuerst in den lokalen Stand übernehmen,")
                print("dann das Release neu bauen. latest.json ist davon unberührt.")
                return

            if not staged:
                print(f"master ist bereits auf dem Stand {version} -- nichts zu tun.")
                return

            msg = f"{SYNC_MARKER}{version} (Release)\n\n{notes}".strip()
            _git(repo, "-c", "user.name=familyfinance release",
                 "-c", "user.email=release@familyfinance.local", "commit", "-q", "-m", msg)
            _git(repo, "push", "-q", "origin", f"HEAD:{CODE_REPO_BRANCH}")
            print(f"master auf {version} gebracht ({len(staged)} Dateien geändert).")
        except Exception as e:  # Abgleich darf das Release nie blockieren
            print(f"Abgleich fehlgeschlagen: {e}")
            print("latest.json und ZIPs sind trotzdem fertig -- Abgleich ggf. später "
                  "nachholen (Skript erneut mit denselben Argumenten starten).")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("version", help="z.B. v205")
    parser.add_argument("--mac", type=Path, help="Pfad zu familyfinance.zip (Mac)")
    parser.add_argument("--windows", type=Path, help="Pfad zu familyfinance-windows.zip")
    parser.add_argument("--notes", default="", help="Kurze Beschreibung, in der App sichtbar")
    parser.add_argument("--no-sync", action="store_true",
                        help="Code-Repo NICHT auf den Release-Stand bringen")
    args = parser.parse_args()

    if not args.mac and not args.windows:
        print("Mindestens --mac oder --windows angeben.")
        sys.exit(1)
    if not args.version.startswith("v"):
        print("Versionsnummer sollte mit 'v' beginnen, z.B. v205")
        sys.exit(1)

    platforms = {}
    for key, path, asset_name in [("mac", args.mac, f"familyfinance-{args.version}.zip"),
                                    ("windows", args.windows, f"familyfinance-windows-{args.version}.zip")]:
        if not path:
            continue
        if not path.exists():
            print(f"Datei nicht gefunden: {path}")
            sys.exit(1)
        print(f"Berechne Prüfsumme von {path.name} ({key}) ...")
        platforms[key] = {
            "download_url": f"https://raw.githubusercontent.com/{REPO}/{BRANCH}/{asset_name}",
            "sha256": sha256_of(path),
            "upload_as": asset_name,
        }

    manifest = {"version": args.version, "notes": args.notes, "platforms": platforms}
    manifest_path = Path("latest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    # Kopien mit dem versionierten Dateinamen anlegen, damit man die
    # richtigen Dateien direkt zum Hochladen parat hat -- wichtig, damit
    # jede Version ihre eigene, dauerhaft erreichbare Adresse hat (sonst
    # könnte GitHubs Zwischenspeicher kurzzeitig eine alte Version ausliefern).
    renamed = []
    for key, path in [("mac", args.mac), ("windows", args.windows)]:
        if not path:
            continue
        upload_as = platforms[key]["upload_as"]
        renamed_path = path.parent / upload_as
        renamed_path.write_bytes(path.read_bytes())
        renamed.append(renamed_path)

    print()
    print("=== Fertig ===")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))
    print()
    print(f"latest.json wurde geschrieben nach: {manifest_path.resolve()}")
    print()
    print("Passende, umbenannte Dateien zum Hochladen:")
    for p in renamed:
        print(f"  {p.resolve()}")
    print()
    print(f"Nächster Schritt -- im Browser auf github.com/{REPO}:")
    print("1. 'Add file' -> 'Upload files'")
    print("2. Die oben genannten umbenannten ZIP-Dateien UND latest.json hochziehen")
    print("3. Commit direkt in den 'main'-Branch")
    print()
    print("(Alte Versions-ZIPs im Repo können bei Bedarf gelöscht werden, müssen aber nicht --")
    print(" latest.json zeigt ohnehin immer nur auf die neueste.)")

    if args.mac and not args.no_sync:
        sync_code_repo(args.mac, args.version, args.notes)


if __name__ == "__main__":
    main()
