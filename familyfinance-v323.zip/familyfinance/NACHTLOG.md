# Nachtlog

## 2026-10-10 – Security-Review (Nachtlauf, unbeaufsichtigt)

**Rolle:** Security-Reviewer · **Geprüfter Stand:** `master` @ `81cc279`, Build v316 (= aktuelles Release v316 laut `latest.json`, Code-Repo also aktuell) · **Ergebnis-Build:** v317 (2026-10-10), kein Release gebaut.

### Behoben

1. **Hochgeladene HTML-/SVG-Dateien liefen als Code in der App (mittel–hoch).**
   `shared_helpers.serve_document_file` (gemeinsam für Belege, Lohnabrechnungen, Vorsorge-Dokumente) lieferte
   jede Datei „inline" mit einem aus dem Dateinamen geratenen Typ aus – ein Beleg `rechnung.html`/`.svg` wurde
   im In-App-Betrachter im Ursprung der App ausgeführt und konnte mit der Sitzung beliebige API-Aufrufe machen.
   Jetzt nur noch PDF, Bilder (inkl. HEIC), TXT/CSV inline; alles andere kommt immer als Download.
   *Test:* TestClient (localhost:8420), Upload über `/api/receipts/upload`: vorher `.html`/`.svg` →
   `inline` + `text/html`/`image/svg+xml`; nachher `attachment`. PDF/PNG/JPG/TXT unverändert `inline`, Download-Knopf unverändert.
2. **Downgrade über `/api/maintenance/apply-app-update` (mittel).** Der Endpunkt übernahm `download_url` und
   `sha256` aus der Anfrage – so ließ sich jede ältere Version aus der Historie des Release-Repos einspielen
   (bekannte, inzwischen behobene Lücken wieder öffnen). Jetzt kommen Adresse/Prüfsumme wie bei
   `apply-all-updates` nur aus dem Manifest; Felder werden aus Kompatibilität angenommen, aber ignoriert.
   Wird vom Frontend nicht benutzt. *Test:* mit gestubbtem Download: vorher wurde die v250-Adresse aus der
   Anfrage eingespielt, nachher „Kein Update verfügbar" bzw. nur die Manifest-Adresse; ohne Login weiterhin 401.
3. **Restliche ungefilterte `innerHTML`-Stellen (mittel)** aus dem letzten Lauf mit `escHtml` nachgezogen
   (`frontend/app.js`): Versicherungsarten (Liste, Dropdown, Auswertung), Kategorie-Dropdown `value`,
   Einnahmen-Kategorie, Lohnabrechnung Arbeitgeber/Monat aus PDF, Zähler-Anbieter, Abrechnungsnotiz,
   Depot ISIN/Klasse/Region, Update-Notizen aus `latest.json`, Sungrow/Zappi/Schlüsselbund-Fehlertexte,
   Finanzierungs-Rechenfehler, sowie alle `data.detail`/`err.detail`/`data.error`/`ocr_error` in `innerHTML`.
   *Test:* Playwright mit Versicherungsart `<img onerror>"q` und Kategorie mit `">`: vorher XSS ausgelöst
   (2 `<img>`), Dropdown-Wert verfälscht; nachher 0, Text wörtlich sichtbar, Dropdown-Wert = Originalname.

Allgemein: `py_compile` (app.py, shared_helpers.py), `node --check` (app.js, service-worker.js), `xss.py` grün,
`fk.py` 0 Serverfehler, Server startet, Ersteinrichtung + Passwort- und TOTP-Login funktionieren
(Datenzugriff erst nach 2. Faktor). Build v316 → v317, Datum 2026-10-10.

### Nachträglich behoben (2026-10-10, auf Wunsch von Benjamin, gleicher Build v317)

4. **Content-Security-Policy** für alle HTML-Antworten (`shared_helpers.content_security_policy`):
   `script-src 'self'`, `object-src 'none'`, `base-uri 'none'`, `frame-ancestors 'self'`. Inline-Skripte aus
   `index.html` nach `theme-boot.js`/`theme-icons.js` ausgelagert, `onclick` durch Listener ersetzt;
   PDF-Betrachter und Sungrow-OAuth-Rückseite mit Nonce (dabei latente XSS über `{str(e)!r}` im
   OAuth-Callback beseitigt). Styles bleiben `'unsafe-inline'` (viele `style=`-Attribute).
5. **Upload-Limit** als ASGI-Middleware: ungültiger `Content-Length` → 400, zu groß angekündigt → 413,
   zusätzlich werden empfangene Bytes gezählt (chunked ohne Header → 413, nichts gespeichert).
6. **Lohnabrechnungs-Dateinamen** bereinigt (`_safe_upload_name`): `../../ausbruch.pdf` landet als
   `data/Gehalt/…_ausbruch.pdf`. Nebenbei: beschädigte PDF beim Einzel-Upload gab 500 + verwaiste Datei → jetzt 400, Datei gelöscht.
7. **Passkey-Anmeldung** nutzt die `rp_id` der aufgerufenen Adresse (Tailscale). **WebAuthn-Challenges** pro
   Sitzung, einmalig, 5 min gültig.
8. **TOTP-Code** nur einmal verwendbar (letzter Zeitschritt wird gemerkt, Vergleich zeitkonstant).
9. **Sitzungen widerrufbar:** Cookie trägt zufällige `sid`; Abmelden und Neu-Anmelden widerrufen die alte
   (in-memory, nach Neustart gelten alte Cookies bis Ablauf weiter – akzeptiert).

*Test:* echter uvicorn auf localhost:8420, vorher/nachher: Cookie nach Abmelden 200→401, TOTP-Wiederholung
200→401, 26 MB chunked 500+gespeichert→413+nicht gespeichert, Traversal 500→bereinigt gespeichert,
rpId `localhost`→Tailscale-Name, fremde Sitzung löst Challenge ein → abgelehnt, CSP fehlt→gesetzt.
Playwright: alle Tabs ohne CSP-Verletzung/JS-Fehler, Theme+Icons korrekt, PDF-Betrachter ohne Verletzung.
`xss.py` grün, `fk.py` 0 Serverfehler, `design.py` ohne Fehler, `users.py` 15/15.

### Bewusst nicht geändert
- Login-Sperre pro IP hinter `tailscale serve` (alle kommen von 127.0.0.1): globale Sperre ist die sicherere
  Fehlrichtung; `X-Forwarded-For` von localhost zu vertrauen wäre fälschbar.
- Exception-Texte in Fehlermeldungen: nur für den angemeldeten Besitzer sichtbar, Bank-/Gerätemeldungen werden gebraucht.
- Secrets ohne Schlüsselbund im Klartext: Fallback by design (Windows/kein Keychain).
- `/api/public/apply-updates` ohne Login: bewusst, nur Manifest-Adresse + SHA-256.

**Geprüft, unauffällig:** Ohne Login erreichbar sind nur Status, Setup (nur wenn noch kein Zugang
existiert), Login, Logout, Manifest, Update-Check/-Einspielen (nur Manifest). SHA-256 vor dem Entpacken,
`extractall` ohne Zip-Slip, `data/` wird nie überschrieben. Keine PIN-/Passwort-Ausgaben in Logs gefunden.

### Offen / braucht Benjamin
- Kurz im echten Betrieb prüfen: Beleg-/Lohnabrechnungs-Ansicht (PDF, iPhone-Foto/HEIC) zeigt weiter inline an.
- Aus dem Vorlauf weiterhin offen: Passkey-Tests an echten Geräten.
- Release bauen (gemergt).

### Vorschlag nächster Lauf
CSP vorbereiten (Inline-Skripte zählen, PDF-Betrachter auslagern); Upload-Limit robust machen;
Lohnabrechnungs-Dateinamen bereinigen; `xss.py` um Versicherungsarten/Fehlertexte erweitern.

## 2026-10-09 – Security-Review (Nachtlauf, unbeaufsichtigt)

**Rolle:** Security-Reviewer · **Geprüfter Stand:** `master` @ `a42acb3`, Build v315 (= aktuelles Release v315 laut `latest.json`, Code-Repo also aktuell) · **Ergebnis-Build:** v316 (2026-10-09), kein Release gebaut.

### Behoben

1. **Zwei-Faktor-Anmeldung ließ sich mit dem Passwort allein umgehen (hoch).**
   Nach dem Passwort-Schritt (`password_ok`) konnte man jederzeit einen *eigenen* Passkey registrieren
   (`/api/auth/passkey/register/*`) oder ein *eigenes* TOTP-Geheimnis setzen (`/api/auth/totp/setup/*`) und
   bekam damit sofort eine volle Sitzung. Das TOTP-Setup überschrieb dabei sogar das echte Geheimnis
   (Besitzer ausgesperrt). RP-ID/Origin kommen aus Host-/Origin-Header, sind also frei wählbar.
   Neu: `auth.require_factor_enrollment` – mit nur dem Passwort ist Einrichten nur erlaubt, solange **noch gar
   kein** zweiter Faktor existiert (Ersteinrichtung); sonst ist volle Anmeldung nötig (Einstellungen).
   Zusätzlich: TOTP-Login hat jetzt eine Fehlversuchs-Sperre (8 Versuche / 15 min, eigener Zähler, den ein
   erfolgreicher Passwort-Login nicht zurücksetzt) und setzt das Secure-Flag passend zur Verbindung.
   *Test:* TestClient gegen `http://localhost:8420`, vorher/nachher: Angriff vorher 200 + Dashboard 200 und
   TOTP überschrieben; nachher 403/403/401, Original-TOTP intakt; Brute-Force vorher 9×401, nachher 429 ab
   Versuch 9; Ersteinrichtung, TOTP-/Passkey-Einrichtung aus den Einstellungen und UI-Login (Passwort + TOTP,
   Playwright) funktionieren.
2. **Reflektiertes XSS im PDF-Betrachter (hoch)** – `app.py` `/api/documents/pdf-viewer`: `json.dumps(url)` im
   `<script>` maskiert `</script>` nicht. Ein präparierter Link (Cookie ist SameSite=Lax, wird bei
   Link-Navigation mitgeschickt) konnte im eingeloggten Browser beliebiges JS ausführen. Jetzt werden `< > &`
   als `<…` maskiert. *Test:* Playwright vorher `window.__pwned=true`, nachher `false` und `documentUrl`
   unverändert korrekt.
3. **XSS beim Smart-Import (mittel–hoch)** – `frontend/app.js` `renderSmartImportMapping`: Spaltenköpfe und
   Beispielzeile einer importierten CSV/ODS/XLSX gingen ungefiltert in `innerHTML`. Jetzt `escHtml`.
   *Test:* Playwright mit CSV-Kopf `<img onerror>`: vorher ausgelöst (8 `<img>`), nachher 0, Dropdown-Wert
   bleibt exakt der Spaltenname (Zuordnung funktioniert).

Allgemein: `py_compile` (app.py, auth.py), `node --check` (app.js, service-worker.js), `xss.py` grün,
`fk.py` 0 Serverfehler, Server startet, Login funktioniert. Build v315 → v316, Datum 2026-10-09.

### Verhaltensänderung (bitte beachten)
Eine **neue Adresse/ein neues Gerät ohne eigenen Passkey** (z. B. erstmals über die Tailscale-Adresse) kann
nicht mehr direkt nach dem Passwort einen Passkey anlegen, sobald irgendwo schon ein zweiter Faktor existiert.
Weg: an einem eingerichteten Gerät anmelden → Einstellungen → Authenticator-Code (TOTP) einrichten → am neuen
Gerät mit Passwort + TOTP anmelden → dort in den Einstellungen Passkey hinzufügen. Die Fehlermeldung erklärt das.
Bestehende Passkeys/TOTP funktionieren unverändert. Notfall: `reset-password.command` / `Reset-Password.bat`.

### Befunde (nicht behoben)

**Mittel**
- Weitere ungefilterte `innerHTML`-Stellen in `frontend/app.js` (mit `escHtml` nachziehen):
  Lohnabrechnung `employer`/`month` aus PDF (:828), Versicherungsarten (:1234, :1753, :5357–5370),
  Zähler-Anbieter (:3461), Abrechnungsnotiz (:4454, in :4471 korrekt), Einnahmen-Kategorie (:618),
  `categoryOptionsHTML` value-Attribut (:941), Depot ISIN/Assetklasse (:6433f.), Update-Notizen aus
  `latest.json` (:1066–1091), Sungrow-Fehlertexte (:4406–4435), diverse `data.detail`/`ocr_error`
  (:2158, :2184, :4023, :4529, :5040, :5049). Vorschlag: alle in einem Rutsch escapen und `xss.py` erweitern.
- `app.py` `/api/maintenance/apply-app-update` übernimmt `download_url` + `sha256` aus der Anfrage. Nur Pfade
  im Releases-Repo erlaubt, aber damit lässt sich jede **ältere** Version aus dessen Historie einspielen
  (Downgrade auf bekannte Lücken). Wird vom Frontend nicht benutzt → entfernen oder wie
  `_apply_all_updates` nur das Manifest verwenden.
- Keine Content-Security-Policy. Eine CSP (`default-src 'self'`) würde XSS-Reste stark entschärfen; vorher
  Inline-Skripte/-Styles (u. a. PDF-Betrachter) prüfen.

**Niedrig**
- `/api/public/apply-updates` ohne Login: jeder im Heimnetz kann ein (echtes, geprüftes) verfügbares Update
  samt Neustart auslösen → alle Sitzungen abgemeldet. Bewusste Entscheidung, nur zur Kenntnis.
- Lohnabrechnungs-Upload nutzt `file.filename` unbereinigt im Dateipfad (`receipts_routes.py:80`, `:112`);
  Pfad-Traversal scheitert nur zufällig, `/` im Namen ergibt Serverfehler. Wie bei Belegen per `re.sub` bereinigen.
- `auth.begin_passkey_login` verwendet `rp_id=RP_ID` (Konstante) statt der pro Anfrage ermittelten `rp_id` –
  bitte prüfen, ob Passkey-Login über die Tailscale-Adresse nur dank Umgebungsvariable funktioniert.
- WebAuthn-Challenges global in einem Slot, nicht an die Sitzung gebunden; Login-Challenge wird bei Fehlschlag
  nicht verworfen. TOTP ohne Schutz gegen Wiederverwendung desselben Codes.
- Sitzungen sind zustandslos: Logout löscht nur das Cookie, ein kopiertes Token bleibt bis 12 h gültig.
- Fehlversuchs-Sperre pro IP: hinter `tailscale serve` kommen evtl. alle Anfragen von 127.0.0.1 → gemeinsamer Zähler.
- Fehlermeldungen geben Exception-Texte weiter (z. B. `app.py` „PDF konnte nicht gelesen werden: {e}“).
- `secret_store`: ohne Schlüsselbund bleiben Geheimnisse im Klartext in der DB (wird in den Einstellungen angezeigt).

**Geprüft, unauffällig:** SQL durchgehend parametrisiert (dynamische Spalten nur aus Pydantic-Feldern/
Whitelists); Update: SHA-256 wird vor dem Entpacken geprüft, `zipfile.extractall` neutralisiert `..`/absolute
Pfade, `data/` wird nie überschrieben; subprocess nur mit fester Argumentliste; CORS nur eigener Origin;
Cookie HttpOnly + SameSite=Lax + Secure bei HTTPS; Zugangsdaten-Endpunkte geben Passwörter/PIN nicht zurück;
alle Datenendpunkte verlangen volle Anmeldung (ohne Login nur Status, Setup, Login, Logout, Manifest, Update-Check/-Einspielen).

### Offen / braucht Benjamin
- Mit echten Geräten testen (ging nachts nicht): Passkey-Login am Mac (localhost) und iPhone (Tailscale),
  danach Passkey „Weiteres Gerät“ aus den Einstellungen.
- Entscheiden, ob die Verhaltensänderung oben so passt (Alternative: Passkey für neue Adresse nur mit
  Bestätigung von einem bereits angemeldeten Gerät).
- Release bauen (gemergt).

### Vorschlag nächster Lauf
Alle oben gelisteten `innerHTML`-Stellen escapen + `xss.py` um Import/Lohnabrechnung/Versicherungsarten
erweitern; `apply-app-update` auf Manifest umstellen; Lohnabrechnungs-Dateinamen bereinigen; CSP vorbereiten.
