"""
Client für die iSolarCloud-API von Sungrow — nutzt bewusst die INOFFIZIELLE
'UserAuth'-Anmeldung der Bibliothek 'sungrow-isolarcloud' (normale
E-Mail/Passwort-Anmeldung, kein eigener Entwickler-Zugang bei Sungrow
nötig), statt der offiziellen, aber langsamen OpenAPI-Registrierung.

WICHTIG, ehrlich gesagt: Anmeldung und Anlagen-Liste sind über die
Bibliothek gut dokumentiert und funktionieren zuverlässig. Das genaue
Feldformat der TAGES-Detaildaten (welches Feld "PV-Ertrag" ist, welches
"Einspeisung" usw.) ist laut Bibliotheks-Dokumentation selbst "unverified
against a live device" -- ich habe daher bewusst noch KEINE automatische
Zuordnung/Speicherung dieser Felder gebaut. Der Vorschau-Endpunkt liefert
die Rohdaten eines Tages, damit die echten Feldnamen einmal gemeinsam
verifiziert werden können, bevor daraus automatisch Jahreswerte entstehen
— nach den früheren Problemen mit fehlerhaften PV-Importen bewusst
lieber einmal zu vorsichtig als einmal zu schnell.
"""
from datetime import date

from pysolarcloud import Server, UserAuth, AuthError


class SungrowError(Exception):
    pass


async def test_connection(email: str, password: str) -> dict:
    """Nur Anmeldung + Anlagen-Liste prüfen, ohne Daten zu importieren."""
    try:
        async with UserAuth(Server.Europe, email, password) as auth:
            plants = await auth.async_get_plants()
            return {"ok": True, "plants": plants}
    except AuthError as e:
        return {"ok": False, "error": f"Anmeldung fehlgeschlagen: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"Verbindung fehlgeschlagen: {e}"}


async def fetch_raw_daily_preview(email: str, password: str, ps_id: str, day: date) -> dict:
    """Rohe Tagesdaten EINES Tages für EINE Anlage -- zur Ansicht/Diagnose,
    damit die Feldnamen echt verifiziert werden können, bevor eine
    automatische Auswertung darauf aufbaut."""
    async with UserAuth(Server.Europe, email, password) as auth:
        raw = await auth.async_get_plant_detail_daily(ps_id, day.strftime("%Y%m%d"))
        return raw
