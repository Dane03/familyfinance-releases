"""
Gemeinsam genutzte kleine Helfer, die mehrere Route-Module brauchen.

Bewusst ein eigenes Modul statt einer Definition in app.py: Die Route-Module
werden VON app.py eingebunden, ein Import in die Gegenrichtung wäre ein
Zirkelbezug. Hier importiert niemand etwas aus app.py, damit bleibt die
Abhängigkeitsrichtung eindeutig.
"""
import io
import re
from pathlib import Path
from typing import Optional

from fastapi.responses import FileResponse, Response

_heif_registered = False


def _ensure_heif_support():
    """HEIC/HEIF-Unterstützung für Pillow einmalig nachrüsten -- Pillow kann
    dieses Format nicht von Haus aus lesen, iPhone-Kamerafotos werden aber
    standardmäßig genau so gespeichert."""
    global _heif_registered
    if not _heif_registered:
        import pillow_heif
        pillow_heif.register_heif_opener()
        _heif_registered = True


def serve_document_file(file_path: Path, filename: str, inline: bool):
    """Antwort für einen Beleg/ein Dokument -- wandelt HEIC/HEIF beim
    Inline-Anzeigen (nicht beim Download!) transparent in JPEG um.

    Hintergrund: iPhone-Kamerafotos werden standardmäßig als HEIC
    gespeichert. Ein <img>-Tag zeigt HEIC in Safari zwar an, ein <iframe>
    (wie im In-App-Dokumentbetrachter verwendet, damit "Schließen" auf dem
    iOS-Homescreen zuverlässig funktioniert) tut das jedoch NICHT -- die
    Datei erscheint dort nur als leere Seite mit einem "fehlender
    Inhaltstyp"-Symbol. Der Download bleibt bewusst unverändert im
    Originalformat, nur die Inline-Ansicht wird konvertiert."""
    suffix = file_path.suffix.lower()
    if inline and suffix in (".heic", ".heif"):
        try:
            _ensure_heif_support()
            from PIL import Image
            with Image.open(file_path) as img:
                buf = io.BytesIO()
                img.convert("RGB").save(buf, format="JPEG", quality=90)
            return Response(content=buf.getvalue(), media_type="image/jpeg")
        except Exception:
            # Umwandlung fehlgeschlagen (z.B. beschädigte Datei) -- lieber
            # das Original ausliefern (funktioniert dann evtl. nur außerhalb
            # des Betrachters), als dem Nutzer nur einen Serverfehler zu zeigen.
            pass
    return FileResponse(
        file_path, filename=filename,
        content_disposition_type="attachment" if not inline else "inline",
    )


def monthly_expr(amount_col: str, freq_col: str, split_col: Optional[str] = None) -> str:
    """Baut einen SQL-Ausdruck, der einen Betrag unabhängig von seinem
    Zahlungsintervall auf einen Monatswert normalisiert — damit lassen sich
    monatliche, quartalsweise und jährliche Posten direkt vergleichen und
    summieren."""
    amt = f"{amount_col}*{split_col}" if split_col else amount_col
    return (f"CASE {freq_col} WHEN 'monthly' THEN {amt} "
            f"WHEN 'quarterly' THEN {amt}/3.0 WHEN 'yearly' THEN {amt}/12.0 END")


def _contract_folder_parts(category_name: str, subcategory: Optional[str],
                            provider: Optional[str], label: str,
                            person_name: Optional[str] = None) -> list:
    """Die Ordner-Teilpfade für die Ablage eines Vertrags — dieselbe Logik wie
    beim Einsortieren eines bestätigten Belegs, damit Archivieren denselben
    Ordner wiederfindet, den confirm_receipt angelegt hat. Ist der Vertrag
    einer Person zugeordnet (z.B. eine individuelle BU-Versicherung), wird
    dafür eine eigene Ordnerebene eingezogen, damit sich z.B. Annas und
    Toms Versicherungsunterlagen nicht im selben Ordner vermischen.
    Haushaltsweite Verträge ohne Personen-Zuordnung bleiben unverändert."""
    category_slug = re.sub(r"[^\w.-]", "_", category_name or "Sonstiges")
    contract_slug = re.sub(r"[^\w.-]", "_", (provider or label or "Vertrag"))[:60]
    parts = [category_slug]
    if subcategory:
        parts.append(re.sub(r"[^\w.-]", "_", subcategory))
    if person_name:
        parts.append(re.sub(r"[^\w.-]", "_", person_name))
    parts.append(contract_slug)
    return parts
