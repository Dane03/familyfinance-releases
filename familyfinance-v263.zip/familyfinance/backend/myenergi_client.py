"""
Client für die (von myenergi selbst als "inoffiziell unterstützt"
bezeichnete) myenergi-API — liest die täglich geladene Energiemenge der
Zappi-Wallbox aus, um sie als eigenen Zählertyp ("ev_charging") in die App
zu übernehmen und so vom normalen Hausverbrauch zu trennen.

WICHTIG, ehrlich gesagt: Diese API ist nicht offiziell dokumentiert. Der
Authentifizierungs-Ablauf (Director-Weiterleitung + Digest-Auth mit der
Hub-Seriennummer) ist gut belegt und wird von mehreren seit Jahren
funktionierenden Open-Source-Projekten genutzt (siehe z.B.
github.com/twonk/MyEnergi-App-Api, github.com/G6EJD/MyEnergi-Python-Example).
Das genaue Feldformat der Tagesdaten-Antwort konnte ich mangels Netzzugriff
in dieser Umgebung nicht gegen die echten Server verifizieren — die
Fehlermeldungen unten sind bewusst konkret gehalten, damit ein
abweichendes Format beim ersten echten Test sofort auffällt, statt
stillschweigend falsche Werte zu übernehmen.
"""
import httpx
from datetime import date, timedelta
from typing import Optional

DIRECTOR_HOST = "director.myenergi.net"


class MyenergiError(Exception):
    pass


def _client(hub_serial: str, hub_password: str, host: str) -> httpx.Client:
    return httpx.Client(
        auth=httpx.DigestAuth(hub_serial, hub_password),
        base_url=f"https://{host}",
        timeout=15.0,
        headers={"User-Agent": "FamilyFinance/1.0"},
    )


def _resolve_server(hub_serial: str, hub_password: str) -> str:
    """Der Director gibt per Response-Header bekannt, welcher Regionalserver
    für den jeweiligen Hub zuständig ist -- ALLE weiteren Aufrufe müssen
    gegen DIESEN Server gehen, nicht gegen den Director selbst."""
    with _client(hub_serial, hub_password, DIRECTOR_HOST) as c:
        r = c.get(f"/cgi-jstatus-E{hub_serial}")
        if r.status_code == 401:
            raise MyenergiError("Anmeldung fehlgeschlagen — Hub-Seriennummer oder Passwort falsch.")
        r.raise_for_status()
        server = r.headers.get("x_myenergi-asn")
        if not server:
            raise MyenergiError(
                "Der Director hat keinen zuständigen Server genannt (Header "
                "'x_myenergi-asn' fehlt) — das API-Format hat sich vermutlich "
                "geändert."
            )
        return server


def test_connection(hub_serial: str, hub_password: str) -> dict:
    """Nur Zugangsdaten prüfen, ohne Daten zu importieren — für einen
    'Verbindung testen'-Knopf getrennt vom eigentlichen Sync."""
    try:
        server = _resolve_server(hub_serial, hub_password)
        return {"ok": True, "server": server}
    except MyenergiError as e:
        return {"ok": False, "error": str(e)}
    except httpx.HTTPError as e:
        return {"ok": False, "error": f"Verbindung fehlgeschlagen: {e}"}


def fetch_raw_daily(hub_serial: str, hub_password: str, zappi_serial: str, day: date) -> dict:
    """Rohe, unverarbeitete Tagesdaten EINES Tages -- zur Diagnose, wenn die
    geparsten Werte nicht plausibel wirken. Zwei Runden dokumentationsbasierter
    Annahmen zu den Feldnamen (h1d/h2d/h3d) haben bei diesem konkreten
    Zappi/Hub nicht zum erwarteten Ergebnis geführt -- die echte Antwort
    ansehen ist zuverlässiger als eine dritte Vermutung."""
    server = _resolve_server(hub_serial, hub_password)
    date_str = day.strftime("%Y-%m-%d")
    with _client(hub_serial, hub_password, server) as c:
        r = c.get(f"/cgi-jday-Z{zappi_serial}-{date_str}")
        if r.status_code == 404:
            return {"status_code": 404, "note": "Kein Eintrag für diesen Tag."}
        r.raise_for_status()
        return {"status_code": r.status_code, "payload": r.json()}


def fetch_daily_charge_kwh(hub_serial: str, hub_password: str, zappi_serial: str,
                            start: date, end: date) -> dict:
    """Liefert {'YYYY-MM-DD': geladene_kWh} für jeden Tag im Bereich [start, end].

    WICHTIG -- dies ist die zweite, an einer ECHTEN Antwort korrigierte
    Fassung: Die zunächst aus alten (2019-2023) Community-Analysen
    übernommene Annahme einer "Tages-Summenzeile" (erster Array-Eintrag
    ohne 'min'-Feld) traf auf das aktuelle API-Verhalten NICHT zu -- eine
    echte Antwort zeigte stattdessen einen vollen Tag aus reinen
    MINUTEN-Werten (1440 Einträge, fehlendes 'hr'/'min' bedeutet Stunde/
    Minute 0), ganz ohne Summenzeile. Die Kanäle 'h1b'/'h2b'/'h3b'
    (netzunterstützte "Boost"-Ladung je Phase) und 'h1d'/'h2d'/'h3d'
    (aus Solarüberschuss "divertierte" Ladung je Phase) erscheinen NUR in
    den Minuten, in denen tatsächlich geladen wurde, und der Wert ist die
    in DIESER EINEN MINUTE geladene Energie in Watt-Sekunden (Joule) --
    per Plausibilitätsprüfung an echten Daten bestätigt: die Werte
    entsprachen umgerechnet einer gleichmäßigen ~3,4kW-Ladeleistung, die
    exakt so gegen Ladeende abklingt, wie es bei einem realen Ladevorgang
    zu erwarten wäre. Fehlen alle sechs Felder in einer Minute, wurde in
    dieser Minute schlicht nicht geladen (0 J) -- daher wird über den
    kompletten Tag aufsummiert statt nur eine (u.U. inaktive) Zeile zu lesen."""
    CHARGE_FIELDS = ("h1b", "h2b", "h3b", "h1d", "h2d", "h3d")
    server = _resolve_server(hub_serial, hub_password)
    result = {}
    with _client(hub_serial, hub_password, server) as c:
        day = start
        while day <= end:
            date_str = day.strftime("%Y-%m-%d")
            r = c.get(f"/cgi-jday-Z{zappi_serial}-{date_str}")
            if r.status_code == 404:
                day += timedelta(days=1)
                continue  # kein Wagen angeschlossen an dem Tag -> 0, einfach überspringen
            r.raise_for_status()
            payload = r.json()
            entries = payload.get(f"U{zappi_serial}") if isinstance(payload, dict) else None
            if entries is None and isinstance(payload, list):
                entries = payload
            if not entries:
                day += timedelta(days=1)
                continue
            joules = sum(
                e.get(k, 0) for e in entries if isinstance(e, dict) for k in CHARGE_FIELDS
            )
            result[date_str] = round(joules / 3_600_000, 3)
            day += timedelta(days=1)
    return result
