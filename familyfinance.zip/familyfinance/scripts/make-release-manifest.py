#!/usr/bin/env python3
"""
Erstellt aus den fertigen ZIP-Dateien (Mac + Windows) die passende
latest.json für das öffentliche Releases-Repo.

Nutzung:
    python3 make-release-manifest.py v205 \
        --mac /pfad/zu/familyfinance.zip \
        --windows /pfad/zu/familyfinance-windows.zip \
        --notes "Kurze Beschreibung"

Mindestens eine der beiden Plattformen muss angegeben werden. Gibt den
fertigen Inhalt aus UND schreibt ihn direkt in latest.json im aktuellen
Ordner -- die dann zusammen mit beiden ZIPs auf das öffentliche
familyfinance-releases-Repo hochgeladen wird.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

# WICHTIG: An deinen tatsächlichen GitHub-Nutzernamen und Repo-Namen
# anpassen, falls du etwas anderes als "familyfinance-releases" gewählt
# hast. Die URL folgt dem Muster, das GitHub für Release-Anhänge
# automatisch vergibt, sobald du die ZIPs als Release-Dateien hochlädst.
REPO = "Dane03/familyfinance-releases"


def sha256_of(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("version", help="z.B. v205")
    parser.add_argument("--mac", type=Path, help="Pfad zu familyfinance.zip (Mac)")
    parser.add_argument("--windows", type=Path, help="Pfad zu familyfinance-windows.zip")
    parser.add_argument("--notes", default="", help="Kurze Beschreibung, in der App sichtbar")
    args = parser.parse_args()

    if not args.mac and not args.windows:
        print("Mindestens --mac oder --windows angeben.")
        sys.exit(1)
    if not args.version.startswith("v"):
        print("Versionsnummer sollte mit 'v' beginnen, z.B. v205")
        sys.exit(1)

    platforms = {}
    for key, path, asset_name in [("mac", args.mac, "familyfinance.zip"),
                                    ("windows", args.windows, "familyfinance-windows.zip")]:
        if not path:
            continue
        if not path.exists():
            print(f"Datei nicht gefunden: {path}")
            sys.exit(1)
        print(f"Berechne Prüfsumme von {path.name} ({key}) ...")
        platforms[key] = {
            "download_url": f"https://github.com/{REPO}/releases/download/{args.version}/{asset_name}",
            "sha256": sha256_of(path),
        }

    manifest = {"version": args.version, "notes": args.notes, "platforms": platforms}
    manifest_path = Path("latest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    print()
    print("=== Fertig ===")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))
    print()
    print(f"latest.json wurde geschrieben nach: {manifest_path.resolve()}")
    print()
    print("Nächster Schritt -- einmal die GitHub CLI einrichten (nur beim allerersten")
    print("Mal noetig): brew install gh && gh auth login")
    print()
    print("Danach reicht für jedes künftige Release genau dieser eine Befehl:")
    print()
    zip_args = " ".join(f'"{p}"' for p in [args.mac, args.windows] if p)
    notes_arg = f' --notes "{args.notes}"' if args.notes else ""
    print(f'  gh release create {args.version} {zip_args} --repo {REPO}{notes_arg} \\')
    print(f'    && cp latest.json /pfad/zum/geklonten/familyfinance-releases/latest.json \\')
    print(f'    && (cd /pfad/zum/geklonten/familyfinance-releases && git add latest.json && git commit -m "{args.version}" && git push)')
    print()
    print("(Beim allerersten Mal muss das familyfinance-releases-Repo einmal lokal")
    print(" geklont sein -- 'git clone https://github.com/" + REPO + ".git' --")
    print(" danach reicht der Befehl oben jedes Mal unverändert, nur die Versionsnummer anpassen.)")


if __name__ == "__main__":
    main()
