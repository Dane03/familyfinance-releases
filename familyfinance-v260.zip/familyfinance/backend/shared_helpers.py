"""
Gemeinsam genutzte kleine Helfer, die mehrere Route-Module brauchen.

Bewusst ein eigenes Modul statt einer Definition in app.py: Die Route-Module
werden VON app.py eingebunden, ein Import in die Gegenrichtung wäre ein
Zirkelbezug. Hier importiert niemand etwas aus app.py, damit bleibt die
Abhängigkeitsrichtung eindeutig.
"""
import io
import re
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from fastapi.responses import FileResponse, Response

from database import get_connection

BASE_DIR = Path(__file__).resolve().parent.parent

_heif_registered = False


def _ensure_heif_support():
    """HEIC/HEIF-Unterstützung für Pillow einmalig nachrüsten -- Pillow kann
    dieses Format nicht von Haus aus lesen, iPhone-Kamerafotos werden aber
    standardmäßig genau so gespeichert."""
    global _heif_registered
    if not _heif_registered:
        import pillow_heif
        pillow_heif.register_heif_opener()
        _heif_registered = True


def _is_encrypted_pdf(file_path: Path) -> bool:
    """True, wenn die PDF passwortgeschützt ist. Wichtig für die Anzeige:
    ein <iframe> (der In-App-Betrachter) kann den nativen Passwort-Dialog
    von iOS/Safari nicht einblenden -- eine verschlüsselte PDF darin bliebe
    einfach leer, mit einem "Inhalt fehlt"-Symbol statt einer Passwortabfrage.
    Nur der Header wird gelesen, nicht die ganze Datei -- schnell genug, um
    bei jedem Öffnen geprüft zu werden.

    Bewusst zweistufig: manche real vorkommenden PDFs (z.B. aus bestimmter
    Lohnabrechnungs-Software) haben eine Struktur, an der pypdf schon beim
    reinen ÖFFNEN scheitert, ohne die Verschlüsselung überhaupt zu erreichen.
    Ein Fehlschlagen hier fälschlich als "nicht verschlüsselt" zu werten wäre
    die GEFÄHRLICHERE Richtung -- genau das führt zu einer leeren Seite ohne
    jede Passwortabfrage. Schlägt pypdf fehl, wird deshalb ersatzweise direkt
    im rohen Dateiinhalt nach dem PDF-eigenen Merkmal für Verschlüsselung
    gesucht (funktioniert auch bei sonst nicht sauber parsbaren Dateien);
    bleibt auch das ohne Ergebnis, gilt im Zweifel "verschlüsselt" als
    sicherere Annahme -- schlimmstenfalls ein unnötiger Umweg über die
    Wrapper-Seite, statt einer stumm leeren Ansicht ohne jeden Ausweg."""
    try:
        from pypdf import PdfReader
        return PdfReader(file_path).is_encrypted
    except Exception as e:
        print(f"[pdf] Verschlüsselungsprüfung über pypdf fehlgeschlagen ({e}) — weiche auf Rohsuche aus.")
        try:
            # Grobe, aber robuste Ersatzprüfung: jede verschlüsselte PDF nach
            # PDF-Spezifikation referenziert im Trailer ein "/Encrypt"-Objekt.
            with open(file_path, "rb") as f:
                tail = f.read()
            if b"/Encrypt" in tail:
                return True
            return False
        except Exception:
            return True  # im Zweifel lieber einmal zu vorsichtig als stumm leer
        return False


def serve_document_file(file_path: Path, filename: str, inline: bool):
    """Antwort für einen Beleg/ein Dokument -- wandelt HEIC/HEIF beim
    Inline-Anzeigen (nicht beim Download!) transparent in JPEG um.

    Hintergrund: iPhone-Kamerafotos werden standardmäßig als HEIC
    gespeichert. Ein <img>-Tag zeigt HEIC in Safari zwar an, ein <iframe>
    (wie im In-App-Dokumentbetrachter verwendet, damit "Schließen" auf dem
    iOS-Homescreen zuverlässig funktioniert) tut das jedoch NICHT -- die
    Datei erscheint dort nur als leere Seite mit einem "fehlender
    Inhaltstyp"-Symbol. Der Download bleibt bewusst unverändert im
    Originalformat, nur die Inline-Ansicht wird konvertiert.

    Bei PDFs wird zusätzlich per Antwort-Header signalisiert, ob die Datei
    passwortgeschützt ist (siehe _is_encrypted_pdf) -- das Frontend prüft
    das per HEAD-Anfrage, bevor es entscheidet, ob der eigene iframe-
    Betrachter (kann keinen Passwort-Dialog zeigen) übersprungen und
    stattdessen eine echte Browser-Navigation ausgelöst wird."""
    suffix = file_path.suffix.lower()
    if inline and suffix in (".heic", ".heif"):
        try:
            _ensure_heif_support()
            from PIL import Image
            with Image.open(file_path) as img:
                buf = io.BytesIO()
                img.convert("RGB").save(buf, format="JPEG", quality=90)
            return Response(content=buf.getvalue(), media_type="image/jpeg")
        except Exception:
            # Umwandlung fehlgeschlagen (z.B. beschädigte Datei) -- lieber
            # das Original ausliefern (funktioniert dann evtl. nur außerhalb
            # des Betrachters), als dem Nutzer nur einen Serverfehler zu zeigen.
            pass
    headers = {}
    if suffix == ".pdf":
        headers["X-Document-Encrypted"] = "true" if _is_encrypted_pdf(file_path) else "false"
    return FileResponse(
        file_path, filename=filename,
        content_disposition_type="attachment" if not inline else "inline",
        headers=headers,
    )


# Jeder der vier Dokumenttypen hat eine eigene Route mit demselben Aufbau
# (stored_path + original_filename in der jeweiligen Tabelle) -- diese
# Zuordnung macht sie über eine einzige, gemeinsame Auflösefunktion nutzbar,
# statt die Lookup-Logik viermal zu duplizieren.
_DOCUMENT_URL_PATTERNS = [
    (re.compile(r"^/api/receipts/(\d+)/file$"), "receipts"),
    (re.compile(r"^/api/payslips/(\d+)/file$"), "payslips"),
    (re.compile(r"^/api/pension-documents/(\d+)$"), "pension_documents"),
    (re.compile(r"^/api/person-documents/(\d+)$"), "person_documents"),
]


def resolve_document_url(url: str) -> Optional[Path]:
    """Bildet eine interne API-URL (z.B. '/api/receipts/5/file') auf den
    zugehörigen Datei-Pfad auf der Festplatte ab, indem die passende Tabelle
    anhand des URL-Musters bestimmt und dort nachgeschlagen wird. Wird vom
    Passwort-Entschlüsseln-Endpunkt gebraucht, der nur die URL kennt (nicht
    Dokumenttyp und ID getrennt), damit er für alle vier Dokumenttypen
    gleichermaßen funktioniert. None, wenn die URL zu keinem bekannten
    Dokumenttyp passt oder der Datensatz/die Datei nicht existiert."""
    path = urlparse(url).path
    for pattern, table in _DOCUMENT_URL_PATTERNS:
        m = pattern.match(path)
        if not m:
            continue
        doc_id = m.group(1)
        conn = get_connection()
        row = conn.execute(f"SELECT stored_path FROM {table} WHERE id=?", (doc_id,)).fetchone()
        conn.close()
        if not row:
            return None
        file_path = BASE_DIR / row["stored_path"]
        return file_path if file_path.exists() else None
    return None


def monthly_expr(amount_col: str, freq_col: str, split_col: Optional[str] = None) -> str:
    """Baut einen SQL-Ausdruck, der einen Betrag unabhängig von seinem
    Zahlungsintervall auf einen Monatswert normalisiert — damit lassen sich
    monatliche, quartalsweise und jährliche Posten direkt vergleichen und
    summieren."""
    amt = f"{amount_col}*{split_col}" if split_col else amount_col
    return (f"CASE {freq_col} WHEN 'monthly' THEN {amt} "
            f"WHEN 'quarterly' THEN {amt}/3.0 WHEN 'yearly' THEN {amt}/12.0 END")


def _person_folder_slug(person_name: Optional[str]) -> str:
    """Ordnername für die Personen-Ebene, die laut neuer Speicherstruktur
    JEDEM Dokument-Themenbereich als zweite Ebene folgt (Themenbereich/
    Person/...) -- auch haushaltsweite Dokumente ohne konkrete Person
    brauchen dafür einen Platzhalter, statt diese Ebene einfach
    auszulassen, sonst wäre die Struktur nicht mehr durchgängig."""
    return re.sub(r"[^\w.-]", "_", person_name) if person_name else "Haushalt"


def _contract_folder_parts(category_name: str, subcategory: Optional[str],
                            provider: Optional[str], label: str,
                            person_name: Optional[str] = None) -> list:
    """Die Ordner-Teilpfade für die Ablage eines Vertrags, UNTERHALB des
    Themenbereich-Wurzelordners (z.B. "Ausgaben") -- dieselbe Logik wie
    beim Einsortieren eines bestätigten Belegs, damit Archivieren denselben
    Ordner wiederfindet, den confirm_receipt angelegt hat.

    Reihenfolge bewusst Person ZUERST, erst danach Kategorie: die
    Speicherstruktur soll durchgängig "Themenbereich/Person/..." sein,
    nicht nur für Verträge mit einer individuellen Personen-Zuordnung --
    haushaltsweite Verträge (keine Personen-Zuordnung) landen deshalb
    unter einem "Haushalt"-Platzhalter statt die Ebene auszulassen, damit
    die Struktur über alle Dokumenttypen hinweg gleich bleibt."""
    category_slug = re.sub(r"[^\w.-]", "_", category_name or "Sonstiges")
    contract_slug = re.sub(r"[^\w.-]", "_", (provider or label or "Vertrag"))[:60]
    parts = [_person_folder_slug(person_name), category_slug]
    if subcategory:
        parts.append(re.sub(r"[^\w.-]", "_", subcategory))
    parts.append(contract_slug)
    return parts
