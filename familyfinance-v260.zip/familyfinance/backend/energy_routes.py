"""
Energy Monitor — alle Endpunkte rund um Zählerstände, Gas/Strom/Wasser,
PV-Anlage und Verbrauchsauswertung.

Aus app.py herausgelöst, um die zentrale Datei überschaubar zu halten. Die
Routen sind unverändert übernommen; registriert werden sie über einen
APIRouter, der in app.py eingebunden wird — die URLs bleiben damit exakt
dieselben wie vorher.
"""
import csv
import hashlib
import io
import json
import re
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, StreamingResponse, HTMLResponse
from pydantic import BaseModel

import auth
import meters
import myenergi_client
import sungrow_client
from database import get_connection
from ocr import extract_receipt_data

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent
RECEIPTS_DIR = BASE_DIR / "data" / "Ausgaben"
# Auch in receipts_routes.py definiert -- bewusst als eigenständige, gleiche
# Definition statt eines Imports, um einen Zirkelbezug zu vermeiden. Es ist
# lediglich ein Ablagepfad für kurzlebige Zwischendateien.
SMART_IMPORT_STAGING = BASE_DIR / "data" / "smart_import_staging"


def _get_meter_settings(conn, meter_type: str) -> dict:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (f"meter_settings_{meter_type}",)).fetchone()
    defaults = meters.DEFAULT_SETTINGS.get(meter_type, {})
    if not row:
        return dict(defaults)
    saved = json.loads(row["value"])
    return {**defaults, **saved}


def _get_readings(conn, meter_type: str) -> list:
    rows = conn.execute(
        "SELECT id, reading_date, value, is_new_meter, note, receipt_id FROM meter_readings "
        "WHERE meter_type=? ORDER BY reading_date ASC", (meter_type,),
    ).fetchall()
    return [dict(r) for r in rows]


def _validate_meter_type(meter_type: str):
    if meter_type not in meters.METER_TYPES:
        raise HTTPException(404, f"Unbekannter Zählertyp: {meter_type}")


@router.get("/api/meters/overview")
def meters_overview(session=Depends(auth.require_full_auth)):
    """Kompakte Übersicht aller Zähler fürs Energy-Monitor-Dashboard."""
    conn = get_connection()
    pv_monthly = _get_pv_monthly(conn)
    result = []
    for meter_type in meters.METER_TYPES:
        readings = _get_readings(conn, meter_type)
        has_pv_data = meter_type in ("elec_in", "elec_out") and bool(pv_monthly)
        if not readings and not has_pv_data:
            continue  # wirklich keine Datenquelle vorhanden -> nicht anzeigen
        settings_ = _get_meter_settings(conn, meter_type)
        settlement = meters.compute_settlement(meter_type, readings, settings_, pv_monthly)
        result.append({
            "meter_type": meter_type,
            "label": meters.METER_META[meter_type]["label"],
            "icon": meters.METER_META[meter_type]["icon"],
            "unit": meters.METER_META[meter_type]["unit"],
            "latest_reading": readings[-1] if readings else None,
            "current_daily_rate": meters.current_daily_rate_with_pv(meter_type, readings, pv_monthly),
            "settlement": settlement,
        })
    conn.close()
    return {"meters": result}


@router.get("/api/meters/{meter_type}/readings")
def get_meter_readings(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"readings": readings}


class MeterReadingIn(BaseModel):
    reading_date: date
    value: float
    is_new_meter: bool = False
    note: Optional[str] = None
    receipt_id: Optional[int] = None


@router.post("/api/meters/{meter_type}/readings")
def add_meter_reading(meter_type: str, payload: MeterReadingIn, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    existing = conn.execute(
        "SELECT id FROM meter_readings WHERE meter_type=? AND reading_date=?",
        (meter_type, payload.reading_date.isoformat()),
    ).fetchone()
    if existing:
        # Zweite Erfassung für denselben Tag überschreibt die erste, statt
        # abgelehnt zu werden -- die spätere Eingabe ist die aktuellere und
        # damit maßgebliche (z.B. mehrfaches Ablesen am selben Tag, oder eine
        # Korrektur eines Tippfehlers).
        conn.execute(
            """UPDATE meter_readings SET value=?, is_new_meter=?, note=?, receipt_id=?
               WHERE id=?""",
            (payload.value, int(payload.is_new_meter), payload.note, payload.receipt_id, existing["id"]),
        )
        reading_id = existing["id"]
        status = "updated"
    else:
        cur = conn.execute(
            """INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note, receipt_id)
               VALUES (?,?,?,?,?,?)""",
            (meter_type, payload.reading_date.isoformat(), payload.value,
             int(payload.is_new_meter), payload.note, payload.receipt_id),
        )
        reading_id = cur.lastrowid
        status = "created"
    if payload.receipt_id:
        conn.execute("UPDATE receipts SET review_needed=0 WHERE id=?", (payload.receipt_id,))
    conn.commit()
    conn.close()
    return {"id": reading_id, "status": status}


@router.delete("/api/meters/{meter_type}/readings/{reading_id}")
def delete_meter_reading(meter_type: str, reading_id: int, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    conn.execute("DELETE FROM meter_readings WHERE id=? AND meter_type=?", (reading_id, meter_type))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/meters/{meter_type}/settings")
def get_meter_settings_endpoint(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    settings_ = _get_meter_settings(conn, meter_type)
    conn.close()
    return settings_


@router.put("/api/meters/{meter_type}/settings")
def put_meter_settings(meter_type: str, payload: dict, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    current = _get_meter_settings(conn, meter_type)
    current.update(payload)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (f"meter_settings_{meter_type}", json.dumps(current)),
    )
    conn.commit()
    conn.close()
    return current


@router.get("/api/meters/{meter_type}/monthly")
def get_meter_monthly(meter_type: str, resolution: str = "month",
                       session=Depends(auth.require_full_auth)):
    """Verbrauch fürs Diagramm — inkl. Prognose fürs laufende Jahr für Monate
    ohne echte Ablesung/Import.

    'resolution' ('day' | 'week' | 'month') steuert die Feinheit, damit kurze
    Zeiträume einen echten Verlauf zeigen statt nur ein bis zwei Balken.

    WICHTIG: Bei Strombezug/Einspeisung stammen die Werte teilweise aus dem
    PV-Import, der ausschließlich MONATSwerte liefert. Eine feinere Auflösung
    ist dort also gar nicht erst verfügbar — in dem Fall wird bewusst auf
    Monate zurückgefallen und das über 'effective_resolution' zurückgemeldet,
    statt aus Monatswerten künstlich Tageswerte zu erfinden."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()

    series = meters.get_effective_monthly(meter_type, readings, pv_monthly)
    effective = "month"

    rate = meters.current_daily_rate_with_pv(meter_type, readings, pv_monthly)
    today = date.today()
    # Prognose ergibt nur bei Monatsauflösung Sinn — sie füllt fehlende
    # KALENDERmonate auf; auf Tages-/Wochenebene gibt es nichts zu ergänzen.
    forecast = meters.forecast_missing_months(
        series, rate, date(today.year, 1, 1), date(today.year, 12, 31)
    ) if effective == "month" else {}
    return {"monthly": series, "forecast": forecast, "current_daily_rate": rate,
            "effective_resolution": effective}


@router.get("/api/meters/{meter_type}/kpis")
def get_meter_kpis(meter_type: str, session=Depends(auth.require_full_auth)):
    """Die 5 KPI-Chips für die Detailseite (Letzter Stand, Tagesrate,
    optimaler Abschlag, erwartete Differenz, Jahresprognose)."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    ev_charging_this_year = None
    if meter_type == "elec_in":
        # "Gesamtverbrauch" laut Sungrow läuft über denselben Hausanschluss
        # wie die Zappi-Wallbox und enthält das Laden deshalb zwangsläufig
        # mit -- für die Aufschlüsselung in compute_kpi_chips gebraucht.
        ev_readings = _get_readings(conn, "ev_charging")
        if ev_readings:
            year = date.today().year
            year_start = f"{year}-01-01"
            # Letzter Stand VOR Jahresbeginn als Basislinie -- gibt es noch
            # keinen (Zähler erst dieses Jahr begonnen), gilt 0 als Start.
            before_year = [r for r in ev_readings if r["reading_date"] < year_start]
            baseline = before_year[-1]["value"] if before_year else 0.0
            latest_value = ev_readings[-1]["value"]
            ev_charging_this_year = max(0.0, latest_value - baseline)
    conn.close()
    chips = meters.compute_kpi_chips(meter_type, readings, settings_, pv_monthly,
                                      ev_charging_this_year=ev_charging_this_year)
    return {"chips": chips}


def _refresh_actual_temperatures_if_due():
    """Holt beim Serverstart automatisch aktuelle Monatstemperaturen nach —
    aber höchstens einmal pro Tag, damit ein mehrfacher Neustart am selben
    Tag nicht unnötig oft die (kostenlose, aber fremde) Wetter-API
    beansprucht. Läuft komplett im Hintergrund; ein Fehlschlag (kein
    Standort hinterlegt, kein Netz) darf den App-Start nie verzögern oder
    stören."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        return

    last_row = conn.execute("SELECT value FROM settings WHERE key='weather_last_fetched'").fetchone()
    last_fetched = json.loads(last_row["value"]) if last_row else None
    today_str = date.today().isoformat()
    if last_fetched == today_str:
        conn.close()
        return

    import threading

    def _do_fetch():
        fresh = meters.fetch_actual_monthly_temperatures(location)
        if not fresh:
            return
        c = get_connection()
        existing_row = c.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
        existing = json.loads(existing_row["value"]) if existing_row else {}
        existing.update(fresh)  # neue/aktualisierte Monate überschreiben, ältere bleiben erhalten
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(existing),),
        )
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(today_str),),
        )
        c.commit()
        c.close()

    # Im Hintergrund, damit ein langsamer/fehlender Netzwerkzugriff den
    # eigentlichen Serverstart nicht blockiert.
    threading.Thread(target=_do_fetch, daemon=True).start()
    conn.close()


@router.post("/api/meters/gas/temperature/refresh")
def refresh_gas_temperature(session=Depends(auth.require_full_auth)):
    """Manueller Sofort-Abruf (z.B. nach dem erstmaligen Eintragen eines
    Standorts, ohne auf den nächsten Neustart warten zu müssen)."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        raise HTTPException(400, "Kein Standort in den Einstellungen hinterlegt.")

    fresh = meters.fetch_actual_monthly_temperatures(location)
    if not fresh:
        conn.close()
        return {"status": "error", "error": "Kein Ergebnis — Standort nicht gefunden oder Wetterdienst nicht erreichbar."}

    existing_row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    existing = json.loads(existing_row["value"]) if existing_row else {}
    existing.update(fresh)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(existing),),
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(date.today().isoformat()),),
    )
    conn.commit()
    conn.close()
    return {"status": "ok", "months_updated": len(fresh)}


@router.get("/api/meters/gas/temperature")
def get_gas_temperature(session=Depends(auth.require_full_auth)):
    """Klimamittel (DWD, statisch) + tatsächliche Monatstemperaturen für die
    Temperatur-Kurve auf der Gas-Seite."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    conn.close()
    actual = json.loads(row["value"]) if row else {}
    return {"dwd_climate_avg": meters.DWD_CLIMATE_AVG, "actual": actual}


@router.get("/api/meters/{meter_type}/intervals")
def get_meter_intervals(meter_type: str, session=Depends(auth.require_full_auth)):
    """Ablesungen mit Delta/Tage/Tagesrate für die Detailtabelle."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"intervals": meters.compute_reading_intervals(readings)}


@router.get("/api/meters/{meter_type}/cumulative")
def get_meter_cumulative(meter_type: str, session=Depends(auth.require_full_auth)):
    """Kumulative Ist-Kosten vs. Abschlag vs. optimaler Abschlag übers Jahr —
    nicht sinnvoll für Einspeisung (keine Kosten, sondern Erlös)."""
    _validate_meter_type(meter_type)
    if meter_type == "elec_out":
        raise HTTPException(400, "Kumulativ-Ansicht ist nur für Gas und Strombezug verfügbar.")
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    ev_readings = _get_readings(conn, "ev_charging") if meter_type == "elec_in" else None
    conn.close()
    return {"months": meters.compute_cumulative_cost(meter_type, readings, settings_, pv_monthly, ev_readings=ev_readings)}


class PVSystemSpecIn(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: date
    note: Optional[str] = None


class PVSystemSpecPatch(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: Optional[date] = None
    note: Optional[str] = None


@router.get("/api/pv/system-specs")
def list_pv_system_specs(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM pv_system_specs ORDER BY valid_from").fetchall()
    conn.close()

    today = date.today().isoformat()
    specs = [dict(r) for r in rows]
    # Aktuell gültigen und (falls vorhanden) als nächstes anstehenden
    # Ausbauschritt markieren — nützlich für die geplante Erweiterung, damit
    # die Oberfläche "ab wann gilt was" nicht selbst nachrechnen muss.
    current = None
    upcoming = []
    for s in specs:
        if s["valid_from"] <= today:
            current = s
        else:
            upcoming.append(s)
    return {"specs": specs, "current": current, "upcoming": upcoming}


@router.post("/api/pv/system-specs")
def create_pv_system_spec(payload: PVSystemSpecIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO pv_system_specs (installed_year, kwp, battery_kwh, valid_from, note)
           VALUES (?,?,?,?,?)""",
        (payload.installed_year, payload.kwp, payload.battery_kwh, payload.valid_from, payload.note),
    )
    conn.commit()
    sid = cur.lastrowid
    conn.close()
    return {"id": sid, "status": "created"}


@router.patch("/api/pv/system-specs/{spec_id}")
def update_pv_system_spec(spec_id: int, patch: PVSystemSpecPatch, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    if not fields:
        conn.close()
        return {"status": "unchanged"}
    fields["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE pv_system_specs SET {set_clause} WHERE id=?", (*fields.values(), spec_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@router.delete("/api/pv/system-specs/{spec_id}")
def delete_pv_system_spec(spec_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    conn.execute("DELETE FROM pv_system_specs WHERE id=?", (spec_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/pv/autarkie")
def get_pv_autarkie(session=Depends(auth.require_full_auth)):
    """Autarkiegrad je Monat (PV-Eigenverbrauchsanteil) — für den
    Autarkie-Chart auf der Strom-Detailseite."""
    conn = get_connection()
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_autarkie_series(pv_monthly)}


@router.get("/api/meters/{meter_type}/settlement")
def get_meter_settlement(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    if not readings and not (meter_type in ("elec_in", "elec_out") and pv_monthly):
        raise HTTPException(400, "Noch keine Ablesungen für diesen Zähler erfasst.")
    return meters.compute_settlement(meter_type, readings, settings_, pv_monthly)


# ---------- Energy Monitor Dashboard: vollständige Übersicht ----------

def _all_readings_and_settings(conn) -> tuple:
    readings_by_type = {mt: _get_readings(conn, mt) for mt in meters.METER_TYPES}
    settings_by_type = {mt: _get_meter_settings(conn, mt) for mt in meters.METER_TYPES}
    return readings_by_type, settings_by_type


def _get_pv_monthly(conn) -> list:
    """Monats-PV-Werte für alle Auswertungen."""
    rows = conn.execute(
        "SELECT key, pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_monthly ORDER BY key"
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/api/energy/overview")
def energy_overview(range: str = "ytd", session=Depends(auth.require_full_auth)):
    """Die vier KPI-Karten (Gas, Bezug, Einspeisung, PV-Ertrag) für den
    Energy-Monitor-Dashboard-Kopf, für den gewählten Zeitraum."""
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    cards = meters.compute_overview_cards(readings_by_type, settings_by_type, pv_monthly, range)
    return {"ranges": meters.RANGES, **cards}


@router.get("/api/energy/cost-trend")
def energy_cost_trend(range: str = "ytd", session=Depends(auth.require_full_auth)):
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_cost_trend(readings_by_type, settings_by_type, pv_monthly, range)}


@router.get("/api/energy/settlement")
def energy_settlement(session=Depends(auth.require_full_auth)):
    """Vollständige Jahresabrechnung — Gas, Strombezug und Einspeisung mit
    Fälligkeits-Countdown, für den Jahresabrechnung-Block im Dashboard."""
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return meters.compute_full_settlement(readings_by_type, settings_by_type, pv_monthly)


class MeterSettlementIn(BaseModel):
    meter_type: str
    settlement_date: date
    note: Optional[str] = None


@router.get("/api/energy/settlements")
def list_meter_settlements(session=Depends(auth.require_full_auth)):
    """Alle manuell erfassten Abrechnungszeitpunkte, je Zählerseite —
    unabhängig von der kalenderjahr-basierten Jahresabrechnung oben. Der
    jeweils letzte Eintrag pro Zählerseite dient als Reset-Basis für
    'Verbrauch seit der Abrechnung'."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.post("/api/energy/settlements")
def create_meter_settlement(payload: MeterSettlementIn, session=Depends(auth.require_full_auth)):
    if payload.meter_type not in meters.METER_TYPES:
        raise HTTPException(400, f"Ungültiger Zählertyp: {payload.meter_type}")
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO meter_settlements (meter_type, settlement_date, note) VALUES (?,?,?)",
        (payload.meter_type, payload.settlement_date.isoformat(), payload.note),
    )
    conn.commit()
    conn.close()
    return {"id": cur.lastrowid, "status": "created"}


@router.delete("/api/energy/settlements/{settlement_id}")
def delete_meter_settlement(settlement_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM meter_settlements WHERE id=?", (settlement_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Abrechnungszeitpunkt nicht gefunden")
    conn.execute("DELETE FROM meter_settlements WHERE id=?", (settlement_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/energy/consumption-since-settlement")
def consumption_since_settlement_overview(session=Depends(auth.require_full_auth)):
    """Verbrauch seit dem jeweils letzten manuell erfassten Abrechnungs-
    zeitpunkt, je Zählerseite — ergänzt die Jahresabrechnung oben um einen
    Reset-Punkt, der nicht an den Kalenderjahreswechsel gebunden ist."""
    conn = get_connection()
    readings_by_type, _ = _all_readings_and_settings(conn)
    settlements = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()

    result = {}
    for mt in meters.METER_TYPES:
        latest_settlement = next((s for s in settlements if s["meter_type"] == mt), None)
        if not latest_settlement:
            result[mt] = None
            continue
        settlement_date = date.fromisoformat(latest_settlement["settlement_date"])
        readings = [dict(r) for r in (readings_by_type.get(mt) or [])]
        since = meters.consumption_since_settlement(readings, settlement_date)
        if since:
            since["settlement_note"] = latest_settlement["note"]
        result[mt] = since
    return result


@router.get("/api/pv/monthly")
def get_pv_monthly(session=Depends(auth.require_full_auth)):
    """PV-Zeitreihe auf Monatsbasis — die einzige Auflösung, mit der die App
    arbeitet."""
    conn = get_connection()
    data = _get_pv_monthly(conn)
    conn.close()
    return {"months": data, "plant": meters.PV_PLANT_DEFAULTS,
            "effective_resolution": "month"}


class PVMonthIn(BaseModel):
    key: str
    pv: float = 0
    bezug: float = 0
    einsp: float = 0
    batt_lad: float = 0
    batt_ent: float = 0
    gesamt: float = 0


@router.put("/api/pv/monthly/{key}")
def upsert_pv_month(key: str, payload: PVMonthIn, session=Depends(auth.require_full_auth)):
    if not re.match(r"^\d{4}-\d{2}$", key):
        raise HTTPException(400, "Ungültiger Monatsschlüssel (erwartet YYYY-MM).")
    conn = get_connection()
    conn.execute(
        """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
             einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
             gesamt=excluded.gesamt""",
        (key, payload.pv, payload.bezug, payload.einsp, payload.batt_lad, payload.batt_ent, payload.gesamt),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


@router.delete("/api/pv/monthly/{key}")
def delete_pv_month(key: str, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM pv_monthly WHERE key=?", (key,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


def _parse_pv_timestamp(raw: str):
    """Erkennt das Zeitformat einer iSolarCloud-Zeile und gibt (art, schlüssel)
    zurück. Bewusst datengetrieben statt über den Dateinamen: Die Exporte
    "Monatsbericht" und "Wochenbericht" enthalten BEIDE Tageszeilen — der Name
    sagt also nichts über die tatsächliche Granularität aus.

    - '2026-09-01 14:35:00' -> ('interval', '2026-09-01')  (5-Minuten-Werte)
    - '2026-09-01'          -> ('day',      '2026-09-01')
    - '2026-09'             -> ('month',    '2026-09')
    """
    s = str(raw).strip()
    if re.match(r"^\d{4}-\d{1,2}-\d{1,2}[ T]\d{1,2}:\d{2}", s):
        d = s.split(" ")[0].split("T")[0]
        y, mo, dy = d.split("-")
        return "interval", f"{y}-{int(mo):02d}-{int(dy):02d}"
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", s)
    if m:
        return "day", f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    m = re.match(r"^(\d{4})-(\d{1,2})$", s)
    if m:
        return "month", f"{m.group(1)}-{int(m.group(2)):02d}"
    return None, None


@router.post("/api/pv/import")
async def import_pv_sungrow(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    """iSolarCloud-JAHRESbericht (XLSX) einlesen — erwartet eine Zeile je Monat.

    Hinweis zu den Exportnamen: Die iSolarCloud-Exporte "Monatsbericht" und
    "Wochenbericht" enthalten trotz ihres Namens TAGESzeilen, der Tagesbericht
    sogar 5-Minuten-Werte. Da die App durchgängig auf Monatsbasis auswertet,
    werden solche Dateien mit einem klaren Hinweis abgelehnt statt aus einer
    Teilmenge von Tagen einen unvollständigen Monatswert zu erzeugen."""
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    tmp_path = SMART_IMPORT_STAGING / f"pv_{hashlib.sha256(content).hexdigest()[:12]}.xlsx"
    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)
    try:
        import pandas as pd
        df = pd.read_excel(tmp_path, engine="openpyxl")
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise HTTPException(400, f"Datei konnte nicht gelesen werden: {e}")
    tmp_path.unlink(missing_ok=True)

    cols = df.columns.tolist()

    def find_col(fragment):
        return next((c for c in cols if fragment.lower() in str(c).lower()), None)

    zeit_col = find_col("zeit")
    pv_col, bezug_col, einsp_col = find_col("pv-ertrag"), find_col("netzbezug"), find_col("einspeisung")
    batt_lad_col, batt_ent_col = find_col("batt.-ladung"), find_col("batt.-entladung")
    ges_col = find_col("gesamtverbrauch")
    # Der Tagesbericht hat andere Spalten: Momentanleistung in Watt statt
    # Energiemengen in kWh, und eine gemeinsame "Netz"-Spalte.
    netz_w_col = find_col("netz(w)")
    is_watt_report = any("(w)" in str(c).lower() for c in cols)

    if not zeit_col or not (pv_col or netz_w_col):
        raise HTTPException(
            400,
            "Diese Datei sieht nicht wie ein iSolarCloud-Export aus — erwartet werden "
            "Spalten wie 'Zeit', 'PV-Ertrag(kWh)', 'Einspeisung(kWh)', 'Netzbezug(kWh)' "
            "(Monats-/Wochenbericht) oder 'PV-Ertrag(W)', 'Netz(W)' (Tagesbericht).",
        )

    def num(row, col):
        if not col or col not in df.columns:
            return 0.0
        try:
            return float(str(row[col]).replace(",", "."))
        except (ValueError, TypeError):
            return 0.0

    # ---- Nur Monatszeilen übernehmen ----
    # Bewusste Entscheidung: Die App wertet ausschließlich auf MONATSbasis aus.
    # Tages-/Intervallzeilen aus den feineren iSolarCloud-Exporten werden daher
    # zwar erkannt, aber nicht gespeichert -- aus wenigen Tagen lässt sich kein
    # belastbarer Monatswert ableiten, und eine Teilmenge würde den Jahreschart
    # verfälschen.
    monthly: dict = {}
    non_monthly = 0
    skipped = 0

    for _, row in df.iterrows():
        kind, key = _parse_pv_timestamp(row[zeit_col])
        if kind == "month":
            monthly[key] = {
                "pv": num(row, pv_col), "bezug": num(row, bezug_col), "einsp": num(row, einsp_col),
                "batt_lad": num(row, batt_lad_col), "batt_ent": num(row, batt_ent_col),
                "gesamt": num(row, ges_col),
            }
        elif kind:
            non_monthly += 1
        else:
            skipped += 1

    if not monthly:
        if non_monthly:
            raise HTTPException(
                400,
                f"Diese Datei enthält {non_monthly} Tages-/Intervallzeilen, aber keine "
                "Monatswerte. Die Auswertung arbeitet auf Monatsbasis — bitte den "
                "JAHRESbericht aus iSolarCloud exportieren (eine Zeile je Monat).",
            )
        raise HTTPException(400, f"Keine verwertbaren Zeilen gefunden ({skipped} Zeilen übersprungen).")

    conn = get_connection()
    added = updated = 0

    for key, v in monthly.items():
        existing = conn.execute("SELECT key FROM pv_monthly WHERE key=?", (key,)).fetchone()
        conn.execute(
            """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                 einsp=excluded.einsp, batt_lad=excluded.batt_lad,
                 batt_ent=excluded.batt_ent, gesamt=excluded.gesamt""",
            (key, v["pv"], v["bezug"], v["einsp"], v["batt_lad"], v["batt_ent"], v["gesamt"]),
        )
        updated += 1 if existing else 0
        added += 0 if existing else 1

    conn.commit()
    conn.close()
    return {"added": added, "updated": updated, "skipped": skipped,
            "months": len(monthly)}


@router.post("/api/meters/{meter_type}/upload")
async def upload_meter_bill(meter_type: str, file: UploadFile = File(...),
                             session=Depends(auth.require_full_auth)):
    """Foto/PDF einer Ablesekarte oder Abrechnung einlesen — analog zum
    Beleg-Upload bei den Ausgaben: lokale OCR-Erkennung, Vorschlag zur
    Bestätigung, kein automatisches Speichern eines Zählerstands."""
    _validate_meter_type(meter_type)
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    file_hash = hashlib.sha256(content).hexdigest()
    conn = get_connection()
    existing = conn.execute(
        "SELECT id, uploaded_at FROM receipts WHERE file_hash=? AND review_needed=0",
        (file_hash,),
    ).fetchone()
    if existing:
        conn.close()
        raise HTTPException(409, f"Diese exakte Datei wurde bereits am {existing['uploaded_at']} importiert.")
    # Beide Module werden von app.py eingebunden, ein Import auf Modulebene
    # wäre ein Zirkelbezug -- zum Aufrufzeitpunkt ist alles fertig geladen.
    import receipts_routes
    receipts_routes._cleanup_unconfirmed_receipts(conn, max_age_hours=None)
    conn.close()

    today = datetime.now()
    safe_stem = re.sub(r"[^\w.-]", "_", Path(file.filename or "zaehlerstand").stem)[:80] or "zaehlerstand"
    suffix = Path(file.filename or "").suffix or ".jpg"
    filename = f"{today.strftime('%Y%m%d%H%M%S')}_{safe_stem}{suffix}"
    tmp_path = RECEIPTS_DIR / "_unbestaetigt" / filename
    tmp_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)

    result = extract_receipt_data(tmp_path)

    # Aus dem erkannten Text zusätzlich nach einem plausiblen Zählerstand
    # suchen (reine Zahl, evtl. mit Tausenderpunkt, in der Nähe von "Zähler-
    # stand"/"Stand"/"m³"/"kWh") — Betrag bleibt die primäre OCR-Info, der
    # Zählerstand ist ein zusätzlicher Bonus-Fund, kein Muss.
    suggested_value = None
    if result.get("raw_text"):
        m = re.search(
            r"(?:z[äa]hlerstand|stand|z[äa]hlerstd)[^\d]{0,15}(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,3})?)",
            result["raw_text"], re.IGNORECASE,
        )
        if m:
            try:
                suggested_value = float(m.group(1).replace(".", "").replace(",", "."))
            except ValueError:
                suggested_value = None

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO receipts
           (original_filename, stored_path, file_hash, ocr_text, detected_amount,
            detected_provider, detected_date, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(tmp_path.relative_to(BASE_DIR)), file_hash, result.get("raw_text"),
         result.get("amount"), result.get("provider"),
         result["date"].isoformat() if result.get("date") else None),
    )
    receipt_id = cur.lastrowid
    conn.commit()
    conn.close()

    return {
        "receipt_id": receipt_id,
        "suggested_value": suggested_value,
        "suggested_date": result["date"].isoformat() if result.get("date") else None,
        "detected": result,
        "note": ("Zählerstand erkannt — bitte prüfen." if suggested_value
                  else "Kein Zählerstand automatisch erkannt — bitte manuell eintragen."),
    }


# ---------- Zappi/myenergi: automatisierter Import der Auto-Lademenge ----------
# Trennt "Auto laden" vom normalen Hausverbrauch, indem die täglich von der
# Zappi-Wallbox geladene Energiemenge über die (von myenergi selbst als
# "inoffiziell unterstützt" bezeichnete) myenergi-API abgerufen und als
# synthetischer, kumulativer Zählerstand für den Zählertyp "ev_charging"
# gespeichert wird -- siehe myenergi_client.py für Details zum Verfahren.

class ZappiCredentialsIn(BaseModel):
    hub_serial: str
    hub_password: Optional[str] = None  # leer/None = vorhandenes Passwort behalten
    zappi_serial: str


@router.get("/api/zappi/credentials")
def get_zappi_credentials(session=Depends(auth.require_full_auth)):
    """Gespeicherte Zappi-Zugangsdaten -- das Passwort wird bewusst NICHT
    zurückgegeben (nur ob eines hinterlegt ist), damit es nicht unnötig oft
    im Browser sichtbar wird."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='zappi_credentials'").fetchone()
    conn.close()
    if not row:
        return {"hub_serial": "", "zappi_serial": "", "has_password": False}
    data = json.loads(row["value"])
    return {"hub_serial": data.get("hub_serial", ""), "zappi_serial": data.get("zappi_serial", ""),
            "has_password": bool(data.get("hub_password"))}


@router.put("/api/zappi/credentials")
def put_zappi_credentials(payload: ZappiCredentialsIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = _get_zappi_credentials(conn) or {}
    data = payload.dict()
    if not data.get("hub_password"):
        data["hub_password"] = existing.get("hub_password", "")
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('zappi_credentials', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(data),),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


def _get_zappi_credentials(conn) -> Optional[dict]:
    row = conn.execute("SELECT value FROM settings WHERE key='zappi_credentials'").fetchone()
    return json.loads(row["value"]) if row else None


@router.post("/api/zappi/test-connection")
def test_zappi_connection(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    creds = _get_zappi_credentials(conn)
    conn.close()
    if not creds or not creds.get("hub_password"):
        raise HTTPException(400, "Noch keine Zappi-Zugangsdaten hinterlegt.")
    result = myenergi_client.test_connection(creds["hub_serial"], creds["hub_password"])
    if not result["ok"]:
        raise HTTPException(400, result["error"])
    return result


@router.post("/api/zappi/sync")
def sync_zappi(session=Depends(auth.require_full_auth)):
    """Fehlende Tage seit der letzten Synchronisierung abrufen und als neue,
    kumulative Ablesung(en) für den Zählertyp 'ev_charging' speichern --
    reiht sich dadurch nahtlos in die bestehende Zähler-Infrastruktur ein
    (Chart, KPIs, Jahresabrechnung funktionieren automatisch mit)."""
    conn = get_connection()
    creds = _get_zappi_credentials(conn)
    if not creds or not creds.get("hub_password"):
        conn.close()
        raise HTTPException(400, "Noch keine Zappi-Zugangsdaten hinterlegt.")

    existing = conn.execute(
        "SELECT reading_date, value FROM meter_readings WHERE meter_type='ev_charging' "
        "ORDER BY reading_date DESC LIMIT 1"
    ).fetchone()
    if existing:
        start = date.fromisoformat(existing["reading_date"]) + timedelta(days=1)
        running_total = existing["value"]
    else:
        # Erster Sync: 90 Tage zurück als vernünftiger Startpunkt, statt die
        # komplette Zappi-Historie auf einmal abzufragen.
        start = date.today() - timedelta(days=90)
        running_total = 0.0
    end = date.today() - timedelta(days=1)  # heutiger, unvollständiger Tag bewusst ausgelassen

    if start > end:
        conn.close()
        return {"status": "nothing_to_sync", "added_days": 0}

    try:
        daily = myenergi_client.fetch_daily_charge_kwh(
            creds["hub_serial"], creds["hub_password"], creds["zappi_serial"], start, end
        )
    except myenergi_client.MyenergiError as e:
        conn.close()
        raise HTTPException(400, str(e))
    except Exception as e:
        conn.close()
        raise HTTPException(502, f"Verbindung zu myenergi fehlgeschlagen: {e}")

    added = 0
    last_date = existing["reading_date"] if existing else None
    for d in sorted(daily.keys()):
        running_total = round(running_total + daily[d], 3)
        # Kein UNIQUE-Constraint auf (meter_type, reading_date) in dieser
        # Tabelle -- explizit prüfen statt ON CONFLICT, sonst würde ein
        # erneuter Sync für denselben Zeitraum Duplikate anlegen.
        row = conn.execute(
            "SELECT id FROM meter_readings WHERE meter_type='ev_charging' AND reading_date=?", (d,)
        ).fetchone()
        if row:
            conn.execute("UPDATE meter_readings SET value=? WHERE id=?", (running_total, row["id"]))
        else:
            conn.execute(
                """INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note)
                   VALUES ('ev_charging', ?, ?, 0, 'Automatisch von Zappi synchronisiert')""",
                (d, running_total),
            )
        added += 1
        last_date = d
    conn.commit()
    conn.close()
    return {"status": "ok", "added_days": added, "last_date": last_date, "total_kwh": running_total}


# ---------- Sungrow/iSolarCloud: automatisierter PV-Datenabruf ----------
# Nutzt bewusst die inoffizielle Anmeldung mit normalen iSolarCloud-
# Zugangsdaten statt der offiziellen, aber langsamen Entwickler-Registrierung
# -- siehe sungrow_client.py. Die eigentliche Feld-Zuordnung für die
# automatische Monatsauswertung ist bewusst noch nicht gebaut, siehe
# Vorschau-Endpunkt unten.

class SungrowCredentialsIn(BaseModel):
    email: str
    password: Optional[str] = None  # leer/None = vorhandenes Passwort behalten
    ps_id: Optional[str] = ""  # leer = automatisch erkennen, sofern nur eine Anlage im Konto existiert


@router.get("/api/sungrow/credentials")
def get_sungrow_credentials(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='sungrow_credentials'").fetchone()
    conn.close()
    if not row:
        return {"email": "", "ps_id": "", "has_password": False}
    data = json.loads(row["value"])
    return {"email": data.get("email", ""), "ps_id": data.get("ps_id", ""),
            "has_password": bool(data.get("password"))}


@router.put("/api/sungrow/credentials")
def put_sungrow_credentials(payload: SungrowCredentialsIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = _get_sungrow_credentials(conn) or {}
    data = payload.dict()
    if not data.get("password"):
        data["password"] = existing.get("password", "")
    if not data.get("ps_id"):
        data["ps_id"] = existing.get("ps_id", "")
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('sungrow_credentials', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(data),),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


def _get_sungrow_credentials(conn) -> Optional[dict]:
    row = conn.execute("SELECT value FROM settings WHERE key='sungrow_credentials'").fetchone()
    return json.loads(row["value"]) if row else None


@router.post("/api/sungrow/test-connection")
async def test_sungrow_connection(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    creds = _get_sungrow_credentials(conn)
    if not creds or not creds.get("password"):
        conn.close()
        raise HTTPException(400, "Noch keine iSolarCloud-Zugangsdaten hinterlegt.")
    result = await sungrow_client.test_connection(creds["email"], creds["password"])
    if not result["ok"]:
        conn.close()
        raise HTTPException(400, result["error"])
    # Bei genau einer Anlage im Konto die ps_id automatisch übernehmen, statt
    # sie den Nutzer mühsam in der iSolarCloud-Oberfläche suchen zu lassen --
    # nur wenn noch keine (oder eine andere) hinterlegt ist, damit ein
    # bewusst manuell gesetzter Wert nicht überschrieben wird. Die
    # tatsächlich erfolgreiche Server-Region wird IMMER übernommen (nicht
    # nur wenn sie fehlt), da sie sich sonst nie korrigieren ließe, falls
    # ursprünglich fälschlich "Europe" angenommen wurde.
    auto_ps_id = result.get("auto_ps_id")
    region_changed = result.get("region") and creds.get("region") != result["region"]
    if (auto_ps_id and creds.get("ps_id") != auto_ps_id) or region_changed:
        if auto_ps_id and creds.get("ps_id") != auto_ps_id:
            creds["ps_id"] = auto_ps_id
            result["ps_id_saved"] = auto_ps_id
        if region_changed:
            creds["region"] = result["region"]
        conn.execute(
            "INSERT INTO settings (key, value) VALUES ('sungrow_credentials', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(creds),),
        )
        conn.commit()
    conn.close()
    return result


@router.post("/api/sungrow/preview-daily")
async def preview_sungrow_daily(day: Optional[str] = None, session=Depends(auth.require_full_auth)):
    """Zeigt die ROHEN Tagesdaten EINES Tages an -- bewusst noch keine
    automatische Auswertung/Speicherung, siehe Modul-Kommentar in
    sungrow_client.py. Dient dazu, die echten Feldnamen einmal zu
    verifizieren, bevor eine automatische Monatsauswertung darauf gebaut
    wird."""
    conn = get_connection()
    creds = _get_sungrow_credentials(conn)
    conn.close()
    if not creds or not creds.get("password"):
        raise HTTPException(400, "Noch keine iSolarCloud-Zugangsdaten hinterlegt.")
    if not creds.get("ps_id"):
        raise HTTPException(
            400,
            "Keine Anlagen-ID hinterlegt — bitte zuerst \"Verbindung testen\" ausführen "
            "(erkennt die Anlage automatisch, sofern nur eine im Konto existiert).",
        )
    target_day = date.fromisoformat(day) if day else date.today() - timedelta(days=1)
    try:
        raw = await sungrow_client.fetch_raw_daily_preview(
            creds["email"], creds["password"], creds["ps_id"], target_day,
            region=creds.get("region", "Europe"),
        )
    except Exception as e:
        raise HTTPException(502, f"Abruf fehlgeschlagen: {e}")
    return {"date": target_day.isoformat(), "raw": raw}


# ---------- Sungrow OAuth (empfohlener Weg, siehe sungrow_client.py) ----------

class SungrowOAuthCredentialsIn(BaseModel):
    appkey: str
    access_key: Optional[str] = None  # leer = vorhandenen Wert behalten (wie beim Passwort-Feld sonst)
    app_id: str
    region: str = "Europe"


def _get_sungrow_oauth_credentials(conn) -> Optional[dict]:
    row = conn.execute("SELECT value FROM settings WHERE key='sungrow_oauth_credentials'").fetchone()
    return json.loads(row["value"]) if row else None


def _save_sungrow_oauth_credentials(conn, data: dict):
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('sungrow_oauth_credentials', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(data),),
    )
    conn.commit()


@router.get("/api/sungrow/oauth/credentials")
def get_sungrow_oauth_credentials(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    creds = _get_sungrow_oauth_credentials(conn)
    conn.close()
    if not creds:
        return {"appkey": "", "app_id": "", "region": "Europe", "ps_id": "", "has_access_key": False, "connected": False}
    return {
        "appkey": creds.get("appkey", ""), "app_id": creds.get("app_id", ""),
        "region": creds.get("region", "Europe"), "ps_id": creds.get("ps_id", ""),
        "has_access_key": bool(creds.get("access_key")),
        "connected": bool(creds.get("tokens")),
    }


@router.put("/api/sungrow/oauth/credentials")
def put_sungrow_oauth_credentials(payload: SungrowOAuthCredentialsIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = _get_sungrow_oauth_credentials(conn) or {}
    data = payload.dict()
    if not data.get("access_key"):
        data["access_key"] = existing.get("access_key", "")
    data["ps_id"] = existing.get("ps_id", "")
    data["tokens"] = existing.get("tokens")
    _save_sungrow_oauth_credentials(conn, data)
    conn.close()
    return {"status": "saved"}


@router.get("/api/sungrow/oauth/authorize-url")
async def get_sungrow_oauth_authorize_url(redirect_uri: str, session=Depends(auth.require_full_auth)):
    """Baut die URL, zu der das Frontend den Browser weiterleiten soll --
    redirect_uri kommt vom Frontend (window.location.origin), da nur der
    Browser selbst weiß, unter welcher Adresse die App gerade erreichbar
    ist (localhost, Tailscale-Adresse usw.); dieselbe Adresse muss im
    Sungrow-Entwicklerportal als erlaubte Redirect-URI der eigenen App
    hinterlegt sein."""
    conn = get_connection()
    creds = _get_sungrow_oauth_credentials(conn)
    conn.close()
    if not creds or not creds.get("access_key"):
        raise HTTPException(400, "Noch keine App-Zugangsdaten (App Key/Secret/ID) hinterlegt.")
    url = await sungrow_client.oauth_authorize_url(
        creds["appkey"], creds["access_key"], creds["app_id"], creds.get("region", "Europe"), redirect_uri,
    )
    return {"url": url}


@router.get("/api/sungrow/oauth/callback", response_class=HTMLResponse)
async def sungrow_oauth_callback(request: Request, code: Optional[str] = None,
                                  error: Optional[str] = None, session=Depends(auth.require_full_auth)):
    """Sprungziel, zu dem Sungrow den Browser nach der Anmeldung des
    Nutzers zurückschickt. Tauscht den Code gegen Token, speichert sie,
    und leitet direkt zurück in die App -- diese Seite selbst wird vom
    Nutzer praktisch nie bewusst wahrgenommen, nur kurz durchlaufen."""
    redirect_uri = str(request.url).split("?")[0]
    if error or not code:
        return "<script>alert('Anmeldung bei iSolarCloud abgebrochen oder fehlgeschlagen.');location.href='/';</script>"
    conn = get_connection()
    creds = _get_sungrow_oauth_credentials(conn)
    if not creds or not creds.get("access_key"):
        conn.close()
        return "<script>alert('Keine App-Zugangsdaten hinterlegt.');location.href='/';</script>"
    try:
        tokens = await sungrow_client.oauth_exchange_code(
            creds["appkey"], creds["access_key"], creds["app_id"], creds.get("region", "Europe"),
            code, redirect_uri,
        )
    except Exception as e:
        conn.close()
        return f"<script>alert('Anmeldung fehlgeschlagen: {str(e)!r}');location.href='/';</script>"
    creds["tokens"] = tokens
    _save_sungrow_oauth_credentials(conn, creds)
    conn.close()
    return "<script>location.href='/';</script>"


@router.post("/api/sungrow/oauth/test-connection")
async def test_sungrow_oauth_connection(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    creds = _get_sungrow_oauth_credentials(conn)
    if not creds or not creds.get("tokens"):
        conn.close()
        raise HTTPException(400, "Noch nicht bei iSolarCloud angemeldet — bitte zuerst \"Mit iSolarCloud verbinden\".")
    result = await sungrow_client.oauth_test_connection(
        creds["appkey"], creds["access_key"], creds["app_id"], creds.get("region", "Europe"), creds["tokens"],
    )
    if not result["ok"]:
        conn.close()
        raise HTTPException(400, result["error"])
    # Token koennen sich beim Testen erneuert haben (Access-Token laeuft
    # nach kurzer Zeit ab) -- IMMER aktualisiert speichern, sonst wuerde
    # der naechste Aufruf mit dem inzwischen ungueltigen alten Token
    # scheitern.
    creds["tokens"] = result["tokens"]
    auto_ps_id = result.get("auto_ps_id")
    if auto_ps_id and creds.get("ps_id") != auto_ps_id:
        creds["ps_id"] = auto_ps_id
        result["ps_id_saved"] = auto_ps_id
    _save_sungrow_oauth_credentials(conn, creds)
    conn.close()
    del result["tokens"]  # nicht ans Frontend durchreichen
    return result


@router.post("/api/sungrow/oauth/disconnect")
def disconnect_sungrow_oauth(session=Depends(auth.require_full_auth)):
    """Trennt die Verbindung (löscht nur die Token, nicht App Key/Secret/
    ID), damit sich der Nutzer bei Bedarf einfach erneut über "Mit
    iSolarCloud verbinden" anmelden kann."""
    conn = get_connection()
    creds = _get_sungrow_oauth_credentials(conn)
    if creds:
        creds["tokens"] = None
        _save_sungrow_oauth_credentials(conn, creds)
    conn.close()
    return {"status": "disconnected"}


@router.post("/api/sungrow/oauth/preview-daily")
async def preview_sungrow_oauth_daily(day: Optional[str] = None, session=Depends(auth.require_full_auth)):
    """Wie /api/sungrow/preview-daily, aber über den OAuth-Weg -- liefert
    dabei bereits LESBARE Feldnamen (code/name/unit je Messpunkt) statt
    der rohen, unbekannten Kürzel des alten UserAuth-Wegs."""
    conn = get_connection()
    creds = _get_sungrow_oauth_credentials(conn)
    if not creds or not creds.get("tokens"):
        conn.close()
        raise HTTPException(400, "Noch nicht bei iSolarCloud angemeldet — bitte zuerst \"Mit iSolarCloud verbinden\".")
    if not creds.get("ps_id"):
        conn.close()
        raise HTTPException(
            400,
            "Keine Anlagen-ID hinterlegt — bitte zuerst \"Verbindung testen\" ausführen "
            "(erkennt die Anlage automatisch, sofern nur eine im Konto existiert).",
        )
    target_day = date.fromisoformat(day) if day else date.today() - timedelta(days=1)
    try:
        data, updated_tokens = await sungrow_client.oauth_fetch_daily_data(
            creds["appkey"], creds["access_key"], creds["app_id"], creds.get("region", "Europe"),
            creds["tokens"], creds["ps_id"], target_day,
        )
    except Exception as e:
        conn.close()
        raise HTTPException(502, f"Abruf fehlgeschlagen: {e}")
    creds["tokens"] = updated_tokens
    _save_sungrow_oauth_credentials(conn, creds)
    conn.close()
    return {"date": target_day.isoformat(), "data": data}
