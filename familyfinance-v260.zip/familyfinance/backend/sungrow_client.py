"""
Client für die iSolarCloud-API von Sungrow.

Zwei Wege werden unterstützt:

1. OAuth (empfohlen, offiziell): Der Nutzer meldet sich direkt bei Sungrow
   an, wir sehen das Passwort nie. Erfordert eine einmalige Registrierung
   einer eigenen "App" im Sungrow-Entwicklerportal
   (https://developer-api.isolarcloud.com), die App Key/App Secret/App-ID
   liefert. Aufwendiger einzurichten, aber zuverlässig und ohne jedes
   Risiko einer Kontosperrung durch unser eigenes Zutun.

2. UserAuth (Altlast, bewusst nicht mehr empfohlen): reine E-Mail/Passwort-
   Anmeldung über die inoffizielle, reverse-engineerte 'UserAuth' der
   Bibliothek. Blieb bestehen für alte, bereits eingerichtete Konten, aber
   nach wiederholten, nicht auf unserer Seite lösbaren Anmeldeproblemen
   (siehe test_connection) nicht mehr der empfohlene Weg für neue
   Einrichtungen.
"""
from datetime import date, datetime, timedelta
from typing import Optional

from pysolarcloud import Server, UserAuth, Auth, AuthError, TokenRefreshError
from pysolarcloud.plants import Plants


class SungrowError(Exception):
    pass


# ---------- OAuth (empfohlener Weg) ----------

def oauth_redirect_uri(base_url: str) -> str:
    """Die Rücksprung-URL, die im Sungrow-Entwicklerportal als erlaubte
    Redirect-URI der eigenen App hinterlegt werden muss -- MUSS exakt mit
    der URL übereinstimmen, unter der die App tatsächlich erreichbar ist
    (z.B. die eigene Tailscale-Adresse), sonst lehnt Sungrow die
    Weiterleitung ab."""
    return f"{base_url.rstrip('/')}/api/sungrow/oauth/callback"


async def oauth_authorize_url(appkey: str, access_key: str, app_id: str, region: str, redirect_uri: str) -> str:
    """URL, zu der der Nutzer weitergeleitet wird, um sich direkt bei
    Sungrow anzumelden -- wir bekommen dabei nie das Passwort zu sehen,
    nur am Ende einen Autorisierungs-Code über die Redirect-URI zurück.

    Bewusst async trotz reiner URL-Berechnung ohne Netzwerkzugriff: Auth()
    legt intern immer eine aiohttp-ClientSession an, die eine laufende
    Event-Loop voraussetzt -- außerhalb eines async-Kontexts (z.B. bei
    einem synchronen Testaufruf) schlägt die reine Konstruktion sonst mit
    "no running event loop" fehl."""
    server = getattr(Server, region, Server.Europe)
    async with Auth(server.value, appkey, access_key, app_id) as auth:
        return auth.auth_url(redirect_uri)


async def oauth_exchange_code(appkey: str, access_key: str, app_id: str, region: str,
                               code: str, redirect_uri: str) -> dict:
    """Tauscht den von Sungrow gelieferten Autorisierungs-Code gegen
    Access-/Refresh-Token, die dauerhaft gespeichert werden (der
    Refresh-Token, bis der Nutzer die Verbindung trennt oder er von
    Sungrow selbst ungültig gemacht wird)."""
    server = getattr(Server, region, Server.Europe)
    async with Auth(server.value, appkey, access_key, app_id) as auth:
        await auth.async_authorize(code, redirect_uri)
        return auth.tokens  # {access_token, refresh_token, expires_at}


async def oauth_test_connection(appkey: str, access_key: str, app_id: str, region: str, tokens: dict) -> dict:
    """Verbindung testen + Anlagen-Liste holen -- liefert dabei auch die
    (ggf. zwischenzeitlich erneuerten) Token zurück, damit der Aufrufer sie
    aktualisiert speichern kann; der Access-Token läuft nach kurzer Zeit ab
    und wird automatisch per Refresh-Token erneuert."""
    server = getattr(Server, region, Server.Europe)
    async with Auth(server.value, appkey, access_key, app_id) as auth:
        auth.tokens = dict(tokens)
        try:
            plants_client = Plants(auth)
            plants = await plants_client.async_get_plants()
            result = {"ok": True, "plants": plants, "tokens": auth.tokens}
            if len(plants) == 1 and plants[0].get("ps_id"):
                result["auto_ps_id"] = str(plants[0]["ps_id"])
            return result
        except TokenRefreshError:
            return {"ok": False, "error": "Verbindung abgelaufen — bitte erneut über \"Mit iSolarCloud verbinden\" anmelden.", "reauth_required": True}
        except AuthError as e:
            return {"ok": False, "error": f"Anmeldung fehlgeschlagen: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"Verbindung fehlgeschlagen: {e}"}


async def oauth_fetch_daily_data(appkey: str, access_key: str, app_id: str, region: str,
                                  tokens: dict, ps_id: str, day: date) -> tuple[dict, dict]:
    """Historische Tagesdaten EINER Anlage über die offizielle API --
    anders als beim alten UserAuth-Weg mit LESBAREN Feldnamen (code/name/
    unit je Messpunkt), keine rohen, unbekannten Kürzel mehr. Gibt die
    Daten UND die (ggf. erneuerten) Token zurück."""
    server = getattr(Server, region, Server.Europe)
    async with Auth(server.value, appkey, access_key, app_id) as auth:
        auth.tokens = dict(tokens)
        plants_client = Plants(auth)
        start = datetime.combine(day, datetime.min.time())
        end = start + timedelta(days=1)
        data = await plants_client.async_get_historical_data(str(ps_id), start, end, interval=timedelta(hours=1))
        return data, auth.tokens


# ---------- UserAuth (Altlast, nicht mehr empfohlen für neue Einrichtungen) ----------

async def test_connection(email: str, password: str) -> dict:
    """Nur Anmeldung + Anlagen-Liste prüfen, ohne Daten zu importieren. Bei
    genau einer Anlage im Konto wird deren ps_id gleich mitgeliefert, damit
    sie nicht mühsam von Hand herausgesucht werden muss.

    Nutzt bewusst NUR "Europe", nicht mehr mehrere Regionen nacheinander:
    ein früherer Versuch, bei Fehlschlag alle bekannten Regionen
    durchzuprobieren, erwies sich als Fehler -- jeder Versuch zählt
    offenbar gegen denselben Konto-weiten Fehlversuchs-Zähler, ein
    Fehlschlag auf der richtigen Region hätte also unnötig mehrfach
    Versuche verbraucht (und damit das Sperrrisiko erhöht statt zu
    helfen), statt das eigentliche Problem zu lösen.

    WICHTIGER HINWEIS: Bei einem konkreten Konto scheiterte dieser Weg
    wiederholt mit einer "falsches Passwort"-Ablehnung durch Sungrows
    Server, obwohl Server-Region UND Passwort nachweislich korrekt waren
    (Anmeldung über die offizielle iSolarCloud-App/-Website funktionierte
    mit denselben Daten einwandfrei). Das deutet auf einen Fehler in der
    (von der Bibliothek selbst als "unofficial and experimental"
    bezeichneten) Verschlüsselungs-/Übertragungslogik dieser
    reverse-engineerten Anmeldung hin, der sich ohne Zugriff auf echte
    Sungrow-Server nicht von hier aus beheben lässt -- deshalb der
    OAuth-Weg oben als empfohlene Alternative für neue Einrichtungen."""
    try:
        async with UserAuth(Server.Europe, email, password) as auth:
            plants = await auth.async_get_plants()
            result = {"ok": True, "plants": plants, "region": "Europe"}
            if len(plants) == 1 and plants[0].get("ps_id"):
                result["auto_ps_id"] = str(plants[0]["ps_id"])
            return result
    except AuthError as e:
        return {"ok": False, "error": f"Anmeldung fehlgeschlagen: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"Verbindung fehlgeschlagen: {e}"}


async def fetch_raw_daily_preview(email: str, password: str, ps_id: str, day: date, region: str = "Europe") -> dict:
    """Rohe Tagesdaten EINES Tages für EINE Anlage -- zur Ansicht/Diagnose,
    damit die Feldnamen echt verifiziert werden können, bevor eine
    automatische Auswertung darauf aufbaut. Nutzt die beim Verbindungstest
    tatsächlich erfolgreiche Server-Region (siehe test_connection), nicht
    blind "Europe" -- sonst würde derselbe Regions-Fehler hier erneut
    auftreten, selbst wenn die Zugangsdaten korrekt sind."""
    server = getattr(Server, region, Server.Europe)
    async with UserAuth(server, email, password) as auth:
        raw = await auth.async_get_plant_detail_daily(ps_id, day.strftime("%Y%m%d"))
        return raw
