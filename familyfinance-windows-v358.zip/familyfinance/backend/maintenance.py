"""
Abhängigkeits-Wartung: prüft installierte Python-Pakete gegen requirements.txt
auf verfügbare Updates und kann sie bei Bedarf installieren.

Wird von zwei Stellen genutzt:
1. app.py (In-App-Button unter Einstellungen → Wartung)
2. check_dependencies.py (eigenständiges Skript, läuft wöchentlich per launchd
   auch dann, wenn die App gerade nicht offen ist — Ergebnis landet in der
   settings-Tabelle, die App zeigt es beim nächsten Öffnen einfach an)

Bewusst nur die feste Paketliste aus requirements.txt — kein beliebiger
Shell-Befehl von außen ausführbar.
"""
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent.parent
REQUIREMENTS_PATH = Path(__file__).resolve().parent / "requirements.txt"

# ---------- App-Selbst-Update ----------
# Bewusst ein SEPARATES, oeffentliches Repository nur fuer Versions-
# Veroeffentlichungen (kein Quellcode, keine privaten Finanzdaten) --
# damit kein GitHub-Zugangstoken in einer an Freunde weitergegebenen App
# hinterlegt werden muss. Fest einprogrammiert (nicht vom Nutzer
# aenderbar), damit die App niemals ein Update von einer beliebigen,
# potenziell manipulierten Quelle akzeptiert.
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Dane03/familyfinance-releases/main/latest.json"


def _current_app_version() -> str:
    """Liest die aktuell laufende Version aus dem APP_BUILD-String in
    app.js — dieselbe Versionsnummer, die auch oben in der App angezeigt
    wird, keine zweite, separat zu pflegende Quelle."""
    app_js = BASE_DIR / "frontend" / "app.js"
    if not app_js.exists():
        return "v0"
    match = re.search(r"·\s*(v\d+)\"", app_js.read_text(encoding="utf-8"))
    return match.group(1) if match else "v0"


def _version_number(v: str) -> int:
    m = re.search(r"\d+", v or "")
    return int(m.group()) if m else 0


def check_app_update() -> dict:
    """Fragt das oeffentliche Manifest ab und vergleicht mit der laufenden
    Version. Netzwerkfehler werden abgefangen -- kein Update-Check darf
    die App selbst zum Absturz bringen. Das Manifest enthaelt getrennte
    Downloads je Plattform (Mac/Windows) unter demselben Versions-Tag."""
    import urllib.request
    import urllib.error

    current = _current_app_version()
    try:
        req = urllib.request.Request(UPDATE_MANIFEST_URL, headers={"Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            manifest = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as e:
        return {"current_version": current, "error": f"Update-Server nicht erreichbar: {e}"}

    latest = manifest.get("version", current)
    platform_key = "windows" if platform.system() == "Windows" else "mac"
    platform_entry = (manifest.get("platforms") or {}).get(platform_key, {})
    return {
        "current_version": current,
        "latest_version": latest,
        "update_available": _version_number(latest) > _version_number(current),
        "download_url": platform_entry.get("download_url"),
        "sha256": platform_entry.get("sha256"),
        "notes": manifest.get("notes"),
    }


_apply_lock = threading.Lock()
# Obergrenze für den Update-Download (ein Release-ZIP hat ~1,3 MB). Schützt vor
# unbegrenztem Speicherverbrauch, falls eine Weiterleitung auf etwas Riesiges zeigt.
MAX_UPDATE_DOWNLOAD_BYTES = 200 * 1024 * 1024


def apply_app_update(download_url: str, expected_sha256: str) -> dict:
    """Wie _apply_app_update_unlocked, aber nie zweimal gleichzeitig: Der Endpunkt
    ist bewusst ohne Login erreichbar -- parallele Anfragen würden sonst gleichzeitig
    dieselben Dateien überschreiben und mehrfach neu starten."""
    if not _apply_lock.acquire(blocking=False):
        return {"status": "error", "error": "Ein Update läuft bereits -- bitte einen Moment warten."}
    try:
        return _apply_app_update_unlocked(download_url, expected_sha256)
    finally:
        _apply_lock.release()


def _apply_app_update_unlocked(download_url: str, expected_sha256: str) -> dict:
    """Laedt das Release-ZIP herunter, prueft die Pruefsumme, entpackt es
    und spielt es ein -- reines Python statt rsync (funktioniert dadurch
    identisch unter macOS UND Windows). Nach erfolgreichem Einspielen
    startet sich der Dienst selbst neu (restart_service ist bereits
    plattformsicher)."""
    import urllib.request
    import hashlib
    import zipfile
    import shutil
    import tempfile

    # Nur von der fest einprogrammierten, oeffentlichen Release-Quelle --
    # verhindert, dass ein manipuliertes Manifest die App auf eine
    # beliebige andere Download-Adresse umlenkt.
    allowed_hosts = ("github.com", "raw.githubusercontent.com", "release-assets.githubusercontent.com",
                      "objects.githubusercontent.com", "codeload.github.com")
    from urllib.parse import urlparse
    parsed = urlparse(download_url)
    host = parsed.hostname or ""
    if parsed.scheme != "https" or not any(host == h or host.endswith("." + h) for h in allowed_hosts):
        return {"status": "error", "error": f"Download-Adresse nicht vertrauenswürdig: {host}"}
    # Nicht ganz GitHub, sondern nur das eigene Release-Repository.
    # "../" im Pfad (auch %-kodiert, auch mehrfach) würde die Präfix-Prüfung
    # aushebeln: /Dane03/familyfinance-releases/../../Fremder/... zeigt beim
    # Server auf ein fremdes Repository.
    from urllib.parse import unquote
    decoded = parsed.path
    for _ in range(5):
        once = unquote(decoded)
        if once == decoded:
            break
        decoded = once
    if (not parsed.path.startswith("/Dane03/familyfinance-releases/")
            or ".." in decoded.replace("\\", "/").split("/")):
        return {"status": "error", "error": "Download-Adresse gehört nicht zum Release-Repository."}

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        zip_path = tmp_path / "update.zip"
        try:
            with urllib.request.urlopen(download_url, timeout=60) as resp:
                data = resp.read(MAX_UPDATE_DOWNLOAD_BYTES + 1)
        except Exception as e:
            return {"status": "error", "error": f"Download fehlgeschlagen: {e}"}
        if len(data) > MAX_UPDATE_DOWNLOAD_BYTES:
            return {"status": "error", "error": "Download ist unerwartet groß -- Update wurde NICHT eingespielt."}
        zip_path.write_bytes(data)

        actual_hash = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        # Eine fehlende Prüfsumme darf die Prüfung NICHT überspringen -- sonst
        # könnte über den (bewusst ohne Login erreichbaren) Update-Endpunkt ein
        # beliebiges ZIP von einer GitHub-Adresse ungeprüft eingespielt werden.
        if not expected_sha256:
            return {"status": "error", "error": "Keine Prüfsumme angegeben -- Update wurde aus Sicherheitsgründen NICHT eingespielt."}
        if actual_hash.lower() != expected_sha256.lower():
            return {"status": "error", "error": "Prüfsumme stimmt nicht überein -- Update wurde NICHT eingespielt (möglicherweise beschädigter oder manipulierter Download)."}

        extract_dir = tmp_path / "extracted"
        try:
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(extract_dir)
        except zipfile.BadZipFile:
            return {"status": "error", "error": "Heruntergeladene Datei ist kein gültiges ZIP-Archiv."}

        # Das ZIP enthaelt einen Wurzelordner (z.B. "familyfinance/") --
        # dessen Inhalt ist die eigentliche Quelle.
        entries = list(extract_dir.iterdir())
        source_root = entries[0] if len(entries) == 1 and entries[0].is_dir() else extract_dir

        # Gleiche Ausschlussliste wie update.command: niemals echte Daten,
        # Geheimnisse oder plattformspezifische Skripte ueberschreiben.
        skip_names = {"data", "__pycache__", "scripts", "update.command",
                      "start-windows.ps1", "Start-FamilyFinance.bat", ".git"}
        for item in source_root.iterdir():
            if item.name in skip_names:
                continue
            target = BASE_DIR / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)

    restart_service()
    return {"status": "applied"}


def _requirement_specs() -> list:
    """Vollständige Zeilen aus requirements.txt MIT Versionsangaben -- damit exakt
    festgelegte Pakete (easy-fints==1.5.0, fints==5.0.0) beim Upgrade nicht
    versehentlich über ihren Pin hinaus aktualisiert werden."""
    return [l.strip() for l in REQUIREMENTS_PATH.read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.strip().startswith("#")]


def _package_names() -> list:
    """Nur die reinen Paketnamen aus requirements.txt (ohne Kommentarzeilen,
    ohne Extras wie 'uvicorn[standard]' -> 'uvicorn')."""
    names = []
    for line in REQUIREMENTS_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name = re.split(r"[\[<>=!~]", line)[0].strip()
        if name:
            names.append(name)
    return names


def pinned_packages() -> dict:
    """Exakt festgelegte Pakete (z.B. fints==5.0.0) -> {name: version}. Diese
    werden NICHT als Update angeboten: upgrade_all hält den Pin ein, das Update
    würde also nie etwas ändern und der Hinweis bliebe für immer stehen."""
    pinned = {}
    for spec in _requirement_specs():
        m = re.match(r"^([A-Za-z0-9_.\-]+)(\[[^\]]*\])?\s*==\s*([^\s;#]+)", spec)
        if m:
            pinned[m.group(1).lower().replace("_", "-")] = m.group(3)
    return pinned


def check_outdated(timeout: int = 30) -> dict:
    """Fragt pip, welche der in requirements.txt gelisteten Pakete veraltet
    sind. Läuft über 'python -m pip', damit garantiert das pip DIESES
    venvs verwendet wird, nicht versehentlich ein System-pip."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "list", "--outdated", "--format=json"],
            capture_output=True, text=True, timeout=timeout, check=True,
        )
        all_outdated = json.loads(result.stdout)
    except Exception as e:
        return {"checked_at": datetime.now().isoformat(), "error": str(e), "outdated": []}

    our_packages = {n.lower() for n in _package_names()}
    pinned = pinned_packages()
    relevant = [
        {"name": p["name"], "current": p["version"], "latest": p["latest_version"]}
        for p in all_outdated
        if p["name"].lower() in our_packages
        and p["name"].lower().replace("_", "-") not in pinned
    ]
    # Fest gesetzte Pakete nur anbieten, wenn die installierte Version vom Pin
    # abweicht (z.B. nach bewusstem Anheben in requirements.txt) -- dann bringt
    # upgrade_all genau die festgelegte Version.
    from importlib import metadata
    for name, wanted in pinned.items():
        try:
            installed = metadata.version(name)
        except metadata.PackageNotFoundError:
            installed = None
        if installed != wanted:
            relevant.append({"name": name, "current": installed or "fehlt", "latest": wanted})
    return {"checked_at": datetime.now().isoformat(), "error": None, "outdated": relevant}


_outdated_cache = {"at": 0.0, "value": None}
_outdated_lock = threading.Lock()


def check_outdated_cached(max_age: int = 900, force: bool = False) -> dict:
    """check_outdated mit kurzem Zwischenspeicher (Standard 15 Min.). 'pip list
    --outdated' braucht oft 10-20 s und wurde bei JEDEM Seitenaufruf neu
    gestartet (auch ohne Login, siehe /api/public/check-updates) -- bei mehreren
    Geräten liefen so mehrere pip-Prozesse gleichzeitig, und die Anmeldeseite
    (Abbruch nach 3 s) bekam nie eine Antwort. Die Sperre sorgt dafür, dass
    gleichzeitige Anfragen auf dasselbe Ergebnis warten statt je einen
    eigenen pip-Prozess zu starten. Fehlerergebnisse werden nicht gespeichert."""
    with _outdated_lock:
        now = time.monotonic()
        cached = _outdated_cache["value"]
        if not force and cached is not None and now - _outdated_cache["at"] < max_age:
            return cached
        result = check_outdated()
        if result.get("error"):
            _outdated_cache["value"] = None
        else:
            _outdated_cache["value"] = result
            _outdated_cache["at"] = time.monotonic()
        return result


def restart_service(delay_seconds: float = 1.5) -> dict:
    """Startet den eigenen Dienst neu (nach einem Paket-Update nötig, damit
    die neuen Versionen tatsächlich geladen werden). Läuft in einem von
    diesem Prozess losgelösten Hintergrundprozess mit kurzer Verzögerung —
    sonst würde der Neustart-Befehl genau den Prozess killen, der gerade
    noch die HTTP-Antwort auf diesen Aufruf senden will.
    Hinweis: Der Secret Key ist pro Prozess zufällig (nicht dateibasiert),
    d.h. nach dem Neustart ist die aktuelle Sitzung ungültig — das Frontend
    muss den Nutzer nach dem Reload neu anmelden lassen.

    Plattform-Unterschied: Unter macOS läuft die App als launchd-Dienst,
    der sich selbst per launchctl neu starten lässt. Unter Windows gibt es
    kein Äquivalent — dort beendet sich der Prozess stattdessen selbst,
    und das Start-Skript (start.bat/.ps1) erkennt das Beenden und startet
    den Server automatisch neu (Supervisor-Schleife)."""
    if platform.system() == "Windows":
        def _delayed_exit():
            time.sleep(delay_seconds)
            os._exit(0)
        threading.Thread(target=_delayed_exit, daemon=True).start()
        return {"status": "restarting"}

    uid = os.getuid()
    cmd = f"sleep {delay_seconds} && launchctl kickstart -k gui/{uid}/com.familyfinance.server"
    try:
        subprocess.Popen(
            ["/bin/sh", "-c", cmd],
            start_new_session=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        return {"status": "restarting"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


EXTERNAL_BACKUP_KEEP = 30


def external_backup_dir() -> Path:
    """Zweiter Ablageort für Sicherungen AUSSERHALB des App-Ordners (Standard: ~/familyfinance-backups,
    überschreibbar mit FAMILYFINANCE_BACKUP_DIR). Hintergrund 14.10.2026: Der App-Ordner landete versehentlich
    im Papierkorb -- und mit ihm data/backups. Eine Kopie außerhalb überlebt das."""
    custom = os.environ.get("FAMILYFINANCE_BACKUP_DIR", "").strip()
    return Path(custom).expanduser() if custom else Path.home() / "familyfinance-backups"


def _is_real_database(path: Path) -> bool:
    """True nur für eine eingerichtete Datenbank (mindestens ein Zugang). Eine leere oder frisch angelegte
    Datenbank -- etwa wenn der Server nach dem Verschieben des Ordners eine neue anlegt -- wird nicht nach
    außen gesichert, sonst würden solche Sicherungen über die Tage die guten verdrängen."""
    import sqlite3
    try:
        if path.stat().st_size == 0:
            return False
        # as_uri() kodiert Sonderzeichen (#, ?, %, Leerzeichen) korrekt -- ein "#" im Ordnernamen schnitt den Pfad
        # sonst ab, die Datenbank galt als "leer" und die Kopie nach außen unterblieb still. Funktioniert auch unter
        # Windows (file:///C:/...).
        conn = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
        try:
            return conn.execute("SELECT COUNT(*) FROM app_user").fetchone()[0] > 0
        finally:
            conn.close()
    except Exception:
        return False


def _copy_backup_external(backup_path: Path) -> dict:
    """Kopiert eine fertige Sicherung in den externen Ordner. Ein Fehler hier darf die eigentliche
    Sicherung nie scheitern lassen -- er wird nur zurückgemeldet."""
    import shutil
    target_dir = external_backup_dir()
    try:
        target_dir_resolved = target_dir.resolve()
        if target_dir_resolved == BASE_DIR.resolve() or BASE_DIR.resolve() in target_dir_resolved.parents:
            return {"external": "skipped", "external_reason": "Externer Ordner liegt im App-Ordner."}
        if not _is_real_database(backup_path):
            return {"external": "skipped", "external_reason": "Datenbank ist leer/nicht eingerichtet -- nicht nach außen kopiert."}
        target_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(backup_path, target_dir / backup_path.name)
        copies = sorted(target_dir.glob("finance_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in copies[EXTERNAL_BACKUP_KEEP:]:
            old.unlink()
        return {"external": "ok", "external_dir": str(target_dir), "external_total": min(len(copies), EXTERNAL_BACKUP_KEEP)}
    except Exception as e:
        return {"external": "error", "external_reason": str(e)}


# Was aus data/ NICHT in den Belege-Spiegel gehört: Datenbanken (eigene Sicherung), Sicherungen selbst,
# Zwischenablage des Imports, Geheimnisse, macOS-/iCloud-Hilfsdateien.
_MIRROR_SKIP_DIRS = {"backups", "smart_import_staging", "__pycache__"}
_MIRROR_SKIP_SUFFIXES = (".db", ".db-journal", ".db-wal", ".db-shm", ".key", ".icloud", ".tmp")
_MIRROR_SKIP_NAMES = {".DS_Store", ".gitkeep", "secret.key"}


def mirror_documents_external() -> dict:
    """Spiegelt alle Belege/Dokumente aus data/ nach <extern>/belege/ (gleiche Ordnerstruktur, damit
    eine Wiederherstellung einfach "zurückkopieren nach data/" ist). Nur neue oder geänderte Dateien
    werden kopiert (Größe + Änderungszeit), im Spiegel wird NIE gelöscht -- so übersteht auch ein
    versehentlich in der App gelöschter Beleg."""
    import shutil
    src = BASE_DIR / "data"
    dest_root = external_backup_dir() / "belege"
    result = {"documents": "ok", "documents_copied": 0, "documents_total": 0}
    try:
        dest_root.resolve().relative_to(BASE_DIR.resolve())
        return {"documents": "skipped", "documents_reason": "Externer Ordner liegt im App-Ordner."}
    except ValueError:
        pass   # liegt außerhalb -> gut
    if not src.exists():
        return {"documents": "skipped", "documents_reason": "Kein data-Ordner."}
    try:
        for dirpath, dirnames, filenames in os.walk(src):
            rel_dir = Path(dirpath).relative_to(src)
            if rel_dir == Path("."):
                dirnames[:] = [d for d in dirnames if d not in _MIRROR_SKIP_DIRS]
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            for name in filenames:
                if name in _MIRROR_SKIP_NAMES or name.startswith(".") or name.lower().endswith(_MIRROR_SKIP_SUFFIXES):
                    continue
                if rel_dir == Path("."):
                    continue   # lose Dateien direkt in data/ sind Datenbanken/Hilfsdateien, keine Belege
                f = Path(dirpath) / name
                target = dest_root / rel_dir / name
                result["documents_total"] += 1
                try:
                    st = f.stat()
                    if target.exists():
                        tt = target.stat()
                        if tt.st_size == st.st_size and int(tt.st_mtime) >= int(st.st_mtime):
                            continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, target)
                    result["documents_copied"] += 1
                except Exception as e:   # einzelne Datei (z. B. gerade von iCloud ausgelagert) überspringen
                    result.setdefault("documents_errors", []).append(f"{rel_dir / name}: {e}")
        if "documents_errors" in result:
            result["documents"] = "partial"
            result["documents_errors"] = result["documents_errors"][:10]
        return result
    except Exception as e:
        return {"documents": "error", "documents_reason": str(e)}


def external_backup_status() -> dict:
    d = external_backup_dir()
    copies = sorted(d.glob("finance_*.db"), key=lambda p: p.stat().st_mtime, reverse=True) if d.exists() else []
    latest = copies[0] if copies else None
    docs = [p for p in (d / "belege").rglob("*") if p.is_file()] if (d / "belege").exists() else []
    return {
        "dir": str(d), "count": len(copies),
        "latest": datetime.fromtimestamp(latest.stat().st_mtime).isoformat() if latest else None,
        "documents": len(docs),
        "documents_mb": round(sum(p.stat().st_size for p in docs) / 1024 / 1024, 1),
    }


def latest_backup_times() -> dict:
    """Zeitpunkt der jüngsten Datenbank-Sicherung (lokal und außerhalb des App-Ordners) für die Statuszeile.
    Bewusst billig: nur die finance_*.db-Dateien, kein Durchlauf über die gespiegelten Belege."""
    def newest(d: Path):
        try:
            files = list(d.glob("finance_*.db")) if d.exists() else []
            return datetime.fromtimestamp(max(p.stat().st_mtime for p in files)).isoformat() if files else None
        except OSError:
            return None
    return {"local": newest(BASE_DIR / "data" / "backups"), "external": newest(external_backup_dir())}


def backup_database(keep_last: int = 14, mirror_documents: bool = True) -> dict:
    """Sichert die SQLite-Datenbank über SQLites eigene Backup-API — sicher
    auch dann, wenn gerade geschrieben wird (im Gegensatz zu einer simplen
    Datei-Kopie, die einen inkonsistenten Zwischenzustand erwischen könnte).
    Besonders wichtig, seit die App in einem iCloud-synchronisierten Ordner
    liegt: iCloud selbst ist NICHT SQLite-bewusst und könnte theoretisch
    mitten in einem Schreibvorgang synchronisieren. Behält nur die letzten
    N Sicherungen, ältere werden automatisch entfernt."""
    import sqlite3
    db_path = BASE_DIR / "data" / "finance.db"
    if not db_path.exists():
        return {"success": False, "error": "Keine Datenbank gefunden."}

    backup_dir = BASE_DIR / "data" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    backup_path = backup_dir / f"finance_{timestamp}.db"

    try:
        # timeout=30 wie database.py: Beim gleichzeitigen Schreiben kurz warten statt sofort "database is locked"
        source = sqlite3.connect(str(db_path), timeout=30)
        dest = sqlite3.connect(str(backup_path), timeout=30)
        source.backup(dest)
        dest.close()
        source.close()
    except Exception as e:
        return {"success": False, "error": str(e)}

    backups = sorted(backup_dir.glob("finance_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[keep_last:]:
        old.unlink()

    return {
        "success": True, "path": str(backup_path.relative_to(BASE_DIR)),
        "created_at": timestamp, "total_backups": min(len(backups), keep_last),
        **_copy_backup_external(backup_path),
        **(mirror_documents_external() if mirror_documents else {}),
    }


def backup_if_due(max_age_hours: float = 20) -> Optional[dict]:
    """Sichert, wenn die jüngste Sicherung älter als max_age_hours ist (oder keine existiert).
    Für den Hintergrund-Thread im Server: Der separate launchd-Sicherungsjob lief nachweislich nicht
    täglich (Okt. 2026: Sicherungen nur bei Neustarts) -- so sichert der Server selbst, auf Mac und Windows."""
    backup_dir = BASE_DIR / "data" / "backups"
    newest = max((p.stat().st_mtime for p in backup_dir.glob("finance_*.db")), default=0) if backup_dir.exists() else 0
    if newest and (time.time() - newest) < max_age_hours * 3600:
        return None
    result = backup_database()
    try:
        from vermoegen_routes import save_networth_snapshot
        save_networth_snapshot()   # wie der Nachtjob: Vermögens-Momentaufnahme gleich mit
    except Exception as e:
        print(f"Vermögens-Momentaufnahme fehlgeschlagen: {e}")
    print(f"Tägliche Sicherung: {'ok' if result.get('success') else result.get('error')}")
    return result


def list_backups() -> list:
    backup_dir = BASE_DIR / "data" / "backups"
    if not backup_dir.exists():
        return []
    backups = sorted(backup_dir.glob("finance_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    return [
        {"filename": p.name, "size_kb": round(p.stat().st_size / 1024, 1),
         "created_at": datetime.fromtimestamp(p.stat().st_mtime).isoformat()}
        for p in backups
    ]


def upgrade_all(timeout: int = 300) -> dict:
    """Aktualisiert alle in requirements.txt gelisteten Pakete auf die
    jeweils neueste Version. Bewusst die GANZE, feste Liste statt einzelner
    vom Aufrufer übergebener Namen — verhindert, dass diese Funktion für
    beliebige Paket-Installationen zweckentfremdet werden könnte."""
    names = _requirement_specs()
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--break-system-packages", *names],
            capture_output=True, text=True, timeout=timeout,
        )
        return {
            "success": result.returncode == 0,
            "output": (result.stdout or "") + (result.stderr or ""),
        }
    except Exception as e:
        return {"success": False, "output": str(e)}
