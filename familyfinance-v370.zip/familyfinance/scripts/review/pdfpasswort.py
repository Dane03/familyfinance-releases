"""Passwortgeschützte PDF im eigenen Betrachter öffnen (v367). Mit Browser.
    cd kopie/backend && python3 ../scripts/review/pdfpasswort.py
Exit-Code 0 = alles grün. Startet einen Server auf Port 8420 (Kopie, eigene Testdaten).

Anlass (29.10.2026): Jede geschützte Gehaltsabrechnung zeigte nach dem Passwort "Unexpected server response (0)
while retrieving PDF blob:…". Der Betrachter gab die entschlüsselte PDF als blob:-Adresse an PDF.js; PDF.js lädt
die per fetch, und das verbietet die Content-Security-Policy (connect-src 'self'). Seit v367 bekommt PDF.js die
Bytes direkt.

Fälle: falsches Passwort -> Fehlermeldung, kein Absturz; richtiges Passwort -> Seite(n) als Canvas gezeichnet,
keine Fehlermeldung, keine CSP-Verletzung in der Konsole.
Mutationstest: auf v366 erscheint "Unexpected server response".
"""
import sys
import threading
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
sys.path.insert(0, ".")

import database  # noqa: E402

database.init_db()
from pypdf import PdfWriter  # noqa: E402

BASE = database.BASE_DIR
target = BASE / "data" / "Gehalt" / "Test" / "geheim.pdf"
target.parent.mkdir(parents=True, exist_ok=True)
w = PdfWriter()
w.add_blank_page(width=300, height=400)
w.add_blank_page(width=300, height=400)
w.encrypt("geheim123")
with open(target, "wb") as fh:
    w.write(fh)

c = database.get_connection()
try:
    c.execute("DELETE FROM payslips WHERE original_filename='geheim.pdf'")
    cur = c.execute("INSERT INTO payslips (original_filename, stored_path, review_needed) VALUES ('geheim.pdf', ?, 0)",
                    (str(target.relative_to(BASE)),))
    slip_id = cur.lastrowid
    c.commit()
finally:
    c.close()

import auth  # noqa: E402
import app as appmod  # noqa: E402
import uvicorn  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

TestClient(appmod.app).post("/api/auth/setup", json={"username": "tester", "password": "testtest123"})
srv = uvicorn.Server(uvicorn.Config(appmod.app, host="127.0.0.1", port=8420, log_level="error"))
threading.Thread(target=srv.run, daemon=True).start()
for _ in range(50):
    if srv.started:
        break
    time.sleep(0.2)

from playwright.sync_api import sync_playwright  # noqa: E402

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


tok = auth._serializer.dumps({"stage": "full", "iat": "x"})
url = f"http://localhost:8420/api/documents/pdf-viewer?url=/api/payslips/{slip_id}/file&title=geheim.pdf"
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
    ctx.add_cookies([{"name": "ffz_session", "value": tok, "url": "http://localhost:8420"}])
    pg = ctx.new_page()
    console, errs = [], []
    pg.on("console", lambda m: console.append(m.text))
    pg.on("pageerror", lambda e: errs.append(str(e)[:120]))
    pg.goto(url)
    pg.wait_for_selector("#pw-input", timeout=10000)

    pg.fill("#pw-input", "falsch")
    pg.click("#pw-form .submit")
    msg = ""
    for _ in range(50):
        msg = pg.evaluate("document.getElementById('pw-error').textContent")
        if msg:
            break
        time.sleep(0.1)
    check("falsches Passwort -> Meldung", bool(msg), True)
    check("Passwortfeld bleibt sichtbar", pg.is_visible("#pw-input"), True)

    pg.fill("#pw-input", "geheim123")
    pg.click("#pw-form .submit")
    canvases, text = 0, ""
    for _ in range(100):
        canvases = pg.evaluate("document.querySelectorAll('#pdf-container canvas').length")
        text = pg.evaluate("document.getElementById('pdf-container').innerText")
        if canvases >= 2 or "nicht angezeigt" in text:
            break
        time.sleep(0.1)
    check("richtiges Passwort -> beide Seiten gezeichnet", canvases, 2)
    check("keine Fehlermeldung", "nicht angezeigt" in text, False)
    check("keine CSP-Verletzung", [m for m in console if "Content Security Policy" in m or "Refused to connect" in m], [])
    check("keine JS-Fehler", errs, [])
    b.close()
srv.should_exit = True

print()
if FAILS:
    print(f"✗ PDF mit Passwort: {len(FAILS)} Fehler: {', '.join(FAILS)}")
    sys.exit(1)
print("✓ PDF mit Passwort: alle Fälle stimmen")
