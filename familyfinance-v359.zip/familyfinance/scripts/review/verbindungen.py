"""Datenbank-Verbindungen werden auch bei Fehlern sauber beendet (v359, `database.db()`). Ohne Server, Sekunden.
    cd kopie/backend && python3 ../scripts/review/verbindungen.py
Exit-Code 0 = alles grün.

Anlass: Viele Handler öffneten Verbindungen ohne try/finally. Scheitert ein Handler NACH einer Schreibaktion, blieb die
Verbindung offen und hielt die Datei gesperrt (kein WAL, Projektordner in iCloud) -- andere Anfragen, Bank-Abruf und
Sicherung warteten bis zu 30 s und meldeten dann "database is locked". Wie lange die Verbindung lebt, hängt davon ab,
wer den Traceback festhält (Fehlerlog, Monitoring); der Test hält ihn bewusst fest wie ein Fehlerlog.

Fälle:
 1) db(): Erfolg -> commit + geschlossen; HTTPException und beliebiger Fehler -> rollback + geschlossen;
    real=True nimmt im Demo-Modus trotzdem die echte DB.
 2) Je umgestelltem Schreib-Endpunkt (Vermögen anlegen/ändern/archivieren, Gehaltsabrechnung übernehmen/rückgängig,
    Bank-Sammelzuordnung): eine Hilfsfunktion schreibt und wirft dann. Erwartet: 500, danach ist die Datei SOFORT
    wieder beschreibbar (fremde Verbindung, 1 s Wartezeit) und die halbe Schreibaktion ist nicht gespeichert.
 3) Ungültiger Finanzierungsvertrag beim Vermögen -> 400 (vorher Fremdschlüssel-Fehler mitten im Schreiben = 500),
    bestehende Verknüpfungen bleiben erhalten.

Mutationstest: auf v358 (ohne db()) schlagen Fall 2 und 3 an.
"""
import contextlib
import io
import sqlite3
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))

TMP = Path(tempfile.mkdtemp(prefix="ff_verb_"))
(TMP / "data").mkdir()

import database  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()

import auth  # noqa: E402
import bank_routes as br  # noqa: E402
import receipts_routes as rr  # noqa: E402
import vermoegen_routes as vr  # noqa: E402
from fastapi import FastAPI, HTTPException  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

rr.BASE_DIR = TMP
rr.PAYSLIPS_DIR = TMP / "data" / "Gehalt"

api = FastAPI()
for r in (vr.router, rr.router, br.router):
    api.include_router(r)
api.dependency_overrides[auth.require_full_auth] = lambda: {"stage": "full"}

KEPT = []   # hält Fehler samt Traceback fest -- wie ein Fehlerlog/Monitoring


@api.exception_handler(Exception)
async def _keep(request, exc):
    KEPT.append(exc)
    return JSONResponse({"detail": "Serverfehler"}, status_code=500)


cl = TestClient(api, raise_server_exceptions=False)


def raw():
    c = sqlite3.connect(database.DB_PATH, timeout=1)
    c.row_factory = sqlite3.Row
    return c


def writable():
    """Kann eine FREMDE Verbindung sofort schreiben? (1 s statt 30 s Wartezeit)"""
    try:
        c = raw()
        c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('verbindungen_probe', 'x')")
        c.commit()
        c.close()
        return True
    except sqlite3.OperationalError as e:
        return f"gesperrt ({e})"


def one(sql, args=()):
    c = raw()
    v = c.execute(sql, args).fetchone()
    c.close()
    return v[0] if v else None


# --- Testdaten ---
c = raw()
c.execute("INSERT INTO contracts (id, label, amount, source) VALUES (1, 'Darlehen', 900, 'manuell')")
c.execute("INSERT INTO assets (id, type, label) VALUES (1, 'immobilie', 'Haus')")
c.execute("INSERT INTO asset_financing_links (asset_id, contract_id) VALUES (1, 1)")
c.execute("INSERT INTO income (id, label, amount, source) VALUES (1, 'Gehalt', 3000, 'manuell')")
(TMP / "data" / "Gehalt").mkdir(parents=True)
(TMP / "data" / "Gehalt" / "abr.pdf").write_bytes(b"%PDF-1.4 test")
c.execute("INSERT INTO payslips (id, original_filename, stored_path, detected_net_amount, review_needed) "
          "VALUES (1, 'abr.pdf', 'data/Gehalt/abr.pdf', 3123.45, 1)")
c.commit()
c.close()

# --- 1) db() selbst ---
print("— 1) database.db()")
with database.db() as conn:
    conn.execute("UPDATE income SET label='Gehalt A' WHERE id=1")
check("Erfolg: gespeichert", one("SELECT label FROM income WHERE id=1"), "Gehalt A")


def _is_closed(cn):
    try:
        cn.execute("SELECT 1")
        return False
    except sqlite3.ProgrammingError:
        return True


check("Erfolg: Verbindung geschlossen", _is_closed(conn), True)
for exc in (HTTPException(404, "x"), RuntimeError("kaputt")):
    try:
        with database.db() as conn:
            conn.execute("UPDATE income SET label='halb' WHERE id=1")
            raise exc
    except type(exc):
        pass
    check(f"{type(exc).__name__}: zurückgenommen", one("SELECT label FROM income WHERE id=1"), "Gehalt A")
    check(f"{type(exc).__name__}: geschlossen", _is_closed(conn), True)
    check(f"{type(exc).__name__}: Datei frei", writable(), True)
tok = database.set_demo_context(True)
try:
    with database.db(real=True) as conn:
        check("real=True im Demo-Modus: echte DB",
              conn.execute("PRAGMA database_list").fetchone()["file"], str(database.DB_PATH))
finally:
    database.reset_demo_context(tok)


# --- 2) Endpunkte: Fehler nach einer Schreibaktion ---
print("— 2) Fehler mitten im Endpunkt")


def boom_after_write(sql):
    def f(conn, *a, **kw):
        conn.execute(sql)
        raise RuntimeError("simulierter Fehler nach dem Schreiben")
    return f


def case(name, patch_obj, attr, sql, request, after_check):
    orig = getattr(patch_obj, attr)
    setattr(patch_obj, attr, boom_after_write(sql))
    try:
        res = request()
    finally:
        setattr(patch_obj, attr, orig)
    check(f"{name}: Serverfehler gemeldet", res.status_code, 500)
    check(f"{name}: Datei sofort wieder beschreibbar", writable(), True)
    q, want = after_check
    check(f"{name}: halbe Schreibaktion nicht gespeichert", one(q), want)
    KEPT.clear()


case("Vermögen ändern", vr, "_set_asset_financing_links",
     "UPDATE assets SET note='halb' WHERE id=1",
     lambda: cl.patch("/api/assets/1", json={"label": "Haus neu", "financing_contract_ids": [1]}),
     ("SELECT label || '|' || COALESCE(note,'') FROM assets WHERE id=1", "Haus|"))
case("Vermögen anlegen", vr, "_set_asset_financing_links",
     "UPDATE assets SET note='halb' WHERE id=1",
     lambda: cl.post("/api/assets", json={"type": "immobilie", "label": "Neu", "financing_contract_ids": [1]}),
     ("SELECT COUNT(*) FROM assets", 1))
case("Gehaltsabrechnung übernehmen", rr, "_move_payslip_to_person_folder",
     "UPDATE settings SET value=value WHERE 0",
     lambda: cl.post("/api/payslips/1/confirm", json={"income_id": 1}),
     ("SELECT amount || '|' || source FROM income WHERE id=1", "3000.0|manuell"))
check("Gehaltsabrechnung: weiter offen", one("SELECT review_needed FROM payslips WHERE id=1"), 1)

orig_bulk = br.bank_matching.bulk_assign
br.bank_matching.bulk_assign = boom_after_write("UPDATE income SET label='halb' WHERE id=1")
try:
    res = cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": [1], "mode": "everyday"})
finally:
    br.bank_matching.bulk_assign = orig_bulk
check("Bank-Sammelzuordnung: Serverfehler gemeldet", res.status_code, 500)
check("Bank-Sammelzuordnung: Datei sofort wieder beschreibbar", writable(), True)
check("Bank-Sammelzuordnung: halbe Schreibaktion nicht gespeichert", one("SELECT label FROM income WHERE id=1"), "Gehalt A")
KEPT.clear()

# Normale Wege funktionieren weiter
res = cl.post("/api/payslips/1/confirm", json={"income_id": 1})
check("Übernehmen normal: 200", res.status_code, 200)
check("Übernehmen normal: Betrag", one("SELECT amount FROM income WHERE id=1"), 3123.45)
check("Übernehmen normal: previous", res.json().get("previous"), {"amount": 3000.0, "source": "manuell"})
res = cl.post("/api/payslips/1/undo-confirm", json={"previous_amount": 3000.0, "previous_source": "manuell"})
check("Rückgängig: 200", res.status_code, 200)
check("Rückgängig: Betrag zurück", one("SELECT amount FROM income WHERE id=1"), 3000.0)
check("Rückgängig nochmal: 404", cl.post("/api/payslips/1/undo-confirm", json={}).status_code, 404)
check("Übernehmen unbekannt: 404", cl.post("/api/payslips/99/confirm", json={}).status_code, 404)
check("Datei frei nach 404", writable(), True)
res = cl.post("/api/assets", json={"type": "konto", "label": "Giro"})
check("Vermögen anlegen normal: 200", res.status_code, 200)
new_id = res.json()["id"]
check("Vermögen archivieren: 200", cl.delete(f"/api/assets/{new_id}").status_code, 200)
check("Vermögen archiviert", one("SELECT archived_at IS NOT NULL FROM assets WHERE id=?", (new_id,)), 1)
check("Vermögen archivieren unbekannt: 404", cl.delete("/api/assets/999").status_code, 404)
check("Vermögen ändern unbekannt: 404", cl.patch("/api/assets/999", json={"label": "x"}).status_code, 404)

# --- 3) Ungültiger Finanzierungsvertrag ---
print("— 3) Ungültiger Finanzierungsvertrag")
res = cl.patch("/api/assets/1", json={"financing_contract_ids": [1, 99999]})
check("ungültiger Vertrag: 400", res.status_code, 400)
check("Verknüpfung zu Vertrag 1 bleibt", one("SELECT COUNT(*) FROM asset_financing_links WHERE asset_id=1"), 1)
check("Datei frei", writable(), True)
res = cl.post("/api/assets", json={"type": "immobilie", "label": "X", "financing_contract_ids": [99999]})
check("anlegen mit ungültigem Vertrag: 400", res.status_code, 400)
check("kein halber Vermögenswert angelegt", one("SELECT COUNT(*) FROM assets WHERE label='X'"), 0)

print()
if FAILS:
    print(f"✗ Verbindungen: {len(FAILS)} Fehler: {', '.join(FAILS)}")
    sys.exit(1)
print("✓ Verbindungen: alle Fälle stimmen")
