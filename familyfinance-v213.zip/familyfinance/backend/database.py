"""
Zentrale DB-Verbindung. Läuft komplett lokal auf SQLite — keine Server, keine Cloud.
"""
import sqlite3
import re
import hashlib
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "finance.db"
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# Spalten, die nach dem ersten Release ergänzt wurden. CREATE TABLE IF NOT
# EXISTS ändert bestehende Tabellen nicht — ohne diese Migration würde eine
# schon vorhandene finance.db beim Öffnen mit "no such column" abstürzen.
_COLUMN_MIGRATIONS = [
    ("contracts", "subcategory", "TEXT"),
    ("contracts", "source", "TEXT"),
    ("contracts", "updated_at", "TIMESTAMP"),
    ("contracts", "last_receipt_id", "INTEGER"),
    ("contracts", "reviewed", "INTEGER"),
    ("contracts", "link", "TEXT"),
    ("contracts", "sort_order", "INTEGER"),
    ("contracts", "person_id", "INTEGER"),
    ("contracts", "interest_rate", "REAL"),
    ("contracts", "remaining_debt", "REAL"),
    ("contracts", "repayment_rate", "REAL"),
    ("contracts", "fixed_interest_until", "DATE"),
    ("contracts", "insurance_type", "TEXT"),
    ("contracts", "insurance_expiry", "DATE"),
    ("contracts", "insurance_sum", "REAL"),
    ("contracts", "insurance_sum_type", "TEXT"),
    ("contracts", "bu_monthly_pension", "REAL"),
    ("pension_accounts", "disability_pension_monthly", "REAL"),
    ("income", "source", "TEXT"),
    ("income", "category", "TEXT"),
    ("income", "updated_at", "TIMESTAMP"),
    ("income", "sort_order", "INTEGER"),
    ("payslips", "file_hash", "TEXT"),
    ("pension_accounts", "linked_contract_id", "INTEGER"),
    ("receipts", "asset_id", "INTEGER"),
    ("assets", "account_number", "TEXT"),
    ("assets", "purpose", "TEXT"),
    ("family_members", "freistellungsauftrag_used", "REAL"),
    ("family_members", "sv_nummer", "TEXT"),
    ("family_members", "steuer_id", "TEXT"),
    ("family_members", "steuerklasse", "TEXT"),
    ("family_members", "krankenkasse", "TEXT"),
    ("family_members", "etin", "TEXT"),
    ("family_members", "steuernummer", "TEXT"),
    ("family_members", "finanzamt", "TEXT"),
    ("assets", "account_type", "TEXT"),
    ("pension_accounts", "is_riester", "INTEGER DEFAULT 0"),
    ("income", "person_id", "INTEGER"),
    ("categories", "sort_order", "INTEGER"),
    ("passkeys", "rp_id", "TEXT"),
    ("receipts", "file_hash", "TEXT"),
]


def _migrate_schema(conn: sqlite3.Connection):
    existing_tables = {r["name"] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()}

    for table, column, coltype in _COLUMN_MIGRATIONS:
        if table not in existing_tables:
            continue
        columns = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in columns:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
            print(f"Migration: Spalte {table}.{column} ergänzt")

    # Sinnvolle Defaults für Zeilen, die es schon vor der Migration gab
    if "contracts" in existing_tables:
        conn.execute("UPDATE contracts SET source='import' WHERE source IS NULL")
        conn.execute("UPDATE contracts SET updated_at=CURRENT_TIMESTAMP WHERE updated_at IS NULL")
        # reviewed war vorher nicht vorhanden -> für bestehende "Sonstiges"-Positionen
        # auf "noch zu prüfen" setzen, alles andere gilt als bereits erledigt
        conn.execute(
            """UPDATE contracts SET reviewed = CASE
                 WHEN category_id IN (SELECT id FROM categories WHERE name='Sonstiges') THEN 0
                 ELSE 1 END
               WHERE reviewed IS NULL"""
        )
    if "income" in existing_tables:
        conn.execute("UPDATE income SET source='import' WHERE source IS NULL")
        conn.execute("UPDATE income SET updated_at=CURRENT_TIMESTAMP WHERE updated_at IS NULL")
    if "passkeys" in existing_tables:
        conn.execute("UPDATE passkeys SET rp_id='localhost' WHERE rp_id IS NULL")
    conn.commit()


def _seed_family_members(conn: sqlite3.Connection):
    """Stammdaten für Vorsorge/Risikoabsicherung: leer nur beim allerersten
    Start befüllen, danach bleibt es vollständig in der Hand des Nutzers
    (umbenennen/löschen über die UI, keine erneute Befüllung)."""
    count = conn.execute("SELECT COUNT(*) AS n FROM family_members").fetchone()["n"]
    if count > 0:
        return
    # Bewusst keine Standard-Personen vorbelegen — jede Installation (auch
    # bei anderen Nutzern) soll mit einer leeren Personen-Liste starten,
    # die über "Einstellungen -> Personen" selbst befüllt wird.


def _auto_match_persons(conn: sqlite3.Connection):
    """Leitet person_id für Einkommen/Verträge automatisch aus der
    Bezeichnung ab (z.B. 'Gehalt Anna' -> Anna), wo noch keine Zuordnung
    gesetzt ist. Überschreibt nie eine bereits bewusst gesetzte Zuordnung."""
    members = [dict(r) for r in conn.execute("SELECT id, name FROM family_members").fetchall()]
    if not members:
        return
    from vorsorge import match_family_member

    for table, has_provider in [("income", False), ("contracts", True)]:
        cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if "person_id" not in cols:
            continue
        select_cols = "id, label" + (", provider" if has_provider else "")
        rows = conn.execute(f"SELECT {select_cols} FROM {table} WHERE person_id IS NULL").fetchall()
        for row in rows:
            provider = row["provider"] if has_provider else None
            match = match_family_member(row["label"], provider, members)
            if match:
                conn.execute(f"UPDATE {table} SET person_id=? WHERE id=?", (match, row["id"]))
    conn.commit()


def _resync_categories(conn: sqlite3.Connection):
    """Wendet die aktuelle categorize.py-Logik erneut auf alle Positionen an,
    die noch nie manuell bearbeitet wurden (source='import'). So kommen
    Verbesserungen an der Kategorisierung (z.B. eine neue Kategorie wie
    "Auto") automatisch auch bei schon importierten Daten an — ohne jemals
    eine bewusste manuelle Zuordnung zu überschreiben."""
    from categorize import categorize

    rows = conn.execute(
        "SELECT id, label, category_id, subcategory FROM contracts WHERE source='import'"
    ).fetchall()
    for row in rows:
        new_category, new_subcategory = categorize(row["label"])
        cur = conn.execute("SELECT id FROM categories WHERE name=?", (new_category,))
        cat_row = cur.fetchone()
        new_category_id = cat_row["id"] if cat_row else conn.execute(
            "INSERT INTO categories (name) VALUES (?)", (new_category,)
        ).lastrowid

        if new_category_id != row["category_id"] or new_subcategory != row["subcategory"]:
            reviewed = 0 if new_category == "Sonstiges" else 1
            conn.execute(
                "UPDATE contracts SET category_id=?, subcategory=?, reviewed=? WHERE id=?",
                (new_category_id, new_subcategory, reviewed, row["id"]),
            )
    conn.commit()


def _clear_insurance_labels_once(conn: sqlite3.Connection):
    """Einmalige Migration: bestehende Versicherungs-Verträge bekommen einen
    leeren Namen, damit sie ab sofort automatisch aus Person/Anbieter/Typ
    abgeleitet werden, statt den alten, manuell eingetippten Namen zu zeigen.
    Über ein Settings-Flag abgesichert, damit das NICHT bei jedem Start
    erneut läuft und einen später bewusst manuell gesetzten Namen wieder
    löscht."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_cleared_insurance_labels'"
    ).fetchone()
    if flag:
        return
    conn.execute(
        """UPDATE contracts SET label=''
           WHERE category_id IN (SELECT id FROM categories WHERE name='Versicherungen')"""
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_cleared_insurance_labels', 'true')"
    )
    conn.commit()


def _fix_financing_zinsbindung_once(conn: sqlite3.Connection):
    """Bei Finanzierungen wurde 'Fälligkeit/Laufzeitende' bisher fälschlich
    für die Zinsbindung genutzt (die aber etwas anderes ist als das
    tatsächliche Tilgungsende). Einmalig: vorhandene Werte in das neue Feld
    fixed_interest_until übernehmen und contract_end dort leeren, da das
    Tilgungsende künftig aus Restschuld+Zins+Tilgung berechnet wird, nicht
    mehr manuell eingetragen."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_fixed_financing_zinsbindung'"
    ).fetchone()
    if flag:
        return
    conn.execute(
        """UPDATE contracts SET fixed_interest_until = contract_end, contract_end = NULL
           WHERE id IN (
               SELECT co.id FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
               WHERE c.name='Haus' AND co.subcategory='Finanzierung'
                 AND co.contract_end IS NOT NULL AND co.fixed_interest_until IS NULL
           )"""
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_fixed_financing_zinsbindung', 'true')"
    )
    conn.commit()


def _categorize_existing_income_once(conn: sqlite3.Connection):
    """Bestehende Einnahmen (vor Einführung des Kategorie-Felds) einmalig
    anhand des Namens grob vorsortieren, statt dass sie alle in
    'Ohne Kategorie' landen. Reine Startwert-Zuordnung — der Nutzer kann
    jede Position danach jederzeit umkategorisieren."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_categorized_income'"
    ).fetchone()
    if flag:
        return
    rules = [
        ("%gehalt%", "Gehalt"), ("%lohn%", "Gehalt"), ("%salär%", "Gehalt"),
        ("%kindergeld%", "Kindergeld"),
    ]
    for pattern, category in rules:
        conn.execute(
            "UPDATE income SET category=? WHERE category IS NULL AND LOWER(label) LIKE ?",
            (category, pattern),
        )
    conn.execute("UPDATE income SET category='Sonstiges' WHERE category IS NULL")
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_categorized_income', 'true')"
    )
    conn.commit()


def _migrate_pension_documents_once(conn: sqlite3.Connection):
    """Bestehende Einzel-Dokumente (vor Einführung der Dokument-Zeitreihe)
    einmalig in die neue pension_documents-Tabelle übernehmen, damit sie
    nicht verloren gehen."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_pension_documents'"
    ).fetchone()
    if flag:
        return
    rows = conn.execute(
        "SELECT id, document_filename, document_path FROM pension_accounts WHERE document_path IS NOT NULL"
    ).fetchall()
    for r in rows:
        conn.execute(
            "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path) VALUES (?,?,?)",
            (r["id"], r["document_filename"], r["document_path"]),
        )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_pension_documents', 'true')"
    )
    conn.commit()


def _fix_manual_contract_source_once(conn: sqlite3.Connection):
    """Rückwirkender Schutz: create_contract hat 'source' nie explizit
    gesetzt und damit ungewollt den Tabellen-Standard 'import' geerbt —
    wodurch auch manuell angelegte Verträge (allen voran Versicherungen mit
    bewusst leerem Label für die automatische Namensableitung) fälschlich
    für die label-basierte Nachkategorisierung in Frage kamen und bei jedem
    Neustart auf 'Sonstiges' zurückfallen konnten. Ein leeres Label ist ein
    zuverlässiges Zeichen für manuelle Anlage, da ein echter Import immer
    einen erkannten Namen mitbringt."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_fixed_manual_contract_source'"
    ).fetchone()
    if flag:
        return
    conn.execute(
        "UPDATE contracts SET source='manuell' WHERE source='import' AND (label IS NULL OR label='')"
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_fixed_manual_contract_source', 'true')"
    )
    conn.commit()


def _dedupe_documents_once(conn: sqlite3.Connection):
    """Einmalige Bereinigung: byteidentische Duplikate (gleicher Datei-Hash)
    innerhalb desselben Kontexts (gleiche Einnahme / gleiches Rentenkonto /
    gleicher Vertrag) automatisch entfernen — behält jeweils die älteste
    Kopie. Ein echter Hash-Treffer ist verlustfrei entfernbar, da der
    Dateiinhalt exakt identisch ist; auf Kontext beschränkt, damit z.B. eine
    zufällig inhaltsgleiche Datei bei zwei verschiedenen Verträgen nicht
    fälschlich als Duplikat gilt."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_deduped_documents'"
    ).fetchone()
    if flag:
        return

    # Gehaltsabrechnungen hatten bisher keinen Hash — für bestehende
    # Dateien einmalig nachträglich berechnen, soweit die Datei noch existiert.
    rows = conn.execute(
        "SELECT id, stored_path FROM payslips WHERE file_hash IS NULL"
    ).fetchall()
    for r in rows:
        file_path = BASE_DIR / r["stored_path"]
        if file_path.exists():
            file_hash = hashlib.sha256(file_path.read_bytes()).hexdigest()
            conn.execute("UPDATE payslips SET file_hash=? WHERE id=?", (file_hash, r["id"]))

    removed_total = 0
    for table, context_col in [
        ("payslips", "income_id"),
        ("pension_documents", "pension_account_id"),
        ("receipts", "contract_id"),
    ]:
        dupe_groups = conn.execute(
            f"""SELECT {context_col} AS ctx, file_hash, COUNT(*) AS n
                FROM {table}
                WHERE file_hash IS NOT NULL AND {context_col} IS NOT NULL
                GROUP BY {context_col}, file_hash HAVING COUNT(*) > 1"""
        ).fetchall()
        for g in dupe_groups:
            dupes = conn.execute(
                f"SELECT id, stored_path FROM {table} WHERE {context_col}=? AND file_hash=? ORDER BY uploaded_at ASC",
                (g["ctx"], g["file_hash"]),
            ).fetchall()
            for extra in dupes[1:]:  # erste (älteste) behalten, Rest entfernen
                file_path = BASE_DIR / extra["stored_path"]
                if file_path.exists():
                    file_path.unlink()
                if table == "receipts":
                    conn.execute("DELETE FROM expenses WHERE receipt_id=?", (extra["id"],))
                    conn.execute("UPDATE contracts SET last_receipt_id=NULL WHERE last_receipt_id=?", (extra["id"],))
                conn.execute(f"DELETE FROM {table} WHERE id=?", (extra["id"],))
                removed_total += 1

    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_deduped_documents', 'true')"
    )
    conn.commit()
    if removed_total:
        print(f"Migration: {removed_total} doppelte Belege/Dokumente entfernt")


def _migrate_asset_financing_links_once(conn: sqlite3.Connection):
    """Überführt eine bereits gesetzte assets.linked_contract_id (aus der
    ursprünglichen 1:1-Verknüpfung) in die neue asset_financing_links-
    Tabelle, die mehrere Verträge pro Immobilie erlaubt — kein Datenverlust
    für alle, die schon vor der Umstellung eine Immobilie verknüpft hatten."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_asset_financing_links'"
    ).fetchone()
    if flag:
        return
    rows = conn.execute(
        "SELECT id, linked_contract_id FROM assets WHERE linked_contract_id IS NOT NULL"
    ).fetchall()
    for r in rows:
        conn.execute(
            "INSERT OR IGNORE INTO asset_financing_links (asset_id, contract_id) VALUES (?,?)",
            (r["id"], r["linked_contract_id"]),
        )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_asset_financing_links', 'true')"
    )
    conn.commit()
    if rows:
        print(f"Migration: {len(rows)} Immobilien-Vertrags-Verknüpfungen übernommen")


def _backfill_payslip_month_from_filename_once(conn: sqlite3.Connection):
    """Für bestehende Gehaltsabrechnungen ohne erkannten Monat (z.B. eine
    Lohnsteuerbescheinigung, deren PDF-Text kein 'Monatsname Jahr' enthält)
    einmalig versuchen, den Monat aus dem Dateinamen nachzutragen — dieselbe
    Fallback-Logik, die jetzt auch bei neuen Uploads greift."""
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_backfilled_payslip_month'"
    ).fetchone()
    if flag:
        return
    from payslip_import import _extract_month_from_filename

    rows = conn.execute(
        "SELECT id, original_filename FROM payslips WHERE detected_month IS NULL AND original_filename IS NOT NULL"
    ).fetchall()
    updated = 0
    for r in rows:
        month = _extract_month_from_filename(r["original_filename"])
        if month:
            conn.execute("UPDATE payslips SET detected_month=? WHERE id=?", (month, r["id"]))
            updated += 1

    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_backfilled_payslip_month', 'true')"
    )
    conn.commit()
    if updated:
        print(f"Migration: {updated} Gehaltsabrechnungen Monat aus Dateinamen nachgetragen")


def init_db():
    conn = get_connection()
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.commit()
    _migrate_schema(conn)
    _seed_family_members(conn)
    _auto_match_persons(conn)
    _clear_insurance_labels_once(conn)
    _fix_financing_zinsbindung_once(conn)
    _categorize_existing_income_once(conn)
    _migrate_pension_documents_once(conn)
    _fix_manual_contract_source_once(conn)
    _dedupe_documents_once(conn)
    _backfill_payslip_month_from_filename_once(conn)
    _migrate_asset_financing_links_once(conn)
    _resync_categories(conn)
    conn.close()
    print(f"Datenbank initialisiert: {DB_PATH}")


if __name__ == "__main__":
    init_db()
