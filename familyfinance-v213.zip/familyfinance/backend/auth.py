"""
Zugriffsschutz: Passwort (1. Faktor) + Passkey/WebAuthn (2. Faktor).

Wichtig zum Passkey-Teil: Browser erlauben WebAuthn nur in einem "sicheren
Kontext" — also unter https:// oder auf localhost. Für den Zugriff vom
Mac aus http://localhost funktioniert das direkt. Fürs iPhone im selben
Netz reicht ein bloßes http://<Mac-Mini-IP> NICHT aus — dafür brauchst du
HTTPS, z.B. über "tailscale serve" (siehe README). RP_ID/ORIGIN unten per
Umgebungsvariable auf deine echte Adresse einstellen, sobald du die hast.
"""
import os
import secrets
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import bcrypt
import webauthn
from webauthn.helpers.structs import (
    AuthenticatorSelectionCriteria, UserVerificationRequirement,
    PublicKeyCredentialDescriptor,
)
from fastapi import Request, HTTPException, Response
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

from database import get_connection

BASE_DIR = Path(__file__).resolve().parent.parent
COOKIE_NAME = "ffz_session"
SESSION_MAX_AGE = 60 * 60 * 24 * 14  # Sicherheitsobergrenze für die Signaturprüfung;
                                       # die eigentliche Gültigkeit endet mit dem Browser-Fenster (siehe issue_session)

# Fallback-Werte, falls die Adresse nicht aus der Anfrage ermittelt werden kann.
# Im Normalbetrieb werden RP_ID/ORIGIN pro Anfrage aus der tatsächlich
# aufgerufenen Adresse abgeleitet (siehe rp_id_for / origin_for) — dadurch
# funktioniert die App gleichzeitig über localhost UND über die
# Tailscale-Adresse, ohne dass Umgebungsvariablen umgestellt werden müssen.
RP_ID = os.environ.get("RP_ID", "localhost")
RP_NAME = "Family Finance"
ORIGIN = os.environ.get("ORIGIN", "http://localhost:8420")


def rp_id_for(request: Optional["Request"]) -> str:
    """Die RP-ID ist immer der reine Hostname der aufgerufenen Adresse.
    WebAuthn verlangt, dass sie exakt zur Adresse in der Browser-Leiste passt."""
    if request is None:
        return RP_ID
    return request.url.hostname or RP_ID


def origin_for(request: Optional["Request"]) -> str:
    """Der Origin muss inkl. Schema und ggf. Port exakt dem entsprechen, was der
    Browser sendet. Hinter einem Proxy (z.B. `tailscale serve`) steht die vom
    Browser genutzte Adresse im Origin-Header — der hat deshalb Vorrang."""
    if request is None:
        return ORIGIN
    header_origin = request.headers.get("origin")
    if header_origin:
        return header_origin
    return f"{request.url.scheme}://{request.url.netloc}"


# Ausstehende WebAuthn-Challenges — läuft als einzelner Prozess für einen
# einzigen Familien-Account, ein einfaches In-Memory-Dict genügt hier völlig.
_pending_challenges: dict[str, bytes] = {}

# WICHTIG: bewusst NICHT auf Festplatte gespeichert, sondern bei jedem
# Prozessstart neu zufällig erzeugt. Dadurch werden alle Sessions bei jedem
# Server-Neustart ungültig — wie gewünscht ein automatischer Logout.
_secret_key = secrets.token_hex(32)
_serializer = URLSafeTimedSerializer(_secret_key)


# ---------------- Setup / Passwort ----------------

def user_exists() -> bool:
    conn = get_connection()
    row = conn.execute("SELECT 1 FROM app_user WHERE id=1").fetchone()
    conn.close()
    return row is not None


# ---------- Schutz gegen Passwort-Durchprobieren ----------
# Bewusst im Arbeitsspeicher gehalten (kein DB-Schreibzugriff bei jedem
# Fehlversuch) — passt zur Single-User-Installation, und ein Serverneustart
# setzt die Sperre ohnehin zurück, was hier akzeptabel ist.
_FAILED_LOGINS: dict = {}
_MAX_ATTEMPTS = 8
_LOCKOUT_MINUTES = 15


def _client_key(request: Optional[Request]) -> str:
    if request is None or request.client is None:
        return "unknown"
    return request.client.host


def check_login_allowed(request: Optional[Request]):
    """Wirft 429, wenn zu viele Fehlversuche von derselben Adresse kamen."""
    key = _client_key(request)
    entry = _FAILED_LOGINS.get(key)
    if not entry:
        return
    count, blocked_until = entry
    if blocked_until and datetime.utcnow() < blocked_until:
        remaining = int((blocked_until - datetime.utcnow()).total_seconds() / 60) + 1
        raise HTTPException(
            429, f"Zu viele Fehlversuche. Bitte in etwa {remaining} Minuten erneut versuchen."
        )
    if blocked_until and datetime.utcnow() >= blocked_until:
        _FAILED_LOGINS.pop(key, None)


def register_failed_login(request: Optional[Request]):
    key = _client_key(request)
    count, _ = _FAILED_LOGINS.get(key, (0, None))
    count += 1
    blocked_until = datetime.utcnow() + timedelta(minutes=_LOCKOUT_MINUTES) if count >= _MAX_ATTEMPTS else None
    _FAILED_LOGINS[key] = (count, blocked_until)


def reset_failed_logins(request: Optional[Request]):
    _FAILED_LOGINS.pop(_client_key(request), None)


def create_user(username: str, password: str):
    if user_exists():
        raise HTTPException(400, "Es existiert bereits ein Zugang.")
    if len(password) < 8:
        raise HTTPException(400, "Passwort muss mindestens 8 Zeichen haben.")
    password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    conn = get_connection()
    conn.execute(
        "INSERT INTO app_user (id, username, password_hash) VALUES (1, ?, ?)",
        (username, password_hash),
    )
    conn.commit()
    conn.close()


def verify_password(username: str, password: str) -> bool:
    conn = get_connection()
    row = conn.execute("SELECT * FROM app_user WHERE id=1").fetchone()
    conn.close()
    if not row or row["username"] != username:
        return False
    return bcrypt.checkpw(password.encode(), row["password_hash"].encode())


def has_passkey(request: Optional[Request] = None) -> bool:
    rp_id = rp_id_for(request)
    conn = get_connection()
    row = conn.execute("SELECT 1 FROM passkeys WHERE rp_id=? LIMIT 1", (rp_id,)).fetchone()
    conn.close()
    return row is not None


# ---------------- Session-Cookie ----------------

def issue_session(response: Response, stage: str, request: Optional[Request] = None):
    """stage: 'password_ok' (Faktor 1 bestanden) oder 'full' (Faktor 2 bestanden).
    Bewusst OHNE max_age/expires gesetzt -> ein echtes Browser-Session-Cookie,
    das verschwindet, sobald der Browser/die App komplett geschlossen wird.
    Zusammen mit dem pro Prozessstart neuen Schlüssel (siehe oben) heißt das:
    Server-Neustart ODER App/Browser schließen -> erneute Anmeldung nötig.

    Das Secure-Flag richtet sich nach der TATSÄCHLICHEN Verbindung, nicht nach
    der ORIGIN-Einstellung: Sonst würde bei ORIGIN=https..., aber Zugriff über
    http://localhost, der Browser das Cookie verwerfen — der Login wäre
    scheinbar erfolgreich, der nächste Aufruf käme aber als 401 zurück."""
    token = _serializer.dumps({"stage": stage, "iat": datetime.utcnow().isoformat()})
    is_https = request.url.scheme == "https" if request is not None else ORIGIN.startswith("https")
    response.set_cookie(
        COOKIE_NAME, token, httponly=True,
        samesite="lax", secure=is_https,
    )


def _read_session(request: Request) -> Optional[dict]:
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return None
    try:
        return _serializer.loads(token, max_age=SESSION_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None


def require_password_stage(request: Request) -> dict:
    """Für Endpunkte, die nach Faktor 1 (Passwort) aber vor Faktor 2 laufen,
    z.B. den Passkey selbst registrieren/abfragen."""
    session = _read_session(request)
    if not session or session.get("stage") not in ("password_ok", "full"):
        raise HTTPException(401, "Bitte zuerst einloggen.")
    return session


def require_full_auth(request: Request) -> dict:
    """Für alle eigentlichen Finanzdaten-Endpunkte: Passwort UND Passkey nötig."""
    session = _read_session(request)
    if not session or session.get("stage") != "full":
        raise HTTPException(401, "Anmeldung (Passwort + Passkey) erforderlich.")
    return session


def clear_session(response: Response):
    response.delete_cookie(COOKIE_NAME)


# ---------------- WebAuthn: Registrierung eines neuen Passkeys ----------------

def begin_passkey_registration(username: str, request: Optional[Request] = None) -> dict:
    import json
    rp_id = rp_id_for(request)
    conn = get_connection()
    existing = conn.execute("SELECT credential_id, rp_id FROM passkeys").fetchall()
    conn.close()

    exclude = [
        PublicKeyCredentialDescriptor(id=webauthn.base64url_to_bytes(r["credential_id"]))
        for r in existing
        if r["rp_id"] == rp_id
    ]
    options = webauthn.generate_registration_options(
        rp_id=rp_id, rp_name=RP_NAME, user_name=username,
        authenticator_selection=AuthenticatorSelectionCriteria(
            user_verification=UserVerificationRequirement.PREFERRED,
        ),
        exclude_credentials=exclude,
    )
    _pending_challenges["register"] = options.challenge
    return json.loads(webauthn.options_to_json(options))


def complete_passkey_registration(credential_json: str, label: str,
                                   request: Optional[Request] = None) -> dict:
    challenge = _pending_challenges.get("register")
    if not challenge:
        raise HTTPException(400, "Keine Registrierung angefordert.")
    rp_id = rp_id_for(request)
    origin = origin_for(request)
    try:
        verification = webauthn.verify_registration_response(
            credential=credential_json, expected_challenge=challenge,
            expected_rp_id=rp_id, expected_origin=origin,
        )
    except Exception as e:
        raise HTTPException(
            400,
            f"Passkey-Registrierung von Browser-Seite abgelehnt ({type(e).__name__}: {e}). "
            f"Erwartete Adresse war RP_ID={rp_id!r}, ORIGIN={origin!r} — "
            "stimmt das exakt mit der Adresse in der Browser-Leiste überein?",
        )
    conn = get_connection()
    conn.execute(
        "INSERT INTO passkeys (label, credential_id, public_key, sign_count, rp_id) VALUES (?,?,?,?,?)",
        (label, webauthn.helpers.bytes_to_base64url(verification.credential_id),
         webauthn.helpers.bytes_to_base64url(verification.credential_public_key),
         verification.sign_count, rp_id),
    )
    conn.commit()
    conn.close()
    _pending_challenges.pop("register", None)
    return {"status": "registered"}


# ---------------- WebAuthn: Anmeldung mit Passkey (2. Faktor) ----------------

def begin_passkey_login(request: Optional[Request] = None) -> dict:
    import json
    rp_id = rp_id_for(request)
    conn = get_connection()
    creds = conn.execute("SELECT credential_id FROM passkeys WHERE rp_id=?", (rp_id,)).fetchall()
    conn.close()
    if not creds:
        raise HTTPException(400, "Noch kein Passkey für diese Adresse registriert.")

    allow = [
        PublicKeyCredentialDescriptor(id=webauthn.base64url_to_bytes(r["credential_id"]))
        for r in creds
    ]
    options = webauthn.generate_authentication_options(
        rp_id=RP_ID, allow_credentials=allow,
        user_verification=UserVerificationRequirement.PREFERRED,
    )
    _pending_challenges["login"] = options.challenge
    return json.loads(webauthn.options_to_json(options))


def complete_passkey_login(credential_json: str, request: Optional[Request] = None) -> bool:
    challenge = _pending_challenges.get("login")
    if not challenge:
        raise HTTPException(400, "Keine Anmeldung angefordert.")

    import json
    raw = json.loads(credential_json) if isinstance(credential_json, str) else credential_json
    cred_id_b64 = raw["id"] if "id" in raw else raw["rawId"]
    rp_id = rp_id_for(request)
    origin = origin_for(request)

    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM passkeys WHERE credential_id=?", (cred_id_b64,)
    ).fetchone()
    if not row:
        conn.close()
        raise HTTPException(401, "Unbekannter Passkey.")

    try:
        verification = webauthn.verify_authentication_response(
            credential=credential_json, expected_challenge=challenge,
            expected_rp_id=rp_id, expected_origin=origin,
            credential_public_key=webauthn.base64url_to_bytes(row["public_key"]),
            credential_current_sign_count=row["sign_count"],
        )
    except Exception as e:
        conn.close()
        raise HTTPException(
            400,
            f"Passkey-Anmeldung von Browser-Seite abgelehnt ({type(e).__name__}: {e}). "
            f"Erwartete Adresse war RP_ID={rp_id!r}, ORIGIN={origin!r} — "
            "stimmt das exakt mit der Adresse in der Browser-Leiste überein?",
        )
    conn.execute(
        "UPDATE passkeys SET sign_count=? WHERE id=?",
        (verification.new_sign_count, row["id"]),
    )
    conn.commit()
    conn.close()
    _pending_challenges.pop("login", None)
    return True
