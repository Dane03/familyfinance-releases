# Entscheidungen von Benjamin – 15.10.2026

Gilt als Auftrag für die genannten Nachtlauf-Rollen. Nach Umsetzung im eigenen Bericht vermerken („erledigt am …“).

## Feste Familiennamen aus `backend/categorize.py` entfernen (Rolle Datenmodell, nächster Donnerstag)

**Freigegeben.** Befund aus `nachtlog/2026-10-15-datenmodell.md`: In `categorize.py` stehen Personennamen als Schlüssel
(z. B. „handyvertrag benny“, „milan: schulgebühren+essen“, „raphi: …“, „tagesgeld milan/jano“). Das verstößt gegen
„Personennamen nie hart“ und wird auch an die Installation beim Verwandten ausgeliefert.

**Umsetzung in zwei Schritten, nicht in einem:**
1. **Festschreiben** – kleine, idempotente Migration `_freeze_import_categories_once` (Marker in `settings`), die in
   `init_db()` **vor** `_resync_categories` läuft: Jeder Vertrag mit `source='import'`, dessen Kategorie/Unterkategorie
   heute nur über einen der personenbezogenen Schlüssel zustande kommt, bekommt `source='manuell'`. Kategorie und
   Unterkategorie bleiben unverändert. Im Zweifel lieber einen Vertrag mehr festschreiben als einen zu wenig.
   Achtung: Labels wurden früher schon umbenannt (`_rename_benny_raphi_once`) – nicht annehmen, dass die alten
   Schreibweisen noch in der Datenbank stehen; der Abgleich muss über `categorize()` laufen, nicht über Namen im Test.
2. **Entfernen** – erst danach die personenbezogenen Einträge aus `categorize.py` löschen. Allgemeine Schlüssel
   (Anbieter, Versicherungsarten) bleiben.

**Test (Pflicht):**
- Demodaten **und** eine Testdatenbank mit Verträgen, deren Labels genau die heutigen Schlüssel tragen
  (`source='import'`): Vorher/Nachher-Vergleich von `category_id`/`subcategory` **aller** Verträge – es darf sich
  keine einzige Kategorie ändern.
- Zwei Starts hintereinander (Idempotenz), danach erneut vergleichen.
- `grep -i` nach den Familiennamen in `backend/` und `frontend/` – darf nichts mehr finden (außer Migrations-Markern).
- `fk.py`, `xss.py`, `rechnen.py` grün.

Wenn der Vergleich auch nur eine Abweichung zeigt: nicht abliefern, sondern als Befund in den Bericht.
