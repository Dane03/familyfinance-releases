# Nachtlauf 2026-10-15 – Datenmodell

**Rolle:** Datenmodell (Donnerstag, Europe/Berlin – der Lauf startete am 15.10. um 01:51 Uhr Berliner Zeit) · **Geprüfter Stand:** `master` @ `1b48ff3`, Build v331 · **Ergebnis-Build:** v332 (2026-10-15), kein Release gebaut.

**Aktualitäts-Check:** `latest.json` meldet v331, `master` steht ebenfalls bei v331. Der Stand ist also aktuell. Das Releases-Repo habe ich nur lesend (öffentlicher `git fetch`) gelesen.
Keine offenen PRs, also keine Überschneidungen. Es ist der erste Datenmodell-Lauf. Die Logs vom 09.–14.10. habe ich gelesen.

## Geändert

1. **Einnahme mit Lohnabrechnungen ließ sich nicht löschen, und die App zeigte nichts an (mittel)** – `backend/app.py` `delete_income`, `frontend/app.js` (⋯ → Löschen).
   - **Problem:** `payslips.income_id` verweist per Fremdschlüssel auf `income`. Beim Löschen einer Gehalts-Einnahme mit Abrechnungen antwortete der Server mit 500. Die Oberfläche hat den Fehler nicht ausgewertet: Der Klick verpuffte ohne Meldung. Außerdem blieb die Datenbankverbindung offen. Im Test führte das bei der nächsten Löschung zu einem weiteren 500 (Folgefehler).
   - **Neu:** Die App antwortet mit 409 und einer klaren Meldung, analog zum Löschen einer Person mit Rentenkonten: „Es sind noch N Lohnabrechnung(en) hinterlegt. Bitte zuerst über ⋯ → „Details bearbeiten“ → „🗂 Belege anzeigen“ löschen.“ Die Oberfläche zeigt diese Meldung an. Es werden bewusst keine Abrechnungen automatisch gelöscht.
   - **Nebenbei:** Wird eine Einnahme gelöscht, verwiesen Bankumsätze (`bank_transactions.income_id`, ohne Fremdschlüssel) bisher ins Leere und galten weiter als „zugeordnet“. Jetzt werden sie wieder offen, und die gelernte Regel für diese Einnahme wird entfernt.
2. **Belege löschen: Zählerstand-Foto führte zu Serverfehler und verlorener Datei (mittel)** – `backend/receipts_routes.py` `delete_receipt` und `resolve_receipt_duplicates`.
   - **Problem:** `meter_readings.receipt_id` (Ablesefoto) wurde beim Löschen nicht gelöst. Dazu kommt die Reihenfolge: Erst wurde die Datei gelöscht, danach scheiterte die Datenbank. Ergebnis: 500, der Eintrag blieb, die Datei war weg.
   - Beim Bereinigen von Duplikaten gab es dasselbe Problem. Stand außerdem der zu behaltende Beleg selbst in `remove_ids`, wurde auch dessen Datei gelöscht.
   - **Neu:** Der Zählerstand bleibt erhalten, nur der Verweis wird gelöst. Bei Duplikaten wird er auf den behaltenen, inhaltsgleichen Beleg umgebogen. Dateien werden erst **nach** dem erfolgreichen Commit gelöscht. Der behaltene Beleg und seine Datei werden nie angefasst.
3. **`scripts/review/fk.py` erweitert:** Lohnabrechnung an einer Einnahme, Ablesefoto an einem Zählerstand und eine gelernte Bank-Regel gehören jetzt zu den Testdaten. Nach jedem Löschaufruf prüft das Skript zusätzlich `PRAGMA foreign_key_check` und verwaiste Verweise in Spalten **ohne** Fremdschlüssel (`bank_transactions.income_id/contract_id`, `meter_readings.receipt_id`, `person_id` in Verträgen, Einnahmen und Vermögen). Der Eintrag in `scripts/review/README.md` ist angepasst.

**Tests (Projektkopie, Demodaten, `http://localhost:8420`):**
- Erweitertes `fk.py` **vorher** (Code v331): 3 Serverfehler (`/api/income/1`, `/api/income/2` als Folgefehler, `/api/receipts/1`). **Nachher:** 0 Serverfehler, 0 verwaiste Verweise.
- Gezielte Prüfungen per TestClient:
  - Einnahme mit Abrechnung: vorher 500, nachher 409 mit Text. Abrechnung, Einnahme und Umsatz bleiben unverändert.
  - Einnahme ohne Abrechnung: 200. Danach ist der Umsatz wieder offen (`income_id`/`match_source` = NULL) und die Regel gelöscht.
  - Zähler-Beleg: vorher 500 mit gelöschter Datei und verbliebener Zeile, nachher 200 und `reading.receipt_id` = NULL.
  - Duplikate (der zu behaltende Beleg steht auch in `remove_ids`): vorher 500 und **beide** Dateien weg; nachher 200, nur das Duplikat entfernt, Zählerstand zeigt auf den behaltenen Beleg.
- Playwright mit echtem uvicorn (iPhone-Breite), Tab Einnahmen, ⋯ → Löschen:
  - Bei der Einnahme mit Abrechnung erscheint die Meldung, die Einnahme bleibt.
  - Die Einnahme ohne Abrechnung verschwindet.
  - Keine JS-Fehler.
- `py_compile` (app.py, receipts_routes.py, fk.py), `node --check` (app.js, service-worker.js), `xss.py` grün, `rechnen.py` alle Fälle stimmen.
- Server startet, Ersteinrichtung 200, Passwort-Login 200 (`password_ok` → zweiter Faktor), ausgeliefert wird v332.
- `design.py` habe ich nicht laufen lassen: An der Oberfläche kommt nur eine Fehlermeldung (`alert`) dazu, am Layout ändert sich nichts.
- Keine Migration, daher kein Idempotenz-Test nötig.

## Befunde (nicht geändert)

**Mittel**
- **Datenbankverbindungen bleiben bei Fehlern offen** (Muster im ganzen Backend: `conn = get_connection()` … `conn.close()` ohne `try/finally`). Wirft eine Abfrage eine Ausnahme, bleibt die Verbindung samt offener Schreib-Transaktion hängen, bis der Garbage Collector sie aufräumt. Die nächste schreibende Anfrage wartet dann bis zu 30 s oder scheitert. Das ist im heutigen Vorher-Test beobachtet (`/api/income/2`).
  Vorschlag: `get_connection()` als Kontextmanager nutzbar machen (`with closing(get_connection()) as conn:`) und schrittweise in den Lösch- und Schreib-Endpunkten einsetzen. Das ist ein größerer Umbau, also kein Nachtlauf-Schritt.
- **Familiennamen fest im Code** – `backend/categorize.py:27–46` (z. B. „handyvertrag benny“, „milan: schulgebühren+essen“). Das verstößt gegen die Regel „Personennamen nie hart“, und die Namen werden auch an die Installation beim Verwandten ausgeliefert.
  **Nicht einfach löschen:** `_resync_categories` kategorisiert alle Verträge mit `source='import'` bei jedem Start neu. Fallen die Einträge weg, könnten eure importierten Verträge in andere Kategorien rutschen.
  Vorschlag: Zuerst per kleiner Migration die betroffenen Import-Verträge auf `source='manuell'` setzen (die Kategorie wäre damit festgeschrieben), danach die Einträge entfernen. Das braucht einen Blick auf die echte Datenbank, wie viele Verträge noch `source='import'` haben.

**Niedrig**
- **Fehlende Indizes auf Verweis-Spalten:** `bank_transactions(contract_id)`, `bank_transactions(income_id)`, `payslips(income_id)`, `pension_documents(pension_account_id)`, `pension_accounts(person_id)`, `expenses(contract_id)`, `expenses(receipt_id)`, `meter_readings(receipt_id)`, `person_documents(person_id)`. Bei Familien-Datenmengen spürt man das kaum. Den größten Nutzen hätten die Zahlungs-Listen je Vertrag oder Einnahme, wenn sich über Jahre Bankumsätze sammeln.
  **Achtung:** Die beiden `bank_transactions`-Indizes dürfen nicht in `schema.sql` stehen, weil das vor `_migrate_schema` läuft und alte Datenbanken die Spalten dort noch nicht haben. Sie gehören in `init_db()` nach die Migration (`CREATE INDEX IF NOT EXISTS`, idempotent).
- **Per Migration ergänzte Spalten haben keinen Fremdschlüssel** (`_COLUMN_MIGRATIONS`: u. a. `contracts.person_id`, `income.person_id`, `receipts.asset_id`, `bank_accounts.contract_id`, `bank_transactions.contract_id/income_id`). Bei bestehenden Datenbanken hängt die Konsistenz also allein am App-Code. Heute sind alle Lösch-Wege sauber, `fk.py` prüft das jetzt mit.
- **`_cleanup_unconfirmed_receipts`** (`receipts_routes.py:317`) löscht wie bisher `delete_receipt` die Dateien **vor** dem Datenbank-Löschen. Das ist heute unkritisch, weil unbestätigte Belege nirgends verknüpft sind. Für die Robustheit wäre dieselbe Reihenfolge wie in Änderung 2 sinnvoll.
- **Rentenkonto löschen entfernt auch alle Dokumente** (Renteninformationen, `vorsorge_routes.py:207–212`). Die Rückfrage lautet nur „Dieses Rentenkonto wirklich löschen?“ (`frontend/app.js:1728`, `:6213`). Vorschlag: Die Anzahl der Dokumente in der Rückfrage nennen.
- **Hochladen eines Zählerfotos räumt *alle* unbestätigten Belege weg** (`energy_routes.py:889`, ebenso `receipts_routes.py:597`). Lädt jemand gleichzeitig auf einem zweiten Gerät einen Beleg hoch und hat ihn noch nicht bestätigt, verschwindet der. Selten, nur zur Kenntnis.

**Geprüft, unauffällig:**
- Person löschen: Rentenkonten und Dokumente → 409. Verträge, Vermögen und Einnahmen verlieren nur die Zuordnung.
- Verträge werden nur archiviert, nie hart gelöscht. Daher keine verwaisten Belege, Bank-Zuordnungen oder Kostenbeteiligungen.
- `income_cost_shares` und `networth_snapshot_items` haben `ON DELETE CASCADE`. Gelernte Bank-Regeln prüfen ihr Ziel vor der Anwendung (`_target_exists`).
- Migrationen in `init_db()` laufen in sinnvoller Reihenfolge. Die `*_once`-Schritte sind über `settings`-Marker idempotent, `_migrate_schema` über `PRAGMA table_info`.
- `contracts.source`: Die manuelle Anlage setzt `'manuell'`, und `_fix_manual_contract_source_once` korrigiert Altfälle.

## Bewusst nicht geändert
- Keine Migration und keine Indizes: Der Nutzen ist heute gering, und eine Migration ohne Blick auf die echte Datenbank wollte ich nicht riskieren.
- `categorize.py`: siehe oben. Ohne vorheriges Festschreiben der Kategorien droht eine stille Umsortierung echter Verträge.
- Verbindungs-Handling (`try/finally`): Das betrifft fast alle Endpunkte, also ein großer Umbau.

## Offen / braucht Benjamin
- Nach dem Mergen kurz prüfen: Einnahmen → bei einer Gehalts-Einnahme mit Abrechnungen ⋯ → Löschen bestätigen. Es sollte die neue Meldung erscheinen, und es wird nichts gelöscht.
- Entscheiden, ob die festen Namen in `categorize.py` raus sollen (siehe Befund). Falls ja: Im nächsten Datenmodell-Lauf zuerst die betroffenen Verträge festschreiben, dann entfernen.
- Release bauen (nach dem Mergen).

## Vorschlag nächster Lauf (Datenmodell)
- Indizes für die Verweis-Spalten nach `_migrate_schema` ergänzen, mit zwei Starts hintereinander als Idempotenz-Test und einer Zeitmessung der Zahlungs-Listen mit ~20.000 Demo-Umsätzen.
- `categorize.py`-Namen in zwei Schritten entfernen (Festschreiben per `_..._once`-Migration, dann Einträge löschen), falls Benjamin zustimmt.
- Prüfen, ob es Dateien in `data/receipts`, `data/Gehalt` und den Vorsorge-Ordnern gibt, auf die kein Datenbankeintrag verweist (und umgekehrt). Dafür ein kleines Prüfskript `scripts/review/dateien.py`, das nur meldet und nichts löscht.
