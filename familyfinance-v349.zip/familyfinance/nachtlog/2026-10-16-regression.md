# Nachtlauf 2026-10-16 – Regression & Tests

**Rolle:** Regression & Tests (Freitag, Europe/Berlin – der Lauf startete am 16.10. kurz vor 02:00 Uhr Berliner Zeit) · **Geprüfter Stand:** `master` @ `8cd1d53`, Build v334 · **Ergebnis-Build:** v335 (2026-10-16), kein Release gebaut.

**Aktualitäts-Check:** `latest.json` meldet v334, `master` steht ebenfalls bei v334 – aktuell. Releases-Repo nur lesend (öffentlicher `git fetch`).
Keine offenen PRs, also keine Überschneidungen. Gelesen: README, `scripts/review/README.md`, alle Nachtlogs inkl. `2026-10-15-entscheidungen.md` (der dortige Auftrag `categorize.py` gilt für den Datenmodell-Lauf am Donnerstag und wurde hier bewusst nicht angefasst).

## Abdeckung der zuletzt gemergten Änderungen

| PR / Build | Änderung | Test vorher | Jetzt |
|---|---|---|---|
| #21 v334, #20 v333 | Bank-Regeln mit Betrag, centgenau | `bankregeln.py`, `rechnen.py` | grün |
| #18 v332 | Löschen ohne Serverfehler/verlorene Dateien | `fk.py` | grün |
| #16 v330, #17 v331 | Sicherung + Belege-Spiegel außerhalb des App-Ordners | **keiner** | neu: `sicherung.py` |
| #15 v329 | CSRF-Sperre über `Sec-Fetch-Site` | **keiner** | neu: `sicherung.py` (Teil 7) |

## Geändert

1. **Neues Prüfskript `scripts/review/sicherung.py`** (in `scripts/review/README.md` eingetragen). Ohne Server, Sekunden, arbeitet nur in Temp-Ordnern (fasst weder `data/` noch `~/familyfinance-backups` an). 35 Prüfungen:
   leere DB wird nicht nach außen kopiert, eingerichtete schon; Obergrenze von 30 externen Kopien (neueste bleibt); externer Ordner im App-Ordner → übersprungen; Belege-Spiegel kopiert genau die Belege in gleicher Struktur (keine `.db`, `secret.key`/`.key`, `backups/`, `smart_import_staging/`, `.icloud`, versteckte Dateien, lose Dateien in `data/`), zweiter Lauf kopiert nichts, geänderte Datei wird erneut kopiert, in der App gelöschte Datei bleibt im Spiegel; Status-Abfrage; Sonderzeichen im Pfad; CSRF: POST/DELETE mit `cross-site`/`same-site` → 403, `same-origin`/`none`/ohne Header → durchgelassen, GET nie blockiert.
2. **Regression gefunden und behoben (niedrig–mittel): Externe Sicherung unterblieb still, wenn ein Ordnername ein `#` enthält** – `backend/maintenance.py` `_is_real_database`.
   - **Problem:** Die Datenbank wurde per `file:{pfad}?mode=ro` geöffnet, ohne den Pfad zu kodieren. SQLite liest `#` als Ende des Pfads → Öffnen scheitert → die Datenbank gilt als „leer/nicht eingerichtet" → keine Kopie nach außen, und die Meldung behauptet fälschlich, die Datenbank sei leer. (Gleiches Risiko bei `?` oder `%xx` im Pfad.) Die Sicherung im App-Ordner selbst war nicht betroffen.
   - **Neu:** `path.resolve().as_uri()` – kodiert Sonderzeichen korrekt, unter Windows entsteht `file:///C:/…`, was SQLite versteht.
   - **Test:** `sicherung.py` Fall 5 vorher ✗ (`skipped`), nachher ✓. Zusätzlich mit echtem Server: `backup_database.py` in einen externen Ordner `ext #backup` → Kopie + Belege-Spiegel angelegt.
3. Build v335 (`app.js` + `service-worker.js`, Datum 2026-10-16).

**Alle Review-Skripte (Projektkopie, Demodaten, `http://localhost:8420`, je ~5 s Pause):**
`sicherung.py` ALLES GRÜN · `bankregeln.py` alle Fälle stimmen · `rechnen.py` alle Fälle stimmen · `xss.py` kein XSS, 0 Fehler · `fk.py` 13 DELETE-Routen/39 Aufrufe, 0 Serverfehler/verwaiste Verweise · `design.py` Fehler [] · `users.py` 15/15 · `hints.py` Fehler [] · `themes.py` alle 5 Themes OK.
`py_compile` (maintenance.py, sicherung.py), `node --check` (app.js, service-worker.js). Server startet, Ersteinrichtung 200, Passwort-Login 200 (`password_ok` → Passkey), ausgeliefert wird v335, Cross-Site-POST → 403.
Keine Regression in den bisherigen Skripten gefunden.

## Befunde (nicht geändert)

**Niedrig**
- **Status-Abfrage zählt bei jedem Öffnen der Einstellungen alle gespiegelten Belege** (`maintenance.py` `external_backup_status`, `rglob` über `belege/`). Bei vielen tausend Belegen oder ausgelagerten iCloud-Dateien kann das die Anzeige „Sicherung" spürbar verzögern. Vorschlag (Robustheits-Lauf): Zahl und Größe aus dem letzten Spiegel-Lauf in `settings` merken statt jedes Mal zu zählen.
- **Belege-Spiegel und nächtliche Sicherung können gleichzeitig laufen** (Start-Thread `belege-spiegel` in `app.py:startup` und `backup_database.py` per launchd). Beide kopieren nur; schlimmstenfalls wird eine Datei doppelt kopiert. Nur zur Kenntnis.
- **Spiegel wächst unbegrenzt** (löscht bewusst nie). Gewollt; im README/Hinweistext könnte stehen, dass man `~/familyfinance-backups/belege` gelegentlich selbst aufräumen darf (PM-Lauf).
- Zwei Sicherungen in derselben Sekunde überschreiben sich (Dateiname mit Sekunden). Praktisch irrelevant.

**Geprüft, unauffällig:** CSRF-Sperre verhält sich wie im Security-Nachtlog beschrieben (auch bei Groß-/Kleinschreibung des Headers). Belege-Spiegel nimmt keine Datenbanken oder Schlüssel mit.

## Bewusst nicht geändert
- `categorize.py`-Namen: Auftrag für den Datenmodell-Lauf (Donnerstag), nicht für diese Rolle.
- Windows selbst ließ sich nicht testen; `Path.as_uri()` erzeugt dort die von SQLite dokumentierte Form `file:///C:/…`. Bitte beim Verwandten nach dem Update einmal unter Einstellungen → Sicherung prüfen, dass „Zusätzliche Kopie außerhalb des App-Ordners" erscheint.

## Offen / braucht Benjamin
- Nach dem Mergen: Release bauen. Danach optional unter Windows die externe Sicherung kontrollieren (siehe oben).

## Vorschlag nächster Lauf (Regression)
- `sicherung.py` um einen Test des Start-Threads erweitern (Server starten, prüfen, dass der Start nicht auf den Spiegel wartet).
- Für die Update-Mechanik (SHA-256, Zip-Slip, nur Manifest-Adressen) gibt es noch kein Review-Skript – mit lokal erzeugtem Test-ZIP und gefälschtem Manifest abdecken.
- Ein kleines Sammelskript `scripts/review/alle.sh`, das alle Skripte mit Pause in einer frischen Kopie ausführt und eine Zeile je Skript ausgibt.
