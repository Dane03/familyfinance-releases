# Nachtlauf 2026-10-23 – Regression & Tests

**Rolle:** Regression & Tests (Freitag, Berliner Zeit; Lauf startete am 22.10. 23:50 UTC) · **Geprüfter Stand:** `master` @ `18bbcc5`, Build v341 · **Ergebnis-Build:** v341 (unverändert – nur Prüfskript und Bericht, keine ausgelieferten Dateien geändert), kein Release gebaut.

**Aktualitäts-Check:** `latest.json` meldet v341, `master` steht ebenfalls bei v341 – aktuell. Releases-Repo nur lesend (öffentliche raw-URL). Keine offenen PRs, keine Überschneidungen.

## Abdeckung der zuletzt gemergten Änderungen

| PR / Build | Änderung | Test vorher | Jetzt |
|---|---|---|---|
| #30 v341 | Route „Übernehmen“ (Gehaltsabrechnung) repariert | `routen.py` (nur Verdrahtung) | zusätzlich Verhalten: `gehaltsabrechnung.py` |
| #30 v341 | Einmal-Reparatur unbestätigter Abrechnungen | **keiner** | neu |
| #30 v341 | Server sichert täglich (`backup_if_due`) | **keiner** | neu (Entscheidung keine/frische/alte Sicherung) |
| #29 v340 | Familiennamen aus `categorize.py`, Migration, Indizes | `fk.py` | + `init_db` zweimal ohne Änderung (neu) |
| #27 v338 | TOTP-QR als data:-PNG | `routen.py` (Route entfernt) | unverändert |

## Geändert

1. **Neues Prüfskript `scripts/review/gehaltsabrechnung.py`** (in der README eingetragen), 28 Prüfungen, ohne Server, nur Temp-Ordner:
   Übernehmen mit bestehender/neuer Einnahme (Betrag, Quelle `lohnabrechnung`, Datei im Personen-Ordner, nicht mehr „zu prüfen“), „nur ablegen“ (Betrag bleibt), kein Betrag → 400, unbekannte ID → 404, ungültige Anfrage → 422; Reparatur-Migration (eindeutiger Treffer, Abrechnung vor dem 10.10. und ohne Treffer unangetastet, Betrag der Einnahme unverändert, zweiter Lauf tut nichts); `init_db` zweimal hintereinander ohne Änderung an Tabellen, Indizes und Einstellungen; `backup_if_due` (ohne Sicherung → sichert, frisch → nichts, > 20 h → sichert) plus echte Sicherung ergibt lesbare Datenbank.
   **Mutationstest:** Die Route von v340 (Dekorator an der Hilfsfunktion) wieder eingebaut → Skript rot (422, Abrechnung bleibt „zu prüfen“); auf v341 grün.
2. Keine Regression gefunden, kein Produktivcode geändert.

**Alle Review-Skripte (Projektkopie, Demodaten, `http://localhost:8420`, je ~5 s Pause):**
`gehaltsabrechnung.py` ALLES GRÜN · `routen.py` 202 Routen richtig · `sicherung.py` ALLES GRÜN · `bankregeln.py` alle Fälle stimmen · `rechnen.py` alle Fälle stimmen · `xss.py` kein XSS, 0 Fehler · `fk.py` 13 DELETE-Routen/39 Aufrufe, 0 Serverfehler/verwaiste Verweise · `design.py` Fehler [] · `users.py` 15/15 · `hints.py` Fehler [] · `themes.py` alle 5 Themes OK.

## Befunde (nicht geändert)

**Niedrig**
- **Tägliche Sicherung im Server ist nur durch die Entscheidungslogik getestet, nicht als laufender Thread** (`app.py` `_start_recurring_backup`, 15 min Anlaufpause, dann alle 2 h). Ein Test des Threads bräuchte Zeitraffer/Monkeypatch im Server; Vorschlag unten.
- **Reparatur-Migration ist bewusst grob** (`receipts_routes.py` `repair_unconfirmed_payslips_once`): ordnet nach Namenspräfix zu, auch Abrechnungen ohne erkannten Betrag. Für den Einmallauf auf den echten Daten laut Commit genau 1 Treffer – kein Handlungsbedarf, nur zur Kenntnis.
- Aus dem Lauf vom 16.10. weiter offen (niedrig): Status-Abfrage zählt bei jedem Öffnen alle gespiegelten Belege (`maintenance.py` `external_backup_status`) → Robustheits-Lauf.

## Bewusst nicht geändert
- Kein Produktivcode: Alle Skripte grün, keine Regression. Daher kein Build-Sprung (v341 bleibt).
- Windows und echte Geräte nicht testbar (unverändert offen: Passkey am iPhone, Beleg-/HEIC-Ansicht, Gas-Faktor, Strom-Aufteilung mit echten Daten).

## Offen / braucht Benjamin
- Nichts Neues. Der PR enthält nur ein Prüfskript und diesen Bericht – kein Release nötig.

## Vorschlag nächster Lauf (Regression)
- Update-Mechanik (SHA-256, Zip-Slip, nur Manifest-Adressen) mit lokal erzeugtem Test-ZIP und gefälschtem Manifest abdecken (seit 16.10. offen).
- Sammelskript `scripts/review/alle.sh`: alle Skripte mit Pause in frischer Kopie, eine Zeile je Skript (seit 16.10. offen).
- Start-Threads (Belege-Spiegel, tägliche Sicherung) in einem Servertest prüfen: Start wartet nicht auf sie.
