# Nachtlauf 2026-10-11 – Fachlogik & Rechenkorrektheit

**Rolle:** Fachlogik (Sonntag) · **Geprüfter Stand:** `master` @ `52ad009`, Build v323 · **Ergebnis-Build:** v324 (2026-10-11), kein Release gebaut.

**Aktualitäts-Check nicht möglich:** Das Releases-Repo `Dane03/familyfinance-releases` ist für diese Sitzung nicht freigegeben (Zugriff verweigert, `add_repo` nicht verfügbar). `latest.json` konnte nicht gelesen werden. Laut `NACHTLOG.md` war das letzte bekannte Release v317, `master` steht bei v323. Ich gehe davon aus, dass `master` aktuell ist.
Keine offenen PRs, daher keine Überschneidungen.

## Geändert

1. **Strom: „Tagesrate aktuell“ im laufenden Monat viel zu niedrig** (`backend/meters.py` `current_daily_rate_with_pv`).
   Der PV-/Sungrow-Monatswert des laufenden Monats enthält erst die Tage bis heute, wurde aber durch *alle* Tage des Monats geteilt.
   *Rechenweg:* 11.10., 6 kWh Bezug/Tag → Monatswert 66 kWh; alt 66 / 31 = **2,13 kWh/Tag**, neu 66 / 11 = **6,00 kWh/Tag**.
   Betroffen: Zähler-Übersicht, KPI-Chip „Tagesrate aktuell“ (Netzbezug und Einspeisung), PDF-Bericht, außerdem die Ersatzrate der Prognose.
   Für den laufenden Monat wird jetzt durch die vergangenen Tage geteilt, und als Vergleichsdatum gegenüber Zählerablesungen gilt „heute“ statt Monatsende.
2. **Strom: „davon Haushalt / davon Auto“ ergab weniger als die prognostizierten Jahreskosten** (`split_auto_household_cost`).
   Monate mit vollständigen Tageswerten wurden nur bis heute gerechnet. Die Jahresprognose rechnet den laufenden Monat aber hoch.
   *Rechenweg (Testdaten: 6 kWh Bezug/Tag, Auto 2 von 10 kWh Hausverbrauch, 0,30 €/kWh, 12 €/Monat Grundpreis):*
   Jahreskosten = 365 × 6 × 0,30 + 12 × 12 = **801 €**. Alt: Haushalt 641 € + Auto 124 € = **765 €** (es fehlten 20 Resttage × 6 kWh × 0,30 € = 36 €).
   Neu: 670 € + 131 € = **801 €**, Auto = 365 × 6 × 0,2 × 0,30 = 131,40 € ✓.
   Der hochgerechnete Rest-Einkauf des laufenden Monats wird im bisherigen Auto-Anteil dieses Monats verteilt.
   Das gilt genauso für die Kurven Auto/Sonstiges im Kumulativ-Chart.
3. **Gas: Hinweis zum Umrechnungsfaktor** (`frontend/app.js`, Gas-Einstellungen).
   Das Feld hieß „Brennwert (kWh/m³)“, gerechnet wird aber kWh = m³ × Faktor. Richtig ist Brennwert × Zustandszahl.
   Wer nur den Brennwert von der Rechnung einträgt, rechnet bei 11,2 statt 11,2 × 0,95 = 10,64 rund 5 % zu hoch (bei 15.000 kWh × 0,12 € ≈ 90 €/Jahr).
   Das Feld heißt jetzt „Umrechnungsfaktor m³ → kWh“ und hat einen kurzen Hinweis darunter. Feld und gespeicherter Wert bleiben gleich, es gibt keine Datenänderung.
   **Bitte einmal den eingetragenen Wert mit der letzten Gasrechnung abgleichen.**

**Tests:**
- `py_compile meters.py`, `node --check` für app.js und service-worker.js.
- Reiner Funktionstest mit nachrechenbaren Testdaten, vorher und nachher (Werte siehe oben).
- End-to-End-Test mit echtem uvicorn auf `http://localhost:8420` in einer Projektkopie mit synthetischen Tageswerten und Zappi-Ständen:
  - Ersteinrichtung, Passwort- und TOTP-Login 200, Dashboard 200.
  - `/api/meters/overview`: Tagesrate elec_in vorher 2,129, nachher 6,0.
  - `/api/meters/elec_in/kpis` wie oben, `cumulative`, `gas/kpis` und `elec_out/kpis` 200.
- `xss.py` grün, `fk.py` 0 Serverfehler, `design.py` ohne Fehler.

## Befunde (nicht geändert)

**Mittel**
- `backend/vorsorge.py:101` und `backend/vorsorge_routes.py:584`: Mit `date(birth.year + 67, birth.month, birth.day)` stürzt die Vorsorge-Seite für jemanden mit **Geburtstag am 29.02.** ab, wenn das Rentenjahr kein Schaltjahr ist (ValueError → 500).
  Die eigene Familie ist nicht betroffen, möglicherweise aber die Installation beim Verwandten.
  Vorschlag: dasselbe Muster wie `meters._add_years` (29.02. → 28.02.). Das ist eine kleine Änderung, braucht aber einen Test der Vorsorge-Endpunkte. Passt zum Lauf am Donnerstag oder Freitag.
- `backend/app.py:1993` (Verbindlichkeiten-Übersicht): Darlehen mit **0 % Zins** (z. B. KfW, Arbeitgeber) fallen wegen `not r["interest_rate"]` aus dem gesamten Tilgungsplan und aus der Summe der Raten heraus.
  In der „Restschuld gesamt“ sind sie aber enthalten, sodass die Chart-Summe zu Jahresbeginn nicht zur angezeigten Restschuld passt. `compute_repayment_schedule` kann mit 0 % rechnen.
  Vorschlag: `r["interest_rate"] is None` prüfen.

**Niedrig**
- `vorsorge.py:113`: Die angenommenen „3 % p.a.“ werden als 0,25 %/Monat mit monatlichem Zinseszins gerechnet, effektiv also 3,04 % p.a. Auf 30 Jahre sind das etwa +1 % Endkapital.
  Vorschlag: `(1 + r) ** (1/12) - 1`. Das ist eher Kosmetik und eine bewusste Vereinfachung.
- `cost_shares.py`: Die Kostenbeteiligung rechnet Verträge mit vollem Betrag. Hätte ein so verknüpfter Vertrag zusätzlich `split_share < 1` (nur per ODS-Import setzbar), würde der Anteil im Überschuss doppelt wirken: einmal als niedrigere Ausgabe, einmal als Einnahme.
  Mit den heutigen Daten ist das vermutlich nicht der Fall. Ein Warnhinweis im Dialog wäre denkbar.
- `shared_helpers.monthly_expr`: Ein unbekanntes Intervall ergibt `NULL` und fällt still aus Summen heraus. Das Schema erlaubt nur monthly/quarterly/yearly, daher nur zur Kenntnis.
- Tagesrate am Monatsersten (Änderung 1): Der heutige Tag zählt schon mit, obwohl er erst teilweise erfasst ist. Früh am Morgen des 1. ist die Rate deshalb etwas zu niedrig, aber nicht mehr um Faktor 3.

**Geprüft und rechnerisch korrekt:**
- Intervall-Umrechnung: einheitlich ÷3 bzw. ÷12 in Dashboard, Bericht, Kostenbeteiligung, Vorsorge, Finanzierung und Zählern.
- Überschuss nach Fixkosten bzw. nach Sparen und Sparquote. Die Einnahme „Anteil Haus“ plus volle Vertragsbeträge sind konsistent, es gibt keine Doppelzählung.
- Kostenbeteiligung: Soll/Ist mit 1 € Toleranz, Vorschlag pro Intervall zurückgerechnet.
- Annuitäten-Tilgungsplan: letzte Rate gekappt, Zinsen > Rate werden erkannt.
- Gas Kosten = m³ × Faktor × Arbeitspreis + 12 × Grundpreis, Wasser inkl. Entwässerung je m³.
- Abrechnungszeitraum ab Abrechnungsdatum (inkl. 29.02.).
- Tagesgenaue Verteilung über Monats- und Jahresgrenzen, Zählerwechsel.

## Bewusst nicht geändert
- Kein eigenes Feld „Zustandszahl“: Dafür müsste das Backend an sechs Stellen geändert werden und es bräuchte Einstellungen plus Migration. Der Hinweis löst das Problem ohne Datenrisiko.
- 29.02.- und 0-%-Befund: Die Fachlogik-Rolle soll nur 1–3 Änderungen machen. Beide brauchen eigene Endpunkt-Tests.

## Offen / braucht Benjamin
- Releases-Repo für den Nachtlauf lesbar freigeben (Aktualitäts-Check).
- Gas-Umrechnungsfaktor mit der Gasrechnung abgleichen.
- Mit echten Sungrow-/Zappi-Daten kurz prüfen, ob „Tagesrate aktuell“ (Strom) und „davon Haushalt/Auto“ jetzt plausibel sind.
- Release bauen (nach dem Mergen).

## Vorschlag nächster Lauf (Fachlogik)
- Die beiden mittleren Befunde (29.02., 0-%-Darlehen) beheben, falls bis dahin nicht erledigt.
- Ein kleines Review-Skript `scripts/review/rechnen.py` mit den nachrechenbaren Fällen von heute (Tagesrate, Auto/Haushalt-Summe, Intervalle, Annuität) als Regressionsschutz anlegen.
- Einspeise-Prognose und Autarkie-Quote nachrechnen.
