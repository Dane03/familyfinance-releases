"""Sicherung außerhalb des App-Ordners (v330/v331) und CSRF-Schutz (v329). Ohne Server, Sekunden.
    cd kopie/backend && python3 ../scripts/review/sicherung.py
Exit-Code 0 = alles grün.

Arbeitet ausschließlich in einem temporären Ordner (eigener App-Ordner + eigener externer Ordner),
fasst weder data/ der Kopie noch ~/familyfinance-backups an.

Fälle:
 1) Leere/nicht eingerichtete Datenbank wird NICHT nach außen kopiert, eingerichtete schon.
 2) Externe Kopien: höchstens EXTERNAL_BACKUP_KEEP, die neuesten bleiben.
 3) Externer Ordner im App-Ordner -> übersprungen (Datenbank und Belege).
 4) Belege-Spiegel: richtige Dateien, keine Datenbanken/Geheimnisse/Sicherungen/Zwischenablage/losen Dateien,
    nur Neues/Geändertes wird kopiert, im Spiegel wird nie gelöscht.
 5) Sonderzeichen im Pfad (Leerzeichen, #, %) -- Erkennung "eingerichtete Datenbank" darf nicht scheitern.
 6) Status-Endpunkt-Funktion zählt Kopien und Belege.
 7) CSRF: schreibende Anfragen mit Sec-Fetch-Site cross-site/same-site -> 403, same-origin/ohne Header -> nicht 403,
    lesende Anfragen nie blockiert.
"""
import os
import sqlite3
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
import maintenance   # noqa: E402

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


def make_app_dir(root: Path, with_user: bool) -> Path:
    app = root / "app"
    (app / "data").mkdir(parents=True)
    db = sqlite3.connect(app / "data" / "finance.db")
    db.execute("CREATE TABLE app_user (id INTEGER PRIMARY KEY, username TEXT)")
    if with_user:
        db.execute("INSERT INTO app_user (username) VALUES ('test')")
    db.commit()
    db.close()
    return app


def use(app: Path, ext: Path):
    maintenance.BASE_DIR = app
    os.environ["FAMILYFINANCE_BACKUP_DIR"] = str(ext)


ORIG_BASE = maintenance.BASE_DIR
ORIG_ENV = os.environ.get("FAMILYFINANCE_BACKUP_DIR")

try:
    # ---------- 1) leere vs. eingerichtete Datenbank ----------
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        app = make_app_dir(root, with_user=False)
        ext = root / "extern"
        use(app, ext)
        r = maintenance.backup_database(mirror_documents=False)
        check("1a leere DB: Sicherung im App-Ordner klappt", r["success"], True)
        check("1a leere DB: nicht nach außen kopiert", r.get("external"), "skipped")
        check("1a externer Ordner hat keine Kopie", len(list(ext.glob("finance_*.db"))) if ext.exists() else 0, 0)

    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        app = make_app_dir(root, with_user=True)
        ext = root / "extern"
        use(app, ext)
        r = maintenance.backup_database(mirror_documents=False)
        check("1b eingerichtete DB: nach außen kopiert", r.get("external"), "ok")
        copies = list(ext.glob("finance_*.db"))
        check("1b genau eine externe Kopie", len(copies), 1)
        n = sqlite3.connect(copies[0]).execute("SELECT COUNT(*) FROM app_user").fetchone()[0] if copies else None
        check("1b externe Kopie ist lesbare Datenbank mit Zugang", n, 1)

        # ---------- 2) Aufbewahrung ----------
        keep = maintenance.EXTERNAL_BACKUP_KEEP
        now = time.time()
        for i in range(keep + 5):   # künstlich alte Kopien
            p = ext / f"finance_2020-01-01_{i:06d}.db"
            p.write_bytes(copies[0].read_bytes())
            os.utime(p, (now - 86400 * (i + 1), now - 86400 * (i + 1)))
        r = maintenance.backup_database(mirror_documents=False)
        left = sorted(ext.glob("finance_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        check("2 externe Kopien auf Obergrenze begrenzt", len(left), keep)
        check("2 neueste Kopie bleibt erhalten", (ext / Path(r["path"]).name).exists(), True)
        check("2 älteste künstliche Kopie entfernt", (ext / f"finance_2020-01-01_{keep + 4:06d}.db").exists(), False)
        check("2 Rückmeldung external_total", r.get("external_total"), keep)

    # ---------- 3) externer Ordner im App-Ordner ----------
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        app = make_app_dir(root, with_user=True)
        (app / "data" / "receipts").mkdir()
        (app / "data" / "receipts" / "a.pdf").write_bytes(b"%PDF-1")
        use(app, app / "data" / "extern")
        r = maintenance.backup_database()
        check("3 DB-Kopie im App-Ordner übersprungen", r.get("external"), "skipped")
        check("3 Belege-Spiegel im App-Ordner übersprungen", r.get("documents"), "skipped")
        check("3 nichts angelegt", (app / "data" / "extern").exists(), False)

    # ---------- 4) Belege-Spiegel ----------
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        app = make_app_dir(root, with_user=True)
        d = app / "data"
        files = {
            "receipts/2026/rechnung.pdf": b"%PDF-rechnung",
            "Gehalt/2026-09.pdf": b"%PDF-gehalt",
            "vorsorge/person_1/info.pdf": b"%PDF-rente",
        }
        skipped = {
            "backups/finance_2026-01-01_000000.db": b"x",
            "smart_import_staging/tmp.pdf": b"x",
            "receipts/.DS_Store": b"x",
            "receipts/geheim.key": b"x",
            "receipts/secret.key": b"x",
            "receipts/halb.pdf.icloud": b"x",
            "receipts/.versteckt/x.pdf": b"x",
            "receipts/kopie.db": b"x",
            "lose-datei.pdf": b"x",           # lose Dateien direkt in data/ gehören nicht dazu
        }
        for rel, content in {**files, **skipped}.items():
            p = d / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(content)
        ext = root / "extern"
        use(app, ext)
        r = maintenance.mirror_documents_external()
        mirror = ext / "belege"
        got = sorted(str(p.relative_to(mirror)) for p in mirror.rglob("*") if p.is_file())
        check("4a genau die Belege gespiegelt (gleiche Ordnerstruktur)", got, sorted(files))
        check("4a Rückmeldung kopiert/gesamt", (r.get("documents"), r.get("documents_copied"), r.get("documents_total")),
              ("ok", 3, 3))
        check("4a Inhalt identisch", (mirror / "Gehalt/2026-09.pdf").read_bytes(), b"%PDF-gehalt")

        r = maintenance.mirror_documents_external()
        check("4b zweiter Lauf kopiert nichts neu", r.get("documents_copied"), 0)

        src = d / "receipts/2026/rechnung.pdf"
        src.write_bytes(b"%PDF-rechnung-korrigiert")
        later = time.time() + 5
        os.utime(src, (later, later))
        r = maintenance.mirror_documents_external()
        check("4c geänderte Datei wird erneut kopiert", r.get("documents_copied"), 1)
        check("4c Spiegel hat neuen Inhalt", (mirror / "receipts/2026/rechnung.pdf").read_bytes(), b"%PDF-rechnung-korrigiert")

        (d / "Gehalt/2026-09.pdf").unlink()
        r = maintenance.mirror_documents_external()
        check("4d in der App gelöschte Datei bleibt im Spiegel", (mirror / "Gehalt/2026-09.pdf").exists(), True)

        # ---------- 6) Status ----------
        maintenance.backup_database(mirror_documents=False)
        s = maintenance.external_backup_status()
        check("6 Status: Ordner", s["dir"], str(ext))
        check("6 Status: eine DB-Kopie", s["count"], 1)
        check("6 Status: Belege gezählt", s["documents"], 3)
        check("6 Status: Datum gesetzt", bool(s["latest"]), True)

    # ---------- 5) Sonderzeichen im Pfad ----------
    for label in ("mit Leerzeichen", "mit #Raute", "mit 100%"):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t) / f"Family Finance {label}"
            root.mkdir()
            app = make_app_dir(root, with_user=True)
            use(app, root / "extern")
            r = maintenance.backup_database(mirror_documents=False)
            check(f"5 Pfad {label}: eingerichtete DB nach außen kopiert", r.get("external"), "ok")
finally:
    maintenance.BASE_DIR = ORIG_BASE
    if ORIG_ENV is None:
        os.environ.pop("FAMILYFINANCE_BACKUP_DIR", None)
    else:
        os.environ["FAMILYFINANCE_BACKUP_DIR"] = ORIG_ENV

# ---------- 7) CSRF (Middleware, ohne echte Daten: nur Endpunkte, die vor jeder Datenbankarbeit ablehnen) ----------
try:
    from fastapi.testclient import TestClient
    import app as app_module
    client = TestClient(app_module.app, base_url="http://localhost:8420")
    # Ohne Sitzung: ein schreibender Endpunkt antwortet 401/403/422 -- entscheidend ist nur, ob die CSRF-Sperre (403
    # mit eigener Meldung) greift.
    MSG = "Anfrage von fremder Seite abgelehnt"

    def blocked(method, site):
        headers = {"Sec-Fetch-Site": site} if site else {}
        resp = client.request(method, "/api/auth/logout", headers=headers)
        return resp.status_code == 403 and MSG in resp.text

    check("7 POST cross-site abgelehnt", blocked("POST", "cross-site"), True)
    check("7 POST same-site abgelehnt", blocked("POST", "same-site"), True)
    check("7 DELETE cross-site abgelehnt", blocked("DELETE", "cross-site"), True)
    check("7 POST same-origin erlaubt", blocked("POST", "same-origin"), False)
    check("7 POST none (direkt eingetippt) erlaubt", blocked("POST", "none"), False)
    check("7 POST ohne Header (Skripte) erlaubt", blocked("POST", None), False)
    check("7 GET cross-site nicht blockiert", blocked("GET", "cross-site"), False)
    check("7 Groß-/Kleinschreibung egal", blocked("POST", "Cross-Site"), True)
except ImportError as e:
    print(f"✗ 7 CSRF-Test nicht ausführbar: {e}")
    FAILS.append("7 import")

print()
print("ALLES GRÜN" if not FAILS else f"{len(FAILS)} FEHLER: {FAILS}")
sys.exit(1 if FAILS else 0)
