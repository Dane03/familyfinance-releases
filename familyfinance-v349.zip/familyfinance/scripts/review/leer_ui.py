# Review-Skript (Stand v344). In einer KOPIE im Ordner backend/ ausführen; zwischen zwei Läufen ~4 s warten (Port 8420).
# Frische, leere Datenbank (echter Modus, kein Demo): "Erste Schritte", Leerzustände mit Knöpfen, Verschwinden der Karte
# nach den ersten Daten, iPhone ohne seitlichen Überlauf, keine JS-Fehler. Exit-Code 1 bei Befund.
import sys, threading, time, warnings
warnings.filterwarnings("ignore"); sys.path.insert(0, '.')
import database, auth
database.init_db()
import uvicorn, app as appmod
from fastapi.testclient import TestClient
TestClient(appmod.app).post('/api/auth/setup', json={'username': 'tester', 'password': 'testtest123'})
srv = uvicorn.Server(uvicorn.Config(appmod.app, host="127.0.0.1", port=8420, log_level="error"))
threading.Thread(target=srv.run, daemon=True).start(); time.sleep(3)
from playwright.sync_api import sync_playwright
tok = auth._serializer.dumps({'stage': 'full', 'iat': 'x'})
FAILS = []
def check(name, ok, info=""):
    print(("✓ " if ok else "✗ ") + name + (f" – {info}" if info != "" else ""))
    if not ok: FAILS.append(name)
def wait_for(pg, js, tries=40):
    for _ in range(tries):
        try:
            if pg.evaluate(js): return True
        except Exception: pass
        pg.wait_for_timeout(500)
    return False
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True, device_scale_factor=2)
    ctx.add_cookies([{'name': 'ffz_session', 'value': tok, 'url': 'http://localhost:8420'}])
    pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)[:120]))
    pg.goto("http://localhost:8420")
    check("Erste-Schritte-Karte erscheint", wait_for(pg, "getComputedStyle(document.getElementById('first-steps')).display==='block'"))
    check("drei Schritte, keiner erledigt", pg.evaluate("document.querySelectorAll('#first-steps-list .first-step').length") == 3
          and pg.evaluate("document.querySelectorAll('#first-steps-list .first-step-done').length") == 0)
    pg.screenshot(path="/tmp/leer_dashboard.png")
    print("== Sprung")
    pg.locator("#first-steps-list [data-empty-go='tab-income']").first.click(); pg.wait_for_timeout(1200)
    check("Knopf führt zum Einnahmen-Tab", pg.evaluate("getComputedStyle(document.getElementById('tab-income')).display") != "none")
    check("Leerzustand Einnahmen mit Knopf", pg.locator("#income-groups [data-empty-click='add-income-btn']").count() == 1)
    pg.locator("#income-groups [data-empty-click='add-income-btn']").click(); pg.wait_for_timeout(600)
    check("Knopf öffnet den Einnahme-Dialog", pg.evaluate("getComputedStyle(document.getElementById('income-form-overlay')).display") != "none")
    pg.evaluate("document.getElementById('income-form-overlay').style.display='none'")
    pg.evaluate("document.querySelector('[data-tab=tab-contracts]').click()"); pg.wait_for_timeout(1000)
    check("Leerzustand Ausgaben mit Knopf", pg.locator("#contract-groups [data-empty-click='add-expense-btn']").count() == 1)
    check("Seite ohne seitlichen Überlauf", pg.evaluate("document.documentElement.scrollWidth <= screen.width + 1"))
    print("== Erste Daten")
    api = TestClient(appmod.app, base_url="http://localhost:8420")
    api.cookies.set('ffz_session', tok)
    r1 = api.post('/api/income', json={"label": "Gehalt", "amount": 3000, "frequency": "monthly", "category": "Gehalt"})
    r2 = api.post('/api/contracts', json={"label": "Strom", "amount": 60, "frequency": "monthly", "category": "Haus", "subcategory": "Strom"})
    check("Testdaten angelegt", r1.status_code < 300 and r2.status_code < 300, f"{r1.status_code}/{r2.status_code}")
    pg.reload(); pg.wait_for_timeout(500)
    check("Karte verschwindet nach Einnahmen + Ausgaben", wait_for(pg, "document.getElementById('first-steps').style.display==='none' && document.getElementById('duedates-list').innerText.indexOf('Lade')<0"))
    check("keine JS-Fehler", not errs, errs)
    b.close()
print()
if FAILS:
    print("✗ FEHLER:", FAILS); sys.exit(1)
print("ALLES GRÜN")
