# Review-Skript (Stand v328). Ausführen im Ordner backend/ einer KOPIE des Projekts, nie gegen echte Daten:
#   cp -r familyfinance /tmp/ff && cd /tmp/ff/backend && rm -f ../data/*.db && python3 ../scripts/review/themes.py
# Prüft alle Design-Themes auf iPhone-Breite (390 px), in allen Tabs und allen Dialogen (.overlay):
#  - Eingabefelder/Knöpfe ohne sichtbare Kante (Rand UND Fläche heben sich nicht vom Untergrund ab)
#  - Kurz-Einblendung (Toast) lesbar (Kontrast >= 4.5)
#  - color-scheme passt zum Theme (native Auswahllisten/Datumsfelder sonst hell auf dunkel)
# .mode-btn (Umschalter-Leiste, inaktive Seite bewusst ohne Rand) wird ignoriert.
import sys, threading, time
sys.path.insert(0,'.')
import database, auth, demo_data
database.init_db(); demo_data.generate_demo_db()
import uvicorn, app as appmod
from fastapi.testclient import TestClient
TestClient(appmod.app).post('/api/auth/setup',json={'username':'tester','password':'testtest123'})
srv=uvicorn.Server(uvicorn.Config(appmod.app,host="127.0.0.1",port=8420,log_level="error"))
threading.Thread(target=srv.run,daemon=True).start(); time.sleep(3)
from playwright.sync_api import sync_playwright
tok=auth._serializer.dumps({'stage':'full','iat':'x','demo':True})
AUD="""(root) => {
 const R=root?document.getElementById(root):document.querySelector('.tab-panel:not([style*="display: none"])')||document.body;
 const rgb=s=>(s.match(/[\\d.]+/g)||[]).map(Number);
 const lum=c=>{const a=c.slice(0,3).map(v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)});return 0.2126*a[0]+0.7152*a[1]+0.0722*a[2]};
 const mix=(f,b)=>{const a=f.length>3?f[3]:1;return [0,1,2].map(i=>f[i]*a+b[i]*(1-a))};
 const bgOf=e=>{let stack=[];while(e){const c=rgb(getComputedStyle(e).backgroundColor);if(c.length>=3&&(c.length<4||c[3]>0)){stack.push(c);if(c.length<4||c[3]>=0.95)break}e=e.parentElement}let base=[255,255,255];for(let i=stack.length-1;i>=0;i--)base=mix(stack[i],base);return base};
 const cr=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
 const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&e.offsetParent!==null};
 const bad=[...R.querySelectorAll('input:not([type=checkbox]):not([type=radio]):not([type=hidden]):not([type=file]):not([type=range]),select,textarea,button')].filter(vis).filter(e=>{
   const s=getComputedStyle(e); const parentBg=bgOf(e.parentElement); const own=bgOf(e);
   const bw=parseFloat(s.borderTopWidth)||0; const bc=bw?mix(rgb(s.borderTopColor),parentBg):parentBg;
   return cr(bc,parentBg)<1.25 && cr(own,parentBg)<1.08 && !e.matches('.mode-btn,.row-menu-btn,.group-toggle,[data-tab],.tab-btn,.sidebar button');
 });
 return [...new Set(bad.map(e=>e.tagName.toLowerCase()+(e.id?'#'+e.id:'')+(e.className&&typeof e.className==='string'?'.'+e.className.trim().split(/\\s+/)[0]:'')+':'+(e.textContent||e.placeholder||'').trim().slice(0,18)))];
}"""
TOAST="""()=>{const e=document.getElementById('app-toast');const s=getComputedStyle(e);
 const rgb=x=>(x.match(/[\\d.]+/g)||[]).map(Number);
 const lum=c=>{const a=c.slice(0,3).map(v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)});return 0.2126*a[0]+0.7152*a[1]+0.0722*a[2]};
 const x=lum(rgb(s.color)),y=lum(rgb(s.backgroundColor));return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)}"""
THEMES={'dark':'dark','light':'light','nothing':'dark','retro80s':'dark','apple':'light'}
fails=[]
with sync_playwright() as p:
    b=p.chromium.launch()
    for theme,scheme in THEMES.items():
        ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
        ctx.add_cookies([{'name':'ffz_session','value':tok,'url':'http://localhost:8420'}])
        ctx.add_init_script(f"try{{localStorage.setItem('ui_theme','{theme}')}}catch(e){{}}")
        pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)[:150]))
        pg.goto("http://localhost:8420"); pg.wait_for_timeout(2500)
        pg.evaluate(f"document.documentElement.setAttribute('data-theme','{theme}')")
        found={}
        for t in pg.evaluate("[...document.querySelectorAll('[data-tab]')].map(b=>b.dataset.tab)"):
            pg.evaluate(f"document.querySelector('[data-tab=\"{t}\"]').click()"); pg.wait_for_timeout(700)
            r=pg.evaluate(AUD,None)
            if r: found[t]=r
        for ov in pg.evaluate("[...document.querySelectorAll('.overlay')].map(o=>o.id).filter(i=>i&&i!=='auth-overlay')"):
            pg.evaluate(f"document.getElementById('{ov}').style.display='flex'"); pg.wait_for_timeout(100)
            r=pg.evaluate(AUD,ov)
            if r: found[ov]=r
            pg.evaluate(f"document.getElementById('{ov}').style.display='none'")
        pg.evaluate("showToast('Gespeichert')"); pg.wait_for_timeout(400)
        toast=pg.evaluate(TOAST); cs=pg.evaluate("getComputedStyle(document.documentElement).colorScheme")
        n=sum(len(v) for v in found.values())
        print(f"== {theme}: ohne Kante {n} | Toast-Kontrast {toast:.1f} | color-scheme {cs} | JS-Fehler {errs}")
        for k,v in found.items(): print("   ",k,v[:5])
        # Nur helle Themes sind hart: dort waren die Kanten komplett unsichtbar. Dunkle Themes nur Hinweis.
        if scheme=='light' and n: fails.append(f"{theme}: {n} Felder/Knöpfe ohne sichtbare Kante")
        if toast<4.5: fails.append(f"{theme}: Toast-Kontrast {toast:.1f}")
        if cs!=scheme: fails.append(f"{theme}: color-scheme {cs} statt {scheme}")
        if errs: fails.append(f"{theme}: JS-Fehler")
        ctx.close()
    b.close()
print("\nERGEBNIS:", "alles OK" if not fails else "FEHLER: "+"; ".join(fails))
sys.exit(1 if fails else 0)
