"""Gehaltsabrechnung "Übernehmen", Reparatur-Migration (v341) und tägliche Sicherung (v341). Ohne Server, Sekunden.
    cd kopie/backend && python3 ../scripts/review/gehaltsabrechnung.py
Exit-Code 0 = alles grün.

Arbeitet ausschließlich in einem temporären App-Ordner (Datenbank, Belege, Sicherungen); fasst data/ der Kopie
und ~/familyfinance-backups nicht an. Anlass: "Übernehmen" war vom 10. bis 22.10.2026 still kaputt.

Fälle:
 1) POST /api/payslips/{id}/confirm: bestehende Einnahme (Betrag übernommen, Datei in Personen-Ordner, nicht mehr
    "zu prüfen"), neue Einnahme, nur ablegen (Betrag bleibt), kein Betrag erkannt -> 400, unbekannte ID -> 404.
 2) repair_unconfirmed_payslips_once: eindeutiger Treffer wird zugeordnet (Betrag der Einnahme unverändert, Datei
    verschoben), Abrechnung vor dem 10.10. und ohne Treffer bleiben unangetastet, läuft nur einmal.
 3) init_db zweimal hintereinander: keine Änderung am zweiten Lauf (Idempotenz).
 4) maintenance.backup_if_due: ohne Sicherung -> sichert, frische (< 20 h) -> nichts, alte (> 20 h) -> sichert.
"""
import sqlite3
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))

TMP = Path(tempfile.mkdtemp(prefix="ff_gehalt_"))
(TMP / "data").mkdir()

import database  # noqa: E402
import maintenance  # noqa: E402
import receipts_routes as rr  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"
rr.BASE_DIR = TMP
rr.PAYSLIPS_DIR = TMP / "data" / "Gehalt"
maintenance.BASE_DIR = TMP

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


import io, contextlib  # noqa: E402
with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
import auth  # noqa: E402
from fastapi import FastAPI  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

api = FastAPI()
api.include_router(rr.router)
api.dependency_overrides[auth.require_full_auth] = lambda: {"stage": "full"}
cl = TestClient(api, raise_server_exceptions=False)


def db():
    c = sqlite3.connect(database.DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def mk_file(name):
    d = TMP / "data" / "Gehalt" / "Haushalt"
    d.mkdir(parents=True, exist_ok=True)
    p = d / name
    p.write_bytes(b"%PDF-1.4 test")
    return str(p.relative_to(TMP))


c = db()
c.execute("INSERT INTO family_members(name) VALUES ('Testperson')")
pid = c.execute("SELECT id FROM family_members WHERE name='Testperson'").fetchone()[0]
c.execute("INSERT INTO income(label, amount, frequency, active, person_id) VALUES ('Gehalt Testperson', 1000, 'monthly', 1, ?)", (pid,))
inc = c.execute("SELECT id FROM income WHERE label='Gehalt Testperson'").fetchone()[0]


def add_slip(fn, net=2500.0, uploaded="2026-10-15 10:00:00", text="Abrechnung fuer Testperson", review=1, income_id=None):
    cur = c.execute(
        "INSERT INTO payslips(original_filename, stored_path, raw_text, detected_net_amount, detected_month, uploaded_at, review_needed, income_id) "
        "VALUES (?,?,?,?,?,?,?,?)", (fn, mk_file(fn), text, net, "2026-10", uploaded, review, income_id))
    c.commit()
    return cur.lastrowid


print("== 1) Übernehmen-Endpunkt")
s1 = add_slip("a.pdf")
r = cl.post(f"/api/payslips/{s1}/confirm", json={"income_id": inc})
check("bestehende Einnahme: Status 200", r.status_code, 200)
check("bestehende Einnahme: Antwort (mit Stand davor)", r.json(), {"status": "confirmed", "income_id": inc, "previous": {"amount": 1000.0, "source": "manuell"}})
row = c.execute("SELECT * FROM payslips WHERE id=?", (s1,)).fetchone()
check("Abrechnung bestätigt und verknüpft", (row["review_needed"], row["income_id"]), (0, inc))
check("Datei im Personen-Ordner", Path(TMP, row["stored_path"]).exists() and "Testperson" in row["stored_path"], True)
check("Betrag der Einnahme übernommen", c.execute("SELECT amount FROM income WHERE id=?", (inc,)).fetchone()[0], 2500.0)

s2 = add_slip("b.pdf", net=1800.0)
r = cl.post(f"/api/payslips/{s2}/confirm", json={"new_income_label": "Nebenjob"})
check("neue Einnahme: Status 200", r.status_code, 200)
new_id = r.json().get("income_id")
check("neue Einnahme angelegt (Betrag, Quelle)",
      tuple(c.execute("SELECT amount, source FROM income WHERE id=?", (new_id,)).fetchone()), (1800.0, "lohnabrechnung"))

s3 = add_slip("c.pdf", net=9999.0)
r = cl.post(f"/api/payslips/{s3}/confirm", json={"income_id": inc, "update_income": False})
check("nur ablegen: Status 200", r.status_code, 200)
check("nur ablegen: Betrag bleibt", c.execute("SELECT amount FROM income WHERE id=?", (inc,)).fetchone()[0], 2500.0)
check("nur ablegen: bestätigt", c.execute("SELECT review_needed FROM payslips WHERE id=?", (s3,)).fetchone()[0], 0)

s4 = add_slip("d.pdf", net=None)
check("kein Betrag erkannt: 400", cl.post(f"/api/payslips/{s4}/confirm", json={"income_id": inc}).status_code, 400)
check("unbekannte ID: 404", cl.post("/api/payslips/99999/confirm", json={"income_id": inc}).status_code, 404)
check("ungültige Anfrage bleibt 422 (nicht still angenommen)", cl.post(f"/api/payslips/{s4}/confirm", content="x").status_code, 422)

print("== 1b) Rückgängig (Direktübernahme)")
c.execute("UPDATE income SET amount=2500, source='lohnabrechnung' WHERE id=?", (inc,)); c.commit()
s5 = add_slip("e.pdf", net=2600.0)
r = cl.post(f"/api/payslips/{s5}/confirm", json={"income_id": inc})
prev = r.json().get("previous")
check("Übernahme meldet Stand davor", prev, {"amount": 2500.0, "source": "lohnabrechnung"})
check("Betrag geändert", c.execute("SELECT amount FROM income WHERE id=?", (inc,)).fetchone()[0], 2600.0)
r = cl.post(f"/api/payslips/{s5}/undo-confirm", json={"previous_amount": prev["amount"], "previous_source": prev["source"]})
check("Rückgängig: Status 200", r.status_code, 200)
check("Rückgängig: Betrag wieder alt", c.execute("SELECT amount FROM income WHERE id=?", (inc,)).fetchone()[0], 2500.0)
row = c.execute("SELECT review_needed, income_id FROM payslips WHERE id=?", (s5,)).fetchone()
check("Rückgängig: Abrechnung wieder offen", (row["review_needed"], row["income_id"]), (1, None))
check("Rückgängig ohne Übernahme: 404", cl.post(f"/api/payslips/{s5}/undo-confirm", json={}).status_code, 404)
check("Erneut manuell übernehmbar", cl.post(f"/api/payslips/{s5}/confirm", json={"income_id": inc}).status_code, 200)
c.execute("UPDATE income SET amount=1000 WHERE id=?", (inc,))
c.execute("DELETE FROM payslips WHERE id=?", (s5,)); c.commit()

print("== 2) Reparatur-Migration")
c.execute("DELETE FROM payslips WHERE id=?", (s4,))   # Rest aus Teil 1 (ohne Betrag, würde mitrepariert)
c.execute("UPDATE income SET amount=1000 WHERE id=?", (inc,)); c.commit()
r1 = add_slip("Testperson_10.pdf", uploaded="2026-10-12 08:00:00")
r2 = add_slip("alt.pdf", uploaded="2026-10-05 08:00:00", text="Abrechnung fuer Testperson")
r3 = add_slip("xyz.pdf", uploaded="2026-10-13 08:00:00", text="Abrechnung fuer Fremdling")
c.execute("DELETE FROM settings WHERE key='migration_repair_payslip_confirm'"); c.commit()
with contextlib.redirect_stdout(io.StringIO()):
    fixed = rr.repair_unconfirmed_payslips_once(c)
check("genau 1 Abrechnung repariert", fixed, 1)
g = lambda i: c.execute("SELECT review_needed, income_id, stored_path FROM payslips WHERE id=?", (i,)).fetchone()
check("eindeutiger Treffer zugeordnet", (g(r1)[0], g(r1)[1]), (0, inc))
check("Datei in Personen-Ordner verschoben", Path(TMP, g(r1)[2]).exists() and "Testperson" in g(r1)[2], True)
check("vor dem 10.10. unangetastet", (g(r2)[0], g(r2)[1]), (1, None))
check("ohne Treffer unangetastet", (g(r3)[0], g(r3)[1]), (1, None))
check("Betrag der Einnahme unverändert", c.execute("SELECT amount FROM income WHERE id=?", (inc,)).fetchone()[0], 1000.0)
with contextlib.redirect_stdout(io.StringIO()):
    again = rr.repair_unconfirmed_payslips_once(c)
check("zweiter Lauf tut nichts", again, 0)

print("== 3) init_db zweimal (Idempotenz)")
c.close()


def snapshot():
    x = sqlite3.connect(database.DB_PATH)
    out = {t: x.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
           for (t,) in x.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
    out["_index"] = x.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index'").fetchone()[0]
    out["_settings"] = tuple(x.execute("SELECT key, value FROM settings ORDER BY key").fetchall())
    x.close()
    return out


with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
a = snapshot()
with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
b = snapshot()
check("zweiter init_db ändert nichts", a == b, True)

print("== 4) backup_if_due")
real = maintenance.backup_database
calls = []
def fake_backup(*a_, **k_):
    calls.append(1)
    bd = TMP / "data" / "backups"; bd.mkdir(parents=True, exist_ok=True)
    (bd / f"finance_{len(calls)}.db").write_bytes(b"x")
    return {"success": True}
maintenance.backup_database = fake_backup
with contextlib.redirect_stdout(io.StringIO()):
    res = maintenance.backup_if_due()
check("keine Sicherung vorhanden -> sichert", (res is not None, len(calls)), (True, 1))
with contextlib.redirect_stdout(io.StringIO()):
    res = maintenance.backup_if_due()
check("frische Sicherung -> nichts", (res, len(calls)), (None, 1))
old = time.time() - 21 * 3600
for p in (TMP / "data" / "backups").glob("finance_*.db"):
    import os; os.utime(p, (old, old))
with contextlib.redirect_stdout(io.StringIO()):
    res = maintenance.backup_if_due()
check("Sicherung älter als 20 h -> sichert", (res is not None, len(calls)), (True, 2))
maintenance.backup_database = real
# Echte Sicherung in den Temp-Ordner (Belege-Spiegel aus): Datei entsteht und ist eine lesbare Datenbank
res = real(mirror_documents=False)
files = sorted((TMP / "data" / "backups").glob("finance_20*.db"))
check("echte Sicherung erzeugt lesbare Datenbank", (res.get("success"), bool(files) and sqlite3.connect(files[-1]).execute("SELECT COUNT(*) FROM payslips").fetchone()[0] > 0), (True, True))

print()
if FAILS:
    print("✗ FEHLER:", FAILS)
    sys.exit(1)
print("ALLES GRÜN")
