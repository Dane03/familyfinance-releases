"""Routen-Verdrahtung: hängt jede API-Route an der richtigen Funktion? Ohne Server, Sekunden.
    cd kopie/backend && python3 ../scripts/review/routen.py
Exit-Code 0 = alles grün.

Anlass (22.10.2026): Am 10.10. wurde eine Hilfsfunktion zwischen `@router.post("/api/payslips/{payslip_id}/confirm")`
und `def confirm_payslip` eingefügt. Die Route hing danach an der Hilfsfunktion, "Übernehmen" einer
Gehaltsabrechnung scheiterte 12 Tage lang still. Geprüft wird je Route:
- jeder Pfad-Platzhalter ({id} usw.) ist ein Parameter der Funktion,
- die Funktion ist keine interne Hilfsfunktion (Name beginnt nicht mit "_"),
- jede Route aus dem Code ist erreichbar (nicht von einer gleichnamigen Route davor verdeckt).
"""
import inspect
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
import database  # noqa: E402

database.init_db()
import app as appmod  # noqa: E402
from fastapi.routing import APIRoute  # noqa: E402

def _all_routes(routes, prefix=""):
    """Auch Routen aus eingebundenen Routern (neuere FastAPI-Versionen packen sie in _IncludedRouter-Hüllen,
    ältere kopieren sie direkt in app.routes)."""
    for r in routes:
        if isinstance(r, APIRoute):
            yield prefix, r
        inner = getattr(r, "original_router", None)
        if inner is not None:
            ctx = getattr(r, "include_context", None)
            yield from _all_routes(inner.routes, prefix + (getattr(ctx, "prefix", "") or ""))


fails, seen = [], {}
pairs = list(_all_routes(appmod.app.routes))
routes = [r for _, r in pairs]
if len(routes) < 100:
    fails.append(f"nur {len(routes)} Routen gefunden – vermutlich werden eingebundene Router nicht erfasst")
for r in routes:
    fn = r.endpoint
    params = set(inspect.signature(fn).parameters)
    placeholders = set(re.findall(r"{(\w+)(?::\w+)?}", r.path))
    missing = placeholders - params
    where = f"{','.join(sorted(r.methods))} {r.path} -> {fn.__module__}.{fn.__name__}"
    if missing:
        fails.append(f"{where}: Pfad-Platzhalter {sorted(missing)} fehlen in der Funktion")
    if fn.__name__.startswith("_"):
        fails.append(f"{where}: Route hängt an interner Hilfsfunktion")
    for m in r.methods:
        key = (m, r.path)
        if key in seen:
            fails.append(f"{where}: doppelt, verdeckt durch {seen[key]}")
        seen[key] = f"{fn.__module__}.{fn.__name__}"

print(f"{len(routes)} Routen geprüft")
for f in fails:
    print("✗", f)
print("✓ Routen: alle richtig verdrahtet" if not fails else f"✗ {len(fails)} Problem(e)")
sys.exit(1 if fails else 0)
