"""
Gemeinsam genutzte kleine Helfer, die mehrere Route-Module brauchen.

Bewusst ein eigenes Modul statt einer Definition in app.py: Die Route-Module
werden VON app.py eingebunden, ein Import in die Gegenrichtung wäre ein
Zirkelbezug. Hier importiert niemand etwas aus app.py, damit bleibt die
Abhängigkeitsrichtung eindeutig.
"""
import io
import re
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from fastapi.responses import FileResponse, Response

from database import get_connection

BASE_DIR = Path(__file__).resolve().parent.parent

_heif_registered = False


def _ensure_heif_support():
    """HEIC/HEIF-Unterstützung für Pillow einmalig nachrüsten -- Pillow kann
    dieses Format nicht von Haus aus lesen, iPhone-Kamerafotos werden aber
    standardmäßig genau so gespeichert."""
    global _heif_registered
    if not _heif_registered:
        import pillow_heif
        pillow_heif.register_heif_opener()
        _heif_registered = True


def _is_encrypted_pdf(file_path: Path) -> bool:
    """True, wenn die PDF passwortgeschützt ist. Wichtig für die Anzeige:
    ein <iframe> (der In-App-Betrachter) kann den nativen Passwort-Dialog
    von iOS/Safari nicht einblenden -- eine verschlüsselte PDF darin bliebe
    einfach leer, mit einem "Inhalt fehlt"-Symbol statt einer Passwortabfrage.
    Nur der Header wird gelesen, nicht die ganze Datei -- schnell genug, um
    bei jedem Öffnen geprüft zu werden.

    Bewusst zweistufig: manche real vorkommenden PDFs (z.B. aus bestimmter
    Lohnabrechnungs-Software) haben eine Struktur, an der pypdf schon beim
    reinen ÖFFNEN scheitert, ohne die Verschlüsselung überhaupt zu erreichen.
    Ein Fehlschlagen hier fälschlich als "nicht verschlüsselt" zu werten wäre
    die GEFÄHRLICHERE Richtung -- genau das führt zu einer leeren Seite ohne
    jede Passwortabfrage. Schlägt pypdf fehl, wird deshalb ersatzweise direkt
    im rohen Dateiinhalt nach dem PDF-eigenen Merkmal für Verschlüsselung
    gesucht (funktioniert auch bei sonst nicht sauber parsbaren Dateien);
    bleibt auch das ohne Ergebnis, gilt im Zweifel "verschlüsselt" als
    sicherere Annahme -- schlimmstenfalls ein unnötiger Umweg über die
    Wrapper-Seite, statt einer stumm leeren Ansicht ohne jeden Ausweg."""
    try:
        from pypdf import PdfReader
        return PdfReader(file_path).is_encrypted
    except Exception as e:
        print(f"[pdf] Verschlüsselungsprüfung über pypdf fehlgeschlagen ({e}) — weiche auf Rohsuche aus.")
        try:
            # Grobe, aber robuste Ersatzprüfung: jede verschlüsselte PDF nach
            # PDF-Spezifikation referenziert im Trailer ein "/Encrypt"-Objekt.
            with open(file_path, "rb") as f:
                tail = f.read()
            if b"/Encrypt" in tail:
                return True
            return False
        except Exception:
            return True  # im Zweifel lieber einmal zu vorsichtig als stumm leer
        return False


# Nur diese Dateitypen werden im Browser direkt angezeigt. Alles andere (vor
# allem HTML, SVG, XML) würde sonst im Ursprung der App ausgeführt -- ein
# hochgeladener/importierter Beleg "rechnung.html" oder ".svg" könnte dann mit
# der Sitzung des Nutzers beliebige Anfragen stellen (gespeichertes XSS).
# Solche Dateien werden stattdessen immer als Download ausgeliefert.
_INLINE_SAFE_SUFFIXES = {".pdf", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
                         ".tif", ".tiff", ".heic", ".heif", ".txt", ".csv"}


def serve_document_file(file_path: Path, filename: str, inline: bool):
    """Antwort für einen Beleg/ein Dokument -- wandelt HEIC/HEIF beim
    Inline-Anzeigen (nicht beim Download!) transparent in JPEG um.

    Hintergrund: iPhone-Kamerafotos werden standardmäßig als HEIC
    gespeichert. Ein <img>-Tag zeigt HEIC in Safari zwar an, ein <iframe>
    (wie im In-App-Dokumentbetrachter verwendet, damit "Schließen" auf dem
    iOS-Homescreen zuverlässig funktioniert) tut das jedoch NICHT -- die
    Datei erscheint dort nur als leere Seite mit einem "fehlender
    Inhaltstyp"-Symbol. Der Download bleibt bewusst unverändert im
    Originalformat, nur die Inline-Ansicht wird konvertiert.

    Bei PDFs wird zusätzlich per Antwort-Header signalisiert, ob die Datei
    passwortgeschützt ist (siehe _is_encrypted_pdf) -- das Frontend prüft
    das per HEAD-Anfrage, bevor es entscheidet, ob der eigene iframe-
    Betrachter (kann keinen Passwort-Dialog zeigen) übersprungen und
    stattdessen eine echte Browser-Navigation ausgelöst wird."""
    suffix = file_path.suffix.lower()
    if inline and (suffix not in _INLINE_SAFE_SUFFIXES
                   or Path(filename or "").suffix.lower() not in _INLINE_SAFE_SUFFIXES | {""}):
        # (Der Inhaltstyp wird aus dem Anzeigenamen abgeleitet -- deshalb wird
        # auch dessen Endung geprüft; ohne Endung wird es application/octet-stream = harmlos.)
        inline = False
    if inline and suffix in (".heic", ".heif"):
        try:
            _ensure_heif_support()
            from PIL import Image
            with Image.open(file_path) as img:
                buf = io.BytesIO()
                img.convert("RGB").save(buf, format="JPEG", quality=90)
            return Response(content=buf.getvalue(), media_type="image/jpeg")
        except Exception:
            # Umwandlung fehlgeschlagen (z.B. beschädigte Datei) -- lieber
            # das Original ausliefern (funktioniert dann evtl. nur außerhalb
            # des Betrachters), als dem Nutzer nur einen Serverfehler zu zeigen.
            pass
    headers = {}
    if suffix == ".pdf":
        headers["X-Document-Encrypted"] = "true" if _is_encrypted_pdf(file_path) else "false"
    return FileResponse(
        file_path, filename=filename,
        content_disposition_type="attachment" if not inline else "inline",
        headers=headers,
    )


# Jeder der vier Dokumenttypen hat eine eigene Route mit demselben Aufbau
# (stored_path + original_filename in der jeweiligen Tabelle) -- diese
# Zuordnung macht sie über eine einzige, gemeinsame Auflösefunktion nutzbar,
# statt die Lookup-Logik viermal zu duplizieren.
_DOCUMENT_URL_PATTERNS = [
    (re.compile(r"^/api/receipts/(\d+)/file$"), "receipts"),
    (re.compile(r"^/api/payslips/(\d+)/file$"), "payslips"),
    (re.compile(r"^/api/pension-documents/(\d+)$"), "pension_documents"),
    (re.compile(r"^/api/person-documents/(\d+)$"), "person_documents"),
]


def resolve_document_url(url: str) -> Optional[Path]:
    """Bildet eine interne API-URL (z.B. '/api/receipts/5/file') auf den
    zugehörigen Datei-Pfad auf der Festplatte ab, indem die passende Tabelle
    anhand des URL-Musters bestimmt und dort nachgeschlagen wird. Wird vom
    Passwort-Entschlüsseln-Endpunkt gebraucht, der nur die URL kennt (nicht
    Dokumenttyp und ID getrennt), damit er für alle vier Dokumenttypen
    gleichermaßen funktioniert. None, wenn die URL zu keinem bekannten
    Dokumenttyp passt oder der Datensatz/die Datei nicht existiert."""
    path = urlparse(url).path
    for pattern, table in _DOCUMENT_URL_PATTERNS:
        m = pattern.match(path)
        if not m:
            continue
        doc_id = m.group(1)
        conn = get_connection()
        row = conn.execute(f"SELECT stored_path FROM {table} WHERE id=?", (doc_id,)).fetchone()
        conn.close()
        if not row:
            return None
        file_path = BASE_DIR / row["stored_path"]
        return file_path if file_path.exists() else None
    return None


def monthly_expr(amount_col: str, freq_col: str, split_col: Optional[str] = None) -> str:
    """Baut einen SQL-Ausdruck, der einen Betrag unabhängig von seinem
    Zahlungsintervall auf einen Monatswert normalisiert — damit lassen sich
    monatliche, quartalsweise und jährliche Posten direkt vergleichen und
    summieren."""
    amt = f"{amount_col}*{split_col}" if split_col else amount_col
    return (f"CASE {freq_col} WHEN 'monthly' THEN {amt} "
            f"WHEN 'quarterly' THEN {amt}/3.0 WHEN 'yearly' THEN {amt}/12.0 END")


def monthly_amount(amount, frequency) -> float:
    """Python-Gegenstück zu monthly_expr: Betrag eines Intervalls (monthly/quarterly/yearly) als Monatswert."""
    amount = amount or 0
    if frequency == "quarterly":
        return amount / 3.0
    if frequency == "yearly":
        return amount / 12.0
    return amount


def _person_folder_slug(person_name: Optional[str]) -> str:
    """Ordnername für die Personen-Ebene, die laut neuer Speicherstruktur
    JEDEM Dokument-Themenbereich als zweite Ebene folgt (Themenbereich/
    Person/...) -- auch haushaltsweite Dokumente ohne konkrete Person
    brauchen dafür einen Platzhalter, statt diese Ebene einfach
    auszulassen, sonst wäre die Struktur nicht mehr durchgängig."""
    return re.sub(r"[^\w.-]", "_", person_name) if person_name else "Haushalt"


def _contract_folder_parts(category_name: str, subcategory: Optional[str],
                            provider: Optional[str], label: str,
                            person_name: Optional[str] = None) -> list:
    """Die Ordner-Teilpfade für die Ablage eines Vertrags, UNTERHALB des
    Themenbereich-Wurzelordners (z.B. "Ausgaben") -- dieselbe Logik wie
    beim Einsortieren eines bestätigten Belegs, damit Archivieren denselben
    Ordner wiederfindet, den confirm_receipt angelegt hat.

    Reihenfolge bewusst Person ZUERST, erst danach Kategorie: die
    Speicherstruktur soll durchgängig "Themenbereich/Person/..." sein,
    nicht nur für Verträge mit einer individuellen Personen-Zuordnung --
    haushaltsweite Verträge (keine Personen-Zuordnung) landen deshalb
    unter einem "Haushalt"-Platzhalter statt die Ebene auszulassen, damit
    die Struktur über alle Dokumenttypen hinweg gleich bleibt."""
    category_slug = re.sub(r"[^\w.-]", "_", category_name or "Sonstiges")
    contract_slug = re.sub(r"[^\w.-]", "_", (provider or label or "Vertrag"))[:60]
    parts = [_person_folder_slug(person_name), category_slug]
    if subcategory:
        parts.append(re.sub(r"[^\w.-]", "_", subcategory))
    parts.append(contract_slug)
    return parts



# ---------- Content-Security-Policy ----------
# Verbietet Inline-Skripte und fremde Quellen: Selbst wenn irgendwo ein
# ungefilterter Text in innerHTML landet, kann daraus kein Code mehr laufen.
# Inline-STYLES bleiben erlaubt (die Oberfläche nutzt style="…" sehr häufig;
# darüber lässt sich kein Code ausführen). Vom Server erzeugte Seiten mit
# eigenem Skript (PDF-Betrachter) erlauben genau dieses Skript per Nonce.
def content_security_policy(nonce: str | None = None) -> str:
    script_src = "'self'" + (f" 'nonce-{nonce}'" if nonce else "")
    return "; ".join([
        "default-src 'self'",
        f"script-src {script_src}",
        "style-src 'self' 'unsafe-inline'",
        "img-src 'self' data: blob:",
        "font-src 'self' data:",
        "connect-src 'self'",
        "worker-src 'self' blob:",
        "frame-src 'self' blob:",
        "object-src 'none'",
        "base-uri 'none'",
        "form-action 'self'",
        "frame-ancestors 'self'",
        "manifest-src 'self'",
    ])


_DOC_TABLES = {"receipts", "payslips", "pension_documents", "person_documents"}


def locate_document_file(table: str, row_id: int, stored_path: str):
    """Findet die Datei zu einem Beleg/Dokument -- auch wenn sie inzwischen
    woanders unter data/ liegt (z.B. Ordner nach Umbenennen eines Vertrags
    verschoben, Projekt-Umzug, von Hand in Finder umsortiert). Wird sie
    gefunden, wird stored_path in der DB gleich mit korrigiert.

    Suche: 1) gespeicherter Pfad, 2) gleicher Dateiname irgendwo unter data/
    (bei mehreren Treffern nur der mit passender Prüfsumme), 3) gleiche
    Prüfsumme (file_hash) bei Dateien gleicher Endung.
    Rückgabe: (Path | None, icloud_placeholder: bool)."""
    import hashlib
    if table not in _DOC_TABLES:
        raise ValueError(table)
    file_path = BASE_DIR / (stored_path or "")
    if stored_path and file_path.is_file():
        return file_path, False
    # iCloud "Mac-Speicher optimieren": Datei ausgelagert, nur Platzhalter da.
    if stored_path and (file_path.parent / f".{file_path.name}.icloud").exists():
        return None, True

    data_dir = BASE_DIR / "data"
    if not data_dir.is_dir():
        return None, False
    conn = get_connection()
    try:
        cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        file_hash = None
        if "file_hash" in cols:
            row = conn.execute(f"SELECT file_hash FROM {table} WHERE id=?", (row_id,)).fetchone()
            file_hash = row["file_hash"] if row else None

        def _hash(p: Path) -> str:
            return hashlib.sha256(p.read_bytes()).hexdigest()

        found = None
        name = Path(stored_path or "").name
        if name:
            candidates = [p for p in data_dir.rglob(name) if p.is_file() and "backups" not in p.parts]
            if len(candidates) == 1 and (not file_hash or _hash(candidates[0]) == file_hash):
                found = candidates[0]
            elif file_hash:
                found = next((p for p in candidates if _hash(p) == file_hash), None)
        if not found and file_hash:
            suffix = Path(stored_path or "").suffix.lower()
            for p in data_dir.rglob(f"*{suffix}" if suffix else "*"):
                if p.is_file() and "backups" not in p.parts and _hash(p) == file_hash:
                    found = p
                    break
        if found:
            conn.execute(f"UPDATE {table} SET stored_path=? WHERE id=?",
                         (str(found.relative_to(BASE_DIR)), row_id))
            conn.commit()
        return found, False
    finally:
        conn.close()


def missing_document_message(icloud: bool, what: str = "Datei") -> str:
    if icloud:
        return (f"{what} liegt nur in iCloud (Mac-Speicher optimieren). Im Finder im Ordner "
                "familyfinance/data mit Rechtsklick „Jetzt laden“ wählen, oder für den Ordner "
                "„Immer auf diesem Gerät behalten“ aktivieren.")
    return f"{what} fehlt auf der Festplatte (auch unter data/ nicht gefunden)."


def missing_document_response(icloud: bool, what: str, download: bool):
    """Fehlende Datei: beim Anzeigen (im Betrachter/neuen Tab) eine lesbare
    Seite statt rohem JSON {"detail": ...}; beim Download weiter JSON-Fehler."""
    import html as _html
    from fastapi.responses import HTMLResponse, JSONResponse
    msg = missing_document_message(icloud, what)
    if download:
        return JSONResponse(status_code=404, content={"detail": msg})
    page = ("<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width'>"
            "<body style='font-family:-apple-system,system-ui,sans-serif;padding:24px;line-height:1.5;"
            "color:#333;background:#fff'><h3 style='margin-top:0'>📄 Datei nicht verfügbar</h3>"
            f"<p>{_html.escape(msg)}</p></body>")
    return HTMLResponse(page, status_code=404)
