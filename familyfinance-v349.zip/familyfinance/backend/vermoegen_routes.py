"""
Vermögen — Konten, Depots, Immobilien, Sonstiges; Depot-Positionen,
Ziel-Allokation, Vermögensverlauf, Steuer-/Förderungsübersicht sowie die
zusammenfassende Vermögensauswertung.

Aus app.py herausgelöst, um die zentrale Datei überschaubar zu halten. Die
Routen sind unverändert übernommen und werden über einen APIRouter in app.py
eingebunden — die URLs bleiben exakt dieselben wie vorher.
"""
import hashlib
import re
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel

import auth
import vorsorge  # noqa: F401  (Projektmodul: Import bewusst belassen)
from database import get_connection
from shared_helpers import monthly_expr, monthly_amount, _person_folder_slug

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent
RECEIPTS_DIR = BASE_DIR / "data" / "Ausgaben"
VERMOEGEN_DIR = BASE_DIR / "data" / "Vermoegen"

# ---------- Vermögensübersicht: Konten, Depots, Immobilien, Sonstiges ----------

class AssetIn(BaseModel):
    type: str                       # 'konto' | 'immobilie' | 'depot' | 'sonstiges'
    label: str
    provider: Optional[str] = None
    account_number: Optional[str] = None
    account_type: Optional[str] = None   # nur für 'konto': 'giro' | 'tagesgeld' | 'festgeld'
    purpose: Optional[str] = None
    person_id: Optional[int] = None
    current_value: Optional[float] = None
    financing_contract_ids: Optional[List[int]] = None  # mehrere Darlehen möglich (Immobilie)
    note: Optional[str] = None
    exclude_from_networth: Optional[bool] = False   # zählt nicht zum Gesamtvermögen (auch rückwirkend)


class AssetPatch(BaseModel):
    label: Optional[str] = None
    provider: Optional[str] = None
    account_number: Optional[str] = None
    account_type: Optional[str] = None
    purpose: Optional[str] = None
    person_id: Optional[int] = None
    current_value: Optional[float] = None
    financing_contract_ids: Optional[List[int]] = None
    note: Optional[str] = None
    exclude_from_networth: Optional[bool] = None


class AssetHoldingIn(BaseModel):
    isin: Optional[str] = None
    name: str
    current_value: float
    asset_class: Optional[str] = None   # 'aktie' | 'anleihe' | 'cash' | 'rohstoffe' | 'sonstiges'
    region: Optional[str] = None        # 'usa' | 'europa' | 'schwellenlaender' |
                                         # 'sonstige_industrielaender' | 'global' | 'sonstiges'


class AssetHoldingPatch(BaseModel):
    isin: Optional[str] = None
    name: Optional[str] = None
    current_value: Optional[float] = None
    asset_class: Optional[str] = None
    region: Optional[str] = None


def _set_asset_financing_links(conn, asset_id: int, contract_ids: List[int]):
    """Ersetzt die komplette Menge verknüpfter Finanzierungsverträge für
    eine Immobilie durch die übergebene Liste — einfacher und robuster als
    einzelne Verknüpfungen zeilenweise abzugleichen, bei der überschaubaren
    Anzahl an Darlehen pro Immobilie (in der Praxis 1-3)."""
    conn.execute("DELETE FROM asset_financing_links WHERE asset_id=?", (asset_id,))
    for cid in set(contract_ids or []):
        conn.execute(
            "INSERT OR IGNORE INTO asset_financing_links (asset_id, contract_id) VALUES (?,?)",
            (asset_id, cid),
        )


def _asset_financing_details(conn, asset_id: int) -> list:
    rows = conn.execute(
        """SELECT co.id, co.label, co.remaining_debt, co.interest_rate, co.repayment_rate, co.amount, co.frequency
           FROM asset_financing_links afl JOIN contracts co ON co.id = afl.contract_id
           WHERE afl.asset_id = ? AND co.status = 'active'""",
        (asset_id,),
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/api/assets")
def list_assets(archived: bool = False, session=Depends(auth.require_full_auth)):
    """Standard: nur aktive Vermögenswerte. archived=true liefert das Archiv."""
    conn = get_connection()
    rows = conn.execute(
        f"""SELECT a.*, fm.name AS person_name
           FROM assets a
           LEFT JOIN family_members fm ON fm.id = a.person_id
           WHERE a.archived_at IS {"NOT NULL" if archived else "NULL"}
           ORDER BY a.type, a.label"""
    ).fetchall()
    result = []
    for r in rows:
        entry = dict(r)
        entry.pop("linked_contract_id", None)  # LEGACY-Feld, nicht mehr nach außen geben
        entry["financing_contracts"] = _asset_financing_details(conn, r["id"]) if r["type"] == "immobilie" else []
        result.append(entry)
    conn.close()
    return result


VALID_ACCOUNT_TYPES = {"giro", "tagesgeld", "festgeld"}


@router.post("/api/assets")
def create_asset(payload: AssetIn, session=Depends(auth.require_full_auth)):
    if payload.account_type and payload.account_type not in VALID_ACCOUNT_TYPES:
        raise HTTPException(400, f"Ungültige Kontoart: {payload.account_type}")
    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO assets (type, label, provider, account_number, account_type, purpose, person_id, current_value, note,
                               exclude_from_networth, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (payload.type, payload.label, payload.provider, payload.account_number, payload.account_type,
         payload.purpose, payload.person_id, payload.current_value, payload.note, 1 if payload.exclude_from_networth else 0,
         datetime.now().strftime("%Y-%m-%d")),
    )
    asset_id = cur.lastrowid
    if payload.financing_contract_ids is not None:
        _set_asset_financing_links(conn, asset_id, payload.financing_contract_ids)
    conn.commit()
    conn.close()
    return {"id": asset_id, "status": "created"}


@router.patch("/api/assets/{asset_id}")
def update_asset(asset_id: int, payload: AssetPatch, session=Depends(auth.require_full_auth)):
    if payload.account_type and payload.account_type not in VALID_ACCOUNT_TYPES:
        raise HTTPException(400, f"Ungültige Kontoart: {payload.account_type}")
    fields = {k: v for k, v in payload.dict(exclude_unset=True).items() if k != "financing_contract_ids"}
    if "exclude_from_networth" in fields:
        fields["exclude_from_networth"] = 1 if fields["exclude_from_networth"] else 0
    conn = get_connection()
    existing = conn.execute("SELECT id FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")
    if fields:
        fields["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE assets SET {set_clause} WHERE id=?", (*fields.values(), asset_id))
    if payload.financing_contract_ids is not None:
        _set_asset_financing_links(conn, asset_id, payload.financing_contract_ids)
    conn.commit()
    conn.close()
    return {"status": "updated"}


@router.delete("/api/assets/{asset_id}")
def archive_asset(asset_id: int, session=Depends(auth.require_full_auth)):
    """'Löschen' archiviert den Vermögenswert, statt ihn hart zu entfernen: Belege,
    Depotpositionen, Finanzierungs-Verknüpfungen und die Verknüpfung zum Bankkonto
    (und damit dessen Umsätze) bleiben unverändert erhalten. Der Eintrag verschwindet
    nur aus Übersicht, Summen und Auswahllisten und lässt sich wiederherstellen."""
    conn = get_connection()
    existing = conn.execute("SELECT id, archived_at FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")
    if not existing["archived_at"]:
        conn.execute("UPDATE assets SET archived_at=? WHERE id=?", (datetime.now().isoformat(), asset_id))
        conn.commit()
    conn.close()
    return {"status": "archived"}


@router.post("/api/assets/{asset_id}/restore")
def restore_asset(asset_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id, archived_at FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")
    if not existing["archived_at"]:
        conn.close()
        raise HTTPException(400, "Dieser Vermögenswert ist nicht archiviert.")
    conn.execute("UPDATE assets SET archived_at=NULL WHERE id=?", (asset_id,))
    conn.commit()
    conn.close()
    return {"status": "restored"}


@router.get("/api/assets/{asset_id}/holdings")
def list_asset_holdings(asset_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM asset_holdings WHERE asset_id=? ORDER BY current_value DESC", (asset_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


VALID_ASSET_CLASSES = {"aktie", "anleihe", "cash", "rohstoffe", "sonstiges"}
VALID_REGIONS = {"usa", "europa", "schwellenlaender", "sonstige_industrielaender", "global", "sonstiges"}


def _validate_holding_class_region(asset_class: Optional[str], region: Optional[str]):
    """Unbekannte Werte fallen sonst stillschweigend in eine 'unbekannt'-
    Sammelkategorie bei der Allokations-Auswertung — ein Tippfehler bliebe
    unbemerkt statt eine klare Fehlermeldung zu bekommen."""
    if asset_class and asset_class not in VALID_ASSET_CLASSES:
        raise HTTPException(400, f"Ungültige Asset-Klasse: {asset_class}")
    if region and region not in VALID_REGIONS:
        raise HTTPException(400, f"Ungültige Region: {region}")


@router.post("/api/assets/{asset_id}/holdings")
def create_asset_holding(asset_id: int, payload: AssetHoldingIn, session=Depends(auth.require_full_auth)):
    _validate_holding_class_region(payload.asset_class, payload.region)
    conn = get_connection()
    asset = conn.execute("SELECT id FROM assets WHERE id=?", (asset_id,)).fetchone()
    if not asset:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")
    cur = conn.execute(
        """INSERT INTO asset_holdings (asset_id, isin, name, current_value, asset_class, region)
           VALUES (?,?,?,?,?,?)""",
        (asset_id, payload.isin, payload.name, payload.current_value, payload.asset_class, payload.region),
    )
    conn.commit()
    holding_id = cur.lastrowid
    conn.close()
    return {"id": holding_id, "status": "created"}


@router.patch("/api/asset-holdings/{holding_id}")
def update_asset_holding(holding_id: int, payload: AssetHoldingPatch, session=Depends(auth.require_full_auth)):
    _validate_holding_class_region(payload.asset_class, payload.region)
    fields = {k: v for k, v in payload.dict(exclude_unset=True).items()}
    conn = get_connection()
    existing = conn.execute("SELECT id FROM asset_holdings WHERE id=?", (holding_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Position nicht gefunden")
    if fields:
        fields["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE asset_holdings SET {set_clause} WHERE id=?", (*fields.values(), holding_id))
        conn.commit()
    conn.close()
    return {"status": "updated"}


@router.delete("/api/asset-holdings/{holding_id}")
def delete_asset_holding(holding_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM asset_holdings WHERE id=?", (holding_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/assets/{asset_id}/receipts")
def list_asset_receipts(asset_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT id, original_filename, uploaded_at, detected_amount, detected_date FROM receipts WHERE asset_id=? ORDER BY uploaded_at DESC",
        (asset_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.post("/api/assets/{asset_id}/bulk-upload-receipts")
async def bulk_upload_asset_receipts(asset_id: int, files: List[UploadFile] = File(...),
                                      session=Depends(auth.require_full_auth)):
    """Mehrere Belege auf einmal zu einem Vermögenswert — für den initialen
    Import einer ganzen Kontoauszugs-/Depotauszugs-Historie. Aktualisiert
    NIE automatisch current_value, auch nicht durch die neueste Datei im
    Stapel — derselbe Grundsatz wie beim Gehalts- und Vertrags-Sammelimport."""
    conn = get_connection()
    asset = conn.execute(
        "SELECT a.type, a.label, fm.name AS person_name FROM assets a "
        "LEFT JOIN family_members fm ON fm.id = a.person_id WHERE a.id=?",
        (asset_id,),
    ).fetchone()
    if not asset:
        conn.close()
        raise HTTPException(404, "Vermögenswert nicht gefunden")

    final_dir = VERMOEGEN_DIR / _person_folder_slug(asset["person_name"]) / re.sub(r"[^\w\-]", "_", asset["label"])
    final_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        existing = conn.execute(
            "SELECT id FROM receipts WHERE asset_id=? AND file_hash=?", (asset_id, file_hash)
        ).fetchone()
        if existing:
            results.append({"receipt_id": existing["id"], "filename": file.filename, "skipped": True})
            continue

        safe_name = re.sub(r"[^\w.\-]", "_", file.filename or "beleg")
        stored_path = final_dir / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{safe_name}"
        stored_path.write_bytes(content)

        cur = conn.execute(
            """INSERT INTO receipts (original_filename, stored_path, file_hash, asset_id, review_needed)
               VALUES (?,?,?,?,0)""",
            (file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash, asset_id),
        )
        results.append({"receipt_id": cur.lastrowid, "filename": file.filename, "skipped": False})

    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}



def _asset_bucket_value(conn, a) -> tuple:
    """(Topf, Wert) eines Vermögenswerts für das Gesamtvermögen — dieselbe Einteilung wie in der Übersicht:
    Immobilie -> immobilien_netto (Wert − Restschuld der verknüpften aktiven Darlehen),
    Zweck Altersvorsorge -> pension_capital, sonst -> liquid."""
    if a["type"] == "immobilie":
        debt = conn.execute(
            """SELECT COALESCE(SUM(co.remaining_debt), 0) AS d FROM asset_financing_links afl
               JOIN contracts co ON co.id = afl.contract_id WHERE afl.asset_id=? AND co.status='active'""",
            (a["id"],),
        ).fetchone()["d"]
        return "immobilien_netto", (a["current_value"] or 0) - (debt or 0)
    if (a["purpose"] or "").lower() == "altersvorsorge":
        return "pension_capital", a["current_value"] or 0
    return "liquid", a["current_value"] or 0


def _compute_networth_totals(conn, include_excluded: bool = False) -> dict:
    """Berechnet nur die vier Kopfzahlen (liquid, pension_capital,
    immobilien_netto, gesamt) — bewusst eigenständige, leichtgewichtige
    Variante der Logik aus vermoegen_overview (ohne Gruppen, Holdings-
    Allokation, Projektion), für den täglichen Snapshot ohne den vollen
    Overhead und ohne die bereits getestete Haupt-Route anzufassen.
    include_excluded=True: auch als "nicht im Gesamtvermögen" markierte Vermögenswerte mitzählen
    (Rohsumme für networth_snapshots; der Verlauf zieht sie wieder ab)."""
    assets = conn.execute("SELECT * FROM assets WHERE archived_at IS NULL").fetchall()
    pension_rows = conn.execute(
        "SELECT current_value FROM pension_accounts WHERE type='privat' AND current_value IS NOT NULL"
    ).fetchall()
    altersvorsorge_contracts = conn.execute(
        """SELECT co.amount FROM contracts co JOIN categories c ON c.id = co.category_id
           WHERE LOWER(c.name) = 'altersvorsorge' AND co.status = 'active'
           AND co.id NOT IN (SELECT linked_contract_id FROM pension_accounts WHERE linked_contract_id IS NOT NULL)"""
    ).fetchall()

    buckets = {"liquid": 0.0, "pension_capital": 0.0, "immobilien_netto": 0.0}
    for a in assets:
        if a["exclude_from_networth"] and not include_excluded:
            continue
        bucket, value = _asset_bucket_value(conn, a)
        buckets[bucket] += value

    pension_capital = (
        sum(p["current_value"] or 0 for p in pension_rows)
        + sum(c["amount"] or 0 for c in altersvorsorge_contracts)
        + buckets["pension_capital"]
    )
    total_networth = buckets["liquid"] + pension_capital + buckets["immobilien_netto"]
    return {
        "liquid": round(buckets["liquid"], 2),
        "pension_capital": round(pension_capital, 2),
        "immobilien_netto": round(buckets["immobilien_netto"], 2),
        "gesamt": round(total_networth, 2),
    }


def save_networth_snapshot():
    """Schreibt eine Momentaufnahme des Gesamtvermögens für den heutigen Tag
    — überschreibt einen eventuell bereits heute vorhandenen Eintrag statt
    Duplikate anzuhäufen (z.B. bei mehreren Neustarts am selben Tag).
    Gespeichert wird die Summe über ALLE Vermögenswerte plus der Wert je Vermögenswert
    (networth_snapshot_items) — daraus rechnet der Verlauf ausgeschlossene Werte rückwirkend heraus."""
    conn = get_connection()
    totals = _compute_networth_totals(conn, include_excluded=True)
    today = datetime.now().strftime("%Y-%m-%d")
    conn.execute(
        """INSERT INTO networth_snapshots (snapshot_date, total_networth, liquid, pension_capital, immobilien_netto)
           VALUES (?,?,?,?,?)
           ON CONFLICT(snapshot_date) DO UPDATE SET
             total_networth=excluded.total_networth, liquid=excluded.liquid,
             pension_capital=excluded.pension_capital, immobilien_netto=excluded.immobilien_netto""",
        (today, totals["gesamt"], totals["liquid"], totals["pension_capital"], totals["immobilien_netto"]),
    )
    conn.execute("DELETE FROM networth_snapshot_items WHERE snapshot_date=?", (today,))
    for a in conn.execute("SELECT * FROM assets WHERE archived_at IS NULL").fetchall():
        bucket, value = _asset_bucket_value(conn, a)
        conn.execute("INSERT INTO networth_snapshot_items (snapshot_date, asset_id, bucket, value) VALUES (?,?,?,?)",
                     (today, a["id"], bucket, round(value, 2)))
    conn.commit()
    conn.close()


def _bank_balance_at(conn, asset_id: int):
    """Kontostand eines mit der Bank verbundenen Kontos am Ende eines Tages, zurückgerechnet aus dem heutigen Saldo
    und den Umsätzen danach. Liefert eine Funktion date_str -> Saldo, oder None ohne Bankverbindung.
    Vor dem ersten bekannten Umsatz fehlen Umsätze -> dann der Stand vor dem ersten bekannten Umsatz."""
    accs = conn.execute("SELECT id, balance FROM bank_accounts WHERE asset_id=? AND ignored=0 AND balance IS NOT NULL",
                        (asset_id,)).fetchall()
    if not accs:
        return None
    tx = conn.execute(
        f"""SELECT booking_date, amount FROM bank_transactions
            WHERE bank_account_id IN ({",".join("?" for _ in accs)}) AND booking_date IS NOT NULL
            ORDER BY booking_date""", [a["id"] for a in accs]).fetchall()
    balance_now = sum(a["balance"] or 0 for a in accs)
    first = tx[0]["booking_date"] if tx else None

    def at(day: str) -> float:
        if first and day < first:
            day = first[:10]
            later = sum(t["amount"] or 0 for t in tx if t["booking_date"] >= day)   # Stand VOR dem ersten Umsatz
        else:
            later = sum(t["amount"] or 0 for t in tx if t["booking_date"] > day)
        return balance_now - later
    return at


def _excluded_history_adjustments(conn, dates: list) -> tuple:
    """Je Momentaufnahme-Datum, was für die als "nicht im Gesamtvermögen" markierten Vermögenswerte abzuziehen ist:
    ({datum: {"liquid": x, "pension_capital": y, "immobilien_netto": z}}, {datum: geschätzt?}).
    Liegt für das Datum ein Einzelwert vor (networth_snapshot_items, seit v327), wird genau dieser abgezogen.
    Ältere Momentaufnahmen kennen nur die Summe -> Schätzung: Bankkonto aus Saldo und Umsätzen zurückgerechnet,
    sonst der älteste gespeicherte Einzelwert, sonst der heutige Wert. Vor dem Anlagedatum und nach der
    Archivierung zählte ein Wert ohnehin nicht mit -> dort nichts abziehen."""
    excluded = conn.execute("SELECT * FROM assets WHERE exclude_from_networth=1").fetchall()
    adj = {d: {"liquid": 0.0, "pension_capital": 0.0, "immobilien_netto": 0.0} for d in dates}
    estimated = {d: False for d in dates}
    if not excluded or not dates:
        return adj, estimated
    for a in excluded:
        items = {r["snapshot_date"]: r for r in conn.execute(
            "SELECT snapshot_date, bucket, value FROM networth_snapshot_items WHERE asset_id=? ORDER BY snapshot_date",
            (a["id"],)).fetchall()}
        oldest = next(iter(items.values()), None)
        bucket_now, value_now = _asset_bucket_value(conn, a)
        bank_at = _bank_balance_at(conn, a["id"]) if a["type"] in ("konto",) else None
        archived = (a["archived_at"] or "")[:10] or None
        created = (a["created_at"] or "")[:10] or None
        for d in dates:
            if d in items:
                adj[d][items[d]["bucket"]] += items[d]["value"]
                continue
            if archived and d >= archived:
                continue
            if created and d < created:
                continue   # gab es an dem Tag noch nicht -> war auch nicht in der Summe
            if oldest and d > oldest["snapshot_date"]:
                continue   # nach Beginn der Einzelwerte, aber ohne Eintrag: Wert existierte an dem Tag nicht
            if bank_at:
                value, bucket = bank_at(d), bucket_now
            elif oldest:
                value, bucket = oldest["value"], oldest["bucket"]
            else:
                value, bucket = value_now, bucket_now
            adj[d][bucket] += value
            estimated[d] = True
    return adj, estimated


class AllocationTargetIn(BaseModel):
    asset_class: str
    target_percent: float


@router.get("/api/vermoegen/allocation-targets")
def get_allocation_targets(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM allocation_targets").fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.put("/api/vermoegen/allocation-targets")
def set_allocation_targets(payload: List[AllocationTargetIn], session=Depends(auth.require_full_auth)):
    """Ersetzt die komplette Soll-Allokation auf einmal — einfacher als
    einzelne Werte abzugleichen, bei einer überschaubaren Anzahl Klassen."""
    conn = get_connection()
    conn.execute("DELETE FROM allocation_targets")
    for t in payload:
        conn.execute(
            "INSERT INTO allocation_targets (asset_class, target_percent) VALUES (?,?)",
            (t.asset_class, t.target_percent),
        )
    conn.commit()
    conn.close()
    return {"status": "updated"}


@router.get("/api/vermoegen/history")
def vermoegen_history(session=Depends(auth.require_full_auth)):
    """Verlauf des Gesamtvermögens. Als "nicht im Gesamtvermögen" markierte Vermögenswerte werden für ALLE Tage
    herausgerechnet (rückwirkend). 'estimated' = für diesen Tag war der Einzelwert nicht gespeichert und ist geschätzt."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT snapshot_date, total_networth, liquid, pension_capital, immobilien_netto "
        "FROM networth_snapshots ORDER BY snapshot_date ASC"
    ).fetchall()
    dates = [r["snapshot_date"] for r in rows]
    adj, estimated = _excluded_history_adjustments(conn, dates)
    conn.close()
    out = []
    for r in rows:
        d, a = r["snapshot_date"], adj[r["snapshot_date"]]
        liquid = (r["liquid"] or 0) - a["liquid"]
        pension = (r["pension_capital"] or 0) - a["pension_capital"]
        immo = (r["immobilien_netto"] or 0) - a["immobilien_netto"]
        out.append({
            "snapshot_date": d,
            "total_networth": round((r["total_networth"] or 0) - sum(a.values()), 2),
            "liquid": round(liquid, 2), "pension_capital": round(pension, 2), "immobilien_netto": round(immo, 2),
            "estimated": estimated[d],
        })
    return out


SPARERPAUSCHBETRAG_PRO_PERSON = 1000.0  # Stand 2026, unverändert seit 2023 (§ 20 Abs. 9 EStG)
RIESTER_GRUNDZULAGE = 175.0             # Stand 2026, unverändert seit 2018
RIESTER_KINDERZULAGE_PRO_KIND = 300.0   # für nach 2008 geborene Kinder


@router.get("/api/steuer/overview")
def steuer_overview(session=Depends(auth.require_full_auth)):
    """Freistellungsauftrag- und Riester-Förderungs-Übersicht. Bewusst
    einfach gehalten: kein Steuerberater-Ersatz, sondern eine grobe
    Orientierung anhand öffentlich bekannter Eckwerte (Stand 2026)."""
    conn = get_connection()
    members = conn.execute(
        "SELECT * FROM family_members WHERE role='elternteil' ORDER BY sort_order"
    ).fetchall()
    kids_count = conn.execute(
        "SELECT COUNT(*) AS n FROM family_members WHERE role='kind'"
    ).fetchone()["n"]

    freistellung = []
    for m in members:
        used = m["freistellungsauftrag_used"] or 0
        freistellung.append({
            "person_name": m["name"],
            "allowance": SPARERPAUSCHBETRAG_PRO_PERSON,
            "used": used,
            "remaining": round(SPARERPAUSCHBETRAG_PRO_PERSON - used, 2),
        })

    riester_accounts = conn.execute(
        """SELECT pa.id, pa.label, pa.provider, fm.name AS person_name
           FROM pension_accounts pa JOIN family_members fm ON fm.id = pa.person_id
           WHERE pa.is_riester = 1"""
    ).fetchall()
    conn.close()

    riester = [{
        "id": r["id"], "label": r["label"], "provider": r["provider"], "person_name": r["person_name"],
        "grundzulage": RIESTER_GRUNDZULAGE,
        "kinderzulage_max": round(kids_count * RIESTER_KINDERZULAGE_PRO_KIND, 2),
        "zulage_gesamt_max": round(RIESTER_GRUNDZULAGE + kids_count * RIESTER_KINDERZULAGE_PRO_KIND, 2),
    } for r in riester_accounts]

    return {
        "freistellungsauftrag": freistellung,
        "riester": riester,
        "riester_note": (
            "Die Kinderzulage fließt automatisch in den Vertrag des Elternteils, "
            "der das Kindergeld bezieht — hier als Maximalbetrag je Riester-Vertrag "
            "gezeigt, nicht automatisch einem Elternteil zugeordnet."
        ),
    }


@router.get("/api/vermoegen/overview")
def vermoegen_overview(session=Depends(auth.require_full_auth)):
    """Aggregiert Vermögenswerte aus mehreren, bereits bestehenden Quellen zu
    EINER Übersicht, statt Daten zu duplizieren:
    - assets (Konten, Depots, sonstige Anlagen, Immobilien) — hier neu erfasst
    - pension_accounts (Altersvorsorge) — bereits unter Vorsorge gepflegt,
      werden hier als EIGENE, sichtbare Einträge geführt (nicht nur als
      stille Summe). Nur die private (kapitalbildende) Vorsorge zählt als
      Vermögen; die gesetzliche Rente ist eine künftige Zahlung, kein heute
      verfügbares Kapital, und fließt daher bewusst NICHT ein.
    - Verträge unter Ausgaben mit Kategorie "Altersvorsorge" — z.B. ein
      Riester-Vertrag, der (noch) nicht formal mit einem Rentenkonto unter
      Vorsorge verknüpft ist. Bereits über pension_accounts.linked_contract_id
      verknüpfte Verträge werden hier ausgeschlossen, um sie nicht doppelt
      zu zählen (einmal über das Rentenkonto, einmal über den Vertrag selbst).
    - Finanzierungsverträge (contracts, subcategory='Finanzierung') — für
      das Netto-Immobilienvermögen (Immobilienwert − Restschuld). Eine
      Immobilie kann mit MEHREREN Verträgen verknüpft sein (z.B. Haupt-
      darlehen + KfW-Förderdarlehen) — deren Restschulden werden summiert.
    """
    conn = get_connection()

    assets = conn.execute(
        """SELECT a.*, fm.name AS person_name
           FROM assets a
           LEFT JOIN family_members fm ON fm.id = a.person_id
           WHERE a.archived_at IS NULL
           ORDER BY a.type, a.label"""
    ).fetchall()

    pension_rows = conn.execute(
        "SELECT pa.id, pa.current_value, pa.label, pa.provider, pa.person_id, fm.name AS person_name "
        "FROM pension_accounts pa JOIN family_members fm ON fm.id = pa.person_id "
        "WHERE pa.type='privat' AND pa.current_value IS NOT NULL"
    ).fetchall()

    altersvorsorge_contracts = conn.execute(
        """SELECT co.id, co.label, co.provider, co.amount, fm.name AS person_name
           FROM contracts co
           JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE LOWER(c.name) = 'altersvorsorge' AND co.status = 'active'
           AND co.id NOT IN (
               SELECT linked_contract_id FROM pension_accounts WHERE linked_contract_id IS NOT NULL
           )"""
    ).fetchall()

    by_type = {"konto": [], "depot": [], "immobilie": [], "sonstiges": [], "altersvorsorge": []}
    total_liquid = 0.0
    total_immobilien_brutto = 0.0
    total_immobilien_schulden = 0.0
    total_altersvorsorge_assets = 0.0
    real_estate_items = []  # (asset_dict, [financing_contract_dict, ...])
    # Als "nicht im Gesamtvermögen" markierte Werte bleiben in der Liste sichtbar, zählen aber in KEINE Summe:
    # Gesamt, Töpfe, Kuchendiagramm, Allokation, Liquiditätsreserve, Immobilien-Projektion.
    excluded_ids = {a["id"] for a in assets if a["exclude_from_networth"]}
    asset_ids_for_holdings = [a["id"] for a in assets if a["id"] not in excluded_ids]

    for a in assets:
        entry = dict(a)
        entry.pop("linked_contract_id", None)
        entry["exclude_from_networth"] = bool(a["exclude_from_networth"])
        counts = a["id"] not in excluded_ids
        if a["type"] == "immobilie":
            financing = _asset_financing_details(conn, a["id"])
            total_debt = sum(f["remaining_debt"] or 0 for f in financing)
            value = a["current_value"] or 0
            entry["financing_contracts"] = financing
            entry["total_remaining_debt"] = round(total_debt, 2)
            entry["net_value"] = round(value - total_debt, 2)
            if counts:
                total_immobilien_brutto += value
                total_immobilien_schulden += total_debt
                real_estate_items.append((a, financing))
        elif (a["purpose"] or "").lower() == "altersvorsorge":
            # Ein Depot/Konto MIT dem Zweck Altersvorsorge zählt konzeptionell
            # als Altersvorsorge-Vermögen, nicht als generisches liquides
            # Vermögen — unabhängig vom technischen "type". Erscheint daher
            # NUR unter "altersvorsorge", nicht zusätzlich unter seinem
            # technischen Typ (sonst doppelte Anzeige). Der VOLLSTÄNDIGE
            # entry (nicht nur ein paar Felder) wird übernommen, da das
            # Bearbeiten-Formular u.a. "type" und "purpose" braucht.
            entry["source"] = "asset"
            if counts:
                total_altersvorsorge_assets += a["current_value"] or 0
            by_type["altersvorsorge"].append(entry)
            continue
        elif counts:
            total_liquid += a["current_value"] or 0
        by_type.setdefault(a["type"], []).append(entry)
    counted_assets = [a for a in assets if a["id"] not in excluded_ids]

    for p in pension_rows:
        by_type["altersvorsorge"].append({
            "id": p["id"], "source": "pension_account", "label": p["label"],
            "provider": p["provider"], "person_name": p["person_name"], "person_id": p["person_id"],
            "current_value": p["current_value"],
        })
    for c in altersvorsorge_contracts:
        by_type["altersvorsorge"].append({
            "id": c["id"], "source": "contract", "label": c["label"],
            "provider": c["provider"], "person_name": c["person_name"],
            "current_value": c["amount"],
        })

    # Asset-Allokation: über ALLE Positionen (asset_holdings) aller Depots
    # hinweg, gewichtet nach ihrem jeweiligen Wert — unabhängig vom Zweck
    # des Depots, damit die Gesamt-Risikostreuung sichtbar wird.
    allocation_by_class = {}
    allocation_by_region = {}
    total_holdings_value = 0.0
    if asset_ids_for_holdings:
        placeholders = ",".join("?" for _ in asset_ids_for_holdings)
        holdings = conn.execute(
            f"SELECT * FROM asset_holdings WHERE asset_id IN ({placeholders})",
            asset_ids_for_holdings,
        ).fetchall()
        for h in holdings:
            value = h["current_value"] or 0
            total_holdings_value += value
            cls = h["asset_class"] or "unbekannt"
            reg = h["region"] or "unbekannt"
            allocation_by_class[cls] = allocation_by_class.get(cls, 0) + value
            allocation_by_region[reg] = allocation_by_region.get(reg, 0) + value

    # Soll-Allokation zum Abgleich mit der Ist-Verteilung.
    targets = {r["asset_class"]: r["target_percent"] for r in conn.execute("SELECT * FROM allocation_targets").fetchall()}

    # Kuchendiagramm über das GESAMTE Nettovermögen (nicht nur Depot-
    # Positionen) nach sieben Anlageklassen. "Sonstiges" wird bewusst als
    # Restgröße (Gesamt minus alle benannten Kategorien) berechnet statt
    # jede Restquelle einzeln aufzuzählen — so summieren sich die Anteile
    # garantiert immer exakt zum Gesamtvermögen, ohne Doppelzählungsrisiko.
    tagesgeld_total = sum(a["current_value"] or 0 for a in counted_assets if a["type"] == "konto" and a["account_type"] == "tagesgeld")
    festgeld_total = sum(a["current_value"] or 0 for a in counted_assets if a["type"] == "konto" and a["account_type"] == "festgeld")
    liquiditaet_total = sum(a["current_value"] or 0 for a in counted_assets if a["type"] == "konto" and a["account_type"] not in ("tagesgeld", "festgeld"))
    aktien_total = allocation_by_class.get("aktie", 0)
    festverzinsliches_total = allocation_by_class.get("anleihe", 0)

    # Liquiditätsreserve: reichen die liquiden Mittel (Konten) für die
    # empfohlenen 3-6 Monatsausgaben? Nutzt dieselbe Fixkosten-Berechnung
    # wie das Dashboard (alle aktiven Ausgaben außer "Sparen").
    monthly_fixed_expenses = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND (c.name IS NULL OR c.name != 'Sparen')"""
    ).fetchone()["v"]
    total_konten = sum(a["current_value"] or 0 for a in counted_assets if a["type"] == "konto")
    months_covered = round(total_konten / monthly_fixed_expenses, 1) if monthly_fixed_expenses else None

    conn.close()

    pension_capital = (
        sum(p["current_value"] or 0 for p in pension_rows)
        + sum(c["amount"] or 0 for c in altersvorsorge_contracts)
        + total_altersvorsorge_assets
    )
    total_immobilien_netto = total_immobilien_brutto - total_immobilien_schulden
    total_networth = total_liquid + pension_capital + total_immobilien_netto

    # Zukunftsprojektion Netto-Immobilienvermögen: Immobilienwert bleibt
    # laut ausdrücklicher Annahme konstant, die Restschuld folgt dem
    # bestehenden Tilgungsplan-Rechner, über alle verknüpften Verträge einer
    # Immobilie UND über alle Immobilien hinweg summiert — Kernidee des
    # ganzen Features ("Wert bleibt, Darlehen sinkt").
    projection = []
    if real_estate_items:
        from finanzierung import compute_repayment_schedule
        combined_by_year = {}
        for asset, financing in real_estate_items:
            property_value = asset["current_value"] or 0
            any_schedule = False
            for contract in financing:
                # 0 % ist gültig (KfW, Arbeitgeberdarlehen); nur ein fehlender Zinssatz schließt aus.
                if not contract["remaining_debt"] or contract["interest_rate"] is None:
                    continue
                result = compute_repayment_schedule(
                    remaining_debt=contract["remaining_debt"],
                    interest_rate=contract["interest_rate"],
                    # Rate auf Monatswert normieren (bisher wurde eine Quartals-/Jahresrate als Monatsrate gerechnet)
                    monthly_payment=monthly_amount(contract["amount"], contract["frequency"]),
                    repayment_rate=contract["repayment_rate"],
                )
                if result["error"]:
                    continue
                any_schedule = True
                for point in result["schedule"]:
                    y = point["year"]
                    combined_by_year.setdefault(y, {"year": y, "debt": 0.0, "value": 0.0})
                    combined_by_year[y]["debt"] += point["remaining_debt"]
            if any_schedule:
                # Immobilienwert für jedes Jahr, in dem mindestens ein
                # verknüpfter Vertrag einen Tilgungsplan beisteuert, addieren
                # — unabhängig davon, wie viele Verträge es sind (der Wert
                # der Immobilie selbst zählt nur einmal pro Jahr).
                for y in combined_by_year:
                    combined_by_year[y]["value"] += property_value
        for y in sorted(combined_by_year):
            p = combined_by_year[y]
            projection.append({
                "year": y, "property_value": round(p["value"], 2),
                "remaining_debt": round(p["debt"], 2),
                "net_value": round(p["value"] - p["debt"], 2),
            })

    def _to_percent_list(d: dict, total: float) -> list:
        if total <= 0:
            return []
        return sorted(
            [{"key": k, "value": round(v, 2), "percent": round(v / total * 100, 1)} for k, v in d.items()],
            key=lambda x: -x["value"],
        )

    by_class_list = _to_percent_list(allocation_by_class, total_holdings_value)
    for item in by_class_list:
        if item["key"] in targets:
            item["target_percent"] = targets[item["key"]]
            item["deviation"] = round(item["percent"] - targets[item["key"]], 1)

    # Kuchendiagramm über das GESAMTE Nettovermögen (nicht nur Depot-
    # Positionen) nach sieben Anlageklassen. "Sonstiges" wird bewusst als
    # Restgröße (Gesamt minus alle benannten Kategorien) berechnet statt
    # jede Restquelle einzeln aufzuzählen — so summieren sich die Anteile
    # garantiert immer exakt zum Gesamtvermögen, ohne Doppelzählungsrisiko.
    named_pie_total = tagesgeld_total + festgeld_total + liquiditaet_total + aktien_total + festverzinsliches_total + total_immobilien_netto
    sonstiges_pie = max(total_networth - named_pie_total, 0)
    pie_allocation = _to_percent_list({
        "Aktien": aktien_total,
        "Festverzinsliches": festverzinsliches_total,
        "Immobilien": total_immobilien_netto,
        "Tagesgelder": tagesgeld_total,
        "Festgelder": festgeld_total,
        "Liquidität": liquiditaet_total,
        "Sonstiges": sonstiges_pie,
    }, total_networth) if total_networth > 0 else []

    return {
        "by_type": by_type,
        "totals": {
            "liquid": round(total_liquid, 2),
            "pension_capital": round(pension_capital, 2),
            "immobilien_brutto": round(total_immobilien_brutto, 2),
            "immobilien_schulden": round(total_immobilien_schulden, 2),
            "immobilien_netto": round(total_immobilien_netto, 2),
            "gesamt": round(total_networth, 2),
        },
        "pension_accounts": [dict(p) for p in pension_rows],
        "real_estate_projection": projection,
        "asset_allocation": {
            "total_value": round(total_holdings_value, 2),
            "by_class": by_class_list,
            "by_region": _to_percent_list(allocation_by_region, total_holdings_value),
            "targets_set": len(targets) > 0,
        },
        "pie_allocation": pie_allocation,
        "liquidity_reserve": {
            "total_konten": round(total_konten, 2),
            "monthly_fixed_expenses": round(monthly_fixed_expenses, 2),
            "months_covered": months_covered,
            # Gängige Faustregel: 3-6 Monatsausgaben als Reserve. Deutlich
            # MEHR als das ist keine zusätzliche Sicherheit mehr, sondern
            # ungenutztes Kapital, das z.B. am Kapitalmarkt arbeiten könnte —
            # daher "zu viel" als eigener, gelber Zustand statt "gut".
            "status": ("zu_viel" if months_covered is not None and months_covered > 9
                       else "gut" if months_covered is not None and months_covered >= 3
                       else "niedrig" if months_covered is not None else "unbekannt"),
        },
    }




