"""PV-Tageswert nach Mitternacht (v357). Ohne Server, ohne Netz, Sekunden.
    cd kopie/backend && python3 ../scripts/review/pvtag.py
Exit-Code 0 = alles grün. Arbeitet nur in einem Temp-Ordner.

Anlass: Die Sungrow-Cloud setzt die Tageszähler nicht pünktlich um Mitternacht zurück. Der erste Abruf nach
Mitternacht lieferte die Endstände von gestern, die App speicherte sie unter heutigem Datum, und weil Tageswerte
„nur wachsen“, blieb der Vortageswert stehen (28.10.2026 = 27.10.).

Fälle:
 1) `device_date_of`: Format JJJJMMTTHHMMSS, Unsinn -> None.
 2) Abruf mit Gerätezeit von gestern -> nichts gespeichert, Status nennt den Grund.
 3) Ohne Gerätezeit vor 05:00 mit PV > 0,1 kWh -> nichts gespeichert; mit zurückgesetzten Zählern -> gespeichert.
 4) Ohne Gerätezeit tagsüber, PV und Einspeisung wie gestern -> nichts gespeichert.
 5) Echter heutiger Wert -> gespeichert; späterer kleinerer Wert ändert nichts (nur wachsend bleibt).
 6) Altbestand: heutiger Wert ist Kopie von gestern -> echter (kleinerer) Wert ersetzt ihn, Monat sinkt mit.
 7) Importierter (größerer) Monat wird beim Ersetzen nicht verkleinert.
 8) „Verlauf korrigieren“: Kopie-Tage bekommen PV/Einspeisung/Bezug aus dem Verlauf, normale Tage nur den
    Hausverbrauch, Monat neu summiert; ohne Verlaufswert bleibt der Tag als „noch mit Vortageswerten“ gemeldet.
"""
import contextlib
import io
import sqlite3
import sys
import tempfile
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
TMP = Path(tempfile.mkdtemp(prefix="ff_pvtag_"))
(TMP / "data").mkdir()

import database  # noqa: E402
import maintenance  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"
maintenance.BASE_DIR = TMP

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
    import app as appmod
import auth  # noqa: E402
import energy_routes as er  # noqa: E402
import sungrow_v1_client as sg  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

appmod.app.dependency_overrides[auth.require_full_auth] = lambda: {"stage": "full"}
cl = TestClient(appmod.app, base_url="http://localhost:8420", raise_server_exceptions=False)

CREDS = {"appkey": "a", "access_key": "k", "rsa_public": None, "account": "x", "password": "p",
         "ps_id": "123", "token": "t"}
er._get_sungrow_v1 = lambda conn: dict(CREDS)
er._save_sungrow_v1 = lambda conn, data: None

SAMPLE = {}
NOW = [datetime(2026, 10, 28, 0, 30)]
sg.get_today_values = lambda *a, **k: dict(SAMPLE)
er._now = lambda: NOW[0]


def db():
    c = sqlite3.connect(database.DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def day(key):
    r = db().execute("SELECT pv, einsp, bezug, gesamt FROM pv_daily WHERE key=?", (key,)).fetchone()
    return None if r is None else (round(r["pv"], 3), round(r["einsp"], 3), round(r["bezug"], 3), round(r["gesamt"], 3))


def month(key):
    r = db().execute("SELECT pv, einsp, bezug FROM pv_monthly WHERE key=?", (key,)).fetchone()
    return None if r is None else (round(r["pv"], 3), round(r["einsp"], 3), round(r["bezug"], 3))


def sync(sample, now):
    SAMPLE.clear()
    SAMPLE.update(sample)
    NOW[0] = now
    c = db()
    try:
        return er._do_sungrow_v1_sync(c)
    finally:
        c.close()


def reset():
    c = db()
    c.execute("DELETE FROM pv_daily")
    c.execute("DELETE FROM pv_monthly")
    # 26.10.: 20,0 PV / 5,0 Einsp / 4,0 Bezug; 27.10.: 27,0 / 4,0 / 3,0 -> Oktober 47,0 / 9,0 / 7,0
    for k, pv, e, b in (("2026-10-26", 20.0, 5.0, 4.0), ("2026-10-27", 27.0, 4.0, 3.0)):
        c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES (?,?,?,?,0,0,?)",
                  (k, pv, b, e, pv - e + b))
    c.execute("INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2026-10',47,7,9,0,0,52)")
    c.commit()
    c.close()


YESTERDAY_STALE = {"pv": 27.0, "einsp": 4.0, "bezug": 3.2, "verbrauch": None}

# 1) Gerätezeit lesen
check("1 device_date_of gültig", sg.device_date_of("20241127151500"), "2024-11-27")
check("1 device_date_of leer", sg.device_date_of(None), None)
check("1 device_date_of Unsinn", sg.device_date_of("abc"), None)
check("1 device_date_of 13. Monat", sg.device_date_of("20241327000000"), None)

# 2) Gerätezeit von gestern
reset()
r = sync({**YESTERDAY_STALE, "device_date": "2026-10-27"}, datetime(2026, 10, 28, 9, 0))
check("2 nichts gespeichert", day("2026-10-28"), None)
check("2 Grund genannt", "27.10." in (r.get("skipped") or ""), True)
check("2 Monat unverändert", month("2026-10"), (47.0, 9.0, 7.0))

# 3) Ohne Gerätezeit nachts
reset()
sync({**YESTERDAY_STALE, "pv": 26.9}, datetime(2026, 10, 28, 0, 30))
check("3 nachts PV>0 -> nichts gespeichert", day("2026-10-28"), None)
sync({"pv": 0.0, "einsp": 0.0, "bezug": 0.4, "verbrauch": 0.4}, datetime(2026, 10, 28, 0, 30))
check("3 zurückgesetzte Zähler -> gespeichert", day("2026-10-28"), (0.0, 0.0, 0.4, 0.4))

# 4) Ohne Gerätezeit tagsüber, gleiche PV/Einspeisung wie gestern
reset()
sync(YESTERDAY_STALE, datetime(2026, 10, 28, 9, 0))
check("4 Kopie tagsüber -> nichts gespeichert", day("2026-10-28"), None)

# 5) echter Wert, dann kleinerer
reset()
sync({"pv": 2.5, "einsp": 0.0, "bezug": 1.5, "verbrauch": 3.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 9, 0))
check("5 echter Wert gespeichert", day("2026-10-28"), (2.5, 0.0, 1.5, 3.0))
check("5 Monat = 47,0 + 2,5", month("2026-10"), (49.5, 9.0, 8.5))
sync({"pv": 2.4, "einsp": 0.0, "bezug": 1.5, "verbrauch": 3.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 9, 30))
check("5 kleinerer Wert ändert PV nicht", day("2026-10-28")[0], 2.5)

# 6) Altbestand v356: 28.10. trägt die Werte vom 27.10.
reset()
c = db()
c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2026-10-28',27,3.2,4,0,0,26.2)")
c.execute("UPDATE pv_monthly SET pv=74, bezug=10.2, einsp=13 WHERE key='2026-10'")
c.commit()
c.close()
sync({"pv": 12.0, "einsp": 1.0, "bezug": 2.0, "verbrauch": 13.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 14, 0))
check("6 Kopie durch echten Wert ersetzt", day("2026-10-28"), (12.0, 1.0, 2.0, 13.0))
check("6 Monat sinkt mit (47+12 / 9+1 / 7+2)", month("2026-10"), (59.0, 10.0, 9.0))

# 7) importierter Monat ist größer als die Tagessumme -> nie verkleinern
reset()
c = db()
c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2026-10-28',27,3.2,4,0,0,26.2)")
c.execute("UPDATE pv_monthly SET pv=300, bezug=50, einsp=100 WHERE key='2026-10'")
c.commit()
c.close()
sync({"pv": 12.0, "einsp": 1.0, "bezug": 2.0, "verbrauch": 13.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 14, 0))
check("7 Tag ersetzt", day("2026-10-28")[0], 12.0)
check("7 importierter Monat bleibt", month("2026-10"), (300.0, 100.0, 50.0))

# 8) Verlauf korrigieren (Tage vor heute; „heute“ = echtes Datum, also Tage in der Vergangenheit anlegen)
c = db()
c.execute("DELETE FROM pv_daily")
c.execute("DELETE FROM pv_monthly")
rows = (("2020-05-01", 30.0, 10.0, 2.0), ("2020-05-02", 30.0, 10.0, 2.5),   # 02. = Kopie von 01.
        ("2020-05-03", 30.0, 10.0, 2.7))                                     # 03. = Kopie, Verlauf liefert nichts
for k, pv, e, b in rows:
    c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES (?,?,?,?,0,0,?)",
              (k, pv, b, e, pv - e + b))
c.execute("INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2020-05',90,7.2,30,0,0,67.2)")
c.commit()
c.close()
TOTALS = {"2020-05-01": {"pv": 30.0, "einsp": 10.0, "bezug": 2.0, "verbrauch": 21.0},
          "2020-05-02": {"pv": 8.0, "einsp": 1.0, "bezug": 6.0, "verbrauch": 12.5},
          "2020-05-03": {"pv": None, "einsp": None, "bezug": None, "verbrauch": None}}
sg.get_day_totals = lambda *a, **k: dict(TOTALS[a[-1].isoformat()])
res = cl.post("/api/sungrow/v1/repair-history")
check("8 Status", res.status_code, 200)
j = res.json()
check("8 normaler Tag: nur Hausverbrauch", day("2020-05-01"), (30.0, 10.0, 2.0, 21.0))
check("8 Kopie-Tag ersetzt", day("2020-05-02"), (8.0, 1.0, 6.0, 12.5))
check("8 Tag ohne Verlauf unverändert", day("2020-05-03"), (30.0, 10.0, 2.7, 22.7))
check("8 gemeldet: ersetzt", [x["day"] for x in j.get("copies_fixed", [])], ["2020-05-02"])
check("8 gemeldet: offen", j.get("copies_unresolved"), ["2020-05-03"])
check("8 Monat neu summiert (30+8+30 / 10+1+10 / 2+6+2,7)", month("2020-05"), (68.0, 21.0, 10.7))

print()
print("ALLES GRÜN" if not FAILS else f"FEHLER: {len(FAILS)} — {', '.join(FAILS)}")
sys.exit(1 if FAILS else 0)
