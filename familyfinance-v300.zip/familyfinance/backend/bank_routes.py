"""
Bankanbindung (FinTS): Verbindungen verwalten, synchronisieren, Konten und
Umsätze ausliefern. Fachlogik der Bankkommunikation steckt in bank_client.py.

Je Bankverbindung ein settings-Eintrag "bank_conn_<n>" -- die PIN darin landet
über secret_store im Schlüsselbund, nie im Klartext in der Datenbank.
"""
import json
import re
import threading
import time
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import auth
import bank_client
import bank_matching
import secret_store
from database import get_connection

router = APIRouter()
PREFIX = "bank_conn_"
SYNC_DAYS = 90


# ---------- Verbindungen ----------

class ConnectionIn(BaseModel):
    bank: str = "custom"              # "bbbank" | "ing" | "custom"
    label: Optional[str] = None
    blz: Optional[str] = None
    server: Optional[str] = None
    user: str
    pin: Optional[str] = None         # leer = gespeicherte PIN behalten
    tan_mechanism: Optional[str] = None


class ProductIn(BaseModel):
    product_id: str


def _keys(conn) -> list:
    rows = conn.execute("SELECT key FROM settings WHERE key LIKE ? ORDER BY key", (PREFIX + "%",)).fetchall()
    return [r["key"] for r in rows]


def _get(conn, key: str) -> dict:
    if not key.startswith(PREFIX):
        raise HTTPException(404, "Unbekannte Bankverbindung.")
    data = secret_store.read_settings_json(conn, key)
    if data is None:
        raise HTTPException(404, "Unbekannte Bankverbindung.")
    return data


def _save(conn, key: str, data: dict):
    secret_store.write_settings_json(conn, key, data)


def _public(key: str, d: dict) -> dict:
    return {
        "key": key, "bank": d.get("bank"), "label": d.get("label"), "blz": d.get("blz"),
        "server": d.get("server"), "user": d.get("user"), "has_pin": bool(d.get("pin")),
        "login_blocked": bool(d.get("login_blocked")), "needs_manual": bool(d.get("needs_manual")),
        "last_sync": d.get("last_sync"), "last_status": d.get("last_status"), "last_message": d.get("last_message"),
    }


def _product_id(conn) -> str:
    row = conn.execute("SELECT value FROM settings WHERE key='fints_product_id'").fetchone()
    return (json.loads(row["value"]) if row else "") or ""


@router.get("/api/banks/known")
def known_banks(session=Depends(auth.require_full_auth)):
    return bank_client.KNOWN_BANKS


@router.get("/api/banks/settings")
def get_bank_settings(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    pid = _product_id(conn)
    conn.close()
    return {"product_id_set": bool(pid), "product_id_hint": (pid[:4] + "…") if pid else "",
            "library_installed": bank_client.library_installed()}


@router.post("/api/banks/install-library")
def install_bank_library(session=Depends(auth.require_full_auth)):
    """Wie der Schlüsselbund-Knopf: installiert über denselben Python, der den
    Server ausführt -- kein Terminal nötig. Bewusst exakt die geprüften
    Versionen, nie "die neueste"."""
    import subprocess, sys
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "easy-fints==1.5.0", "fints==5.0.0"],
                           capture_output=True, text=True, timeout=180)
    except Exception as e:
        raise HTTPException(502, f"Installation konnte nicht gestartet werden: {e}")
    out = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0:
        raise HTTPException(400, out[-2000:] or f"pip beendete sich mit Code {r.returncode}")
    return {"status": "ok", "installed": bank_client.library_installed()}


@router.put("/api/banks/settings")
def put_bank_settings(payload: ProductIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("INSERT INTO settings (key, value) VALUES ('fints_product_id', ?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(payload.product_id.strip()),))
    conn.commit()
    conn.close()
    return {"status": "saved"}


@router.get("/api/banks/connections")
def list_connections(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        return [_public(k, secret_store.read_settings_json(conn, k) or {}) for k in _keys(conn)]
    finally:
        conn.close()


@router.post("/api/banks/connections")
def create_connection(payload: ConnectionIn, session=Depends(auth.require_full_auth)):
    if not payload.pin:
        raise HTTPException(400, "PIN fehlt.")
    conn = get_connection()
    try:
        nums = [int(k[len(PREFIX):]) for k in _keys(conn) if k[len(PREFIX):].isdigit()]
        key = f"{PREFIX}{max(nums, default=0) + 1}"
        _save(conn, key, _merge_connection({}, payload))
        return {"status": "created", "key": key}
    finally:
        conn.close()


@router.put("/api/banks/connections/{key}")
def update_connection(key: str, payload: ConnectionIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        old = _get(conn, key)
        data = _merge_connection(old, payload)
        data["login_blocked"] = False      # bewusste Änderung durch den Nutzer hebt die Pause auf
        data["needs_manual"] = False
        _save(conn, key, data)
        return {"status": "saved"}
    finally:
        conn.close()


def _merge_connection(old: dict, p: ConnectionIn) -> dict:
    preset = bank_client.KNOWN_BANKS.get(p.bank, {})
    return {
        **{k: v for k, v in old.items() if k not in ("pin",)},
        "bank": p.bank,
        "label": (p.label or "").strip() or preset.get("label") or old.get("label") or "Bank",
        "blz": (p.blz or "").strip() or preset.get("blz") or old.get("blz", ""),
        "server": (p.server or "").strip() or preset.get("server") or old.get("server", ""),
        "user": p.user.strip(),
        "pin": p.pin or old.get("pin", ""),
        "tan_mechanism": (p.tan_mechanism or "").strip() or old.get("tan_mechanism") or None,
    }


@router.delete("/api/banks/connections/{key}")
def delete_connection(key: str, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        _get(conn, key)
        ids = [r["id"] for r in conn.execute("SELECT id FROM bank_accounts WHERE connection_key=?", (key,))]
        for i in ids:
            conn.execute("DELETE FROM bank_transactions WHERE bank_account_id=?", (i,))
        conn.execute("DELETE FROM bank_accounts WHERE connection_key=?", (key,))
        conn.commit()
        secret_store.delete_all_for_key(conn, key)   # auch die PIN aus dem Schlüsselbund
        return {"status": "deleted"}
    finally:
        conn.close()


# ---------- Speichern eines Abrufs ----------

def _digits(value) -> str:
    return re.sub(r"\D", "", str(value or "")).lstrip("0")


def _auto_link_asset(conn, account_number: str, iban: str) -> Optional[int]:
    """Ordnet ein Bankkonto/-depot einem vorhandenen Vermögens-Konto bzw. -Depot zu, wenn dessen
    hinterlegte Kontonummer zur Kontonummer bzw. zum Ende der IBAN passt."""
    num, iban_d = _digits(account_number), _digits(iban)
    if not num and not iban_d:
        return None
    for a in conn.execute("SELECT id, account_number FROM assets WHERE type IN ('konto','depot') AND account_number IS NOT NULL "
                         "AND id NOT IN (SELECT asset_id FROM bank_accounts WHERE asset_id IS NOT NULL)"):
        cand = _digits(a["account_number"])
        if cand and (cand == num or (iban_d and iban_d.endswith(cand) and len(cand) >= 6)):
            return a["id"]
    return None


def _upsert_account(conn, key: str, acc: dict) -> int:
    iban, number = acc.get("iban") or "", acc.get("account_number") or ""
    row = conn.execute("SELECT id, asset_id FROM bank_accounts WHERE connection_key=? AND iban=? AND account_number=?",
                       (key, iban, number)).fetchone()
    balance = bank_client.parse_amount(acc.get("balance"))
    now = datetime.now().isoformat(timespec="seconds")
    if row:
        acc_id, asset_id = row["id"], row["asset_id"]
        if balance is not None:
            conn.execute("UPDATE bank_accounts SET balance=?, balance_updated_at=?, label=?, owner_name=?, currency=? WHERE id=?",
                         (balance, now, acc.get("label"), acc.get("owner_name"), acc.get("currency"), acc_id))
    else:
        asset_id = _auto_link_asset(conn, number, iban)
        cur = conn.execute(
            "INSERT INTO bank_accounts (connection_key, iban, account_number, label, owner_name, currency, balance, "
            "balance_updated_at, asset_id) VALUES (?,?,?,?,?,?,?,?,?)",
            (key, iban, number, acc.get("label"), acc.get("owner_name"), acc.get("currency"),
             balance, now if balance is not None else None, asset_id))
        acc_id = cur.lastrowid
    if asset_id and balance is not None:
        conn.execute("UPDATE assets SET current_value=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (balance, asset_id))
    return acc_id


def store_sync_result(conn, key: str, result: dict) -> dict:
    accounts_seen, new_tx = 0, 0
    ids_by_ident = {}
    for acc in result.get("accounts") or []:
        ids_by_ident[(acc.get("iban") or "", acc.get("account_number") or "")] = _upsert_account(conn, key, acc)
        accounts_seen += 1
    for group in result.get("transactions_by_account") or []:
        acc = group.get("account") or {}
        ident = (acc.get("iban") or "", acc.get("account_number") or "")
        acc_id = ids_by_ident.get(ident) or _upsert_account(conn, key, acc)
        txs = group.get("transactions") or []
        for t, h in zip(txs, bank_client.tx_hashes(txs, f"{key}:{ident[0]}:{ident[1]}")):
            cur = conn.execute(
                "INSERT OR IGNORE INTO bank_transactions (bank_account_id, booking_date, value_date, amount, currency, "
                "counterparty_name, counterparty_iban, purpose, tx_hash) VALUES (?,?,?,?,?,?,?,?,?)",
                (acc_id, t.get("booking_date"), t.get("value_date"), bank_client.parse_amount(t.get("amount")),
                 t.get("currency"), t.get("counterparty_name"), t.get("counterparty_iban"), t.get("purpose"), h))
            new_tx += cur.rowcount
    conn.commit()
    auto = bank_matching.apply_rules(conn)
    return {"accounts": accounts_seen, "new_transactions": new_tx, "auto_assigned": auto}


def _record(conn, key: str, data: dict, status: str, message: str, **flags):
    data.update(flags)
    data["last_sync"] = datetime.now().isoformat(timespec="seconds")
    data["last_status"] = status
    data["last_message"] = message
    _save(conn, key, data)


def _handle_result(conn, key: str, data: dict, result: dict) -> dict:
    if result["status"] == "ok":
        summary = store_sync_result(conn, key, result)
        _record(conn, key, data, "ok",
                f"{summary['accounts']} Konto/Konten, {summary['new_transactions']} neue Umsätze",
                login_blocked=False, needs_manual=False)
        return {"status": "ok", **summary}
    return result   # tan_required / pending -- Zustand bleibt, bis die Freigabe abgeschlossen ist


# ---------- Synchronisieren (manuell, mit Freigabe) ----------

@router.post("/api/banks/connections/{key}/sync")
def sync_connection(key: str, session=Depends(auth.require_full_auth)):
    """Bewusster, einzelner Abrufversuch durch den Nutzer -- hebt eine Pause
    nach abgelehnter PIN auf, aber immer nur für genau diesen einen Versuch."""
    conn = get_connection()
    try:
        data = _get(conn, key)
        try:
            result = bank_client.start_sync(key, data, _product_id(conn), SYNC_DAYS, allow_tan=True)
        except bank_client.BankLoginError as e:
            _record(conn, key, data, "error", str(e), login_blocked=True)
            raise HTTPException(400, f"Anmeldung abgelehnt: {e} — automatische Abrufe pausiert.")
        except bank_client.BankConfigError as e:
            raise HTTPException(400, str(e))
        except bank_client.BankError as e:
            _record(conn, key, data, "error", str(e))
            raise HTTPException(502, str(e))
        return _handle_result(conn, key, data, result)
    finally:
        conn.close()


class TanIn(BaseModel):
    tan: Optional[str] = ""


@router.post("/api/banks/sessions/{token}/poll")
def poll_session(token: str, payload: TanIn, session=Depends(auth.require_full_auth)):
    """Vom Frontend alle paar Sekunden aufgerufen, solange auf die Bestätigung
    in der Banking-App gewartet wird -- bzw. einmal mit eingegebener TAN."""
    key = bank_client.session_conn_key(token)
    if not key:
        raise HTTPException(410, "Die Freigabe-Sitzung ist abgelaufen — bitte erneut synchronisieren.")
    conn = get_connection()
    try:
        data = _get(conn, key)
        try:
            result = bank_client.resume(token, payload.tan or "")
        except bank_client.BankLoginError as e:
            _record(conn, key, data, "error", str(e), login_blocked=True)
            raise HTTPException(400, str(e))
        except bank_client.BankError as e:
            _record(conn, key, data, "error", str(e))
            raise HTTPException(502, str(e))
        return _handle_result(conn, key, data, result)
    finally:
        conn.close()


@router.post("/api/banks/sessions/{token}/cancel")
def cancel_session(token: str, session=Depends(auth.require_full_auth)):
    bank_client.cancel_session(token)
    return {"status": "cancelled"}


# ---------- Konten & Umsätze ----------

@router.get("/api/banks/accounts")
def list_accounts(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT ba.*, a.label AS asset_label, "
        "(SELECT COUNT(*) FROM bank_transactions bt WHERE bt.bank_account_id = ba.id) AS tx_count "
        "FROM bank_accounts ba LEFT JOIN assets a ON a.id = ba.asset_id ORDER BY ba.connection_key, ba.label").fetchall()
    conn.close()
    return [dict(r) for r in rows]


class LinkIn(BaseModel):
    asset_id: Optional[int] = None


@router.put("/api/banks/accounts/{account_id}/link")
def link_account(account_id: int, payload: LinkIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        row = conn.execute("SELECT balance FROM bank_accounts WHERE id=?", (account_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Konto nicht gefunden.")
        if payload.asset_id:
            other = conn.execute("SELECT id FROM bank_accounts WHERE asset_id=? AND id<>?",
                                 (payload.asset_id, account_id)).fetchone()
            if other:
                raise HTTPException(409, "Dieser Eintrag ist bereits mit einem anderen Bankkonto verknüpft.")
        conn.execute("UPDATE bank_accounts SET asset_id=? WHERE id=?", (payload.asset_id, account_id))
        if payload.asset_id and row["balance"] is not None:
            conn.execute("UPDATE assets SET current_value=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                         (row["balance"], payload.asset_id))
        conn.commit()
        return {"status": "linked"}
    finally:
        conn.close()


class CreateAssetIn(BaseModel):
    type: str = "konto"       # "konto" | "depot"


@router.post("/api/banks/accounts/{account_id}/create-asset")
def create_asset_from_account(account_id: int, payload: CreateAssetIn, session=Depends(auth.require_full_auth)):
    """Legt aus einem noch nicht zugeordneten Bankkonto einen neuen Vermögenseintrag
    (Konto oder Depot) an und verknüpft beide -- Saldo kommt künftig von der Bank."""
    if payload.type not in ("konto", "depot"):
        raise HTTPException(400, "Typ muss 'konto' oder 'depot' sein.")
    conn = get_connection()
    try:
        acc = conn.execute("SELECT * FROM bank_accounts WHERE id=?", (account_id,)).fetchone()
        if not acc:
            raise HTTPException(404, "Konto nicht gefunden.")
        if acc["asset_id"]:
            raise HTTPException(409, "Dieses Bankkonto ist bereits zugeordnet.")
        data = secret_store.read_settings_json(conn, acc["connection_key"]) or {}
        label = (acc["label"] or "").strip() or ("Depot" if payload.type == "depot" else "Konto")
        number = (acc["account_number"] or "").strip() or (acc["iban"] or "").strip() or None
        cur = conn.execute(
            "INSERT INTO assets (type, label, provider, account_number, current_value, account_type) VALUES (?,?,?,?,?,?)",
            (payload.type, label, data.get("label") or None, number, acc["balance"] or 0,
             "giro" if payload.type == "konto" else None))
        asset_id = cur.lastrowid
        conn.execute("UPDATE bank_accounts SET asset_id=? WHERE id=?", (asset_id, account_id))
        conn.commit()
        return {"status": "created", "asset_id": asset_id}
    finally:
        conn.close()


@router.get("/api/banks/accounts/{account_id}/transactions")
def account_transactions(account_id: int, q: Optional[str] = None, limit: int = 500,
                         session=Depends(auth.require_full_auth)):
    conn = get_connection()
    sql = ("SELECT bt.*, c.label AS contract_label, i.label AS income_label FROM bank_transactions bt "
           "LEFT JOIN contracts c ON c.id = bt.contract_id LEFT JOIN income i ON i.id = bt.income_id "
           "WHERE bt.bank_account_id=?")
    args = [account_id]
    if q:
        sql += " AND (bt.counterparty_name LIKE ? OR bt.purpose LIKE ? OR c.label LIKE ? OR i.label LIKE ?)"
        args += [f"%{q}%"] * 4
    sql += " ORDER BY bt.booking_date DESC, bt.id DESC LIMIT ?"
    args.append(max(1, min(limit, 5000)))
    rows = conn.execute(sql, args).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------- Hintergrund-Abruf ----------

ERROR_RETRY_HOURS = 6


def _older_than(iso, hours: float) -> bool:
    try:
        return (datetime.now() - datetime.fromisoformat(iso)).total_seconds() >= hours * 3600
    except Exception:
        return True


def background_sync_all():
    """Ohne Nutzer: nur Abrufe, die KEINE Freigabe brauchen. Verlangt die Bank
    eine Freigabe, wird sofort abgebrochen und die Verbindung auf "manuell
    nötig" gesetzt -- so bekommt das Handy nicht bei jedem Durchlauf eine
    neue Push-Anfrage. Nach abgelehnter PIN wird nie automatisch wiederholt."""
    conn = get_connection()
    try:
        pid = _product_id(conn)
        if not pid:
            return
        for key in _keys(conn):
            data = secret_store.read_settings_json(conn, key) or {}
            if data.get("login_blocked") or data.get("needs_manual") or not data.get("pin"):
                continue
            # Nur Verbindungen, die schon einmal funktioniert haben ("Verbindung steht").
            # Nie erfolgreich abgerufen -> erst bewusst per Klick einrichten.
            status = data.get("last_status")
            if status not in ("ok", "error"):
                continue
            # Nach einem Fehler (z.B. Netz, Bank-Meldung) nur alle 6 Stunden erneut versuchen.
            if status == "error" and not _older_than(data.get("last_sync"), ERROR_RETRY_HOURS):
                continue
            try:
                result = bank_client.start_sync(key, data, pid, SYNC_DAYS, allow_tan=False)
                _handle_result(conn, key, data, result)
            except bank_client.BankLoginError as e:
                _record(conn, key, data, "error", str(e), login_blocked=True)
            except bank_client.BankError as e:
                if getattr(e, "needs_manual", False):
                    _record(conn, key, data, "needs_manual", str(e), needs_manual=True)
                else:
                    _record(conn, key, data, "error", str(e))
    finally:
        conn.close()


def start_background_sync(interval_hours: float = 1):
    def _loop():
        time.sleep(60)   # Serverstart nicht verzögern
        while True:
            try:
                background_sync_all()
            except Exception:
                pass
            time.sleep(interval_hours * 3600)
    threading.Thread(target=_loop, daemon=True).start()


# ---------- Zuordnung Umsatz <-> Vertrag / Einnahme ----------

class AssignIn(BaseModel):
    kind: str                 # "contract" | "income"
    target_id: int
    learn: bool = True        # Regel für künftige Umsätze merken


@router.put("/api/banks/transactions/{tx_id}/assign")
def assign_transaction(tx_id: int, payload: AssignIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        return {"status": "ok", **bank_matching.assign(conn, tx_id, payload.kind, payload.target_id, payload.learn)}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except LookupError as e:
        raise HTTPException(404, str(e))
    finally:
        conn.close()


@router.delete("/api/banks/transactions/{tx_id}/assign")
def unassign_transaction(tx_id: int, forget_rule: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        bank_matching.unassign(conn, tx_id, forget_rule)
        return {"status": "ok"}
    except LookupError as e:
        raise HTTPException(404, str(e))
    finally:
        conn.close()


@router.get("/api/banks/transactions/{tx_id}/suggestions")
def transaction_suggestions(tx_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        return bank_matching.suggestions(conn, tx_id)
    finally:
        conn.close()


def _payments(kind: str, target_id: int) -> list:
    col = "contract_id" if kind == "contract" else "income_id"
    conn = get_connection()
    rows = conn.execute(
        f"SELECT bt.id, bt.booking_date, bt.amount, bt.counterparty_name, bt.purpose, bt.match_source, "
        f"ba.label AS account_label FROM bank_transactions bt JOIN bank_accounts ba ON ba.id = bt.bank_account_id "
        f"WHERE bt.{col}=? ORDER BY bt.booking_date DESC, bt.id DESC", (target_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.get("/api/contracts/{contract_id}/payments")
def contract_payments(contract_id: int, session=Depends(auth.require_full_auth)):
    return _payments("contract", contract_id)


@router.get("/api/income/{income_id}/payments")
def income_payments(income_id: int, session=Depends(auth.require_full_auth)):
    return _payments("income", income_id)


@router.get("/api/banks/insights")
def bank_insights(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        return bank_matching.insights(conn)
    finally:
        conn.close()


class ApplyAmountIn(BaseModel):
    kind: str
    target_id: int
    amount: float


@router.post("/api/banks/insights/apply-amount")
def apply_detected_amount(payload: ApplyAmountIn, session=Depends(auth.require_full_auth)):
    """Übernimmt einen erkannten neuen Betrag -- NUR auf ausdrücklichen Klick."""
    if payload.kind not in ("contract", "income") or payload.amount <= 0:
        raise HTTPException(400, "Ungültige Angabe.")
    table = "contracts" if payload.kind == "contract" else "income"
    conn = get_connection()
    try:
        cur = conn.execute(f"UPDATE {table} SET amount=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                           (round(payload.amount, 2), payload.target_id))
        conn.commit()
        if not cur.rowcount:
            raise HTTPException(404, "Nicht gefunden.")
        return {"status": "ok"}
    finally:
        conn.close()
