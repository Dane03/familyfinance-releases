"""
Täglicher Hintergrund-Job für die Datenbank-Sicherung UND die
Vermögens-Momentaufnahme (für den Zeitverlauf in der Vermögensübersicht) —
läuft unabhängig davon, ob/wie oft die App-Sitzung offen ist oder der
Server neu startet (siehe scripts/com.familyfinance.backup.plist).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import maintenance
from database import init_db


def main():
    init_db()
    result = maintenance.backup_database()
    if result["success"]:
        print(f"Sicherung erstellt: {result['path']} ({result['total_backups']} Sicherungen insgesamt)")
        if result.get("external") == "ok":
            print(f"Zusätzliche Kopie außerhalb des App-Ordners: {result['external_dir']} ({result['external_total']} Kopien)")
        else:
            print(f"Externe Kopie: {result.get('external')} – {result.get('external_reason', '')}")
    else:
        print(f"Sicherung fehlgeschlagen: {result['error']}")

    from vermoegen_routes import save_networth_snapshot
    save_networth_snapshot()
    print("Vermögens-Momentaufnahme aktualisiert.")


if __name__ == "__main__":
    main()
