"""Einmal-Werkzeug (v360, try/finally-Umbau Etappe 2): umschließt in Funktionen ab `x = get_connection()`
(bzw. get_real_connection) den Rest des Funktionsrumpfs mit try/finally: x.close().

Verändert NUR das Schließen: commit/rollback-Verhalten bleibt gleich (close ohne commit verwirft wie bisher).
Vorhandene x.close()-Aufrufe bleiben stehen (doppeltes close ist bei sqlite3 harmlos, frühes Schließen bleibt früh).
Zeilen innerhalb mehrzeiliger Zeichenketten werden nicht eingerückt (Inhalt unverändert).

Sonderfälle werden NICHT angefasst, sondern gemeldet: Generatoren, Verbindung wird zurückgegeben/weitergereicht an
innere Funktionen oder Lambdas, mehrere Verbindungs-Zuweisungen, Zuweisung nicht direkt im Funktionsrumpf,
Aufruf ohne Zuweisung, schon vorhandenes try/finally um die Verbindung.

    python3 scripts/tools/wrap_connections.py backend/app.py ...          # Trockenlauf
    python3 scripts/tools/wrap_connections.py --write backend/app.py ...  # schreiben
"""
import ast
import io
import sys
import tokenize

OPENERS = {"get_connection", "get_real_connection"}


def string_inner_lines(src):
    """Zeilennummern (1-basiert), die INNERHALB eines mehrzeiligen Strings beginnen (nicht dessen erste Zeile)."""
    inner = set()
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.STRING or getattr(tokenize, "FSTRING_MIDDLE", -1) == tok.type:
            (sl, _), (el, _) = tok.start, tok.end
            inner.update(range(sl + 1, el + 1))
    # f-Strings ab Python 3.12 bestehen aus mehreren Tokens -> zusätzlich über FSTRING_START/END
    fs = getattr(tokenize, "FSTRING_START", None)
    if fs is not None:
        start = None
        for tok in tokenize.generate_tokens(io.StringIO(src).readline):
            if tok.type == fs and start is None:
                start = tok.start[0]
            elif tok.type == tokenize.FSTRING_END and start is not None:
                inner.update(range(start + 1, tok.end[0] + 1))
                start = None
    return inner


def is_opener_call(node):
    return isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in OPENERS


def own_nodes(func):
    """Alle Knoten der Funktion ohne innere Funktionen/Klassen/Lambdas (deren Rümpfe)."""
    stack = list(func.body)
    while stack:
        n = stack.pop()
        yield n
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef)):
            continue
        stack.extend(ast.iter_child_nodes(n))


def analyse(func):
    nodes = list(own_nodes(func))
    calls = [n for n in nodes if is_opener_call(n)]
    if not calls:
        return None, None
    if any(isinstance(n, (ast.Yield, ast.YieldFrom)) for n in nodes):
        return None, "Generator"
    assigns = [s for s in func.body if isinstance(s, ast.Assign) and is_opener_call(s.value)
               and len(s.targets) == 1 and isinstance(s.targets[0], ast.Name)]
    if len(calls) != 1 or len(assigns) != 1:
        return None, f"{len(calls)} Öffnungen, {len(assigns)} direkt zugewiesen"
    stmt = assigns[0]
    name = stmt.targets[0].id
    idx = func.body.index(stmt)
    rest = func.body[idx + 1:]
    if rest and isinstance(rest[0], ast.Try) and rest[0].finalbody:
        return None, "hat schon try/finally"
    for n in nodes:
        if isinstance(n, ast.Return) and isinstance(n.value, ast.Name) and n.value.id == name:
            return None, "gibt Verbindung zurück"
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets) and n is not stmt:
            return None, "Verbindung wird neu zugewiesen"
    for n in ast.walk(func):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)) and n is not func:
            if any(isinstance(m, ast.Name) and m.id == name for m in ast.walk(n)):
                return None, "innere Funktion nutzt Verbindung"
    if not rest:
        return None, "nichts nach dem Öffnen"
    return (stmt, name, rest), None


def transform(path, write):
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src)
    inner = string_inner_lines(src)
    lines = src.split("\n")
    edits, skipped, done = [], [], []
    for func in ast.walk(tree):
        if not isinstance(func, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        res, why = analyse(func)
        if why:
            skipped.append((func.name, func.lineno, why))
        if not res:
            continue
        stmt, name, rest = res
        indent = stmt.col_offset
        first = rest[0].lineno
        if rest[0].decorator_list if hasattr(rest[0], "decorator_list") and rest[0].decorator_list else False:
            first = rest[0].decorator_list[0].lineno
        # Kommentare/Leerzeilen direkt vor dem ersten Folge-Statement gehören mit hinein
        last = func.end_lineno
        edits.append((stmt.end_lineno, first, last, indent, name))
        done.append((func.name, func.lineno))
    # von hinten nach vorne, damit Zeilennummern stimmen
    for stmt_end, first, last, indent, name in sorted(edits, reverse=True):
        pad = " " * indent
        body = lines[stmt_end:last]          # Zeilen stmt_end+1 .. last (0-basiert stmt_end..last-1)
        new = []
        for i, ln in enumerate(body, start=stmt_end + 1):
            if i in inner or not ln.strip():
                new.append(ln)
            else:
                new.append("    " + ln)
        # nachfolgende Leerzeilen am Ende nicht in den try-Block ziehen
        trail = []
        while new and not new[-1].strip():
            trail.insert(0, new.pop())
        lines[stmt_end:last] = [pad + "try:"] + new + [pad + "finally:", pad + f"    {name}.close()"] + trail
    out = "\n".join(lines)
    ast.parse(out)  # muss gültig bleiben
    if write and edits:
        open(path, "w", encoding="utf-8").write(out)
    return done, skipped


if __name__ == "__main__":
    write = "--write" in sys.argv
    total = 0
    for p in [a for a in sys.argv[1:] if not a.startswith("--")]:
        done, skipped = transform(p, write)
        total += len(done)
        print(f"{p}: {len(done)} umschlossen" + (f", {len(skipped)} ausgelassen" if skipped else ""))
        for name, ln, why in sorted(skipped, key=lambda s: s[1]):
            print(f"    – {name} (Zeile {ln}): {why}")
    print(f"gesamt umschlossen: {total}" + ("" if write else " (Trockenlauf)"))
