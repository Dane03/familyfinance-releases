"""Datei-Abgleich Belege <-> Datenbank. NUR LESEND: löscht, verschiebt und ändert nie etwas.

    python3 scripts/review/dateien.py                 # Testmodus (Temp-Kopie mit Demodaten)
    python3 scripts/review/dateien.py PFAD/zu/data    # prüft einen vorhandenen Datenordner (nur lesend)

Meldet
  a) Dateien in den Beleg-Ordnern unter data/ (Ausgaben inkl. _archiv/_unbestaetigt, Gehalt, Vorsorge,
     Vermoegen, Personendokumente, alte Ordner wie receipts/ ...) ohne Datenbankeintrag,
  b) Datenbankeinträge (receipts -- auch Ablesefotos und Vermögensbelege --, payslips, pension_documents,
     person_documents), deren Datei fehlt. Liegt eine Datei gleichen Namens bzw. gleicher Prüfsumme woanders
     unter data/, wird das als "verschoben" gemeldet (die App korrigiert den Pfad beim nächsten Öffnen selbst)
     und die Datei zählt nicht als verwaist.
Berücksichtigt werden beide Datenbanken im Ordner (finance.db und demo.db), da sie sich data/ teilen.
Nicht geprüft: backups/, smart_import_staging/ (räumt die App beim Start selbst auf), lose Dateien direkt in
data/ (Datenbanken, Schlüssel), versteckte/macOS-Hilfsdateien. iCloud-Platzhalter (.name.icloud) gelten als
vorhanden ("nur in iCloud").

Datenbanken werden schreibgeschützt geöffnet (mode=ro, notfalls immutable=1).
Exit-Code: Prüfmodus 1 bei Befund, Testmodus 1 wenn nicht genau die präparierten Fälle gemeldet werden.
"""
import hashlib
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

DOC_TABLES = ("receipts", "payslips", "pension_documents", "person_documents")
DB_NAMES = ("finance.db", "demo.db")
SKIP_TOP_DIRS = {"backups", "smart_import_staging", "__pycache__"}
SKIP_SUFFIXES = (".db", ".db-journal", ".db-wal", ".db-shm", ".key", ".tmp")
SKIP_NAMES = {".DS_Store", ".gitkeep", "secret.key", "Thumbs.db", "desktop.ini"}


def _key(rel: str) -> str:
    # macOS (APFS) ist standardmäßig ohne Groß-/Kleinschreibung -> casefold, damit nichts doppelt gemeldet wird
    return os.path.normpath(rel).replace("\\", "/").casefold()


def _open_ro(path: Path) -> sqlite3.Connection:
    uri = path.resolve().as_uri()
    try:
        conn = sqlite3.connect(f"{uri}?mode=ro", uri=True)
        conn.execute("SELECT 1 FROM sqlite_master LIMIT 1").fetchall()
    except sqlite3.OperationalError:
        conn = sqlite3.connect(f"{uri}?immutable=1", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def scan_files(data_dir: Path) -> dict:
    """{schlüssel: (relativer Pfad ab App-Ordner, Path, icloud)} aller Beleg-Dateien unter data/."""
    base = data_dir.parent
    found = {}
    for dirpath, dirnames, filenames in os.walk(data_dir):
        here = Path(dirpath)
        if here == data_dir:
            dirnames[:] = [d for d in dirnames if d not in SKIP_TOP_DIRS]
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        if here == data_dir:
            continue   # lose Dateien direkt in data/ = Datenbanken/Hilfsdateien
        for name in filenames:
            icloud = False
            if name.startswith(".") and name.endswith(".icloud"):
                icloud, name = True, name[1:-len(".icloud")]
            elif name.startswith(".") or name in SKIP_NAMES or name.lower().endswith(SKIP_SUFFIXES):
                continue
            p = here / name
            rel = p.relative_to(base).as_posix()
            found[_key(rel)] = (rel, p, icloud)
    return found


def db_entries(data_dir: Path) -> list:
    """[(db, tabelle, id, stored_path, file_hash)] aus allen vorhandenen Datenbanken."""
    out = []
    for db_name in DB_NAMES:
        db = data_dir / db_name
        if not db.is_file():
            continue
        conn = _open_ro(db)
        try:
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for t in DOC_TABLES:
                if t not in tables:
                    continue
                cols = {r[1] for r in conn.execute(f"PRAGMA table_info({t})")}
                hash_col = "file_hash" if "file_hash" in cols else "NULL"
                for r in conn.execute(f"SELECT id, stored_path, {hash_col} FROM {t} ORDER BY id"):
                    out.append((db_name, t, r[0], r[1] or "", r[2]))
        finally:
            conn.close()
    return out


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def check(data_dir: Path) -> dict:
    data_dir = Path(data_dir).resolve()
    base = data_dir.parent
    files = scan_files(data_dir)
    entries = db_entries(data_dir)
    referenced, missing, icloud_only = set(), [], []
    for db, t, rid, sp, fh in entries:
        p = Path(sp)
        rel = p.relative_to(base).as_posix() if p.is_absolute() and p.is_relative_to(base) else sp
        k = _key(rel)
        if sp and k in files:
            referenced.add(k)
            if files[k][2]:
                icloud_only.append((db, t, rid, sp))
            continue
        missing.append([db, t, rid, sp, fh, None])
    orphans = {k: v for k, v in files.items() if k not in referenced}
    # Verschoben? Gleicher Dateiname (eindeutig bzw. passende Prüfsumme) oder gleiche Prüfsumme -- wie
    # shared_helpers.locate_document_file, aber ohne den Pfad in der DB zu korrigieren.
    hashes = {}
    for m in missing:
        db, t, rid, sp, fh, _ = m
        name = Path(sp).name.casefold()
        cands = [k for k, v in orphans.items() if Path(v[0]).name.casefold() == name and not v[2]] if name else []
        hit = None
        if len(cands) == 1 and (not fh or _sha(orphans[cands[0]][1]) == fh):
            hit = cands[0]
        if not hit and fh:
            for k in cands + [k for k, v in orphans.items() if not v[2] and k not in cands]:
                if k not in hashes:
                    hashes[k] = _sha(orphans[k][1])
                if hashes[k] == fh:
                    hit = k
                    break
        if hit:
            m[5] = orphans[hit][0]
    moved_to = {_key(m[5]) for m in missing if m[5]}
    return {
        "files": len(files), "entries": len(entries),
        "orphans": sorted(v[0] for k, v in orphans.items() if k not in moved_to),
        "missing": [tuple(m[:4]) for m in missing if not m[5]],
        "moved": [(m[0], m[1], m[2], m[3], m[5]) for m in missing if m[5]],
        "icloud": icloud_only,
    }


def report(res: dict) -> int:
    print(f"{res['files']} Dateien, {res['entries']} Datenbankeinträge geprüft.")
    print(f"Dateien ohne Datenbankeintrag: {len(res['orphans'])}")
    for rel in res["orphans"]:
        print(f"  - {rel}")
    print(f"Einträge, deren Datei fehlt: {len(res['missing'])}")
    for db, t, rid, sp in res["missing"]:
        print(f"  - {db} {t} #{rid}: {sp or '(kein Pfad)'}")
    if res["moved"]:
        print(f"Verschoben (App korrigiert den Pfad beim Öffnen): {len(res['moved'])}")
        for db, t, rid, sp, new in res["moved"]:
            print(f"  - {db} {t} #{rid}: {sp} -> {new}")
    if res["icloud"]:
        print(f"Nur in iCloud (Platzhalter, gilt als vorhanden): {len(res['icloud'])}")
    return 1 if res["orphans"] or res["missing"] else 0


# ---------------------------------------------------------------- Testmodus
def selftest() -> int:
    backend = Path(__file__).resolve().parents[2] / "backend"
    tmp = Path(tempfile.mkdtemp(prefix="ff_dateien_"))
    fails = []
    try:
        shutil.copytree(backend, tmp / "backend", ignore=shutil.ignore_patterns("__pycache__"))
        (tmp / "data").mkdir()
        # Demo-DB in der Kopie erzeugen (BASE_DIR der Kopie = tmp, echte Daten bleiben unberührt)
        r = subprocess.run([sys.executable, "-c",
                            "import sys; sys.path.insert(0,'.'); import database, demo_data; "
                            "database.init_db(); demo_data.generate_demo_db()"],
                           cwd=tmp / "backend", capture_output=True, text=True)
        if r.returncode:
            print("✗ Demodaten konnten nicht erzeugt werden:\n" + r.stderr[-2000:])
            return 1
        data = tmp / "data"

        def put(rel, content=b"x"):
            p = tmp / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(content)
            return hashlib.sha256(content).hexdigest()

        c = sqlite3.connect(data / "demo.db")
        acc = c.execute("SELECT id FROM pension_accounts LIMIT 1").fetchone()[0]
        person = c.execute("SELECT id FROM family_members LIMIT 1").fetchone()[0]
        income = c.execute("SELECT id FROM income LIMIT 1").fetchone()[0]
        contract = c.execute("SELECT id FROM contracts LIMIT 1").fetchone()[0]
        # Korrekte Fälle (dürfen nicht gemeldet werden)
        h = put("data/Ausgaben/Person/Haus/beleg_ok.pdf", b"beleg")
        c.execute("INSERT INTO receipts(original_filename,stored_path,file_hash,contract_id,review_needed) "
                  "VALUES ('beleg_ok.pdf','data/Ausgaben/Person/Haus/beleg_ok.pdf',?,?,0)", (h, contract))
        h = put("data/Ausgaben/_unbestaetigt/zaehler.jpg", b"foto")
        rid = c.execute("INSERT INTO receipts(original_filename,stored_path,file_hash) "
                        "VALUES ('zaehler.jpg','data/Ausgaben/_unbestaetigt/zaehler.jpg',?)", (h,)).lastrowid
        c.execute("INSERT INTO meter_readings(meter_type,reading_date,value,receipt_id) VALUES ('gas','2026-10-02',1,?)", (rid,))
        h = put("data/Gehalt/Person/abrechnung.pdf", b"gehalt")
        c.execute("INSERT INTO payslips(original_filename,stored_path,file_hash,income_id) "
                  "VALUES ('abrechnung.pdf','data/Gehalt/Person/abrechnung.pdf',?,?)", (h, income))
        h = put("data/Vorsorge/Person/Konto/info.pdf", b"rente")
        c.execute("INSERT INTO pension_documents(pension_account_id,original_filename,stored_path,file_hash) "
                  "VALUES (?,'info.pdf','data/Vorsorge/Person/Konto/info.pdf',?)", (acc, h))
        # Nur in iCloud ausgelagert -> gilt als vorhanden
        put("data/Personendokumente/Person/.ausweis.pdf.icloud")
        c.execute("INSERT INTO person_documents(person_id,original_filename,stored_path) "
                  "VALUES (?,'ausweis.pdf','data/Personendokumente/Person/ausweis.pdf')", (person,))
        # Verschoben (Ordner umbenannt): kein Befund, sondern Hinweis
        h = put("data/Ausgaben/_archiv/Person/Alt_1/alt.pdf", b"archiviert")
        c.execute("INSERT INTO receipts(original_filename,stored_path,file_hash,review_needed) "
                  "VALUES ('alt.pdf','data/Ausgaben/Person/Alt/alt.pdf',?,0)", (h,))
        # Präparierte Fehler: genau diese beiden müssen gemeldet werden
        put("data/Vorsorge/Person/Konto/verwaist.pdf", b"niemand kennt mich")
        missing_id = c.execute("INSERT INTO payslips(original_filename,stored_path,income_id) "
                               "VALUES ('weg.pdf','data/Gehalt/Person/weg.pdf',?)", (income,)).lastrowid
        c.commit()
        c.close()
        # Darf nie gemeldet werden: Sicherungen, Import-Zwischenablage, Hilfsdateien
        put("data/backups/finance_2026-10-01.db")
        put("data/smart_import_staging/tmp.pdf")
        put("data/Ausgaben/.DS_Store")
        put("data/notiz.txt")

        before = {p: p.stat().st_mtime_ns for p in data.rglob("*") if p.is_file()}
        res = check(data)
        rc = report(res)
        after = {p: p.stat().st_mtime_ns for p in data.rglob("*") if p.is_file()}

        def expect(name, got, want):
            ok = got == want
            print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
            if not ok:
                fails.append(name)

        print("--- Testmodus")
        expect("verwaiste Datei", res["orphans"], ["data/Vorsorge/Person/Konto/verwaist.pdf"])
        expect("Eintrag ohne Datei", res["missing"], [("demo.db", "payslips", missing_id, "data/Gehalt/Person/weg.pdf")])
        expect("verschoben erkannt", [m[4] for m in res["moved"]], ["data/Ausgaben/_archiv/Person/Alt_1/alt.pdf"])
        expect("iCloud-Platzhalter vorhanden", len(res["icloud"]), 1)
        expect("Exit-Code bei Befund", rc, 1)
        expect("nichts verändert (Dateien, Zeitstempel)", after == before, True)
        # Gegenprobe: nach Beheben der beiden Fehler (in der Temp-Kopie) ist alles sauber
        (data / "Vorsorge/Person/Konto/verwaist.pdf").unlink()
        put("data/Gehalt/Person/weg.pdf")
        import contextlib, io
        with contextlib.redirect_stdout(io.StringIO()):
            rc2 = report(check(data))
        expect("sauber nach Beheben -> Exit 0", rc2, 0)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("ALLES GRÜN" if not fails else f"FEHLER: {fails}")
    return 1 if fails else 0


if __name__ == "__main__":
    if len(sys.argv) > 1:
        d = Path(sys.argv[1]).expanduser()
        if d.name != "data" and (d / "data").is_dir():
            d = d / "data"   # App-Ordner statt data/ angegeben
        if not d.is_dir():
            sys.exit(f"Kein Ordner: {d}")
        sys.exit(report(check(d)))
    sys.exit(selftest())
