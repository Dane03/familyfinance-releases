"""PV-Tageswert nach Mitternacht (v357). Ohne Server, ohne Netz, Sekunden.
    cd kopie/backend && python3 ../scripts/review/pvtag.py
Exit-Code 0 = alles grün. Arbeitet nur in einem Temp-Ordner.

Anlass: Die Sungrow-Cloud setzt die Tageszähler nicht pünktlich um Mitternacht zurück. Der erste Abruf nach
Mitternacht lieferte die Endstände von gestern, die App speicherte sie unter heutigem Datum, und weil Tageswerte
„nur wachsen“, blieb der Vortageswert stehen (28.10.2026 = 27.10.).

Fälle:
 1) `device_date_of`: Format JJJJMMTTHHMMSS, Unsinn -> None.
 2) Abruf mit Gerätezeit von gestern -> nichts gespeichert, Status nennt den Grund.
 3) Ohne Gerätezeit vor 05:00 mit PV > 0,1 kWh -> nichts gespeichert; mit zurückgesetzten Zählern -> gespeichert.
 4) Ohne Gerätezeit tagsüber, PV und Einspeisung wie gestern -> nichts gespeichert.
 5) Echter heutiger Wert -> gespeichert; späterer kleinerer Wert ändert nichts (nur wachsend bleibt).
 6) Altbestand: heutiger Wert ist Kopie von gestern -> echter (kleinerer) Wert ersetzt ihn, Monat sinkt mit.
 7) Importierter (größerer) Monat wird beim Ersetzen nicht verkleinert.
 8) „Verlauf korrigieren“: Kopie-Tage bekommen PV/Einspeisung/Bezug aus dem Verlauf, normale Tage nur den
    Hausverbrauch, Monat neu summiert; ohne Verlaufswert bleibt der Tag als „noch mit Vortageswerten“ gemeldet.
"""
import contextlib
import io
import sqlite3
import sys
import tempfile
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
TMP = Path(tempfile.mkdtemp(prefix="ff_pvtag_"))
(TMP / "data").mkdir()

import database  # noqa: E402
import maintenance  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"
maintenance.BASE_DIR = TMP

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
    import app as appmod
import auth  # noqa: E402
import energy_routes as er  # noqa: E402
import sungrow_v1_client as sg  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

appmod.app.dependency_overrides[auth.require_full_auth] = lambda: {"stage": "full"}
cl = TestClient(appmod.app, base_url="http://localhost:8420", raise_server_exceptions=False)

CREDS = {"appkey": "a", "access_key": "k", "rsa_public": None, "account": "x", "password": "p",
         "ps_id": "123", "token": "t"}
er._get_sungrow_v1 = lambda conn: dict(CREDS)
er._save_sungrow_v1 = lambda conn, data: None

SAMPLE = {}
NOW = [datetime(2026, 10, 28, 0, 30)]
ORIG_GET_TODAY = sg.get_today_values
sg.get_today_values = lambda *a, **k: dict(SAMPLE)
er._now = lambda: NOW[0]


def db():
    c = sqlite3.connect(database.DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def day(key):
    r = db().execute("SELECT pv, einsp, bezug, gesamt FROM pv_daily WHERE key=?", (key,)).fetchone()
    return None if r is None else (round(r["pv"], 3), round(r["einsp"], 3), round(r["bezug"], 3), round(r["gesamt"], 3))


def month(key):
    r = db().execute("SELECT pv, einsp, bezug FROM pv_monthly WHERE key=?", (key,)).fetchone()
    return None if r is None else (round(r["pv"], 3), round(r["einsp"], 3), round(r["bezug"], 3))


def sync(sample, now):
    SAMPLE.clear()
    SAMPLE.update(sample)
    NOW[0] = now
    c = db()
    try:
        return er._do_sungrow_v1_sync(c)
    finally:
        c.close()


def reset():
    c = db()
    c.execute("DELETE FROM pv_daily")
    c.execute("DELETE FROM pv_monthly")
    # 26.10.: 20,0 PV / 5,0 Einsp / 4,0 Bezug; 27.10.: 27,0 / 4,0 / 3,0 -> Oktober 47,0 / 9,0 / 7,0
    for k, pv, e, b in (("2026-10-26", 20.0, 5.0, 4.0), ("2026-10-27", 27.0, 4.0, 3.0)):
        c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES (?,?,?,?,0,0,?)",
                  (k, pv, b, e, pv - e + b))
    c.execute("INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2026-10',47,7,9,0,0,52)")
    c.commit()
    c.close()


YESTERDAY_STALE = {"pv": 27.0, "einsp": 4.0, "bezug": 3.2, "verbrauch": None}

# 1) Gerätezeit lesen
check("1 device_date_of gültig", sg.device_date_of("20241127151500"), "2024-11-27")
check("1 device_date_of leer", sg.device_date_of(None), None)
check("1 device_date_of Unsinn", sg.device_date_of("abc"), None)
check("1 device_date_of 13. Monat", sg.device_date_of("20241327000000"), None)

# 2) Gerätezeit von gestern
reset()
r = sync({**YESTERDAY_STALE, "device_date": "2026-10-27"}, datetime(2026, 10, 28, 9, 0))
check("2 nichts gespeichert", day("2026-10-28"), None)
check("2 Grund genannt", "27.10." in (r.get("skipped") or ""), True)
check("2 Monat unverändert", month("2026-10"), (47.0, 9.0, 7.0))

# 3) Ohne Gerätezeit nachts
reset()
sync({**YESTERDAY_STALE, "pv": 26.9}, datetime(2026, 10, 28, 0, 30))
check("3 nachts PV>0 -> nichts gespeichert", day("2026-10-28"), None)
sync({"pv": 0.0, "einsp": 0.0, "bezug": 0.4, "verbrauch": 0.4}, datetime(2026, 10, 28, 0, 30))
check("3 zurückgesetzte Zähler -> gespeichert", day("2026-10-28"), (0.0, 0.0, 0.4, 0.4))

# 4) Ohne Gerätezeit tagsüber, gleiche PV/Einspeisung wie gestern
reset()
sync(YESTERDAY_STALE, datetime(2026, 10, 28, 9, 0))
check("4 Kopie tagsüber -> nichts gespeichert", day("2026-10-28"), None)

# 5) echter Wert, dann kleinerer
reset()
sync({"pv": 2.5, "einsp": 0.0, "bezug": 1.5, "verbrauch": 3.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 9, 0))
check("5 echter Wert gespeichert", day("2026-10-28"), (2.5, 0.0, 1.5, 3.0))
check("5 Monat = 47,0 + 2,5", month("2026-10"), (49.5, 9.0, 8.5))
sync({"pv": 2.4, "einsp": 0.0, "bezug": 1.5, "verbrauch": 3.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 9, 30))
check("5 kleinerer Wert ändert PV nicht", day("2026-10-28")[0], 2.5)

# 6) Altbestand v356: 28.10. trägt die Werte vom 27.10.
reset()
c = db()
c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2026-10-28',27,3.2,4,0,0,26.2)")
c.execute("UPDATE pv_monthly SET pv=74, bezug=10.2, einsp=13 WHERE key='2026-10'")
c.commit()
c.close()
sync({"pv": 12.0, "einsp": 1.0, "bezug": 2.0, "verbrauch": 13.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 14, 0))
check("6 Kopie durch echten Wert ersetzt", day("2026-10-28"), (12.0, 1.0, 2.0, 13.0))
check("6 Monat sinkt mit (47+12 / 9+1 / 7+2)", month("2026-10"), (59.0, 10.0, 9.0))

# 7) importierter Monat ist größer als die Tagessumme -> nie verkleinern
reset()
c = db()
c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2026-10-28',27,3.2,4,0,0,26.2)")
c.execute("UPDATE pv_monthly SET pv=300, bezug=50, einsp=100 WHERE key='2026-10'")
c.commit()
c.close()
sync({"pv": 12.0, "einsp": 1.0, "bezug": 2.0, "verbrauch": 13.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 14, 0))
check("7 Tag ersetzt", day("2026-10-28")[0], 12.0)
check("7 importierter Monat bleibt", month("2026-10"), (300.0, 100.0, 50.0))

# 8) Verlauf korrigieren (Tage vor heute; „heute“ = echtes Datum, also Tage in der Vergangenheit anlegen)
c = db()
c.execute("DELETE FROM pv_daily")
c.execute("DELETE FROM pv_monthly")
rows = (("2020-05-01", 30.0, 10.0, 2.0), ("2020-05-02", 30.0, 10.0, 2.5),   # 02. = Kopie von 01.
        ("2020-05-03", 30.0, 10.0, 2.7))                                     # 03. = Kopie, Verlauf liefert nichts
for k, pv, e, b in rows:
    c.execute("INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES (?,?,?,?,0,0,?)",
              (k, pv, b, e, pv - e + b))
c.execute("INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt) VALUES ('2020-05',90,7.2,30,0,0,67.2)")
c.commit()
c.close()
TOTALS = {"2020-05-01": {"pv": 30.0, "einsp": 10.0, "bezug": 2.0, "verbrauch": 21.0},
          "2020-05-02": {"pv": 8.0, "einsp": 1.0, "bezug": 6.0, "verbrauch": 12.5},
          "2020-05-03": {"pv": None, "einsp": None, "bezug": None, "verbrauch": None}}
ORIG_GET_DAY = sg.get_day_totals
sg.get_day_totals = lambda *a, **k: dict(TOTALS[a[-1].isoformat()])
res = cl.post("/api/sungrow/v1/repair-history")
check("8 Status", res.status_code, 200)
j = res.json()
check("8 normaler Tag: nur Hausverbrauch", day("2020-05-01"), (30.0, 10.0, 2.0, 21.0))
check("8 Kopie-Tag ersetzt", day("2020-05-02"), (8.0, 1.0, 6.0, 12.5))
check("8 Tag ohne Verlauf unverändert", day("2020-05-03"), (30.0, 10.0, 2.7, 22.7))
check("8 gemeldet: ersetzt", [x["day"] for x in j.get("copies_fixed", [])], ["2020-05-02"])
check("8 gemeldet: offen", j.get("copies_unresolved"), ["2020-05-03"])
check("8 Monat neu summiert (30+8+30 / 10+1+10 / 2+6+2,7)", month("2020-05"), (68.0, 21.0, 10.7))

# 9) Hausverbrauch von Sungrow (p83118) -- Plausibilität (v364)
def raw_points(pv, einsp, bezug, load, device_time="20261029100000"):
    pts = {"p83022": str(pv * 1000), "p83072": str(einsp * 1000), "p83102": str(bezug * 1000), "device_time": device_time}
    if load is not None:
        pts["p83118"] = load if isinstance(load, str) else str(load * 1000)
    return {"result_code": "1", "result_data": {"device_point_list": [{"device_point": pts}]}}


orig_post, orig_check = sg._post, sg._check_token_response
sg._check_token_response = lambda data: None
try:
    def today_with(**kw):
        sg._post = lambda *a, **k: raw_points(**kw)
        return ORIG_GET_TODAY("a", "k", None, "t", "123")
    # Morgens nach einer Nacht aus der Batterie: 4,1 PV + 0,5 Netz, Verbrauch 8,0 (3,6 kWh aus der Batterie)
    r9 = today_with(pv=4.1, einsp=0.2, bezug=0.5, load=8.0)
    check("9 Batterie-Nacht: Sungrow-Wert übernommen (war bis v363 verworfen)", (r9["verbrauch"], r9["verbrauch_note"]), (8.0, None))
    r9 = today_with(pv=4.1, einsp=0.2, bezug=0.5, load=4.2)
    check("9 normaler Wert übernommen", r9["verbrauch"], 4.2)
    r9 = today_with(pv=4.1, einsp=0.2, bezug=0.5, load=4500.0)
    check("9 Faktor 1000 verworfen, mit Grund", (r9["verbrauch"], "unplausibel" in (r9["verbrauch_note"] or "")), (None, True))
    r9 = today_with(pv=4.1, einsp=0.2, bezug=0.5, load=None)
    check("9 Punkt fehlt: Grund genannt", (r9["verbrauch"], r9["verbrauch_note"]), (None, "Sungrow liefert den Punkt nicht"))
    r9 = today_with(pv=4.1, einsp=0.2, bezug=0.5, load="--")
    check("9 Punkt '--': wie fehlend", r9["verbrauch"], None)
    check("9 Gerätezeit gelesen", r9["device_date"], "2026-10-29")
finally:
    sg._post, sg._check_token_response = orig_post, orig_check

reset()
sync({"pv": 4.1, "einsp": 0.2, "bezug": 0.5, "verbrauch": None, "verbrauch_note": "Sungrow-Wert 4500.0 kWh unplausibel",
      "device_date": None}, datetime(2026, 10, 28, 10, 0))
msg = cl.get("/api/sungrow/v1/last-sync").json().get("message") or ""
check("9 Meldung nennt den Grund", "unplausibel" in msg, True)
check("9 Meldung nennt fehlende Gerätezeit", "Gerätezeit fehlt" in msg, True)
sync({"pv": 5.0, "einsp": 0.2, "bezug": 0.5, "verbrauch": 9.0, "device_date": "2026-10-28"}, datetime(2026, 10, 28, 11, 0))
check("9 Hausverbrauch aus Sungrow gespeichert", day("2026-10-28")[3], 9.0)

# 10) Verlauf: alle Wege probieren, 401 richtig einordnen (v365)
from datetime import date as _date  # noqa: E402
CALLS = []


def fake_post_by_path(answers):
    def f(path, payload, access_key, rsa_public, token=None):
        CALLS.append((path, payload))
        a = answers[path]
        if isinstance(a, Exception):
            raise a
        return a
    return f


ST, PF, DV = ("/openapi/getPowerStationPointMinuteDataList", "/openapi/platform/getPowerStationPointMinuteDataList",
              "/openapi/getDevicePointMinuteDataList")
E401 = sg.SungrowTokenExpired("Token abgelaufen (HTTP 401).")
orig_post = sg._post
try:
    CALLS.clear()
    sg._post = fake_post_by_path({ST: E401, PF: E401, DV: {"result_code": "1", "result_data": {"data": [
        {"time_stamp": "20261028233000", "points": {"p83022": "20000"}},
        {"time_stamp": "20261028235500", "points": {"p83022": "20100", "p83072": "4000", "p83102": "3000",
                                                    "p83118": {"value": "9800"}}}]}}})
    r10 = ORIG_GET_DAY("a", "k", None, "t", "123", _date(2026, 10, 28))
    check("10 Anlage 401 -> Geräteebene liefert (letzter Wert des Tages)", (r10["pv"], r10["verbrauch"]), (20.1, 9.8))
    check("10 alle drei Wege versucht (bis v364 Abbruch nach dem ersten)", [c[0] for c in CALLS], [ST, PF, DV])
    check("10 Geräteebene mit Gerätekennzeichen", CALLS[2][1].get("ps_key_list"), ["123_11_0_0"])

    sg._post = fake_post_by_path({ST: E401, PF: E401, DV: E401})
    try:
        ORIG_GET_DAY("a", "k", None, "t", "123", _date(2026, 10, 28))
        got = "kein Fehler"
    except sg.SungrowTokenExpired:
        got = "Token"
    check("10 alle 401 -> Token-Fehler", got, "Token")

    sg._post = fake_post_by_path({ST: E401, PF: {"result_code": "E900", "result_msg": "no permission"}, DV: E401})
    try:
        ORIG_GET_DAY("a", "k", None, "t", "123", _date(2026, 10, 28))
        got = "kein Fehler"
    except sg.SungrowTokenExpired:
        got = "Token"
    except sg.SungrowV1Error:
        got = "anderer Fehler"
    check("10 nicht alle 401 -> kein Token-Fehler (kein sinnloser Neu-Login)", got, "anderer Fehler")

    sg._post = fake_post_by_path({ST: {"result_code": "1", "result_data": {
        "123": [{"time_stamp": "20261028235500", "p83022": "21.5", "p83118": "11.25"}],
        "point_dict": [{"point_id": "83022", "point_unit": "kWh"}, {"point_id": "p83118", "point_unit": "kWh"}]}},
        PF: E401, DV: E401})
    r10 = ORIG_GET_DAY("a", "k", None, "t", "123", _date(2026, 10, 28))
    check("10 bisherige Antwortform (Anlage, Einheit kWh)", (r10["pv"], r10["verbrauch"]), (21.5, 11.25))
finally:
    sg._post = orig_post

LOGINS = []
orig_login, orig_totals = er._sungrow_v1_login, sg.get_day_totals


def always_401(*a, **k):
    raise sg.SungrowTokenExpired("Alle Verlaufs-Abrufe abgelehnt")


er._sungrow_v1_login = lambda conn, creds: LOGINS.append(1) or "frisch"
sg.get_day_totals = always_401
try:
    res = cl.post("/api/sungrow/v1/repair-history")
finally:
    er._sungrow_v1_login, sg.get_day_totals = orig_login, orig_totals
check("10 frischer Token, trotzdem 401 -> 502", res.status_code, 502)
check("10 Meldung nennt Berechtigung statt 'Token abgelaufen'", "nicht freigegeben" in res.json().get("detail", ""), True)
check("10 genau eine Neuanmeldung", len(LOGINS), 1)

print()
print("ALLES GRÜN" if not FAILS else f"FEHLER: {len(FAILS)} — {', '.join(FAILS)}")
sys.exit(1 if FAILS else 0)
