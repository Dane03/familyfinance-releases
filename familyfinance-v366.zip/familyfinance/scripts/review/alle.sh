#!/usr/bin/env bash
# Führt alle Review-Skripte aus scripts/review/ nacheinander in einer frischen Kopie des Projekts aus.
#   bash scripts/review/alle.sh               # alle Skripte
#   bash scripts/review/alle.sh update fk     # nur ausgewählte (Name ohne .py)
# Umgebungsvariablen: PYTHON (Standard: python3), PAUSE (Sekunden zwischen zwei Skripten, Standard: 5),
#                     BEHALTEN=1 (Kopie nach dem Lauf nicht löschen, z. B. zur Fehlersuche).
# Exit-Code 0 = alle grün, 1 = mindestens ein Skript fehlgeschlagen.
#
# Achtung: mehrere Skripte starten einen Server auf Port 8420 und einen Browser -- nicht parallel zu einer
# laufenden App bzw. zu anderen Testläufen starten. Die Pause zwischen den Skripten gibt den Port wieder frei.
set -u

QUELLE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PYTHON="${PYTHON:-python3}"
PAUSE="${PAUSE:-5}"

KOPIE="$(mktemp -d "${TMPDIR:-/tmp}/ff_review_XXXXXX")"
aufraeumen() {
    if [ "${BEHALTEN:-0}" = "1" ]; then
        echo "Kopie bleibt erhalten: $KOPIE"
    else
        rm -rf "$KOPIE"
    fi
}
trap aufraeumen EXIT

# Frische Kopie ohne Git-Daten, Caches, Datenbanken und Sicherungen (tar statt rsync: überall vorhanden).
( cd "$QUELLE" && tar -cf - \
    --exclude='./.git' --exclude='./.claude' --exclude='__pycache__' --exclude='*.pyc' \
    --exclude='./data' --exclude='./backups' --exclude='node_modules' . ) | ( cd "$KOPIE" && tar -xf - )
mkdir -p "$KOPIE/data"
cd "$KOPIE/backend" || { echo "FEHLER: backend/ fehlt in der Kopie"; exit 1; }

# Skriptliste: alle *.py in scripts/review/ (alphabetisch), dieses Sammelskript selbst ist keine .py-Datei.
SKRIPTE=()
if [ "$#" -gt 0 ]; then
    for name in "$@"; do
        name="${name%.py}"
        if [ -f "../scripts/review/$name.py" ]; then
            SKRIPTE+=("$name.py")
        else
            echo "FEHLER: unbekanntes Skript $name.py"
            exit 1
        fi
    done
else
    for f in ../scripts/review/*.py; do
        SKRIPTE+=("$(basename "$f")")
    done
fi

echo "Projektkopie: $KOPIE  (${#SKRIPTE[@]} Skripte, Logs in $KOPIE/review-logs/)"
mkdir -p "$KOPIE/review-logs"

FEHLGESCHLAGEN=0
ERSTES=1
for skript in "${SKRIPTE[@]}"; do
    if [ "$ERSTES" = "0" ]; then
        sleep "$PAUSE"
    fi
    ERSTES=0
    rm -f ../data/*.db
    log="$KOPIE/review-logs/${skript%.py}.log"
    start=$(date +%s)
    "$PYTHON" "../scripts/review/$skript" >"$log" 2>&1
    rc=$?
    dauer=$(( $(date +%s) - start ))
    if [ "$rc" -eq 0 ]; then
        zeile=$(printf '%-8s %-24s %4ss' "OK" "$skript" "$dauer")
    else
        zeile=$(printf '%-8s %-24s %4ss  (Exit %s, letzte Zeile: %s)' "FEHLER" "$skript" "$dauer" "$rc" \
            "$(tail -n 1 "$log" | cut -c1-120)")
        FEHLGESCHLAGEN=$((FEHLGESCHLAGEN + 1))
        BEHALTEN=1   # Logs zur Fehlersuche aufheben
    fi
    echo "$zeile"
done

echo
if [ "$FEHLGESCHLAGEN" -eq 0 ]; then
    echo "ALLE ${#SKRIPTE[@]} SKRIPTE GRÜN"
    exit 0
fi
echo "$FEHLGESCHLAGEN von ${#SKRIPTE[@]} Skripten FEHLGESCHLAGEN"
exit 1
