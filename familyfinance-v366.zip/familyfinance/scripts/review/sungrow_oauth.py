"""Sungrow-OAuth-Rücksprung nur aus einer selbst gestarteten Anmeldung (v362). Ohne Server, ohne Netz, Sekunden.
    cd kopie/backend && python3 ../scripts/review/sungrow_oauth.py
Exit-Code 0 = alles grün.

iSolarCloud kennt keinen OAuth-"state". Ohne Schutz konnte ein untergeschobener Link
/api/sungrow/oauth/callback?code=<fremder Code> (Cookie wird bei Top-Level-Navigation mitgeschickt) die Verbindung
auf ein fremdes Sungrow-Konto umbiegen. Der Rücksprung nimmt deshalb nur einen Code an, wenn dieselbe Sitzung kurz
vorher /api/sungrow/oauth/authorize-url abgerufen hat -- einmalig, höchstens 10 Minuten.

Fälle:
 1) Rücksprung ohne vorherigen Start -> abgelehnt, kein Token-Tausch, nichts gespeichert.
 2) Start in Sitzung A, Rücksprung in Sitzung B -> abgelehnt.
 3) Start und Rücksprung in A -> Token gespeichert; derselbe Rücksprung ein zweites Mal -> abgelehnt.
 4) Start, dann > 10 Minuten -> abgelehnt.
 5) Abbruch bei Sungrow (error=…) beendet den Vorgang; ein späterer Code ohne neuen Start -> abgelehnt.
 6) Rücksprungseite bleibt CSP-geschützt (Nonce), Meldung maskiert.

Mutationstest: auf v361 schlägt Fall 1 an (fremde Token werden gespeichert).
"""
import asyncio
import contextlib
import io
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))

TMP = Path(tempfile.mkdtemp(prefix="ff_sgoauth_"))
(TMP / "data").mkdir()

import database  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"
with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()

import auth  # noqa: E402
import energy_routes as er  # noqa: E402
import sungrow_client  # noqa: E402
from fastapi import FastAPI, Request  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


EXCHANGED = []


async def fake_authorize_url(appkey, access_key, app_id, region, redirect_uri):
    return f"https://web3.isolarcloud.eu/#/authorized-app?applicationId={app_id}"


async def fake_exchange(appkey, access_key, app_id, region, code, redirect_uri):
    EXCHANGED.append(code)
    return {"access_token": f"tok-{code}", "refresh_token": "r", "expires_at": 9999999999}


sungrow_client.oauth_authorize_url = fake_authorize_url
sungrow_client.oauth_exchange_code = fake_exchange

api = FastAPI()
api.include_router(er.router)


def fake_session(request: Request):
    return {"stage": "full", "sid": request.headers.get("x-test-sid", "A")}


api.dependency_overrides[auth.require_full_auth] = fake_session
cl = TestClient(api, base_url="http://localhost:8420", raise_server_exceptions=False)

with database.db() as conn:
    er._save_sungrow_oauth_credentials(conn, {"appkey": "k", "access_key": "s", "app_id": "42", "region": "Europe"})


def stored_token():
    with database.db() as conn:
        return ((er._get_sungrow_oauth_credentials(conn) or {}).get("tokens") or {}).get("access_token")


def start(sid="A"):
    return cl.get("/api/sungrow/oauth/authorize-url",
                  params={"redirect_uri": "http://localhost:8420/api/sungrow/oauth/callback"},
                  headers={"x-test-sid": sid})


def back(sid="A", **params):
    return cl.get("/api/sungrow/oauth/callback", params=params, headers={"x-test-sid": sid})


print("— 1) ohne Start")
r = back(code="FREMD")
check("1 Seite ausgeliefert", r.status_code, 200)
check("1 Hinweis 'nicht aus der App gestartet'", "nicht aus der App gestartet" in r.text, True)
check("1 kein Token-Tausch", EXCHANGED, [])
check("1 nichts gespeichert", stored_token(), None)

print("— 2) andere Sitzung")
check("2 Start in A: 200", start("A").status_code, 200)
r = back("B", code="FREMD")
check("2 Rücksprung in B abgelehnt", "nicht aus der App gestartet" in r.text, True)
check("2 nichts gespeichert", stored_token(), None)

print("— 3) eigene Sitzung, einmalig")
r = back("A", code="ECHT")
check("3 Rücksprung in A angenommen", "nicht aus der App" not in r.text, True)
check("3 Token gespeichert", stored_token(), "tok-ECHT")
r = back("A", code="NOCHMAL")
check("3 zweiter Rücksprung abgelehnt", "nicht aus der App gestartet" in r.text, True)
check("3 Token unverändert", stored_token(), "tok-ECHT")

print("— 4) abgelaufen")
start("A")
orig_clock = er._oauth_clock
er._oauth_clock = lambda: orig_clock() + er.SUNGROW_OAUTH_TTL_SECONDS + 1
try:
    r = back("A", code="SPAET")
finally:
    er._oauth_clock = orig_clock
check("4 nach > 10 min abgelehnt", "nicht aus der App gestartet" in r.text, True)
check("4 Token unverändert", stored_token(), "tok-ECHT")

print("— 5) Abbruch beendet den Vorgang")
start("A")
r = back("A", error="access_denied")
check("5 Abbruch-Meldung", "abgebrochen" in r.text, True)
r = back("A", code="DANACH")
check("5 Code danach ohne neuen Start abgelehnt", "nicht aus der App gestartet" in r.text, True)
check("5 Token unverändert", stored_token(), "tok-ECHT")

print("— 6) Rücksprungseite")
csp = r.headers.get("content-security-policy", "")
check("6 CSP mit Nonce", "nonce-" in csp, True)
check("6 keine rohen spitzen Klammern aus der Meldung", "<script nonce" in r.text and r.text.count("<") == 4, True)
check("Tausch nur für echte Anmeldung", EXCHANGED, ["ECHT"])

print()
if FAILS:
    print(f"✗ Sungrow-OAuth: {len(FAILS)} Fehler: {', '.join(FAILS)}")
    sys.exit(1)
print("✓ Sungrow-OAuth: alle Fälle stimmen")
