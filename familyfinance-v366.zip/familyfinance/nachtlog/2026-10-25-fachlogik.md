# Nachtlauf 2026-10-25 – Fachlogik & Rechenkorrektheit

**Rolle:** Fachlogik (Sonntag, Berliner Zeit) · **Geprüfter Stand:** `master` @ `8a5e639`, Build v351 · **Ergebnis-Build:** v351 (keine ausgelieferte Datei geändert, daher keine Build-Erhöhung), kein Release gebaut.

**Aktualitäts-Check:** `latest.json` meldet v351, `master` steht ebenfalls bei v351 – aktuell. Keine offenen PRs, keine Überschneidungen.

## Geändert
1. **Regressionsschutz erweitert** (`scripts/review/rechnen.py`, README-Zeile ergänzt). Neue, von Hand nachrechenbare Fälle:
   - Gas-Jahresabrechnung: 10 m³/Tag → 3.650 m³ × Faktor 10 = 36.500 kWh; Kosten 36.500 × 0,10 € + 12 × 10 € = **3.770 €**; Abschläge 1.200 € → Differenz **−2.570 €**.
   - Einspeisung: 3.650 kWh × 0,08 € = **292 €** (kein Grundpreis).
   - Autarkie: (10 − 6) / 10 = 40 %; ohne Verbrauch 0; Bezug > Verbrauch 0 (nie negativ).
   - Test: `rechnen.py` in Projektkopie, alle Fälle grün (alte und neue). Kein App-Code geändert.

## Geprüft und rechnerisch korrekt
- Alle Befunde vom 11.10. sind behoben (29.02., 0-%-Darlehen, effektiver Monatszins) und durch `rechnen.py` abgesichert.
- Tilgungsplan: Annuität, letzte Rate gekappt, Rate unter Zinsen → klare Meldung; Quartals-/Jahresraten werden an allen drei Aufrufstellen (`app.py`, `vermoegen_routes.py`, `vorsorge_routes.py`) auf Monatswerte normiert.
- Jahres-Hochrechnung Gas (Stichprobe mit 296 Tagen Daten): Ist 2.830 m³ + Rest Oktober + Nov/Dez mit gewichteter Rate = 3.489,69 m³ ✓, Kosten stimmen mit Chips und Abrechnung überein.
- Laufender Monat: Hochrechnung der Resttage (`data_through`) konsistent für Zähler und Sungrow.
- Kostenbeteiligung/`split_share`: `report.py` und `monthly_expr` rechnen identisch; Hinweis bei doppelter Anteilsrechnung ist vorhanden.
- Autarkie-Formel (Hausverbrauch − Netzbezug) / Hausverbrauch, im laufenden Teilmonat unverzerrt (Zähler und Nenner gleicher Zeitraum).

## Befunde (nicht geändert)
**Niedrig**
- `meters.py` `forecast_missing_months` (Vorjahresmonat × Trend): Februar im Schaltjahr wird nicht um 29/28 skaliert (+3,6 % in einem Monat, <0,3 % aufs Jahr). Tritt erst ab Herbst 2027 auf (Prognose Feb 2028). Vorschlag: Vorjahreswert / Tage(Vorjahresmonat) × Tage(Zielmonat).
- `meters.period_consumption`: Parameter `today` wird nicht verwendet, intern gilt `date.today()`. Nur Testbarkeit, kein Rechenfehler.

## Bewusst nicht geändert
- Schaltjahr-Skalierung: Wirkung unter 0,3 %/Jahr und erst ab 2027, Prognosecode ist fein abgestimmt (siehe Kommentare).

## Offen / braucht Benjamin
- Weiterhin offen aus früheren Läufen: Gas-Umrechnungsfaktor mit Rechnung abgleichen; Strom-Tagesrate und Haushalt/Auto mit echten Sungrow-/Zappi-Daten plausibilisieren.

## Vorschlag nächster Lauf (Fachlogik)
- Vorsorge-Projektion (Sparraten + Rendite + Rente) und Dashboard-Überschuss/Sparquote mit Demodaten End-to-End nachrechnen (Endpunkt-Ebene, nicht nur Funktionen).
- Optional: Schaltjahr-Skalierung der Februar-Prognose mit Test.
