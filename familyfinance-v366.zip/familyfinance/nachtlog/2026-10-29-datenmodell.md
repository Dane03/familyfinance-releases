# Nachtlauf 2026-10-29 – Datenmodell

**Rolle:** Datenmodell (Donnerstag, Berliner Zeit) · **Geprüfter Stand:** `master` @ `25dba46`, Build v357 · **Ergebnis-Build:** v358 (2026-10-29), kein Release gebaut.
**Aktualitäts-Check:** `latest.json` meldet v357, `master` steht ebenfalls bei v357 – aktuell. Releases-Repo nur lesend (raw.githubusercontent.com). `add_repo` stand nicht als Werkzeug zur Verfügung; Repo war bereits geklont und im Scope. Keine offenen `nacht/`-PRs geprüft (kein GitHub-Listing nötig, Änderung berührt nur einen Kommentar).

## Geändert
1. **Echter Name aus Code-Kommentar entfernt** (`backend/bank_matching.py`, Docstring `split_name_iban`): Das Beispiel enthielt einen realen Familiennamen und wird mit der App ausgeliefert. Ersetzt durch „Max Mustermann“. Nur Kommentar, keine Logik.
2. Build v358 / Cache `familyfinance-v358`, Datum 2026-10-29.

## Geprüft, unauffällig (Projektkopie, Demodaten / leere DB, `http://localhost:8420`)
- **Migrations-Idempotenz:** (a) Datenbank mit Schema von v315 (`29097fe`) → aktueller `init_db()`; (b) Demo-DB. Je drei Starts hintereinander: Dump nach Start 2 und 3 **identisch** (SHA-256), `integrity_check` ok, `foreign_key_check` leer, 40 Indizes stabil.
- **Verwaiste Verweise** in Spalten ohne Fremdschlüssel (`income.person_id`, `bank_transactions.contract_id/income_id`): 0.
- **Feste Personennamen** im Code (`backend/*.py`, `frontend/*`): außer Befund 1 keine.
- `py_compile`, `node --check`, `fk.py` (13 DELETE-Routen, 0 Serverfehler/Verwaiste), `xss.py` (nicht ausgelöst), `rechnen.py` (alle Fälle stimmen). `design.py` nicht nötig (keine Oberflächenänderung).

## Befunde (nicht geändert)
**Mittel**
- Datenbankverbindungen ohne `try/finally` (Muster im ganzen Backend, siehe Log 15.10.) – großer Umbau.
**Niedrig**
- Per Migration ergänzte Spalten haben keinen Fremdschlüssel; Konsistenz hängt am App-Code (`fk.py` prüft sie, heute sauber).
- `_cleanup_unconfirmed_receipts` löscht Dateien vor dem DB-Eintrag (unkritisch, unbestätigte Belege sind nirgends verknüpft).

## Bewusst nicht geändert
- Keine Migration, kein Schema-Eingriff: nichts Auffälliges gefunden, der Nutzen wäre gering.
- Datei-Abgleich mit echten Belegen (`dateien.py`) braucht den echten Datenordner – nicht in der Cloud-Routine ausführbar.

## Offen / braucht Benjamin
- Optional `python3 scripts/review/dateien.py PFAD/zu/data` einmal gegen den echten Datenordner laufen lassen (nur lesend).
- Release bauen (nach dem Mergen).

## Vorschlag nächster Lauf (Datenmodell)
- `try/finally`-Muster für Verbindungen: `get_connection()` als Kontextmanager, zunächst nur in 2–3 Schreib-Endpunkten.
- Optionaler Test, der Idempotenz mit einer DB mit `source='import'`-Verträgen (Migration `_pin_changed_import_categories_once`) abdeckt.
