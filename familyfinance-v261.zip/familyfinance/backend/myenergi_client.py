"""
Client für die (von myenergi selbst als "inoffiziell unterstützt"
bezeichnete) myenergi-API — liest die täglich geladene Energiemenge der
Zappi-Wallbox aus, um sie als eigenen Zählertyp ("ev_charging") in die App
zu übernehmen und so vom normalen Hausverbrauch zu trennen.

WICHTIG, ehrlich gesagt: Diese API ist nicht offiziell dokumentiert. Der
Authentifizierungs-Ablauf (Director-Weiterleitung + Digest-Auth mit der
Hub-Seriennummer) ist gut belegt und wird von mehreren seit Jahren
funktionierenden Open-Source-Projekten genutzt (siehe z.B.
github.com/twonk/MyEnergi-App-Api, github.com/G6EJD/MyEnergi-Python-Example).
Das genaue Feldformat der Tagesdaten-Antwort konnte ich mangels Netzzugriff
in dieser Umgebung nicht gegen die echten Server verifizieren — die
Fehlermeldungen unten sind bewusst konkret gehalten, damit ein
abweichendes Format beim ersten echten Test sofort auffällt, statt
stillschweigend falsche Werte zu übernehmen.
"""
import httpx
from datetime import date, timedelta
from typing import Optional

DIRECTOR_HOST = "director.myenergi.net"


class MyenergiError(Exception):
    pass


def _client(hub_serial: str, hub_password: str, host: str) -> httpx.Client:
    return httpx.Client(
        auth=httpx.DigestAuth(hub_serial, hub_password),
        base_url=f"https://{host}",
        timeout=15.0,
        headers={"User-Agent": "FamilyFinance/1.0"},
    )


def _resolve_server(hub_serial: str, hub_password: str) -> str:
    """Der Director gibt per Response-Header bekannt, welcher Regionalserver
    für den jeweiligen Hub zuständig ist -- ALLE weiteren Aufrufe müssen
    gegen DIESEN Server gehen, nicht gegen den Director selbst."""
    with _client(hub_serial, hub_password, DIRECTOR_HOST) as c:
        r = c.get(f"/cgi-jstatus-E{hub_serial}")
        if r.status_code == 401:
            raise MyenergiError("Anmeldung fehlgeschlagen — Hub-Seriennummer oder Passwort falsch.")
        r.raise_for_status()
        server = r.headers.get("x_myenergi-asn")
        if not server:
            raise MyenergiError(
                "Der Director hat keinen zuständigen Server genannt (Header "
                "'x_myenergi-asn' fehlt) — das API-Format hat sich vermutlich "
                "geändert."
            )
        return server


def test_connection(hub_serial: str, hub_password: str) -> dict:
    """Nur Zugangsdaten prüfen, ohne Daten zu importieren — für einen
    'Verbindung testen'-Knopf getrennt vom eigentlichen Sync."""
    try:
        server = _resolve_server(hub_serial, hub_password)
        return {"ok": True, "server": server}
    except MyenergiError as e:
        return {"ok": False, "error": str(e)}
    except httpx.HTTPError as e:
        return {"ok": False, "error": f"Verbindung fehlgeschlagen: {e}"}


def fetch_daily_charge_kwh(hub_serial: str, hub_password: str, zappi_serial: str,
                            start: date, end: date) -> dict:
    """Liefert {'YYYY-MM-DD': geladene_kWh} für jeden Tag im Bereich [start, end].

    Nutzt den 'cgi-jday-Z<seriennummer>-<datum>'-Endpunkt. Der erste Eintrag
    im 'U<seriennummer>'-Array (der KEIN 'min'-Feld hat) ist laut mehreren
    unabhängig übereinstimmenden Community-Analysen bereits eine fertige
    TAGES-Summe (nicht minutengenau) -- die genutzt wird, statt selbst über
    alle Minuten-Einträge zu aggregieren. Die Felder 'h1d'/'h2d'/'h3d'
    (eins je Phase, bei einer 1-phasigen Installation nur 'h1d') sind laut
    mehreren unabhängigen, an echten Geräten verifizierten Foren-Analysen
    (myenergi.info, github.com/DougieLawson/Zappi_API) die vom Zappi
    GELADENE Energie in WATT-SEKUNDEN (Joule), nicht Wattstunden -- Division
    durch 3.600.000 statt 1000 ergibt kWh. Fehlen alle drei Felder an einem
    Tag komplett, bedeutet das laut denselben Quellen schlicht "an diesem
    Tag nicht geladen" (0 kWh), keinen API-Fehler."""
    server = _resolve_server(hub_serial, hub_password)
    result = {}
    with _client(hub_serial, hub_password, server) as c:
        day = start
        while day <= end:
            date_str = day.strftime("%Y-%m-%d")
            r = c.get(f"/cgi-jday-Z{zappi_serial}-{date_str}")
            if r.status_code == 404:
                day += timedelta(days=1)
                continue  # kein Wagen angeschlossen an dem Tag -> 0, einfach überspringen
            r.raise_for_status()
            payload = r.json()
            entries = payload.get(f"U{zappi_serial}") if isinstance(payload, dict) else None
            if entries is None and isinstance(payload, list):
                entries = payload
            if not entries:
                day += timedelta(days=1)
                continue
            # Die Tages-Summenzeile hat kein 'min'-Feld (Minute des Tages);
            # zur Sicherheit trotzdem robust danach suchen statt blind
            # entries[0] anzunehmen, falls sich die Reihenfolge mal ändert.
            summary = next((e for e in entries if isinstance(e, dict) and "min" not in e), entries[0])
            joules = sum(summary.get(k, 0) for k in ("h1d", "h2d", "h3d"))
            result[date_str] = round(joules / 3_600_000, 3)
            day += timedelta(days=1)
    return result
