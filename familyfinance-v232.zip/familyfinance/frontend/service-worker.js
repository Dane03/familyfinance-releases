const CACHE = "familyfinance-v232";
const ASSETS = ["/", "/index.html", "/style.css", "/auth.js", "/app.js", "/manifest.json", "/icon.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)));
  // Sofort aktivieren, nicht auf das Schließen aller Tabs warten — sonst
  // bekommt man die neue Version oft erst beim übernächsten Start zu sehen.
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      // Alte Caches aus vorherigen Versionen restlos entfernen — sonst
      // sammeln sich mit jedem Update verwaiste Kopien an, die zwar nicht
      // mehr benutzt werden, aber auch nie aufgeräumt wurden.
      const keys = await caches.keys();
      await Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key)));
      // Sofort die Kontrolle über alle offenen Tabs/die PWA übernehmen,
      // ohne dass ein manueller Neustart nötig ist.
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  // API-Aufrufe immer live vom lokalen Server holen, nie cachen.
  if (event.request.url.includes("/api/")) return;

  // Network-First: bei jedem Aufruf zuerst versuchen, die aktuelle Version
  // vom Server zu holen (und den Cache damit zu aktualisieren) — das ist der
  // Grund, warum man beim erneuten Öffnen (Browser oder PWA) automatisch den
  // neuesten Stand sieht, ohne manuell Cache leeren zu müssen. Der Cache
  // dient nur noch als Rückfallebene, falls der Server gerade nicht
  // erreichbar ist (z.B. kurzer Netzwerk-Aussetzer).
  event.respondWith(
    fetch(event.request, { cache: "no-store" })
      .then((response) => {
        const responseClone = response.clone();
        caches.open(CACHE).then((cache) => cache.put(event.request, responseClone));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
