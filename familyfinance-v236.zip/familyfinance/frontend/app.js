const APP_BUILD = "Build 2026-09-04 · v236";

const fmt = (n) => new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(n || 0);
const freqLabel = (f) => (f === "monthly" ? "mtl." : f === "yearly" ? "jährl." : "quart.");
const sourceLabel = (s) => ({ import: "Import", manuell: "manuell geändert", foto: "per Foto aktualisiert", lohnabrechnung: "aus Gehaltsabrechnung" }[s] || s);
const reminderIcon = (t) => (t === "contract_end" ? "📅" : t === "notice_period" ? "🔔" : "⏰");

document.getElementById("build-version").textContent = APP_BUILD;

// ---------- Sidebar-Navigation ----------
const TAB_LOADERS = {
  "tab-vorsorge-dashboard": () => loadVorsorgeDashboard(),
  "tab-vorsorge-aufbau": () => loadAufbauTab(),
  "tab-vorsorge-absicherung": () => loadAbsicherungTab(),
  "tab-vermoegen": () => loadVermoegenOverview(),
  "tab-energy-dashboard": () => loadEnergyOverview(),
  "tab-energy-gas": () => loadMeterPage("gas", "meter-page-gas", "🔥 Gas"),
  "tab-energy-water": () => loadMeterPage("water", "meter-page-water", "💧 Wasser"),
  "tab-energy-strom": () => loadStromSubtab(document.querySelector(".mode-btn[data-strom-subtab].active")?.dataset.stromSubtab || "verbrauch"),
};

function loadStromSubtab(subtab) {
  if (subtab === "verbrauch") {
    loadMeterPage("elec_in", "meter-page-elec_in", "⚡ Strombezug");
  } else {
    loadMeterPage("elec_out", "meter-page-elec_out", "↑ Einspeisung");
    loadPvSystemSpecs();
  }
}

document.querySelectorAll(".mode-btn[data-strom-subtab]").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".mode-btn[data-strom-subtab]").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const subtab = btn.dataset.stromSubtab;
    document.getElementById("strom-subtab-verbrauch").style.display = subtab === "verbrauch" ? "block" : "none";
    document.getElementById("strom-subtab-produktion").style.display = subtab === "produktion" ? "block" : "none";
    loadStromSubtab(subtab);
  });
});

document.querySelectorAll(".sidebar-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".sidebar-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => (p.style.display = "none"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).style.display = "block";
    TAB_LOADERS[btn.dataset.tab]?.();
  });
});

// ---------- Zahlen im deutschen Format robust parsen ----------
// Naives ".replace(',', '.')" scheitert an Tausenderpunkten: "73.412" würde
// als 73.412 (also ~73) statt als 73412 gelesen. Diese Funktion erkennt:
// - Komma + Punkt zusammen -> Punkte sind Tausendertrenner, Komma ist Dezimal
// - nur Komma -> Dezimaltrennzeichen
// - mehrere Punkte -> garantiert Tausendertrenner (Dezimalzahlen haben nie 2 Punkte)
// - genau ein Punkt mit exakt 3 Nachkommastellen -> Tausendertrenner (z.B. "1.200")
// - genau ein Punkt mit 1-2 Nachkommastellen -> Dezimaltrennzeichen (z.B. "3.45")
// Formatiert einen Betrag fürs EDITIERBARE Eingabefeld (kein Währungssymbol,
// aber mit Tausendertrenner) -- ohne das zeigten Inline-Beträge über 999 den
// rohen JS-Zahlwert mit Punkt als Dezimaltrenner (z.B. "205836.02" statt
// "205.836,02"), obwohl der Rest der App durchgängig das deutsche Schema
// nutzt. parseGermanNumber() versteht dieses Format beim Zurückspeichern.
function formatAmountForInput(n) {
  const num = Number(n) || 0;
  return num.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function parseGermanNumber(str) {
  if (str === null || str === undefined) return null;
  str = String(str).trim();
  if (!str) return null;
  const hasComma = str.includes(",");
  const hasDot = str.includes(".");
  if (hasComma && hasDot) {
    str = str.replace(/\./g, "").replace(",", ".");
  } else if (hasComma) {
    str = str.replace(",", ".");
  } else if (hasDot) {
    const dotCount = (str.match(/\./g) || []).length;
    if (dotCount > 1) {
      str = str.replace(/\./g, "");
    } else {
      const afterDot = str.split(".")[1] || "";
      if (afterDot.length === 3) {
        str = str.replace(".", "");
      }
    }
  }
  const n = parseFloat(str);
  return Number.isNaN(n) ? null : n;
}

async function authedFetch(url, options = {}) {
  let res;
  try {
    res = await fetch(url, { ...options, credentials: "same-origin" });
  } catch (networkErr) {
    // Netzwerk weg / Server nicht erreichbar: ohne diese Behandlung würde der
    // Aufrufer an res.json() scheitern und die Oberfläche bliebe stumm bei
    // "Lade …" stehen, ohne dass klar wird, woran es liegt.
    showToast("Keine Verbindung zum Server. Läuft er noch?", true);
    throw networkErr;
  }
  if (res.status === 401) {
    location.reload(); // Session abgelaufen -> zurück zum Login
    throw new Error("Nicht angemeldet");
  }
  if (res.status >= 500) {
    showToast(`Serverfehler (${res.status}) — Details im Server-Log.`, true);
  }
  return res;
}

// ---------- Kurze Einblendung für Fehler/Hinweise ----------
// Bewusst kein alert(): das blockiert die ganze Oberfläche und muss
// weggeklickt werden, was bei Hintergrund-Ladefehlern nur nervt.
let toastTimer = null;
function showToast(message, isError = false) {
  let el = document.getElementById("app-toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "app-toast";
    el.className = "app-toast";
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.toggle("app-toast-error", isError);
  el.classList.add("app-toast-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("app-toast-visible"), 5000);
}

async function patchJSON(url, body) {
  return authedFetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

// ---------- Generisches Drag & Drop für Listen/Blöcke ----------
function enableDragReorder(container, itemSelector, onReorder) {
  let dragEl = null;
  container.querySelectorAll(itemSelector).forEach((item) => {
    item.setAttribute("draggable", "true");
    item.addEventListener("dragstart", () => {
      dragEl = item;
      item.classList.add("dragging");
    });
    item.addEventListener("dragend", () => {
      item.classList.remove("dragging");
      dragEl = null;
    });
    item.addEventListener("dragover", (e) => {
      e.preventDefault();
      if (!dragEl || item === dragEl) return;
      const rect = item.getBoundingClientRect();
      const putAfter = (e.clientY - rect.top) / rect.height > 0.5;
      item.parentNode.insertBefore(dragEl, putAfter ? item.nextSibling : item);
    });
    item.addEventListener("drop", (e) => {
      e.preventDefault();
      const ids = Array.from(container.querySelectorAll(itemSelector)).map((el) => el.dataset.dragId);
      onReorder(ids);
    });
  });
}

// ---------- Block-Reihenfolge per Drag & Drop, serverseitig gespeichert --
// Generalisiert aus der ursprünglich Dashboard-spezifischen Lösung, damit
// jeder Tab-Bereich (nicht nur das Dashboard) seine Kacheln in eigener
// Reihenfolge merken kann -- ein eigener settingsKey pro Bereich, damit
// sich die Sortierungen nicht gegenseitig überschreiben.
async function applyBlockOrder(tabId, settingsKey) {
  const res = await authedFetch(`/api/settings/${settingsKey}`);
  const { value } = await res.json();
  if (!value) return;
  const tab = document.getElementById(tabId);
  if (!tab) return;
  value.forEach((blockId) => {
    const el = tab.querySelector(`#block-${blockId}, [data-block-id="${blockId}"]`);
    if (el) tab.appendChild(el);
  });
}

function setupBlockDragReorder(tabId, settingsKey) {
  const tab = document.getElementById(tabId);
  if (!tab) return;
  tab.querySelectorAll(".draggable-block").forEach((el) => {
    el.dataset.dragId = el.dataset.blockId;
  });
  enableDragReorder(tab, ".draggable-block", async (ids) => {
    await authedFetch(`/api/settings/${settingsKey}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: ids }),
    });
  });
}

async function applyDashboardOrder() {
  await applyBlockOrder("tab-dashboard", "dashboard_order");
}

function setupDashboardDragReorder() {
  setupBlockDragReorder("tab-dashboard", "dashboard_order");
}

// ---------- Theme-bewusste Chart-Farben ----------
// Jedes Theme bekommt dieselben benannten Rollen (primary/accent/warn/...),
// damit alle Charts der App automatisch zum gewählten Design passen, ohne
// dass jede einzelne Chart-Funktion das Theme selbst kennen müsste.
function chartPalette() {
  const theme = document.documentElement.getAttribute("data-theme") || "dark";
  const palettes = {
    // Jede Rolle bewusst auf einen eigenen Farbton geprüft -- vorher gab es
    // in mehreren Themes exakte oder fast-identische Duplikate (z.B. warn ===
    // orange), wodurch benachbarte Chart-Serien/Kreissegmente kaum zu
    // unterscheiden waren.
    dark: { primary: "#4ade80", accent: "#22d3ee", warn: "#fbbf24", purple: "#a855f7", orange: "#fb923c", bad: "#f87171", neutral: "#94a3b8", teal: "#2dd4bf", info: "#60a5fa", onColor: "#1a1a2e" },
    light: { primary: "#34c759", accent: "#007aff", warn: "#ffcc00", purple: "#af52de", orange: "#ff9500", bad: "#ff3b30", neutral: "#8e8e93", teal: "#30b0c7", info: "#5ac8fa", onColor: "#1c1c1e" },
    apple: { primary: "#30d158", accent: "#0a84ff", warn: "#ffd60a", purple: "#bf5af2", orange: "#ff9f0a", bad: "#ff453a", neutral: "#98989f", teal: "#64d2ff", info: "#5ac8fa", onColor: "#1c1c1e" },
    // Nothing bleibt bewusst nahezu monochrom -- aber jetzt mit einer
    // echten Graustufen-Rampe statt versehentlich mehrfach demselben Grau/
    // Rot, damit z.B. eine Ausgaben-Kreisgrafik mit vielen Kategorien nicht
    // mehrere kaum unterscheidbare Rottöne nebeneinander zeigt.
    nothing: { primary: "#ffffff", accent: "#ff0000", warn: "#8a8a8a", purple: "#b8b8b8", orange: "#5c5c5c", bad: "#8b1a1a", teal: "#3d3d3d", neutral: "#707070", info: "#a0a0a0", onColor: "#000000" },
    retro80s: { primary: "#00f0ff", accent: "#ff2e97", warn: "#ffe83d", purple: "#c77dff", orange: "#ffb020", bad: "#ff5555", neutral: "#c9a8e0", teal: "#00b8d4", info: "#7dd3fc", onColor: "#170821" },
  };
  return palettes[theme] || palettes.dark;
}

function hexToRgba(hex, alpha) {
  const h = hex.replace("#", "");
  const r = parseInt(h.substring(0, 2), 16), g = parseInt(h.substring(2, 4), 16), b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// Zeitraum-Optionen — EINMAL zentral definiert, damit alle Chart-Selektoren
// garantiert dieselben Optionen anbieten. Die zugehörige Auflösung (Tage /
// Wochen / Monate) steuert resolutionForRange() weiter unten.
const CHART_RANGES = [
  { id: "1m", label: "1 Mo" },
  { id: "3m", label: "3 Mo" },
  { id: "12m", label: "12 Mo" },
  { id: "ytd", label: "YTD" },
  { id: "all", label: "Gesamt" },
];

// Kurze Zeiträume feiner auflösen — sonst zeigt "1 Monat" nur einen
// einzigen Balken und lässt keinerlei Verlauf erkennen. Spiegelt exakt
// resolution_for_range() im Backend (meters.py).
// Alle Charts arbeiten auf MONATSbasis. Feinere Auflösungen (Tage/Wochen)
// wurden bewusst wieder entfernt: Ohne engmaschige Ablesungen entstehen dabei
// nur interpolierte Werte, die mehr Genauigkeit vortäuschen als vorhanden ist.
// Die Zeitraum-Auswahl steuert weiterhin, WIE VIELE Monate gezeigt werden.
function resolutionForRange(rangeId) {
  return "month";
}

// Einheitliche Chart-Überschrift: benennt die TATSÄCHLICH gezeigte Auflösung.
// "effective" kann von der angefragten abweichen, wenn für den Zeitraum keine
// feineren Daten vorliegen (z.B. nur monatlicher PV-Import) — dann steht das
// auch so in der Überschrift, statt eine Genauigkeit vorzutäuschen.
function chartTitleWithResolution(baseTitle) {
  return `${baseTitle} je Monat`;
}

function chartColorsList() {
  const p = chartPalette();
  return [p.accent, p.warn, p.primary, p.purple, p.bad, p.teal, p.orange, p.neutral];
}

// ---------- Diagramme (reines SVG, keine externe Bibliothek nötig) ----------

function renderBarChart(income, fixed, savings) {
  const expensesTotal = fixed + savings;
  const max = Math.max(income, expensesTotal, 1);
  const W = 220, H = 170, padBottom = 34, padTop = 24, barW = 64, gap = 40;
  const chartH = H - padBottom - padTop;

  const incomeH = Math.max((income / max) * chartH, income > 0 ? 2 : 0);
  const incomeX = 16;
  const incomeY = H - padBottom - incomeH;

  // Ausgaben-Balken: Fixkosten + Sparen gestapelt, auf derselben Skala wie
  // Einnahmen — so ist auf einen Blick vergleichbar, wie die Ausgaben
  // (zusammen) im Verhältnis zu den Einnahmen stehen, und wie sie sich
  // intern aufteilen.
  const expensesH = Math.max((expensesTotal / max) * chartH, expensesTotal > 0 ? 2 : 0);
  const expensesX = incomeX + barW + gap;
  const expensesY = H - padBottom - expensesH;
  const fixedShare = expensesTotal > 0 ? fixed / expensesTotal : 0;
  const savingsShare = expensesTotal > 0 ? savings / expensesTotal : 0;
  const fixedH = expensesH * fixedShare;
  const savingsH = expensesH * savingsShare;
  const fixedPct = Math.round(fixedShare * 100);
  const savingsPct = Math.round(savingsShare * 100);

  const cpBars = chartPalette();
  const segmentLabel = (h, y, pct, text) =>
    h >= 18 ? `<text x="${expensesX + barW / 2}" y="${y + h / 2 + 4}" text-anchor="middle" font-size="10" font-weight="700" fill="${cpBars.onColor}">${pct}%</text>` : "";

  document.getElementById("chart-bars").innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block" role="img" aria-label="Einnahmen im Vergleich zu Ausgaben, Ausgaben aufgeteilt in Fixkosten und Sparen" style="overflow:visible">
      <defs>
        <linearGradient id="grad-income" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${cpBars.primary}" />
          <stop offset="100%" stop-color="${hexToRgba(cpBars.primary, 0.75)}" />
        </linearGradient>
        <linearGradient id="grad-fixed" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${cpBars.bad}" />
          <stop offset="100%" stop-color="${hexToRgba(cpBars.bad, 0.75)}" />
        </linearGradient>
        <linearGradient id="grad-savings" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${cpBars.primary}" />
          <stop offset="100%" stop-color="${hexToRgba(cpBars.primary, 0.75)}" />
        </linearGradient>
        <filter id="bar-shadow" x="-40%" y="-40%" width="180%" height="180%">
          <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.2" />
        </filter>
      </defs>
      <line x1="10" y1="${H - padBottom}" x2="${W - 10}" y2="${H - padBottom}" stroke="rgba(255,255,255,0.12)" />

      <rect x="${incomeX}" y="${incomeY}" width="${barW}" height="${incomeH}" rx="6" fill="url(#grad-income)" filter="url(#bar-shadow)" />
      <text x="${incomeX + barW / 2}" y="${incomeY - 6}" text-anchor="middle" font-size="10" fill="var(--text)">${fmt(income)}</text>
      <text x="${incomeX + barW / 2}" y="${H - padBottom + 15}" text-anchor="middle" font-size="11" fill="var(--muted)">Einnahmen</text>

      <clipPath id="clip-expenses-bar"><rect x="${expensesX}" y="${expensesY}" width="${barW}" height="${expensesH}" rx="6" /></clipPath>
      <g clip-path="url(#clip-expenses-bar)" filter="url(#bar-shadow)">
        <rect x="${expensesX}" y="${expensesY}" width="${barW}" height="${fixedH}" fill="url(#grad-fixed)">
          <title>Fixkosten: ${fmt(fixed)} (${fixedPct}%)</title>
        </rect>
        <rect x="${expensesX}" y="${expensesY + fixedH}" width="${barW}" height="${savingsH}" fill="url(#grad-savings)">
          <title>Sparen: ${fmt(savings)} (${savingsPct}%)</title>
        </rect>
      </g>
      ${segmentLabel(fixedH, expensesY, fixedPct, "Fixkosten")}
      ${segmentLabel(savingsH, expensesY + fixedH, savingsPct, "Sparen")}
      <text x="${expensesX + barW / 2}" y="${expensesY - 6}" text-anchor="middle" font-size="10" fill="var(--text)">${fmt(expensesTotal)}</text>
      <text x="${expensesX + barW / 2}" y="${H - padBottom + 15}" text-anchor="middle" font-size="11" fill="var(--muted)">Ausgaben</text>
    </svg>
    <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:0.75rem;color:var(--muted);margin-top:4px;justify-content:center">
      <span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpBars.bad};border-radius:2px;display:inline-block"></span>Fixkosten ${fmt(fixed)}</span>
      <span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpBars.primary};border-radius:2px;display:inline-block"></span>Sparen ${fmt(savings)}</span>
    </div>`;
}

function renderPieChart(categories, containerId = "chart-pie") {
  const data = categories
    .filter((c) => c.monthly_amount > 0)
    .sort((a, b) => b.monthly_amount - a.monthly_amount);

  if (data.length === 0) {
    document.getElementById(containerId).innerHTML =
      '<p class="muted">Noch keine Ausgaben erfasst</p>';
    return;
  }

  // Sehr kleine Kategorien zusammenfassen, sonst wird der Kuchen unleserlich
  const MAX = 8;
  let slices = data.slice(0, MAX).map((c) => ({
    label: c.subcategory ? `${c.category} · ${c.subcategory}` : (c.category || "Ohne Kategorie"),
    value: c.monthly_amount,
  }));
  if (data.length > MAX) {
    slices.push({
      label: "Weitere",
      value: data.slice(MAX).reduce((s, c) => s + c.monthly_amount, 0),
    });
  }

  const total = slices.reduce((s, c) => s + c.value, 0) || 1;
  const cx = 95, cy = 95, r = 82;
  let angle = -Math.PI / 2; // oben starten
  const colors = chartColorsList();

  const paths = slices.map((s, i) => {
    const slice = (s.value / total) * Math.PI * 2;
    const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
    angle += slice;
    const x2 = cx + r * Math.cos(angle), y2 = cy + r * Math.sin(angle);
    const largeArc = slice > Math.PI ? 1 : 0;
    // Vollkreis-Sonderfall: ein einzelner Wert würde sonst als leerer Pfad enden
    const d = slices.length === 1
      ? `M ${cx} ${cy - r} A ${r} ${r} 0 1 1 ${cx - 0.01} ${cy - r} Z`
      : `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;
    return `<path class="pie-slice" d="${d}" fill="${colors[i % colors.length]}"
                  stroke="var(--card)" stroke-width="2.5" style="transform-origin:${cx}px ${cy}px;transition:transform 0.15s ease" />`;
  }).join("");

  const legend = slices.map((s, i) => `
    <li class="legend-item">
      <span class="legend-dot" style="background:${colors[i % colors.length]}"></span>
      <span class="legend-label">${s.label}</span>
      <span class="legend-value">${fmt(s.value)} · ${Math.round((s.value / total) * 100)} %</span>
    </li>`).join("");

  document.getElementById(containerId).innerHTML = `
    <div class="pie-wrap">
      <svg viewBox="0 0 190 190" width="180" height="180" role="img" style="overflow:visible"
           aria-label="Verteilung der Ausgaben nach Kategorie">
        <defs>
          <filter id="pie-shadow-${containerId}" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.22" />
          </filter>
        </defs>
        <g filter="url(#pie-shadow-${containerId})">${paths}</g>
      </svg>
      <ul class="legend">${legend}</ul>
    </div>`;

  document.getElementById(containerId).querySelectorAll(".pie-slice").forEach((slice) => {
    slice.addEventListener("mouseenter", () => { slice.style.transform = "scale(1.035)"; });
    slice.addEventListener("mouseleave", () => { slice.style.transform = "scale(1)"; });
  });
}

// ---------- Finanz-Check (Health Check) ----------
const HEALTHCHECK_ICON = { green: "✅", yellow: "⚠️", red: "🔴", info: "ℹ️" };

function renderHealthCheck(checks) {
  const container = document.getElementById("healthcheck-list");
  if (!container) return;
  if (checks.length === 0) {
    container.innerHTML = '<p class="muted">Noch keine Einnahmen erfasst — Finanz-Check startet, sobald Zahlen da sind.</p>';
    return;
  }
  container.innerHTML = checks.map((c) => `
    <div class="healthcheck-item healthcheck-${c.status}">
      <div class="healthcheck-row">
        <span class="healthcheck-icon">${HEALTHCHECK_ICON[c.status] || ""}</span>
        <span class="healthcheck-title">${c.title}</span>
        <span class="healthcheck-value">${c.value_label}</span>
      </div>
      <p class="healthcheck-message">${c.message}</p>
      <p class="healthcheck-target">${c.target_label}</p>
    </div>
  `).join("");
}

// ---------- Dashboard: Überblick + Kategorien + Fälligkeiten ----------
async function loadDashboard() {
  const res = await authedFetch("/api/dashboard");
  const data = await res.json();

  document.getElementById("stat-income").textContent = fmt(data.monthly_income);
  document.getElementById("stat-fixed").textContent = fmt(data.monthly_fixed_expenses);
  document.getElementById("stat-savings").textContent = fmt(data.monthly_savings);

  const s1 = document.getElementById("stat-surplus-fixed");
  s1.textContent = fmt(data.surplus_after_fixed_costs);
  s1.style.color = data.surplus_after_fixed_costs >= 0 ? "var(--good)" : "var(--bad)";

  const s2 = document.getElementById("stat-surplus-savings");
  s2.textContent = fmt(data.surplus_after_savings);
  s2.style.color = data.surplus_after_savings >= 0 ? "var(--good)" : "var(--bad)";

  const reminderList = document.getElementById("duedates-list");
  if (data.upcoming_reminders.length === 0) {
    reminderList.innerHTML = '<li class="muted">Keine anstehenden Fälligkeiten in den nächsten 4 Wochen 🎉</li>';
  } else {
    reminderList.innerHTML = data.upcoming_reminders.map(
      (r) => `<li><span>${reminderIcon(r.reminder_type)} ${r.message}</span><span class="tag">${r.trigger_date}</span></li>`
    ).join("");
  }

  renderBarChart(data.monthly_income, data.monthly_fixed_expenses, data.monthly_savings);
  renderPieChart(data.by_category || []);
  renderHealthCheck(data.health_check || []);
}

// ---------- PDF-Export ----------
document.getElementById("export-pdf-btn").addEventListener("click", async (e) => {
  const btn = e.target;
  const originalText = btn.textContent;
  btn.textContent = "Wird erstellt …";
  btn.disabled = true;
  try {
    const res = await authedFetch("/api/report/pdf");
    if (!res.ok) throw new Error("Export fehlgeschlagen");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Finanzreport_${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (err) {
    alert("PDF-Export fehlgeschlagen: " + err.message);
  } finally {
    btn.textContent = originalText;
    btn.disabled = false;
  }
});

document.getElementById("export-energy-pdf-btn").addEventListener("click", async (e) => {
  const btn = e.target;
  const originalText = btn.textContent;
  btn.textContent = "Wird erstellt …";
  btn.disabled = true;
  try {
    const res = await authedFetch("/api/report/energy-pdf");
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || "Export fehlgeschlagen");
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Energy-Monitor-Report_${new Date().toISOString().slice(0, 10)}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (err) {
    alert("PDF-Export fehlgeschlagen: " + err.message);
  } finally {
    btn.textContent = originalText;
    btn.disabled = false;
  }
});

// ---------- Einnahmen ----------
async function loadIncome() {
  const res = await authedFetch("/api/income");
  const rows = await res.json();
  allIncome = rows;
  const container = document.getElementById("income-groups");
  if (rows.length === 0) {
    container.innerHTML = '<p class="muted">Noch keine Einnahmen erfasst</p>';
    return;
  }

  // Aufgeklappte Gruppen merken, damit eine Aktualisierung (z.B. Betrag
  // bearbeiten) nicht alle Gruppen wieder einklappt — gleiches Muster wie
  // bei den Ausgaben.
  const expandedGroups = new Set(
    Array.from(container.querySelectorAll(".contract-list:not(.collapsed)"))
      .map((ul) => ul.dataset.group)
  );

  const groups = {};
  for (const r of rows) {
    const key = r.category || "Sonstiges";
    (groups[key] = groups[key] || []).push(r);
  }
  // Immer wertbasiert sortiert -- höchster Betrag zuerst, sowohl je Gruppe
  // als auch innerhalb einer Gruppe. Keine manuelle Sortierung mehr.
  Object.values(groups).forEach((items) => items.sort((a, b) => b.monthly_amount - a.monthly_amount));

  const sortedGroups = Object.entries(groups)
    .map(([groupName, items]) => [groupName, items, items.reduce((sum, r) => sum + (r.active ? r.monthly_amount : 0), 0)])
    .sort((a, b) => b[2] - a[2]);

  const total = rows.filter((r) => r.active).reduce((sum, r) => sum + r.monthly_amount, 0);

  container.innerHTML = sortedGroups.map(([groupName, items, groupSum]) => {
    const isExpanded = expandedGroups.has(groupName);
    return `
    <div class="contract-group">
      <h3 class="group-toggle">
        <span class="chevron">${isExpanded ? "▾" : "▸"}</span> ${groupName}
        <span class="group-sum">${fmt(groupSum)}/Mon.</span>
      </h3>
      <ul class="contract-list${isExpanded ? "" : " collapsed"}" data-group="${groupName}">
        ${items.map((r) => `
          <li class="contract-row income-item" data-income-row="${r.id}" data-drag-id="${r.id}" style="${r.active ? "" : "opacity:0.5"}">
            <div class="contract-main">
              ${rowMenuButtonHTML("income", r.id)}
              <span class="contract-label">${r.label}</span>
              <span class="tag">${sourceLabel(r.source)}</span>
              ${!r.active ? '<span class="tag">inaktiv</span>' : ""}
            </div>
            <div class="contract-amount row-actions">
              <input type="text" class="inline-amount" data-income-id="${r.id}" value="${formatAmountForInput(r.amount)}" inputmode="decimal" />
              <span class="muted" style="font-size:0.75rem">€/${freqLabel(r.frequency)} · ${fmt(r.monthly_amount)}/Mon.</span>
            </div>
          </li>`).join("")}
      </ul>
    </div>`;
  }).join("") + `
    <ul><li class="total-row"><span>Summe / Monat</span><span>${fmt(total)}</span></li></ul>`;

  container.querySelectorAll(".group-toggle").forEach((h3) => {
    h3.addEventListener("click", () => {
      const ul = h3.nextElementSibling;
      ul.classList.toggle("collapsed");
      h3.querySelector(".chevron").textContent = ul.classList.contains("collapsed") ? "▸" : "▾";
    });
  });

  container.querySelectorAll("[data-income-id]").forEach((input) => {
    input.addEventListener("change", async () => {
      const amount = parseGermanNumber(input.value);
      if (Number.isNaN(amount)) return alert("Ungültiger Betrag");
      await patchJSON(`/api/income/${input.dataset.incomeId}`, { amount });
      loadIncome();
      loadDashboard();
      // Die Versorgungslücken-Berechnung in Vorsorge hängt direkt am
      // Nettoeinkommen -- ohne dies zu invalidieren, zeigte Vorsorge bis zum
      // nächsten Neuladen weiterhin die Zahlen mit dem alten Einkommen.
      vorsorgeLastRenteData = null;
      vorsorgeLastRisikoData = null;
    });
  });

  container.querySelectorAll("[data-income-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuIncomeId = row.dataset.incomeRow;
      showIncomeContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(container, "income", (id, x, y) => {
    contextMenuIncomeId = id;
    showIncomeContextMenu(x, y);
  });

  const bulkSelect = document.getElementById("payslip-bulk-income");
  if (bulkSelect) {
    const previousValue = bulkSelect.value;
    bulkSelect.innerHTML = rows.map((r) => `<option value="${r.id}">${r.label}${r.category ? ` (${r.category})` : ""}</option>`).join("");
    if (previousValue) bulkSelect.value = previousValue;
  }
}

let allIncome = [];
let contextMenuIncomeId = null;
const incomeContextMenu = document.getElementById("income-context-menu");
const incomeFormOverlay = document.getElementById("income-form-overlay");

function showIncomeContextMenu(x, y) {
  incomeContextMenu.style.left = `${x}px`;
  incomeContextMenu.style.top = `${y}px`;
  incomeContextMenu.style.display = "block";
}

function hideIncomeContextMenu() {
  incomeContextMenu.style.display = "none";
  contextMenuIncomeId = null;
}

document.addEventListener("click", (e) => {
  if (!incomeContextMenu.contains(e.target)) hideIncomeContextMenu();
});

incomeContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuIncomeId;
  hideIncomeContextMenu();
  if (id) openIncomeForm(id);
});

incomeContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuIncomeId;
  hideIncomeContextMenu();
  if (!id || !confirm("Diese Einnahme wirklich löschen?")) return;
  await authedFetch(`/api/income/${id}`, { method: "DELETE" });
  loadIncome();
  loadDashboard();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
});

async function openIncomeForm(incomeId) {
  const form = document.getElementById("income-form");
  form.reset();
  form.dataset.incomeId = incomeId || "";
  document.getElementById("income-form-title").textContent = incomeId ? "✏️ Einnahme bearbeiten" : "➕ Neue Einnahme";

  const personSelect = document.getElementById("income-person");
  if (personSelect.options.length <= 1) {
    const members = await (await authedFetch("/api/family-members")).json();
    members.forEach((m) => {
      const opt = document.createElement("option");
      opt.value = m.id; opt.textContent = m.name;
      personSelect.appendChild(opt);
    });
  }

  if (incomeId) {
    const row = allIncome.find((r) => String(r.id) === String(incomeId));
    if (row) {
      document.getElementById("income-label").value = row.label;
      document.getElementById("income-category").value = row.category || "";
      document.getElementById("income-amount").value = row.amount;
      document.getElementById("income-frequency").value = row.frequency;
      personSelect.value = row.person_id || "";
    }
  }

  const payslipsSection = document.getElementById("income-payslips-section");
  const showPayslipsBtn = document.getElementById("income-show-payslips-btn");
  payslipsSection.style.display = "none";
  payslipsSection.innerHTML = "";
  incomeFormPayslipsCache = null;

  if (incomeId) {
    showPayslipsBtn.style.display = "block";
    incomeFormPayslipsCache = await (await authedFetch(`/api/income/${incomeId}/payslips`)).json();
  } else {
    // Eine noch nicht gespeicherte, neue Einnahme hat zwangsläufig keine
    // Gehaltsabrechnungs-Historie — der Button wäre hier nur eine leere Sackgasse.
    showPayslipsBtn.style.display = "none";
  }

  incomeFormOverlay.style.display = "flex";
}

let incomeFormPayslipsCache = null;

document.getElementById("income-show-payslips-btn").addEventListener("click", () => {
  const section = document.getElementById("income-payslips-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) {
    section.style.display = "none";
    return;
  }
  const incomeId = document.getElementById("income-form").dataset.incomeId;
  section.style.display = "block";
  const slips = incomeFormPayslipsCache || [];
  if (slips.length === 0) {
    section.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Gehaltsabrechnungen hinterlegt.</p>';
    return;
  }
  section.innerHTML = '<div id="income-payslips-list"></div>';
  setupScrollableDocList("income-payslips-list", slips, (s) => s.detected_month || s.uploaded_at, (filtered, ul) => {
    // Wie oft kommt derselbe Monat in der aktuell angezeigten (ggf.
    // jahresgefilterten) Liste vor? Nur dann lohnt sich eine
    // Unterscheidungshilfe — im Normalfall (1 Beleg/Monat) reicht "Jul 2026".
    const monthCounts = {};
    filtered.forEach((s) => {
      const key = s.detected_month || s.uploaded_at || "?";
      monthCounts[key] = (monthCounts[key] || 0) + 1;
    });
    ul.innerHTML = filtered.map((s) => {
      const monthKey = s.detected_month || s.uploaded_at || "?";
      const monthLabel = s.detected_month ? formatPayslipMonth(s.detected_month) : (s.uploaded_at ? `hochgeladen ${s.uploaded_at.slice(0, 10)}` : "Datum unbekannt");
      const needsDisambiguation = monthCounts[monthKey] > 1;
      return `
      <li data-payslip-row="${s.id}">
        <a href="/api/payslips/${s.id}/file" rel="noopener" data-view-doc-url="/api/payslips/${s.id}/file" data-view-doc-title="${monthLabel}">
          📄 ${monthLabel}${needsDisambiguation ? ` — ${s.original_filename || "Beleg " + s.id}` : ""}
        </a>
        <span class="row-actions">
          ${s.detected_net_amount ? `<span class="muted" style="font-size:0.72rem">${fmt(s.detected_net_amount)}</span>` : ""}
          <a href="/api/payslips/${s.id}/file?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
          <button type="button" class="del-btn" data-delete-payslip="${s.id}" title="Löschen">🗑</button>
        </span>
      </li>`;
    }).join("");
    wireDocumentViewerLinks(ul);
    ul.querySelectorAll("[data-delete-payslip]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        if (!confirm("Diese Gehaltsabrechnung wirklich löschen?")) return;
        await authedFetch(`/api/payslips/${btn.dataset.deletePayslip}`, { method: "DELETE" });
        await openIncomeForm(incomeId);
        document.getElementById("income-show-payslips-btn").click();
      });
    });
  });
});

document.getElementById("add-income-btn").addEventListener("click", () => openIncomeForm(null));
document.getElementById("income-form-cancel-btn").addEventListener("click", () => {
  incomeFormOverlay.style.display = "none";
});

document.getElementById("income-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const incomeId = e.target.dataset.incomeId;
  const label = document.getElementById("income-label").value.trim();
  if (!label) return alert("Bitte eine Bezeichnung angeben.");
  const amount = parseGermanNumber(document.getElementById("income-amount").value);
  if (amount === null || Number.isNaN(amount)) return alert("Ungültiger Betrag.");
  const personVal = document.getElementById("income-person").value;

  const payload = {
    label,
    category: document.getElementById("income-category").value.trim() || "Sonstiges",
    amount,
    frequency: document.getElementById("income-frequency").value,
    person_id: personVal ? parseInt(personVal, 10) : null,
  };

  const res = incomeId
    ? await authedFetch(`/api/income/${incomeId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      })
    : await authedFetch("/api/income", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Speichern.");
  }
  incomeFormOverlay.style.display = "none";
  loadIncome();
  loadDashboard();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
});

document.getElementById("payslip-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("payslip-input");
  const password = document.getElementById("payslip-password").value;
  const resultDiv = document.getElementById("payslip-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst eine PDF auswählen.";
    return;
  }
  resultDiv.textContent = "Wird gelesen …";
  const formData = new FormData();
  formData.append("file", input.files[0]);
  if (password) formData.append("password", password);

  const res = await authedFetch("/api/payslips/upload", { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) {
    resultDiv.textContent = data.detail || "Fehler beim Lesen der PDF.";
    return;
  }
  const d = data.detected;
  const incomeRows = await (await authedFetch("/api/income")).json();
  const incomeOptions = incomeRows.map((r) => `<option value="${r.id}">${r.label}</option>`).join("");

  resultDiv.innerHTML = `
    <p style="margin:0 0 8px">Erkannt: <b>${fmt(d.net_amount)}</b> · ${d.month || "Monat unbekannt"} · ${d.employer || "?"}</p>
    <label class="muted" style="font-size:0.8rem">Wem gehört diese Abrechnung?</label>
    <select id="payslip-income-select"${data.matched_income ? "" : ' class="needs-attention"'}>
      <option value="">– neue Einnahme anlegen –</option>
      ${incomeOptions}
    </select>
    ${data.matched_income ? `<p class="muted" style="margin:4px 0 0;font-size:0.75rem">✅ automatisch zugeordnet (Name erkannt)</p>` : ""}
    <label class="checkbox-label">
      <input type="checkbox" id="payslip-update-income" checked />
      <span>Einkommen aktualisieren (bei reinen Mitteilungen ohne Gehaltszahlung abwählen)</span>
    </label>
    <button id="payslip-confirm-btn" style="margin-top:10px">Übernehmen</button>
  `;

  if (data.matched_income) {
    document.getElementById("payslip-income-select").value = String(data.matched_income.id);
  }

  document.getElementById("payslip-confirm-btn").addEventListener("click", async () => {
    const update_income = document.getElementById("payslip-update-income").checked;
    const selected = document.getElementById("payslip-income-select").value;
    let income_id = selected ? parseInt(selected, 10) : null;
    let new_income_label = null;
    if (update_income && !income_id) {
      new_income_label = prompt("Bezeichnung für diese neue Einnahme:", d.employer || "Gehalt");
      if (!new_income_label) return;
    }
    await authedFetch(`/api/payslips/${data.payslip_id}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ income_id, new_income_label, update_income }),
    });
    resultDiv.innerHTML += "<br>Übernommen ✅";
    loadIncome();
    loadDashboard();
  });
});

document.getElementById("payslip-bulk-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("payslip-bulk-input");
  const incomeSelect = document.getElementById("payslip-bulk-income");
  const password = document.getElementById("payslip-bulk-password").value;
  const resultDiv = document.getElementById("payslip-bulk-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst eine oder mehrere PDFs auswählen.";
    return;
  }
  if (!incomeSelect.value) {
    resultDiv.textContent = "Bitte zuerst eine Einnahme anlegen, der die Abrechnungen zugeordnet werden.";
    return;
  }
  resultDiv.textContent = `Importiere ${input.files.length} Dateien …`;
  const formData = new FormData();
  formData.append("income_id", incomeSelect.value);
  for (const file of input.files) formData.append("files", file);
  if (password) formData.append("password", password);

  const res = await authedFetch("/api/payslips/bulk-upload", { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) {
    resultDiv.textContent = data.detail || "Fehler beim Import.";
    return;
  }
  const failed = data.results.filter((r) => r.error);
  resultDiv.innerHTML = `
    <p style="margin:4px 0 0">✅ ${data.count} Datei${data.count === 1 ? "" : "en"} importiert${failed.length ? `, davon ${failed.length} ohne erkannte Werte (trotzdem archiviert)` : ""}.</p>
    <p class="muted" style="font-size:0.75rem;margin:2px 0 0">Der aktuelle Betrag der Einnahme wurde dabei bewusst nicht verändert.</p>`;
  input.value = "";
});

document.getElementById("bulk-receipt-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("bulk-receipt-input");
  const contractSelect = document.getElementById("bulk-receipt-contract");
  const resultDiv = document.getElementById("bulk-receipt-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst eine oder mehrere Dateien auswählen.";
    return;
  }
  if (!contractSelect.value) {
    resultDiv.textContent = "Bitte zuerst einen Vertrag anlegen, dem die Belege zugeordnet werden.";
    return;
  }
  resultDiv.textContent = `Importiere ${input.files.length} Dateien …`;
  const formData = new FormData();
  for (const file of input.files) formData.append("files", file);

  const res = await authedFetch(`/api/contracts/${contractSelect.value}/bulk-upload-receipts`, {
    method: "POST", body: formData,
  });
  const data = await res.json();
  if (!res.ok) {
    resultDiv.textContent = data.detail || "Fehler beim Import.";
    return;
  }
  const skipped = data.results.filter((r) => r.skipped);
  resultDiv.innerHTML = `
    <p style="margin:4px 0 0">✅ ${data.count} Datei${data.count === 1 ? "" : "en"} verarbeitet${skipped.length ? `, davon ${skipped.length} bereits vorhanden (übersprungen)` : ""}.</p>
    <p class="muted" style="font-size:0.75rem;margin:2px 0 0">Der aktuelle Vertragsbetrag wurde dabei bewusst nicht verändert.</p>`;
  input.value = "";
});

// ---------- Kategorie-Dropdown-Helfer: "Haus" nur mit Unterkategorie wählbar ----------
function categoryOptionsHTML() {
  const entries = allCategories.flatMap((cat) => {
    if (cat === "Haus") {
      return [
        { value: "Haus::Finanzierung", label: "Haus · Finanzierung" },
        { value: "Haus::Nebenkosten", label: "Haus · Nebenkosten" },
      ];
    }
    return [{ value: cat, label: cat }];
  });
  entries.sort((a, b) => a.label.localeCompare(b.label, "de"));
  return entries.map((e) => `<option value="${e.value}">${e.label}</option>`).join("");
}

function categoryValueFor(categoryName, subcategory) {
  return categoryName === "Haus" ? `Haus::${subcategory || "Nebenkosten"}` : (categoryName || "Sonstiges");
}

function parseCategoryValue(value) {
  if (value.includes("::")) {
    const [category, subcategory] = value.split("::");
    return { category, subcategory };
  }
  return { category: value, subcategory: null };
}

// ---------- Admin-Ebene: Kategorien verwalten ----------
const manageCategoriesOverlay = document.getElementById("manage-categories-overlay");
const categoriesOverlay = document.getElementById("categories-overlay");

async function loadManageCategoriesList() {
  allCategories = await (await authedFetch("/api/categories")).json();
  const list = document.getElementById("manage-categories-list");
  list.innerHTML = allCategories.map((cat) => `<li><span>${cat}</span></li>`).join("");
}

document.getElementById("manage-categories-btn").addEventListener("click", async () => {
  const toggleRes = await authedFetch("/api/settings/energy_monitor_enabled");
  const { value } = await toggleRes.json();
  document.getElementById("toggle-energy-monitor").checked = !!value;
  const vorsorgeToggleRes = await authedFetch("/api/settings/vorsorge_enabled");
  const { value: vorsorgeValue } = await vorsorgeToggleRes.json();
  document.getElementById("toggle-vorsorge").checked = !!vorsorgeValue;
  manageCategoriesOverlay.style.display = "flex";
  loadBackupStatus();
  loadSecurityStatus();
  const versionMatch = APP_BUILD.match(/·\s*(v\d+)/);
  document.getElementById("app-version-current").textContent = versionMatch ? versionMatch[1] : "–";
});

async function loadSecurityStatus() {
  const statusEl = document.getElementById("security-2fa-status");
  const setupBtn = document.getElementById("security-setup-totp-btn");
  const disableBtn = document.getElementById("security-disable-totp-btn");
  const status = await (await authedFetch("/api/auth/status")).json();
  const parts = [];
  if (status.passkey_registered) parts.push("Passkey aktiv");
  if (status.totp_registered) parts.push("Authenticator-App (TOTP) aktiv");
  statusEl.textContent = parts.length ? `Zweiter Faktor: ${parts.join(" · ")}.` : "Kein zweiter Faktor aktiv.";
  setupBtn.style.display = status.totp_registered ? "none" : "";
  disableBtn.style.display = status.totp_registered ? "" : "none";
  document.getElementById("security-totp-setup-area").style.display = "none";
}

document.getElementById("security-add-passkey-btn").addEventListener("click", async () => {
  const issue = webauthnSupportIssue();
  if (issue) return alert(issue);
  try {
    await registerPasskey("Weiteres Gerät");
    alert("Passkey hinzugefügt.");
    loadSecurityStatus();
  } catch (err) {
    alert("Fehlgeschlagen: " + formatWebAuthnError(err));
  }
});

let securityPendingTotpSecret = null;

document.getElementById("security-setup-totp-btn").addEventListener("click", async () => {
  const res = await authedFetch("/api/auth/totp/setup/begin", { method: "POST" });
  const data = await res.json();
  securityPendingTotpSecret = data.secret;
  document.getElementById("security-totp-qr").innerHTML =
    `<img src="/api/auth/totp/qr?secret=${encodeURIComponent(data.secret)}" alt="QR-Code" style="width:180px;height:180px" />`;
  document.getElementById("security-totp-secret-fallback").textContent = `Manuell eintragen: ${data.secret}`;
  document.getElementById("security-totp-setup-area").style.display = "block";
});

document.getElementById("security-totp-confirm-btn").addEventListener("click", async () => {
  const code = document.getElementById("security-totp-code").value.trim();
  if (!securityPendingTotpSecret || !code) return;
  const res = await authedFetch("/api/auth/totp/setup/complete", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ secret: securityPendingTotpSecret, code }),
  });
  if (res.ok) {
    alert("Authenticator-App eingerichtet.");
    loadSecurityStatus();
  } else {
    alert("Code stimmt nicht überein — bitte erneut versuchen.");
  }
});

document.getElementById("security-disable-totp-btn").addEventListener("click", async () => {
  if (!confirm("Authenticator-App (TOTP) wirklich deaktivieren?")) return;
  await authedFetch("/api/auth/totp/disable", { method: "POST" });
  loadSecurityStatus();
});

function renderBackupStatus(backups) {
  const el = document.getElementById("backup-status");
  if (!backups || backups.length === 0) {
    el.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Sicherung vorhanden.</p>';
    return;
  }
  const latest = backups[0];
  const date = new Date(latest.created_at);
  el.innerHTML = `<p style="font-size:0.78rem;color:var(--good)">✅ Letzte Sicherung: ${date.toLocaleString("de-DE")} (${backups.length} insgesamt, ${latest.size_kb} KB)</p>`;
}

async function loadBackupStatus() {
  document.getElementById("backup-status").innerHTML = '<p class="muted" style="font-size:0.78rem">Lade …</p>';
  const backups = await (await authedFetch("/api/maintenance/backups")).json();
  renderBackupStatus(backups);
}

document.getElementById("backup-now-btn").addEventListener("click", async () => {
  const btn = document.getElementById("backup-now-btn");
  btn.disabled = true;
  document.getElementById("backup-status").innerHTML = '<p class="muted" style="font-size:0.78rem">Sichere …</p>';
  const res = await authedFetch("/api/maintenance/backup-now", { method: "POST" });
  const data = await res.json();
  btn.disabled = false;
  if (data.success) {
    loadBackupStatus();
  } else {
    document.getElementById("backup-status").innerHTML = `<p style="color:var(--bad);font-size:0.78rem">❌ Fehlgeschlagen: ${data.error}</p>`;
  }
});

let pendingCombinedUpdate = null;

function renderCombinedUpdateCheck(data) {
  const statusEl = document.getElementById("combined-update-status");
  const applyBtn = document.getElementById("apply-all-updates-btn");
  document.getElementById("app-version-current").textContent = (data.app && data.app.current_version) || "–";

  const hasAppUpdate = !!(data.app && data.app.update_available);
  const outdated = (data.packages && data.packages.outdated) || [];
  const hasPackages = outdated.length > 0;

  if (!hasAppUpdate && !hasPackages) {
    const appNote = data.app && data.app.error ? ` (App-Check: ${data.app.error})` : "";
    statusEl.innerHTML = `<p style="font-size:0.78rem;color:var(--good)">✅ Alles aktuell${appNote}.</p>`;
    applyBtn.style.display = "none";
    pendingCombinedUpdate = null;
    return;
  }

  let html = '<p style="font-size:0.78rem;color:var(--accent);margin-bottom:4px">Folgendes wird aktualisiert:</p><ul style="margin:0;font-size:0.75rem">';
  if (hasAppUpdate) {
    html += `<li>App: ${data.app.current_version} → ${data.app.latest_version}${data.app.notes ? ` — ${data.app.notes}` : ""}</li>`;
  }
  if (hasPackages) {
    html += `<li>${outdated.length} Python-Paket${outdated.length > 1 ? "e" : ""}: ${outdated.map((p) => `${p.name} ${p.current}→${p.latest}`).join(", ")}</li>`;
  }
  html += "</ul>";
  statusEl.innerHTML = html;

  pendingCombinedUpdate = {
    apply_app: hasAppUpdate, apply_packages: hasPackages,
    download_url: hasAppUpdate ? data.app.download_url : null,
    sha256: hasAppUpdate ? data.app.sha256 : null,
  };
  applyBtn.style.display = "";
}

document.getElementById("check-all-updates-btn").addEventListener("click", async () => {
  document.getElementById("combined-update-status").innerHTML = '<p class="muted" style="font-size:0.78rem">Prüfe …</p>';
  document.getElementById("apply-all-updates-btn").style.display = "none";
  const data = await (await authedFetch("/api/maintenance/check-all-updates")).json();
  renderCombinedUpdateCheck(data);
});

document.getElementById("apply-all-updates-btn").addEventListener("click", async () => {
  if (!pendingCombinedUpdate) return;
  if (!confirm("Jetzt aktualisieren? Der Dienst startet danach automatisch neu, eine erneute Anmeldung ist nötig. Das kann einige Minuten dauern.")) return;
  const btn = document.getElementById("apply-all-updates-btn");
  const resultEl = document.getElementById("combined-update-result");
  btn.disabled = true;
  resultEl.innerHTML = '<p class="muted">Aktualisiere … das kann einige Minuten dauern.</p>';
  const res = await authedFetch("/api/maintenance/apply-all-updates", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(pendingCombinedUpdate),
  });
  const data = await res.json();
  if (data.status === "applied") {
    if ("serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister()));
    }
    resultEl.innerHTML = '<p style="color:var(--good)">✅ Aktualisiert — Dienst wird neu gestartet, Seite lädt in wenigen Sekunden neu. Danach ist eine erneute Anmeldung nötig.</p>';
    setTimeout(() => window.location.reload(), 4000);
  } else {
    btn.disabled = false;
    resultEl.innerHTML = '<p style="color:var(--bad)">❌ Fehlgeschlagen — Details siehe Konsole.</p>';
    console.error("Update fehlgeschlagen:", data);
  }
});

// Beim Start der Seite automatisch und still im Hintergrund prüfen (App-
// Version + Python-Pakete zusammen) — bei Fund einen Hinweis-Banner
// zeigen, der direkt zur Bestätigung in den Einstellungen führt, statt den
// Nutzer ungefragt irgendetwas herunterladen zu lassen.
async function checkAllUpdatesOnBoot() {
  try {
    const data = await (await authedFetch("/api/maintenance/check-all-updates")).json();
    const hasAppUpdate = !!(data.app && data.app.update_available);
    const outdatedCount = (data.packages && data.packages.outdated && data.packages.outdated.length) || 0;
    if (!hasAppUpdate && outdatedCount === 0) return;

    const parts = [];
    if (hasAppUpdate) parts.push(`App ${data.app.latest_version}`);
    if (outdatedCount > 0) parts.push(`${outdatedCount} Paket${outdatedCount > 1 ? "e" : ""}`);

    const banner = document.createElement("div");
    banner.textContent = `🔄 Update verfügbar: ${parts.join(" · ")} — zum Prüfen klicken`;
    banner.style.cssText = `position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:var(--accent);color:${chartPalette().onColor};padding:10px 16px;border-radius:10px;font-size:0.85rem;font-weight:600;z-index:200;cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,0.3)`;
    banner.addEventListener("click", () => {
      banner.remove();
      document.getElementById("manage-categories-btn").click();
      renderCombinedUpdateCheck(data);
    });
    document.body.appendChild(banner);
  } catch (e) {
    // Update-Check ist rein informativ -- ein Fehler hier darf den
    // restlichen Seitenstart nicht stoeren.
  }
}

document.getElementById("manage-categories-btn-inner").addEventListener("click", async () => {
  await loadManageCategoriesList();
  categoriesOverlay.style.display = "flex";
});

document.getElementById("categories-overlay-close-btn").addEventListener("click", () => {
  categoriesOverlay.style.display = "none";
});

document.getElementById("toggle-energy-monitor").addEventListener("change", async (e) => {
  await authedFetch("/api/settings/energy_monitor_enabled", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ value: e.target.checked }),
  });
  applyEnergyMonitorToggle();
});

document.getElementById("toggle-vorsorge").addEventListener("change", async (e) => {
  await authedFetch("/api/settings/vorsorge_enabled", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ value: e.target.checked }),
  });
  applyVorsorgeToggle();
});

document.getElementById("manage-categories-close-btn").addEventListener("click", () => {
  manageCategoriesOverlay.style.display = "none";
});

document.getElementById("add-category-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("new-category-name");
  const name = input.value.trim();
  if (!name) return;
  const res = await authedFetch("/api/categories", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Anlegen.");
  }
  input.value = "";
  await loadManageCategoriesList();
});

const insuranceTypesOverlay = document.getElementById("insurance-types-overlay");

async function loadManageInsuranceTypesList() {
  allInsuranceTypes = await (await authedFetch("/api/insurance-types")).json();
  const list = document.getElementById("manage-insurance-types-list");
  list.innerHTML = allInsuranceTypes.map((t) => `<li><span>${t}</span></li>`).join("");
}

document.getElementById("manage-insurance-types-btn").addEventListener("click", async () => {
  await loadManageInsuranceTypesList();
  insuranceTypesOverlay.style.display = "flex";
});

document.getElementById("insurance-types-overlay-close-btn").addEventListener("click", () => {
  insuranceTypesOverlay.style.display = "none";
});

document.getElementById("add-insurance-type-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("new-insurance-type-name");
  const name = input.value.trim();
  if (!name) return;
  const res = await authedFetch("/api/insurance-types", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Anlegen.");
  }
  input.value = "";
  await loadManageInsuranceTypesList();
});

// ---------- Verträge & Abos, gruppiert nach Kategorie ----------
let allContracts = [];
let allCategories = [];
let contextMenuContractId = null;

async function loadContracts() {
  const res = await authedFetch("/api/contracts");
  const contracts = await res.json();
  allContracts = contracts;
  const container = document.getElementById("contract-groups");
  if (contracts.length === 0) {
    container.innerHTML = '<p class="muted">Noch keine Verträge erfasst</p>';
    return;
  }

  // Welche Gruppen waren gerade aufgeklappt? Sonst würde jede Änderung
  // (z.B. Betrag bearbeiten) alle Gruppen wieder einklappen, obwohl sich
  // nur die Sortierung aktualisiert — das wirkt dann wie ein Reset statt
  // einer nahtlosen Neusortierung.
  const expandedGroups = new Set(
    Array.from(container.querySelectorAll(".contract-list:not(.collapsed)"))
      .map((ul) => ul.dataset.group)
  );

  const groups = {};
  for (const c of contracts) {
    const key = c.category_name ? (c.subcategory ? `${c.category_name} · ${c.subcategory}` : c.category_name) : "Ohne Kategorie";
    (groups[key] = groups[key] || []).push(c);
  }
  // Immer wertbasiert sortiert -- höchster Betrag zuerst, sowohl je Gruppe
  // als auch innerhalb einer Gruppe. Keine manuelle Sortierung mehr.
  Object.values(groups).forEach((items) => items.sort((a, b) => b.monthly_amount - a.monthly_amount));

  const sortedGroups = Object.entries(groups)
    .map(([groupName, items]) => [groupName, items, items.reduce((sum, c) => sum + c.monthly_amount, 0)])
    .sort((a, b) => b[2] - a[2]);

  container.innerHTML = sortedGroups.map(([groupName, items, groupSum]) => {
    const isExpanded = expandedGroups.has(groupName);
    return `
    <div class="contract-group">
      <h3 class="group-toggle">
        <span class="chevron">${isExpanded ? "▾" : "▸"}</span> ${groupName}
        <span class="group-sum">${fmt(groupSum)}/Mon.</span>
      </h3>
      <ul class="contract-list${isExpanded ? "" : " collapsed"}" data-group="${groupName}">
        ${items.map((c) => `
          <li class="contract-row" data-drag-id="${c.id}" data-contract-row="${c.id}">
            <div class="contract-main">
              ${rowMenuButtonHTML("contract", c.id)}
              <span class="contract-label">${c.label}${!c.label_is_manual ? ' <span class="tag" style="opacity:0.6" title="Automatisch abgeleitet">✨</span>' : ""}</span>
              ${c.contract_end ? `<span class="tag">bis ${c.contract_end}</span>` : ""}
              <span class="tag">${sourceLabel(c.source)}</span>
            </div>
            <div class="contract-amount row-actions">
              <input type="text" class="inline-amount" data-contract-id="${c.id}" value="${formatAmountForInput(c.amount)}" inputmode="decimal" />
              <span class="muted" style="font-size:0.75rem">€/${freqLabel(c.frequency)} · ${fmt(c.monthly_amount)}/Mon.</span>
            </div>
          </li>`).join("")}
      </ul>
    </div>`;
  }).join("") + `
    <ul><li class="total-row"><span>Summe / Monat</span><span>${fmt(contracts.reduce((sum, c) => sum + c.monthly_amount, 0))}</span></li></ul>`;

  container.querySelectorAll(".group-toggle").forEach((h3) => {
    h3.addEventListener("click", () => {
      const ul = h3.nextElementSibling;
      ul.classList.toggle("collapsed");
      h3.querySelector(".chevron").textContent = ul.classList.contains("collapsed") ? "▸" : "▾";
    });
  });

  container.querySelectorAll("[data-contract-id]").forEach((input) => {
    input.addEventListener("change", async () => {
      const amount = parseGermanNumber(input.value);
      if (Number.isNaN(amount)) return alert("Ungültiger Betrag");
      await patchJSON(`/api/contracts/${input.dataset.contractId}`, { amount });
      loadContracts();
      loadDashboard();
    });
  });

  // Rechtsklick öffnet das Kontextmenü statt eines separaten Lösch-Buttons
  container.querySelectorAll("[data-contract-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuContractId = row.dataset.contractRow;
      showContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(container, "contract", (id, x, y) => {
    contextMenuContractId = id;
    showContextMenu(x, y);
  });

  const bulkReceiptSelect = document.getElementById("bulk-receipt-contract");
  if (bulkReceiptSelect) {
    const previousValue = bulkReceiptSelect.value;
    bulkReceiptSelect.innerHTML = contracts.map((c) => {
      const parts = [
        c.category_name ? (c.subcategory ? `${c.category_name} · ${c.subcategory}` : c.category_name) : "?",
        c.label, c.provider || null,
      ].filter(Boolean);
      return `<option value="${c.id}">${parts.join(" — ")}</option>`;
    }).join("");
    if (previousValue) bulkReceiptSelect.value = previousValue;
  }
}

// ---------- Neue Ausgabe manuell anlegen ----------
const addExpenseOverlay = document.getElementById("add-expense-overlay");

function updateExpenseConditionalFields() {
  const { category, subcategory } = parseCategoryValue(document.getElementById("expense-category").value);
  const isFinanzierung = category === "Haus" && subcategory === "Finanzierung";
  const isVersicherung = category === "Versicherungen";
  document.getElementById("expense-interest-rate-group").style.display = isFinanzierung ? "block" : "none";
  document.getElementById("expense-insurance-type-group").style.display = isVersicherung ? "block" : "none";

  const insType = document.getElementById("expense-insurance-type").value;
  document.getElementById("expense-insurance-life-group").style.display =
    (isVersicherung && insType === "Risikolebensversicherung") ? "block" : "none";
  document.getElementById("expense-bu-group").style.display =
    (isVersicherung && insType === "Berufsunfähigkeitsversicherung") ? "block" : "none";
}

document.getElementById("expense-category").addEventListener("change", updateExpenseConditionalFields);
document.getElementById("expense-insurance-type").addEventListener("change", updateExpenseConditionalFields);

function updateExpenseLabelDerivedHint() {
  const category = parseCategoryValue(document.getElementById("expense-category").value).category;
  const provider = document.getElementById("expense-provider").value.trim() || null;
  const contractNumber = document.getElementById("expense-contract-number").value.trim() || null;
  const insuranceType = document.getElementById("expense-insurance-type").value || null;
  const personSelect = document.getElementById("expense-person");
  const personName = personSelect.value
    ? allFamilyMembers.find((m) => String(m.id) === personSelect.value)?.name
    : null;

  const hasManualLabel = document.getElementById("expense-label").value.trim() !== "";
  const hint = document.getElementById("expense-label-derived-hint");
  if (hasManualLabel) {
    hint.style.display = "none";
    return;
  }
  let preview;
  if (category === "Versicherungen") {
    preview = [personName ? `${personName}:` : "", provider || "", insuranceType || "Versicherung"].filter(Boolean).join(" ");
  } else {
    preview = [provider || "Vertrag", contractNumber || ""].filter(Boolean).join(" ");
  }
  document.getElementById("expense-label-derived-preview").textContent = preview;
  hint.style.display = "block";
}

["expense-label", "expense-category", "expense-provider", "expense-contract-number", "expense-insurance-type", "expense-person"].forEach((id) => {
  document.getElementById(id).addEventListener("input", updateExpenseLabelDerivedHint);
  document.getElementById(id).addEventListener("change", updateExpenseLabelDerivedHint);
});

async function openAddExpenseForm(presetCategoryValue) {
  if (allCategories.length === 0) {
    allCategories = await (await authedFetch("/api/categories")).json();
  }
  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  if (allInsuranceTypes.length === 0) {
    allInsuranceTypes = await (await authedFetch("/api/insurance-types")).json();
  }
  const select = document.getElementById("expense-category");
  select.innerHTML = categoryOptionsHTML();
  document.getElementById("expense-person").innerHTML = personOptionsHTML(null);
  document.getElementById("expense-insurance-type").innerHTML = insuranceTypeOptionsHTML(null);
  document.getElementById("add-expense-form").reset();
  if (presetCategoryValue) select.value = presetCategoryValue;
  expenseEndDateToggle.setInitial(false); // Neuanlage startet ohne Fälligkeit, Feld sichtbar
  updateExpenseConditionalFields();
  updateExpenseLabelDerivedHint();
  addExpenseOverlay.style.display = "flex";
}

document.getElementById("add-expense-btn").addEventListener("click", () => openAddExpenseForm());

document.getElementById("add-expense-cancel-btn").addEventListener("click", () => {
  addExpenseOverlay.style.display = "none";
});

document.getElementById("add-expense-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const label = document.getElementById("expense-label").value.trim();
  const { category, subcategory } = parseCategoryValue(document.getElementById("expense-category").value);
  const provider = document.getElementById("expense-provider").value.trim() || null;
  const contract_number = document.getElementById("expense-contract-number").value.trim() || null;
  const amount = parseGermanNumber(document.getElementById("expense-amount").value);
  const frequency = document.getElementById("expense-frequency").value;
  const noEndDate = document.getElementById("expense-no-enddate").checked;
  const contract_end = noEndDate ? null : (document.getElementById("expense-contract-end").value || null);
  if (Number.isNaN(amount)) return alert("Bitte einen gültigen Betrag angeben.");

  const num = (id) => {
    return parseGermanNumber(document.getElementById(id).value);
  };
  const personVal = document.getElementById("expense-person").value;
  const payload = {
    label, provider, contract_number, category, subcategory, amount, frequency, contract_end,
    person_id: personVal ? parseInt(personVal, 10) : null,
    interest_rate: category === "Haus" && subcategory === "Finanzierung" ? num("expense-interest-rate") : null,
    insurance_type: category === "Versicherungen" ? document.getElementById("expense-insurance-type").value : null,
  };
  if (payload.insurance_type === "Risikolebensversicherung") {
    payload.insurance_expiry = document.getElementById("expense-insurance-expiry").value || null;
    payload.insurance_sum = num("expense-insurance-sum");
    payload.insurance_sum_type = document.getElementById("expense-insurance-sum-type").value;
  } else if (payload.insurance_type === "Berufsunfähigkeitsversicherung") {
    payload.bu_monthly_pension = num("expense-bu-pension");
  }

  const res = await authedFetch("/api/contracts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Anlegen.");
  }
  addExpenseOverlay.style.display = "none";
  loadContracts();
  loadDashboard();
  loadReview();
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
    if (document.getElementById("vermoegen-subtab-verbindlichkeiten").style.display !== "none") {
      loadVerbindlichkeiten();
    }
  }
});

// ---------- Kontextmenü ----------
const contextMenu = document.getElementById("context-menu");

function showContextMenu(x, y) {
  contextMenu.style.left = `${x}px`;
  contextMenu.style.top = `${y}px`;
  contextMenu.style.display = "block";
}

function hideContextMenu() {
  contextMenu.style.display = "none";
  contextMenuContractId = null;
}

document.addEventListener("click", (e) => {
  if (!contextMenu.contains(e.target)) hideContextMenu();
});

contextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuContractId;
  hideContextMenu();
  if (!id || !confirm("Diesen Vertrag archivieren? Er verschwindet aus der aktiven Liste, Belege bleiben im Archiv erhalten.")) return;
  const res = await authedFetch(`/api/contracts/${id}`, { method: "DELETE" });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.detail || "Fehler beim Archivieren.");
    return;
  }
  loadContracts();
  loadDashboard();
  loadReview();
});

contextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuContractId;
  hideContextMenu();
  if (!id) return;
  openDetailsModal(id);
});

// ---------- Kontextmenü für Rentenkonten (gleiche UX wie bei Ausgaben) ----------
let contextMenuPensionId = null;
const pensionContextMenu = document.getElementById("pension-context-menu");

function showPensionContextMenu(x, y) {
  pensionContextMenu.style.left = `${x}px`;
  pensionContextMenu.style.top = `${y}px`;
  pensionContextMenu.style.display = "block";
}

function hidePensionContextMenu() {
  pensionContextMenu.style.display = "none";
  contextMenuPensionId = null;
}

document.addEventListener("click", (e) => {
  if (!pensionContextMenu.contains(e.target)) hidePensionContextMenu();
});

pensionContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuPensionId;
  hidePensionContextMenu();
  if (!id) return;
  openPensionForm(id);
});

pensionContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuPensionId;
  hidePensionContextMenu();
  if (!id || !confirm("Dieses Rentenkonto wirklich löschen?")) return;
  await authedFetch(`/api/pension-accounts/${id}`, { method: "DELETE" });
  loadHaushaltSummary();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
  loadAufbauTab();
  loadAbsicherungTab();
});

// ---------- Alle Belege zu einem Vertrag anzeigen (aktiv oder archiviert) ----------
const receiptsListOverlay = document.getElementById("receipts-list-overlay");

async function showReceiptsList(contractId, contractLabel) {
  const title = document.getElementById("receipts-list-title");
  const content = document.getElementById("receipts-list-content");
  title.textContent = `🗂 Belege — ${contractLabel}`;
  content.innerHTML = '<p class="muted">Lade …</p>';
  receiptsListOverlay.style.display = "flex";
  await refreshReceiptsList(contractId, "receipts-list-content");
}

async function refreshReceiptsList(contractId, targetId = "receipts-list-content") {
  const content = document.getElementById(targetId);
  const receipts = await (await authedFetch(`/api/contracts/${contractId}/receipts`)).json();
  if (!receipts.length) {
    content.innerHTML = '<p class="muted">Noch keine Belege für diesen Vertrag hochgeladen.</p>';
    return;
  }
  content.innerHTML = `<div id="${targetId}-scroll"></div>`;
  setupScrollableDocList(`${targetId}-scroll`, receipts, (r) => resolveDocDate(r), (filtered, ul) => {
    ul.className = "receipt-list";
    ul.innerHTML = filtered.map((r) => {
      const dateStr = resolveDocDate(r) || "–";
      return `
      <li class="receipt-row">
        <a href="/api/receipts/${r.id}/file" rel="noopener" class="receipt-link" data-view-doc-url="/api/receipts/${r.id}/file" data-view-doc-title="${r.original_filename || "Beleg"}">
          <span class="receipt-date">${dateStr}</span>
          <span class="receipt-filename muted">${r.original_filename || "Beleg"}${r.detected_amount ? ` · ${fmt(r.detected_amount)}` : ""}</span>
        </a>
        <a href="/api/receipts/${r.id}/file?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
        <button type="button" class="del-btn" data-delete-receipt="${r.id}" title="Löschen">🗑</button>
      </li>`;
    }).join("");
    wireDocumentViewerLinks(ul);
    ul.querySelectorAll("[data-delete-receipt]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Diesen Beleg wirklich löschen?")) return;
        await authedFetch(`/api/receipts/${btn.dataset.deleteReceipt}`, { method: "DELETE" });
        refreshReceiptsList(contractId, targetId);
        loadContracts();
      });
    });
  });
}

document.getElementById("receipts-list-close-btn").addEventListener("click", () => {
  receiptsListOverlay.style.display = "none";
});

// ---------- Archiv: archivierte Verträge durchsuchen, ohne ins Dateisystem zu wechseln ----------
document.getElementById("open-archive-btn").addEventListener("click", async () => {
  const title = document.getElementById("receipts-list-title");
  const content = document.getElementById("receipts-list-content");
  title.textContent = "🗂 Archiv";
  content.innerHTML = '<p class="muted">Lade …</p>';
  receiptsListOverlay.style.display = "flex";

  const archived = await (await authedFetch("/api/archive")).json();
  if (!archived.length) {
    content.innerHTML = '<p class="muted">Noch keine archivierten Verträge — rechtsklick auf einen Vertrag → Archivieren.</p>';
    return;
  }
  content.innerHTML = `<div id="archive-list-scroll"></div>`;
  setupScrollableDocList("archive-list-scroll", archived, (c) => c.updated_at, (filtered, ul) => {
    ul.innerHTML = filtered.map((c) => `
        <li>
          <button type="button" data-archived-contract="${c.id}" data-archived-label="${c.label.replace(/"/g, "&quot;")}"
                  style="background:none;border:none;color:var(--text);cursor:pointer;text-align:left;padding:0;font-size:0.9rem;flex:1;min-width:0">
            ${c.category_name ? `${c.category_name}${c.subcategory ? " · " + c.subcategory : ""} — ` : ""}${c.provider || c.label}
            <div class="muted" style="font-size:0.72rem">${c.receipt_count} Beleg(e)${c.updated_at ? " · archiviert " + c.updated_at.slice(0, 10) : ""}</div>
          </button>
          <button type="button" class="ghost-btn" style="width:auto;padding:6px 10px;font-size:0.75rem" data-restore-contract="${c.id}">↩️ Wiederherstellen</button>
        </li>
      `).join("");
    ul.querySelectorAll("[data-archived-contract]").forEach((btn) => {
      btn.addEventListener("click", () => {
        showReceiptsList(btn.dataset.archivedContract, btn.dataset.archivedLabel);
      });
    });
  });
  content.querySelectorAll("[data-restore-contract]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diesen Vertrag wiederherstellen? Er erscheint danach wieder in der aktiven Liste.")) return;
      const res = await authedFetch(`/api/contracts/${btn.dataset.restoreContract}/restore`, { method: "POST" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        return alert(err.detail || "Fehler beim Wiederherstellen.");
      }
      document.getElementById("open-archive-btn").click();
      loadContracts();
      loadDashboard();
    });
  });
});

// ---------- Fälligkeitsdatum <-> "Unbefristet"-Checkbox: garantiert gegenseitig exklusiv ----------
// Native <input type="date"> zeigen leer manchmal das heutige Datum blass als Platzhalter an —
// das sah wie ein gesetzter Wert aus, obwohl keiner da war. Deshalb wird das Feld bei
// "Unbefristet" komplett ausgeblendet statt nur deaktiviert, das ist eindeutig.
function wireEndDateToggle(dateId, checkboxId) {
  const dateInput = document.getElementById(dateId);
  const checkbox = document.getElementById(checkboxId);

  function apply(unbefristet) {
    checkbox.checked = unbefristet;
    dateInput.style.display = unbefristet ? "none" : "block";
    dateInput.disabled = unbefristet;
    if (unbefristet) dateInput.value = "";
  }

  checkbox.addEventListener("change", () => apply(checkbox.checked));
  // Datum eingetragen -> "Unbefristet" automatisch abwählen (andere Richtung der Exklusivität)
  dateInput.addEventListener("input", () => {
    if (dateInput.value) apply(false);
  });

  return { setInitial: (hasDate) => apply(!hasDate) };
}

const detailsEndDateToggle = wireEndDateToggle("details-contract-end", "details-no-enddate");
const expenseEndDateToggle = wireEndDateToggle("expense-contract-end", "expense-no-enddate");

// ---------- Details-Formular ----------
const detailsOverlay = document.getElementById("details-overlay");

let allFamilyMembers = [];
let allInsuranceTypes = [];

function personOptionsHTML(selectedId) {
  return `<option value="">– haushaltsweit –</option>` + allFamilyMembers.map((m) =>
    `<option value="${m.id}" ${String(m.id) === String(selectedId) ? "selected" : ""}>${m.name}</option>`
  ).join("");
}

function insuranceTypeOptionsHTML(selected) {
  return allInsuranceTypes.map((t) =>
    `<option value="${t}" ${t === selected ? "selected" : ""}>${t}</option>`
  ).join("");
}

function updateDetailsConditionalFields() {
  const { category, subcategory } = parseCategoryValue(document.getElementById("details-category").value);
  const isFinanzierung = category === "Haus" && subcategory === "Finanzierung";
  const isVersicherung = category === "Versicherungen";
  document.getElementById("details-interest-rate-group").style.display = isFinanzierung ? "block" : "none";
  document.getElementById("details-insurance-type-group").style.display = isVersicherung ? "block" : "none";

  const insType = document.getElementById("details-insurance-type").value;
  document.getElementById("details-insurance-life-group").style.display =
    (isVersicherung && insType === "Risikolebensversicherung") ? "block" : "none";
  document.getElementById("details-bu-group").style.display =
    (isVersicherung && insType === "Berufsunfähigkeitsversicherung") ? "block" : "none";
}

document.getElementById("details-category").addEventListener("change", updateDetailsConditionalFields);
document.getElementById("details-insurance-type").addEventListener("change", updateDetailsConditionalFields);

function updateDetailsLabelDerivedHint() {
  const category = parseCategoryValue(document.getElementById("details-category").value).category;
  const provider = document.getElementById("details-provider").value.trim() || null;
  const contractNumber = document.getElementById("details-contract-number").value.trim() || null;
  const insuranceType = document.getElementById("details-insurance-type").value || null;
  const personSelect = document.getElementById("details-person");
  const personName = personSelect.value
    ? allFamilyMembers.find((m) => String(m.id) === personSelect.value)?.name
    : null;

  const hasManualLabel = document.getElementById("details-label").value.trim() !== "";
  const hint = document.getElementById("details-label-derived-hint");
  if (hasManualLabel) {
    hint.style.display = "none";
    return;
  }
  let preview;
  if (category === "Versicherungen") {
    preview = [personName ? `${personName}:` : "", provider || "", insuranceType || "Versicherung"].filter(Boolean).join(" ");
  } else {
    preview = [provider || "Vertrag", contractNumber || ""].filter(Boolean).join(" ");
  }
  document.getElementById("details-label-derived-preview").textContent = preview;
  hint.style.display = "block";
}

["details-category", "details-provider", "details-contract-number", "details-insurance-type", "details-person"].forEach((id) => {
  document.getElementById(id).addEventListener("input", updateDetailsLabelDerivedHint);
  document.getElementById(id).addEventListener("change", updateDetailsLabelDerivedHint);
});
document.getElementById("details-label").addEventListener("input", updateDetailsLabelDerivedHint);

document.getElementById("details-label-clear-btn").addEventListener("click", () => {
  document.getElementById("details-label").value = "";
  updateDetailsLabelDerivedHint();
});

document.getElementById("details-show-receipts-btn").addEventListener("click", async () => {
  const section = document.getElementById("details-receipts-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) {
    section.style.display = "none";
    return;
  }
  const contractId = document.getElementById("details-form").dataset.contractId;
  section.style.display = "block";
  section.innerHTML = '<p class="muted">Lade …</p>';
  await refreshReceiptsList(contractId, "details-receipts-section");
});

// ---------- Tilgungsplan (Restschuld-Verlauf + kumulierte Zinsen) ----------
// ---------- Gemeinsamer, wiederverwendbarer Mehrlinien-Chart mit
// klickbarer Legende (Linie ein-/ausblenden) und Hover-Tooltips (Wert +
// Bezeichnung) — von allen Verlaufs-Charts der App genutzt, damit sich
// diese Interaktion nicht mehrfach unterschiedlich verhält. ----------
let chartInstanceCounter = 0;

// Wandelt eine Punktfolge in einen sanft geglätteten SVG-Pfad um (Catmull-Rom
// zu kubischen Bezier-Kurven) statt scharfer Eckpunkte zwischen geraden
// Liniensegmenten — der Hauptunterschied zwischen "Excel-Diagramm" und
// modernem Look.
function smoothLinePath(pts) {
  if (pts.length < 2) return "";
  if (pts.length === 2) return `M ${pts[0][0]} ${pts[0][1]} L ${pts[1][0]} ${pts[1][1]}`;
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i === 0 ? 0 : i - 1];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2 < pts.length ? i + 2 : i + 1];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2[0]} ${p2[1]}`;
  }
  return d;
}

function renderInteractiveMultiLineChart(container, points, series, opts = {}) {
  const W = opts.width || 700, H = opts.height || 260;
  const padL = opts.padL || 60, padR = opts.padR || 10, padT = opts.padT || 15, padB = opts.padB || 30;
  const chartW = W - padL - padR, chartH = H - padT - padB;
  const yFormat = opts.yFormat || fmt;
  const xLabel = opts.xLabel || ((p) => String(p.year ?? ""));
  const instanceId = `chart${++chartInstanceCounter}`;

  const maxVal = Math.max(...points.flatMap((p) => series.map((s) => p[s.key] || 0))) * 1.05 || 1;
  const x = (i) => padL + (i / (points.length - 1 || 1)) * chartW;
  const y = (v) => padT + chartH - ((v || 0) / maxVal) * chartH;
  const seriesPoints = (key) => points.map((p, i) => [x(i), y(p[key])]);
  const linePath = (key) => smoothLinePath(seriesPoints(key));
  // Flaeche unter der Linie bis zur x-Achse, fuer den Gradient-Fuellungs-Effekt.
  const areaPath = (key) => `${linePath(key)} L ${x(points.length - 1)} ${padT + chartH} L ${x(0)} ${padT + chartH} Z`;

  // Nur ein paar dezente horizontale Gitterlinien statt eines Kastens —
  // wirkt deutlich weniger "Tabellenkalkulation".
  const gridLines = [0.33, 0.66, 1].map((f) =>
    `<line x1="${padL}" y1="${padT + chartH * (1 - f)}" x2="${W - padR}" y2="${padT + chartH * (1 - f)}" stroke="rgba(255,255,255,0.06)" stroke-dasharray="2,4" />`
  ).join("");

  // Nur eine begrenzte Anzahl X-Achsen-Beschriftungen, sonst überlappen sie
  // bei langen Zeitreihen.
  const labelEvery = Math.max(1, Math.ceil(points.length / (opts.maxXLabels || 8)));
  const xLabelsHtml = points.map((p, i) => {
    if (i !== 0 && i !== points.length - 1 && i % labelEvery !== 0) return "";
    const anchor = i === 0 ? "start" : i === points.length - 1 ? "end" : "middle";
    return `<text x="${x(i)}" y="${H - 8}" text-anchor="${anchor}" font-size="10" fill="var(--muted)">${xLabel(p, i)}</text>`;
  }).join("");

  // Pro Punkt und Serie ein unsichtbarer, aber gut treffbarer Kreis mit
  // nativem Tooltip (Browser-eigenes <title>) — zeigt Bezeichnung + Wert
  // beim Hovern, ganz ohne eigenes Tooltip-Positionierungs-JS.
  const dotsHtml = series.map((s) => points.map((p, i) => `
      <circle cx="${x(i)}" cy="${y(p[s.key])}" r="7" fill="transparent" data-series-dot="${s.key}">
        <title>${xLabel(p, i)} — ${s.label}: ${yFormat(p[s.key] || 0)}</title>
      </circle>`).join("")).join("");

  const gradientDefs = series.map((s) => `
    <linearGradient id="${instanceId}-grad-${s.key}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${s.color}" stop-opacity="0.14" />
      <stop offset="100%" stop-color="${s.color}" stop-opacity="0" />
    </linearGradient>`).join("");

  container.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block" id="${instanceId}">
      <defs>${gradientDefs}</defs>
      ${gridLines}
      <line x1="${padL}" y1="${padT + chartH}" x2="${W - padR}" y2="${padT + chartH}" stroke="rgba(255,255,255,0.15)" />
      <text x="${padL}" y="12" font-size="10" fill="var(--muted)">${yFormat(maxVal).replace(/,\d+/, "")}</text>
      ${series.map((s) => s.fill === false ? "" : `<path data-series-area="${s.key}" d="${areaPath(s.key)}" fill="url(#${instanceId}-grad-${s.key})" stroke="none" />`).join("")}
      ${series.map((s) => `<path data-series-line="${s.key}" d="${linePath(s.key)}" fill="none" stroke="${s.color}" stroke-width="${s.width || 2}" stroke-linecap="round" stroke-linejoin="round" ${s.dashed ? 'stroke-dasharray="4,3"' : ""} />`).join("")}
      ${dotsHtml}
      ${xLabelsHtml}
    </svg>
    <div class="row-actions" style="justify-content:center;gap:14px;font-size:0.72rem;margin-top:4px;flex-wrap:wrap">
      ${series.map((s) => `<span data-legend-toggle="${s.key}" style="cursor:pointer;user-select:none"><span style="color:${s.color}">●</span> ${s.label}</span>`).join("")}
    </div>`;

  const svg = container.querySelector(`#${instanceId}`);
  container.querySelectorAll("[data-legend-toggle]").forEach((legendItem) => {
    legendItem.addEventListener("click", () => {
      const key = legendItem.dataset.legendToggle;
      const line = svg.querySelector(`[data-series-line="${key}"]`);
      const area = svg.querySelector(`[data-series-area="${key}"]`);
      const hidden = line.style.display === "none";
      line.style.display = hidden ? "" : "none";
      if (area) area.style.display = hidden ? "" : "none";
      svg.querySelectorAll(`[data-series-dot="${key}"]`).forEach((dot) => { dot.style.display = hidden ? "" : "none"; });
      legendItem.style.opacity = hidden ? "1" : "0.35";
      legendItem.style.textDecoration = hidden ? "none" : "line-through";
    });
  });
}

function renderRepaymentChart(containerId, data) {
  const el = document.getElementById(containerId);
  if (data.error) {
    el.innerHTML = `<p class="muted" style="font-size:0.8rem">${data.error}</p>`;
    return;
  }
  const pts = data.schedule;
  if (pts.length < 2) {
    el.innerHTML = '<p class="muted" style="font-size:0.8rem">Zu wenig Daten für einen Verlauf.</p>';
    return;
  }

  el.innerHTML = `
    <p class="muted" style="font-size:0.78rem;margin:0 0 8px">
      ${fmtEur0(data.remaining_debt)} Restschuld bei ${data.interest_rate}% · ${fmtEur0(data.monthly_payment)}/Mo
      → abbezahlt <b>${data.payoff_year}</b> (${data.years_to_payoff} Jahre), dabei ${fmtEur0(data.total_interest)} Zinsen.
    </p>
    <div id="${containerId}-chart-inner"></div>`;

  const cp1 = chartPalette();
  renderInteractiveMultiLineChart(
    document.getElementById(`${containerId}-chart-inner`),
    pts,
    [
      { key: "remaining_debt", label: "Restschuld", color: cp1.orange, width: 2.5 },
      { key: "interest_paid_cumulative", label: "Gezahlte Zinsen (kumuliert)", color: cp1.purple, width: 2, dashed: true, fill: false },
    ],
    { height: 190, yFormat: fmtEur0, xLabel: (p) => p.year }
  );
}

async function loadRepaymentSchedule(contractId) {
  const section = document.getElementById("details-repayment-section");
  const chart = document.getElementById("details-repayment-chart");
  section.style.display = "block";
  chart.innerHTML = '<p class="muted">Lade …</p>';
  const res = await authedFetch(`/api/contracts/${contractId}/repayment-schedule`);
  if (!res.ok) {
    chart.innerHTML = '<p class="muted" style="font-size:0.8rem">Tilgungsplan konnte nicht geladen werden.</p>';
    return;
  }
  renderRepaymentChart("details-repayment-chart", await res.json());
}

async function openDetailsModal(contractId) {
  const c = allContracts.find((x) => String(x.id) === String(contractId));
  if (!c) return;
  if (allCategories.length === 0) {
    allCategories = await (await authedFetch("/api/categories")).json();
  }
  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  if (allInsuranceTypes.length === 0) {
    allInsuranceTypes = await (await authedFetch("/api/insurance-types")).json();
  }
  const catSelect = document.getElementById("details-category");
  catSelect.innerHTML = categoryOptionsHTML();
  catSelect.value = categoryValueFor(c.category_name, c.subcategory);

  document.getElementById("details-person").innerHTML = personOptionsHTML(c.person_id);
  document.getElementById("details-insurance-type").innerHTML = insuranceTypeOptionsHTML(c.insurance_type);
  document.getElementById("details-interest-rate").value = c.interest_rate ?? "";
  document.getElementById("details-remaining-debt").value = c.remaining_debt != null ? formatAmountForInput(c.remaining_debt) : "";
  document.getElementById("details-repayment-rate").value = c.repayment_rate ?? "";
  document.getElementById("details-fixed-interest-until").value = c.fixed_interest_until || "";
  document.getElementById("details-insurance-expiry").value = c.insurance_expiry || "";
  document.getElementById("details-insurance-sum").value = c.insurance_sum != null ? formatAmountForInput(c.insurance_sum) : "";
  document.getElementById("details-insurance-sum-type").value = c.insurance_sum_type || "fix";
  document.getElementById("details-bu-pension").value = c.bu_monthly_pension ?? "";

  document.getElementById("details-form").dataset.contractId = contractId;
  // Nur den TATSÄCHLICH manuell gesetzten Namen ins Feld schreiben — bei
  // Ableitung ist c.label bereits der berechnete Anzeigename, den man sonst
  // fälschlich als "manuell gesetzt" ins Feld übernehmen würde.
  document.getElementById("details-label").value = c.label_is_manual ? c.label : "";
  document.getElementById("details-provider").value = c.provider || "";
  document.getElementById("details-contract-number").value = c.contract_number || "";
  document.getElementById("details-contract-end").value = c.contract_end || "";
  detailsEndDateToggle.setInitial(!!c.contract_end);
  document.getElementById("details-frequency").value = c.frequency || "monthly";
  document.getElementById("details-link").value = c.link || "";
  document.getElementById("details-updated-at").textContent = c.updated_at || "–";
  document.getElementById("details-receipts-section").style.display = "none";
  // Tilgungsplan nur bei Finanzierungen mit hinterlegter Restschuld — sonst
  // gäbe es nichts zu rechnen und der Abschnitt bliebe leer.
  const isFinanzierung = c.category_name === "Haus" && c.subcategory === "Finanzierung";
  if (isFinanzierung && c.remaining_debt) {
    loadRepaymentSchedule(contractId);
  } else {
    document.getElementById("details-repayment-section").style.display = "none";
  }
  updateDetailsConditionalFields();
  updateDetailsLabelDerivedHint();
  detailsOverlay.style.display = "flex";
}

document.getElementById("details-cancel-btn").addEventListener("click", () => {
  detailsOverlay.style.display = "none";
});

document.getElementById("details-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const contractId = e.target.dataset.contractId;
  // Bewusst OHNE Rückfall auf den alten Namen: wird das Feld absichtlich
  // leer gelassen, soll das auch leer beim Server ankommen (= Ableitung
  // einschalten), nicht stillschweigend beim vorherigen Namen bleiben.
  const newLabel = document.getElementById("details-label").value.trim();
  const { category, subcategory } = parseCategoryValue(document.getElementById("details-category").value);
  const noEndDate = document.getElementById("details-no-enddate").checked;
  const num = (id) => {
    return parseGermanNumber(document.getElementById(id).value);
  };
  const personVal = document.getElementById("details-person").value;
  const payload = {
    label: newLabel,
    provider: document.getElementById("details-provider").value.trim() || null,
    category,
    subcategory,
    contract_number: document.getElementById("details-contract-number").value || null,
    contract_end: noEndDate ? null : (document.getElementById("details-contract-end").value || null),
    frequency: document.getElementById("details-frequency").value,
    link: document.getElementById("details-link").value || null,
    person_id: personVal ? parseInt(personVal, 10) : null,
    interest_rate: category === "Haus" && subcategory === "Finanzierung" ? num("details-interest-rate") : null,
    remaining_debt: category === "Haus" && subcategory === "Finanzierung" ? num("details-remaining-debt") : null,
    repayment_rate: category === "Haus" && subcategory === "Finanzierung" ? num("details-repayment-rate") : null,
    fixed_interest_until: category === "Haus" && subcategory === "Finanzierung" ? (document.getElementById("details-fixed-interest-until").value || null) : null,
    insurance_type: category === "Versicherungen" ? document.getElementById("details-insurance-type").value : null,
  };
  if (payload.insurance_type === "Risikolebensversicherung") {
    payload.insurance_expiry = document.getElementById("details-insurance-expiry").value || null;
    payload.insurance_sum = num("details-insurance-sum");
    payload.insurance_sum_type = document.getElementById("details-insurance-sum-type").value;
  } else if (payload.insurance_type === "Berufsunfähigkeitsversicherung") {
    payload.bu_monthly_pension = num("details-bu-pension");
  }

  await patchJSON(`/api/contracts/${contractId}`, payload);
  detailsOverlay.style.display = "none";
  loadContracts();
  loadDashboard();
  loadReview();
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
    if (document.getElementById("vermoegen-subtab-verbindlichkeiten").style.display !== "none") {
      loadVerbindlichkeiten();
    }
  }
});

// ---------- Noch zu kategorisieren ----------
async function loadReview() {
  if (allCategories.length === 0) {
    allCategories = await (await authedFetch("/api/categories")).json();
  }
  const res = await authedFetch("/api/contracts?needs_review=true");
  const items = await res.json();
  const section = document.getElementById("block-review");
  const list = document.getElementById("review-list");

  if (items.length === 0) {
    section.style.display = "none";
    return;
  }
  section.style.display = "block";

  const categoryOptions = categoryOptionsHTML();

  list.innerHTML = items.map((c) => `
    <li>
      <span>${c.provider || c.label} <span class="tag">${fmt(c.amount)}/${freqLabel(c.frequency)}</span></span>
      <span class="row-actions">
        <select data-recategorize="${c.id}">
          <option value="">Kategorie wählen …</option>
          ${categoryOptions}
        </select>
        <button class="del-btn" data-delete-review="${c.id}" title="Löschen">🗑</button>
      </span>
    </li>`).join("");

  list.querySelectorAll("[data-recategorize]").forEach((select) => {
    select.addEventListener("change", async () => {
      if (!select.value) return;
      const { category, subcategory } = parseCategoryValue(select.value);
      await patchJSON(`/api/contracts/${select.dataset.recategorize}`, { category, subcategory });
      loadReview();
      loadContracts();
      loadDashboard();
    });
  });

  list.querySelectorAll("[data-delete-review]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diese Position wirklich löschen?")) return;
      await authedFetch(`/api/contracts/${btn.dataset.deleteReview}`, { method: "DELETE" });
      loadReview();
      loadContracts();
      loadDashboard();
    });
  });
}

// ---------- Beleg-Upload ----------
document.getElementById("upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("receipt-input");
  const resultDiv = document.getElementById("upload-result");
  if (!input.files.length) {
    resultDiv.textContent = "Bitte zuerst ein Foto auswählen.";
    return;
  }
  resultDiv.textContent = "Wird lokal erkannt …";
  const formData = new FormData();
  formData.append("file", input.files[0]);

  let res, data;
  try {
    res = await authedFetch("/api/receipts/upload", { method: "POST", body: formData });
    data = await res.json();
  } catch (err) {
    resultDiv.textContent = "Upload fehlgeschlagen: " + err.message;
    return;
  }
  if (!res.ok) {
    resultDiv.innerHTML = `<div class="healthcheck-item healthcheck-yellow">
      <p style="margin:0;font-size:0.85rem">${data.detail || "Fehler beim Hochladen."}</p>
    </div>`;
    input.value = "";
    return;
  }

  const d = data.detected;
  const attention = data.needs_attention || [];
  const engineLabel = d.ocr_engine === "vision" ? "macOS Vision (lokal)"
    : d.ocr_engine === "tesseract" ? "Tesseract (lokal)"
    : d.ocr_engine === "pdf-text" ? "PDF-Text (direkt)" : "keine Erkennung";

  const contractOptions = allContracts.map((c) => {
    const parts = [
      c.category_name ? (c.subcategory ? `${c.category_name} · ${c.subcategory}` : c.category_name) : "?",
      c.label,
      c.provider || null,
      c.contract_number || null,
    ].filter(Boolean);
    return `<option value="${c.id}">${parts.join(" — ")}</option>`;
  }).join("");

  const flag = (name) => (attention.includes(name) ? ' class="needs-attention"' : "");
  const periodText = d.period_start && d.period_end ? `Zeitraum: ${d.period_start} – ${d.period_end}` : "";

  resultDiv.innerHTML = `
    <p class="muted" style="margin:8px 0 4px">Erkennung: ${engineLabel}${d.ocr_error ? " – " + d.ocr_error : ""}</p>
    ${periodText ? `<p class="muted" style="margin:0 0 8px;font-size:0.75rem">${periodText}</p>` : ""}

    <label class="muted" style="font-size:0.8rem">Betrag (€)</label>
    <input type="text" id="confirm-amount"${flag("Betrag")} value="${d.amount != null ? formatAmountForInput(d.amount) : ""}" placeholder="z.B. 34,90" />

    <label class="muted" style="font-size:0.8rem">Anbieter</label>
    <input type="text" id="confirm-provider" value="${d.provider ?? ""}" placeholder="z.B. octopus energy" />

    <label class="muted" style="font-size:0.8rem">Vertragsnummer</label>
    <input type="text" id="confirm-contract-number" value="${d.contract_number ?? ""}" placeholder="z.B. K-123456" />

    <label class="muted" style="font-size:0.8rem">Homepage / Link</label>
    <input type="text" id="confirm-website" value="${d.website ?? ""}" placeholder="https://…" />

    <label class="muted" style="font-size:0.8rem">Zu welchem Vertrag gehört das? *</label>
    ${allContracts.length === 0
      ? `<p class="muted" style="margin:4px 0 8px;font-size:0.78rem">Noch keine Verträge angelegt — bitte zuerst einen Vertrag anlegen, dann kann dieser Beleg zugeordnet werden.</p>`
      : `<select id="confirm-contract"${flag("Zuordnung zu einem Vertrag")}>
      <option value="" disabled selected>– bitte auswählen –</option>
      ${contractOptions}
    </select>`}
    ${data.matched_contract ? `<p class="muted" style="margin:4px 0 0;font-size:0.75rem">✅ automatisch zugeordnet (${data.matched_contract.confidence === "vertragsnummer" ? "Vertragsnummer" : "Anbieter"})</p>` : ""}

    <label class="checkbox-label">
      <input type="checkbox" id="confirm-update-expense" checked />
      <span>Ausgabe/Vertragsbetrag aktualisieren (bei reinen Mitteilungen ohne Rechnungsbetrag abwählen)</span>
    </label>

    <button id="confirm-receipt-btn" style="margin-top:10px"${allContracts.length === 0 ? " disabled" : ""}>Bestätigen &amp; übernehmen</button>
  `;

  if (data.matched_contract) {
    document.getElementById("confirm-contract").value = String(data.matched_contract.id);
  }

  const applyContractDataToForm = (contractId) => {
    const contract = allContracts.find((c) => String(c.id) === String(contractId));
    if (!contract) return;
    // Anbieter/Vertragsnummer/Link sind Eigenschaften des Vertrags selbst
    // und ändern sich praktisch nie — hier gewinnt immer der bekannte
    // Vertragswert. Der Betrag dagegen ändert sich naturgemäß von Rechnung
    // zu Rechnung (neue Abrechnungsperiode) — ein bereits korrekt per OCR
    // erkannter neuer Betrag darf hier nie durch den alten Vertragswert
    // überschrieben werden, deshalb nur dort auffüllen, wenn das Feld noch leer ist.
    const amountEl = document.getElementById("confirm-amount");
    if (!amountEl.value) amountEl.value = contract.amount != null ? formatAmountForInput(contract.amount) : "";
    document.getElementById("confirm-provider").value = contract.provider || "";
    document.getElementById("confirm-contract-number").value = contract.contract_number || "";
    document.getElementById("confirm-website").value = contract.link || "";
  };
  const contractSelect = document.getElementById("confirm-contract");
  if (contractSelect) {
    contractSelect.addEventListener("change", () => applyContractDataToForm(contractSelect.value));
    if (data.matched_contract) applyContractDataToForm(data.matched_contract.id);
  }

  document.getElementById("confirm-receipt-btn").addEventListener("click", async () => {
    const contractSelectEl = document.getElementById("confirm-contract");
    if (!contractSelectEl || !contractSelectEl.value) {
      if (contractSelectEl) contractSelectEl.classList.add("needs-attention");
      alert("Bitte einen Vertrag zuordnen — eine Ausgabe ohne Zuordnung kann nicht übernommen werden.");
      return;
    }

    const amount = parseGermanNumber(document.getElementById("confirm-amount").value);
    const provider = document.getElementById("confirm-provider").value || null;
    const contract_number = document.getElementById("confirm-contract-number").value || null;
    const link = document.getElementById("confirm-website").value || null;
    const contract_id = parseInt(contractSelectEl.value, 10);
    const update_expense = document.getElementById("confirm-update-expense").checked;

    const confirmRes = await authedFetch(`/api/receipts/${data.receipt_id}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contract_id, amount, provider, contract_number, link, update_expense }),
    });
    if (confirmRes.ok) {
      resultDiv.innerHTML = "Übernommen ✅";
      input.value = "";
      loadContracts();
      loadDashboard();
    } else {
      const err = await confirmRes.json().catch(() => ({}));
      alert(err.detail || "Fehler beim Bestätigen.");
    }
  });
});

// ---------- Chatbot ----------
document.getElementById("chat-btn").addEventListener("click", async () => {
  const input = document.getElementById("chat-input");
  const log = document.getElementById("chat-log");
  const question = input.value.trim();
  if (!question) return;

  log.innerHTML += `<div class="q">Du: ${question}</div><div class="a">Denke nach …</div>`;
  log.scrollTop = log.scrollHeight;
  input.value = "";

  const res = await authedFetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question }),
  });
  const data = await res.json();
  log.lastElementChild.textContent = data.answer;
  log.scrollTop = log.scrollHeight;
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/service-worker.js").then((registration) => {
    // Eine als PWA installierte/im Dock liegende App bekommt neue Dateien
    // sonst oft erst nach einem vollständigen Beenden+Neustart zu sehen —
    // ein einfaches "in den Vordergrund holen" reicht bei einer PWA anders
    // als bei einem Browser-Tab meist NICHT für einen echten Reload. Daher
    // hier aktiv nachfragen, sobald die App wieder sichtbar wird, statt nur
    // auf die (bei ruhenden PWAs seltene) automatische Browser-Prüfung zu
    // warten.
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") registration.update();
    });

    navigator.serviceWorker.addEventListener("controllerchange", () => {
      // Ein offener, unbestätigter Dialog (z.B. mitten in einer Bearbeitung)
      // soll nicht durch einen automatischen Reload weggerissen werden —
      // dann lieber ein dezenter Hinweis, der beim Fertigwerden Zeit lässt.
      const openOverlay = [...document.querySelectorAll(".overlay")]
        .some((o) => getComputedStyle(o).display !== "none");
      if (openOverlay) {
        showUpdateAvailableBanner();
      } else {
        window.location.reload();
      }
    });
  });
}

function showUpdateAvailableBanner() {
  if (document.getElementById("update-available-banner")) return;
  const banner = document.createElement("div");
  banner.id = "update-available-banner";
  banner.style.cssText = `position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:var(--accent);color:${chartPalette().onColor};padding:10px 16px;border-radius:10px;font-size:0.85rem;font-weight:600;z-index:200;cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,0.3)`;
  banner.textContent = "🔄 Neue Version verfügbar — zum Aktualisieren klicken";
  banner.addEventListener("click", () => window.location.reload());
  document.body.appendChild(banner);
}

function applyUiScale() {
  // Bewusst NICHT vom Server geladen: die Textgröße ist eine reine
  // Geräte-Einstellung (z.B. am Mac "Groß", am iPhone "Klein") — ein
  // geräteübergreifend geteilter Wert würde die Wahl eines Geräts beim
  // nächsten Laden auf einem anderen Gerät überschreiben.
  const cached = localStorage.getItem("ui_scale");
  const scale = ["s", "m", "l"].includes(cached) ? cached : "m";
  document.documentElement.classList.remove("ui-scale-s", "ui-scale-m", "ui-scale-l");
  document.documentElement.classList.add(`ui-scale-${scale}`);
  document.querySelectorAll("#ui-scale-selector [data-ui-scale]").forEach((btn) => {
    btn.classList.toggle("active-scale", btn.dataset.uiScale === scale);
  });
  updateHeaderHeightVar();
}

document.querySelectorAll("#ui-scale-selector [data-ui-scale]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const scale = btn.dataset.uiScale;
    document.documentElement.classList.remove("ui-scale-s", "ui-scale-m", "ui-scale-l");
    document.documentElement.classList.add(`ui-scale-${scale}`);
    localStorage.setItem("ui_scale", scale);
    document.querySelectorAll("#ui-scale-selector [data-ui-scale]").forEach((b) => {
      b.classList.toggle("active-scale", b === btn);
    });
    updateHeaderHeightVar();
  });
});

function applyUiTheme(theme) {
  const valid = ["dark", "light", "apple", "nothing", "retro80s"];
  const t = valid.includes(theme) ? theme : "dark";
  document.documentElement.setAttribute("data-theme", t);
  localStorage.setItem("ui_theme", t);
  document.querySelectorAll("#ui-theme-selector [data-ui-theme]").forEach((btn) => {
    btn.classList.toggle("active-scale", btn.dataset.uiTheme === t);
  });
  const headerIcon = document.getElementById("app-header-icon");
  if (headerIcon) headerIcon.src = `/icons/icon-${t}.svg`;
  const touchIcon = document.getElementById("apple-touch-icon-link");
  if (touchIcon) touchIcon.href = `/icons/icon-${t}-180.png`;
  const favicon = document.getElementById("favicon-link");
  if (favicon) favicon.href = `/icons/icon-${t}.svg`;
}

async function syncUiThemeFromServer() {
  // Sofort das lokal zwischengespeicherte Theme anzeigen (kein Warten auf
  // das Netzwerk nötig, das <head>-Skript hat es ohnehin schon gesetzt),
  // danach mit dem geräteübergreifend gespeicherten Wert abgleichen — falls
  // auf einem anderen Gerät ein anderes Theme gewählt wurde.
  applyUiTheme(localStorage.getItem("ui_theme"));
  const res = await authedFetch("/api/settings/ui_theme");
  const { value } = await res.json();
  if (value) applyUiTheme(value);
}

document.querySelectorAll("#ui-theme-selector [data-ui-theme]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    applyUiTheme(btn.dataset.uiTheme);
    await authedFetch("/api/settings/ui_theme", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: btn.dataset.uiTheme }),
    });
    // Bereits gerenderte Charts nutzen sonst weiter die Farben des vorher
    // aktiven Themes, bis die jeweilige Seite das nächste Mal geladen wird
    // — hier die naheliegendsten, chart-lastigen Ansichten sofort neu
    // zeichnen, damit der Wechsel unmittelbar sichtbar wird.
    loadDashboard();
    if (document.getElementById("tab-vermoegen").style.display !== "none") loadVermoegenOverview();
    if (document.getElementById("tab-contracts").style.display !== "none") loadContracts();
  });
});

function bootApp() {
  loadDashboard();
  loadIncome();
  loadContracts();
  loadReview();
  applyDashboardOrder();
  setupDashboardDragReorder();
  applyBlockOrder("tab-contracts", "ausgaben_order").then(() => setupBlockDragReorder("tab-contracts", "ausgaben_order"));
  applyBlockOrder("tab-income", "einnahmen_order").then(() => setupBlockDragReorder("tab-income", "einnahmen_order"));
  applyBlockOrder("tab-energy-dashboard", "energy_dashboard_order").then(() => setupBlockDragReorder("tab-energy-dashboard", "energy_dashboard_order"));
  applyEnergyMonitorToggle();
  applyVorsorgeToggle();
  applyUiScale();
  syncUiThemeFromServer();
  checkAllUpdatesOnBoot();
}

// ═══════════════════════════════════════════════════════════════
// ENERGY MONITOR
// ═══════════════════════════════════════════════════════════════

async function applyEnergyMonitorToggle() {
  const res = await authedFetch("/api/settings/energy_monitor_enabled");
  const { value } = await res.json();
  const enabled = !!value;
  const display = enabled ? "flex" : "none";
  document.getElementById("energy-section-title").style.display = enabled ? "flex" : "none";
  ["nav-energy-dashboard", "nav-energy-gas", "nav-energy-strom", "nav-energy-water"].forEach((id) => {
    document.getElementById(id).style.display = display;
  });
  // Falls das Modul gerade deaktiviert wurde, während eine Energy-Seite
  // offen war: zurück zum Finanz-Dashboard, statt eine unsichtbar
  // gewordene Seite anzuzeigen.
  const activeEnergyPanel = ["tab-energy-dashboard", "tab-energy-gas", "tab-energy-strom", "tab-energy-water"]
    .find((id) => document.getElementById(id).style.display !== "none");
  if (!enabled && activeEnergyPanel) {
    document.querySelector('.sidebar-btn[data-tab="tab-dashboard"]').click();
  }
}

async function applyVorsorgeToggle() {
  const res = await authedFetch("/api/settings/vorsorge_enabled");
  const { value } = await res.json();
  const enabled = !!value;
  const display = enabled ? "flex" : "none";
  document.getElementById("vorsorge-section-title").style.display = display;
  ["nav-vorsorge-dashboard", "nav-vorsorge-aufbau", "nav-vorsorge-absicherung"].forEach((id) => {
    document.getElementById(id).style.display = display;
  });
  // Wie beim Energy Monitor: bei Deaktivierung während offener Ansicht
  // zurück zum Finanz-Dashboard, statt eine unsichtbar gewordene Seite zu zeigen.
  const activeVorsorgePanel = ["tab-vorsorge-dashboard", "tab-vorsorge-aufbau", "tab-vorsorge-absicherung"]
    .find((id) => document.getElementById(id).style.display !== "none");
  if (!enabled && activeVorsorgePanel) {
    document.querySelector('.sidebar-btn[data-tab="tab-dashboard"]').click();
  }
}

function fmtUnit(value, unit) {
  if (value == null) return "–";
  return `${value.toLocaleString("de-DE", { maximumFractionDigits: 1 })} ${unit}`;
}

// ---------- Energy Monitor: Übersicht ----------
// ---------- Energy Monitor: Zeitraum-Filter (1 Mo / 3 Mo / YTD / Gesamt) ----------
let energyRange = "ytd";

function fmtDE0(v) { return Math.round(v).toLocaleString("de-DE"); }
function fmtDE1(v) { return v.toLocaleString("de-DE", { minimumFractionDigits: 1, maximumFractionDigits: 1 }); }
function fmtDE2(v) { return v.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

async function initEnergyRangeSelector() {
  const el = document.getElementById("energy-range-sel");
  const ranges = CHART_RANGES;
  el.innerHTML = ranges.map((r) =>
    `<button class="range-btn${r.id === energyRange ? " active" : ""}" data-range="${r.id}">${r.label}</button>`
  ).join("");
  el.querySelectorAll(".range-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      energyRange = btn.dataset.range;
      el.querySelectorAll(".range-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      loadEnergyCards();
      loadEnergyTrend();
      loadEnergyCostPie();
    });
  });
}

async function loadEnergyOverview() {
  await initEnergyRangeSelector();
  await loadEnergyCards();
  await loadEnergyTrend();
  await loadEnergyCostPie();
  await loadEnergySettlement();
}

async function loadEnergyCards() {
  const container = document.getElementById("energy-overview-cards");
  const res = await authedFetch(`/api/energy/overview?range=${energyRange}`);
  const d = await res.json();

  const noData = d.gas.daily_rate == null && d.elec_in.daily_rate == null && d.elec_out.daily_rate == null && d.pv.months === 0 && !d.water.has_data;
  if (noData) {
    container.innerHTML = '<p class="muted">Noch keine Zählerstände erfasst — auf den Seiten Gas/Strom die erste Ablesung eintragen.</p>';
    return;
  }

  const cards = [
    { cls: "gas", icon: "🔥", name: `Gas · ${d.gas.anbieter}`, val: `${fmtDE1(d.gas.kwh)} kWh`,
      unit: `${fmtDE1(d.gas.m3)} m<sup>3</sup> · ${fmtDE2(d.gas.kosten)} €`,
      sub: d.gas.daily_rate != null ? `${d.gas.daily_rate.toLocaleString("de-DE")} m<sup>3</sup>/Tag aktuell` : "" },
    { cls: "elec", icon: "⚡", name: `Bezug · ${d.elec_in.anbieter}`, val: `${fmtDE0(d.elec_in.kwh)} kWh`,
      unit: `${fmtDE2(d.elec_in.kosten)} € Kosten`,
      sub: d.elec_in.daily_rate != null ? `${d.elec_in.daily_rate.toFixed(1)} kWh/Tag aktuell` : "" },
    { cls: "feed", icon: "↑", name: `Einspeisung · ${d.elec_out.anbieter}`, val: `${fmtDE0(d.elec_out.kwh)} kWh`,
      unit: `${fmtDE2(d.elec_out.erloes)} € Erlös`,
      sub: d.elec_out.daily_rate != null ? `${d.elec_out.daily_rate.toFixed(1)} kWh/Tag aktuell` : (d.elec_out.source === "pv" ? "iSolarCloud-Daten" : "") },
  ];
  // Wasser nur anzeigen, sobald tatsächlich Ablesungen erfasst sind — sonst
  // würde eine leere/nullige Karte nur verwirren, bevor der Nutzer die
  // Wasser-Seite überhaupt zum ersten Mal befüllt hat.
  if (d.water.has_data) {
    cards.push({ cls: "water", icon: "💧", name: `Wasser${d.water.anbieter ? ` · ${d.water.anbieter}` : ""}`, val: `${fmtDE1(d.water.m3)} m³`,
      unit: `${fmtDE2(d.water.kosten)} € Kosten`,
      sub: d.water.daily_rate != null ? `${d.water.daily_rate.toFixed(2)} m³/Tag aktuell` : "" });
  }

  container.innerHTML = `
    <div class="overview-grid">
      ${cards.map((c) => `
        <div class="ov-card ${c.cls}">
          <div class="ov-icon">${c.icon}</div>
          <div class="ov-name">${c.name}</div>
          <div class="ov-val">${c.val}</div>
          <div class="ov-sub" style="margin-top:2px">${c.unit}</div>
          <div class="ov-sub" style="margin-top:6px">${c.sub}</div>
        </div>
      `).join("")}
    </div>`;
}

// ---------- Kostentrend: SVG-Balken (gemessen/Prognose) + Linie (Gesamt) ----------
async function loadEnergyCostPie() {
  const container = document.getElementById("energy-cost-pie-chart");
  const res = await authedFetch(`/api/energy/overview?range=${energyRange}`);
  const d = await res.json();

  // Netto-Stromkosten (Bezug minus Einspeisungserlös), wie im Kostentrend
  // schon gehandhabt — negative Werte (Erlös übersteigt Bezugskosten)
  // würden im Pie-Chart keinen Sinn ergeben, daher bei 0 gedeckelt.
  const netElec = Math.max(d.elec_in.kosten - d.elec_out.erloes, 0);
  const slices = [
    { category: "Gas", monthly_amount: d.gas.kosten },
    { category: "Strom (netto)", monthly_amount: netElec },
  ];
  if (d.water.has_data) {
    slices.push({ category: "Wasser", monthly_amount: d.water.kosten });
  }
  const total = slices.reduce((s, c) => s + c.monthly_amount, 0);
  if (total <= 0) {
    container.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Kosten im gewählten Zeitraum.</p>';
    return;
  }
  renderPieChart(slices, "energy-cost-pie-chart");
}

async function loadEnergyTrend() {
  const container = document.getElementById("energy-trend-chart");
  const res = await authedFetch(`/api/energy/cost-trend?range=${energyRange}`);
  const { months } = await res.json();
  if (!months.length) {
    container.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Ablesungen für einen Kostentrend.</p>';
    return;
  }

  const W = 720, H = 260, padL = 40, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const hasWater = months.some((m) => m.water_measured > 0 || m.water_forecast > 0);
  const subtitleEl = document.getElementById("energy-trend-subtitle");
  if (subtitleEl) subtitleEl.textContent = hasWater ? "Gas + Strom netto + Wasser · monatlich" : "Gas + Strom netto · monatlich";
  const maxVal = Math.max(...months.map((m) => m.gas_measured + m.gas_forecast + m.elec_measured + m.elec_forecast + m.water_measured + m.water_forecast), 1);
  const minVal = Math.min(0, ...months.map((m) => m.total));
  const range = maxVal - minVal || 1;
  const barW = chartW / months.length;
  const y0 = padT + chartH * (maxVal / range); // y-Position der 0-Linie

  const yScale = (v) => padT + chartH * ((maxVal - v) / range);
  const cp = chartPalette();

  const bars = months.map((m, i) => {
    const x = padL + i * barW + barW * 0.12;
    const w = barW * 0.76;
    let cum = 0;
    const seg = (val, color, label) => {
      if (!val) return "";
      const yTop = yScale(cum + val);
      const yBot = yScale(cum);
      cum += val;
      return `<rect x="${x}" y="${yTop}" width="${w}" height="${Math.max(yBot - yTop, 0)}" fill="${color}"><title>${monthLabel(m.key)} — ${label}: ${fmtDE0(val)} €</title></rect>`;
    };
    return seg(m.gas_measured, cp.purple, "Gas (gemessen)") + seg(m.gas_forecast, hexToRgba(cp.purple, 0.35), "Gas (Prognose)")
         + seg(m.elec_measured, cp.teal, "Strom netto (gemessen)") + seg(m.elec_forecast, hexToRgba(cp.teal, 0.35), "Strom netto (Prognose)")
         + seg(m.water_measured, cp.info, "Wasser (gemessen)") + seg(m.water_forecast, hexToRgba(cp.info, 0.35), "Wasser (Prognose)");
  }).join("");

  const linePoints = months.map((m, i) => {
    const x = padL + i * barW + barW / 2;
    const y = yScale(m.total);
    return `${x},${y}`;
  }).join(" ");

  const dots = months.map((m, i) => {
    const x = padL + i * barW + barW / 2;
    const y = yScale(m.total);
    return `<circle cx="${x}" cy="${y}" r="3" fill="${cp.orange}"><title>${monthLabel(m.key)} — Gesamt: ${fmtDE0(m.total)} €</title></circle>`;
  }).join("");

  const xLabels = months.map((m, i) => {
    const x = padL + i * barW + barW / 2;
    const [y, mo] = m.key.split("-");
    const monthNames = ["", "Jan", "Feb", "Mrz", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
    return `<text x="${x}" y="${H - 6}" text-anchor="middle" font-size="9" fill="var(--muted)">${monthNames[parseInt(mo, 10)]} '${y.slice(2)}</text>`;
  }).join("");

  const gridLines = [0, 0.25, 0.5, 0.75, 1].map((f) => {
    const val = minVal + range * f;
    const y = yScale(val);
    return `<line x1="${padL}" y1="${y}" x2="${W - 10}" y2="${y}" stroke="rgba(255,255,255,0.06)" />
            <text x="${padL - 6}" y="${y + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${Math.round(val).toLocaleString("de-DE")}€</text>`;
  }).join("");

  container.innerHTML = `
    <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:0.7rem;color:var(--muted);margin-bottom:8px">
      <span><span style="display:inline-block;width:8px;height:8px;background:${cp.purple};border-radius:2px;margin-right:4px"></span>Gas gemessen</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${hexToRgba(cp.purple, 0.35)};border-radius:2px;margin-right:4px"></span>Gas Prognose</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${cp.teal};border-radius:2px;margin-right:4px"></span>Strom gemessen</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${hexToRgba(cp.teal, 0.35)};border-radius:2px;margin-right:4px"></span>Strom Prognose</span>
      ${hasWater ? `
      <span><span style="display:inline-block;width:8px;height:8px;background:${cp.info};border-radius:2px;margin-right:4px"></span>Wasser gemessen</span>
      <span><span style="display:inline-block;width:8px;height:8px;background:${hexToRgba(cp.info, 0.35)};border-radius:2px;margin-right:4px"></span>Wasser Prognose</span>` : ""}
      <span><span style="display:inline-block;width:12px;height:2px;background:${cp.orange};margin-right:4px;vertical-align:middle"></span>Gesamt</span>
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block" role="img" aria-label="Kostentrend">
      ${gridLines}
      ${bars}
      <polyline points="${linePoints}" fill="none" stroke="${cp.orange}" stroke-width="2" />
      ${dots}
      ${xLabels}
    </svg>`;
}

// ---------- Jahresabrechnung ----------
async function loadEnergySettlement() {
  const container = document.getElementById("energy-settlement-content");
  const s = await (await authedFetch("/api/energy/settlement")).json();

  function settleRow(icon, label, sub, diff, note, settleLbl, daysUntil) {
    const cls = diff >= 0 ? "settle-ok" : "settle-red";
    return `<div class="settle-row">
      <div style="flex:1;min-width:0">
        <div class="settle-lbl">${icon} ${label}</div>
        <div class="settle-sub">${sub}</div>
        ${note ? `<div class="settle-sub">${note}</div>` : ""}
        <div class="settle-sub" style="font-style:italic">Abrechnung: ${settleLbl}${daysUntil != null ? ` (in ${daysUntil} Tagen)` : ""}</div>
      </div>
      <div class="settle-val ${cls}">${diff >= 0 ? "+" : ""}${Math.round(diff).toLocaleString("de-DE")} €</div>
    </div>`;
  }

  const fmtDate = (iso) => new Date(iso).toLocaleDateString("de-DE", { day: "numeric", month: "long", year: "numeric" });

  container.innerHTML = `
    <div class="settle-lbl" style="font-size:1rem;margin-bottom:8px">⚖️ Jahresabrechnung ${s.year}</div>

    ${settleRow("🔥", "Gas", `${fmtDE0(s.gas.abschlaege)} € gezahlt — ${fmtDE0(s.gas.jahr_kosten)} € progn. Jahreskosten`,
      s.gas.diff, "", fmtDate(s.gas.settle_date), s.gas.days_until_settle)}

    ${settleRow("⚡", "Strombezug", `${fmtDE0(s.elec_in.abschlaege)} € gezahlt — ${fmtDE0(s.elec_in.jahr_kosten)} € progn. Jahreskosten`,
      s.elec_in.diff, `${fmtDE0(s.elec_in.monthly_cost)} €/Mo tatsächl. Bezugskosten`, fmtDate(s.elec_in.settle_date), s.elec_in.days_until_settle)}

    ${s.water.has_data ? settleRow("💧", "Wasser", `${fmtDE0(s.water.abschlaege)} € gezahlt — ${fmtDE0(s.water.jahr_kosten)} € progn. Jahreskosten`,
      s.water.diff, "", fmtDate(s.water.settle_date), s.water.days_until_settle) : ""}

    <div class="settle-row" style="flex-direction:column;align-items:stretch;gap:8px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">
        <div style="flex:1;min-width:0">
          <div class="settle-lbl">☀️ Einspeisung</div>
          <div class="settle-sub">${fmtDE0(s.elec_out.bezahlt)} € erhalten (${s.elec_out.m_seit_januar}× ${fmtDE0(s.elec_out.abschlag)} €/Mo) — ${fmtDE0(s.elec_out.jahr_erloes)} € progn. Jahresvergütung</div>
          <div class="settle-sub" style="font-style:italic">Abrechnung: ${fmtDate(s.elec_out.settle_date)} (in ${s.elec_out.days_until_settle} Tagen)</div>
        </div>
        <div class="settle-val ${s.elec_out.diff >= 0 ? "settle-ok" : "settle-red"}">${s.elec_out.diff >= 0 ? "+" : ""}${Math.round(s.elec_out.diff).toLocaleString("de-DE")} €</div>
      </div>
      <div class="pv-breakdown-grid">
        <div>
          <div class="pv-bd-label">Gemessen (${s.elec_out.gemessene_monate} Mo.)</div>
          <div class="pv-bd-val" style="color:var(--good)">${fmtDE0(s.elec_out.bisher_kwh)} kWh</div>
          <div class="ov-sub">${fmtDE0(s.elec_out.erloes_bisher)} € Erlös bisher</div>
        </div>
        <div>
          <div class="pv-bd-label">Prognose (${s.elec_out.prognose_monate} Mo. · Vorjahr)</div>
          <div class="pv-bd-val" style="color:var(--warn)">${fmtDE0(s.elec_out.prognose_kwh)} kWh</div>
          <div class="ov-sub">${s.elec_out.laufender_monat_label || ""}</div>
        </div>
        <div>
          <div class="pv-bd-label">Jahresgesamt</div>
          <div class="pv-bd-val">${fmtDE0(s.elec_out.jahr_gesamt_kwh)} kWh</div>
          <div class="ov-sub">${fmtDE0(s.elec_out.jahres_abschlaege)} € erhalten vs. ${fmtDE0(s.elec_out.jahr_erloes)} € erwartet</div>
        </div>
      </div>
    </div>

    <div class="settle-row" style="border-top:1px solid rgba(255,255,255,0.12);padding-top:14px">
      <div>
        <div class="settle-lbl" style="font-size:1.05rem">Gesamt ${s.year}</div>
        <div class="settle-sub">Gas + Bezug${s.water.has_data ? " + Wasser" : ""} − Einspeisungserlös</div>
      </div>
      <div class="settle-val ${s.total_diff >= 0 ? "settle-ok" : "settle-red"}" style="font-size:1.4rem">${s.total_diff >= 0 ? "+" : ""}${Math.round(s.total_diff).toLocaleString("de-DE")} €</div>
    </div>`;
}


// ---------- Energy Monitor: Zähler-Detailseite (Gas / Strombezug / Einspeisung) ----------
// ---------- Zeitraum-Filterung (clientseitig, pro Chart unabhängig) ----------
const meterChartRange = {};

// Startdatum eines Zeitraums — spiegelt range_start_date() im Backend.
function rangeStartDate(rangeId) {
  if (rangeId === "all" || !rangeId) return null;
  const today = new Date();
  if (rangeId === "ytd") return new Date(today.getFullYear(), 0, 1);
  const monthsBack = { "1m": 1, "3m": 3, "12m": 12 }[rangeId];
  if (monthsBack === undefined) return null;
  return rangeId === "12m"
    ? new Date(today.getFullYear(), today.getMonth() - 12, 1)
    : new Date(today.getFullYear(), today.getMonth() - monthsBack, today.getDate());
}

// Versteht alle drei Schlüsselformate: Tag "2026-07-15", Woche "2026-W29",
// Monat "2026-07" — damit greift dieselbe Funktion unabhängig davon, wie fein
// der jeweilige Chart gerade aufgelöst ist.
function filterPeriodKeysByRange(keys, rangeId) {
  if (rangeId === "all" || !rangeId) return keys.slice().sort();
  const cutoff = rangeStartDate(rangeId);
  if (!cutoff) return keys.slice().sort();
  const today = new Date();
  return keys.filter((k) => {
    const [y, m] = k.split("-").map(Number);
    const monthStart = new Date(y, m - 1, 1);
    // Der ganze Monat zählt, wenn sein ENDE nach dem Stichtag liegt — sonst
    // fiele z.B. der laufende Monat bei "1 Mo" heraus.
    const monthEnd = new Date(y, m, 0);
    // Zukunft (Prognosewerte) bei kurzen Zeiträumen ausblenden.
    const noFuture = rangeId === "ytd" || monthStart <= today;
    return monthEnd >= cutoff && noFuture;
  }).sort();
}

// Alter Name bleibt als Hülle bestehen, damit vorhandene Aufrufer unverändert
// weiterlaufen.
function filterMonthKeysByRange(keys, rangeId) {
  return filterPeriodKeysByRange(keys, rangeId);
}

function filterIntervalsByRange(intervals, rangeId) {
  if (rangeId === "all") return intervals;
  const cutoff = rangeStartDate(rangeId);
  if (!cutoff) return intervals;
  return intervals.filter((iv) => new Date(iv.reading_date) >= cutoff);
}

function renderChartRangeSelector(stateKey, containerId, defaultRange, onChange) {
  meterChartRange[stateKey] = meterChartRange[stateKey] || defaultRange;
  const el = document.getElementById(containerId);
  const ranges = CHART_RANGES;
  el.innerHTML = ranges.map((r) =>
    `<button class="range-btn${r.id === meterChartRange[stateKey] ? " active" : ""}" data-range="${r.id}">${r.label}</button>`
  ).join("");
  el.querySelectorAll(".range-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      meterChartRange[stateKey] = btn.dataset.range;
      el.querySelectorAll(".range-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      onChange(btn.dataset.range);
    });
  });
  return meterChartRange[stateKey];
}

// ---------- Wiederverwendbare Dokument-Liste: Scroll-Container ab ~10
// Zeilen statt unbegrenzter Höhe, plus Jahres-Filter bei mehreren Jahren.
// Verhindert, dass eine Liste mit vielen Einträgen (z.B. nach einem
// Sammel-Import) den Dialog so hoch macht, dass die Buttons unerreichbar
// aus dem Fenster laufen. ----------
// ---------- Zeilen-Menü-Button: sichtbare Alternative zum Rechtsklick.
// Auf iOS gibt es als PWA kein Rechtsklick und Long-Press ist unzuverlässig/
// nicht entdeckbar — ein fest sichtbarer "⋯"-Button funktioniert dagegen auf
// Maus UND Touch gleichermaßen und öffnet dasselbe Kontextmenü an derselben
// Stelle. Rechtsklick bleibt für Maus-Nutzer zusätzlich erhalten. ----------
function rowMenuButtonHTML(dataAttr, id) {
  return `<button type="button" class="row-menu-btn" data-row-menu-trigger="${dataAttr}" data-row-menu-id="${id}" title="Menü" aria-label="Menü öffnen">⋯</button>`;
}

function wireRowMenuButtons(container, dataAttr, onOpen) {
  container.querySelectorAll(`[data-row-menu-trigger="${dataAttr}"]`).forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const rect = btn.getBoundingClientRect();
      onOpen(btn.dataset.rowMenuId, rect.left, rect.bottom + 4);
    });
  });
}

function setupScrollableDocList(containerId, items, dateExtractor, renderListCallback) {
  const container = document.getElementById(containerId);
  // Neuester Beleg immer ganz oben — zentral hier sortiert, damit das
  // konsistent für alle Beleg-Listen gilt (Gehaltsabrechnungen, Renten-
  // dokumente, Verträge, Archiv), die diese gemeinsame Funktion nutzen.
  // Einträge ohne erkennbares Datum rutschen ans Ende statt die Reihenfolge
  // der übrigen, datierten Einträge zu verfälschen.
  items = [...items].sort((a, b) => {
    const da = dateExtractor(a) || "";
    const db = dateExtractor(b) || "";
    if (!da && !db) return 0;
    if (!da) return 1;
    if (!db) return -1;
    return db < da ? -1 : db > da ? 1 : 0;
  });
  const years = [...new Set(items.map(dateExtractor).filter(Boolean).map((d) => String(d).slice(0, 4)))].sort().reverse();
  let selectedYear = "all";

  const filterHtml = years.length > 1 ? `
    <div class="doc-list-filter">
      <label class="muted" style="font-size:0.75rem">Jahr:</label>
      <select id="${containerId}-year-filter">
        <option value="all">Alle (${items.length})</option>
        ${years.map((y) => `<option value="${y}">${y} (${items.filter((i) => String(dateExtractor(i) || "").slice(0, 4) === y).length})</option>`).join("")}
      </select>
    </div>` : "";

  container.innerHTML = `${filterHtml}<div class="doc-list-scroll"><ul id="${containerId}-ul" style="margin:0"></ul></div>`;

  function doRender() {
    const filtered = selectedYear === "all" ? items : items.filter((i) => String(dateExtractor(i) || "").slice(0, 4) === selectedYear);
    renderListCallback(filtered, document.getElementById(`${containerId}-ul`));
  }

  const yearSelect = document.getElementById(`${containerId}-year-filter`);
  if (yearSelect) {
    yearSelect.addEventListener("change", () => {
      selectedYear = yearSelect.value;
      doRender();
    });
  }
  doRender();
}

const MONTH_NAMES = ["", "Jan", "Feb", "Mrz", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
// ---------- Datum für Beleg-Anzeige ermitteln: Dateiname zuerst (z.B.
// "15.10.2025 Depotauszug per 30.09.2025.pdf" trägt ein weit aussage-
// kräftigeres Datum als das reine Scan-/Upload-Datum), dann ein per OCR
// erkanntes Datum aus dem Dokumentinhalt, erst ganz zuletzt das
// Scan-Datum als Rückfall, falls gar nichts anderes zu finden ist. ----------
function extractDateFromFilename(filename) {
  if (!filename) return null;
  // Deutsches Format TT.MM.JJJJ (auch mit - oder _ statt .)
  let m = filename.match(/\b(\d{1,2})[.\-_](\d{1,2})[.\-_](\d{4})\b/);
  if (m) {
    const [, d, mo, y] = m;
    if (+mo >= 1 && +mo <= 12 && +d >= 1 && +d <= 31) {
      return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
    }
  }
  // ISO-Format JJJJ-MM-TT im Dateinamen
  m = filename.match(/\b(\d{4})[.\-_](\d{1,2})[.\-_](\d{1,2})\b/);
  if (m) {
    const [, y, mo, d] = m;
    if (+mo >= 1 && +mo <= 12 && +d >= 1 && +d <= 31) {
      return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
    }
  }
  return null;
}

function resolveDocDate(item) {
  return extractDateFromFilename(item.original_filename)
    || item.detected_date
    || (item.uploaded_at || "").slice(0, 10)
    || null;
}

function formatPayslipMonth(key) {
  const [y, m] = key.split("-");
  const idx = parseInt(m, 10);
  return idx >= 1 && idx <= 12 ? `${MONTH_NAMES[idx]} ${y}` : key;
}
// Y-Achsen-Zahl: bei kleinen Wertebereichen (z.B. 1,7 m³ pro Tag) würde
// reines Runden "1, 1, 0" ergeben — dann eine Nachkommastelle zeigen.
function axisNumber(value, maxVal) {
  if (maxVal < 10) return value.toFixed(1).replace(".", ",");
  return String(Math.round(value));
}

// Beschriftet Monats-, Wochen- UND Tagesschlüssel korrekt — ohne das würde
// z.B. "2026-09-07" als "Sep '20" beschriftet (Jahr aus dem falschen Teil).
function monthLabel(key) {
  const [y, m] = key.split("-");
  return `${MONTH_NAMES[parseInt(m, 10)]} '${y.slice(2)}`;
}

// Kurzform für die X-Achse bei feiner Auflösung: bei Tagen reicht die reine
// Tageszahl, der Monat wird nur beim Monatswechsel (und am ersten Punkt)
// dazugeschrieben — sonst steht auf jedem Balken redundant derselbe Monat.
function axisLabel(key) {
  return monthLabel(key);
}

// Zeichnet die X-Achsen-Beschriftung und DÜNNT SIE AUS, wenn zu wenig Platz
// ist. Ohne das überlappen sich bei Tagesauflösung (30+ Balken) die Texte zu
// unlesbarem Matsch. Es wird immer der erste und letzte Punkt beschriftet,
// dazwischen in gleichmäßigen Abständen.
function renderXAxisLabels(keys, padL, barW, y, minSpacingPx = 34) {
  const step = Math.max(1, Math.ceil(minSpacingPx / Math.max(barW, 1)));
  return keys.map((k, i) => {
    const isLast = i === keys.length - 1;
    if (i % step !== 0 && !isLast) return "";
    // Ganz am Ende nicht zeichnen, wenn es mit dem vorletzten kollidieren würde.
    if (isLast && keys.length > 1 && (keys.length - 1) % step !== 0 && step > 1
        && (keys.length - 1 - Math.floor((keys.length - 1) / step) * step) * barW < minSpacingPx) return "";
    return `<text x="${padL + i * barW + barW / 2}" y="${y}" text-anchor="middle" font-size="8" fill="var(--muted)">${axisLabel(k)}</text>`;
  }).join("");
}

// ---------- Hauptchart: Balken (gemessen/Prognose) + optionale PV-Linie ----------
function renderMeterMainChart(containerId, monthly, forecast, unit, temps) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  // Ist-Werte UND Prognose zusammenführen: Die Prognose füllt nur fehlende
  // KALENDERmonate und ist bei Tages-/Wochenauflösung leer — ohne das
  // Zusammenführen bliebe der Chart dort komplett leer.
  const values = { ...monthly, ...forecast };
  const months = filterPeriodKeysByRange(Object.keys(values), meterChartRange[stateKey] || "ytd");
  if (!months.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Ablesungen.</p>'; return; }

  const W = 700, H = 220, padL = 42, padR = temps ? 32 : 10, padB = 26, padT = 10;
  const barVals = months.map((m) => values[m] || 0);
  const maxVal = Math.max(...barVals, 1);
  const chartW = W - padL - padR, chartH = H - padT - padB;
  const barW = chartW / months.length;
  const yScale = (v) => padT + chartH * (1 - v / maxVal);
  const cp = chartPalette();

  const bars = months.map((m, i) => {
    // Prognose nur dort, wo tatsächlich eine vorliegt. Bei Tages-/Wochen-
    // auflösung ist 'forecast' leer -- ohne diese Prüfung gälten dann ALLE
    // Balken fälschlich als Prognose und würden blass gezeichnet.
    const isForecast = !(m in monthly) && (m in forecast);
    const h = Math.max((barVals[i] / maxVal) * chartH, 1);
    const x = padL + i * barW + barW * 0.15;
    const w = barW * 0.7;
    return `<rect x="${x}" y="${padT + chartH - h}" width="${w}" height="${h}" rx="2" fill="${isForecast ? hexToRgba(cp.purple, 0.28) : cp.purple}"><title>${monthLabel(m)}: ${fmtDE1(barVals[i])} ${unit}${isForecast ? " (Prognose)" : ""}</title></rect>`;
  }).join("");

  const xLabels = renderXAxisLabels(months, padL, barW, H - 6);
  const yLabels = [0, 0.5, 1].map((f) => `<text x="${padL - 6}" y="${padT + chartH * (1 - f) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${axisNumber(maxVal * f, maxVal)}</text>`).join("");

  let tempLayer = "";
  if (temps) {
    // Skala aus den TATSÄCHLICH vorkommenden Werten ableiten statt fest
    // -5..25°C zu verdrahten -- sonst schneidet die Linie bei jedem Wert
    // außerhalb dieses Bereichs ab (z.B. ein heißer Sommertag über 25°C,
    // in Freiburg keine Seltenheit). Etwas Rand oben/unten, damit Punkte
    // nicht direkt am Kartenrand kleben.
    const allTempVals = [
      ...Object.values(temps.dwd_climate_avg || {}),
      ...months.map((m) => temps.actual[m]).filter((v) => v != null),
    ];
    const rawMin = allTempVals.length ? Math.min(...allTempVals) : -5;
    const rawMax = allTempVals.length ? Math.max(...allTempVals) : 25;
    const span = Math.max(rawMax - rawMin, 1);
    const tMin = Math.floor((rawMin - span * 0.1) / 5) * 5;
    const tMax = Math.ceil((rawMax + span * 0.1) / 5) * 5;
    const tScale = (t) => padT + chartH * (1 - (t - tMin) / (tMax - tMin));
    const xOf = (i) => padL + i * barW + barW / 2;
    const climPts = months.map((m, i) => {
      const mo = parseInt(m.split("-")[1], 10);
      const t = temps.dwd_climate_avg[String(mo)];
      return t != null ? `${xOf(i)},${tScale(t)}` : null;
    }).filter(Boolean).join(" ");
    const actualPts = months.map((m, i) => temps.actual[m] != null ? `${xOf(i)},${tScale(temps.actual[m])}` : null).filter(Boolean).join(" ");
    const actualDots = months.map((m, i) => {
      const t = temps.actual[m];
      if (t == null) return "";
      return `<circle cx="${xOf(i)}" cy="${tScale(t)}" r="3" fill="${cp.orange}"><title>${monthLabel(m)}: ${t.toFixed(1)}°C (Ist)</title></circle>`;
    }).join("");
    const tempYLabels = [tMin, (tMin + tMax) / 2, tMax].map((t) =>
      `<text x="${W - padR + 6}" y="${tScale(t) + 3}" text-anchor="start" font-size="8" fill="${cp.orange}">${Math.round(t)}°</text>`
    ).join("");
    tempLayer = `
      ${climPts ? `<polyline points="${climPts}" fill="none" stroke="${cp.neutral}" stroke-width="1.5" stroke-dasharray="4,3" />` : ""}
      ${actualPts ? `<polyline points="${actualPts}" fill="none" stroke="${cp.orange}" stroke-width="2" />` : ""}
      ${actualDots}
      ${tempYLabels}`;
  }

  el.innerHTML = `
    ${temps ? `<div style="font-size:0.7rem;color:var(--muted);margin-bottom:6px">
      <span style="display:inline-block;width:8px;height:8px;background:${cp.purple};border-radius:2px;margin-right:4px"></span>${unit === "m³" ? "Verbrauch" : "Wert"}
      &nbsp; <span style="display:inline-block;width:12px;height:2px;background:${cp.orange};margin-right:4px;vertical-align:middle"></span>Temperatur (Ist)
      &nbsp; <span style="display:inline-block;width:12px;height:2px;background:${cp.neutral};border-top:2px dashed;margin-right:4px;vertical-align:middle"></span>Klimamittel
    </div>` : ""}
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${yLabels}${bars}${tempLayer}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Helle Balken = Prognose (keine echte Ablesung in dem Monat) · Zahlen bei Mouse-over</p>`;
}

// ---------- Gestapelter Balkenchart: mehrere Komponenten je Monat (z.B.
// Eigenverbrauch + Netzbezug = Gesamtverbrauch, oder Eigenverbrauch +
// Einspeisung = PV-Ertrag) ----------
function renderStackedBarChart(containerId, months, series, unit) {
  const el = document.getElementById(containerId);
  if (!months.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Daten.</p>'; return; }

  const W = 700, H = 230, padL = 42, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const totals = months.map((m) => series.reduce((s, sr) => s + (m.values[sr.key] || 0), 0));
  const maxVal = Math.max(...totals, 1);
  const barW = chartW / months.length;
  const yScale = (v) => padT + chartH * (1 - v / maxVal);

  const bars = months.map((m, i) => {
    const x = padL + i * barW + barW * 0.15;
    const w = barW * 0.7;
    let cum = 0;
    return series.map((sr) => {
      const val = m.values[sr.key] || 0;
      const yTop = yScale(cum + val);
      const yBot = yScale(cum);
      cum += val;
      if (val <= 0) return "";
      return `<rect x="${x}" y="${yTop}" width="${w}" height="${Math.max(yBot - yTop, 1)}" fill="${sr.color}"><title>${monthLabel(m.key)} — ${sr.label}: ${fmtDE1(val)} ${unit}</title></rect>`;
    }).join("");
  }).join("");

  const xLabels = renderXAxisLabels(months.map((m) => m.key), padL, barW, H - 6);
  const yLabels = [0, 0.5, 1].map((f) => `<text x="${padL - 6}" y="${padT + chartH * (1 - f) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${axisNumber(maxVal * f, maxVal)}</text>`).join("");

  el.innerHTML = `
    <div style="font-size:0.7rem;color:var(--muted);margin-bottom:6px">
      ${series.map((sr) => `<span style="display:inline-block;width:8px;height:8px;background:${sr.color};border-radius:2px;margin-right:4px"></span>${sr.label}`).join(" &nbsp; ")}
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${yLabels}${bars}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Zahlen bei Mouse-over</p>`;
}

// ---------- Tagesverbrauch je Ableseintervall (nur Gas) ----------
function renderDailyRateChart(containerId, intervals, currentRate, unit) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  let ivals = intervals.filter((iv) => iv.rate != null);
  ivals = filterIntervalsByRange(ivals, meterChartRange[stateKey] || "ytd");
  // Bewusst KEINE feste Obergrenze mehr: Bei "Gesamt" sollen auch ältere
  // Ablesungen sichtbar sein. Die Achsenbeschriftung dünnt sich bei vielen
  // Einträgen ohnehin selbst aus, und wer weniger sehen will, wählt einen
  // kürzeren Zeitraum.
  if (!ivals.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Ablesungen.</p>'; return; }

  const W = 700, H = 180, padL = 36, padB = 34, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const maxVal = Math.max(...ivals.map((iv) => iv.rate), currentRate || 0, 0.1);
  const barW = chartW / ivals.length;
  const yScale = (v) => padT + chartH * (1 - v / maxVal);
  const cpRate = chartPalette();

  const bars = ivals.map((iv, i) => {
    const h = Math.max((iv.rate / maxVal) * chartH, 1);
    const x = padL + i * barW + barW * 0.15;
    return `<rect x="${x}" y="${padT + chartH - h}" width="${barW * 0.7}" height="${h}" rx="2" fill="${cpRate.purple}"><title>${iv.reading_date}: ${iv.rate.toFixed(2)} ${unit}/Tag</title></rect>`;
  }).join("");

  const refY = currentRate ? yScale(currentRate) : null;
  const refLine = refY != null ? `<line x1="${padL}" y1="${refY}" x2="${W - 10}" y2="${refY}" stroke="${cpRate.orange}" stroke-width="2" stroke-dasharray="5,3"><title>Aktuelle Tagesrate: ${currentRate.toFixed(2)} ${unit}/Tag</title></line>` : "";

  // Auch hier ausdünnen: Ohne die frühere 20er-Begrenzung können deutlich
  // mehr Balken auftreten. Gedrehte Beschriftungen brauchen weniger Abstand
  // als waagerechte, daher ein kleinerer Mindestabstand.
  const labelStep = Math.max(1, Math.ceil(16 / Math.max(barW, 1)));
  const xLabels = ivals.map((iv, i) => {
    if (i % labelStep !== 0 && i !== ivals.length - 1) return "";
    const d = new Date(iv.reading_date);
    const lbl = `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")}`;
    return `<text x="${padL + i * barW + barW / 2}" y="${H - 8}" text-anchor="middle" font-size="7" fill="var(--muted)" transform="rotate(45 ${padL + i * barW + barW / 2} ${H - 8})">${lbl}</text>`;
  }).join("");

  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${bars}${refLine}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Gestrichelte Linie = aktuelle Tagesrate (${currentRate != null ? currentRate.toFixed(2) : "–"} ${unit}/Tag) · Zahlen bei Mouse-over</p>`;
}


// ---------- Kumulativ-Chart: Ist-Kosten vs. Abschlag vs. optimaler Abschlag ----------
function renderCumulativeChart(containerId, months) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  const filtered = months.filter((m) => filterMonthKeysByRange([m.key], meterChartRange[stateKey] || "ytd").length);
  const use = filtered.length ? filtered : months;
  if (!use.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch nicht genug Daten.</p>'; return; }

  const W = 700, H = 200, padL = 44, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const maxVal = Math.max(...use.flatMap((m) => [m.cost, m.abschlag, m.opt_abschlag]), 1);
  const stepX = chartW / (use.length - 1 || 1);
  const yScale = (v) => padT + chartH * (1 - v / maxVal);
  const cpCum = chartPalette();

  const line = (key, color, dash) => {
    const pts = use.map((m, i) => `${padL + i * stepX},${yScale(m[key])}`).join(" ");
    return `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" ${dash ? `stroke-dasharray="${dash}"` : ""} />`;
  };
  const dots = (key, color, label) => use.map((m, i) =>
    `<circle cx="${padL + i * stepX}" cy="${yScale(m[key])}" r="3" fill="${color}"><title>${monthLabel(m.key)} — ${label}: ${fmtDE0(m[key])} €</title></circle>`
  ).join("");

  const xLabels = renderXAxisLabels(use.map((m) => m.key), padL - stepX / 2, stepX, H - 6);
  const yLabels = [0, 0.5, 1].map((f) => `<text x="${padL - 6}" y="${padT + chartH * (1 - f) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${Math.round(maxVal * f).toLocaleString("de-DE")}€</text>`).join("");

  el.innerHTML = `
    <div style="font-size:0.7rem;color:var(--muted);margin-bottom:6px">
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.orange};margin-right:4px;vertical-align:middle"></span>Ist-Kosten
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.purple};border-top:2px dashed;margin:0 4px 0 12px;vertical-align:middle"></span>Abschlag
      <span style="display:inline-block;width:12px;height:2px;background:${cpCum.teal};margin:0 4px 0 12px;vertical-align:middle"></span>Optimaler Abschlag
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">${yLabels}${line("abschlag", cpCum.purple, "6,3")}${line("opt_abschlag", cpCum.teal, "3,3")}${line("cost", cpCum.orange)}${dots("abschlag", cpCum.purple, "Abschlag")}${dots("opt_abschlag", cpCum.teal, "Optimaler Abschlag")}${dots("cost", cpCum.orange, "Ist-Kosten")}${xLabels}</svg>
    <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Zahlen bei Mouse-over</p>`;
}

// ---------- Autarkie-Chart (nur Einspeisung/PV) ----------
function renderAutarkieChart(containerId, months) {
  const el = document.getElementById(containerId);
  const stateKey = containerId.replace(/-chart$/, "");
  const filtered = months.filter((m) => filterMonthKeysByRange([m.key], meterChartRange[stateKey] || "ytd").length);
  const use = filtered.length ? filtered : months;
  if (!use.length) { el.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine PV-Daten importiert.</p>'; return; }

  const W = 700, H = 200, padL = 32, padB = 26, padT = 10;
  const chartW = W - padL - 10, chartH = H - padT - padB;
  const stepX = chartW / (use.length - 1 || 1);

  // Skala an die tatsächliche Datenspanne anpassen (mit etwas Puffer), statt
  // immer starr 0–100% zu zeigen — sonst sind z.B. 90–98% optisch kaum von
  // 100% zu unterscheiden, obwohl es ein echter Unterschied ist.
  const values = use.map((m) => m.autarkie);
  const dataMin = Math.min(...values), dataMax = Math.max(...values);
  const yMin = Math.max(0, Math.floor((dataMin - 8) / 10) * 10);
  const yMax = Math.min(100, Math.ceil((dataMax + 8) / 10) * 10);
  const yRange = (yMax - yMin) || 1;
  const yScale = (v) => padT + chartH * (1 - (v - yMin) / yRange);
  const cpAut = chartPalette();

  const pts = use.map((m, i) => `${padL + i * stepX},${yScale(m.autarkie)}`).join(" ");
  const dots = use.map((m, i) => {
    const color = m.autarkie >= 90 ? cpAut.teal : m.autarkie >= 70 ? cpAut.orange : cpAut.purple;
    return `<circle cx="${padL + i * stepX}" cy="${yScale(m.autarkie)}" r="3.5" fill="${color}"><title>${monthLabel(m.key)}: ${m.autarkie}% autark</title></circle>`;
  }).join("");
  const xLabels = renderXAxisLabels(use.map((m) => m.key), padL - stepX / 2, stepX, H - 6);
  const yTicks = [yMin, Math.round((yMin + yMax) / 2), yMax];
  const yLabels = yTicks.map((v) => `<text x="${padL - 6}" y="${yScale(v) + 3}" text-anchor="end" font-size="8" fill="var(--muted)">${v}%</text>`).join("");

  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
    ${yLabels}
    <polyline points="${pts}" fill="none" stroke="${cpAut.teal}" stroke-width="2.5" />
    <polygon points="${padL},${yScale(yMin)} ${pts} ${padL + (use.length - 1) * stepX},${yScale(yMin)}" fill="${hexToRgba(cpAut.teal, 0.08)}" />
    ${dots}${xLabels}
  </svg>
  <p class="muted" style="font-size:0.7rem;margin:4px 0 0">Skala ${yMin}–${yMax}% (an Datenspanne angepasst) · Zahlen bei Mouse-over</p>`;
}

async function loadMeterPage(meterType, containerId, title) {
  const container = document.getElementById(containerId);
  container.innerHTML = '<p class="muted">Lade …</p>';
  const unit = meterType === "gas" || meterType === "water" ? "m³" : "kWh";
  const isEinspeisung = meterType === "elec_out";
  const isElecIn = meterType === "elec_in";

  const [readingsRes, monthlyRes, settingsRes, kpisRes, intervalsRes] = await Promise.all([
    authedFetch(`/api/meters/${meterType}/readings`),
    authedFetch(`/api/meters/${meterType}/monthly`),
    authedFetch(`/api/meters/${meterType}/settings`),
    authedFetch(`/api/meters/${meterType}/kpis`),
    authedFetch(`/api/meters/${meterType}/intervals`),
  ]);
  const { readings } = await readingsRes.json();
  const { monthly, forecast } = await monthlyRes.json();
  const settings_ = await settingsRes.json();
  const { chips } = await kpisRes.json();
  const { intervals } = await intervalsRes.json();

  let pvMonthly = [];
  if (isElecIn || isEinspeisung) {
    pvMonthly = (await (await authedFetch("/api/pv/monthly")).json()).months;
  }
  let autarkieMonths = [];
  if (isEinspeisung) {
    autarkieMonths = (await (await authedFetch("/api/pv/autarkie")).json()).months;
  }
  let cumMonths = [];
  if (!isEinspeisung) {
    cumMonths = (await (await authedFetch(`/api/meters/${meterType}/cumulative`)).json()).months;
  }

  const contractBadge = settings_.anbieter ? `
    <div class="contract-badge">
      <span>${title.split(" ")[0]} <strong>${settings_.anbieter}</strong></span>
      ${!isEinspeisung ? `<span class="muted">${(settings_.arbeitspreis || 0).toFixed(4)} €/${unit} · ${(settings_.grundpreis || 0).toFixed(2)} €/Mo</span>` : `<span class="muted">${(settings_.einspeisepreis || 0).toFixed(4)} €/kWh</span>`}
    </div>` : "";

  const chipsHtml = `
    <div class="kpi-chip-row">
      ${chips.map((c) => `
        <div class="kpi-chip">
          <div class="kpi-chip-lbl">${c.label}</div>
          <div class="kpi-chip-val${c.status ? ` ${c.status === "ok" ? "settle-ok" : "settle-red"}` : ""}">${c.value}</div>
          <div class="kpi-chip-sub">${c.sub}</div>
        </div>`).join("")}
    </div>`;

  container.innerHTML = `
    <section class="card">
      <h2>${title}</h2>
      ${contractBadge}
      ${chipsHtml}
    </section>

    <section class="card">
      <h3 style="margin:0 0 10px;font-size:0.95rem;color:var(--accent)">Tarif &amp; Abschlag</h3>
      <form id="${containerId}-settings-form">
        <label class="muted" style="font-size:0.8rem">Anbieter</label>
        <input type="text" id="${containerId}-s-anbieter" value="${settings_.anbieter || ""}" />

        ${!isEinspeisung ? `
          <label class="muted" style="font-size:0.8rem">Vertragsablauf (optional)</label>
          <input type="date" id="${containerId}-s-vertragsende" value="${settings_.vertragsende || ""}" />
        ` : ""}

        <label class="muted" style="font-size:0.8rem">Monatlicher Abschlag (€)</label>
        <input type="text" id="${containerId}-s-abschlag" inputmode="decimal" value="${settings_.abschlag || 0}" />

        ${isEinspeisung ? `
          <label class="muted" style="font-size:0.8rem">Einspeisevergütung (€/kWh)</label>
          <input type="text" id="${containerId}-s-einspeisepreis" inputmode="decimal" value="${settings_.einspeisepreis || 0}" />
        ` : `
          <label class="muted" style="font-size:0.8rem">Arbeitspreis (€/${unit})</label>
          <input type="text" id="${containerId}-s-arbeitspreis" inputmode="decimal" value="${settings_.arbeitspreis || 0}" />

          <label class="muted" style="font-size:0.8rem">Grundpreis (€/Monat)</label>
          <input type="text" id="${containerId}-s-grundpreis" inputmode="decimal" value="${settings_.grundpreis || 0}" />

          ${meterType === "water" ? `
            <label class="muted" style="font-size:0.8rem">Entwässerung / Schmutzwasser (€/${unit})</label>
            <input type="text" id="${containerId}-s-entwaesserung" inputmode="decimal" value="${settings_.entwaesserung_preis || 0}" />
            <p class="muted" style="font-size:0.72rem;margin:2px 0 0">Wird zum Trinkwasserpreis addiert — die Kosten basieren auf demselben verbrauchten Kubikmeter, es gibt in der Regel keinen eigenen Abwasserzähler.</p>
          ` : ""}

          ${meterType === "gas" ? `
            <label class="muted" style="font-size:0.8rem">Brennwert (kWh/m³)</label>
            <input type="text" id="${containerId}-s-brennwert" inputmode="decimal" value="${settings_.brennwert || 10}" />
          ` : ""}
        `}

        <button type="submit" style="margin-top:12px">Speichern</button>
      </form>
    </section>

    <section class="card">
      <h3 style="margin:0 0 4px;font-size:0.95rem;color:var(--accent)">📅 Abrechnungszeitpunkte</h3>
      <p class="muted" style="margin:0 0 10px;font-size:0.75rem">Wann eine echte Abrechnung eingegangen ist — dient als Reset-Basis für "Verbrauch seit der Abrechnung", unabhängig vom Kalenderjahr.</p>
      <div id="${containerId}-settlement-since"></div>
      <div class="row-actions" style="margin-top:10px">
        <input type="date" id="${containerId}-settlement-date" style="flex:1" />
        <input type="text" id="${containerId}-settlement-note" placeholder="Notiz (optional)" style="flex:1" />
      </div>
      <button type="button" id="${containerId}-settlement-add-btn" class="ghost-btn" style="width:100%;margin-top:8px">+ Abrechnungszeitpunkt erfassen</button>
      <div id="${containerId}-settlement-list" style="margin-top:10px"></div>
    </section>

    ${meterType === "gas" ? `
    <section class="card">
      <h3 style="margin:0 0 4px;font-size:0.95rem;color:var(--accent)">🌡️ Wetter-Standort</h3>
      <p class="muted" style="margin:0 0 10px;font-size:0.75rem">Für die "Temperatur (Ist)"-Linie im Chart unten — wird automatisch beim Start der App aktualisiert (höchstens einmal pro Tag). Ohne Standort bleibt nur die Klimamittel-Linie sichtbar.</p>
      <div class="row-actions">
        <input type="text" id="gas-weather-location" placeholder="z.B. Ort oder Postleitzahl" style="flex:1" />
        <button type="button" id="gas-weather-refresh-btn" class="ghost-btn" style="width:auto">🔄 Jetzt abrufen</button>
      </div>
      <div id="gas-weather-status" style="margin-top:8px;font-size:0.75rem"></div>
    </section>
    ` : ""}

    <div class="chart-grid">
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 id="${containerId}-main-title" style="margin:0;font-size:0.95rem;color:var(--accent)">${isEinspeisung ? "Produktion" : isElecIn ? "Gesamtverbrauch" : meterType === "gas" ? "Verbrauch & Temperatur" : "Verbrauch"}</h3>
          <div id="${containerId}-main-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-main-chart"></div>
      </section>

      ${meterType === "gas" ? `
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Tagesverbrauch je Ableseintervall</h3>
          <div id="${containerId}-daily-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-daily-chart"></div>
      </section>` : ""}

      ${isEinspeisung ? `
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Autarkiegrad</h3>
          <div id="${containerId}-aut-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-aut-chart"></div>
      </section>` : `
      <section class="card">
        <div class="row-actions" style="justify-content:space-between;margin-bottom:8px">
          <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Kumulative Kosten</h3>
          <div id="${containerId}-cum-range" class="range-sel"></div>
        </div>
        <div id="${containerId}-cum-chart"></div>
      </section>`}
    </div>

    <section class="card">
      <h2 style="margin-bottom:10px">📥 Ablesung hinzufügen</h2>
      <div class="mode-toggle">
        <button type="button" class="mode-btn active" data-mode="manual">✏️ Manuell</button>
        <button type="button" class="mode-btn" data-mode="smart">🧠 Intelligenter Import</button>
      </div>

      <div id="${containerId}-mode-manual">
        <form id="${containerId}-add-form" class="row-actions" style="flex-wrap:wrap;gap:8px;margin-top:12px">
          <input type="date" id="${containerId}-date" required style="flex:1;min-width:130px" />
          <input type="text" id="${containerId}-value" required inputmode="decimal" placeholder="Zählerstand (${unit})" style="flex:1;min-width:130px" />
          <button type="submit" style="width:auto">Speichern</button>
        </form>
        <label class="checkbox-label">
          <input type="checkbox" id="${containerId}-new-meter" />
          <span>Erster Stand nach einem Zählerwechsel (neuer Zähler)</span>
        </label>

        <div class="divider"></div>
        <p class="muted" style="margin:0 0 6px;font-size:0.8rem">Oder Foto der Ablesekarte/Abrechnung einlesen:</p>
        <input type="file" id="${containerId}-photo" accept="image/*,application/pdf" />
        <button type="button" id="${containerId}-photo-btn" class="ghost-btn" style="width:100%;margin-top:6px">Einlesen</button>
        <div id="${containerId}-photo-result"></div>
      </div>

      <div id="${containerId}-mode-smart" style="display:none;margin-top:12px">
        <p class="muted" style="margin:0 0 8px;font-size:0.75rem">CSV/Excel-Datei mit Datum + Zählerstand hochladen — Spalten werden automatisch erkannt.</p>
        <input type="file" id="${containerId}-smart-file" accept=".csv,.xlsx,.xls,.ods" />
        <button type="button" id="${containerId}-smart-analyze-btn" class="ghost-btn" style="width:100%;margin-top:8px">Datei analysieren</button>
        <div id="${containerId}-smart-result"></div>
      </div>
    </section>

    <section class="card">
      ${isEinspeisung ? `
        <h3 style="margin:0 0 10px;font-size:0.95rem;color:var(--accent)">Produktion &amp; Einspeisung je Monat (${pvMonthly.length})</h3>
        <div style="overflow-x:auto">
          <table class="meter-table">
            <thead><tr><th>Monat</th><th class="r">Produktion</th><th class="r">Eigenverbrauch</th><th class="r">Einspeisung</th><th></th></tr></thead>
            <tbody>
              ${pvMonthly.length === 0 ? '<tr><td colspan="5" class="muted">Noch keine PV-Daten importiert</td></tr>' : pvMonthly.slice().reverse().map((m) => `
                <tr>
                  <td>${monthLabel(m.key)}</td>
                  <td class="r">${fmtUnit(m.pv, "kWh")}</td>
                  <td class="r muted">${fmtUnit(Math.max(0, m.pv - m.einsp), "kWh")}</td>
                  <td class="r">${fmtUnit(m.einsp, "kWh")}</td>
                  <td><button class="del-btn" data-delete-pv="${m.key}" title="Löschen">🗑</button></td>
                </tr>`).join("")}
            </tbody>
          </table>
        </div>
        <p class="muted" style="margin:8px 0 0;font-size:0.7rem">Eigenverbrauch = Produktion − Einspeisung. Zählerablesungen der Einspeisung fließen zusätzlich in Tagesrate/Kennzahlen oben ein, sind hier aber nicht separat aufgeführt.</p>
      ` : isElecIn ? `
        <h3 style="margin:0 0 10px;font-size:0.95rem;color:var(--accent)">Ablesungen (${readings.length})</h3>
        <div style="overflow-x:auto">
          <table class="meter-table">
            <thead><tr><th>Datum</th><th class="r">Verbrauchszähler</th><th></th></tr></thead>
            <tbody>
              ${intervals.length === 0 ? '<tr><td colspan="3" class="muted">Noch keine Ablesungen</td></tr>' : intervals.slice().reverse().map((iv) => `
                <tr>
                  <td>${iv.reading_date}${iv.is_new_meter ? ' <span class="tag">neuer Zähler</span>' : ""}</td>
                  <td class="r">${fmtUnit(iv.value, unit)}</td>
                  <td><button class="del-btn" data-delete-reading="${iv.id}" title="Löschen">🗑</button></td>
                </tr>`).join("")}
            </tbody>
          </table>
        </div>
      ` : `
        <h3 style="margin:0 0 10px;font-size:0.95rem;color:var(--accent)">Ablesungen (${readings.length})</h3>
        <div style="overflow-x:auto">
          <table class="meter-table">
            <thead><tr><th>Datum</th><th class="r">Stand</th><th class="r">Delta</th><th class="r">Tage</th><th class="r">Rate/Tag</th><th></th></tr></thead>
            <tbody>
              ${intervals.length === 0 ? '<tr><td colspan="6" class="muted">Noch keine Ablesungen</td></tr>' : intervals.slice().reverse().map((iv) => `
                <tr>
                  <td>${iv.reading_date}${iv.is_new_meter ? ' <span class="tag">neuer Zähler</span>' : ""}</td>
                  <td class="r">${fmtUnit(iv.value, unit)}</td>
                  <td class="r muted">${iv.delta === "meter_switch" ? "↺ Wechsel" : (iv.delta != null ? iv.delta : "–")}</td>
                  <td class="r muted">${iv.days != null ? iv.days : "–"}</td>
                  <td class="r">${iv.rate != null ? iv.rate : "–"}</td>
                  <td><button class="del-btn" data-delete-reading="${iv.id}" title="Löschen">🗑</button></td>
                </tr>`).join("")}
            </tbody>
          </table>
        </div>
      `}
    </section>
  `;

  // ---- Manuell / Intelligenter Import umschalten ----
  container.querySelectorAll(".mode-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      container.querySelectorAll(".mode-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`${containerId}-mode-manual`).style.display = btn.dataset.mode === "manual" ? "block" : "none";
      document.getElementById(`${containerId}-mode-smart`).style.display = btn.dataset.mode === "smart" ? "block" : "none";
    });
  });

  // ---- Charts mit je eigenem Zeitraum-Filter ----
  const pvByKey = Object.fromEntries(pvMonthly.map((d) => [d.key, d]));
  const cp4 = chartPalette();

  if (isElecIn || isEinspeisung) {
    const series = isElecIn
      ? [
          { key: "eigenverbrauch", label: "Eigenverbrauch (PV)", color: cp4.teal },
          { key: "netzbezug", label: "Netzbezug", color: cp4.purple },
        ]
      : [
          { key: "eigenverbrauch", label: "Eigenverbrauch (PV)", color: cp4.teal },
          { key: "einspeisung", label: "Einspeisung", color: cp4.purple },
        ];
    const secondKey = isElecIn ? "netzbezug" : "einspeisung";
    // Für Produktion NICHT die Zähler-eigene Prognose nutzen (nur 2 Ablesungen
    // vorhanden → ohne jede Saisonalität, extrapoliert sonst z.B. die hohe
    // Sommer-Tagesrate fälschlich auf den ganzen Winter). Stattdessen dieselbe
    // echte PV-Monatsdatenquelle wie die Tabelle darunter verwenden. Bei
    // Verbrauch kommt der Netzbezug jetzt bereits über 'forecast' bevorzugt
    // aus dem iSolarCloud-Import (siehe Backend get_effective_monthly).
    const einspeisungByKey = isEinspeisung ? Object.fromEntries(pvMonthly.map((d) => [d.key, d.einsp])) : null;
    const secondSeriesByKey = isElecIn ? forecast : einspeisungByKey;

    // Eigenverbrauch: bei Verbrauch aus Gesamtverbrauch − Netzbezug (beides
    // jetzt aus demselben iSolarCloud-Import, konsistent mit den anderen
    // Kennzahlen dieser Seite) — bei Produktion aus PV-Ertrag − Einspeisung
    // (Erzeugerseite, konsistent mit der Tabelle auf der Produktionsseite).
    const eigenverbrauchByKey = {};
    if (isElecIn) {
      Object.keys(pvByKey).forEach((key) => {
        const gesamt = pvByKey[key].gesamt || 0;
        const bezug = secondSeriesByKey[key] ?? pvByKey[key].bezug ?? 0;
        eigenverbrauchByKey[key] = Math.max(0, gesamt - bezug);
      });
    } else {
      pvMonthly.forEach((d) => { eigenverbrauchByKey[d.key] = Math.max(0, d.pv - d.einsp); });
    }

    const baseTitle = isEinspeisung ? "Produktion" : "Gesamtverbrauch";
    const renderStacked = async (rangeId) => {
      rangeId = rangeId || meterChartRange[`${containerId}-main`] || "ytd";
      // Daten in der passenden Auflösung nachladen — bei kurzen Zeiträumen
      // Tages-/Wochenwerte, sonst bliebe nur ein einzelner Balken übrig.
      const pvRes = await (await authedFetch("/api/pv/monthly")).json();
      const pvSeries = pvRes.months || [];
      const effective = pvRes.effective_resolution || "month";
      const titleEl = document.getElementById(`${containerId}-main-title`);
      if (titleEl) titleEl.textContent = chartTitleWithResolution(baseTitle);

      const meterRes = await (await authedFetch(`/api/meters/${meterType}/monthly`)).json();
      const secondByKey = isElecIn
        ? { ...(meterRes.monthly || {}), ...(meterRes.forecast || {}) }
        : Object.fromEntries(pvSeries.map((d) => [d.key, d.einsp]));

      // Eigenverbrauch: bei Verbrauch aus Gesamtverbrauch − Netzbezug, bei
      // Produktion aus PV-Ertrag − Einspeisung (Erzeugerseite).
      const eigenByKey = {};
      pvSeries.forEach((d) => {
        eigenByKey[d.key] = isElecIn
          ? Math.max(0, (d.gesamt || 0) - (secondByKey[d.key] ?? d.bezug ?? 0))
          : Math.max(0, (d.pv || 0) - (d.einsp || 0));
      });

      const allKeys = new Set([...Object.keys(secondByKey), ...Object.keys(eigenByKey)]);
      const filteredKeys = filterPeriodKeysByRange([...allKeys], rangeId);
      const monthsData = filteredKeys.map((key) => ({
        key,
        values: { eigenverbrauch: eigenByKey[key] || 0, [secondKey]: secondByKey[key] || 0 },
      }));
      renderStackedBarChart(`${containerId}-main-chart`, monthsData, series, unit);
    };
    renderChartRangeSelector(`${containerId}-main`, `${containerId}-main-range`, "ytd", renderStacked);
    renderStacked();
  } else {
    let gasTemps = null;
    if (meterType === "gas") {
      gasTemps = await (await authedFetch("/api/meters/gas/temperature")).json();
    }
    const baseTitle = isEinspeisung ? "Produktion" : isElecIn ? "Gesamtverbrauch"
                      : meterType === "gas" ? "Verbrauch & Temperatur" : "Verbrauch";
    // Bei Zeitraumwechsel die Daten in der passenden Auflösung NACHLADEN --
    // ein kurzer Zeitraum braucht Tages-/Wochenwerte, sonst bliebe nur ein
    // einzelner Balken übrig.
    const loadAndRender = async (rangeId) => {
      const res = await (await authedFetch(`/api/meters/${meterType}/monthly`)).json();
      const titleEl = document.getElementById(`${containerId}-main-title`);
      if (titleEl) {
        titleEl.textContent = chartTitleWithResolution(baseTitle);
      }
      // Temperatur-Linie nur bei Monatsauflösung — die Klimamittel-Referenz
      // liegt ausschließlich als Monatswert vor.
      const temps = (res.effective_resolution === "month") ? gasTemps : null;
      renderMeterMainChart(`${containerId}-main-chart`, res.monthly, res.forecast || {}, unit, temps);
    };
    renderChartRangeSelector(`${containerId}-main`, `${containerId}-main-range`, "ytd", loadAndRender);
    loadAndRender(meterChartRange[`${containerId}-main`] || "ytd");
  }

  if (meterType === "gas") {
    const currentRate = intervals.length ? intervals[intervals.length - 1].rate : null;
    renderChartRangeSelector(`${containerId}-daily`, `${containerId}-daily-range`, "ytd", () => renderDailyRateChart(`${containerId}-daily-chart`, intervals, currentRate, unit));
    renderDailyRateChart(`${containerId}-daily-chart`, intervals, currentRate, unit);
  }

  if (isEinspeisung) {
    renderChartRangeSelector(`${containerId}-aut`, `${containerId}-aut-range`, "ytd", () => renderAutarkieChart(`${containerId}-aut-chart`, autarkieMonths));
    renderAutarkieChart(`${containerId}-aut-chart`, autarkieMonths);
  } else {
    renderChartRangeSelector(`${containerId}-cum`, `${containerId}-cum-range`, "ytd", () => renderCumulativeChart(`${containerId}-cum-chart`, cumMonths));
    renderCumulativeChart(`${containerId}-cum-chart`, cumMonths);
  }

  document.getElementById(`${containerId}-date`).value = new Date().toISOString().slice(0, 10);

  // ---- Ablesung speichern ----
  document.getElementById(`${containerId}-add-form`).addEventListener("submit", async (e) => {
    e.preventDefault();
    const reading_date = document.getElementById(`${containerId}-date`).value;
    const value = parseGermanNumber(document.getElementById(`${containerId}-value`).value);
    const is_new_meter = document.getElementById(`${containerId}-new-meter`).checked;
    if (Number.isNaN(value)) return alert("Bitte einen gültigen Zählerstand eingeben.");
    const res = await authedFetch(`/api/meters/${meterType}/readings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reading_date, value, is_new_meter }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return alert(err.detail || "Fehler beim Speichern.");
    }
    loadMeterPage(meterType, containerId, title);
  });

  // ---- Ablesung löschen ----
  container.querySelectorAll("[data-delete-reading]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diese Ablesung wirklich löschen?")) return;
      await authedFetch(`/api/meters/${meterType}/readings/${btn.dataset.deleteReading}`, { method: "DELETE" });
      loadMeterPage(meterType, containerId, title);
    });
  });

  // ---- Foto/PDF einlesen ----
  document.getElementById(`${containerId}-photo-btn`).addEventListener("click", async () => {
    const input = document.getElementById(`${containerId}-photo`);
    const resultDiv = document.getElementById(`${containerId}-photo-result`);
    if (!input.files.length) return (resultDiv.textContent = "Bitte zuerst eine Datei auswählen.");
    resultDiv.textContent = "Wird gelesen …";
    const formData = new FormData();
    formData.append("file", input.files[0]);
    const res = await authedFetch(`/api/meters/${meterType}/upload`, { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) {
      resultDiv.innerHTML = `<div class="healthcheck-item healthcheck-yellow"><p style="margin:0;font-size:0.85rem">${data.detail || "Fehler beim Einlesen."}</p></div>`;
      return;
    }
    resultDiv.innerHTML = `
      <p class="muted" style="margin:8px 0 4px">${data.note}</p>
      <label class="muted" style="font-size:0.8rem">Datum</label>
      <input type="date" id="${containerId}-photo-date" value="${data.suggested_date || new Date().toISOString().slice(0, 10)}" />
      <label class="muted" style="font-size:0.8rem">Zählerstand (${unit})</label>
      <input type="text" id="${containerId}-photo-value" inputmode="decimal" value="${data.suggested_value ?? ""}" placeholder="manuell eintragen" />
      <button type="button" id="${containerId}-photo-confirm" style="margin-top:8px">Als Ablesung übernehmen</button>
    `;
    document.getElementById(`${containerId}-photo-confirm`).addEventListener("click", async () => {
      const reading_date = document.getElementById(`${containerId}-photo-date`).value;
      const valueStr = document.getElementById(`${containerId}-photo-value`).value;
      const value = parseGermanNumber(valueStr);
      if (Number.isNaN(value)) return alert("Bitte einen gültigen Zählerstand eingeben.");
      const confirmRes = await authedFetch(`/api/meters/${meterType}/readings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reading_date, value, receipt_id: data.receipt_id }),
      });
      if (!confirmRes.ok) {
        const err = await confirmRes.json().catch(() => ({}));
        return alert(err.detail || "Fehler beim Speichern.");
      }
      input.value = "";
      loadMeterPage(meterType, containerId, title);
    });
  });

  // ---- Tarif-Einstellungen speichern ----
  document.getElementById(`${containerId}-settings-form`).addEventListener("submit", async (e) => {
    e.preventDefault();
    const num = (id) => parseGermanNumber(document.getElementById(id)?.value) || 0;
    const payload = {
      anbieter: document.getElementById(`${containerId}-s-anbieter`).value || null,
      abschlag: num(`${containerId}-s-abschlag`),
    };
    if (isEinspeisung) {
      payload.einspeisepreis = num(`${containerId}-s-einspeisepreis`);
    } else {
      payload.vertragsende = document.getElementById(`${containerId}-s-vertragsende`).value || null;
      payload.arbeitspreis = num(`${containerId}-s-arbeitspreis`);
      payload.grundpreis = num(`${containerId}-s-grundpreis`);
      if (meterType === "water") payload.entwaesserung_preis = num(`${containerId}-s-entwaesserung`);
      if (meterType === "gas") payload.brennwert = num(`${containerId}-s-brennwert`);
    }
    await authedFetch(`/api/meters/${meterType}/settings`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    loadMeterPage(meterType, containerId, title);
  });

  // ---- PV-Monat loeschen (nur auf der Produktions-Tabelle) ----
  container.querySelectorAll("[data-delete-pv]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm(`PV-Daten für ${btn.dataset.deletePv} wirklich löschen?`)) return;
      await authedFetch(`/api/pv/monthly/${btn.dataset.deletePv}`, { method: "DELETE" });
      loadMeterPage(meterType, containerId, title);
    });
  });

  // ---- Viele Ablesungen auf einmal (intelligenter Import) ----
  initSmartImport(
    `${containerId}-smart`,
    () => "meter_readings",
    () => ({ meter_type: meterType }),
    () => loadMeterPage(meterType, containerId, title),
  );

  loadMeterSettlements(meterType, containerId, title);
  if (meterType === "gas") initGasWeatherLocation();
}

// ---------- Wetter-Standort für die Ist-Temperatur-Linie (Gas) ----------
async function initGasWeatherLocation() {
  const input = document.getElementById("gas-weather-location");
  const statusEl = document.getElementById("gas-weather-status");
  const refreshBtn = document.getElementById("gas-weather-refresh-btn");
  if (!input) return;

  const res = await authedFetch("/api/settings/weather_location");
  const { value } = await res.json();
  if (value) input.value = value;

  input.addEventListener("change", async () => {
    await authedFetch("/api/settings/weather_location", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: input.value.trim() || null }),
    });
    statusEl.innerHTML = '<p class="muted">Gespeichert — beim nächsten App-Start automatisch abgerufen, oder jetzt direkt per "Jetzt abrufen".</p>';
  });

  refreshBtn.addEventListener("click", async () => {
    if (!input.value.trim()) { statusEl.innerHTML = '<p style="color:var(--bad)">Bitte zuerst einen Standort eintragen.</p>'; return; }
    await authedFetch("/api/settings/weather_location", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: input.value.trim() }),
    });
    statusEl.innerHTML = '<p class="muted">Rufe Wetterdaten ab …</p>';
    const r = await authedFetch("/api/meters/gas/temperature/refresh", { method: "POST" });
    const data = await r.json();
    if (data.status === "ok") {
      statusEl.innerHTML = `<p style="color:var(--good)">✅ ${data.months_updated} Monat${data.months_updated === 1 ? "" : "e"} aktualisiert.</p>`;
      setTimeout(() => loadMeterPage("gas", "meter-page-gas", "🔥 Gas"), 1500);
    } else {
      statusEl.innerHTML = `<p style="color:var(--bad)">❌ ${data.error || "Fehlgeschlagen."}</p>`;
    }
  });
}

// ---------- Manuell erfasste Abrechnungszeitpunkte je Zählerseite ----------
async function loadMeterSettlements(meterType, containerId, title) {
  const [allSettlements, sinceOverview] = await Promise.all([
    (await authedFetch("/api/energy/settlements")).json(),
    (await authedFetch("/api/energy/consumption-since-settlement")).json(),
  ]);
  const entries = allSettlements.filter((s) => s.meter_type === meterType);
  const since = sinceOverview[meterType];
  const unit = meterType === "elec_in" || meterType === "elec_out" ? "kWh" : "m³";

  const sinceEl = document.getElementById(`${containerId}-settlement-since`);
  if (since) {
    sinceEl.innerHTML = `
      <div class="stats"><div>
        <span class="label">Verbrauch seit ${new Date(since.since_date).toLocaleDateString("de-DE")}${since.settlement_note ? ` (${since.settlement_note})` : ""}</span>
        <span>${fmt(since.consumption).replace("€", unit)} · ${since.days} Tage</span>
      </div></div>`;
  } else if (entries.length > 0) {
    sinceEl.innerHTML = '<p class="muted" style="font-size:0.78rem">Verbrauch seit der letzten Abrechnung lässt sich gerade nicht berechnen (z.B. wegen eines dazwischenliegenden Zählerwechsels).</p>';
  } else {
    sinceEl.innerHTML = "";
  }

  const listEl = document.getElementById(`${containerId}-settlement-list`);
  if (!entries.length) {
    listEl.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Abrechnungszeitpunkte erfasst.</p>';
  } else {
    listEl.innerHTML = `<ul class="contract-list">${entries.map((s) => `
      <li>
        <div class="contract-main">
          <span class="contract-label">${new Date(s.settlement_date).toLocaleDateString("de-DE")}</span>
          ${s.note ? `<span class="muted" style="font-size:0.78rem">${s.note}</span>` : ""}
        </div>
        <button type="button" class="del-btn" data-delete-settlement="${s.id}" title="Löschen">🗑</button>
      </li>`).join("")}</ul>`;
    listEl.querySelectorAll("[data-delete-settlement]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Diesen Abrechnungszeitpunkt wirklich löschen?")) return;
        await authedFetch(`/api/energy/settlements/${btn.dataset.deleteSettlement}`, { method: "DELETE" });
        loadMeterSettlements(meterType, containerId, title);
      });
    });
  }

  document.getElementById(`${containerId}-settlement-add-btn`).addEventListener("click", async () => {
    const dateInput = document.getElementById(`${containerId}-settlement-date`);
    const noteInput = document.getElementById(`${containerId}-settlement-note`);
    if (!dateInput.value) { alert("Bitte ein Datum wählen."); return; }
    await authedFetch("/api/energy/settlements", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ meter_type: meterType, settlement_date: dateInput.value, note: noteInput.value || null }),
    });
    dateInput.value = "";
    noteInput.value = "";
    loadMeterSettlements(meterType, containerId, title);
  }, { once: true });
}

// ═══════════════════════════════════════════════════════════════
// INTELLIGENTER DATEI-IMPORT (Ollama-gestützt, lernt Spalten-Zuordnungen)
// ═══════════════════════════════════════════════════════════════

const SMART_IMPORT_FIELD_LABELS = {
  label: "Bezeichnung", amount: "Betrag", date: "Datum", provider: "Anbieter",
  category: "Kategorie", frequency: "Häufigkeit", contract_number: "Vertragsnummer",
  contract_end: "Vertragsende", current_value: "Aktueller Wert", type: "Art",
};

const SMART_IMPORT_SOURCE_LABELS = {
  learned: "✅ Gelerntes Schema (schon mal so importiert)",
  ai: "🧠 KI-Vorschlag",
  heuristic: "📋 Stichwort-Erkennung (kein Ollama erreichbar oder unsicher)",
};

function initSmartImport(prefix, getTarget, getExtraPayload = () => ({}), onImported = null) {
  const fileInput = document.getElementById(`${prefix}-file`);
  const resultDiv = document.getElementById(`${prefix}-result`);
  const analyzeBtn = document.getElementById(`${prefix}-analyze-btn`);
  if (!fileInput || !resultDiv || !analyzeBtn) return; // Abschnitt auf dieser Seite nicht vorhanden

  analyzeBtn.addEventListener("click", async () => {
    if (!fileInput.files.length) return (resultDiv.textContent = "Bitte zuerst eine Datei auswählen.");
    const target = getTarget();
    resultDiv.innerHTML = '<p class="muted">Datei wird analysiert …</p>';
    const formData = new FormData();
    formData.append("file", fileInput.files[0]);
    const res = await authedFetch(`/api/smart-import/${target}/analyze`, { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) {
      resultDiv.innerHTML = `<div class="healthcheck-item healthcheck-yellow"><p style="margin:0;font-size:0.85rem">${data.detail || "Fehler beim Einlesen."}</p></div>`;
      return;
    }
    renderSmartImportMapping(prefix, target, data, getExtraPayload, onImported);
  });
}

function renderSmartImportMapping(prefix, target, data, getExtraPayload = () => ({}), onImported = null) {
  const resultDiv = document.getElementById(`${prefix}-result`);
  const reverseMapping = {}; // Zielfeld -> Quellspalte, fürs Vorbelegen der Dropdowns
  Object.entries(data.mapping).forEach(([col, field]) => { reverseMapping[field] = col; });

  const fieldOptions = (selectedCol) => `
    <option value="">– ignorieren –</option>
    ${data.columns.map((col) => `<option value="${col}" ${col === selectedCol ? "selected" : ""}>${col}</option>`).join("")}
  `;

  resultDiv.innerHTML = `
    <p class="muted" style="margin:8px 0 4px;font-size:0.78rem">${SMART_IMPORT_SOURCE_LABELS[data.mapping_source] || ""}</p>
    <p class="muted" style="margin:0 0 10px;font-size:0.78rem">${data.row_count} Zeile(n) erkannt. Beispiel: ${JSON.stringify(data.sample_rows[0] || {})}</p>

    <div id="${prefix}-field-mapping">
      ${Object.entries(data.target_fields).map(([field, desc]) => `
        <label class="muted" style="font-size:0.78rem">${SMART_IMPORT_FIELD_LABELS[field] || field}${data.required_fields.includes(field) ? " *" : ""}</label>
        <select data-field="${field}">${fieldOptions(reverseMapping[field])}</select>
      `).join("")}
    </div>

    <label class="checkbox-label">
      <input type="checkbox" id="${prefix}-save-schema" checked />
      <span>Diese Zuordnung für künftige gleiche Dateien merken</span>
    </label>

    <button type="button" id="${prefix}-confirm-btn" style="margin-top:10px">Import starten</button>
  `;

  document.getElementById(`${prefix}-confirm-btn`).addEventListener("click", async () => {
    const mapping = {};
    resultDiv.querySelectorAll(`#${prefix}-field-mapping select`).forEach((sel) => {
      if (sel.value) mapping[sel.value] = sel.dataset.field;
    });
    const missing = data.required_fields.filter((f) => !Object.values(mapping).includes(f));
    if (missing.length > 0) {
      return alert(`Bitte noch zuordnen: ${missing.map((f) => SMART_IMPORT_FIELD_LABELS[f] || f).join(", ")}`);
    }
    const save_schema = document.getElementById(`${prefix}-save-schema`).checked;
    const res = await authedFetch(`/api/smart-import/${target}/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ staging_id: data.staging_id, mapping, save_schema, ...getExtraPayload() }),
    });
    const result = await res.json();
    if (!res.ok) {
      alert(result.detail || "Fehler beim Import.");
      return;
    }
    resultDiv.innerHTML = `<p style="margin:0">✅ ${result.imported} importiert${result.skipped ? `, ${result.skipped} übersprungen` : ""}.</p>`;
    if (onImported) {
      onImported();
    } else {
      loadIncome();
      loadContracts();
      loadDashboard();
    }
  });
}

initSmartImport("smart-import-income", () => "income");
initSmartImport("smart-import-contracts", () => document.getElementById("smart-import-contracts-target").value);
initSmartImport("smart-import-pv", () => "pv_monthly", () => ({}), () => {
  loadMeterPage("elec_out", "meter-page-elec_out", "↑ Einspeisung");
  loadEnergyOverview();
});

// ═══════════════════════════════════════════════════════════════
// VORSORGE: RENTE
// ═══════════════════════════════════════════════════════════════

function fmtEur0(v) { return `${Math.round(v).toLocaleString("de-DE")} €`; }

function renderPensionGapChart(containerId, gap, showFinancingRelief = false) {
  const el = document.getElementById(containerId);
  // Deutlich flacher als zuvor und mit Rand oben/rechts, damit die
  // Ziel-Beschriftung nicht mehr aus dem Diagramm herausragt. Die
  // Schriftgrößen sind relativ zur viewBox — bei 700px Breite und dieser
  // Höhe entspricht font-size 13 ungefähr normaler Fließtextgröße.
  const W = 700, H = 52, padL = 4, padR = 4, barH = 22, barY = 22;
  const chartW = W - padL - padR;
  const statutory = gap.statutory_pension_monthly || 0;
  const priv = gap.private_pension_monthly_projected || 0;
  // Die Finanzierungs-Entlastung erscheint nur auf Haushalts-Ebene als
  // eigenes Segment — bei Einzelpersonen macht sie keinen Sinn, da sie ein
  // gemeinsamer Haushaltseffekt ist, keiner Person allein zurechenbar.
  const relief = showFinancingRelief ? (gap.expense_relief_monthly || 0) : 0;
  const target = gap.target_pension_monthly || 0;
  // Summe aus den Einzelteilen berechnen statt auf ein separates Gesamtfeld
  // zu vertrauen — sonst kippt die ganze Skalierung auf NaN, sobald das Feld
  // einmal fehlt, und das Diagramm bleibt leer.
  const maxVal = Math.max(target, statutory + priv + relief, 1);
  const scale = (v) => (v / maxVal) * chartW;

  const statutoryW = scale(statutory);
  const privateW = scale(priv);
  const reliefW = scale(relief);
  const targetX = padL + scale(target);
  const reachedW = statutoryW + privateW + reliefW;

  // Ziel-Beschriftung am Rand festhalten, damit sie bei einem Ziel ganz
  // rechts nicht abgeschnitten wird (genau das passierte vorher).
  const labelText = `Ziel ${fmtEur0(target)}`;
  const approxLabelHalfWidth = labelText.length * 3.4;
  const labelX = Math.min(Math.max(targetX, padL + approxLabelHalfWidth), W - padR - approxLabelHalfWidth);

  const cpGap = chartPalette();
  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
      <rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="5" fill="rgba(255,255,255,0.06)" />
      ${reachedW > 0 ? `
        <clipPath id="clip-${containerId}"><rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="5" /></clipPath>
        <g clip-path="url(#clip-${containerId})">
          <rect x="${padL}" y="${barY}" width="${statutoryW}" height="${barH}" fill="${cpGap.accent}">
            <title>Gesetzliche Rente: ${fmtEur0(statutory)}/Monat</title>
          </rect>
          <rect x="${padL + statutoryW}" y="${barY}" width="${privateW}" height="${barH}" fill="${cpGap.teal}">
            <title>Private Vorsorge: ${fmtEur0(priv)}/Monat</title>
          </rect>
          ${relief > 0 ? `
          <rect x="${padL + statutoryW + privateW}" y="${barY}" width="${reliefW}" height="${barH}" fill="${cpGap.warn}">
            <title>Abbezahlte Finanzierung: ${fmtEur0(relief)}/Monat</title>
          </rect>` : ""}
        </g>` : ""}
      <line x1="${targetX}" y1="${barY - 4}" x2="${targetX}" y2="${barY + barH + 4}" stroke="var(--text)" stroke-width="1.5" stroke-dasharray="3,2" />
      <text x="${labelX}" y="${barY - 8}" text-anchor="middle" font-size="13" fill="var(--text)">${labelText}</text>
    </svg>`;
}

function pensionLegendHTML(gap, showFinancingRelief = false) {
  const cpLegend = chartPalette();
  const parts = [
    `<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpLegend.accent};border-radius:2px;display:inline-block"></span>Gesetzlich ${fmtEur0(gap.statutory_pension_monthly)}</span>`,
  ];
  if (gap.private_pension_monthly_projected > 0) {
    parts.push(`<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpLegend.teal};border-radius:2px;display:inline-block"></span>Privat ${fmtEur0(gap.private_pension_monthly_projected)}</span>`);
  } else {
    parts.push(`<span class="muted">Privat: noch nichts hinterlegt</span>`);
  }
  if (showFinancingRelief && gap.expense_relief_monthly > 0) {
    parts.push(`<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:${cpLegend.warn};border-radius:2px;display:inline-block"></span>Abbezahlte Finanzierung ${fmtEur0(gap.expense_relief_monthly)}</span>`);
  }
  if (gap.gap_monthly > 0) {
    parts.push(`<span style="display:inline-flex;align-items:center;gap:5px"><span style="width:9px;height:9px;background:rgba(255,255,255,0.12);border-radius:2px;display:inline-block"></span>Lücke ${fmtEur0(gap.gap_monthly)}</span>`);
  }
  return `<div style="display:flex;gap:14px;flex-wrap:wrap;font-size:0.78rem;color:var(--muted);margin-top:6px">${parts.join("")}</div>`;
}

let vorsorgeActivePersonId = null;

async function loadVorsorgeDashboard() {
  await loadHaushaltSummary();
  await renderVorsorgeSummaryCards();
}

async function renderVorsorgeSummaryCards() {
  const el = document.getElementById("vorsorge-summary-cards");
  const data = await (await authedFetch("/api/vorsorge/rente")).json();
  const h = data.household;
  if (!h.gap_analysis) {
    el.innerHTML = '<p class="muted">Noch keine Berechnungsgrundlage — Einkommen mit Personen verknüpfen.</p>';
    return;
  }
  const g = h.gap_analysis;
  // Gesamtkapital heute UND zum Renteneintritt über alle Personen und all
  // ihre privaten Konten hinweg -- macht sichtbar, wie viel bereits
  // vorhanden ist und wohin es sich entwickelt, nicht nur die reine Lücke.
  let capitalToday = 0, capitalAtRetirement = 0;
  for (const p of data.persons) {
    for (const a of p.private_accounts) capitalToday += a.current_value || 0;
    if (p.capital_projection && p.capital_projection.length) {
      capitalAtRetirement += p.capital_projection[p.capital_projection.length - 1].capital;
    }
  }
  el.innerHTML = `
    <div><span class="label">Deckungsgrad</span><span style="color:${g.status === "green" ? "var(--good)" : g.status === "yellow" ? "var(--warn)" : "var(--bad)"}">${g.coverage_rate}%</span></div>
    <div><span class="label">Rente gesamt (gesetzl. + privat)</span><span>${fmtEur0(g.statutory_pension_monthly + g.private_pension_monthly_projected)}/Mo</span></div>
    <div><span class="label">Privates Kapital heute</span><span>${fmtEur0(capitalToday)}</span></div>
    <div><span class="label">Prognose bei Rente</span><span>${fmtEur0(capitalAtRetirement)}</span></div>
  `;
}

function cssVarToRgba(varName, alpha) {
  const hex = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
  return hex.startsWith("#") ? hexToRgba(hex, alpha) : hex;
}

async function loadHaushaltSummary() {
  const container = document.getElementById("vorsorge-haushalt-content");
  container.innerHTML = '<p class="muted">Lade …</p>';
  const data = await (await authedFetch("/api/vorsorge/rente")).json();
  const h = data.household;

  if (!h.gap_analysis) {
    container.innerHTML = `
      <section class="card">
        <h3 style="margin:0 0 4px;font-size:0.95rem;color:var(--accent)">Familieneinkommen</h3>
        <p class="muted" style="margin:0;font-size:0.82rem">Noch kein Einkommen mit Personen verknüpft — die Haushaltsübersicht braucht mindestens eine Person mit Einkommen.</p>
      </section>`;
    return;
  }

  const g = h.gap_analysis;
  const statusColor = g.status === "green" ? "var(--good)" : g.status === "yellow" ? "var(--warn)" : "var(--bad)";
  const financingWithPayoff = h.financing.filter((f) => f.paid_off_before_retirement);
  const financingWithoutPayoff = h.financing.filter((f) => !f.paid_off_before_retirement);
  // Alter IM jeweiligen Tilgungsjahr (nicht das heutige Alter!) — jede
  // Finanzierung kann ein anderes Tilgungsjahr haben, deshalb pro Eintrag
  // statt einmal gemeinsam für alle.
  const agesAtPayoffLabel = (f) => f.ages_at_payoff && f.ages_at_payoff.length
    ? ` (Alter ${f.payoff_year}: ${f.ages_at_payoff.map((p) => `${p.person_name} ${p.age}`).join(", ")})`
    : "";

  container.innerHTML = `
    <section class="card">
      <div class="row-actions" style="justify-content:space-between;align-items:baseline;flex-wrap:wrap">
        <h3 style="margin:0;font-size:0.95rem;color:var(--accent)">Familieneinkommen zusammen</h3>
        <span style="font-size:1.15rem;font-weight:700;color:${statusColor}">${g.coverage_rate}% gedeckt</span>
      </div>
      <p class="muted" style="margin:2px 0 12px;font-size:0.78rem">${fmtEur0(h.net_income_monthly)}/Mo Netto gemeinsam · Zielrente ${fmtEur0(g.target_pension_monthly)}/Mo (80% davon)</p>

      <div id="haushalt-gap-chart"></div>
      ${pensionLegendHTML(g, true)}
      <p class="settle-sub" style="margin:10px 0 0">
        ${g.gap_monthly > 0
          ? `Es fehlen <b class="settle-red">${fmtEur0(g.gap_monthly)}/Monat</b> bis zur Zielrente.`
          : `<b class="settle-ok">Ziel erreicht</b> — ${fmtEur0(-g.gap_monthly)}/Monat Puffer.`}
      </p>

      ${financingWithPayoff.length ? `
        <div style="background:${cssVarToRgba("--good", 0.08)};border-radius:8px;padding:8px 10px;margin-top:10px;font-size:0.78rem">
          🏠 ${financingWithPayoff.map((f) => `${f.label} ist laut Tilgungsplan ${f.payoff_year} abbezahlt${agesAtPayoffLabel(f)}`).join(", ")} — zählt oben als ${fmtEur0(g.expense_relief_monthly)}/Mo zusätzliche "Einnahme", da diese Rate dann wegfällt.
        </div>` : ""}
      ${financingWithoutPayoff.length ? `
        <div style="background:${cssVarToRgba("--warn", 0.08)};border-radius:8px;padding:8px 10px;margin-top:8px;font-size:0.78rem">
          💡 ${financingWithoutPayoff.map((f) => f.calculation_error ? `${f.label}: ${f.calculation_error}` : `${f.label}: laut Tilgungsplan erst ${f.payoff_year || "nach der Rente"} abbezahlt${agesAtPayoffLabel(f)}`).join(" · ")}
        </div>` : ""}
    </section>`;
  renderPensionGapChart("haushalt-gap-chart", g, true);
}

async function fetchVorsorgeDataOnce() {
  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  if (!vorsorgeLastRenteData || !vorsorgeLastRisikoData) {
    const [renteData, risikoData] = await Promise.all([
      authedFetch("/api/vorsorge/rente").then((r) => r.json()),
      authedFetch("/api/vorsorge/risiko").then((r) => r.json()),
    ]);
    vorsorgeLastRenteData = renteData;
    vorsorgeLastRisikoData = risikoData;
  }
  return { renteData: vorsorgeLastRenteData, risikoData: vorsorgeLastRisikoData };
}

function wirePersonTabs(tabsEl, persons, onSwitch) {
  if (!vorsorgeActivePersonId || !persons.some((p) => p.person_id === vorsorgeActivePersonId)) {
    vorsorgeActivePersonId = persons[0].person_id;
  }
  tabsEl.innerHTML = persons.map((p) => `
    <button type="button" class="mode-btn${p.person_id === vorsorgeActivePersonId ? " active" : ""}" data-person-tab="${p.person_id}">${p.person_name}</button>
  `).join("");
  tabsEl.querySelectorAll("[data-person-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      vorsorgeActivePersonId = parseInt(btn.dataset.personTab, 10);
      tabsEl.querySelectorAll("[data-person-tab]").forEach((b) => b.classList.toggle("active", b === btn));
      onSwitch();
    });
  });
}

async function loadAufbauTab() {
  const tabsEl = document.getElementById("vorsorge-aufbau-person-tabs");
  const contentEl = document.getElementById("vorsorge-aufbau-content");
  contentEl.innerHTML = '<p class="muted">Lade …</p>';
  const { renteData } = await fetchVorsorgeDataOnce();

  if (renteData.persons.length === 0) {
    tabsEl.innerHTML = "";
    contentEl.innerHTML = '<section class="card"><p class="muted">Noch keine Elternteile als Personen angelegt. Über "👪 Personen verwalten" oben anlegen (Rolle "Elternteil").</p></section>';
    return;
  }
  wirePersonTabs(tabsEl, renteData.persons, () => renderAufbauPersonCard(vorsorgeLastRenteData));
  renderAufbauPersonCard(renteData);
}

async function loadAbsicherungTab() {
  const tabsEl = document.getElementById("vorsorge-absicherung-person-tabs");
  const contentEl = document.getElementById("vorsorge-absicherung-person-content");
  contentEl.innerHTML = '<p class="muted">Lade …</p>';
  const { renteData, risikoData } = await fetchVorsorgeDataOnce();
  renderVorsorgeAbsicherungSummaryCards(risikoData);

  if (renteData.persons.length === 0) {
    tabsEl.innerHTML = "";
    contentEl.innerHTML = "";
    renderRiskSharedContent(risikoData);
    return;
  }
  wirePersonTabs(tabsEl, renteData.persons, () => renderAbsicherungPersonCard(vorsorgeLastRenteData, vorsorgeLastRisikoData));
  renderAbsicherungPersonCard(renteData, risikoData);
  renderRiskSharedContent(risikoData);
}

function renderVorsorgeAbsicherungSummaryCards(risikoData) {
  const el = document.getElementById("vorsorge-absicherung-summary-cards");
  const toMonthly = (amount, freq) => freq === "yearly" ? amount / 12 : freq === "quarterly" ? amount / 3 : amount;
  let totalMonthly = 0, count = 0;
  for (const g of risikoData.groups) {
    for (const e of g.entries) {
      totalMonthly += toMonthly(e.amount, e.frequency);
      count++;
    }
  }
  el.innerHTML = `
    <div><span class="label">Versicherungen gesamt</span><span>${count}</span></div>
    <div><span class="label">Prämien gesamt</span><span>${fmtEur0(totalMonthly)}/Mo</span></div>
    <div><span class="label">Häufig empfohlene vorhanden</span><span style="color:${risikoData.essential_present === risikoData.essential_total ? "var(--good)" : "var(--warn)"}">${risikoData.essential_present}/${risikoData.essential_total}</span></div>
  `;
}

let vorsorgeLastRenteData = null;
let vorsorgeLastRisikoData = null;

function renderAufbauPersonCard(renteData) {
  const contentEl = document.getElementById("vorsorge-aufbau-content");
  const p = renteData.persons.find((x) => x.person_id === vorsorgeActivePersonId);
  if (!p) return;

  // Private Vorsorge nach Variante gruppieren statt einer flachen Liste —
  // Riester hat eigene Zulagen-Logik und unterscheidet sich grundlegend von
  // sonstiger privater Vorsorge (ETF-Sparplan, klassische Rentenversicherung
  // etc.), das verdient eine eigene Überschrift statt nur eines Tags.
  const riesterAccounts = p.private_accounts.filter((a) => a.is_riester);
  const otherPrivateAccounts = p.private_accounts.filter((a) => !a.is_riester);

  const accountRow = (a, typeLabel) => `
    <li data-pension-row="${a.id}" style="cursor:context-menu;flex-direction:column;align-items:stretch;gap:4px">
      <div class="row-actions" style="justify-content:space-between">
        <span>${rowMenuButtonHTML("pension", a.id)} <b>${a.label}</b>${a.provider && a.provider !== a.label ? ` · ${a.provider}` : ""}</span>
        <span style="font-weight:600">${fmtEur0(typeLabel === "Gesetzlich" ? (a.projected_monthly_at_67 || 0) : a.projected_monthly)}/Mo</span>
      </div>
      <div class="row-actions muted" style="font-size:0.72rem;justify-content:space-between;flex-wrap:wrap">
        <span>
          ${typeLabel !== "Gesetzlich" ? `Angespart: ${fmtEur0(a.current_value || 0)} · Prognose 67: ${fmtEur0(a.projected_capital_at_67)}` : ""}
          ${a.linked_contract_id ? " · verknüpft mit Vertrag" : (a.monthly_contribution ? ` · ${fmtEur0(a.monthly_contribution)}/Mo Beitrag` : "")}
          ${a.return_rate_assumption ? ` · ${a.return_rate_assumption}% p.a. angenommen` : ""}
        </span>
        ${a.disability_pension_monthly ? `<span>+ ${fmtEur0(a.disability_pension_monthly)}/Mo Erwerbsminderungsrente</span>` : ""}
      </div>
    </li>`;

  const accountsSection = (title, accounts, typeLabel, addKey, icon) => `
    <h4 style="margin:16px 0 8px;font-size:0.85rem;color:var(--accent)">${icon} ${title}</h4>
    ${accounts.length === 0 ? '<p class="muted" style="font-size:0.8rem">Noch nichts hinterlegt.</p>' : `<ul>${accounts.map((a) => accountRow(a, typeLabel)).join("")}</ul>`}
    <button type="button" class="ghost-btn" style="width:100%;margin-top:4px" data-add-pension="${addKey}" data-add-pension-person="${p.person_id}">+ ${title === "Gesetzliche Rente" ? "Gesetzliche Rente" : "Private Vorsorge"} hinzufügen</button>`;

  contentEl.innerHTML = `
    <section class="card" data-person-card="${p.person_id}">
      <div class="row-actions" style="justify-content:space-between;flex-wrap:wrap;align-items:baseline">
        <h3 style="margin:0">${p.person_name}${p.gap_analysis ? ` <span style="font-size:1rem;font-weight:700;color:${p.gap_analysis.status === "green" ? "var(--good)" : p.gap_analysis.status === "yellow" ? "var(--warn)" : "var(--bad)"}">${p.gap_analysis.coverage_rate}% gedeckt</span>` : ""}</h3>
        <div class="row-actions" style="gap:8px">
          <label class="muted" style="font-size:0.75rem">Geburtsdatum</label>
          <input type="date" data-birth-date="${p.person_id}" value="${p.birth_date || ""}" style="width:auto" />
        </div>
      </div>
      <p class="muted" style="font-size:0.78rem;margin:4px 0 12px">
        ${fmtEur0(p.net_income_monthly)}/Mo Netto
        ${p.years_until_retirement != null ? ` · noch ${Math.round(p.years_until_retirement)} Jahre bis 67` : " · Geburtsdatum fehlt (private Vorsorge kann nicht hochgerechnet werden)"}
      </p>

      <h4 style="margin:0 0 8px;font-size:0.85rem;color:var(--accent)">👴 Versorgungslücke gesamt</h4>
      ${p.gap_analysis ? `
        <div id="gap-chart-${p.person_id}"></div>
        <div class="row-actions" style="justify-content:space-between;flex-wrap:wrap;margin-top:6px">
          ${pensionLegendHTML(p.gap_analysis)}
          <p class="settle-sub" style="margin:0">
            ${p.gap_analysis.gap_monthly > 0
              ? `Es fehlen <b class="settle-red">${fmtEur0(p.gap_analysis.gap_monthly)}/Monat</b>.`
              : `<b class="settle-ok">Ziel erreicht</b> — ${fmtEur0(-p.gap_analysis.gap_monthly)}/Monat Puffer.`}
          </p>
        </div>
      ` : '<p class="muted" style="font-size:0.8rem">Kein Nettoeinkommen hinterlegt — Versorgungslücke kann nicht berechnet werden.</p>'}

      ${accountsSection("Gesetzliche Rente", p.statutory_accounts, "Gesetzlich", "gesetzlich", "🏛️")}
      ${accountsSection("Riester-Rente", riesterAccounts, "Privat", "privat", "🎁")}
      ${accountsSection("Sonstige private Vorsorge", otherPrivateAccounts, "Privat", "privat", "💰")}

      ${p.capital_projection && p.capital_projection.length > 1 ? `
        <h4 style="margin:16px 0 8px;font-size:0.85rem;color:var(--accent)">📈 Kapitalverlauf bis zur Rente</h4>
        <p class="muted" style="font-size:0.72rem;margin:0 0 8px">Zinseszins auf den heutigen Bestand plus laufende Beiträge, angenommene Rendite je Konto — grobe Hochrechnung, keine Garantie.</p>
        <div id="capital-projection-chart-${p.person_id}"></div>
      ` : ""}

      <p class="muted" style="font-size:0.72rem;margin:12px 0 0">Rechtsklick oder ⋯ auf einen Eintrag für Details, Beleg &amp; Löschen.</p>
    </section>
  `;

  if (p.gap_analysis) renderPensionGapChart(`gap-chart-${p.person_id}`, p.gap_analysis);
  if (p.capital_projection && p.capital_projection.length > 1) {
    const cpProj = chartPalette();
    renderInteractiveMultiLineChart(
      document.getElementById(`capital-projection-chart-${p.person_id}`),
      p.capital_projection,
      [{ key: "capital", label: "Privates Kapital", color: cpProj.primary, width: 2.5 }],
      { height: 170, yFormat: fmtEur0, xLabel: (pt) => pt.year }
    );
  }

  contentEl.querySelectorAll("[data-birth-date]").forEach((input) => {
    input.addEventListener("change", async () => {
      await authedFetch(`/api/family-members/${input.dataset.birthDate}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ birth_date: input.value || null }),
      });
      vorsorgeLastRenteData = null;
      vorsorgeLastRisikoData = null;
      loadHaushaltSummary();
      loadAufbauTab();
    });
  });
  contentEl.querySelectorAll("[data-add-pension]").forEach((btn) => {
    btn.addEventListener("click", () => openPensionForm(null, btn.dataset.addPension, btn.dataset.addPensionPerson));
  });
  contentEl.querySelectorAll("[data-pension-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuPensionId = row.dataset.pensionRow;
      showPensionContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(contentEl, "pension", (id, x, y) => {
    contextMenuPensionId = id;
    showPensionContextMenu(x, y);
  });
}

function renderAbsicherungPersonCard(renteData, risikoData) {
  const contentEl = document.getElementById("vorsorge-absicherung-person-content");
  const p = renteData.persons.find((x) => x.person_id === vorsorgeActivePersonId);
  if (!p) return;
  const riskByPerson = {};
  (risikoData.persons_summary || []).forEach((x) => { riskByPerson[x.person_id] = x; });
  const risk = riskByPerson[p.person_id];

  contentEl.innerHTML = `
    <section class="card">
      <h3 style="margin:0 0 10px">${p.person_name}</h3>
      ${risk ? `
        ${renderRiskAssessmentLine("Berufsunfähigkeit", risk.bu, "monthly", risk.bu_em_combination)}
        ${renderRiskAssessmentLine("Risikoleben", risk.rlv, "sum")}
      ` : '<p class="muted" style="font-size:0.8rem">Keine Einkommensdaten hinterlegt — Absicherungsbedarf kann nicht berechnet werden.</p>'}
    </section>
  `;
  pendingRiskCharts.forEach((fn) => fn());
  pendingRiskCharts = [];
}

// ---------- Rentenkonto anlegen/bearbeiten (richtiges Formular-Overlay) ----------
const pensionFormOverlay = document.getElementById("pension-form-overlay");

function updatePensionDirectValueVisibility() {
  const useDirect = document.getElementById("pension-use-direct-value").checked;
  document.getElementById("pension-direct-value-group").style.display = useDirect ? "block" : "none";
}

document.getElementById("pension-use-direct-value").addEventListener("change", updatePensionDirectValueVisibility);

function updatePensionContributionLockState() {
  const linkedId = document.getElementById("pension-linked-contract").value;
  const contributionInput = document.getElementById("pension-contribution");
  const hint = document.getElementById("pension-linked-contract-hint");
  const documentGroup = document.getElementById("pension-document-group");
  if (linkedId) {
    const contract = allContracts.find((c) => String(c.id) === linkedId);
    contributionInput.value = contract ? contract.monthly_amount : "";
    contributionInput.disabled = true;
    hint.style.color = "var(--accent)";
    if (documentGroup) documentGroup.style.display = "none";
  } else {
    contributionInput.disabled = false;
    hint.style.color = "";
    if (documentGroup) documentGroup.style.display = "block";
  }
}

document.getElementById("pension-linked-contract").addEventListener("change", updatePensionContributionLockState);

document.getElementById("pension-analyze-document-btn").addEventListener("click", async () => {
  const fileInput = document.getElementById("pension-document");
  const suggestionBox = document.getElementById("pension-document-suggestion");
  if (!fileInput.files.length) {
    alert("Bitte zuerst eine Datei auswählen.");
    return;
  }
  suggestionBox.style.display = "block";
  suggestionBox.innerHTML = '<span class="muted">Lese Beleg …</span>';

  const fd = new FormData();
  fd.append("file", fileInput.files[0]);
  const res = await authedFetch("/api/pension-accounts/analyze-document", { method: "POST", body: fd });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    suggestionBox.innerHTML = `<span class="settle-red">${err.detail || "Beleg konnte nicht gelesen werden."}</span>`;
    return;
  }
  const result = await res.json();
  const form = document.getElementById("pension-form");
  form.dataset.documentStagingId = result.staging_id;
  form.dataset.documentOriginalFilename = result.original_filename;

  if (result.ocr_error) {
    suggestionBox.innerHTML = `<span class="settle-red">${result.ocr_error}</span> — Datei wird trotzdem beim Speichern angehängt, Werte bitte manuell eintragen.`;
    return;
  }
  if (result.suggested_monthly_amount == null) {
    suggestionBox.innerHTML = 'Kein Rentenbetrag im Beleg gefunden. Datei wird beim Speichern trotzdem angehängt — bitte Werte manuell eintragen.';
    return;
  }

  const isStatutory = form.dataset.type === "gesetzlich";
  const applyBtnId = "pension-apply-suggestion-btn";
  suggestionBox.innerHTML = `
    ✨ Gefunden: <b>${fmtEur0(result.suggested_monthly_amount)}/Monat</b>${result.provider ? ` bei ${result.provider}` : ""}
    ${result.all_amounts_found.length > 1 ? `<br><span class="muted">Weitere gefundene Beträge: ${result.all_amounts_found.filter((a) => a !== result.suggested_monthly_amount).map(fmtEur0).join(", ")}</span>` : ""}
    <br><button type="button" id="${applyBtnId}" class="ghost-btn" style="width:100%;margin-top:6px;font-size:0.75rem">✅ Übernehmen</button>
  `;
  document.getElementById(applyBtnId).addEventListener("click", () => {
    if (isStatutory) {
      document.getElementById("pension-projected").value = result.suggested_monthly_amount;
    } else {
      document.getElementById("pension-use-direct-value").checked = true;
      updatePensionDirectValueVisibility();
      document.getElementById("pension-projected-private").value = result.suggested_monthly_amount;
    }
    if (result.provider && !document.getElementById("pension-provider").value) {
      document.getElementById("pension-provider").value = result.provider;
    }
  });
});

document.getElementById("pension-form-cancel-btn").addEventListener("click", () => {
  pensionFormOverlay.style.display = "none";
});

let pensionFormDocsCache = null;

document.getElementById("pension-show-documents-btn").addEventListener("click", () => {
  const section = document.getElementById("pension-documents-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) {
    section.style.display = "none";
    return;
  }
  const accountId = document.getElementById("pension-form").dataset.accountId;
  section.style.display = "block";
  const docs = pensionFormDocsCache || [];
  if (docs.length === 0) {
    section.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Dokumente hinterlegt.</p>';
    return;
  }
  section.innerHTML = '<div id="pension-documents-list"></div>';
  setupScrollableDocList("pension-documents-list", docs, (d) => resolveDocDate(d), (filtered, ul) => {
    ul.innerHTML = filtered.map((d) => {
      const isFromContract = d.source === "contract";
      const baseUrl = isFromContract ? `/api/receipts/${d.id}/file` : `/api/pension-documents/${d.id}`;
      return `
      <li data-pension-doc-row="${d.id}">
        <a href="${baseUrl}" rel="noopener" data-view-doc-url="${baseUrl}" data-view-doc-title="${d.original_filename || "Dokument"}">📎 ${d.original_filename || "Dokument"}</a>
        <span class="row-actions">
          <span class="muted" style="font-size:0.72rem">${resolveDocDate(d) || ""}</span>
          <a href="${baseUrl}?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
          ${isFromContract
            ? '<span class="tag" title="Wird über den verknüpften Vertrag unter Ausgaben verwaltet">Vertrag</span>'
            : `<button type="button" class="del-btn" data-delete-pension-doc="${d.id}" title="Löschen">🗑</button>`}
        </span>
      </li>`;
    }).join("");
    wireDocumentViewerLinks(ul);
    ul.querySelectorAll("[data-delete-pension-doc]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        if (!confirm("Dieses Dokument wirklich löschen?")) return;
        await authedFetch(`/api/pension-documents/${btn.dataset.deletePensionDoc}`, { method: "DELETE" });
        const form = document.getElementById("pension-form");
        const type = form.dataset.type;
        const personId = form.dataset.personId;
        await openPensionForm(accountId, type, personId);
        document.getElementById("pension-show-documents-btn").click();
      });
    });
  });
});

async function openPensionForm(accountId, type, personId) {
  let account = null;
  document.getElementById("pension-is-riester").checked = false;
  if (accountId) {
    const all = await (await authedFetch("/api/vorsorge/rente")).json();
    for (const p of all.persons) {
      const stat = p.statutory_accounts.find((a) => String(a.id) === String(accountId));
      const priv = p.private_accounts.find((a) => String(a.id) === String(accountId));
      if (stat) { account = stat; type = "gesetzlich"; personId = p.person_id; break; }
      if (priv) { account = priv; type = "privat"; personId = p.person_id; break; }
    }
  }

  const isStatutory = type === "gesetzlich";
  const form = document.getElementById("pension-form");
  form.reset();
  form.dataset.accountId = accountId || "";
  form.dataset.type = type;
  form.dataset.personId = personId;
  form.dataset.documentStagingId = "";
  form.dataset.documentOriginalFilename = "";
  document.getElementById("pension-document-suggestion").style.display = "none";

  document.getElementById("pension-form-title").textContent =
    `${accountId ? "Bearbeiten" : "Neu"}: ${isStatutory ? "Gesetzliche Rente" : "Private Vorsorge"}`;
  document.getElementById("pension-statutory-fields").style.display = isStatutory ? "block" : "none";
  document.getElementById("pension-private-fields").style.display = isStatutory ? "none" : "block";

  const docLabel = document.getElementById("pension-document-label");
  const showDocsBtn = document.getElementById("pension-show-documents-btn");
  const docsSection = document.getElementById("pension-documents-section");
  docsSection.style.display = "none";
  docsSection.innerHTML = "";
  pensionFormDocsCache = null;

  if (accountId) {
    showDocsBtn.style.display = "block";
    const docs = await (await authedFetch(`/api/pension-accounts/${accountId}/documents`)).json();
    pensionFormDocsCache = docs;
    docLabel.textContent = docs.length > 0 ? "Weiteres Dokument hinzufügen" : "Dokument (optional, z.B. Renteninformation)";
  } else {
    // Ein noch nicht gespeichertes, neues Konto hat zwangsläufig keine
    // Dokument-Historie — der Button wäre hier nur eine leere Sackgasse.
    showDocsBtn.style.display = "none";
    docLabel.textContent = "Dokument (optional, z.B. Renteninformation)";
  }

  if (account) {
    document.getElementById("pension-label").value = account.label || "";
    document.getElementById("pension-provider").value = account.provider || "";
    document.getElementById("pension-note").value = account.note || "";
    if (isStatutory) {
      document.getElementById("pension-projected").value = account.projected_monthly_at_67 != null ? formatAmountForInput(account.projected_monthly_at_67) : "";
      document.getElementById("pension-disability").value = account.disability_pension_monthly != null ? formatAmountForInput(account.disability_pension_monthly) : "";
    } else {
      document.getElementById("pension-current-value").value = account.current_value != null ? formatAmountForInput(account.current_value) : "";
      document.getElementById("pension-contribution").value = account.monthly_contribution != null ? formatAmountForInput(account.monthly_contribution) : "";
      document.getElementById("pension-is-riester").checked = !!account.is_riester;
      // Wurde das Konto mit einem direkt eingetragenen Prognosewert angelegt,
      // muss der Schalter beim Bearbeiten auch wieder gesetzt sein — sonst
      // würde beim Speichern stillschweigend auf Hochrechnung umgestellt.
      if (account.projected_monthly_at_67 != null) {
        document.getElementById("pension-use-direct-value").checked = true;
        document.getElementById("pension-projected-private").value = formatAmountForInput(account.projected_monthly_at_67);
      }
    }
  }

  if (!isStatutory) {
    if (allContracts.length === 0) {
      allContracts = await (await authedFetch("/api/contracts")).json();
    }
    const linkedSelect = document.getElementById("pension-linked-contract");
    linkedSelect.innerHTML = '<option value="">– kein Vertrag verknüpft –</option>' +
      allContracts.map((c) => `<option value="${c.id}">${c.label}${c.provider ? ` · ${c.provider}` : ""} (${fmt(c.monthly_amount)}/Mon.)</option>`).join("");
    linkedSelect.value = account && account.linked_contract_id ? String(account.linked_contract_id) : "";
    updatePensionContributionLockState();
  }
  updatePensionDirectValueVisibility();
  pensionFormOverlay.style.display = "flex";
}

document.getElementById("pension-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const accountId = form.dataset.accountId;
  const type = form.dataset.type;
  const num = (id) => {
    return parseGermanNumber(document.getElementById(id).value);
  };

  const label = document.getElementById("pension-label").value.trim();
  if (!label) return alert("Bitte eine Bezeichnung angeben.");

  const payload = {
    label,
    provider: document.getElementById("pension-provider").value.trim() || null,
    note: document.getElementById("pension-note").value.trim() || null,
  };

  if (type === "gesetzlich") {
    const projected = num("pension-projected");
    if (projected === null) return alert("Bitte die voraussichtliche Rente mit 67 angeben.");
    payload.projected_monthly_at_67 = projected;
    payload.disability_pension_monthly = num("pension-disability");
  } else {
    const useDirect = document.getElementById("pension-use-direct-value").checked;
    payload.current_value = num("pension-current-value");
    payload.is_riester = document.getElementById("pension-is-riester").checked;
    const linkedContractId = document.getElementById("pension-linked-contract").value;
    payload.linked_contract_id = linkedContractId ? parseInt(linkedContractId, 10) : null;
    if (useDirect) {
      payload.projected_monthly_at_67 = num("pension-projected-private");
    } else {
      // Bei Verknüpfung kommt der Beitrag live vom Vertrag — hier nur
      // mitsenden, wenn NICHT verknüpft, sonst würde ein (gesperrter, aber
      // theoretisch noch im DOM vorhandener) Wert versehentlich überschreiben.
      if (!linkedContractId) {
        payload.monthly_contribution = num("pension-contribution");
      }
      payload.projected_monthly_at_67 = null;
    }
  }

  let targetId = accountId;
  if (accountId) {
    // Wurde der Beleg vorher analysiert (Knopf "Werte übernehmen"), auch
    // beim BEARBEITEN eines bestehenden Kontos mit anhängen -- vorher ging
    // das nur beim Neuanlegen.
    if (form.dataset.documentStagingId) {
      payload.document_staging_id = form.dataset.documentStagingId;
      payload.document_original_filename = form.dataset.documentOriginalFilename;
    }
    const res = await authedFetch(`/api/pension-accounts/${accountId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return alert(err.detail || "Fehler beim Speichern.");
    }
  } else {
    payload.person_id = parseInt(form.dataset.personId, 10);
    payload.type = type;
    // Wurde der Beleg vorher analysiert (Knopf "Werte übernehmen"), liegt die
    // Datei schon zwischengespeichert — direkt mit anhängen, statt sie nach
    // dem Anlegen ein zweites Mal hochzuladen.
    if (form.dataset.documentStagingId) {
      payload.document_staging_id = form.dataset.documentStagingId;
      payload.document_original_filename = form.dataset.documentOriginalFilename;
    }
    const res = await authedFetch("/api/pension-accounts", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return alert(err.detail || "Fehler beim Anlegen.");
    }
    targetId = (await res.json()).id;
  }

  // Datei manuell ausgewählt (egal ob neu angelegt oder bearbeitet), aber
  // "Werte übernehmen" nie geklickt (kein Analyse-Durchlauf) -> Datei
  // trotzdem ganz normal anhängen (ersetzt ein evtl. vorhandenes Dokument).
  const fileInput = document.getElementById("pension-document");
  if (!form.dataset.documentStagingId && fileInput.files.length && targetId) {
    const fd = new FormData();
    fd.append("file", fileInput.files[0]);
    await authedFetch(`/api/pension-accounts/${targetId}/document`, { method: "POST", body: fd });
  }

  pensionFormOverlay.style.display = "none";
  loadHaushaltSummary();
  vorsorgeLastRenteData = null;
  vorsorgeLastRisikoData = null;
  loadAufbauTab();
  loadAbsicherungTab();
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
  }
});

// ═══════════════════════════════════════════════════════════════
// VORSORGE: RISIKOABSICHERUNG
// ═══════════════════════════════════════════════════════════════

const ASSESSMENT_LABELS = {
  green: { text: "Gut abgesichert", cls: "settle-ok" },
  yellow: { text: "Prüfen", cls: "" },
  red: { text: "Lücke", cls: "settle-red" },
  present: { text: "Vorhanden", cls: "settle-ok" },
  unknown: { text: "Keine Bewertung möglich", cls: "" },
};

let pendingRiskCharts = [];

function renderRiskSharedContent(data) {
  const container = document.getElementById("risiko-shared-content");
  if (data.groups.length === 0 && data.missing_common_types.length === 0) {
    container.innerHTML = "";
    return;
  }

  // Sammelt alle Chart-Render-Aufrufe, die erst NACH dem Einfügen des HTML
  // in den DOM ausgeführt werden dürfen — hier unabhängig von der
  // Personen-Karte, deshalb eigener Reset/Flush.
  pendingRiskCharts = [];

  const householdNote = [];
  if (data.household.child_count > 0) {
    householdNote.push(`${data.household.child_count} Kind${data.household.child_count > 1 ? "er" : ""} im Haushalt — deshalb gilt der höhere Richtwert (5-8x statt 3-5x Jahresnetto) für die Risikolebensversicherung.`);
  }
  if (data.household.financing_monthly > 0) {
    householdNote.push(`Immobilienfinanzierung mit ${fmtEur0(data.household.financing_monthly)}/Monat läuft zusätzlich — im Ernstfall muss diese Rate weiter bezahlt werden können (nicht als Restschuld eingerechnet).`);
  }
  const noteHtml = householdNote.length
    ? `<p class="muted" style="font-size:0.75rem;margin:0 0 12px">💡 ${householdNote.join(" ")}</p>` : "";

  const missingHtml = data.missing_common_types.length ? `
    <section class="card">
      <div class="row-actions" style="align-items:flex-start;gap:16px;flex-wrap:wrap">
        <div id="essential-coverage-pie" style="flex-shrink:0"></div>
        <div style="flex:1;min-width:200px">
          <h3 style="margin:0 0 8px;font-size:0.9rem;color:var(--warn)">⚠️ Häufig empfohlen, aber nicht gefunden</h3>
          <ul>
            ${data.missing_common_types.map((m) => `
              <li style="flex-direction:column;align-items:flex-start;gap:2px">
                <span style="font-weight:600">${m.insurance_type}</span>
                <span class="muted" style="font-size:0.78rem">${m.reason}</span>
              </li>`).join("")}
          </ul>
        </div>
      </div>
    </section>` : "";
  if (data.essential_total > 0) {
    pendingRiskCharts.push(() => renderYesNoPieChart("essential-coverage-pie", data.essential_present, data.essential_total));
  }

  const groupsHtml = data.groups.map((g) => `
    <section class="card">
      <h3 style="margin:0 0 10px;font-size:0.95rem;color:var(--accent)">${g.insurance_type}</h3>
      <ul>
        ${g.entries.map((e) => {
          const a = ASSESSMENT_LABELS[e.assessment];
          let detail = "";
          if (e.income_replacement_rate != null) {
            detail = `${fmtEur0(e.bu_monthly_pension)}/Mo · ${e.income_replacement_rate}% des Nettos`;
          } else if (e.years_of_income_covered != null) {
            detail = `${fmtEur0(e.insurance_sum)} · deckt ${e.years_of_income_covered} Jahre Nettoeinkommen`;
          }
          return `
            <li>
              <span>${e.label}${e.person_name ? ` <span class="tag">${e.person_name}</span>` : ""}</span>
              <span class="row-actions">
                ${detail ? `<span class="muted" style="font-size:0.75rem">${detail}</span>` : ""}
                <span class="${a.cls}" style="font-size:0.8rem;font-weight:600">${a.text}</span>
              </span>
            </li>`;
        }).join("")}
      </ul>
    </section>
  `).join("");

  container.innerHTML = noteHtml + missingHtml + groupsHtml;
  pendingRiskCharts.forEach((fn) => fn());
  pendingRiskCharts = [];
}

function renderBuEmLine(combo) {
  if (!combo || combo.status === "unknown") return "";
  if (!combo.em_monthly) {
    return `<div class="settle-sub" style="margin:0 0 6px">Erwerbsminderungsrente noch nicht hinterlegt — steht auf der Renteninformation und lässt sich beim gesetzlichen Rentenkonto eintragen.</div>`;
  }
  const excess = combo.combined_monthly - combo.cap_hard;
  const warn = combo.status === "over"
    ? `<span class="settle-red">${fmtEur0(excess)}/Mo über dem Nettoeinkommen — das ist Überversicherung. Der Versicherer zahlt im Leistungsfall maximal das bisherige Netto, der Rest wird gekappt. Ihr zahlt also vermutlich Beiträge für eine Absicherung, die im Ernstfall gar nicht in voller Höhe ausgezahlt würde — lohnt sich, die BU-Rente mit dem Versicherer zu prüfen und ggf. zu reduzieren.</span>`
    : combo.status === "near_cap"
      ? `<span style="color:var(--warn)">nahe der üblichen Obergrenze (~80% des Nettos) — bei einer Erhöhung der BU-Rente prüft der Versicherer das genau.</span>`
      : `noch ${fmtEur0(combo.headroom_to_soft_cap)} Luft bis zur üblichen Obergrenze (~80% des Nettos).`;
  return `
    <div class="settle-sub" style="margin:0 0 6px">
      BU ${fmtEur0(combo.bu_monthly)} + Erwerbsminderungsrente ${fmtEur0(combo.em_monthly)}
      = <b>${fmtEur0(combo.combined_monthly)}/Mo</b> (${combo.combined_rate}% des Nettos) — ${warn}
    </div>`;
}

// ---------- Einheitlicher Deckungs-Balken: Ist-Wert vs. Sollbereich, Lücke sichtbar ----------
// Derselbe visuelle Grundtyp wie renderPensionGapChart bei der Rente — hier
// mit einem Sollbereich (Band) statt eines einzelnen Zielwerts, da BU/RLV
// als Spanne statt fixem Punkt empfohlen werden.
// ---------- BU-Deckungs-Chart: BU (voll) + Erwerbsminderungsrente
// (schraffiert) gestapelt, Sollbereich als Band, harte Obergrenze (Netto)
// als Linie — Überversicherung ist damit direkt sichtbar, ohne dass ein
// Kommentartext das erst erklären müsste. ----------
function renderBuCoverageChart(containerId, buAmount, emAmount, targetMin, targetMax, hardCap, status) {
  const el = document.getElementById(containerId);
  const W = 700, H = 50, padL = 4, padR = 4, padT = 20, barH = 20, barY = padT;
  const chartW = W - padL - padR;
  const total = buAmount + emAmount;
  const maxVal = Math.max(hardCap, total, targetMax, 1) * 1.08;
  const scale = (v) => (v / maxVal) * chartW;
  const cpBu = chartPalette();
  const color = status === "green" ? cpBu.primary : status === "yellow" ? cpBu.warn : cpBu.bad;
  const buW = Math.max(scale(buAmount), 0);
  const emW = Math.max(scale(emAmount), 0);
  const minX = padL + scale(targetMin);
  const maxX = padL + scale(targetMax);
  const capX = padL + scale(hardCap);
  const patternId = `hatch-${containerId}`;
  // Beschriftung an den rechten Rand klammern, damit sie bei einer Max-Linie
  // ganz rechts nicht seitlich abgeschnitten wird (gleiches Prinzip wie bei
  // der Ziel-Beschriftung im Vorsorge-Chart).
  const capLabel = "Max (100% Netto)";
  const approxHalfWidth = capLabel.length * 2.4;
  const capLabelX = Math.min(Math.max(capX, padL + approxHalfWidth), W - padR - approxHalfWidth);

  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
      <defs>
        <pattern id="${patternId}" width="6" height="6" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
          <rect width="6" height="6" fill="${color}" opacity="0.55" />
          <line x1="0" y1="0" x2="0" y2="6" stroke="${cpBu.onColor}" stroke-width="2.5" />
        </pattern>
      </defs>
      <rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="4" fill="rgba(255,255,255,0.06)" />
      <rect x="${minX}" y="${barY}" width="${Math.max(maxX - minX, 1)}" height="${barH}" fill="rgba(255,255,255,0.10)">
        <title>Sollbereich BU: ${fmtEur0(targetMin)} – ${fmtEur0(targetMax)}/Mo (60-80% des Nettos)</title>
      </rect>
      <rect x="${padL}" y="${barY}" width="${buW}" height="${barH}" rx="4" fill="${color}">
        <title>BU-Rente: ${fmtEur0(buAmount)}/Mo</title>
      </rect>
      ${emAmount > 0 ? `
      <rect x="${padL + buW}" y="${barY}" width="${emW}" height="${barH}" fill="url(#${patternId})">
        <title>+ Erwerbsminderungsrente: ${fmtEur0(emAmount)}/Mo (fließt bei einer BU-Prüfung mit ein)</title>
      </rect>` : ""}
      <line x1="${minX}" y1="${barY - 3}" x2="${minX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1" stroke-dasharray="2,2" opacity="0.6" />
      <line x1="${maxX}" y1="${barY - 3}" x2="${maxX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1.5" stroke-dasharray="2,2" />
      <line x1="${capX}" y1="${barY - 6}" x2="${capX}" y2="${barY + barH + 6}" stroke="${cpBu.bad}" stroke-width="1.5" />
      <text x="${capLabelX}" y="${padT - 8}" text-anchor="middle" font-size="10" fill="${cpBu.bad}">${capLabel}</text>
    </svg>`;
}

function renderCoverageBarChart(containerId, current, targetMin, targetMax, status) {
  const el = document.getElementById(containerId);
  const W = 700, H = 34, padL = 4, padR = 4, barH = 18, barY = 8;
  const chartW = W - padL - padR;
  const maxVal = Math.max(targetMax, current, 1) * 1.05;
  const scale = (v) => (v / maxVal) * chartW;
  const cpCov = chartPalette();
  const color = status === "green" ? cpCov.primary : status === "yellow" ? cpCov.warn : cpCov.bad;
  const currentW = Math.max(scale(current), 0);
  const minX = padL + scale(targetMin);
  const maxX = padL + scale(targetMax);

  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block">
      <rect x="${padL}" y="${barY}" width="${chartW}" height="${barH}" rx="4" fill="rgba(255,255,255,0.06)" />
      <rect x="${minX}" y="${barY}" width="${Math.max(maxX - minX, 1)}" height="${barH}" fill="rgba(255,255,255,0.10)">
        <title>Sollbereich: ${fmtEur0(targetMin)} – ${fmtEur0(targetMax)}</title>
      </rect>
      <rect x="${padL}" y="${barY}" width="${currentW}" height="${barH}" rx="4" fill="${color}">
        <title>Aktuell: ${fmtEur0(current)}</title>
      </rect>
      <line x1="${minX}" y1="${barY - 3}" x2="${minX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1" stroke-dasharray="2,2" opacity="0.6" />
      <line x1="${maxX}" y1="${barY - 3}" x2="${maxX}" y2="${barY + barH + 3}" stroke="var(--text)" stroke-width="1.5" stroke-dasharray="2,2" />
    </svg>`;
}

// ---------- Ja/Nein-Pie-Chart für boolesche Absicherungsfragen ----------
function renderYesNoPieChart(containerId, yesCount, totalCount) {
  const el = document.getElementById(containerId);
  const pct = totalCount > 0 ? (yesCount / totalCount) * 100 : 0;
  const radius = 42, stroke = 16, circumference = 2 * Math.PI * radius;
  const yesArc = (pct / 100) * circumference;
  const cpYn = chartPalette();
  const color = pct >= 100 ? cpYn.primary : pct >= 50 ? cpYn.warn : cpYn.bad;

  el.innerHTML = `
    <svg viewBox="0 0 120 120" width="130" height="130">
      <circle cx="60" cy="60" r="${radius}" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="${stroke}" />
      <circle cx="60" cy="60" r="${radius}" fill="none" stroke="${color}" stroke-width="${stroke}"
        stroke-dasharray="${yesArc} ${circumference}" stroke-linecap="round" transform="rotate(-90 60 60)">
        <title>${yesCount} von ${totalCount} vorhanden</title>
      </circle>
      <text x="60" y="56" text-anchor="middle" font-size="24" font-weight="700" fill="var(--text)">${yesCount}/${totalCount}</text>
      <text x="60" y="75" text-anchor="middle" font-size="10" fill="var(--muted)">vorhanden</text>
    </svg>`;
}

function renderRiskAssessmentLine(label, a, kind, emCombo) {
  if (a.assessment === "unknown") {
    return `<div class="settle-sub" style="margin-bottom:4px">${label}: kein Nettoeinkommen hinterlegt — keine Bewertung möglich.</div>`;
  }
  const chartId = `coverage-chart-${label.replace(/[^a-zA-Z0-9]/g, "")}-${Math.random().toString(36).slice(2, 8)}`;
  if (kind === "monthly") {
    const buAmount = a.bu_monthly_pension || 0;
    const emAmount = (emCombo && emCombo.em_monthly) || 0;
    const hardCap = (emCombo && emCombo.cap_hard) || a.target_max_monthly;
    pendingRiskCharts.push(() => renderBuCoverageChart(chartId, buAmount, emAmount, a.target_min_monthly, a.target_max_monthly, hardCap, a.assessment));
    return `
      <div style="margin-bottom:10px">
        <div class="settle-sub">${label}${emAmount > 0 ? " (schraffiert: + Erwerbsminderungsrente)" : ""}</div>
        <div id="${chartId}" style="margin:4px 0"></div>
      </div>`;
  }
  const current = a.insurance_sum || 0;
  const color = a.assessment === "green" ? "settle-ok" : a.assessment === "yellow" ? "" : "settle-red";
  pendingRiskCharts.push(() => renderCoverageBarChart(chartId, current, a.target_min_sum, a.target_max_sum, a.assessment));
  return `
    <div style="margin-bottom:6px">
      <div class="settle-sub">${label} — Soll ${fmtEur0(a.target_min_sum)}–${fmtEur0(a.target_max_sum)} (${a.target_multiple_min}-${a.target_multiple_max}x Jahresnetto)</div>
      <div id="${chartId}" style="margin:4px 0"></div>
      <div class="${color}" style="font-size:0.82rem;font-weight:600">
        Aktuell ${fmtEur0(current)} (${a.years_of_income_covered} Jahre)${a.assessment !== "green" ? ` — fehlen mind. ${fmtEur0(a.gap_to_min_sum)}` : " — im Sollbereich"}
      </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PERSONEN VERWALTEN (Stammdaten)
// ═══════════════════════════════════════════════════════════════

const familyMembersOverlay = document.getElementById("family-members-overlay");

async function loadFamilyMembersList() {
  allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  const list = document.getElementById("family-members-list");
  list.innerHTML = `
    <ul>
      ${allFamilyMembers.map((m) => `
        <li>
          <span style="flex:1"><b>${m.name}</b> <span class="tag">${m.role === "elternteil" ? "Elternteil" : "Kind"}</span></span>
          <span class="row-actions">
            <button type="button" class="ghost-btn" style="width:auto;padding:6px 12px;font-size:0.8rem" data-edit-member="${m.id}">✏️ Bearbeiten</button>
            <button class="del-btn" data-delete-member="${m.id}" title="Löschen">🗑</button>
          </span>
        </li>`).join("")}
    </ul>`;

  list.querySelectorAll("[data-edit-member]").forEach((btn) => {
    btn.addEventListener("click", () => openPersonDetailForm(btn.dataset.editMember));
  });

  list.querySelectorAll("[data-delete-member]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diese Person wirklich löschen? Verträge bleiben erhalten, verlieren aber die Zuordnung.")) return;
      await authedFetch(`/api/family-members/${btn.dataset.deleteMember}`, { method: "DELETE" });
      allFamilyMembers = [];
      loadFamilyMembersList();
    });
  });
}

document.getElementById("manage-family-members-btn").addEventListener("click", () => {
  familyMembersOverlay.style.display = "flex";
  loadFamilyMembersList();
});

document.getElementById("family-members-close-btn").addEventListener("click", () => {
  familyMembersOverlay.style.display = "none";
  if (document.getElementById("tab-vorsorge-dashboard").style.display !== "none") loadVorsorgeDashboard();
  if (document.getElementById("tab-vorsorge-aufbau").style.display !== "none") loadAufbauTab();
  if (document.getElementById("tab-vorsorge-absicherung").style.display !== "none") loadAbsicherungTab();
});

document.getElementById("add-family-member-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("new-member-name").value.trim();
  const role = document.getElementById("new-member-role").value;
  if (!name) return;
  const res = await authedFetch("/api/family-members", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, role }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.detail || "Fehler beim Anlegen.");
    return;
  }
  document.getElementById("add-family-member-form").reset();
  allFamilyMembers = [];
  loadFamilyMembersList();
});

// ═══════════════════════════════════════════════════════════════
// PV-ANLAGENDATEN (Strom → Produktion)
// ═══════════════════════════════════════════════════════════════

async function loadPvSystemSpecs() {
  const container = document.getElementById("pv-system-specs-content");
  container.innerHTML = '<p class="muted">Lade …</p>';
  const data = await (await authedFetch("/api/pv/system-specs")).json();

  if (data.specs.length === 0) {
    container.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Anlagendaten hinterlegt.</p>';
    return;
  }

  const currentId = data.current ? data.current.id : null;
  const upcomingIds = new Set(data.upcoming.map((s) => s.id));

  container.innerHTML = `
    <ul>
      ${data.specs.map((s) => {
        const isCurrent = s.id === currentId;
        const isUpcoming = upcomingIds.has(s.id);
        const badge = isCurrent ? `<span class="tag" style="background:${cssVarToRgba("--good", 0.15)};color:var(--good)">aktuell</span>`
          : isUpcoming ? `<span class="tag" style="background:${cssVarToRgba("--warn", 0.15)};color:var(--warn)">🔜 geplant</span>`
          : '<span class="muted" style="font-size:0.72rem">bis zur nächsten Änderung</span>';
        const specParts = [];
        if (s.kwp) specParts.push(`${s.kwp} kWp`);
        if (s.battery_kwh) specParts.push(`${s.battery_kwh} kWh Speicher`);
        if (s.installed_year) specParts.push(`Baujahr ${s.installed_year}`);
        return `
          <li data-pv-spec-row="${s.id}" style="cursor:context-menu;${isUpcoming ? "opacity:0.85" : ""}">
            <span>
              <b>ab ${s.valid_from}</b> — ${specParts.join(" · ") || "keine Werte hinterlegt"}
              ${s.note ? `<br><span class="muted" style="font-size:0.75rem">${s.note}</span>` : ""}
            </span>
            <span class="row-actions">
              ${badge}
              ${rowMenuButtonHTML("pvspec", s.id)}
            </span>
          </li>`;
      }).join("")}
    </ul>
    <p class="muted" style="font-size:0.72rem;margin:6px 0 0">Rechtsklick oder ⋯ auf einen Eintrag zum Bearbeiten oder Löschen.</p>`;

  container.querySelectorAll("[data-pv-spec-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuPvSpecId = row.dataset.pvSpecRow;
      showPvSpecContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(container, "pvspec", (id, x, y) => {
    contextMenuPvSpecId = id;
    showPvSpecContextMenu(x, y);
  });
}

let contextMenuPvSpecId = null;
const pvSpecContextMenu = document.getElementById("pv-spec-context-menu");

document.getElementById("pv-add-spec-btn").addEventListener("click", () => openPvSpecForm(null));

const pvSpecFormOverlay = document.getElementById("pv-spec-form-overlay");

async function openPvSpecForm(specId) {
  const form = document.getElementById("pv-spec-form");
  form.reset();
  form.dataset.specId = specId || "";
  document.getElementById("pv-spec-form-title").textContent = specId ? "🔧 Ausbauschritt bearbeiten" : "🔧 Ausbauschritt hinzufügen";

  if (specId) {
    const data = await (await authedFetch("/api/pv/system-specs")).json();
    const spec = data.specs.find((s) => String(s.id) === String(specId));
    if (spec) {
      document.getElementById("pv-spec-valid-from").value = spec.valid_from || "";
      document.getElementById("pv-spec-installed-year").value = spec.installed_year ?? "";
      document.getElementById("pv-spec-kwp").value = spec.kwp ?? "";
      document.getElementById("pv-spec-battery").value = spec.battery_kwh ?? "";
      document.getElementById("pv-spec-note").value = spec.note || "";
    }
  }
  pvSpecFormOverlay.style.display = "flex";
}

document.getElementById("pv-spec-form-cancel-btn").addEventListener("click", () => {
  pvSpecFormOverlay.style.display = "none";
});

document.getElementById("pv-spec-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const specId = e.target.dataset.specId;
  const validFrom = document.getElementById("pv-spec-valid-from").value;
  if (!validFrom) return alert("Bitte ein Gültig-ab-Datum angeben.");

  const yearStr = document.getElementById("pv-spec-installed-year").value.trim();
  const payload = {
    valid_from: validFrom,
    installed_year: yearStr ? parseInt(yearStr, 10) : null,
    kwp: parseGermanNumber(document.getElementById("pv-spec-kwp").value),
    battery_kwh: parseGermanNumber(document.getElementById("pv-spec-battery").value),
    note: document.getElementById("pv-spec-note").value.trim() || null,
  };

  const res = specId
    ? await authedFetch(`/api/pv/system-specs/${specId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      })
    : await authedFetch("/api/pv/system-specs", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    return alert(err.detail || "Fehler beim Speichern.");
  }
  pvSpecFormOverlay.style.display = "none";
  loadPvSystemSpecs();
});

function showPvSpecContextMenu(x, y) {
  pvSpecContextMenu.style.left = `${x}px`;
  pvSpecContextMenu.style.top = `${y}px`;
  pvSpecContextMenu.style.display = "block";
}

function hidePvSpecContextMenu() {
  pvSpecContextMenu.style.display = "none";
  contextMenuPvSpecId = null;
}

document.addEventListener("click", (e) => {
  if (!pvSpecContextMenu.contains(e.target)) hidePvSpecContextMenu();
});

pvSpecContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const id = contextMenuPvSpecId;
  hidePvSpecContextMenu();
  if (id) openPvSpecForm(id);
});

pvSpecContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const id = contextMenuPvSpecId;
  hidePvSpecContextMenu();
  if (!id || !confirm("Diesen Ausbauschritt wirklich löschen?")) return;
  await authedFetch(`/api/pv/system-specs/${id}`, { method: "DELETE" });
  loadPvSystemSpecs();
});

// ---------- Sticky Header: reale Höhe messen und als CSS-Variable
// bereitstellen, damit die Sidebar exakt darunter andockt statt sie zu
// überlappen oder eine Lücke zu lassen. Header-Höhe variiert je nach Gerät
// (env(safe-area-inset-top) bei Notch) und Textgrößen-Einstellung, daher
// nicht fest verdrahtet, sondern gemessen. ResizeObserver statt nur
// load/resize-Events, da ein einmaliges Messen bei manchen Browsern
// (insbesondere Safari) zu früh greifen kann, bevor der Header seine
// endgültige Höhe erreicht hat — der Observer reagiert zuverlässig auf
// jede tatsächliche Größenänderung. ----------
function updateHeaderHeightVar() {
  const header = document.querySelector("header");
  if (header) {
    document.documentElement.style.setProperty("--header-height", `${header.offsetHeight}px`);
  }
}
window.addEventListener("resize", updateHeaderHeightVar);
window.addEventListener("load", updateHeaderHeightVar);
updateHeaderHeightVar();

const headerEl = document.querySelector("header");
if (headerEl && typeof ResizeObserver !== "undefined") {
  new ResizeObserver(updateHeaderHeightVar).observe(headerEl);
}

// ==================== VERMÖGENSÜBERSICHT ====================
let allAssets = [];
let contextMenuAssetId = null;
const ASSET_TYPE_LABELS = { konto: "Konten", depot: "Depots", immobilie: "Immobilien", altersvorsorge: "Altersvorsorge", sonstiges: "Sonstiges" };
const ASSET_TYPE_ICONS = { konto: "🏦", depot: "📈", immobilie: "🏠", altersvorsorge: "👴", sonstiges: "💼" };

async function loadVermoegenOverview() {
  const data = await (await authedFetch("/api/vermoegen/overview")).json();
  allAssets = Object.entries(data.by_type)
    .flatMap(([type, items]) => (type === "altersvorsorge" ? items.filter((i) => i.source === "asset") : items));
  renderVermoegenSummaryCards(data.totals);
  renderVermoegenGroups(data.by_type);
  renderVermoegenRealEstateChart(data.real_estate_projection);
  renderVermoegenPieChart(data.pie_allocation);
  renderVermoegenAllocation(data.asset_allocation);
  renderVermoegenLiquidity(data.liquidity_reserve);
  populateVermoegenBulkDropdown(allAssets);
  loadVermoegenHistory();
  loadSteuerOverview();
  await applyBlockOrder("vermoegen-subtab-uebersicht", "vermoegen_uebersicht_order");
  setupBlockDragReorder("vermoegen-subtab-uebersicht", "vermoegen_uebersicht_order");
}

function renderVermoegenSummaryCards(totals) {
  const el = document.getElementById("vermoegen-summary-cards");
  el.className = "stats";
  el.innerHTML = `
    <div><span class="label">Gesamtvermögen</span><span>${fmt(totals.gesamt)}</span></div>
    <div><span class="label">Liquide Mittel &amp; Depots</span><span>${fmt(totals.liquid)}</span></div>
    <div><span class="label">Private Altersvorsorge</span><span>${fmt(totals.pension_capital)}</span></div>
    <div><span class="label">Immobilien netto</span><span>${fmt(totals.immobilien_netto)}</span></div>`;
}

function renderVermoegenGroups(byType) {
  const el = document.getElementById("vermoegen-groups");
  // Wie bei Ausgaben: aktuell aufgeklappte Gruppen merken, statt bei jeder
  // Aktualisierung (z.B. nach einem Beleg-Import) wieder alles einzuklappen.
  // Beim allerersten Laden ist damit automatisch alles eingeklappt.
  const expandedGroups = new Set(
    Array.from(el.querySelectorAll(".contract-list:not(.collapsed)")).map((ul) => ul.dataset.group)
  );
  const order = ["konto", "depot", "immobilie", "altersvorsorge", "sonstiges"];
  el.innerHTML = order.map((type) => {
    const items = byType[type] || [];
    const sum = items.reduce((s, a) => s + (a.current_value || 0), 0);
    const isAltersvorsorge = type === "altersvorsorge";
    const isExpanded = expandedGroups.has(type);
    return `
    <div class="contract-group">
      <h3 class="group-toggle" data-group="${type}">
        <span class="chevron">${isExpanded ? "▾" : "▸"}</span> ${ASSET_TYPE_ICONS[type]} ${ASSET_TYPE_LABELS[type]}
        <span class="group-sum">${fmt(sum)}</span>
      </h3>
      <ul class="contract-list${isExpanded ? "" : " collapsed"}" data-group="${type}">
        ${items.length === 0 ? `<li class="muted" style="padding:8px 0">${isAltersvorsorge ? "Noch nichts unter Vorsorge oder als Vertrag (Kategorie „Altersvorsorge“) hinterlegt." : "Noch nichts hinterlegt."}</li>` : items.map((a) => (isAltersvorsorge && a.source !== "asset") ? `
          <li data-external-row="${a.source}:${a.id}:${a.person_id || ""}" style="cursor:context-menu">
            <div class="contract-main">
              ${rowMenuButtonHTML("external", `${a.source}:${a.id}:${a.person_id || ""}`)}
              <span class="contract-label">${a.label}</span>
              ${a.provider ? `<span class="muted" style="font-size:0.78rem">${a.provider}</span>` : ""}
              ${a.person_name ? `<span class="tag">${a.person_name}</span>` : ""}
              <span class="tag" style="opacity:0.7" title="${a.source === "pension_account" ? "Rentenkonto unter Vorsorge" : "Vertrag unter Ausgaben"}">${a.source === "pension_account" ? "Vorsorge" : "Ausgaben"}</span>
            </div>
            <div class="contract-amount row-actions">
              <b>${fmt(a.current_value)}</b>
            </div>
          </li>` : `
          <li data-asset-row="${a.id}" style="cursor:context-menu">
            <div class="contract-main">
              ${rowMenuButtonHTML("asset", a.id)}
              <span class="contract-label">${a.label}</span>
              ${a.provider ? `<span class="muted" style="font-size:0.78rem">${a.provider}${a.account_number ? ` · ${a.account_number}` : ""}</span>` : (a.account_number ? `<span class="muted" style="font-size:0.78rem">${a.account_number}</span>` : "")}
              ${a.person_name ? `<span class="tag">${a.person_name}</span>` : ""}
              ${isAltersvorsorge ? '<span class="tag" style="opacity:0.7">Depot</span>' : ""}
              ${(a.financing_contracts || []).map((f) => `<span class="tag" title="Verknüpfter Finanzierungsvertrag">🔗 ${f.label}</span>`).join("")}
            </div>
            <div class="contract-amount row-actions">
              ${a.type === "immobilie" && a.total_remaining_debt > 0
                ? `<span class="muted" style="font-size:0.72rem" title="Restschuld unter Verbindlichkeiten">${fmt(a.total_remaining_debt)} Restschuld</span> <b>${fmt(a.current_value)}</b>`
                : a.type === "konto"
                ? `<b class="inline-editable-value" data-inline-edit-asset="${a.id}" data-raw-value="${a.current_value ?? 0}" title="Klicken zum Bearbeiten">${fmt(a.current_value)}</b>`
                : `<b>${fmt(a.current_value)}</b>`}
            </div>
          </li>`).join("")}
      </ul>
    </div>`;
  }).join("");

  el.querySelectorAll(".group-toggle").forEach((h3) => {
    h3.addEventListener("click", () => {
      const ul = el.querySelector(`.contract-list[data-group="${h3.dataset.group}"]`);
      ul.classList.toggle("collapsed");
      h3.querySelector(".chevron").textContent = ul.classList.contains("collapsed") ? "▸" : "▾";
    });
  });
  el.querySelectorAll("[data-asset-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuAssetId = row.dataset.assetRow;
      showAssetContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(el, "asset", (id, x, y) => {
    contextMenuAssetId = id;
    showAssetContextMenu(x, y);
  });
  wireInlineAssetValueEdit(el);

  el.querySelectorAll("[data-external-row]").forEach((row) => {
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuExternalKey = row.dataset.externalRow;
      showExternalContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(el, "external", (key, x, y) => {
    contextMenuExternalKey = key;
    showExternalContextMenu(x, y);
  });
}

let contextMenuExternalKey = null;
const externalContextMenu = document.getElementById("external-context-menu");

function showExternalContextMenu(x, y) {
  externalContextMenu.style.left = `${x}px`;
  externalContextMenu.style.top = `${y}px`;
  externalContextMenu.style.display = "block";
}
function hideExternalContextMenu() {
  externalContextMenu.style.display = "none";
  contextMenuExternalKey = null;
}
document.addEventListener("click", (e) => {
  if (!externalContextMenu.contains(e.target)) hideExternalContextMenu();
});

externalContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  const key = contextMenuExternalKey;
  hideExternalContextMenu();
  if (!key) return;
  openExternalAltersvorsorgeEntry(key);
});

externalContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  const key = contextMenuExternalKey;
  hideExternalContextMenu();
  if (!key) return;
  const [source, id] = key.split(":");
  if (source === "pension_account") {
    if (!confirm("Dieses Rentenkonto wirklich löschen?")) return;
    await authedFetch(`/api/pension-accounts/${id}`, { method: "DELETE" });
    loadHaushaltSummary();
    vorsorgeLastRenteData = null;
    vorsorgeLastRisikoData = null;
    loadAufbauTab();
    loadAbsicherungTab();
  } else {
    // "contract" (Altersvorsorge-Vertrag) und "financing" (Verbindlichkeiten)
    // sind beide derselbe zugrunde liegende Vertrag — dieselbe Archivieren-Logik.
    if (!confirm("Diesen Vertrag archivieren? Er verschwindet aus der aktiven Liste, Belege bleiben im Archiv erhalten.")) return;
    const res = await authedFetch(`/api/contracts/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(err.detail || "Fehler beim Archivieren.");
      return;
    }
    loadContracts();
    loadDashboard();
    loadReview();
  }
  if (document.getElementById("tab-vermoegen").style.display !== "none") {
    loadVermoegenOverview();
    if (document.getElementById("vermoegen-subtab-verbindlichkeiten").style.display !== "none") {
      loadVerbindlichkeiten();
    }
  }
});

function openExternalAltersvorsorgeEntry(key) {
  const [source, id, personId] = key.split(":");
  if (source === "pension_account") {
    openPensionForm(id, "privat", personId || null);
  } else if (source === "contract") {
    openDetailsModal(id);
  }
}

const assetContextMenu = document.getElementById("asset-context-menu");
function showAssetContextMenu(x, y) {
  assetContextMenu.style.left = `${x}px`;
  assetContextMenu.style.top = `${y}px`;
  assetContextMenu.style.display = "block";
}
document.addEventListener("click", (e) => {
  if (!assetContextMenu.contains(e.target)) assetContextMenu.style.display = "none";
});
assetContextMenu.querySelector('[data-action="edit"]').addEventListener("click", () => {
  assetContextMenu.style.display = "none";
  const asset = allAssets.find((a) => String(a.id) === String(contextMenuAssetId));
  if (asset) openAssetForm(asset.id, asset.type);
});
assetContextMenu.querySelector('[data-action="delete"]').addEventListener("click", async () => {
  assetContextMenu.style.display = "none";
  if (!confirm("Diesen Vermögenswert wirklich löschen? Zugehörige Belege werden mit entfernt.")) return;
  await authedFetch(`/api/assets/${contextMenuAssetId}`, { method: "DELETE" });
  loadVermoegenOverview();
});

document.querySelectorAll("[data-add-asset]").forEach((btn) => {
  btn.addEventListener("click", () => openAssetForm(null, btn.dataset.addAsset));
});

const assetFormOverlay = document.getElementById("asset-form-overlay");
let assetFormDocsCache = null;

async function openAssetForm(assetId, type) {
  const form = document.getElementById("asset-form");
  form.reset();
  form.dataset.assetId = assetId || "";
  form.dataset.type = type;
  document.getElementById("asset-form-title").textContent = `${ASSET_TYPE_ICONS[type]} ${type === "konto" ? "Konto" : type === "depot" ? "Depot" : type === "immobilie" ? "Immobilie" : "Sonstiger Vermögenswert"}`;
  document.getElementById("asset-value-label").textContent = type === "immobilie" ? "Aktueller Immobilienwert (€)" : "Aktueller Wert / Saldo (€)";

  if (allFamilyMembers.length === 0) {
    allFamilyMembers = await (await authedFetch("/api/family-members")).json();
  }
  const personSelect = document.getElementById("asset-person");
  personSelect.innerHTML = '<option value="">– gemeinsam/Haushalt –</option>' +
    allFamilyMembers.map((p) => `<option value="${p.id}">${p.name}</option>`).join("");

  const financingGroup = document.getElementById("asset-financing-link-group");
  let asset = null;
  if (assetId) asset = allAssets.find((a) => String(a.id) === String(assetId));
  const linkedIds = new Set((asset?.financing_contracts || []).map((f) => f.id));

  if (type === "immobilie") {
    financingGroup.style.display = "block";
    if (allContracts.length === 0) allContracts = await (await authedFetch("/api/contracts")).json();
    const financingContracts = allContracts.filter((c) => c.subcategory === "Finanzierung");
    const checkboxContainer = document.getElementById("asset-financing-checkboxes");
    if (financingContracts.length === 0) {
      checkboxContainer.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch kein Finanzierungsvertrag unter Ausgaben angelegt.</p>';
    } else {
      checkboxContainer.innerHTML = financingContracts.map((c) => `
        <label class="checkbox-label">
          <input type="checkbox" value="${c.id}" data-financing-checkbox ${linkedIds.has(c.id) ? "checked" : ""} />
          <span>${c.label} (Restschuld ${fmt(c.remaining_debt || 0)})</span>
        </label>`).join("");
    }
  } else {
    financingGroup.style.display = "none";
  }

  const purposeGroup = document.getElementById("asset-purpose-group");
  purposeGroup.style.display = type === "immobilie" ? "none" : "block";

  document.getElementById("asset-account-type-group").style.display = type === "konto" ? "block" : "none";

  const holdingsGroup = document.getElementById("asset-holdings-group");
  holdingsGroup.style.display = (type === "depot" && assetId) ? "block" : "none";
  if (type === "depot" && assetId) {
    await loadAssetHoldings(assetId);
  } else {
    document.getElementById("asset-holdings-list").innerHTML = "";
  }

  const showDocsBtn = document.getElementById("asset-show-documents-btn");
  const docsSection = document.getElementById("asset-documents-section");
  docsSection.style.display = "none";
  docsSection.innerHTML = "";
  assetFormDocsCache = null;

  if (assetId) {
    document.getElementById("asset-label").value = asset.label || "";
    document.getElementById("asset-provider").value = asset.provider || "";
    document.getElementById("asset-account-number").value = asset.account_number || "";
    document.getElementById("asset-account-type").value = asset.account_type || "";
    document.getElementById("asset-purpose").value = asset.purpose || "";
    document.getElementById("asset-person").value = asset.person_id || "";
    document.getElementById("asset-current-value").value = asset.current_value != null ? formatAmountForInput(asset.current_value) : "";
    document.getElementById("asset-note").value = asset.note || "";

    showDocsBtn.style.display = "block";
    assetFormDocsCache = await (await authedFetch(`/api/assets/${assetId}/receipts`)).json();
  } else {
    showDocsBtn.style.display = "none";
  }

  assetFormOverlay.style.display = "flex";
}

document.getElementById("asset-form-cancel-btn").addEventListener("click", () => {
  assetFormOverlay.style.display = "none";
});

document.getElementById("asset-show-documents-btn").addEventListener("click", () => {
  const section = document.getElementById("asset-documents-section");
  const isOpen = section.style.display !== "none";
  if (isOpen) { section.style.display = "none"; return; }
  section.style.display = "block";
  const docs = assetFormDocsCache || [];
  if (docs.length === 0) {
    section.innerHTML = '<p class="muted" style="font-size:0.8rem">Noch keine Belege hinterlegt.</p>';
    return;
  }
  section.innerHTML = '<div id="asset-documents-list"></div>';
  setupScrollableDocList("asset-documents-list", docs, (d) => resolveDocDate(d), (filtered, ul) => {
    ul.innerHTML = filtered.map((d) => `
      <li data-asset-doc-row="${d.id}">
        <a href="/api/receipts/${d.id}/file" rel="noopener" data-view-doc-url="/api/receipts/${d.id}/file" data-view-doc-title="${d.original_filename || "Beleg"}">📎 ${d.original_filename || "Beleg"}</a>
        <span class="row-actions">
          <span class="muted" style="font-size:0.72rem">${resolveDocDate(d) || ""}${d.detected_amount ? ` · ${fmt(d.detected_amount)}` : ""}</span>
          <a href="/api/receipts/${d.id}/file?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
          <button type="button" class="ghost-btn" data-reassign-receipt="${d.id}" title="Zu anderem Vermögenswert verschieben" style="padding:2px 6px;font-size:0.85rem">🔀</button>
          <button type="button" class="del-btn" data-delete-asset-receipt="${d.id}" title="Löschen">🗑</button>
        </span>
      </li>`).join("");
    wireDocumentViewerLinks(ul);

    ul.querySelectorAll("[data-delete-asset-receipt]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        if (!confirm("Diesen Beleg wirklich löschen?")) return;
        await authedFetch(`/api/receipts/${btn.dataset.deleteAssetReceipt}`, { method: "DELETE" });
        const form = document.getElementById("asset-form");
        await openAssetForm(form.dataset.assetId, form.dataset.type);
        document.getElementById("asset-show-documents-btn").click();
      });
    });

    ul.querySelectorAll("[data-reassign-receipt]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const li = btn.closest("li");
        if (li.querySelector(".reassign-inline")) return; // schon offen
        const currentAssetId = document.getElementById("asset-form").dataset.assetId;
        const options = allAssets.filter((a) => String(a.id) !== String(currentAssetId));
        const inline = document.createElement("div");
        inline.className = "reassign-inline";
        inline.style.cssText = "margin-top:6px;display:flex;gap:6px;width:100%";
        inline.innerHTML = `
          <select style="flex:1">${options.map((a) => `<option value="${a.id}">${ASSET_TYPE_ICONS[a.type]} ${a.label}</option>`).join("")}</select>
          <button type="button" class="ghost-btn" style="flex-shrink:0">Verschieben</button>`;
        li.appendChild(inline);
        inline.querySelector("button").addEventListener("click", async () => {
          const newAssetId = parseInt(inline.querySelector("select").value, 10);
          await authedFetch(`/api/receipts/${btn.dataset.reassignReceipt}/reassign-asset`, {
            method: "PATCH", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ asset_id: newAssetId }),
          });
          const form = document.getElementById("asset-form");
          await openAssetForm(form.dataset.assetId, form.dataset.type);
          document.getElementById("asset-show-documents-btn").click();
          loadVermoegenOverview();
        });
      });
    });
  });
});

document.getElementById("asset-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const assetId = form.dataset.assetId;
  const type = form.dataset.type;
  const payload = {
    type,
    label: document.getElementById("asset-label").value.trim(),
    provider: document.getElementById("asset-provider").value.trim() || null,
    account_number: document.getElementById("asset-account-number").value.trim() || null,
    account_type: document.getElementById("asset-account-type").value || null,
    purpose: document.getElementById("asset-purpose").value || null,
    person_id: document.getElementById("asset-person").value ? parseInt(document.getElementById("asset-person").value, 10) : null,
    current_value: parseGermanNumber(document.getElementById("asset-current-value").value),
    note: document.getElementById("asset-note").value.trim() || null,
  };
  if (type === "immobilie") {
    payload.financing_contract_ids = [...document.querySelectorAll("[data-financing-checkbox]:checked")]
      .map((cb) => parseInt(cb.value, 10));
  }
  if (assetId) {
    await authedFetch(`/api/assets/${assetId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
  } else {
    await authedFetch("/api/assets", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
  }
  assetFormOverlay.style.display = "none";
  loadVermoegenOverview();
});

async function populateVermoegenBulkDropdown(assets) {
  const select = document.getElementById("vermoegen-bulk-asset");
  if (!select) return;
  const previousValue = select.value;
  const pensionAccounts = await (await authedFetch("/api/pension-accounts")).json();

  const assetOptions = assets.map((a) => `<option value="asset:${a.id}">${ASSET_TYPE_ICONS[a.type]} ${a.label}</option>`).join("");
  const pensionOptions = pensionAccounts.map((p) =>
    `<option value="pension:${p.id}">🛡️ ${p.label}${p.person_name ? ` (${p.person_name})` : ""}</option>`
  ).join("");

  select.innerHTML = `
    ${assetOptions ? `<optgroup label="Vermögenswerte">${assetOptions}</optgroup>` : ""}
    ${pensionOptions ? `<optgroup label="Vorsorge / Rentenkonten">${pensionOptions}</optgroup>` : ""}`;
  if (previousValue) select.value = previousValue;
}

document.getElementById("vermoegen-bulk-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("vermoegen-bulk-input");
  const targetSelect = document.getElementById("vermoegen-bulk-asset");
  const resultDiv = document.getElementById("vermoegen-bulk-result");
  if (!input.files.length) { resultDiv.textContent = "Bitte zuerst eine oder mehrere Dateien auswählen."; return; }
  if (!targetSelect.value) { resultDiv.textContent = "Bitte zuerst einen Vermögenswert oder ein Rentenkonto anlegen."; return; }
  const [kind, id] = targetSelect.value.split(":");
  resultDiv.textContent = `Importiere ${input.files.length} Dateien …`;
  const formData = new FormData();
  for (const file of input.files) formData.append("files", file);
  const endpoint = kind === "pension"
    ? `/api/pension-accounts/${id}/bulk-upload-documents`
    : `/api/assets/${id}/bulk-upload-receipts`;
  const res = await authedFetch(endpoint, { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) { resultDiv.textContent = data.detail || "Fehler beim Import."; return; }
  const skipped = data.results.filter((r) => r.skipped);
  resultDiv.innerHTML = `
    <p style="margin:4px 0 0">✅ ${data.count} Datei${data.count === 1 ? "" : "en"} verarbeitet${skipped.length ? `, davon ${skipped.length} bereits vorhanden (übersprungen)` : ""}.</p>
    <p class="muted" style="font-size:0.75rem;margin:2px 0 0">Der aktuelle Wert wurde dabei bewusst nicht verändert.</p>`;
  input.value = "";
});

// ---------- Einzel-Beleg-Upload mit OCR, Zuordnung zu einem Vermögenswert ----------
document.getElementById("vermoegen-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("vermoegen-receipt-input");
  const resultDiv = document.getElementById("vermoegen-upload-result");
  if (!input.files.length) { resultDiv.textContent = "Bitte zuerst eine Datei auswählen."; return; }
  resultDiv.innerHTML = '<p class="muted">Lade hoch und lese aus …</p>';
  const formData = new FormData();
  formData.append("file", input.files[0]);
  const res = await authedFetch("/api/receipts/upload", { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) { resultDiv.textContent = data.detail || "Fehler beim Hochladen."; return; }

  const detected = data.detected;
  const pensionAccounts = await (await authedFetch("/api/pension-accounts")).json();
  const assetOptions = allAssets.map((a) => `<option value="asset:${a.id}">${ASSET_TYPE_ICONS[a.type]} ${a.label}</option>`).join("");
  const pensionOptions = pensionAccounts.map((p) =>
    `<option value="pension:${p.id}">🛡️ ${p.label}${p.person_name ? ` (${p.person_name})` : ""}</option>`
  ).join("");

  resultDiv.innerHTML = `
    <p class="muted" style="font-size:0.78rem">Erkannt: ${detected.provider || "kein Anbieter"}${detected.amount != null ? ` · ${fmt(detected.amount)}` : ""}</p>
    <label class="muted" style="font-size:0.8rem">Betrag / Wert (€)</label>
    <input type="text" id="vermoegen-confirm-amount" inputmode="decimal" value="${detected.amount != null ? formatAmountForInput(detected.amount) : ""}" />
    <label class="muted" style="font-size:0.8rem">Zu welchem Vermögenswert oder Rentenkonto gehört das?</label>
    <select id="vermoegen-confirm-asset">
      ${assetOptions ? `<optgroup label="Vermögenswerte">${assetOptions}</optgroup>` : ""}
      ${pensionOptions ? `<optgroup label="Vorsorge / Rentenkonten">${pensionOptions}</optgroup>` : ""}
    </select>
    <label class="checkbox-label">
      <input type="checkbox" id="vermoegen-confirm-update-value" checked />
      <span>Aktuellen Wert aktualisieren</span>
    </label>
    <button type="button" id="vermoegen-confirm-btn" class="ghost-btn" style="width:100%;margin-top:8px">Bestätigen &amp; übernehmen</button>`;

  document.getElementById("vermoegen-confirm-btn").addEventListener("click", async () => {
    const targetValue = document.getElementById("vermoegen-confirm-asset").value;
    if (!targetValue) { alert("Bitte zuerst einen Vermögenswert oder ein Rentenkonto anlegen."); return; }
    const [kind, id] = targetValue.split(":");
    const amount = parseGermanNumber(document.getElementById("vermoegen-confirm-amount").value);
    const updateValue = document.getElementById("vermoegen-confirm-update-value").checked;
    const payload = { amount, update_expense: updateValue };
    if (kind === "pension") payload.pension_account_id = parseInt(id, 10);
    else payload.asset_id = parseInt(id, 10);
    await authedFetch(`/api/receipts/${data.receipt_id}/confirm`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    resultDiv.innerHTML = '<p style="color:var(--good)">✅ Übernommen.</p>';
    input.value = "";
    loadVermoegenOverview();
  });
});

// ---------- Intelligenter Datei-Import für Vermögenswerte — nutzt dieselbe
// generische Spalten-Zuordnungs-Infrastruktur wie Ausgaben/Einnahmen/Verträge. ----------
initSmartImport("smart-import-vermoegen", () => "assets", () => ({}), () => loadVermoegenOverview());

function renderVermoegenRealEstateChart(projection) {
  const card = document.getElementById("vermoegen-real-estate-chart-card");
  if (!projection || projection.length === 0) {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-real-estate-chart");
  const cp2 = chartPalette();
  renderInteractiveMultiLineChart(el, projection, [
    { key: "property_value", label: "Immobilienwert", color: cp2.neutral, width: 2, dashed: true, fill: false },
    { key: "remaining_debt", label: "Restschuld", color: cp2.bad, width: 2, fill: false },
    { key: "net_value", label: "Nettovermögen", color: cp2.primary, width: 2.5 },
  ], { xLabel: (p) => p.year });
}

// ---------- Depot-Positionen (Holdings) ----------
const ASSET_CLASS_LABELS = { aktie: "Aktie", anleihe: "Anleihe", cash: "Cash", rohstoffe: "Rohstoffe", sonstiges: "Sonstiges" };
const REGION_LABELS = {
  usa: "USA", europa: "Europa", schwellenlaender: "Schwellenländer",
  sonstige_industrielaender: "Sonstige Industrieländer", global: "Global", sonstiges: "Sonstiges",
};

async function loadAssetHoldings(assetId) {
  const holdings = await (await authedFetch(`/api/assets/${assetId}/holdings`)).json();
  renderAssetHoldings(assetId, holdings);
}

function renderAssetHoldings(assetId, holdings) {
  const el = document.getElementById("asset-holdings-list");
  if (holdings.length === 0) {
    el.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Positionen erfasst.</p>';
    return;
  }
  const total = holdings.reduce((s, h) => s + (h.current_value || 0), 0);
  el.innerHTML = holdings.map((h) => `
    <div class="row-actions" style="justify-content:space-between;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.06)">
      <span style="font-size:0.82rem">
        ${h.name}${h.isin ? ` <span class="muted" style="font-size:0.7rem">${h.isin}</span>` : ""}<br>
        <span class="muted" style="font-size:0.72rem">${h.asset_class ? ASSET_CLASS_LABELS[h.asset_class] || h.asset_class : "Klasse?"} · ${h.region ? REGION_LABELS[h.region] || h.region : "Region?"}</span>
      </span>
      <span style="text-align:right;font-size:0.82rem">
        ${fmt(h.current_value)}<br>
        <span class="muted" style="font-size:0.72rem">${total > 0 ? Math.round((h.current_value / total) * 100) : 0}%</span>
        <button type="button" class="del-btn" data-delete-holding="${h.id}" title="Löschen" style="margin-left:4px">🗑</button>
      </span>
    </div>`).join("");

  el.querySelectorAll("[data-delete-holding]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Diese Position wirklich löschen?")) return;
      await authedFetch(`/api/asset-holdings/${btn.dataset.deleteHolding}`, { method: "DELETE" });
      loadAssetHoldings(assetId);
    });
  });
}

document.getElementById("asset-add-holding-btn").addEventListener("click", async () => {
  const assetId = document.getElementById("asset-form").dataset.assetId;
  if (!assetId) return;
  const name = document.getElementById("asset-holding-name").value.trim();
  const value = parseGermanNumber(document.getElementById("asset-holding-value").value);
  if (!name || value == null || Number.isNaN(value)) {
    alert("Bitte mindestens Name und Wert angeben.");
    return;
  }
  await authedFetch(`/api/assets/${assetId}/holdings`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name,
      isin: document.getElementById("asset-holding-isin").value.trim() || null,
      current_value: value,
      asset_class: document.getElementById("asset-holding-class").value || null,
      region: document.getElementById("asset-holding-region").value || null,
    }),
  });
  document.getElementById("asset-holding-name").value = "";
  document.getElementById("asset-holding-isin").value = "";
  document.getElementById("asset-holding-value").value = "";
  document.getElementById("asset-holding-class").value = "";
  document.getElementById("asset-holding-region").value = "";
  loadAssetHoldings(assetId);
});

// ---------- Asset-Allokation (Vermögensübersicht) ----------
function renderVermoegenAllocation(allocation) {
  const card = document.getElementById("vermoegen-allocation-card");
  if (!allocation || !allocation.total_value) {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-allocation-charts");

  const renderBar = (title, items) => `
    <div>
      <h3 style="font-size:0.85rem;margin:0 0 8px">${title}</h3>
      ${items.map((item) => `
        <div style="margin-bottom:6px">
          <div class="row-actions" style="justify-content:space-between;font-size:0.78rem">
            <span>${ASSET_CLASS_LABELS[item.key] || REGION_LABELS[item.key] || item.key}</span>
            <span>${item.percent}%${item.target_percent != null ? ` <span class="muted">(Soll ${item.target_percent}%${item.deviation ? `, ${item.deviation > 0 ? "+" : ""}${item.deviation}` : ""})</span>` : ""}</span>
          </div>
          <div style="background:rgba(255,255,255,0.08);border-radius:4px;height:6px;overflow:hidden;position:relative">
            <div style="background:${item.deviation != null && Math.abs(item.deviation) > 10 ? "var(--warn)" : "var(--accent)"};height:100%;width:${item.percent}%"></div>
            ${item.target_percent != null ? `<div style="position:absolute;top:0;bottom:0;left:${item.target_percent}%;width:2px;background:var(--text)"></div>` : ""}
          </div>
        </div>`).join("")}
    </div>`;

  el.innerHTML = renderBar("Nach Anlageklasse", allocation.by_class) + renderBar("Nach Region", allocation.by_region);
}

// ---------- Ziel-Allokation festlegen ----------
const allocationTargetsOverlay = document.getElementById("allocation-targets-overlay");
const ALLOCATION_TARGET_FIELDS = ["aktie", "anleihe", "cash", "rohstoffe", "sonstiges"];

document.getElementById("vermoegen-set-targets-btn").addEventListener("click", async () => {
  const current = await (await authedFetch("/api/vermoegen/allocation-targets")).json();
  const currentMap = Object.fromEntries(current.map((t) => [t.asset_class, t.target_percent]));
  for (const cls of ALLOCATION_TARGET_FIELDS) {
    document.getElementById(`target-${cls}`).value = currentMap[cls] ?? "";
  }
  allocationTargetsOverlay.style.display = "flex";
});

document.getElementById("allocation-targets-cancel-btn").addEventListener("click", () => {
  allocationTargetsOverlay.style.display = "none";
});

document.getElementById("allocation-targets-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const values = [];
  for (const cls of ALLOCATION_TARGET_FIELDS) {
    const raw = document.getElementById(`target-${cls}`).value.trim();
    if (raw === "") continue;
    const num = parseGermanNumber(raw);
    if (num != null && !Number.isNaN(num)) values.push({ asset_class: cls, target_percent: num });
  }
  await authedFetch("/api/vermoegen/allocation-targets", {
    method: "PUT", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(values),
  });
  allocationTargetsOverlay.style.display = "none";
  loadVermoegenOverview();
});

// ---------- Liquiditätsreserve ----------
function renderVermoegenLiquidity(reserve) {
  const card = document.getElementById("vermoegen-liquidity-card");
  if (!reserve || reserve.status === "unbekannt") {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-liquidity-content");
  const color = reserve.status === "gut" ? "var(--good)" : "var(--warn)";
  const icon = reserve.status === "gut" ? "✅" : "⚠️";
  const hint = reserve.status === "niedrig"
    ? '<p class="muted" style="font-size:0.78rem;margin:4px 0 0">Unter der empfohlenen 3-Monats-Grenze.</p>'
    : reserve.status === "zu_viel"
    ? '<p class="muted" style="font-size:0.78rem;margin:4px 0 0">Deutlich über den empfohlenen 3–6 Monaten — das überschüssige Kapital arbeitet auf dem Konto nicht, eine Anlage außerhalb der Reserve könnte sich lohnen.</p>'
    : "";
  el.innerHTML = `
    <p style="font-size:0.95rem;margin:0 0 6px">${icon} <b style="color:${color}">${reserve.months_covered} Monate</b> auf Konten verfügbar</p>
    <p class="muted" style="font-size:0.78rem;margin:0">${fmt(reserve.total_konten)} Kontostand ÷ ${fmt(reserve.monthly_fixed_expenses)} monatliche Fixkosten</p>
    ${hint}`;
}

// ---------- Vermögens-Historie ----------
async function loadVermoegenHistory() {
  const history = await (await authedFetch("/api/vermoegen/history")).json();
  renderVermoegenHistory(history);
}

function renderVermoegenHistory(history) {
  const card = document.getElementById("vermoegen-history-chart-card");
  card.style.display = "block";
  const el = document.getElementById("vermoegen-history-chart");

  if (!history || history.length < 2) {
    const count = history ? history.length : 0;
    el.innerHTML = `<p class="muted" style="font-size:0.85rem">Noch nicht genug Verlaufsdaten (${count} von mindestens 2 Tagen vorhanden). Es wird täglich ein Datenpunkt gespeichert — ab morgen erscheint hier der Verlauf.</p>`;
    return;
  }

  const cp3 = chartPalette();
  renderInteractiveMultiLineChart(el, history, [
    { key: "total_networth", color: cp3.primary, label: "Gesamtvermögen", width: 2.5 },
    { key: "liquid", color: cp3.accent, label: "Liquide Mittel & Depots", width: 2, fill: false },
    { key: "pension_capital", color: cp3.warn, label: "Private Altersvorsorge", width: 2, fill: false },
    { key: "immobilien_netto", color: cp3.purple, label: "Immobilien netto", width: 2, fill: false },
  ], { xLabel: (p) => p.snapshot_date });
}

// ---------- Steuer & Förderung ----------
async function loadSteuerOverview() {
  const data = await (await authedFetch("/api/steuer/overview")).json();
  renderSteuerOverview(data);
}

function renderSteuerOverview(data) {
  const el = document.getElementById("steuer-content");
  let html = "";

  if (data.freistellungsauftrag.length > 0) {
    html += `<h3 style="font-size:0.85rem;margin:0 0 8px">Freistellungsauftrag (Sparerpauschbetrag 2026: 1.000 €/Person)</h3>`;
    html += data.freistellungsauftrag.map((f) => `
      <div class="row-actions" style="justify-content:space-between;font-size:0.85rem;padding:4px 0">
        <span>${f.person_name}</span>
        <span>${fmt(f.used)} genutzt · <b style="color:${f.remaining >= 0 ? "var(--good)" : "var(--bad)"}">${fmt(f.remaining)} frei</b></span>
      </div>`).join("");
    html += `<p class="muted" style="font-size:0.72rem;margin:6px 0 0">Genutzten Betrag unter Einstellungen → Personen pflegen.</p>`;
  } else {
    html += '<p class="muted" style="font-size:0.85rem">Keine Elternteile hinterlegt.</p>';
  }

  html += `<div class="divider"></div><h3 style="font-size:0.85rem;margin:0 0 8px">Riester-Förderung</h3>`;
  if (data.riester.length > 0) {
    html += data.riester.map((r) => `
      <div style="padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.06)">
        <div class="row-actions" style="justify-content:space-between;font-size:0.85rem">
          <span>${r.label}${r.provider ? ` · ${r.provider}` : ""} <span class="tag">${r.person_name}</span></span>
          <b>${fmt(r.zulage_gesamt_max)}/Jahr</b>
        </div>
        <p class="muted" style="font-size:0.72rem;margin:2px 0 0">${fmt(r.grundzulage)} Grundzulage + bis zu ${fmt(r.kinderzulage_max)} Kinderzulage</p>
      </div>`).join("");
    html += `<p class="muted" style="font-size:0.72rem;margin:6px 0 0">${data.riester_note}</p>`;
  } else {
    html += '<p class="muted" style="font-size:0.85rem">Kein Riester-Vertrag als solcher markiert (unter Vorsorge → Rentenkonto bearbeiten).</p>';
  }

  el.innerHTML = html;
}

// ---------- Vermögen: Unter-Reiter (Übersicht / Vermögen / Verbindlichkeiten) ----------
document.querySelectorAll(".vermoegen-subtab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".vermoegen-subtab-btn").forEach((b) => b.classList.toggle("active-scale", b === btn));
    document.querySelectorAll(".vermoegen-subtab-panel").forEach((panel) => {
      panel.style.display = panel.id === `vermoegen-subtab-${btn.dataset.vsubtab}` ? "block" : "none";
    });
    if (btn.dataset.vsubtab === "verbindlichkeiten") loadVerbindlichkeiten();
  });
});

let verbindlichkeitenSelectedId = null;

document.getElementById("add-financing-btn").addEventListener("click", () => openAddExpenseForm("Haus::Finanzierung"));

async function loadVerbindlichkeiten() {
  if (allContracts.length === 0) allContracts = await (await authedFetch("/api/contracts")).json();
  const data = await (await authedFetch("/api/verbindlichkeiten/overview")).json();
  renderVerbindlichkeitenSummary(data);
  renderVerbindlichkeitenList();
  renderVerbindlichkeitenChart(data);
}

function renderVerbindlichkeitenSummary(data) {
  const stats = document.getElementById("verbindlichkeiten-summary-stats");
  stats.innerHTML = `
    <div><span class="label">Gesamte Restschuld</span><span>${fmt(data.total_remaining_debt)}</span></div>
    <div><span class="label">Ø Zinssatz (gewichtet)</span><span>${data.average_interest_rate != null ? data.average_interest_rate + " %" : "–"}</span></div>`;

  const locksEl = document.getElementById("verbindlichkeiten-rate-locks");
  if (!data.upcoming_rate_locks || data.upcoming_rate_locks.length === 0) {
    locksEl.innerHTML = "";
    return;
  }
  locksEl.innerHTML = `
    <div class="divider"></div>
    <h3 style="font-size:0.85rem;margin:0 0 8px">Anstehende Zinsbindungsenden</h3>
    ${data.upcoming_rate_locks.map((l) => `
      <div class="row-actions" style="justify-content:space-between;font-size:0.85rem;padding:3px 0">
        <span>${l.label}</span>
        <span>${l.contract_end} <span class="muted">(${fmt(l.remaining_debt)})</span></span>
      </div>`).join("")}`;
}

function renderVerbindlichkeitenList() {
  const el = document.getElementById("verbindlichkeiten-list");
  const financings = allContracts.filter((c) => c.subcategory === "Finanzierung" && c.status === "active");

  if (financings.length === 0) {
    el.innerHTML = '<p class="muted">Keine laufende Finanzierung unter Ausgaben hinterlegt.</p>';
    return;
  }

  el.innerHTML = `<ul class="contract-list">${financings.map((f) => {
    // Manche Nutzer tragen den Anbieter bereits als Teil des Labels ein
    // (z.B. "BBBank e.G. DE70...") -- den Anbieter dann NICHT nochmal
    // separat anzeigen, sonst erscheint er doppelt und ohne sichtbaren
    // Abstand (Flex-Gap zwischen den Elementen ist bewusst klein).
    const showProvider = f.provider && !f.label.includes(f.provider);
    const fixedUntil = f.fixed_interest_until
      ? new Date(f.fixed_interest_until).toLocaleDateString("de-DE", { month: "2-digit", year: "numeric" })
      : null;
    return `
    <li data-financing-row="${f.id}" style="cursor:pointer;flex-wrap:wrap;${String(f.id) === String(verbindlichkeitenSelectedId) ? `background:${cssVarToRgba("--accent", 0.08)}` : ""}">
      <div class="contract-main">
        ${rowMenuButtonHTML("financing", f.id)}
        <span class="contract-label">${f.label}</span>
        ${showProvider ? `<span class="muted" style="font-size:0.78rem"> · ${f.provider}</span>` : ""}
      </div>
      <div class="contract-amount row-actions" style="justify-content:flex-end;flex-wrap:wrap;gap:4px 10px;width:100%">
        <span class="row-actions" style="gap:4px">
          <input type="text" class="inline-amount" data-financing-debt="${f.id}" value="${formatAmountForInput(f.remaining_debt)}" inputmode="decimal" style="width:130px;text-align:right" />
          <span class="muted" style="font-size:0.78rem">€</span>
        </span>
        <span class="muted" style="font-size:0.75rem;white-space:nowrap">${f.interest_rate || 0}% Zins${fixedUntil ? ` · Bindung bis ${fixedUntil}` : ""}</span>
      </div>
    </li>`;
  }).join("")}</ul>`;

  el.querySelectorAll("[data-financing-debt]").forEach((input) => {
    input.addEventListener("click", (e) => e.stopPropagation());
    input.addEventListener("change", async (e) => {
      e.stopPropagation();
      const remaining_debt = parseGermanNumber(input.value);
      if (Number.isNaN(remaining_debt)) return alert("Ungültiger Betrag");
      await patchJSON(`/api/contracts/${input.dataset.financingDebt}`, { remaining_debt });
      allContracts = [];
      loadVerbindlichkeiten();
    });
  });

  el.querySelectorAll("[data-financing-row]").forEach((row) => {
    row.addEventListener("click", (e) => {
      if (e.target.closest("[data-row-menu-trigger]")) return;
      const id = row.dataset.financingRow;
      verbindlichkeitenSelectedId = (String(verbindlichkeitenSelectedId) === String(id)) ? null : id;
      renderVerbindlichkeitenList();
      loadVerbindlichkeitenChartForSelection();
    });
    row.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      contextMenuExternalKey = `contract:${row.dataset.financingRow}`;
      showExternalContextMenu(e.pageX, e.pageY);
    });
  });
  wireRowMenuButtons(el, "financing", (id, x, y) => {
    contextMenuExternalKey = `contract:${id}`;
    showExternalContextMenu(x, y);
  });
}

async function renderVerbindlichkeitenChart(overviewData) {
  const title = document.getElementById("verbindlichkeiten-chart-title");
  const container = document.getElementById("verbindlichkeiten-chart");
  if (verbindlichkeitenSelectedId) {
    const financing = allContracts.find((c) => String(c.id) === String(verbindlichkeitenSelectedId));
    title.textContent = `📈 Tilgungsplan — ${financing ? financing.label : ""}`;
    const res = await authedFetch(`/api/contracts/${verbindlichkeitenSelectedId}/repayment-schedule`);
    renderRepaymentChart("verbindlichkeiten-chart", await res.json());
  } else {
    title.textContent = "📈 Tilgungsplan — alle Finanzierungen zusammen";
    renderRepaymentChart("verbindlichkeiten-chart", overviewData.aggregated_schedule);
  }
}

async function loadVerbindlichkeitenChartForSelection() {
  const data = await (await authedFetch("/api/verbindlichkeiten/overview")).json();
  renderVerbindlichkeitenChart(data);
}


// ---------- Kuchendiagramm: Verteilung nach Anlageklassen (gesamtes Nettovermögen) ----------
// PIE_COLORS entfernt zugunsten von chartColorsList() (theme-bewusst)

function renderVermoegenPieChart(pieAllocation) {
  const card = document.getElementById("vermoegen-pie-card");
  if (!pieAllocation || pieAllocation.length === 0) {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";
  const el = document.getElementById("vermoegen-pie-chart");

  const size = 220, cx = size / 2, cy = size / 2, r = 90;
  let cumulativeAngle = -90; // oben beginnen, im Uhrzeigersinn

  const polarToXY = (angleDeg, radius) => {
    const rad = (angleDeg * Math.PI) / 180;
    return [cx + radius * Math.cos(rad), cy + radius * Math.sin(rad)];
  };
  const pieColors = chartColorsList();

  const slices = pieAllocation.map((item, i) => {
    const angle = (item.percent / 100) * 360;
    const startAngle = cumulativeAngle;
    const endAngle = cumulativeAngle + angle;
    cumulativeAngle = endAngle;
    const [x1, y1] = polarToXY(startAngle, r);
    const [x2, y2] = polarToXY(endAngle, r);
    const largeArc = angle > 180 ? 1 : 0;
    const color = pieColors[i % pieColors.length];
    // Ein Vollkreis (100% eine einzige Kategorie) laesst sich nicht als
    // einzelner Arc-Pfad zeichnen (Start=Ende) -> als Kreis behandeln.
    const path = item.percent >= 99.95
      ? `M ${cx - r} ${cy} A ${r} ${r} 0 1 1 ${cx + r} ${cy} A ${r} ${r} 0 1 1 ${cx - r} ${cy}`
      : `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;
    return { path, color, item };
  });

  el.innerHTML = `
    <div style="display:flex;gap:20px;flex-wrap:wrap;align-items:center;justify-content:center">
      <svg viewBox="0 0 ${size} ${size}" width="180" height="180" style="overflow:visible;max-width:100%;flex-shrink:0">
        <defs>
          <filter id="pie-shadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="2" stdDeviation="4" flood-opacity="0.25" />
          </filter>
        </defs>
        <g filter="url(#pie-shadow)">
          ${slices.map((s) => `<path class="pie-slice" d="${s.path}" fill="${s.color}" stroke="var(--bg)" stroke-width="2.5" style="transform-origin:${cx}px ${cy}px;transition:transform 0.15s ease"><title>${s.item.key}: ${fmt(s.item.value)} (${s.item.percent}%)</title></path>`).join("")}
        </g>
      </svg>
      <div style="flex:1;min-width:180px">
        ${slices.map((s) => `
          <div class="row-actions" style="justify-content:space-between;font-size:0.82rem;padding:3px 0">
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:${s.color};vertical-align:middle;margin-right:6px"></span>${s.item.key}</span>
            <span>${s.item.percent}% <span class="muted">(${fmt(s.item.value)})</span></span>
          </div>`).join("")}
      </div>
    </div>`;

  el.querySelectorAll(".pie-slice").forEach((slice) => {
    slice.addEventListener("mouseenter", () => { slice.style.transform = "scale(1.035)"; });
    slice.addEventListener("mouseleave", () => { slice.style.transform = "scale(1)"; });
  });
}

// ---------- Inline-Bearbeitung des Kontostands (ohne das volle Formular zu oeffnen) ----------
function wireInlineAssetValueEdit(container) {
  container.querySelectorAll("[data-inline-edit-asset]").forEach((el) => {
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      if (el.querySelector("input")) return; // bereits im Bearbeiten-Modus
      const assetId = el.dataset.inlineEditAsset;
      const rawValue = el.dataset.rawValue;
      el.innerHTML = `<input type="text" inputmode="decimal" value="${formatAmountForInput(rawValue)}" style="width:110px;text-align:right;font-weight:600" />`;
      const input = el.querySelector("input");
      input.focus();
      input.select();

      let settled = false;
      const commit = async () => {
        if (settled) return;
        settled = true;
        const newValue = parseGermanNumber(input.value);
        if (newValue == null || Number.isNaN(newValue)) {
          loadVermoegenOverview();
          return;
        }
        await authedFetch(`/api/assets/${assetId}`, {
          method: "PATCH", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ current_value: newValue }),
        });
        loadVermoegenOverview();
      };
      const cancel = () => {
        if (settled) return;
        settled = true;
        loadVermoegenOverview();
      };

      input.addEventListener("blur", commit);
      input.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") { ev.preventDefault(); input.blur(); }
        if (ev.key === "Escape") { ev.preventDefault(); cancel(); }
      });
    });
  });
}

// ---------- Dokument-/Beleg-Betrachter (In-App, mit garantiertem
// Schließen-Button) — ersetzt target="_blank"-Links für Belege, da diese
// in der auf dem iOS-Homescreen installierten Standalone-App oft ohne
// jede Browser-Oberfläche (und damit ohne Zurueck-Moeglichkeit) geoeffnet
// werden. ----------
const documentViewerOverlay = document.getElementById("document-viewer-overlay");
const documentViewerFrame = document.getElementById("document-viewer-frame");

function openDocumentViewer(url, title) {
  documentViewerFrame.src = url;
  document.getElementById("document-viewer-title").textContent = title || "";
  documentViewerOverlay.style.display = "flex";
}
function closeDocumentViewer() {
  documentViewerOverlay.style.display = "none";
  documentViewerFrame.src = "about:blank"; // Laufende Wiedergabe/Ladevorgänge stoppen
}
document.getElementById("document-viewer-close-btn").addEventListener("click", closeDocumentViewer);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && documentViewerOverlay.style.display !== "none") closeDocumentViewer();
});

function wireDocumentViewerLinks(container) {
  container.querySelectorAll("[data-view-doc-url]").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      openDocumentViewer(link.dataset.viewDocUrl, link.dataset.viewDocTitle);
    });
  });
}

// ---------- Person-Details: Steuer-/SV-Daten + Dokumente ----------
const personDetailOverlay = document.getElementById("person-detail-overlay");
let personDetailCurrentId = null;

function openPersonDetailForm(personId) {
  const person = allFamilyMembers.find((m) => String(m.id) === String(personId));
  if (!person) return;
  personDetailCurrentId = person.id;

  document.getElementById("person-detail-name").value = person.name;
  document.getElementById("person-detail-role").value = person.role;
  document.getElementById("person-detail-freistellung-group").style.display = person.role === "elternteil" ? "block" : "none";
  document.getElementById("person-detail-freistellung").value = person.freistellungsauftrag_used ?? "";
  document.getElementById("person-detail-sv-nummer").value = person.sv_nummer || "";
  document.getElementById("person-detail-steuer-id").value = person.steuer_id || "";
  document.getElementById("person-detail-steuerklasse").value = person.steuerklasse || "";
  document.getElementById("person-detail-krankenkasse").value = person.krankenkasse || "";
  document.getElementById("person-detail-etin").value = person.etin || "";
  document.getElementById("person-detail-steuernummer").value = person.steuernummer || "";
  document.getElementById("person-detail-finanzamt").value = person.finanzamt || "";
  document.getElementById("person-detail-documents").style.display = "none";
  document.getElementById("person-detail-documents-list").innerHTML = "";

  personDetailOverlay.style.display = "flex";
}

document.getElementById("person-detail-role").addEventListener("change", (e) => {
  document.getElementById("person-detail-freistellung-group").style.display = e.target.value === "elternteil" ? "block" : "none";
});

document.getElementById("person-detail-cancel-btn").addEventListener("click", () => {
  personDetailOverlay.style.display = "none";
});

document.getElementById("person-detail-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById("person-detail-name").value.trim(),
    role: document.getElementById("person-detail-role").value,
    sv_nummer: document.getElementById("person-detail-sv-nummer").value.trim() || null,
    steuer_id: document.getElementById("person-detail-steuer-id").value.trim() || null,
    steuerklasse: document.getElementById("person-detail-steuerklasse").value.trim() || null,
    krankenkasse: document.getElementById("person-detail-krankenkasse").value.trim() || null,
    etin: document.getElementById("person-detail-etin").value.trim() || null,
    steuernummer: document.getElementById("person-detail-steuernummer").value.trim() || null,
    finanzamt: document.getElementById("person-detail-finanzamt").value.trim() || null,
  };
  if (payload.role === "elternteil") {
    payload.freistellungsauftrag_used = parseGermanNumber(document.getElementById("person-detail-freistellung").value);
  }
  await authedFetch(`/api/family-members/${personDetailCurrentId}`, {
    method: "PATCH", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  personDetailOverlay.style.display = "none";
  allFamilyMembers = [];
  loadFamilyMembersList();
});

document.getElementById("person-detail-show-documents-btn").addEventListener("click", async () => {
  const panel = document.getElementById("person-detail-documents");
  const isHidden = panel.style.display === "none";
  panel.style.display = isHidden ? "block" : "none";
  if (isHidden) await loadPersonDocumentsList();
});

async function loadPersonDocumentsList() {
  const listEl = document.getElementById("person-detail-documents-list");
  listEl.innerHTML = '<p class="muted">Lade …</p>';
  const docs = await (await authedFetch(`/api/family-members/${personDetailCurrentId}/documents`)).json();
  if (!docs.length) {
    listEl.innerHTML = '<p class="muted" style="font-size:0.78rem">Noch keine Dokumente hinterlegt.</p>';
    return;
  }
  listEl.innerHTML = `<ul>${docs.map((d) => `
    <li>
      <a href="/api/person-documents/${d.id}" rel="noopener" data-view-doc-url="/api/person-documents/${d.id}" data-view-doc-title="${d.original_filename || "Dokument"}">📎 ${d.original_filename || "Dokument"}</a>
      <span class="row-actions">
        <span class="muted" style="font-size:0.72rem">${(d.uploaded_at || "").slice(0, 10)}</span>
        <a href="/api/person-documents/${d.id}?download=true" title="Herunterladen" style="text-decoration:none">⬇️</a>
        <button type="button" class="del-btn" data-delete-person-doc="${d.id}" title="Löschen">🗑</button>
      </span>
    </li>`).join("")}</ul>`;
  wireDocumentViewerLinks(listEl);
  listEl.querySelectorAll("[data-delete-person-doc]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Dieses Dokument wirklich löschen?")) return;
      await authedFetch(`/api/person-documents/${btn.dataset.deletePersonDoc}`, { method: "DELETE" });
      loadPersonDocumentsList();
    });
  });
}

document.getElementById("person-detail-upload-btn").addEventListener("click", async () => {
  const input = document.getElementById("person-detail-upload-input");
  if (!input.files.length) { alert("Bitte zuerst eine Datei auswählen."); return; }
  const formData = new FormData();
  formData.append("file", input.files[0]);
  await authedFetch(`/api/family-members/${personDetailCurrentId}/documents`, { method: "POST", body: formData });
  input.value = "";
  loadPersonDocumentsList();
});
