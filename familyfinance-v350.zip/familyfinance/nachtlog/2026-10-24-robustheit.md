# Nachtlauf 2026-10-24 – Robustheit & Performance

**Rolle:** Robustheit & Performance (Samstag, Berliner Zeit) · **Geprüfter Stand:** `master` @ `05c4f74`, Build v349 · **Ergebnis-Build:** v350 (2026-10-24), kein Release gebaut.

**Aktualitäts-Check:** `latest.json` meldet v349, `master` steht bei v349 → aktuell. Keine offenen PRs. Es gab noch kein Robustheit-Log, daher kein Vorlauf.

## Geändert

1. **Update-Prüfung startete bei jedem Seitenaufruf einen neuen `pip list --outdated` (10–20 s)** (`backend/maintenance.py` neu `check_outdated_cached`, `backend/app.py` `_check_all_updates`).
   Auch die Anmeldeseite (`/api/public/check-updates`, ohne Login) löste das aus und bricht nach 3 s ab (`frontend/auth.js`). Der Server arbeitete trotzdem weiter. Folge: mehrere Geräte = mehrere parallele pip-Prozesse, und der Update-Hinweis vor der Anmeldung erschien praktisch nie.
   Neu: Ergebnis 15 Minuten zwischengespeichert, mit Sperre (gleichzeitige Anfragen warten auf denselben Lauf). Fehler werden nicht gespeichert. Der Knopf „Nach Updates suchen“ in den Einstellungen fragt mit `?refresh=1` immer frisch (`frontend/app.js`). Die App-Versions-Prüfung (0,3 s) bleibt live.
2. **Windows: `requirements.txt` mit `encoding="utf-8"` lesen** (`backend/maintenance.py:161,169`). Die Datei enthält Umlaute; ohne Angabe nutzt Windows die ANSI-Codepage.
3. Build v350, Datum 2026-10-24 (`app.js`, `service-worker.js`).

**Getestet:** `py_compile`, `node --check`. Vorher/Nachher: erster Aufruf `/api/public/check-updates` 13,5 s, zweiter 0,3 s; eingeloggt zwischengespeichert 0,11 s, `refresh=1` 14,5 s. Thread-Test: 5 parallele Aufrufe = 1 pip-Lauf; `force` startet neu; Fehler werden nicht gespeichert. `xss.py` grün, `fk.py` 0 Fehler. Keine UI-Layout-Änderung, daher kein `design.py`.

## Messung Datenmenge (Demodaten hochskaliert: 60 000 Bankumsätze, 5 000 Zählerstände)
Alle GET-Endpunkte ohne Pfad-Parameter: kein Serverfehler (die Zählerdaten dieser ersten Messung waren unrealistisch, siehe Befund cost-trend). Langsam sind nur die Netz-/pip-Prüfungen (siehe oben). Sonst: `energy-pdf` 1,1 s, `banks/open-groups` 0,4 s (103 KB), `energy/cost-trend` 0,2 s, Rest < 0,25 s. Dashboard 0,07 s.

## Befunde
- ~~mittel: `energy/cost-trend` 387 KB~~ **zurückgezogen:** Messartefakt. Meine Testdaten reichten (5 000 Stände auf 4 Zähler verteilt, ein Datum pro 20 Stände ab 2000) bis ins Jahr 2250, daraus wurden Hunderte Prognose-Monate. Mit realistischen Daten (täglich, 4 Zähler, 2016–2026, 15 784 Stände): `ytd` 12 Monate/1,9 KB, `12m` 2,4 KB, `all` 132 Monate/21 KB, je ~0,2 s. Der Zeitraum-Filter (`range`) greift bereits. Kein Handlungsbedarf.
- **niedrig:** `maintenance.py:439-440` und `reset_access.py:82` öffnen SQLite ohne `timeout` (Standard 5 s). Bei gleichzeitigem Schreiben kann die Sicherung „database is locked“ melden. Vorschlag: `timeout=30` wie in `database.py:53`.
- **niedrig:** `/api/public/check-updates` ist ohne Login und nach Ablauf des Zwischenspeichers weiterhin der Auslöser für einen pip-Lauf (höchstens alle 15 Min.). Vorschlag (Security-Rolle): Pakete vor der Anmeldung gar nicht prüfen, die Anmeldeseite wertet nur die App-Version aus.

## Bewusst nicht geändert
- Integrationen (Zappi, Sungrow, Fronius, FinTS, Ollama aus) und echte Geräte: ohne Zugangsdaten nicht testbar.
- `/api/maintenance/outdated-packages` bleibt live (Knopf-Prüfung).

## Offen / braucht Benjamin
- Nach dem Mergen: Release bauen. 

## Vorschlag nächster Lauf (Robustheit)
Sicherungs-/Lock-Verhalten (`timeout`), Startzeit mit großer echter Datenbank, Offline-Verhalten der PWA (Service-Worker bei ausgeschaltetem Server), Windows-Pfade in `update.command`-Gegenstück.
