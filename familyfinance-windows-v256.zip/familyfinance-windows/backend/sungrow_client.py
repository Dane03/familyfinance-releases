"""
Client für die iSolarCloud-API von Sungrow — nutzt bewusst die INOFFIZIELLE
'UserAuth'-Anmeldung der Bibliothek 'sungrow-isolarcloud' (normale
E-Mail/Passwort-Anmeldung, kein eigener Entwickler-Zugang bei Sungrow
nötig), statt der offiziellen, aber langsamen OpenAPI-Registrierung.

WICHTIG, ehrlich gesagt: Anmeldung und Anlagen-Liste sind über die
Bibliothek gut dokumentiert und funktionieren zuverlässig. Das genaue
Feldformat der TAGES-Detaildaten (welches Feld "PV-Ertrag" ist, welches
"Einspeisung" usw.) ist laut Bibliotheks-Dokumentation selbst "unverified
against a live device" -- ich habe daher bewusst noch KEINE automatische
Zuordnung/Speicherung dieser Felder gebaut. Der Vorschau-Endpunkt liefert
die Rohdaten eines Tages, damit die echten Feldnamen einmal gemeinsam
verifiziert werden können, bevor daraus automatisch Jahreswerte entstehen
— nach den früheren Problemen mit fehlerhaften PV-Importen bewusst
lieber einmal zu vorsichtig als einmal zu schnell.
"""
from datetime import date

from pysolarcloud import Server, UserAuth, AuthError


class SungrowError(Exception):
    pass


async def test_connection(email: str, password: str) -> dict:
    """Nur Anmeldung + Anlagen-Liste prüfen, ohne Daten zu importieren. Bei
    genau einer Anlage im Konto wird deren ps_id gleich mitgeliefert, damit
    sie nicht mühsam von Hand herausgesucht werden muss.

    Probiert bewusst ALLE bekannten iSolarCloud-Server-Regionen der Reihe
    nach durch, nicht nur "Europe": Das Konto kann (z.B. je nach Händler/
    Installateur) auf einem anderen Server registriert sein als dem, den
    der Wohnort vermuten lässt -- eine falsche Region liefert dabei
    typischerweise dieselbe generische "falsches Passwort"-Meldung wie ein
    tatsächlich falsches Passwort (teils sogar auf Chinesisch, unabhängig
    vom eingestellten lang-Parameter), was ansonsten leicht in die Irre
    führt. Die erfolgreiche Region wird zurückgegeben, damit sie sich
    dauerhaft speichern lässt."""
    errors = {}
    # Europe zuerst versuchen (wahrscheinlichste Region für diesen
    # deutschen Haushalt), erst danach die übrigen -- vermeidet unnötige
    # Anfragen im Normalfall, in dem die Region ohnehin stimmt.
    ordered_servers = sorted(Server, key=lambda s: 0 if s.name == "Europe" else 1)
    for server in ordered_servers:
        try:
            async with UserAuth(server, email, password) as auth:
                plants = await auth.async_get_plants()
                result = {"ok": True, "plants": plants, "region": server.name}
                if len(plants) == 1 and plants[0].get("ps_id"):
                    result["auto_ps_id"] = str(plants[0]["ps_id"])
                return result
        except AuthError as e:
            errors[server.name] = str(e)
        except Exception as e:
            errors[server.name] = str(e)
    # Auf KEINEM Server erfolgreich -- alle Einzelfehler zeigen, damit
    # unterscheidbar ist, ob es wirklich überall dieselbe
    # Zugangsdaten-Ablehnung war oder ob z.B. nur eine Region einen
    # Netzwerkfehler hatte.
    detail = "; ".join(f"{name}: {msg}" for name, msg in errors.items())
    return {"ok": False, "error": f"Anmeldung auf keinem bekannten Server erfolgreich — {detail}"}


async def fetch_raw_daily_preview(email: str, password: str, ps_id: str, day: date, region: str = "Europe") -> dict:
    """Rohe Tagesdaten EINES Tages für EINE Anlage -- zur Ansicht/Diagnose,
    damit die Feldnamen echt verifiziert werden können, bevor eine
    automatische Auswertung darauf aufbaut. Nutzt die beim Verbindungstest
    tatsächlich erfolgreiche Server-Region (siehe test_connection), nicht
    blind "Europe" -- sonst würde derselbe Regions-Fehler hier erneut
    auftreten, selbst wenn die Zugangsdaten korrekt sind."""
    server = getattr(Server, region, Server.Europe)
    async with UserAuth(server, email, password) as auth:
        raw = await auth.async_get_plant_detail_daily(ps_id, day.strftime("%Y%m%d"))
        return raw
