"""
Energy Monitor — alle Endpunkte rund um Zählerstände, Gas/Strom/Wasser,
PV-Anlage und Verbrauchsauswertung.

Aus app.py herausgelöst, um die zentrale Datei überschaubar zu halten. Die
Routen sind unverändert übernommen; registriert werden sie über einen
APIRouter, der in app.py eingebunden wird — die URLs bleiben damit exakt
dieselben wie vorher.
"""
import csv
import hashlib
import io
import json
import re
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

import auth
import meters
from database import get_connection
from ocr import extract_receipt_data

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent
RECEIPTS_DIR = BASE_DIR / "data" / "receipts"
# Auch in receipts_routes.py definiert -- bewusst als eigenständige, gleiche
# Definition statt eines Imports, um einen Zirkelbezug zu vermeiden. Es ist
# lediglich ein Ablagepfad für kurzlebige Zwischendateien.
SMART_IMPORT_STAGING = BASE_DIR / "data" / "smart_import_staging"


def _get_meter_settings(conn, meter_type: str) -> dict:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (f"meter_settings_{meter_type}",)).fetchone()
    defaults = meters.DEFAULT_SETTINGS.get(meter_type, {})
    if not row:
        return dict(defaults)
    saved = json.loads(row["value"])
    return {**defaults, **saved}


def _get_readings(conn, meter_type: str) -> list:
    rows = conn.execute(
        "SELECT id, reading_date, value, is_new_meter, note, receipt_id FROM meter_readings "
        "WHERE meter_type=? ORDER BY reading_date ASC", (meter_type,),
    ).fetchall()
    return [dict(r) for r in rows]


def _validate_meter_type(meter_type: str):
    if meter_type not in meters.METER_TYPES:
        raise HTTPException(404, f"Unbekannter Zählertyp: {meter_type}")


@router.get("/api/meters/overview")
def meters_overview(session=Depends(auth.require_full_auth)):
    """Kompakte Übersicht aller Zähler fürs Energy-Monitor-Dashboard."""
    conn = get_connection()
    result = []
    for meter_type in meters.METER_TYPES:
        readings = _get_readings(conn, meter_type)
        if not readings:
            continue  # Zähler, für die es noch keine einzige Ablesung gibt, nicht anzeigen
        settings_ = _get_meter_settings(conn, meter_type)
        settlement = meters.compute_settlement(meter_type, readings, settings_)
        result.append({
            "meter_type": meter_type,
            "label": meters.METER_META[meter_type]["label"],
            "icon": meters.METER_META[meter_type]["icon"],
            "unit": meters.METER_META[meter_type]["unit"],
            "latest_reading": readings[-1],
            "current_daily_rate": meters.current_daily_rate(readings),
            "settlement": settlement,
        })
    conn.close()
    return {"meters": result}


@router.get("/api/meters/{meter_type}/readings")
def get_meter_readings(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"readings": readings}


class MeterReadingIn(BaseModel):
    reading_date: date
    value: float
    is_new_meter: bool = False
    note: Optional[str] = None
    receipt_id: Optional[int] = None


@router.post("/api/meters/{meter_type}/readings")
def add_meter_reading(meter_type: str, payload: MeterReadingIn, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    existing = conn.execute(
        "SELECT id FROM meter_readings WHERE meter_type=? AND reading_date=?",
        (meter_type, payload.reading_date.isoformat()),
    ).fetchone()
    if existing:
        conn.close()
        raise HTTPException(409, f"Für den {payload.reading_date.isoformat()} liegt bei diesem Zähler bereits eine Ablesung vor.")
    cur = conn.execute(
        """INSERT INTO meter_readings (meter_type, reading_date, value, is_new_meter, note, receipt_id)
           VALUES (?,?,?,?,?,?)""",
        (meter_type, payload.reading_date.isoformat(), payload.value,
         int(payload.is_new_meter), payload.note, payload.receipt_id),
    )
    reading_id = cur.lastrowid
    if payload.receipt_id:
        conn.execute("UPDATE receipts SET review_needed=0 WHERE id=?", (payload.receipt_id,))
    conn.commit()
    conn.close()
    return {"id": reading_id, "status": "created"}


@router.delete("/api/meters/{meter_type}/readings/{reading_id}")
def delete_meter_reading(meter_type: str, reading_id: int, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    conn.execute("DELETE FROM meter_readings WHERE id=? AND meter_type=?", (reading_id, meter_type))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/meters/{meter_type}/settings")
def get_meter_settings_endpoint(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    settings_ = _get_meter_settings(conn, meter_type)
    conn.close()
    return settings_


@router.put("/api/meters/{meter_type}/settings")
def put_meter_settings(meter_type: str, payload: dict, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    current = _get_meter_settings(conn, meter_type)
    current.update(payload)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (f"meter_settings_{meter_type}", json.dumps(current)),
    )
    conn.commit()
    conn.close()
    return current


@router.get("/api/meters/{meter_type}/monthly")
def get_meter_monthly(meter_type: str, resolution: str = "month",
                       session=Depends(auth.require_full_auth)):
    """Verbrauch fürs Diagramm — inkl. Prognose fürs laufende Jahr für Monate
    ohne echte Ablesung/Import.

    'resolution' ('day' | 'week' | 'month') steuert die Feinheit, damit kurze
    Zeiträume einen echten Verlauf zeigen statt nur ein bis zwei Balken.

    WICHTIG: Bei Strombezug/Einspeisung stammen die Werte teilweise aus dem
    PV-Import, der ausschließlich MONATSwerte liefert. Eine feinere Auflösung
    ist dort also gar nicht erst verfügbar — in dem Fall wird bewusst auf
    Monate zurückgefallen und das über 'effective_resolution' zurückgemeldet,
    statt aus Monatswerten künstlich Tageswerte zu erfinden."""
    _validate_meter_type(meter_type)
    if resolution not in ("day", "week", "month"):
        resolution = "month"
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    pv_daily = _get_pv_daily(conn) if meter_type in ("elec_in", "elec_out") else []
    conn.close()

    if resolution == "month":
        series = meters.get_effective_monthly(meter_type, readings, pv_monthly)
        effective = "month"
    elif meter_type in ("elec_in", "elec_out") and pv_daily:
        # Echte Tageswerte aus dem PV-Import verdichten -- deutlich genauer als
        # die aus wenigen Zählerständen interpolierte Rechnung.
        field = "bezug" if meter_type == "elec_in" else "einsp"
        series = {}
        for row in pv_daily:
            key = row["key"] if resolution == "day" else meters._period_key(
                date.fromisoformat(row["key"]), resolution)
            series[key] = round(series.get(key, 0.0) + (row[field] or 0.0), 3)
        effective = resolution
    elif meter_type in ("elec_in", "elec_out") and pv_monthly:
        # Werte stammen aus dem monatlichen PV-Import -- feiner geht es hier
        # schlicht nicht, also ehrlich auf Monate zurückfallen.
        series = meters.get_effective_monthly(meter_type, readings, pv_monthly)
        effective = "month"
    else:
        series = meters.consumption_by_period(readings, resolution)
        effective = resolution

    rate = meters.current_daily_rate(readings)
    today = date.today()
    # Prognose ergibt nur bei Monatsauflösung Sinn — sie füllt fehlende
    # KALENDERmonate auf; auf Tages-/Wochenebene gibt es nichts zu ergänzen.
    forecast = meters.forecast_missing_months(
        series, rate, date(today.year, 1, 1), date(today.year, 12, 31)
    ) if effective == "month" else {}
    return {"monthly": series, "forecast": forecast, "current_daily_rate": rate,
            "effective_resolution": effective}


@router.get("/api/meters/{meter_type}/kpis")
def get_meter_kpis(meter_type: str, session=Depends(auth.require_full_auth)):
    """Die 5 KPI-Chips für die Detailseite (Letzter Stand, Tagesrate,
    optimaler Abschlag, erwartete Differenz, Jahresprognose)."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"chips": meters.compute_kpi_chips(meter_type, readings, settings_, pv_monthly)}


def _refresh_actual_temperatures_if_due():
    """Holt beim Serverstart automatisch aktuelle Monatstemperaturen nach —
    aber höchstens einmal pro Tag, damit ein mehrfacher Neustart am selben
    Tag nicht unnötig oft die (kostenlose, aber fremde) Wetter-API
    beansprucht. Läuft komplett im Hintergrund; ein Fehlschlag (kein
    Standort hinterlegt, kein Netz) darf den App-Start nie verzögern oder
    stören."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        return

    last_row = conn.execute("SELECT value FROM settings WHERE key='weather_last_fetched'").fetchone()
    last_fetched = json.loads(last_row["value"]) if last_row else None
    today_str = date.today().isoformat()
    if last_fetched == today_str:
        conn.close()
        return

    import threading

    def _do_fetch():
        fresh = meters.fetch_actual_monthly_temperatures(location)
        if not fresh:
            return
        c = get_connection()
        existing_row = c.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
        existing = json.loads(existing_row["value"]) if existing_row else {}
        existing.update(fresh)  # neue/aktualisierte Monate überschreiben, ältere bleiben erhalten
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(existing),),
        )
        c.execute(
            "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(today_str),),
        )
        c.commit()
        c.close()

    # Im Hintergrund, damit ein langsamer/fehlender Netzwerkzugriff den
    # eigentlichen Serverstart nicht blockiert.
    threading.Thread(target=_do_fetch, daemon=True).start()
    conn.close()


@router.post("/api/meters/gas/temperature/refresh")
def refresh_gas_temperature(session=Depends(auth.require_full_auth)):
    """Manueller Sofort-Abruf (z.B. nach dem erstmaligen Eintragen eines
    Standorts, ohne auf den nächsten Neustart warten zu müssen)."""
    conn = get_connection()
    location_row = conn.execute("SELECT value FROM settings WHERE key='weather_location'").fetchone()
    location = json.loads(location_row["value"]) if location_row else None
    if not location:
        conn.close()
        raise HTTPException(400, "Kein Standort in den Einstellungen hinterlegt.")

    fresh = meters.fetch_actual_monthly_temperatures(location)
    if not fresh:
        conn.close()
        return {"status": "error", "error": "Kein Ergebnis — Standort nicht gefunden oder Wetterdienst nicht erreichbar."}

    existing_row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    existing = json.loads(existing_row["value"]) if existing_row else {}
    existing.update(fresh)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('gas_monthly_temps', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(existing),),
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('weather_last_fetched', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(date.today().isoformat()),),
    )
    conn.commit()
    conn.close()
    return {"status": "ok", "months_updated": len(fresh)}


@router.get("/api/meters/gas/temperature")
def get_gas_temperature(session=Depends(auth.require_full_auth)):
    """Klimamittel (DWD, statisch) + tatsächliche Monatstemperaturen für die
    Temperatur-Kurve auf der Gas-Seite."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='gas_monthly_temps'").fetchone()
    conn.close()
    actual = json.loads(row["value"]) if row else {}
    return {"dwd_climate_avg": meters.DWD_CLIMATE_AVG, "actual": actual}


@router.get("/api/meters/{meter_type}/intervals")
def get_meter_intervals(meter_type: str, session=Depends(auth.require_full_auth)):
    """Ablesungen mit Delta/Tage/Tagesrate für die Detailtabelle."""
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    conn.close()
    return {"intervals": meters.compute_reading_intervals(readings)}


@router.get("/api/meters/{meter_type}/cumulative")
def get_meter_cumulative(meter_type: str, session=Depends(auth.require_full_auth)):
    """Kumulative Ist-Kosten vs. Abschlag vs. optimaler Abschlag übers Jahr —
    nicht sinnvoll für Einspeisung (keine Kosten, sondern Erlös)."""
    _validate_meter_type(meter_type)
    if meter_type == "elec_out":
        raise HTTPException(400, "Kumulativ-Ansicht ist nur für Gas und Strombezug verfügbar.")
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_cumulative_cost(meter_type, readings, settings_, pv_monthly)}


class PVSystemSpecIn(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: date
    note: Optional[str] = None


class PVSystemSpecPatch(BaseModel):
    installed_year: Optional[int] = None
    kwp: Optional[float] = None
    battery_kwh: Optional[float] = None
    valid_from: Optional[date] = None
    note: Optional[str] = None


@router.get("/api/pv/system-specs")
def list_pv_system_specs(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM pv_system_specs ORDER BY valid_from").fetchall()
    conn.close()

    today = date.today().isoformat()
    specs = [dict(r) for r in rows]
    # Aktuell gültigen und (falls vorhanden) als nächstes anstehenden
    # Ausbauschritt markieren — nützlich für die geplante Erweiterung, damit
    # die Oberfläche "ab wann gilt was" nicht selbst nachrechnen muss.
    current = None
    upcoming = []
    for s in specs:
        if s["valid_from"] <= today:
            current = s
        else:
            upcoming.append(s)
    return {"specs": specs, "current": current, "upcoming": upcoming}


@router.post("/api/pv/system-specs")
def create_pv_system_spec(payload: PVSystemSpecIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO pv_system_specs (installed_year, kwp, battery_kwh, valid_from, note)
           VALUES (?,?,?,?,?)""",
        (payload.installed_year, payload.kwp, payload.battery_kwh, payload.valid_from, payload.note),
    )
    conn.commit()
    sid = cur.lastrowid
    conn.close()
    return {"id": sid, "status": "created"}


@router.patch("/api/pv/system-specs/{spec_id}")
def update_pv_system_spec(spec_id: int, patch: PVSystemSpecPatch, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    if not fields:
        conn.close()
        return {"status": "unchanged"}
    fields["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE pv_system_specs SET {set_clause} WHERE id=?", (*fields.values(), spec_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@router.delete("/api/pv/system-specs/{spec_id}")
def delete_pv_system_spec(spec_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pv_system_specs WHERE id=?", (spec_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Anlagendaten-Eintrag nicht gefunden")
    conn.execute("DELETE FROM pv_system_specs WHERE id=?", (spec_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/pv/autarkie")
def get_pv_autarkie(session=Depends(auth.require_full_auth)):
    """Autarkiegrad je Monat (PV-Eigenverbrauchsanteil) — für den
    Autarkie-Chart auf der Strom-Detailseite."""
    conn = get_connection()
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_autarkie_series(pv_monthly)}


@router.get("/api/meters/{meter_type}/settlement")
def get_meter_settlement(meter_type: str, session=Depends(auth.require_full_auth)):
    _validate_meter_type(meter_type)
    conn = get_connection()
    readings = _get_readings(conn, meter_type)
    settings_ = _get_meter_settings(conn, meter_type)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    if not readings:
        raise HTTPException(400, "Noch keine Ablesungen für diesen Zähler erfasst.")
    return meters.compute_settlement(meter_type, readings, settings_, pv_monthly)


# ---------- Energy Monitor Dashboard: vollständige Übersicht ----------

def _all_readings_and_settings(conn) -> tuple:
    readings_by_type = {mt: _get_readings(conn, mt) for mt in meters.METER_TYPES}
    settings_by_type = {mt: _get_meter_settings(conn, mt) for mt in meters.METER_TYPES}
    return readings_by_type, settings_by_type


def _get_pv_monthly(conn) -> list:
    """Monats-PV-Werte für alle Auswertungen. Wo TAGESdaten vorliegen, werden
    diese zu Monatswerten aufsummiert und den gespeicherten Monatszeilen
    vorgezogen — feinere Quelle gewinnt. Für Monate ohne Tagesdaten bleibt es
    bei den (gröberen) Monatszeilen, sodass ältere Importe unverändert
    weiterverwendet werden."""
    monthly = {r["key"]: dict(r) for r in conn.execute(
        "SELECT key, pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_monthly"
    ).fetchall()}
    for r in conn.execute(
        """SELECT substr(key,1,7) AS key, SUM(pv) AS pv, SUM(bezug) AS bezug,
                  SUM(einsp) AS einsp, SUM(batt_lad) AS batt_lad,
                  SUM(batt_ent) AS batt_ent, SUM(gesamt) AS gesamt
           FROM pv_daily GROUP BY substr(key,1,7)"""
    ).fetchall():
        monthly[r["key"]] = {k: (round(v, 3) if isinstance(v, float) else v)
                              for k, v in dict(r).items()}
    return [monthly[k] for k in sorted(monthly)]


def _get_pv_daily(conn) -> list:
    """Tagesgenaue PV-Werte — Grundlage für die feinen Auflösungen (1 Mo /
    3 Mo) in den Diagrammen."""
    rows = conn.execute(
        "SELECT key, pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_daily ORDER BY key"
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/api/energy/overview")
def energy_overview(range: str = "ytd", session=Depends(auth.require_full_auth)):
    """Die vier KPI-Karten (Gas, Bezug, Einspeisung, PV-Ertrag) für den
    Energy-Monitor-Dashboard-Kopf, für den gewählten Zeitraum."""
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    cards = meters.compute_overview_cards(readings_by_type, settings_by_type, pv_monthly, range)
    return {"ranges": meters.RANGES, **cards}


@router.get("/api/energy/cost-trend")
def energy_cost_trend(range: str = "ytd", session=Depends(auth.require_full_auth)):
    if range not in {r["id"] for r in meters.RANGES}:
        raise HTTPException(400, f"Unbekannter Zeitraum: {range}")
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return {"months": meters.compute_cost_trend(readings_by_type, settings_by_type, pv_monthly, range)}


@router.get("/api/energy/settlement")
def energy_settlement(session=Depends(auth.require_full_auth)):
    """Vollständige Jahresabrechnung — Gas, Strombezug und Einspeisung mit
    Fälligkeits-Countdown, für den Jahresabrechnung-Block im Dashboard."""
    conn = get_connection()
    readings_by_type, settings_by_type = _all_readings_and_settings(conn)
    pv_monthly = _get_pv_monthly(conn)
    conn.close()
    return meters.compute_full_settlement(readings_by_type, settings_by_type, pv_monthly)


class MeterSettlementIn(BaseModel):
    meter_type: str
    settlement_date: date
    note: Optional[str] = None


@router.get("/api/energy/settlements")
def list_meter_settlements(session=Depends(auth.require_full_auth)):
    """Alle manuell erfassten Abrechnungszeitpunkte, je Zählerseite —
    unabhängig von der kalenderjahr-basierten Jahresabrechnung oben. Der
    jeweils letzte Eintrag pro Zählerseite dient als Reset-Basis für
    'Verbrauch seit der Abrechnung'."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.post("/api/energy/settlements")
def create_meter_settlement(payload: MeterSettlementIn, session=Depends(auth.require_full_auth)):
    if payload.meter_type not in meters.METER_TYPES:
        raise HTTPException(400, f"Ungültiger Zählertyp: {payload.meter_type}")
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO meter_settlements (meter_type, settlement_date, note) VALUES (?,?,?)",
        (payload.meter_type, payload.settlement_date.isoformat(), payload.note),
    )
    conn.commit()
    conn.close()
    return {"id": cur.lastrowid, "status": "created"}


@router.delete("/api/energy/settlements/{settlement_id}")
def delete_meter_settlement(settlement_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM meter_settlements WHERE id=?", (settlement_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Abrechnungszeitpunkt nicht gefunden")
    conn.execute("DELETE FROM meter_settlements WHERE id=?", (settlement_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/energy/consumption-since-settlement")
def consumption_since_settlement_overview(session=Depends(auth.require_full_auth)):
    """Verbrauch seit dem jeweils letzten manuell erfassten Abrechnungs-
    zeitpunkt, je Zählerseite — ergänzt die Jahresabrechnung oben um einen
    Reset-Punkt, der nicht an den Kalenderjahreswechsel gebunden ist."""
    conn = get_connection()
    readings_by_type, _ = _all_readings_and_settings(conn)
    settlements = conn.execute(
        "SELECT * FROM meter_settlements ORDER BY meter_type, settlement_date DESC"
    ).fetchall()
    conn.close()

    result = {}
    for mt in meters.METER_TYPES:
        latest_settlement = next((s for s in settlements if s["meter_type"] == mt), None)
        if not latest_settlement:
            result[mt] = None
            continue
        settlement_date = date.fromisoformat(latest_settlement["settlement_date"])
        readings = [dict(r) for r in (readings_by_type.get(mt) or [])]
        since = meters.consumption_since_settlement(readings, settlement_date)
        if since:
            since["settlement_note"] = latest_settlement["note"]
        result[mt] = since
    return result


@router.get("/api/pv/monthly")
def get_pv_monthly(resolution: str = "month", session=Depends(auth.require_full_auth)):
    """PV-Zeitreihe. 'resolution' ('day'|'week'|'month') steuert die Feinheit —
    Tages- und Wochenwerte werden aus pv_daily verdichtet. Liegen für den
    gewünschten Zeitraum keine Tagesdaten vor, wird ehrlich auf Monatswerte
    zurückgefallen und das über 'effective_resolution' zurückgemeldet."""
    if resolution not in ("day", "week", "month"):
        resolution = "month"
    conn = get_connection()
    if resolution == "month":
        data, effective = _get_pv_monthly(conn), "month"
    else:
        daily = _get_pv_daily(conn)
        if not daily:
            data, effective = _get_pv_monthly(conn), "month"
        elif resolution == "day":
            data, effective = daily, "day"
        else:
            buckets: dict = {}
            for row in daily:
                key = meters._period_key(date.fromisoformat(row["key"]), "week")
                acc = buckets.setdefault(key, {"key": key, "pv": 0.0, "bezug": 0.0,
                                                "einsp": 0.0, "batt_lad": 0.0,
                                                "batt_ent": 0.0, "gesamt": 0.0})
                for f in ("pv", "bezug", "einsp", "batt_lad", "batt_ent", "gesamt"):
                    acc[f] = round(acc[f] + (row[f] or 0.0), 3)
            data, effective = [buckets[k] for k in sorted(buckets)], "week"
    conn.close()
    return {"months": data, "plant": meters.PV_PLANT_DEFAULTS,
            "effective_resolution": effective}


class PVMonthIn(BaseModel):
    key: str
    pv: float = 0
    bezug: float = 0
    einsp: float = 0
    batt_lad: float = 0
    batt_ent: float = 0
    gesamt: float = 0


@router.put("/api/pv/monthly/{key}")
def upsert_pv_month(key: str, payload: PVMonthIn, session=Depends(auth.require_full_auth)):
    if not re.match(r"^\d{4}-\d{2}$", key):
        raise HTTPException(400, "Ungültiger Monatsschlüssel (erwartet YYYY-MM).")
    conn = get_connection()
    conn.execute(
        """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
             einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
             gesamt=excluded.gesamt""",
        (key, payload.pv, payload.bezug, payload.einsp, payload.batt_lad, payload.batt_ent, payload.gesamt),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


@router.delete("/api/pv/monthly/{key}")
def delete_pv_month(key: str, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM pv_monthly WHERE key=?", (key,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


def _parse_pv_timestamp(raw: str):
    """Erkennt das Zeitformat einer iSolarCloud-Zeile und gibt (art, schlüssel)
    zurück. Bewusst datengetrieben statt über den Dateinamen: Die Exporte
    "Monatsbericht" und "Wochenbericht" enthalten BEIDE Tageszeilen — der Name
    sagt also nichts über die tatsächliche Granularität aus.

    - '2026-09-01 14:35:00' -> ('interval', '2026-09-01')  (5-Minuten-Werte)
    - '2026-09-01'          -> ('day',      '2026-09-01')
    - '2026-09'             -> ('month',    '2026-09')
    """
    s = str(raw).strip()
    if re.match(r"^\d{4}-\d{1,2}-\d{1,2}[ T]\d{1,2}:\d{2}", s):
        d = s.split(" ")[0].split("T")[0]
        y, mo, dy = d.split("-")
        return "interval", f"{y}-{int(mo):02d}-{int(dy):02d}"
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", s)
    if m:
        return "day", f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    m = re.match(r"^(\d{4})-(\d{1,2})$", s)
    if m:
        return "month", f"{m.group(1)}-{int(m.group(2)):02d}"
    return None, None


@router.post("/api/pv/import")
async def import_pv_sungrow(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    """iSolarCloud-Export (XLSX) einlesen — erkennt Tages-, Wochen- und
    Monatsberichte automatisch anhand der Daten.

    Hintergrund: Die Exporte heißen zwar "Monatsbericht"/"Wochenbericht",
    enthalten aber beide TAGESzeilen; der Tagesbericht wiederum enthält
    5-Minuten-Werte in Watt. Der Importer richtet sich deshalb nach dem
    tatsächlichen Inhalt.

    Feinere Daten haben Vorrang: Tageswerte landen in pv_daily und werden bei
    Auswertungen den Monatswerten vorgezogen. Ein Monatsbericht überschreibt
    also keine bereits vorhandenen, genaueren Tagesdaten."""
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    tmp_path = SMART_IMPORT_STAGING / f"pv_{hashlib.sha256(content).hexdigest()[:12]}.xlsx"
    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)
    try:
        import pandas as pd
        df = pd.read_excel(tmp_path, engine="openpyxl")
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise HTTPException(400, f"Datei konnte nicht gelesen werden: {e}")
    tmp_path.unlink(missing_ok=True)

    cols = df.columns.tolist()

    def find_col(fragment):
        return next((c for c in cols if fragment.lower() in str(c).lower()), None)

    zeit_col = find_col("zeit")
    pv_col, bezug_col, einsp_col = find_col("pv-ertrag"), find_col("netzbezug"), find_col("einspeisung")
    batt_lad_col, batt_ent_col = find_col("batt.-ladung"), find_col("batt.-entladung")
    ges_col = find_col("gesamtverbrauch")
    # Der Tagesbericht hat andere Spalten: Momentanleistung in Watt statt
    # Energiemengen in kWh, und eine gemeinsame "Netz"-Spalte.
    netz_w_col = find_col("netz(w)")
    is_watt_report = any("(w)" in str(c).lower() for c in cols)

    if not zeit_col or not (pv_col or netz_w_col):
        raise HTTPException(
            400,
            "Diese Datei sieht nicht wie ein iSolarCloud-Export aus — erwartet werden "
            "Spalten wie 'Zeit', 'PV-Ertrag(kWh)', 'Einspeisung(kWh)', 'Netzbezug(kWh)' "
            "(Monats-/Wochenbericht) oder 'PV-Ertrag(W)', 'Netz(W)' (Tagesbericht).",
        )

    def num(row, col):
        if not col or col not in df.columns:
            return 0.0
        try:
            return float(str(row[col]).replace(",", "."))
        except (ValueError, TypeError):
            return 0.0

    # ---- Zeilen einsammeln und nach erkannter Granularität gruppieren ----
    daily: dict = {}
    monthly: dict = {}
    interval_acc: dict = {}   # Tagesschlüssel -> Liste von Watt-Messpunkten
    skipped = 0

    for _, row in df.iterrows():
        kind, key = _parse_pv_timestamp(row[zeit_col])
        if not kind:
            skipped += 1
            continue
        if kind == "interval":
            # 5-Minuten-Momentanleistung (W) -> Energie (kWh) über das Intervall.
            # Zeitstempel mitführen, damit die tatsächliche Intervalllänge aus
            # den Daten abgeleitet werden kann (ein Tagesbericht kann einen
            # ANGEFANGENEN Tag enthalten, z.B. nur bis 13:50 Uhr).
            interval_acc.setdefault(key, []).append({
                "ts": str(row[zeit_col]).strip(),
                "pv": num(row, pv_col), "netz": num(row, netz_w_col),
                "gesamt": num(row, ges_col),
            })
        elif kind == "day":
            daily[key] = {
                "pv": num(row, pv_col), "bezug": num(row, bezug_col), "einsp": num(row, einsp_col),
                "batt_lad": num(row, batt_lad_col), "batt_ent": num(row, batt_ent_col),
                "gesamt": num(row, ges_col),
            }
        else:
            monthly[key] = {
                "pv": num(row, pv_col), "bezug": num(row, bezug_col), "einsp": num(row, einsp_col),
                "batt_lad": num(row, batt_lad_col), "batt_ent": num(row, batt_ent_col),
                "gesamt": num(row, ges_col),
            }

    # 5-Minuten-Werte zu Tagessummen verdichten. Ein Momentanwert in Watt gilt
    # für die Dauer seines Intervalls -> kWh = W × Stunden ÷ 1000.
    for key, points in interval_acc.items():
        if len(points) < 2:
            continue
        # Intervalllänge aus zwei aufeinanderfolgenden Zeitstempeln ableiten,
        # NICHT aus "24h ÷ Anzahl Punkte": Ein Export des laufenden Tages endet
        # mittendrin (z.B. 13:50 Uhr), sonst würde jeder Wert um den Faktor
        # "fehlende Stunden" zu hoch gerechnet.
        try:
            t0 = datetime.fromisoformat(points[0]["ts"])
            t1 = datetime.fromisoformat(points[1]["ts"])
            hours_per_point = abs((t1 - t0).total_seconds()) / 3600.0
        except (ValueError, KeyError):
            hours_per_point = 24.0 / len(points)
        if hours_per_point <= 0:
            continue

        covered_hours = hours_per_point * len(points)
        # Angefangene Tage bewusst NICHT als Tageswert speichern -- die Summe
        # wäre zwangsläufig zu niedrig und würde einen bereits vorhandenen,
        # vollständigen Wert desselben Tages verschlechtern. Der Tag wird
        # nachgetragen, sobald ein vollständiger Export vorliegt.
        if covered_hours < 23.0:
            skipped += len(points)
            continue

        pv_kwh = sum(p["pv"] for p in points) * hours_per_point / 1000.0
        ges_kwh = sum(p["gesamt"] for p in points) * hours_per_point / 1000.0
        # "Netz" ist vorzeichenbehaftet: positiv = Bezug, negativ = Einspeisung.
        bezug_kwh = sum(p["netz"] for p in points if p["netz"] > 0) * hours_per_point / 1000.0
        einsp_kwh = -sum(p["netz"] for p in points if p["netz"] < 0) * hours_per_point / 1000.0
        daily.setdefault(key, {
            "pv": round(pv_kwh, 3), "bezug": round(bezug_kwh, 3), "einsp": round(einsp_kwh, 3),
            "batt_lad": 0.0, "batt_ent": 0.0, "gesamt": round(ges_kwh, 3),
        })

    if not daily and not monthly:
        if interval_acc:
            raise HTTPException(
                400,
                "Dieser Tagesbericht deckt nur einen angefangenen Tag ab und wurde deshalb "
                "nicht übernommen — ein Teil-Tag würde einen zu niedrigen Tageswert ergeben. "
                "Bitte den Export nach Tagesende erneut herunterladen, oder den Wochen-/"
                "Monatsbericht nutzen (der enthält fertige Tageswerte).",
            )
        raise HTTPException(400, f"Keine verwertbaren Zeilen gefunden ({skipped} Zeilen übersprungen).")

    conn = get_connection()
    added = updated = 0

    for key, v in daily.items():
        existing = conn.execute("SELECT key FROM pv_daily WHERE key=?", (key,)).fetchone()
        conn.execute(
            """INSERT INTO pv_daily (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                 einsp=excluded.einsp, batt_lad=excluded.batt_lad,
                 batt_ent=excluded.batt_ent, gesamt=excluded.gesamt""",
            (key, v["pv"], v["bezug"], v["einsp"], v["batt_lad"], v["batt_ent"], v["gesamt"]),
        )
        updated += 1 if existing else 0
        added += 0 if existing else 1

    # Monatszeilen nur dort übernehmen, wo für diesen Monat KEINE Tagesdaten
    # vorliegen -- feinere Daten haben Vorrang und sollen nicht von einem
    # gröberen Bericht überschrieben werden.
    for key, v in monthly.items():
        has_daily = conn.execute(
            "SELECT 1 FROM pv_daily WHERE key LIKE ? LIMIT 1", (f"{key}-%",)
        ).fetchone()
        if has_daily:
            skipped += 1
            continue
        existing = conn.execute("SELECT key FROM pv_monthly WHERE key=?", (key,)).fetchone()
        conn.execute(
            """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                 einsp=excluded.einsp, batt_lad=excluded.batt_lad,
                 batt_ent=excluded.batt_ent, gesamt=excluded.gesamt""",
            (key, v["pv"], v["bezug"], v["einsp"], v["batt_lad"], v["batt_ent"], v["gesamt"]),
        )
        updated += 1 if existing else 0
        added += 0 if existing else 1

    conn.commit()
    conn.close()
    detected = "Tageswerte" if daily else "Monatswerte"
    return {"added": added, "updated": updated, "skipped": skipped,
            "detected_granularity": detected,
            "days": len(daily), "months": len(monthly)}


@router.post("/api/meters/{meter_type}/upload")
async def upload_meter_bill(meter_type: str, file: UploadFile = File(...),
                             session=Depends(auth.require_full_auth)):
    """Foto/PDF einer Ablesekarte oder Abrechnung einlesen — analog zum
    Beleg-Upload bei den Ausgaben: lokale OCR-Erkennung, Vorschlag zur
    Bestätigung, kein automatisches Speichern eines Zählerstands."""
    _validate_meter_type(meter_type)
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    file_hash = hashlib.sha256(content).hexdigest()
    conn = get_connection()
    existing = conn.execute(
        "SELECT id, uploaded_at FROM receipts WHERE file_hash=? AND review_needed=0",
        (file_hash,),
    ).fetchone()
    if existing:
        conn.close()
        raise HTTPException(409, f"Diese exakte Datei wurde bereits am {existing['uploaded_at']} importiert.")
    # Beide Module werden von app.py eingebunden, ein Import auf Modulebene
    # wäre ein Zirkelbezug -- zum Aufrufzeitpunkt ist alles fertig geladen.
    import receipts_routes
    receipts_routes._cleanup_unconfirmed_receipts(conn, max_age_hours=None)
    conn.close()

    today = datetime.now()
    safe_stem = re.sub(r"[^\w.-]", "_", Path(file.filename or "zaehlerstand").stem)[:80] or "zaehlerstand"
    suffix = Path(file.filename or "").suffix or ".jpg"
    filename = f"{today.strftime('%Y%m%d%H%M%S')}_{safe_stem}{suffix}"
    tmp_path = RECEIPTS_DIR / "_unbestaetigt" / filename
    tmp_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)

    result = extract_receipt_data(tmp_path)

    # Aus dem erkannten Text zusätzlich nach einem plausiblen Zählerstand
    # suchen (reine Zahl, evtl. mit Tausenderpunkt, in der Nähe von "Zähler-
    # stand"/"Stand"/"m³"/"kWh") — Betrag bleibt die primäre OCR-Info, der
    # Zählerstand ist ein zusätzlicher Bonus-Fund, kein Muss.
    suggested_value = None
    if result.get("raw_text"):
        m = re.search(
            r"(?:z[äa]hlerstand|stand|z[äa]hlerstd)[^\d]{0,15}(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,3})?)",
            result["raw_text"], re.IGNORECASE,
        )
        if m:
            try:
                suggested_value = float(m.group(1).replace(".", "").replace(",", "."))
            except ValueError:
                suggested_value = None

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO receipts
           (original_filename, stored_path, file_hash, ocr_text, detected_amount,
            detected_provider, detected_date, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(tmp_path.relative_to(BASE_DIR)), file_hash, result.get("raw_text"),
         result.get("amount"), result.get("provider"),
         result["date"].isoformat() if result.get("date") else None),
    )
    receipt_id = cur.lastrowid
    conn.commit()
    conn.close()

    return {
        "receipt_id": receipt_id,
        "suggested_value": suggested_value,
        "suggested_date": result["date"].isoformat() if result.get("date") else None,
        "detected": result,
        "note": ("Zählerstand erkannt — bitte prüfen." if suggested_value
                  else "Kein Zählerstand automatisch erkannt — bitte manuell eintragen."),
    }
