"""
Lokaler Finanz-Chatbot — beantwortet Fragen zu Konten, Verträgen, Vermögen
und Ausgaben, komplett offline über Ollama (https://ollama.com), das
ebenfalls lokal auf dem Mac Mini läuft. Kein Datenaustausch mit der Cloud.

WICHTIG, DAUERHAFT GÜLTIG: build_context() muss bei JEDER künftigen
Funktionserweiterung, die neue Datenbank-Tabellen/-Felder mit sich bringt,
mit überprüft und bei Bedarf erweitert werden — sonst kennt der Chatbot
neue App-Bereiche schlicht nicht.

Voraussetzung auf dem Mac Mini:
    brew install ollama
    ollama serve                     # läuft dauerhaft im Hintergrund
    ollama pull qwen3:8b              # einmalig, ca. 5.2 GB, läuft gut auf M-Chips

Kontextgröße (v373, Anlass: Tagesgeld-Saldo kam nicht beim Modell an):
Der Kontext wird bei jeder Frage frisch aus der DB gebaut. Ollama rechnet aber
nur mit `num_ctx` Tokens und schneidet längere Eingaben STILL ab. Bis v372 war
`num_ctx` nicht gesetzt (Ollama-Standard: wenige tausend Tokens) und der
Kontext enthielt bis zu 150 Bankumsätze als JSON (~10–15k Tokens) — Vermögen
und Kontostände in der Mitte gingen verloren, das Modell riet dann.
Seitdem:
  * kompakte Textzeilen statt JSON, leere Felder weggelassen,
  * Bankumsätze nur als Monatssummen + die letzten Buchungen,
  * Kontostände (mit Stand-Datum) als LETZTER Block, direkt vor der Frage,
  * fester `num_ctx` (8k — der Mac Mini hat 8 GB, das Modell belegt ~5 GB,
    jeder Token Kontext kostet ~150 KB Arbeitsspeicher),
  * harte Obergrenze CONTEXT_MAX_CHARS: ist der Kontext länger, werden zuerst
    die Einzelbuchungen gekürzt, die Kontostände nie.
"""
import logging
import re
import json
import urllib.request
from datetime import date

import database
from shared_helpers import monthly_amount

log = logging.getLogger("familyfinance.chatbot")

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "qwen3:8b"
NUM_CTX = 8192
# Faustregel ~3 Zeichen je Token bei deutschem Text mit Zahlen. 15.000 Zeichen
# ≈ 5.000 Tokens Kontext — lässt in 8k Platz für Frage, Denkschritte und Antwort.
CONTEXT_MAX_CHARS = 15000
RECENT_TX_LIMIT = 20
TX_MONTHS = 4

SYSTEM_PROMPT = """Du bist der Finanz-Assistent einer Familie. Unten steht der aktuelle \
Stand aus der App (Konten, Verträge, Vermögen, Einnahmen, Bankumsätze). Regeln:
1. Antworte NUR auf Basis dieser Daten. Steht etwas nicht drin, sag das ehrlich, statt zu raten.
2. Kontostände nimmst du IMMER aus dem Block KONTOSTÄNDE und nennst Betrag und Stand-Datum. \
Beträge in der Frage des Nutzers sind Preise, Ausgaben oder Einnahmen — nicht der Kontostand, \
außer der Nutzer sagt ausdrücklich, dass sein Kontostand anders ist.
3. Bei Rechnungen: zeige den Rechenweg Schritt für Schritt mit Zwischenergebnissen.
4. Antworte auf Deutsch, kurz und klar."""

_FREQ = {"monthly": "monatlich", "quarterly": "vierteljährlich", "yearly": "jährlich"}


def _eur(v) -> str:
    """1234.5 -> '1.234,50 €' (deutsch, damit das Modell nichts umdeuten muss)."""
    if v is None:
        return "unbekannt"
    s = f"{float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return s + " €"


def _de_date(v) -> str:
    """'2026-11-06 14:03:00' -> '06.11.2026'; unbekannt bleibt erkennbar."""
    if not v:
        return "unbekannt"
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", str(v))
    return f"{m.group(3)}.{m.group(2)}.{m.group(1)}" if m else str(v)


def _line(*parts) -> str:
    return "- " + " | ".join(str(p) for p in parts if p not in (None, ""))


def _liquid_accounts(conn, member_names: dict) -> list[str]:
    """Alle Konten (Vermögen Typ 'konto' + nicht zugeordnete Bankkonten) mit
    Saldo und Stand-Datum. Bei bankverknüpften Konten gilt der Bank-Saldo."""
    lines = []
    rows = conn.execute(
        """SELECT a.id, a.label, a.provider, a.account_type, a.purpose, a.person_id,
                  a.current_value, a.updated_at, a.exclude_from_networth,
                  ba.balance AS bank_balance, ba.balance_updated_at
           FROM assets a LEFT JOIN bank_accounts ba ON ba.asset_id = a.id AND ba.ignored = 0
           WHERE a.type = 'konto' AND a.archived_at IS NULL
           ORDER BY a.label""").fetchall()
    for r in rows:
        if r["bank_balance"] is not None:
            value, stand, quelle = r["bank_balance"], r["balance_updated_at"], "von der Bank abgerufen"
        else:
            value, stand, quelle = r["current_value"], r["updated_at"], "von Hand gepflegt"
        lines.append(_line(
            r["label"], r["provider"], r["account_type"] and f"Art: {r['account_type']}",
            r["purpose"] and f"Zweck: {r['purpose']}",
            member_names.get(r["person_id"], "Haushalt"),
            f"Kontostand {_eur(value)}", f"Stand {_de_date(stand)} ({quelle})",
            "zählt NICHT zum Gesamtvermögen" if r["exclude_from_networth"] else ""))
    # Bankkonten ohne Vermögenseintrag (und keine Darlehen) — sonst fehlen sie.
    for r in conn.execute(
            """SELECT label, substr(iban, -4) AS iban_ende, balance, balance_updated_at
               FROM bank_accounts
               WHERE ignored = 0 AND asset_id IS NULL AND contract_id IS NULL"""):
        lines.append(_line(r["label"] or "Bankkonto", r["iban_ende"] and f"IBAN …{r['iban_ende']}",
                           f"Kontostand {_eur(r['balance'])}",
                           f"Stand {_de_date(r['balance_updated_at'])} (von der Bank abgerufen)"))
    return lines


def _transactions(conn, today: date) -> tuple[list[str], list[str]]:
    """(Monatssummen, letzte Einzelbuchungen) — statt 150 Rohumsätzen."""
    start = date(today.year, today.month, 1)
    for _ in range(TX_MONTHS - 1):
        start = date(start.year - 1, 12, 1) if start.month == 1 else date(start.year, start.month - 1, 1)
    try:
        sums = [_line(r["monat"], f"Eingänge {_eur(r['ein'])}", f"Ausgänge {_eur(r['aus'])}",
                      f"{r['n']} Buchungen")
                for r in conn.execute(
                    """SELECT substr(bt.booking_date, 1, 7) AS monat,
                              SUM(CASE WHEN bt.amount > 0 THEN bt.amount ELSE 0 END) AS ein,
                              SUM(CASE WHEN bt.amount < 0 THEN -bt.amount ELSE 0 END) AS aus,
                              COUNT(*) AS n
                       FROM bank_transactions bt JOIN bank_accounts ba ON ba.id = bt.bank_account_id
                       WHERE ba.ignored = 0 AND bt.booking_date >= ?
                       GROUP BY monat ORDER BY monat DESC""", (start.isoformat(),))]
        recent = [_line(_de_date(r["booking_date"]), _eur(r["amount"]), r["counterparty_name"],
                        (r["purpose"] or "")[:50], r["konto"])
                  for r in conn.execute(
                      """SELECT ba.label AS konto, bt.booking_date, bt.amount, bt.counterparty_name,
                                bt.purpose
                         FROM bank_transactions bt JOIN bank_accounts ba ON ba.id = bt.bank_account_id
                         WHERE ba.ignored = 0
                         ORDER BY bt.booking_date DESC, bt.id DESC LIMIT ?""", (RECENT_TX_LIMIT,))]
    except Exception:  # Bank-Tabellen fehlen in sehr alten DBs
        return [], []
    return sums, recent


def _assemble(sections: list[tuple[str, list[str]]]) -> str:
    return "\n\n".join(f"{title}:\n" + ("\n".join(lines) if lines else "- (keine)")
                       for title, lines in sections)


def build_context(today: date | None = None) -> str:
    today = today or date.today()
    with database.db() as conn:
        members = conn.execute("SELECT id, name, role FROM family_members").fetchall()
        member_names = {m["id"]: m["name"] for m in members}
        fam = [_line(m["name"], m["role"]) for m in members]

        income = [_line(r["label"], r["category"], f"{_eur(r['amount'])} {_FREQ.get(r['frequency'], r['frequency'])}")
                  for r in conn.execute(
                      "SELECT label, category, amount, frequency FROM income WHERE active=1 ORDER BY sort_order, id")]

        contracts, fixed_month = [], 0.0
        for c in conn.execute(
                """SELECT co.label, co.provider, co.amount, co.frequency, co.contract_end,
                          co.notice_period_days, co.insurance_type, co.person_id, c.name AS category
                   FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
                   WHERE co.status='active' ORDER BY c.name, co.label"""):
            fixed_month += monthly_amount(c["amount"], c["frequency"])
            contracts.append(_line(
                c["label"], c["provider"], c["category"], c["insurance_type"],
                f"{_eur(c['amount'])} {_FREQ.get(c['frequency'], c['frequency'] or '')}".strip(),
                member_names.get(c["person_id"], "Haushalt"),
                c["contract_end"] and f"Ende {_de_date(c['contract_end'])}",
                c["notice_period_days"] and f"Kündigungsfrist {c['notice_period_days']} Tage"))
        if contracts:
            contracts.append(f"- SUMME aller Fixkosten: {_eur(fixed_month)} pro Monat")

        pensions = [_line(p["label"], p["type"], p["provider"], "Riester" if p["is_riester"] else "",
                          f"Wert {_eur(p['current_value'])}",
                          p["monthly_contribution"] and f"Beitrag {_eur(p['monthly_contribution'])}/Monat",
                          member_names.get(p["person_id"], "unbekannt"))
                    for p in conn.execute(
                        """SELECT type, label, provider, is_riester, current_value,
                                  monthly_contribution, person_id FROM pension_accounts""")]

        other_assets = [_line(a["label"], a["type"], a["provider"], a["purpose"] and f"Zweck: {a['purpose']}",
                              f"Wert {_eur(a['current_value'])}",
                              member_names.get(a["person_id"], "Haushalt"),
                              "zählt NICHT zum Gesamtvermögen" if a["exclude_from_networth"] else "",
                              (a["note"] or "")[:60])
                        for a in conn.execute(
                            """SELECT type, label, provider, purpose, current_value, person_id, note,
                                      exclude_from_networth
                               FROM assets WHERE archived_at IS NULL AND type <> 'konto'
                               ORDER BY type, label""")]

        reminders = [_line(_de_date(r["trigger_date"]), r["message"])
                     for r in conn.execute(
                         "SELECT trigger_date, message FROM reminders WHERE sent=0 ORDER BY trigger_date LIMIT 15")]

        tx_sums, tx_recent = _transactions(conn, today)
        accounts = _liquid_accounts(conn, member_names)

    def sections(recent):
        return [
            (f"HEUTE", [f"- {_de_date(today.isoformat())}"]),
            ("FAMILIENMITGLIEDER", fam),
            ("EINNAHMEN", income),
            ("VERTRÄGE / FIXKOSTEN (inkl. Versicherungen)", contracts),
            ("RENTENKONTEN / ALTERSVORSORGE", pensions),
            ("WEITERES VERMÖGEN (Depots, Immobilien, Sonstiges)", other_assets),
            ("OFFENE ERINNERUNGEN", reminders),
            ("BANKUMSÄTZE je Monat (alle Konten)", tx_sums),
            (f"LETZTE BANKBUCHUNGEN (negativ = Ausgabe)", recent),
            # Bewusst ZULETZT: steht direkt vor der Frage und geht nie verloren.
            ("KONTOSTÄNDE (Girokonten, Tagesgeld, Festgeld — maßgeblich für 'was bleibt übrig')", accounts),
        ]

    recent = list(tx_recent)
    text = _assemble(sections(recent))
    while len(text) > CONTEXT_MAX_CHARS and recent:
        recent = recent[:len(recent) // 2] if len(recent) > 1 else []
        text = _assemble(sections(recent))
    if len(text) > CONTEXT_MAX_CHARS:
        # Notfall: Verträge kürzen, Kontostände (letzter Block) bleiben erhalten.
        log.warning("Chatbot-Kontext zu lang (%d Zeichen) — Verträge werden gekürzt", len(text))
        head, tail = text.split("KONTOSTÄNDE", 1)
        text = head[:CONTEXT_MAX_CHARS - len(tail) - 40] + "\n[… gekürzt]\n\nKONTOSTÄNDE" + tail
    return text


def _needs_reasoning(question: str) -> bool:
    """Rechenfragen (≥ 2 Zahlen oder typische Wörter) bekommen Denkschritte —
    ohne rechnet ein 8B-Modell mehrstufig unzuverlässig."""
    numbers = re.findall(r"\d[\d.,]*", question)
    return len(numbers) >= 2 or bool(re.search(r"\b(übrig|bleibt|rechne|reicht|wie ?viel)\b", question, re.I))


def ask(question: str) -> str:
    context = build_context()
    think = _needs_reasoning(question)
    log.info("Chatbot: Kontext %d Zeichen (~%d Tokens), Denken %s",
             len(context), len(context) // 3, "an" if think else "aus")
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT + "\n\n" + context},
            {"role": "user", "content": question},
        ],
        "stream": False,
        "think": think,
        "options": {"num_ctx": NUM_CTX},
    }
    req = urllib.request.Request(
        OLLAMA_URL, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=180 if think else 60) as resp:
            data = json.loads(resp.read())
        content = data["message"]["content"]
        # Denk-Block nie anzeigen (kommt bei think=True getrennt in
        # message.thinking, ältere Versionen schreiben ihn in den Text).
        content = re.sub(r"<think>.*?</think>\s*", "", content, flags=re.DOTALL).strip()
        if data.get("prompt_eval_count") and data["prompt_eval_count"] >= NUM_CTX - 64:
            log.warning("Chatbot: Eingabe füllt den Kontext (%s Tokens) — evtl. abgeschnitten",
                        data["prompt_eval_count"])
        return content
    except Exception as e:
        return (f"Der lokale Chatbot (Ollama) ist gerade nicht erreichbar ({e}). "
                f"Läuft 'ollama serve' auf dem Mac Mini?")


if __name__ == "__main__":
    import sys
    if sys.argv[1:] == ["--context"]:
        ctx = build_context()
        print(ctx)
        print(f"\n[{len(ctx)} Zeichen, ~{len(ctx) // 3} Tokens]")
    else:
        q = " ".join(sys.argv[1:]) or "Welche Verträge laufen bald aus?"
        print(ask(q))
