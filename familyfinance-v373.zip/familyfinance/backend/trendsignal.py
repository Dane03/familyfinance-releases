"""
Trendsignal für ein Core-Satellite-Depot (v372).

Idee (Backtest 1990–2026, siehe PR-Beschreibung): Der Core (z. B. 70 % Welt-ETF)
läuft als Sparplan und wird nie verkauft. Der Satellit (z. B. 30 %) wechselt nach
einer festen Regel zwischen einem Aktien-ETF und einem Geldmarkt-ETF. Die Regel
wird einmal im Monat mit den Monatsendkursen ausgewertet und gilt für den
Folgemonat.

Regel "ensemble" (Standard): vier Einzelsignale, jedes steuert ein Viertel des
Satelliten (Ziel-Aktienquote 0/25/50/75/100 %):
  - 12-Monats-Momentum: Rendite Aktien-ETF > Rendite Geldmarkt-ETF über 12 Monate
  - 9-Monats-Momentum:  dasselbe über 9 Monate
  - Kurs über dem Durchschnitt der letzten 10 Monatsendkurse
  - Kurs über dem Durchschnitt der letzten 12 Monatsendkurse
Regel "momentum12": nur das 12-Monats-Momentum (0 oder 100 %).

Kurse kommen aus der FinTS-Depotaufstellung (bei jedem Bankabruf) und -- nur wenn
ausdrücklich eingeschaltet -- aus einem öffentlichen Kursabruf bei justETF. Dabei
wird ausschließlich die ISIN übertragen, nie Bestände, Beträge oder Zugangsdaten.

Umsetzung mit Blick auf die ING-Konditionen (Stand 11/2026): Sparpläne sind
kostenlos, Einmalkäufe von Aktions-ETFs kosten erst ab 1.000 € nur 1,90 €,
Verkäufe immer 4,90 € + 0,25 % (max. 69,90 €). Deshalb wird zuerst der
Satelliten-Sparplan umgestellt (kostenlos) und erst umgeschichtet, wenn die
Abweichung vom Ziel die Mindestorder erreicht oder das Signal komplett kippt.
"""
import json
import re
import threading
import time
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import auth
import database

router = APIRouter()

CONFIG_KEY = "trend_config"
FETCH_STATUS_KEY = "trend_fetch_status"
ISIN_RE = re.compile(r"^[A-Z]{2}[A-Z0-9]{9}[0-9]$")
STALE_DAYS = 7                 # Kurse älter als das -> Hinweis "Kurse veraltet"
FETCH_EVERY_HOURS = 20         # Sperre für ungezwungene Abrufe (Zeitplan und Knopf erzwingen)
FETCH_HISTORY_DAYS = 460       # reicht für 12-Monats-Momentum + Puffer
JUSTETF_URL = "https://www.justetf.com/api/etfs/{isin}/performance-chart"
MAX_RESPONSE_BYTES = 5_000_000

DEFAULT_CONFIG = {
    "enabled": False,
    "asset_id": None,          # Depot (assets.id, type='depot')
    "core_isin": "",
    "sat_eq_isin": "",
    "sat_mm_isin": "",
    "core_share": 70,          # % der monatlichen Sparrate für den Core
    "monthly_amount": 500.0,   # gesamte monatliche Sparrate (Core + Satellit)
    "rule": "ensemble",        # 'ensemble' | 'momentum12'
    "min_trade": 1000.0,       # Umschichten erst ab dieser Abweichung (ING-Aktion ab 1.000 €)
    "action_etfs": True,       # Kauf der ETFs zu Aktionskonditionen (1,90 € ab 1.000 €)
    "price_fetch": False,      # optionaler Kursabruf per ISIN (verlässt das Heimnetz)
}

# ---------- Einstellungen ----------

def get_config(conn) -> dict:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (CONFIG_KEY,)).fetchone()
    cfg = dict(DEFAULT_CONFIG)
    if row and row["value"]:
        try:
            cfg.update({k: v for k, v in json.loads(row["value"]).items() if k in DEFAULT_CONFIG})
        except (ValueError, TypeError):
            pass
    return cfg


def _save_setting(conn, key: str, value: dict):
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, json.dumps(value)))


def _load_setting(conn, key: str) -> dict:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    try:
        return json.loads(row["value"]) if row and row["value"] else {}
    except (ValueError, TypeError):
        return {}


def strategy_isins(cfg: dict) -> list:
    return [i for i in (cfg.get("sat_eq_isin"), cfg.get("sat_mm_isin"), cfg.get("core_isin")) if i]


# ---------- Kurse speichern ----------

def store_price(conn, isin: str, day: str, price: float, source: str):
    """Ein Kurs je ISIN und Tag. Ein Bankkurs wird nie von einem Abrufkurs überschrieben."""
    if not isin or price is None or price <= 0 or not day:
        return
    conn.execute(
        "INSERT INTO price_history (isin, date, price, source) VALUES (?,?,?,?) "
        "ON CONFLICT(isin, date) DO UPDATE SET price=excluded.price, source=excluded.source "
        "WHERE price_history.source != 'bank' OR excluded.source = 'bank'",
        (isin.upper(), day[:10], float(price), source))


def store_bank_holdings(conn, connection_key: str, holdings_by_account: list) -> int:
    """Übernimmt die FinTS-Depotaufstellung in die Positionen des verknüpften Depots
    und speichert die Kurse. Läuft in einem Savepoint: bei einem Fehler bleibt von
    diesem Teil nichts Halbes zurück (Salden/Umsätze des Abrufs sind davon getrennt)."""
    updated = 0
    conn.execute("SAVEPOINT trend_holdings")
    try:
        for group in holdings_by_account or []:
            acc = group.get("account") or {}
            holdings = group.get("holdings") or []
            row = conn.execute(
                "SELECT asset_id, balance FROM bank_accounts WHERE connection_key=? AND COALESCE(account_number,'')=? "
                "AND ignored=0 ORDER BY (COALESCE(iban,'')=?) DESC LIMIT 1",
                (connection_key, acc.get("account_number") or "", acc.get("iban") or "")).fetchone()
            for h in holdings:
                day = h.get("valuation_date") or date.today().isoformat()
                if h.get("price") and (h.get("currency") in (None, "", "EUR")):
                    store_price(conn, h["isin"], day, h["price"], "bank")
            if not row or not row["asset_id"]:
                continue   # Depot noch keinem Vermögenswert zugeordnet: nur Kurse merken
            asset_id = row["asset_id"]
            seen = set()
            for h in holdings:
                isin = h["isin"]
                seen.add(isin)
                value = h.get("total_value")
                if value is None and h.get("pieces") is not None and h.get("price") is not None:
                    value = round(h["pieces"] * h["price"], 2)
                if value is None:
                    continue
                existing = conn.execute("SELECT id FROM asset_holdings WHERE asset_id=? AND UPPER(isin)=?",
                                        (asset_id, isin)).fetchone()
                if existing:
                    conn.execute("UPDATE asset_holdings SET current_value=?, quantity=?, price=?, source='bank', "
                                 "updated_at=CURRENT_TIMESTAMP WHERE id=?",
                                 (value, h.get("pieces"), h.get("price"), existing["id"]))
                else:
                    conn.execute("INSERT INTO asset_holdings (asset_id, isin, name, current_value, quantity, price, source) "
                                 "VALUES (?,?,?,?,?,?, 'bank')",
                                 (asset_id, isin, h.get("name") or isin, value, h.get("pieces"), h.get("price")))
                updated += 1
            # Von der Bank gemeldete Positionen, die nicht mehr im Depot sind (verkauft) -> entfernen.
            # Von Hand erfasste Positionen bleiben unangetastet.
            for old in conn.execute("SELECT id, isin FROM asset_holdings WHERE asset_id=? AND source='bank'",
                                    (asset_id,)).fetchall():
                if (old["isin"] or "").upper() not in seen:
                    conn.execute("DELETE FROM asset_holdings WHERE id=?", (old["id"],))
            if row["balance"] is None and holdings:
                total = sum((h.get("total_value") or 0) for h in holdings)
                conn.execute("UPDATE assets SET current_value=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                             (round(total, 2), asset_id))
        conn.execute("RELEASE SAVEPOINT trend_holdings")
    except Exception:
        conn.execute("ROLLBACK TO SAVEPOINT trend_holdings")
        conn.execute("RELEASE SAVEPOINT trend_holdings")
        raise
    return updated


# ---------- Optionaler Kursabruf (nur ISIN verlässt das Netz) ----------

def _http_get_json(url: str) -> dict:
    """Eigene, kleine Hülle: nur https, nur der feste justETF-Host, begrenzte Größe."""
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname != "www.justetf.com":
        raise ValueError("Unzulässige Adresse für den Kursabruf")
    req = urllib.request.Request(url, headers={"User-Agent": "FamilyFinance", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as resp:   # noqa: S310 (Host oben fest geprüft)
        final = urllib.parse.urlparse(resp.geturl())
        if final.scheme != "https" or final.hostname != "www.justetf.com":
            raise ValueError("Weiterleitung zu fremdem Host abgelehnt")
        data = resp.read(MAX_RESPONSE_BYTES + 1)
    if len(data) > MAX_RESPONSE_BYTES:
        raise ValueError("Antwort zu groß")
    return json.loads(data.decode("utf-8"))


def fetch_prices_justetf(isin: str, days: int = FETCH_HISTORY_DAYS) -> list:
    """Tageskurse (EUR, ohne Ausschüttungen -- bei thesaurierenden ETFs = Gesamtrendite).
    Rückgabe: [(JJJJ-MM-TT, Kurs), ...]."""
    if not ISIN_RE.match(isin or ""):
        raise ValueError("Ungültige ISIN")
    params = urllib.parse.urlencode({
        "locale": "de", "currency": "EUR", "valuesType": "MARKET_VALUE", "reduceData": "false",
        "includeDividends": "false", "dateFrom": (date.today() - timedelta(days=days)).isoformat(),
        "dateTo": date.today().isoformat(),
    })
    data = _http_get_json(JUSTETF_URL.format(isin=isin) + "?" + params)
    out = []
    for item in data.get("series") or []:
        try:
            day = str(item["date"])[:10]
            date.fromisoformat(day)
            val = item["value"]["raw"] if isinstance(item.get("value"), dict) else item.get("value")
            price = float(val)
        except (KeyError, TypeError, ValueError):
            continue
        if price > 0:
            out.append((day, price))
    return out


def refresh_prices(conn, force: bool = False) -> dict:
    """Holt Kurse für die ISINs der Strategie -- nur wenn der Kursabruf eingeschaltet ist."""
    cfg = get_config(conn)
    if not (cfg["enabled"] and cfg["price_fetch"]):
        return {"status": "off"}
    last = _load_setting(conn, FETCH_STATUS_KEY)
    if not force and last.get("at"):
        try:
            if datetime.now() - datetime.fromisoformat(last["at"]) < timedelta(hours=FETCH_EVERY_HOURS):
                return {"status": "skipped", **last}
        except ValueError:
            pass
    results, errors = {}, []
    for isin in strategy_isins(cfg):
        try:
            rows = fetch_prices_justetf(isin)
            for day, price in rows:
                store_price(conn, isin, day, price, "justetf")
            results[isin] = len(rows)
            if not rows:
                errors.append(f"{isin}: keine Kurse erhalten")
        except Exception as e:
            errors.append(f"{isin}: {type(e).__name__}")
    status = {"at": datetime.now().isoformat(timespec="seconds"), "ok": not errors,
              "message": "; ".join(errors) if errors else f"{sum(results.values())} Kurse aktualisiert",
              "counts": results}
    _save_setting(conn, FETCH_STATUS_KEY, status)
    return {"status": "ok" if not errors else "error", **status}


# ---------- Signal ----------

def _de_pct(x: float) -> str:
    return f"{x * 100:+.1f} %".replace(".", ",")


def _de_num(x: float) -> str:
    return f"{x:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def month_end_prices(conn, isin: str) -> dict:
    """{JJJJ-MM: letzter Kurs des Monats}"""
    rows = conn.execute("SELECT date, price FROM price_history WHERE isin=? ORDER BY date", (isin.upper(),)).fetchall()
    out = {}
    for r in rows:
        out[r["date"][:7]] = r["price"]
    return out


def _prev_month(m: str, n: int = 1) -> str:
    y, mo = int(m[:4]), int(m[5:7])
    idx = y * 12 + (mo - 1) - n
    return f"{idx // 12:04d}-{idx % 12 + 1:02d}"


def last_completed_month(today: Optional[date] = None) -> str:
    today = today or date.today()
    return _prev_month(f"{today.year:04d}-{today.month:02d}")


def compute_signal(eq: dict, mm: dict, month: str, rule: str = "ensemble") -> dict:
    """Signal aus Monatsendkursen. eq/mm: {JJJJ-MM: Kurs}. Gibt die Einzelsignale und die
    Ziel-Aktienquote zurück; fehlen Kurse, steht in 'missing', wie viele Monate fehlen."""
    def ret(series, n):
        a, b = series.get(month), series.get(_prev_month(month, n))
        return None if a is None or b is None else a / b - 1

    def sma_above(n):
        vals = [eq.get(_prev_month(month, k)) for k in range(n)]
        if any(v is None for v in vals):
            return None
        return eq[month] > sum(vals) / n

    comps = []
    for n in ((12, 9) if rule == "ensemble" else (12,)):
        r_eq, r_mm = ret(eq, n), ret(mm, n)
        comps.append({"key": f"mom{n}", "label": f"{n}-Monats-Momentum",
                      "value": None if r_eq is None or r_mm is None else r_eq > r_mm,
                      "detail": None if r_eq is None or r_mm is None
                      else f"Aktien {_de_pct(r_eq)} vs. Geldmarkt {_de_pct(r_mm)}"})
    if rule == "ensemble":
        for n in (10, 12):
            v = sma_above(n)
            avg = None if v is None else sum(eq[_prev_month(month, k)] for k in range(n)) / n
            comps.append({"key": f"sma{n}", "label": f"Kurs über {n}-Monats-Durchschnitt", "value": v,
                          "detail": None if v is None else f"Kurs {_de_num(eq[month])} vs. Durchschnitt {_de_num(avg)}"})
    known = [c["value"] for c in comps if c["value"] is not None]
    complete = len(known) == len(comps)
    share = (sum(1 for v in known if v) / len(comps)) if complete else None
    months_eq = sum(1 for k in range(13) if eq.get(_prev_month(month, k)) is not None)
    months_mm = sum(1 for k in range(13) if mm.get(_prev_month(month, k)) is not None)
    return {"month": month, "rule": rule, "components": comps, "complete": complete, "equity_share": share,
            "months_available": min(months_eq, months_mm), "months_needed": 13}


# ---------- Empfehlung (ING-Kosten) ----------

def ing_order_fee(amount: float, side: str, action_etf: bool = True) -> float:
    """Ordergebühr ING Direkt-Depot (Stand 11/2026, Direkthandel). Kauf eines Aktions-ETFs
    ab 1.000 € = 1,90 € (Basis-ETF); sonst 4,90 € + 0,25 %, max. 69,90 €."""
    if amount <= 0:
        return 0.0
    if side == "buy" and action_etf and amount >= 1000:
        return 1.90
    return round(min(4.90 + 0.0025 * amount, 69.90), 2)


def recommendation(cfg: dict, share: float, holdings: dict, prev_share: Optional[float]) -> dict:
    """holdings: {ISIN: Wert}. Liefert Sparplan-Aufteilung und ggf. Umschichtung."""
    eq_isin, mm_isin = cfg["sat_eq_isin"].upper(), cfg["sat_mm_isin"].upper()
    eq_v, mm_v = holdings.get(eq_isin, 0.0), holdings.get(mm_isin, 0.0)
    sat_total = eq_v + mm_v
    sat_monthly = round(cfg["monthly_amount"] * (100 - cfg["core_share"]) / 100, 2)
    plan_eq = round(sat_monthly * share)
    plan = {"core": round(cfg["monthly_amount"] - sat_monthly, 2), "sat_eq": plan_eq,
            "sat_mm": round(sat_monthly - plan_eq, 2)}
    target_eq = round(sat_total * share, 2)
    diff = round(target_eq - eq_v, 2)          # >0: Geldmarkt -> Aktien, <0: Aktien -> Geldmarkt
    full_flip = share in (0.0, 1.0) and abs(diff) >= 50
    trade = None
    if sat_total > 0 and (abs(diff) >= cfg["min_trade"] or full_flip):
        amount = abs(diff)
        sell_isin, buy_isin = (mm_isin, eq_isin) if diff > 0 else (eq_isin, mm_isin)
        sell_fee = ing_order_fee(amount, "sell")
        buy_fee = ing_order_fee(amount - sell_fee, "buy", cfg["action_etfs"])
        trade = {"sell_isin": sell_isin, "buy_isin": buy_isin, "amount": round(amount, 2),
                 "fees": round(sell_fee + buy_fee, 2), "reason": "full_flip" if full_flip and abs(diff) < cfg["min_trade"] else "deviation"}
    plan_changed = prev_share is None or abs(prev_share - share) > 1e-9
    return {"sat_total": round(sat_total, 2), "sat_eq_value": round(eq_v, 2), "sat_mm_value": round(mm_v, 2),
            "target_eq_value": target_eq, "deviation": diff, "savings_plan": plan, "plan_changed": plan_changed,
            "trade": trade, "action_needed": bool(trade) or plan_changed}


def _holdings_of(conn, asset_id) -> dict:
    if not asset_id:
        return {}
    rows = conn.execute("SELECT isin, current_value FROM asset_holdings WHERE asset_id=? AND isin IS NOT NULL",
                        (asset_id,)).fetchall()
    out = {}
    for r in rows:
        out[r["isin"].upper()] = out.get(r["isin"].upper(), 0.0) + (r["current_value"] or 0.0)
    return out


def _latest_price_info(conn, isin: str) -> dict:
    r = conn.execute("SELECT date, price, source FROM price_history WHERE isin=? ORDER BY date DESC LIMIT 1",
                     (isin.upper(),)).fetchone()
    if not r:
        return {"isin": isin, "last_date": None, "last_price": None, "source": None, "stale": True}
    age = (date.today() - date.fromisoformat(r["date"])).days
    return {"isin": isin, "last_date": r["date"], "last_price": r["price"], "source": r["source"],
            "age_days": age, "stale": age > STALE_DAYS}


def evaluate(conn, today: Optional[date] = None) -> dict:
    """Wertet das Signal für den letzten abgeschlossenen Monat aus, speichert es und
    liefert den kompletten Zustand für Karte und Dashboard-Hinweis."""
    cfg = get_config(conn)
    state = {"config": cfg, "configured": False}
    if not cfg["enabled"]:
        return state
    if not (cfg["sat_eq_isin"] and cfg["sat_mm_isin"] and cfg["asset_id"]):
        state["problem"] = "Strategie unvollständig: Depot und beide Satelliten-ETFs festlegen."
        return state
    state["configured"] = True
    month = last_completed_month(today)
    eq, mm = month_end_prices(conn, cfg["sat_eq_isin"]), month_end_prices(conn, cfg["sat_mm_isin"])
    sig = compute_signal(eq, mm, month, cfg["rule"])
    state["signal"] = sig
    state["valid_for"] = _prev_month(month, -1)
    state["prices"] = [_latest_price_info(conn, i) for i in (cfg["sat_eq_isin"], cfg["sat_mm_isin"])]
    state["fetch_status"] = _load_setting(conn, FETCH_STATUS_KEY)
    if sig["complete"]:
        conn.execute(
            "INSERT INTO trend_signals (month, equity_share, components, evaluated_at) VALUES (?,?,?,?) "
            "ON CONFLICT(month) DO UPDATE SET equity_share=excluded.equity_share, components=excluded.components, "
            "evaluated_at=excluded.evaluated_at",
            (month, sig["equity_share"], json.dumps(sig["components"]), datetime.now().isoformat(timespec="seconds")))
        prev = conn.execute("SELECT equity_share FROM trend_signals WHERE month < ? ORDER BY month DESC LIMIT 1",
                            (month,)).fetchone()
        rec = recommendation(cfg, sig["equity_share"], _holdings_of(conn, cfg["asset_id"]),
                             prev["equity_share"] if prev else None)
        ack = conn.execute("SELECT acknowledged_at FROM trend_signals WHERE month=?", (month,)).fetchone()
        rec["acknowledged_at"] = ack["acknowledged_at"] if ack else None
        state["recommendation"] = rec
    state["history"] = [dict(r) for r in conn.execute(
        "SELECT month, equity_share, acknowledged_at FROM trend_signals ORDER BY month DESC LIMIT 12").fetchall()]
    return state


# ---------- Dashboard-Hinweise ----------

def _eur(v: float) -> str:
    return f"{v:,.0f} €".replace(",", ".")


_MONTHS = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September",
           "Oktober", "November", "Dezember"]


def _month_label(m: str) -> str:
    return f"{_MONTHS[int(m[5:7]) - 1]} {m[:4]}"


def dashboard_hints(conn=None) -> list:
    """Hinweise für die Dashboard-Karte (ganz vorn). Ohne Ablehnen-Schlüssel: erledigt
    wird über "Umgesetzt" auf der Vermögensseite. Eigene Verbindung, weil die
    Auswertung das Monatssignal speichert (die Dashboard-Verbindung liest nur)."""
    try:
        with database.db() as own:
            st = evaluate(own)
    except Exception as e:
        print(f"Trendsignal-Auswertung fehlgeschlagen: {type(e).__name__}: {e}")
        return []
    if not st.get("configured"):
        return []
    hints = []
    base = {"tab": "tab-vermoegen", "tab_label": "Vermögen", "anchor": "trend-card", "key": None}
    rec = st.get("recommendation")
    sig = st.get("signal") or {}
    if rec and rec["action_needed"] and not rec.get("acknowledged_at"):
        share = int(round(sig["equity_share"] * 100))
        if rec["trade"]:
            t = rec["trade"]
            fees = f"{t['fees']:.2f}".replace(".", ",")
            text = (f"Trendsignal {_month_label(st['valid_for'])}: Satellit {share} % Aktien. Umschichten: "
                    f"{_eur(t['amount'])} von {t['sell_isin']} nach {t['buy_isin']} (ca. {fees} € Gebühren).")
        else:
            p = rec["savings_plan"]
            text = (f"Trendsignal {_month_label(st['valid_for'])}: Satellit {share} % Aktien. Sparplan umstellen: "
                    f"{_eur(p['sat_eq'])} Aktien-ETF, {_eur(p['sat_mm'])} Geldmarkt-ETF.")
        hints.append({"icon": "📈", "text": text, "severity": "warn", "title": "Trendsignal", **base})
    stale = [p for p in st.get("prices") or [] if p["stale"]]
    if stale:
        hints.append({"icon": "⏱️", "text": "Trendsignal: Kurse veraltet oder fehlen ("
                      + ", ".join(p["isin"] for p in stale) + "). Depot synchronisieren"
                      + (" oder Kursabruf prüfen." if st["config"]["price_fetch"] else " oder Kursabruf einschalten."),
                      "severity": "info", "title": "Trendsignal-Kurse", **base})
    return hints


# ---------- API ----------

class TrendConfigIn(BaseModel):
    enabled: bool = False
    asset_id: Optional[int] = None
    core_isin: str = ""
    sat_eq_isin: str = ""
    sat_mm_isin: str = ""
    core_share: float = 70
    monthly_amount: float = 500
    rule: str = "ensemble"
    min_trade: float = 1000
    action_etfs: bool = True
    price_fetch: bool = False


@router.get("/api/trend")
def get_trend(session=Depends(auth.require_full_auth)):
    with database.db() as conn:
        return evaluate(conn)


@router.put("/api/trend/config")
def put_trend_config(payload: TrendConfigIn, session=Depends(auth.require_full_auth)):
    cfg = payload.model_dump()
    for k in ("core_isin", "sat_eq_isin", "sat_mm_isin"):
        cfg[k] = (cfg[k] or "").strip().upper().replace(" ", "")
        if cfg[k] and not ISIN_RE.match(cfg[k]):
            raise HTTPException(400, f"Ungültige ISIN: {cfg[k]}")
    if cfg["sat_eq_isin"] and cfg["sat_eq_isin"] == cfg["sat_mm_isin"]:
        raise HTTPException(400, "Aktien- und Geldmarkt-ETF müssen verschieden sein.")
    if cfg["core_isin"] and cfg["core_isin"] in (cfg["sat_eq_isin"], cfg["sat_mm_isin"]):
        raise HTTPException(400, "Der Core braucht eine eigene ISIN (sonst verkauft die Bank beim Umschichten "
                                 "nach FIFO zuerst die ältesten Core-Anteile).")
    if cfg["rule"] not in ("ensemble", "momentum12"):
        raise HTTPException(400, "Unbekannte Regel.")
    if not (0 <= cfg["core_share"] <= 100) or cfg["monthly_amount"] < 0 or cfg["min_trade"] < 0:
        raise HTTPException(400, "Werte außerhalb des zulässigen Bereichs.")
    with database.db() as conn:
        if cfg["asset_id"] is not None:
            a = conn.execute("SELECT type FROM assets WHERE id=? AND archived_at IS NULL", (cfg["asset_id"],)).fetchone()
            if not a or a["type"] != "depot":
                raise HTTPException(400, "Bitte ein (nicht archiviertes) Depot wählen.")
        _save_setting(conn, CONFIG_KEY, cfg)
    return {"status": "saved"}


@router.post("/api/trend/refresh")
def refresh_trend(session=Depends(auth.require_full_auth)):
    with database.db() as conn:
        res = refresh_prices(conn, force=True)
    with database.db() as conn:
        return {"fetch": res, "state": evaluate(conn)}


@router.post("/api/trend/ack")
def ack_trend(session=Depends(auth.require_full_auth)):
    with database.db() as conn:
        st = evaluate(conn)
        sig = st.get("signal")
        if not sig or not sig.get("complete"):
            raise HTTPException(400, "Kein vollständiges Signal zum Quittieren.")
        conn.execute("UPDATE trend_signals SET acknowledged_at=? WHERE month=?",
                     (datetime.now().isoformat(timespec="seconds"), sig["month"]))
    return {"status": "ok"}


# ---------- Hintergrund ----------
# Zeitplan (Ortszeit des Rechners): Kursabruf täglich um 0:00 Uhr. Beim App-Start wird
# einmal nachgeholt, wenn der letzte Abruf fehlgeschlagen ist -- oder wenn um 0:00 gar
# keiner lief (Rechner/App war aus) bzw. noch nie abgerufen wurde.

def seconds_until_midnight(now: Optional[datetime] = None) -> float:
    now = now or datetime.now()
    nxt = datetime.combine(now.date() + timedelta(days=1), datetime.min.time())
    return max((nxt - now).total_seconds(), 1.0)


def needs_startup_fetch(status: dict, now: Optional[datetime] = None) -> bool:
    """True, wenn der letzte Abruf fehlschlug, fehlt oder vor dem letzten 0:00-Termin lag."""
    now = now or datetime.now()
    if not status or not status.get("at"):
        return True
    if not status.get("ok"):
        return True
    try:
        last = datetime.fromisoformat(status["at"])
    except (TypeError, ValueError):
        return True
    return last < datetime.combine(now.date(), datetime.min.time())


def run_scheduled(startup: bool = False) -> dict:
    """Ein Lauf des Zeitplans -- immer die echte Datenbank. Wertet danach das Signal aus
    (auch ohne Kursabruf, damit der Monatswechsel erkannt wird)."""
    result = {"status": "skipped"}
    with database.db(real=True) as conn:
        cfg = get_config(conn)
        if cfg["enabled"] and cfg["price_fetch"]:
            if not startup or needs_startup_fetch(_load_setting(conn, FETCH_STATUS_KEY)):
                result = refresh_prices(conn, force=True)
    with database.db(real=True) as conn:
        evaluate(conn)
    return result


def start_background():
    def _loop():
        time.sleep(90)    # Serverstart abwarten
        try:
            run_scheduled(startup=True)
        except Exception as e:
            print(f"Trendsignal beim Start fehlgeschlagen: {type(e).__name__}: {e}")
        last_day = date.today()
        while True:
            # In Häppchen schlafen und an der Uhrzeit prüfen: time.sleep läuft auf dem Mac im
            # Ruhezustand nicht weiter -- so wird ein verschlafener 0:00-Termin nach dem
            # Aufwachen sofort nachgeholt.
            time.sleep(min(300.0, seconds_until_midnight() + 5))
            if date.today() == last_day:
                continue
            last_day = date.today()
            try:
                run_scheduled()
            except Exception as e:
                print(f"Trendsignal um 0:00 fehlgeschlagen: {type(e).__name__}: {e}")
    threading.Thread(target=_loop, daemon=True, name="trendsignal").start()
