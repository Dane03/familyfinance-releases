"""Trendsignal (v372): Signal, Empfehlung mit ING-Kosten, FinTS-Depotpositionen, Kursabruf, API, Dashboard-Hinweis.
Ohne Server, ohne Netz, Sekunden.
    cd kopie/backend && python3 ../scripts/review/trendsignal.py
Exit-Code 0 = alles grün. Arbeitet nur in einem Temp-Ordner.

Fälle:
 1) compute_signal mit von Hand nachrechenbaren Monatskursen: Ensemble 0/25/50/75/100 %, Regel momentum12,
    fehlende Monate -> unvollständig (keine Quote), Monatsgrenzen über den Jahreswechsel.
 2) ing_order_fee: Aktionskauf ab 1.000 € = 1,90 €, darunter 4,90 € + 0,25 %, Verkauf immer, Deckel 69,90 €.
 3) recommendation: Sparplan-Aufteilung, Umschichten erst ab Mindestorder, komplettes Kippen auch darunter,
    Richtung (Aktien <-> Geldmarkt), plan_changed gegenüber Vormonat.
 4) store_bank_holdings: Positionen des zugeordneten Depots aktualisiert/angelegt, verkaufte Bank-Positionen
    entfernt, Handeinträge bleiben, Kurse gespeichert, Bankkurs wird nicht von Abrufkurs überschrieben,
    nicht zugeordnetes Depot -> nur Kurse; Fehler -> Savepoint, nichts Halbes.
 5) bank_client._fetch_holdings mit gefälschtem python-fints-Client: nur Konten mit GET_HOLDINGS,
    Freigabe nötig / Fehler -> übersprungen, nie Exception.
 6) Kursabruf: nur bei eingeschaltetem Abruf, URL enthält nur ISIN + feste Parameter, fremder Host und
    Weiterleitung abgelehnt, kaputte Antwort -> Fehlerstatus ohne Absturz, höchstens etwa einmal täglich.
 7) API: Einstellungen prüfen (ISIN-Format, Core != Satellit, Depot-Typ), GET /api/trend, Quittieren,
    Dashboard-Hinweis ganz vorn und nach "Umgesetzt" weg, Hinweis "Kurse veraltet".
 8) init_db zweimal hintereinander ohne Fehler (Migration idempotent).
 9) Zeitplan: täglich 0:00 (Sekunden bis Mitternacht), beim Start nur nachholen, wenn der letzte Abruf
    fehlschlug, fehlt oder vor dem letzten 0:00-Termin lag; Start-Lauf ruft sonst nicht ab, 0:00-Lauf immer.
"""
import contextlib
import io
import json
import sys
import tempfile
from datetime import date, timedelta
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path.cwd()))
TMP = Path(tempfile.mkdtemp(prefix="ff_trend_"))
(TMP / "data").mkdir()

import database  # noqa: E402
import maintenance  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"
maintenance.BASE_DIR = TMP

FAILS = []


def check(name, got, want):
    ok = got == want
    print(("OK   " if ok else "FEHL ") + name + ("" if ok else f"  -> bekommen {got!r}, erwartet {want!r}"))
    if not ok:
        FAILS.append(name)


with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
    database.init_db()   # 8) idempotent
check("8) init_db zweimal", True, True)

import trendsignal as T  # noqa: E402
import bank_client  # noqa: E402

# ---------- 1) Signal ----------
M = "2026-10"
months = [T._prev_month(M, k) for k in range(13)]          # 2026-10 ... 2025-10


def series(vals):  # vals[0] = Monat M, vals[12] = M-12
    return {m: v for m, v in zip(months, vals)}


mm = series([100 + 0.2 * (12 - k) for k in range(13)])     # Geldmarkt: stetig +0,2/Monat (≈ +2,4 % in 12 M.)
up = series([100 + 2 * (12 - k) for k in range(13)])       # Aktien steigen stetig
down = series([100 - 2 * (12 - k) for k in range(13)])     # Aktien fallen stetig
s = T.compute_signal(up, mm, M)
check("1a) steigend -> 100 %", s["equity_share"], 1.0)
check("1b) fallend -> 0 %", T.compute_signal(down, mm, M)["equity_share"], 0.0)
# Gemischt: 12M-Rendite positiv, aber zuletzt Einbruch unter beide Durchschnitte, 9M negativ
mixed_vals = [104, 112, 118, 120, 118, 115, 112, 110, 106, 103, 101, 100, 100]
mixed = series(mixed_vals)
r12 = 104 / 100 - 1; r9 = 104 / 110 - 1
sma10 = sum(mixed_vals[:10]) / 10; sma12 = sum(mixed_vals[:12]) / 12
want = (int(r12 > (mm[M] / mm[months[12]] - 1)) + int(r9 > (mm[M] / mm[months[9]] - 1))
        + int(104 > sma10) + int(104 > sma12)) / 4
check("1c) gemischt von Hand nachgerechnet", T.compute_signal(mixed, mm, M)["equity_share"], want)
check("1c') gemischt = 25 %", want, 0.25)
check("1d) momentum12 binär", T.compute_signal(mixed, mm, M, "momentum12")["equity_share"], 1.0)
short = {k: v for k, v in up.items() if k != months[11]}
s2 = T.compute_signal(short, mm, M)
check("1e) Lücke -> unvollständig", (s2["complete"], s2["equity_share"]), (False, None))
check("1f) Jahreswechsel", (T._prev_month("2026-01"), T._prev_month("2026-01", 13), T._prev_month("2025-12", -1)),
      ("2025-12", "2024-12", "2026-01"))
check("1g) letzter abgeschlossener Monat", T.last_completed_month(date(2026, 1, 5)), "2025-12")

# ---------- 2) Gebühren ----------
check("2a) Aktionskauf 1.000 €", T.ing_order_fee(1000, "buy"), 1.90)
check("2b) Kauf 999 €", T.ing_order_fee(999, "buy"), round(4.90 + 2.4975, 2))
check("2c) Kauf ohne Aktion", T.ing_order_fee(5000, "buy", action_etf=False), 17.40)
check("2d) Verkauf 5.000 €", T.ing_order_fee(5000, "sell"), 17.40)
check("2e) Deckel", T.ing_order_fee(100000, "sell"), 69.90)

# ---------- 3) Empfehlung ----------
cfg = dict(T.DEFAULT_CONFIG, sat_eq_isin="IE00B3YLTY66", sat_mm_isin="LU0290358497", core_isin="IE0003XJA0J9",
           monthly_amount=500, core_share=70, min_trade=1000)
r = T.recommendation(cfg, 0.75, {"IE00B3YLTY66": 4000, "LU0290358497": 1000}, 0.75)
check("3a) Sparplan 75 %", r["savings_plan"], {"core": 350.0, "sat_eq": 112, "sat_mm": 38.0})
check("3b) Ziel erreicht -> kein Handel, kein Plan-Wechsel", (r["trade"], r["plan_changed"], r["action_needed"]),
      (None, False, False))
r = T.recommendation(cfg, 0.5, {"IE00B3YLTY66": 4000, "LU0290358497": 1000}, 0.75)
check("3c) Abweichung 1.500 € -> umschichten Aktien->Geldmarkt",
      (r["trade"]["sell_isin"], r["trade"]["buy_isin"], r["trade"]["amount"]), ("IE00B3YLTY66", "LU0290358497", 1500.0))
check("3d) Gebühren Verkauf+Aktionskauf", r["trade"]["fees"], round(4.90 + 3.75 + 1.90, 2))
r = T.recommendation(cfg, 0.75, {"IE00B3YLTY66": 3000, "LU0290358497": 1000}, 0.5)
check("3e) Abweichung 0 €, aber Plan geändert", (r["trade"], r["plan_changed"], r["action_needed"]), (None, True, True))
r = T.recommendation(cfg, 0.0, {"IE00B3YLTY66": 600, "LU0290358497": 0}, 0.25)
check("3f) komplettes Kippen unter Mindestorder -> trotzdem umschichten",
      (r["trade"]["amount"], r["trade"]["reason"]), (600.0, "full_flip"))
r = T.recommendation(cfg, 0.25, {"IE00B3YLTY66": 600, "LU0290358497": 0}, 0.5)
check("3g) Teilschritt unter Mindestorder -> nur Sparplan", r["trade"], None)

# ---------- 4) Depotpositionen aus FinTS ----------
with database.db() as conn:
    conn.execute("INSERT INTO assets (type, label, account_number, current_value) VALUES ('depot','ING Depot','5554443332', 0)")
    depot = conn.execute("SELECT id FROM assets WHERE label='ING Depot'").fetchone()["id"]
    conn.execute("INSERT INTO bank_accounts (connection_key, iban, account_number, label, balance, asset_id) "
                 "VALUES ('bank_conn_1','', '5554443332', 'Direkt-Depot', NULL, ?)", (depot,))
    conn.execute("INSERT INTO asset_holdings (asset_id, isin, name, current_value, source) VALUES (?,?,?,?, 'bank')",
                 (depot, "DE0005557508", "Verkaufte Aktie", 100))
    conn.execute("INSERT INTO asset_holdings (asset_id, isin, name, current_value) VALUES (?,?,?,?)",
                 (depot, "XX0000000000", "Von Hand", 50))
    T.store_price(conn, "IE00B3YLTY66", "2026-11-05", 200.0, "bank")
    hold = [{"account": {"iban": "", "account_number": "5554443332"}, "holdings": [
        {"isin": "IE00B3YLTY66", "name": "SPDR ACWI IMI", "price": 201.5, "currency": "EUR",
         "valuation_date": "2026-11-05", "pieces": 10.0, "total_value": 2015.0},
        {"isin": "LU0290358497", "name": "Xtrackers Overnight", "price": 150.0, "currency": "EUR",
         "valuation_date": "2026-11-05", "pieces": 4.0, "total_value": None}]}]
    n = T.store_bank_holdings(conn, "bank_conn_1", hold)
    rows = {r["isin"]: dict(r) for r in conn.execute("SELECT * FROM asset_holdings WHERE asset_id=?", (depot,))}
    check("4a) zwei Positionen übernommen", n, 2)
    check("4b) Wert aus Stück × Kurs", rows["LU0290358497"]["current_value"], 600.0)
    check("4c) verkaufte Bank-Position entfernt, Handeintrag bleibt",
          ("DE0005557508" in rows, "XX0000000000" in rows), (False, True))
    check("4d) Kurs gespeichert (Bank überschreibt Bank)",
          conn.execute("SELECT price FROM price_history WHERE isin='IE00B3YLTY66' AND date='2026-11-05'").fetchone()[0], 201.5)
    T.store_price(conn, "IE00B3YLTY66", "2026-11-05", 999.0, "justetf")
    check("4e) Abrufkurs überschreibt Bankkurs nicht",
          conn.execute("SELECT price FROM price_history WHERE isin='IE00B3YLTY66' AND date='2026-11-05'").fetchone()[0], 201.5)
    check("4f) Depotwert ohne Banksaldo = Summe Positionen",
          conn.execute("SELECT current_value FROM assets WHERE id=?", (depot,)).fetchone()[0], 2015.0)
    n2 = T.store_bank_holdings(conn, "bank_conn_1", [{"account": {"iban": "", "account_number": "999"},
                                                     "holdings": [{"isin": "IE0003XJA0J9", "price": 9.5, "valuation_date": "2026-11-05"}]}])
    check("4g) unbekanntes Depot -> keine Positionen, aber Kurs",
          (n2, conn.execute("SELECT COUNT(*) FROM price_history WHERE isin='IE0003XJA0J9'").fetchone()[0]), (0, 1))
    before = conn.execute("SELECT COUNT(*) FROM asset_holdings").fetchone()[0]
    try:
        T.store_bank_holdings(conn, "bank_conn_1", [{"account": {"iban": "", "account_number": "5554443332"},
                                                    "holdings": [{"isin": "IE00B3YLTY66", "pieces": "kaputt", "price": 1,
                                                                  "total_value": None, "valuation_date": "2026-11-06"}]}])
        raised = False
    except Exception:
        raised = True
    check("4h) Fehler -> Exception und nichts Halbes",
          (raised, conn.execute("SELECT COUNT(*) FROM asset_holdings").fetchone()[0],
           conn.execute("SELECT COUNT(*) FROM price_history WHERE date='2026-11-06'").fetchone()[0]), (True, before, 0))

# ---------- 5) FinTS: _fetch_holdings ----------
from fints.client import FinTSOperations, NeedTANResponse  # noqa: E402


class FakeInnerClient:
    def __init__(self, mode):
        self.mode = mode

    def get_information(self):
        bid = SimpleNamespace(bank_code="50010517")
        return {"accounts": [
            {"iban": "DE001", "account_number": "111", "bank_identifier": bid,
             "supported_operations": {FinTSOperations.GET_HOLDINGS: False}},
            {"iban": None, "account_number": "5554443332", "subaccount_number": None, "bank_identifier": bid,
             "supported_operations": {FinTSOperations.GET_HOLDINGS: True}}]}

    def get_holdings(self, acc):
        assert acc.accountnumber == "5554443332" and acc.blz == "50010517"
        if self.mode == "tan":
            return NeedTANResponse.__new__(NeedTANResponse)
        if self.mode == "error":
            raise RuntimeError("Bank sagt nein")
        H = SimpleNamespace
        return [H(ISIN="ie00b3ylty66", name="SPDR", market_value="201,50", value_symbol="EUR",
                  valuation_date=date(2026, 11, 5), pieces="10", total_value="2.015,00", acquisitionprice=None)]


class FakeScope:
    def __init__(self, c): self.c = c
    def __enter__(self): return self.c
    def __exit__(self, *a): return False


def fake_fints(mode):
    inner = SimpleNamespace(_client_scope=lambda: FakeScope(FakeInnerClient(mode)))
    return SimpleNamespace(_client=inner)


res = bank_client._fetch_holdings(fake_fints("ok"))
check("5a) nur Depot mit GET_HOLDINGS", [g["account"]["account_number"] for g in res], ["5554443332"])
check("5b) Position normalisiert", res[0]["holdings"][0],
      {"isin": "IE00B3YLTY66", "name": "SPDR", "price": 201.5, "currency": "EUR", "valuation_date": "2026-11-05",
       "pieces": 10.0, "total_value": 2015.0})
check("5c) Freigabe nötig -> übersprungen", bank_client._fetch_holdings(fake_fints("tan")), [])
check("5d) Bankfehler -> übersprungen", bank_client._fetch_holdings(fake_fints("error")), [])
check("5e) ohne easy-fints-Innenleben -> leer", bank_client._fetch_holdings(SimpleNamespace()), [])

# ---------- 6) Kursabruf ----------
calls = []


class FakeResp:
    def __init__(self, url, body): self.url, self.body = url, body
    def geturl(self): return self.url
    def read(self, n=-1): return self.body
    def __enter__(self): return self
    def __exit__(self, *a): return False


def make_urlopen(body, redirect=None):
    def _urlopen(req, timeout=None):
        calls.append(req.full_url)
        return FakeResp(redirect or req.full_url, body)
    return _urlopen


today = date.today()
monthly_days = []   # 14 Monatsenden rückwärts
d = today.replace(day=1) - timedelta(days=1)
for k in range(14):
    monthly_days.append(d)
    d = d.replace(day=1) - timedelta(days=1)
series_up = [{"date": x.isoformat(), "value": {"raw": 100 + 2 * (13 - i)}} for i, x in enumerate(monthly_days)]
series_up.append({"date": today.isoformat(), "value": {"raw": 130}})
series_mm = [{"date": x.isoformat(), "value": {"raw": 100 + 0.1 * (13 - i)}} for i, x in enumerate(monthly_days)]
series_mm.append({"date": today.isoformat(), "value": {"raw": 101.5}})

import urllib.request as ur  # noqa: E402
orig = ur.urlopen
with database.db() as conn:
    check("6a) Abruf aus -> nichts", T.refresh_prices(conn, force=True)["status"], "off")
    T._save_setting(conn, T.CONFIG_KEY, dict(cfg, enabled=True, asset_id=depot, price_fetch=True))


def routed(req, timeout=None):
    body = json.dumps({"series": series_mm if "LU0290358497" in req.full_url else series_up}).encode()
    calls.append(req.full_url)
    return FakeResp(req.full_url, body)


ur.urlopen = routed
try:
    with database.db() as conn:
        out = T.refresh_prices(conn, force=True)
    check("6b) Abruf ok", out["status"], "ok")
    check("6c) nur justETF-Host, nur ISIN + feste Parameter",
          all(u.startswith("https://www.justetf.com/api/etfs/") and "5554443332" not in u and "2015" not in u
              for u in calls) and len(calls) == 3, True)
    with database.db() as conn:
        check("6d) zweiter Abruf ohne force übersprungen", T.refresh_prices(conn)["status"], "skipped")
    ur.urlopen = make_urlopen(b"{}", redirect="https://boese.example/x")
    try:
        T.fetch_prices_justetf("IE00B3YLTY66"); red = False
    except ValueError:
        red = True
    check("6e) Weiterleitung zu fremdem Host abgelehnt", red, True)
    try:
        T._http_get_json("https://www.justetf.com.boese.de/api"); host = False
    except ValueError:
        host = True
    check("6f) fremder Host abgelehnt", host, True)
    ur.urlopen = make_urlopen(b"kein json")
    with database.db() as conn:
        out = T.refresh_prices(conn, force=True)
    check("6g) kaputte Antwort -> Fehlerstatus", (out["status"], out["ok"]), ("error", False))
    try:
        T.fetch_prices_justetf("../etc/passwd"); bad = False
    except ValueError:
        bad = True
    check("6h) ungültige ISIN nie in die URL", bad, True)
finally:
    ur.urlopen = orig

# ---------- 9) Zeitplan ----------
from datetime import datetime  # noqa: E402
now = datetime(2026, 11, 6, 14, 30)
check("9a) Sekunden bis 0:00", T.seconds_until_midnight(now), 9.5 * 3600)
check("9b) 23:59:59 -> 1 s", T.seconds_until_midnight(datetime(2026, 12, 31, 23, 59, 59)), 1.0)
check("9c) Start: nie abgerufen -> nachholen", T.needs_startup_fetch({}, now), True)
check("9d) Start: letzter Abruf fehlgeschlagen -> nachholen",
      T.needs_startup_fetch({"at": "2026-11-06T00:00:05", "ok": False}, now), True)
check("9e) Start: heute 0:00 erfolgreich -> nicht nachholen",
      T.needs_startup_fetch({"at": "2026-11-06T00:00:05", "ok": True}, now), False)
check("9f) Start: 0:00-Lauf verpasst (letzter gestern) -> nachholen",
      T.needs_startup_fetch({"at": "2026-11-05T00:00:05", "ok": True}, now), True)
check("9g) Start: kaputter Zeitstempel -> nachholen", T.needs_startup_fetch({"at": "x", "ok": True}, now), True)
fetched = []
orig_refresh, orig_db = T.refresh_prices, database.db
T.refresh_prices = lambda conn, force=False: fetched.append(force) or {"status": "ok"}
T.database.db = lambda real=False: orig_db()          # Testlauf: Temp-DB statt "echter" DB
try:
    with database.db() as conn:
        T._save_setting(conn, T.CONFIG_KEY, dict(cfg, enabled=True, asset_id=depot, price_fetch=True))
        T._save_setting(conn, T.FETCH_STATUS_KEY, {"at": datetime.now().isoformat(timespec="seconds"), "ok": True})
    T.run_scheduled(startup=True)
    check("9h) Start nach erfolgreichem Abruf heute -> kein Abruf", fetched, [])
    with database.db() as conn:
        T._save_setting(conn, T.FETCH_STATUS_KEY, {"at": datetime.now().isoformat(timespec="seconds"), "ok": False})
    T.run_scheduled(startup=True)
    check("9i) Start nach Fehlschlag -> Abruf (erzwungen)", fetched, [True])
    T.run_scheduled()
    check("9j) 0:00-Lauf ruft immer ab", fetched, [True, True])
    with database.db() as conn:
        T._save_setting(conn, T.CONFIG_KEY, dict(cfg, enabled=True, asset_id=depot, price_fetch=False))
    T.run_scheduled()
    check("9k) Kursabruf aus -> kein Abruf", fetched, [True, True])
finally:
    T.refresh_prices, T.database.db = orig_refresh, orig_db

# ---------- 7) API und Dashboard ----------
import auth  # noqa: E402
import app as appmod  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

appmod.app.dependency_overrides[auth.require_full_auth] = lambda: {"stage": "full"}
cl = TestClient(appmod.app, base_url="http://localhost:8420", raise_server_exceptions=False)
base = dict(enabled=True, asset_id=depot, core_isin="IE0003XJA0J9", sat_eq_isin="IE00B3YLTY66",
            sat_mm_isin="LU0290358497", core_share=70, monthly_amount=500, rule="ensemble", min_trade=1000,
            action_etfs=True, price_fetch=True)
check("7a) ungültige ISIN -> 400", cl.put("/api/trend/config", json=dict(base, sat_eq_isin="ABC")).status_code, 400)
check("7b) Core = Satellit -> 400", cl.put("/api/trend/config", json=dict(base, core_isin="IE00B3YLTY66")).status_code, 400)
with database.db() as conn:
    conn.execute("INSERT INTO assets (type, label, current_value) VALUES ('konto','Giro', 1)")
    giro = conn.execute("SELECT id FROM assets WHERE label='Giro'").fetchone()["id"]
check("7c) Konto statt Depot -> 400", cl.put("/api/trend/config", json=dict(base, asset_id=giro)).status_code, 400)
check("7d) gültig -> gespeichert", cl.put("/api/trend/config", json=dict(base, sat_eq_isin=" ie00b3ylty66 ")).status_code, 200)
st = cl.get("/api/trend").json()
check("7e) Signal vollständig, 100 % Aktien", (st["signal"]["complete"], st["signal"]["equity_share"]), (True, 1.0))
check("7f) ISIN normalisiert", st["config"]["sat_eq_isin"], "IE00B3YLTY66")
d = cl.get("/api/dashboard").json()
check("7g) Hinweis ganz vorn", (d["hints"][0]["anchor"], d["hints"][0]["icon"]), ("trend-card", "📈"))
check("7h) erster Monat: Sparplan einrichten", "Sparplan umstellen" in d["hints"][0]["text"] or "Umschichten" in d["hints"][0]["text"], True)
check("7i) Quittieren", cl.post("/api/trend/ack").status_code, 200)
d = cl.get("/api/dashboard").json()
check("7j) nach Umgesetzt kein Signal-Hinweis", any(h.get("anchor") == "trend-card" and h["icon"] == "📈" for h in d["hints"]), False)
with database.db() as conn:
    conn.execute("DELETE FROM price_history WHERE date >= ?", ((today - timedelta(days=10)).isoformat(),))
d = cl.get("/api/dashboard").json()
check("7k) Kurse veraltet -> Hinweis", any(h["icon"] == "⏱️" for h in d["hints"]), True)
check("7l) Routen vorhanden", all(p in appmod.app.openapi()["paths"] for p in
                                   ("/api/trend", "/api/trend/config", "/api/trend/refresh", "/api/trend/ack")), True)

print()
print("ALLES GRÜN" if not FAILS else f"{len(FAILS)} FEHLER: {FAILS}")
sys.exit(1 if FAILS else 0)
