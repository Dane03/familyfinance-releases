"""Chatbot-Kontext (v373): Kommen die Kontostände sicher beim Modell an?

Anlass: Der Chatbot kannte den Tagesgeld-Saldo nicht und nahm einen Betrag aus der Frage als
Kontostand. Ursache: Kontext (bis 150 Umsätze als JSON) länger als Ollamas Kontextfenster,
`num_ctx` nicht gesetzt -> Ollama schnitt still ab.

Prüft ohne Server und ohne Ollama (Anfrage wird abgefangen), DB im Temp-Ordner aus schema.sql:
    cd kopie/backend && python3 ../scripts/review/chatbot.py
"""
import json
import sys
import tempfile
from datetime import date, timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
import database  # noqa: E402

tmp = Path(tempfile.mkdtemp())
database.BASE_DIR = tmp
database.DB_PATH = tmp / "ff.db"
database.DEMO_DB_PATH = tmp / "demo.db"
database.init_db()
import chatbot  # noqa: E402

FAILS = []


def check(name, ok, info=""):
    print(f"{'✓' if ok else '✗'} {name}" + (f" — {info}" if info else ""))
    if not ok:
        FAILS.append(name)


TODAY = date(2026, 11, 6)
with database.db() as c:
    c.execute("INSERT INTO assets (type, label, provider, account_type, current_value, updated_at) "
              "VALUES ('konto', 'Tagesgeld', 'ING', 'tagesgeld', 1.0, '2026-01-01')")   # alter Handwert
    tg = c.execute("SELECT max(id) FROM assets").fetchone()[0]
    c.execute("INSERT INTO assets (type, label, current_value, updated_at) "
              "VALUES ('konto', 'Bargeldkasse', 250, '2026-10-01')")
    c.execute("INSERT INTO assets (type, label, current_value) VALUES ('depot', 'ETF-Depot', 30000)")
    c.execute("INSERT INTO bank_accounts (connection_key, iban, account_number, label, balance, "
              "balance_updated_at, asset_id) VALUES ('bank_conn_1', 'DE00TEST0000000001', '1', "
              "'Extra-Konto', 61234.56, '2026-11-06 07:00:00', ?)", (tg,))
    c.execute("INSERT INTO bank_accounts (connection_key, iban, account_number, label, balance, "
              "balance_updated_at) VALUES ('bank_conn_1', 'DE00TEST0000000002', '2', 'Girokonto', "
              "1500, '2026-11-05')")
    giro = c.execute("SELECT max(id) FROM bank_accounts").fetchone()[0]
    for i in range(400):   # viele Umsätze -> der alte Kontext lief über
        d = (TODAY - timedelta(days=i % 55)).isoformat()
        c.execute("INSERT INTO bank_transactions (bank_account_id, booking_date, amount, counterparty_name, "
                  "purpose, tx_hash) VALUES (?, ?, ?, ?, ?, ?)",
                  (giro, d, -12.34 if i % 2 else 100.0, f"Händler Nummer {i}", "Verwendungszweck " * 6, f"h{i}"))
    for i in range(60):
        c.execute("INSERT INTO contracts (label, provider, amount, frequency, status, source) "
                  "VALUES (?, 'Anbieter', 10, 'monthly', 'active', 'manuell')", (f"Vertrag {i}",))
    c.execute("INSERT INTO contracts (label, amount, frequency, status, source) "
              "VALUES ('Jahresbeitrag', 120, 'yearly', 'active', 'manuell')")

ctx = chatbot.build_context(TODAY)
last = ctx.split("KONTOSTÄNDE", 1)[-1]
check("Kontext unter Obergrenze", len(ctx) <= chatbot.CONTEXT_MAX_CHARS, f"{len(ctx)} Zeichen")
check("Kontostände sind der letzte Block", "KONTOSTÄNDE" in ctx and "VERTRÄGE" not in last)
check("Tagesgeld mit Bank-Saldo (nicht Handwert)", "Tagesgeld" in last and "61.234,56 €" in last
      and "1,00 €" not in last, )
check("Stand-Datum der Bank", "Stand 06.11.2026 (von der Bank abgerufen)" in last)
check("Handkonto mit eigenem Stand", "Bargeldkasse" in last and "Stand 01.10.2026 (von Hand gepflegt)" in last)
check("Nicht zugeordnetes Bankkonto", "Girokonto" in last and "1.500,00 €" in last)
check("Depot nicht unter Kontoständen", "ETF-Depot" not in last and "ETF-Depot" in ctx)
check("Fixkosten-Summe centgenau (60×10 + 120/12 = 610)", "SUMME aller Fixkosten: 610,00 € pro Monat" in ctx)
check("Umsätze als Monatssumme", "2026-11 | Eingänge" in ctx)
check("Heute steht drin", "06.11.2026" in ctx.split("FAMILIEN")[0])

check("Rechenfrage -> Denken an", chatbot._needs_reasoning(
    "Kia 43.000€, Inzahlungnahme 20.000€ — was bleibt übrig auf dem Tagesgeld?"))
check("Einfache Frage -> Denken aus", not chatbot._needs_reasoning("Welche Verträge laufen bald aus?"))

sent = {}


class FakeResp:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self):
        return json.dumps({"message": {"content": "<think>x</think>Antwort"}}).encode()


def fake_urlopen(req, timeout):
    sent["payload"] = json.loads(req.data)
    sent["timeout"] = timeout
    return FakeResp()


with patch.object(chatbot.urllib.request, "urlopen", fake_urlopen):
    ans = chatbot.ask("Was bleibt übrig, wenn 23.000 € und 4.000 € abgehen?")
p = sent["payload"]
check("num_ctx gesetzt", p.get("options", {}).get("num_ctx") == chatbot.NUM_CTX)
check("Kontext + Prompt passen ins Fenster (~3 Zeichen/Token)",
      len(p["messages"][0]["content"]) // 3 < chatbot.NUM_CTX - 1500, f"{len(p['messages'][0]['content'])} Zeichen")
check("Denken bei Rechenfrage + längere Wartezeit", p["think"] is True and sent["timeout"] >= 120)
check("Denk-Block entfernt", ans == "Antwort")

print(f"\n{len(FAILS)} Fehler" if FAILS else "\nAlles grün")
sys.exit(1 if FAILS else 0)
