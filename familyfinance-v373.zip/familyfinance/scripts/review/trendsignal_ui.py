"""Trendsignal im Browser (v372, iPhone 390 px, Demodaten). Mit Server auf Port 8420.
    cd kopie/backend && python3 ../scripts/review/trendsignal_ui.py
Prüft: Dashboard-Hinweis ganz vorn mit Sprung zur Karte, Karte auf der Vermögensseite (Signal, Einzelsignale,
Sparplan, Umschichten), kein seitlicher Überlauf (Karte und Einstellungsdialog, auch Textgröße L), Tippflächen der
Knöpfe, Einstellungsdialog öffnen/speichern/Esc, "Umgesetzt" entfernt den Hinweis, bösartiger Depotname kommt nie
als HTML an, keine JS-Fehler. Exit-Code 1 bei Befund."""
import json
import sys
import threading
import time
import warnings
from datetime import date, timedelta

warnings.filterwarnings("ignore")
sys.path.insert(0, ".")
import database  # noqa: E402
import auth  # noqa: E402
import demo_data  # noqa: E402

database.init_db()
demo_data.generate_demo_db()
database._use_demo_db.set(True)
database.init_db()

FAILS = []


def check(name, cond, info=""):
    print(("OK   " if cond else "FEHL ") + name + ("" if cond else f"  -> {info}"))
    if not cond:
        FAILS.append(name)


with database.db() as conn:
    depot = conn.execute("SELECT id FROM assets WHERE type='depot' AND archived_at IS NULL ORDER BY id LIMIT 1").fetchone()["id"]
    conn.execute("UPDATE assets SET label=? WHERE id=?", ('Depot <img src=x onerror="window.__xss=1">', depot))
    conn.execute("INSERT INTO asset_holdings (asset_id, isin, name, current_value, source) VALUES (?,?,?,?,'bank')",
                 (depot, "IE00B3YLTY66", "SPDR MSCI ACWI IMI", 6000))
    conn.execute("INSERT INTO asset_holdings (asset_id, isin, name, current_value, source) VALUES (?,?,?,?,'bank')",
                 (depot, "LU0290358497", "Xtrackers EUR Overnight", 500))
    # 15 Monatsenden: Aktien zuletzt eingebrochen (gemischtes Signal), Geldmarkt stetig
    d = date.today().replace(day=1) - timedelta(days=1)
    eq_vals = [104, 112, 118, 120, 118, 115, 112, 110, 106, 103, 101, 100, 100, 99, 98]
    for i in range(15):
        conn.execute("INSERT OR REPLACE INTO price_history (isin, date, price, source) VALUES (?,?,?, 'bank')",
                     ("IE00B3YLTY66", d.isoformat(), eq_vals[i]))
        conn.execute("INSERT OR REPLACE INTO price_history (isin, date, price, source) VALUES (?,?,?, 'bank')",
                     ("LU0290358497", d.isoformat(), 100 + 0.2 * (14 - i)))
        d = d.replace(day=1) - timedelta(days=1)
    for isin, p in (("IE00B3YLTY66", 105), ("LU0290358497", 103)):
        conn.execute("INSERT OR REPLACE INTO price_history (isin, date, price, source) VALUES (?,?,?, 'bank')",
                     (isin, date.today().isoformat(), p))
    cfg = {"enabled": True, "asset_id": depot, "core_isin": "IE0003XJA0J9", "sat_eq_isin": "IE00B3YLTY66",
           "sat_mm_isin": "LU0290358497", "core_share": 70, "monthly_amount": 500, "rule": "ensemble",
           "min_trade": 1000, "action_etfs": True, "price_fetch": False}
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('trend_config', ?)", (json.dumps(cfg),))

import uvicorn  # noqa: E402
import app as appmod  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

TestClient(appmod.app).post("/api/auth/setup", json={"username": "tester", "password": "testtest123"})
srv = uvicorn.Server(uvicorn.Config(appmod.app, host="127.0.0.1", port=8420, log_level="error"))
threading.Thread(target=srv.run, daemon=True).start()
time.sleep(3)

from playwright.sync_api import sync_playwright  # noqa: E402

tok = auth._serializer.dumps({"stage": "full", "iat": "x", "demo": True})
OVERFLOW_JS = """(sel) => [...document.querySelectorAll(sel + ' *')].filter(e => {
  const r = e.getBoundingClientRect(); return r.width && (r.right > innerWidth + 1 || r.left < -1); }).length"""
SMALL_TAP_JS = """(sel) => [...document.querySelectorAll(sel + ' button')].filter(b => b.offsetParent !== null)
  .filter(b => { const r = b.getBoundingClientRect(); return r.height < 40; }).map(b => b.textContent.trim().slice(0, 30))"""

with sync_playwright() as p:
    b = p.chromium.launch()
    for size in ("M", "L"):
        ctx = b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True, device_scale_factor=2)
        ctx.add_cookies([{"name": "ffz_session", "value": tok, "url": "http://localhost:8420"}])
        if size == "L":
            ctx.add_init_script("try{localStorage.setItem('ui_scale','l')}catch(e){}")
        pg = ctx.new_page()
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)[:120]))
        pg.goto("http://localhost:8420")
        pg.wait_for_timeout(2500)          # Service-Worker kann beim ersten Aufruf einmal neu laden
        pg.wait_for_load_state("networkidle")
        pg.wait_for_selector("#duedates-list li", timeout=15000)
        first = pg.locator("#duedates-list li").first.inner_text()
        if size == "M":
            check("Dashboard: Trendsignal-Hinweis ganz vorn", "Trendsignal" in first and "📈" in first, first[:120])
            pg.locator("#duedates-list li").first.locator("[data-go-tab]").click()
        else:   # Hinweis ist nach "Umgesetzt" (Lauf M) weg -> direkt zur Vermögensseite
            pg.evaluate("document.querySelector('.sidebar-btn[data-tab=\"tab-vermoegen\"]').click()")
        pg.wait_for_selector("#trend-card #trend-content .stats", timeout=10000)
        txt = pg.inner_text("#trend-card")
        if size == "M":
            check("Karte: Ziel 25 % (gemischtes Signal)", "25 %" in txt, txt[:200])
            check("Karte: vier Einzelsignale", pg.locator("#trend-card li:has-text('Momentum'), #trend-card li:has-text('Durchschnitt')").count() == 4)
            check("Karte: Umschichten-Vorschlag", "Umschichten" in txt and "Gebühren" in txt, txt[:300])
            check("Karte: Sprungziel sichtbar", pg.evaluate("document.getElementById('trend-card').getBoundingClientRect().top < innerHeight"))
        check(f"[{size}] Karte ohne seitlichen Überlauf", pg.evaluate(OVERFLOW_JS, "#trend-card") == 0)
        small = pg.evaluate(SMALL_TAP_JS, "#trend-card")
        check(f"[{size}] Tippflächen Karte ≥ 40 px", not small, small)
        pg.click("#trend-settings-btn")
        pg.wait_for_selector("#trend-config-overlay", state="visible")
        check(f"[{size}] Dialog ohne seitlichen Überlauf", pg.evaluate(OVERFLOW_JS, "#trend-config-overlay .auth-card") == 0)
        fs = pg.evaluate("[...document.querySelectorAll('#trend-config-overlay input:not([type=checkbox]), #trend-config-overlay select')]"
                         ".map(e => parseFloat(getComputedStyle(e).fontSize)).filter(f => f < 16).length")
        check(f"[{size}] Eingabefelder ≥ 16 px (kein iOS-Zoom)", fs == 0, fs)
        check(f"[{size}] Depot vorausgewählt", pg.input_value("#trend-asset") == str(depot))
        check(f"[{size}] Depotname nicht als HTML", pg.evaluate("window.__xss") is None
              and pg.locator("#trend-asset img").count() == 0)
        pg.keyboard.press("Escape")
        check(f"[{size}] Esc schließt Dialog", pg.locator("#trend-config-overlay").is_hidden())
        if size == "M":
            pg.click("#trend-settings-btn")
            pg.fill("#trend-core-isin", "IE00B3YLTY66")   # gleich wie Satellit -> Fehlermeldung, Dialog bleibt
            pg.click("#trend-config-form button[type=submit]")
            pg.wait_for_timeout(600)
            check("Dialog: Core = Satellit wird abgelehnt", pg.locator("#trend-config-overlay").is_visible())
            pg.fill("#trend-core-isin", "IE0003XJA0J9")
            pg.fill("#trend-min-trade", "500")
            pg.click("#trend-config-form button[type=submit]")
            pg.wait_for_selector("#trend-config-overlay", state="hidden", timeout=5000)
            pg.wait_for_timeout(800)
            pg.click("#trend-ack-btn")
            pg.wait_for_timeout(1200)
            check("Umgesetzt: Karte quittiert", "Umgesetzt" in pg.inner_text("#trend-card") and pg.locator("#trend-ack-btn").count() == 0)
            pg.evaluate("document.querySelector('.sidebar-btn[data-tab=\"tab-dashboard\"]').click()")
            pg.wait_for_timeout(1200)
            check("Umgesetzt: Hinweis weg", "📈" not in pg.inner_text("#duedates-list"))
        check(f"[{size}] keine JS-Fehler", not errs, errs)
        ctx.close()
    b.close()

print()
print("ALLES GRÜN" if not FAILS else f"{len(FAILS)} FEHLER: {FAILS}")
sys.exit(1 if FAILS else 0)
