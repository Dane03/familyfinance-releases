"""
Energy Monitor — Berechnungslogik für Zählerstände, Verbrauch und Abrechnung.

Migriert aus der eigenständigen Energy-Monitor-App (localStorage-basiert) in
die Family-Hub-Datenbank. Rechenlogik bewusst vereinfacht gegenüber dem
Original:
- Verbrauchsprognose für fehlende Monate nutzt die aktuelle Tagesrate statt
  der sehr hausspezifischen Monatsfaktor-Tabelle des Originals.
- Der Sungrow/PV-Import (iSolarCloud) ist NICHT migriert — nur Gas, Strombezug,
  Strom-Einspeisung und neu Wasser, mit denselben Kernrechnungen (Verbrauch,
  Tagesrate, Abrechnungsvergleich Abschlag vs. tatsächliche Kosten).

Zählerwechsel werden generisch über das Flag is_new_meter gehandhabt: die
erste Ablesung nach einem Wechsel markiert eine Zäsur, das Intervall davor
wird bei der Verbrauchsberechnung übersprungen — keine hausspezifischen
Konstanten mehr nötig (anders als im Original mit fest einprogrammiertem
ELEC_BASIS_OLD).
"""
import json
from datetime import date, datetime, timedelta
from typing import Optional

METER_TYPES = ("gas", "elec_in", "elec_out", "water")

METER_META = {
    "gas": {"label": "Gas", "unit": "m³", "icon": "🔥"},
    "elec_in": {"label": "Strombezug", "unit": "kWh", "icon": "⚡"},
    "elec_out": {"label": "Einspeisung", "unit": "kWh", "icon": "↑"},
    "water": {"label": "Wasser", "unit": "m³", "icon": "💧"},
}

# Anlagenstammdaten der PV-Anlage — rein informativ auf der Übersichtskarte,
# kein Berechnungsfaktor. Bewusst ohne Vorbelegung, jede Installation trägt
# ihre eigene Anlage über die Einstellungen ein.
PV_PLANT_DEFAULTS = {"kwp": 0, "model": "", "hersteller": ""}

# Klimamittel-Referenzwerte (DWD, bundesweiter Durchschnitt Deutschland) —
# permanente Konstante, kein Live-Datenabruf. Für die Temperatur-Kurve auf
# der Gas-Seite. Bewusst der bundesweite statt ein regionaler Durchschnitt,
# damit kein Rückschluss auf den Wohnort einzelner Nutzer möglich ist.
DWD_CLIMATE_AVG = {1: 2.1, 2: 2.8, 3: 6.2, 4: 10.3, 5: 14.4, 6: 17.4,
                   7: 19.4, 8: 19.0, 9: 14.9, 10: 10.3, 11: 5.6, 12: 2.9}

RANGES = [
    {"id": "1m", "label": "1 Mo"},
    {"id": "3m", "label": "3 Mo"},
    {"id": "12m", "label": "12 Mo"},
    {"id": "ytd", "label": "YTD"},
    {"id": "all", "label": "Gesamt"},
]


def fetch_actual_monthly_temperatures(location: str, months_back: int = 15) -> dict:
    """Holt tatsächliche Monats-Durchschnittstemperaturen für einen vom
    Nutzer selbst eingetragenen Standort (z.B. Ort oder Postleitzahl) über
    Open-Meteo — kostenlos, ohne API-Schlüssel, kein Standort fest im Code
    hinterlegt. Wird nur aufgerufen, wenn der Nutzer selbst einen Standort
    in den Einstellungen hinterlegt hat. Gibt {} zurück und wirft nie einen
    Fehler nach außen, falls Standort leer, Geocoding erfolglos oder das
    Netzwerk nicht erreichbar ist -- ein fehlgeschlagener Wetter-Abruf darf
    den restlichen App-Start niemals stören."""
    import urllib.request
    import urllib.parse
    from datetime import date as _date, timedelta

    if not location or not location.strip():
        return {}

    try:
        geo_url = "https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(
            {"name": location.strip(), "count": 1, "language": "de"}
        )
        with urllib.request.urlopen(geo_url, timeout=10) as resp:
            geo = json.loads(resp.read().decode("utf-8"))
        results = geo.get("results") or []
        if not results:
            return {}
        lat, lon = results[0]["latitude"], results[0]["longitude"]

        end = _date.today() - timedelta(days=3)  # Archiv braucht ein paar Tage Vorlauf
        start = (end.replace(day=1) - timedelta(days=months_back * 31)).replace(day=1)
        archive_url = "https://archive-api.open-meteo.com/v1/archive?" + urllib.parse.urlencode({
            "latitude": lat, "longitude": lon,
            "start_date": start.isoformat(), "end_date": end.isoformat(),
            "daily": "temperature_2m_mean", "timezone": "auto",
        })
        with urllib.request.urlopen(archive_url, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        daily = data.get("daily", {})
        dates = daily.get("time", [])
        temps = daily.get("temperature_2m_mean", [])
        by_month: dict[str, list[float]] = {}
        for d, t in zip(dates, temps):
            if t is None:
                continue
            month_key = d[:7]  # "YYYY-MM"
            by_month.setdefault(month_key, []).append(t)

        return {m: round(sum(vals) / len(vals), 1) for m, vals in by_month.items() if vals}
    except Exception:
        return {}



def resolution_for_range(range_id: str) -> str:
    """Die zum Zeitraum passende Auflösung — kurze Zeiträume feiner, lange
    gröber. Ohne das zeigt z.B. "1 Monat" nur einen einzigen Balken, was
    keinerlei Verlauf erkennen lässt."""
    return {"1m": "day", "3m": "week"}.get(range_id, "month")


def range_start_date(range_id: str) -> Optional[date]:
    """Startdatum des Zeitraums, oder None für "alles"."""
    if range_id == "all" or not range_id:
        return None
    today = date.today()
    if range_id == "ytd":
        return date(today.year, 1, 1)
    months_back = {"1m": 1, "3m": 3, "12m": 12}.get(range_id)
    if months_back is None:
        return None
    m, y = today.month - months_back, today.year
    while m <= 0:
        m += 12
        y -= 1
    return date(y, m, today.day if range_id != "12m" else 1)


def filter_keys_by_range(keys: list, range_id: str) -> list:
    """Filtert Zeitabschnitt-Schlüssel nach Zeitraum. Versteht alle drei
    Schlüssel-Formate (Tag '2026-07-15', Woche '2026-W29', Monat '2026-07'),
    damit dieselbe Funktion unabhängig von der gewählten Auflösung greift."""
    if range_id == "all" or not range_id:
        return sorted(keys)
    cutoff = range_start_date(range_id)
    if cutoff is None:
        return sorted(keys)

    def in_range(k: str) -> bool:
        try:
            if "W" in k:  # ISO-Woche: über das Montagsdatum der Woche vergleichen
                iso_year, iso_week = int(k[:4]), int(k.split("W")[1])
                monday = date.fromisocalendar(iso_year, iso_week, 1)
                return monday >= cutoff
            parts = k.split("-")
            if len(parts) == 3:  # Tag
                return date(int(parts[0]), int(parts[1]), int(parts[2])) >= cutoff
            # Monat: der ganze Monat zählt, wenn sein Ende nach dem Stichtag liegt
            return f"{parts[0]}-{parts[1]}" >= f"{cutoff.year}-{cutoff.month:02d}"
        except (ValueError, IndexError):
            return False

    return sorted(k for k in keys if in_range(k))


def months_in_range(range_id: str) -> float:
    """Näherungsweise Monatsanzahl im Zeitraum — für Kostenhochrechnung
    (Grundpreis-Anteil etc.)."""
    today = date.today()
    return {"1m": 1, "3m": 3, "ytd": today.month, "all": 24}.get(range_id, today.month)

DEFAULT_SETTINGS = {
    "gas": {"abschlag": 0.0, "arbeitspreis": 0.0, "grundpreis": 0.0, "brennwert": 10.0,
            "anbieter": "", "vertragsende": None, "settle_month": 1, "settle_day": 1},
    "elec_in": {"abschlag": 0.0, "arbeitspreis": 0.0, "grundpreis": 0.0,
                "anbieter": "", "vertragsende": None, "settle_month": 1, "settle_day": 1},
    "elec_out": {"abschlag": 0.0, "einspeisepreis": 0.0, "anbieter": "",
                 "settle_month": 1, "settle_day": 31},
    "water": {"abschlag": 0.0, "arbeitspreis": 0.0, "grundpreis": 0.0,
              "anbieter": "", "vertragsende": None, "settle_month": 1, "settle_day": 1},
}


def _parse_date(d) -> date:
    if isinstance(d, date):
        return d
    return datetime.strptime(str(d)[:10], "%Y-%m-%d").date()


def _period_key(d: date, resolution: str) -> str:
    """Ordnet ein Datum dem passenden Zeitabschnitt zu.

    - 'day'   -> '2026-07-15'  (Tag)
    - 'week'  -> '2026-W29'    (ISO-Kalenderwoche, beginnt montags)
    - 'month' -> '2026-07'     (Monat)
    """
    if resolution == "day":
        return d.isoformat()
    if resolution == "week":
        iso_year, iso_week, _ = d.isocalendar()
        return f"{iso_year}-W{iso_week:02d}"
    return f"{d.year}-{d.month:02d}"


def consumption_by_period(readings: list, resolution: str = "month") -> dict:
    """Verteilt den Verbrauch zwischen zwei Ablesungen tagesanteilig auf die
    betroffenen Zeitabschnitte. readings: Liste von dicts mit reading_date,
    value, is_new_meter, sortiert aufsteigend nach Datum.

    'resolution' steuert die Feinheit: 'day', 'week' oder 'month'. Die
    tagesanteilige Verteilung ist in allen Fällen identisch — es ändert sich
    nur, wie die Tage anschließend zusammengefasst werden. Dadurch bleibt die
    Summe über einen Zeitraum unabhängig von der gewählten Auflösung gleich.

    Ergebnis: {'2026-07': 45.3, ...} — Verbrauch je Abschnitt in derselben
    Einheit wie die Zählerstände (m³ oder kWh)."""
    by_period: dict = {}
    for prev, cur in zip(readings, readings[1:]):
        # Zählerwechsel: die erste Ablesung des neuen Zählers markiert eine
        # Zäsur — der "Sprung" zwischen altem Endstand und neuem Startstand
        # ist kein Verbrauch, das Intervall wird übersprungen.
        if cur.get("is_new_meter"):
            continue
        d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
        days = (d2 - d1).days
        if days <= 0:
            continue
        delta = cur["value"] - prev["value"]
        if delta < 0:
            continue  # unplausibel (z.B. vertauschte Reihenfolge) -> ignorieren
        daily_rate = delta / days
        d = d1
        while d < d2:
            key = _period_key(d, resolution)
            next_day_start = min(d + timedelta(days=1), d2)
            fraction_days = (next_day_start - d).days
            by_period[key] = by_period.get(key, 0.0) + daily_rate * fraction_days
            d = next_day_start
    return {k: round(v, 3) for k, v in by_period.items()}


def monthly_consumption(readings: list) -> dict:
    """Monatliche Aggregation — dünne Hülle um consumption_by_period(), damit
    alle bestehenden Aufrufer unverändert weiterlaufen."""
    return consumption_by_period(readings, "month")


def current_daily_rate(readings: list) -> Optional[float]:
    """Tagesrate aus dem letzten gültigen (nicht durch Zählerwechsel
    unterbrochenen) Intervall — für "aktueller Verbrauch pro Tag" auf dem
    Dashboard."""
    for prev, cur in zip(reversed(readings[:-1]), reversed(readings[1:])):
        if cur.get("is_new_meter"):
            continue
        d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
        days = (d2 - d1).days
        if days <= 0:
            continue
        delta = cur["value"] - prev["value"]
        if delta < 0:
            continue
        return round(delta / days, 3)
    return None


def current_daily_rate_with_pv(meter_type: str, readings: list, pv_monthly: list) -> Optional[float]:
    """Wie current_daily_rate(), aber für elec_in/elec_out zusätzlich den
    PV-Import als Quelle einbezogen und die JEWEILS AKTUELLERE Quelle gewählt.

    Hintergrund: Netzbezug und Einspeisung kommen bei den meisten Haushalten
    ausschließlich aus dem monatlichen PV-Import, nicht aus manuell erfassten
    Zählerständen. Verließe sich die Tagesrate ausschließlich auf
    readings, bliebe sie beim letzten manuellen Ablesewert eingefroren,
    sobald jemand nur noch importiert — ein neuer Monatsimport würde die
    Kennzahl dann nie wieder aktualisieren."""
    reading_rate, reading_date_ = None, None
    for prev, cur in zip(reversed(readings[:-1]), reversed(readings[1:])):
        if cur.get("is_new_meter"):
            continue
        d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
        days = (d2 - d1).days
        if days <= 0:
            continue
        delta = cur["value"] - prev["value"]
        if delta < 0:
            continue
        reading_rate, reading_date_ = round(delta / days, 3), d2
        break

    if meter_type not in ("elec_in", "elec_out") or not pv_monthly:
        return reading_rate

    field = "bezug" if meter_type == "elec_in" else "einsp"
    last_pv = max(pv_monthly, key=lambda r: r["key"])
    y, m = int(last_pv["key"][:4]), int(last_pv["key"][5:7])
    days_in_month = (date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)) - date(y, m, 1)
    pv_rate = round((last_pv.get(field) or 0.0) / days_in_month.days, 3)
    # Letzten Tag des PV-Monats als Vergleichsdatum nehmen, um zu entscheiden,
    # welche Quelle aktueller ist.
    pv_date = date(y, m, days_in_month.days)

    if reading_date_ is None or pv_date >= reading_date_:
        return pv_rate
    return reading_rate


def forecast_missing_months(monthly: dict, daily_rate: Optional[float],
                             start: date, end: date) -> dict:
    """Ergänzt Monate ohne echte Ablesedaten im Zeitraum [start, end] um eine
    Hochrechnung.

    Nutzt eine saisonale Verhältnis-Skalierung statt den Vorjahreswert 1:1 zu
    übernehmen: Für den fehlenden Monat wird das Verhältnis zwischen dem
    Vorjahreswert desselben Kalendermonats und dem NIEDRIGSTEN Vorjahresmonat
    (typischerweise Sommer, geringster Heizbedarf) berechnet, und dieses
    Verhältnis auf die AKTUELLE Tagesrate angewendet. Das bildet ab, wenn der
    Verbrauch dieses Jahr generell niedriger/höher liegt als im Vorjahr (z.B.
    durch neue PV-Anlage, geändertes Heizverhalten) — eine reine 1:1-Vorjahres-
    übernahme würde das ignorieren und die Prognose systematisch verzerren.
    Ohne ausreichende Vorjahresdaten fällt es auf die aktuelle Tagesrate ×
    Tage im Monat zurück. Bewusst ohne feste Monats-/Jahres-Literale —
    funktioniert unabhängig vom Kalenderjahr."""
    result = dict(monthly)
    cur = date(start.year, start.month, 1)
    while cur <= end:
        key = f"{cur.year}-{cur.month:02d}"
        if key not in result:
            days_in_month = ((date(cur.year + (cur.month == 12), (cur.month % 12) + 1, 1))
                              - date(cur.year, cur.month, 1)).days
            prior_key = f"{cur.year - 1}-{cur.month:02d}"
            prior_year_months = {k: v for k, v in monthly.items() if k.startswith(f"{cur.year - 1}-")}

            if daily_rate is not None and prior_key in prior_year_months and len(prior_year_months) >= 2:
                baseline = min(prior_year_months.values())
                avg = sum(prior_year_months.values()) / len(prior_year_months)
                # Verh\u00e4ltnis-Skalierung nur, wenn die Baseline nicht nahe Null
                # liegt \u2014 sonst explodiert das Verh\u00e4ltnis (Winterwert \u00f7 fast Null).
                # Kommt z.B. bei Strombezug in PV-starken H\u00e4usern vor: im Sommer
                # praktisch kein Netzbezug, dann w\u00fcrde selbst eine kleine aktuelle
                # Rate mit einem riesigen Faktor multipliziert. In dem Fall den
                # Vorjahreswert direkt \u00fcbernehmen statt zu skalieren.
                if baseline > 0 and baseline >= avg * 0.15:
                    ratio = prior_year_months[prior_key] / baseline
                    result[key] = round(daily_rate * days_in_month * ratio, 2)
                else:
                    result[key] = prior_year_months[prior_key]
            elif prior_key in monthly:
                result[key] = monthly[prior_key]
            elif daily_rate is not None:
                result[key] = round(daily_rate * days_in_month, 2)
        cur = date(cur.year + (cur.month == 12), (cur.month % 12) + 1, 1)
    return result


def compute_settlement(meter_type: str, readings: list, settings: dict,
                        pv_monthly: Optional[list] = None, today: Optional[date] = None) -> dict:
    """Vergleicht gezahlte Abschläge mit den (gemessenen + hochgerechneten)
    tatsächlichen Jahreskosten — für Gas/Wasser/Strombezug: Kosten = Verbrauch
    × Arbeitspreis + 12 × Grundpreis. Für Einspeisung: Erlös = Verbrauch ×
    Einspeisepreis (kein Grundpreis, keine Kosten sondern Gutschrift)."""
    today = today or date.today()
    year = today.year
    monthly = get_effective_monthly(meter_type, readings, pv_monthly)
    rate = current_daily_rate_with_pv(meter_type, readings, pv_monthly or [])
    monthly_fc = forecast_missing_months(monthly, rate, date(year, 1, 1), date(year, 12, 31))

    total_this_year = sum(v for k, v in monthly_fc.items() if k.startswith(f"{year}-"))
    months_with_data = sum(1 for k in monthly if k.startswith(f"{year}-"))

    abschlag = settings.get("abschlag", 0) or 0
    paid_so_far = abschlag * today.month
    paid_full_year = abschlag * 12

    if meter_type == "elec_out":
        preis = settings.get("einspeisepreis", 0) or 0
        jahres_ertrag = total_this_year * preis
        diff = jahres_ertrag - paid_full_year
        kosten_oder_erloes = jahres_ertrag
    else:
        ap = settings.get("arbeitspreis", 0) or 0
        gp = settings.get("grundpreis", 0) or 0
        bw = settings.get("brennwert", 1.0) or 1.0 if meter_type == "gas" else 1.0
        einheit_umgerechnet = total_this_year * bw if meter_type == "gas" else total_this_year
        jahres_kosten = einheit_umgerechnet * ap + 12 * gp
        diff = paid_full_year - jahres_kosten
        kosten_oder_erloes = jahres_kosten

    return {
        "year": year,
        "total_consumption_this_year": round(total_this_year, 2),
        "months_with_real_data": months_with_data,
        "current_daily_rate": rate,
        "paid_so_far": round(paid_so_far, 2),
        "paid_full_year": round(paid_full_year, 2),
        "projected_annual_cost_or_revenue": round(kosten_oder_erloes, 2),
        "diff": round(diff, 2),
    }


def next_settle_date(month: int, day: int, today: Optional[date] = None) -> date:
    """Nächster Abrechnungstermin — dieses Jahr, falls noch nicht vorbei, sonst
    nächstes Jahr."""
    today = today or date.today()
    try:
        d = date(today.year, month, day)
    except ValueError:
        d = date(today.year, month, 28)
    if d <= today:
        try:
            d = date(today.year + 1, month, day)
        except ValueError:
            d = date(today.year + 1, month, 28)
    return d


def get_effective_monthly(meter_type: str, readings: list, pv_monthly: Optional[list],
                           today: Optional[date] = None) -> dict:
    """Monatswerte für einen Zähler — bevorzugt bei Strombezug/Einspeisung die
    Werte aus dem iSolarCloud/Sungrow-PV-Import (Netzbezug, Einspeisung),
    da dieser Import i.d.R. vollständiger und zuverlässiger ist als die
    Zählerstand-basierte Berechnung aus einzelnen, oft lückenhaften
    Ablesungen. Fällt für Monate ohne Import-Daten auf die Zählerstand-
    Berechnung zurück. Bei Gas/Wasser unverändert zählerstandbasiert (dafür
    gibt es keine iSolarCloud-Quelle).

    Der LAUFENDE (noch nicht abgeschlossene) Monat wird gesondert behandelt:
    ein Import am 1. eines Monats deckt zwangsläufig nur diesen einen Tag ab
    — würde man das ungeprüft als Monatswert übernehmen, sähe es so aus, als
    würde der ganze Monat nur so wenig erzeugen/verbrauchen. Stattdessen wird
    der bisherige Wert auf Tagesbasis hochgerechnet: (Wert ÷ bisher
    vergangene Tage) × Tage im Monat. Für alle VERGANGENEN Monate (die
    zwangsläufig vollständig sind) wird der Importwert unverändert
    übernommen."""
    today = today or date.today()
    meter_monthly = monthly_consumption(readings)
    if meter_type not in ("elec_in", "elec_out") or not pv_monthly:
        return meter_monthly
    field = "bezug" if meter_type == "elec_in" else "einsp"
    current_key = f"{today.year}-{today.month:02d}"
    days_elapsed = today.day
    days_in_current_month = (
        date(today.year + (today.month == 12), (today.month % 12) + 1, 1) - date(today.year, today.month, 1)
    ).days

    merged = dict(meter_monthly)
    for d in pv_monthly:
        val = d.get(field)
        if val is None:
            continue
        if d["key"] == current_key and days_elapsed < days_in_current_month and days_elapsed > 0:
            # Laufender, noch nicht abgeschlossener Monat -> auf Tagesbasis
            # hochrechnen statt den bisherigen Teilwert 1:1 zu übernehmen.
            merged[d["key"]] = round((val / days_elapsed) * days_in_current_month, 2)
        else:
            merged[d["key"]] = val
    return merged


def compute_full_settlement(readings_by_type: dict, settings_by_type: dict, pv_monthly: list,
                             today: Optional[date] = None) -> dict:
    """Vollständige Jahresabrechnung wie im Original: pro Zähler Abschlag
    gegen tatsächliche/prognostizierte Jahreskosten, mit eigenem Abrechnungs-
    termin und Tage-Countdown. Einspeisung nutzt die monatlichen PV-Daten
    (Sungrow) als primäre Datenquelle für den gemessenen Ertrag — genau wie
    im Original, da der iSolarCloud-Export zuverlässiger ist als der
    Wechselrichter-eigene Netto-Einspeisungszähler."""
    today = today or date.today()
    year = today.year
    month = today.month
    pv_by_key = {d["key"]: d for d in pv_monthly}

    # ---- Gas ----
    G = settings_by_type.get("gas") or DEFAULT_SETTINGS["gas"]
    gas_readings = readings_by_type.get("gas") or []
    gm = monthly_consumption(gas_readings)
    g_rate = current_daily_rate(gas_readings)
    g_forecast = forecast_missing_months(gm, g_rate, date(year, 1, 1), date(year, 12, 31))
    tot_gas_m3 = sum(g_forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    gas_jahr_kosten = tot_gas_m3 * (G.get("brennwert") or 1.0) * (G.get("arbeitspreis") or 0) + 12 * (G.get("grundpreis") or 0)
    gas_abschlaege = 12 * (G.get("abschlag") or 0)
    gas_diff = gas_abschlaege - gas_jahr_kosten
    gas_settle = next_settle_date(G.get("settle_month") or 1, G.get("settle_day") or 24, today)

    # ---- Wasser (nur wenn tatsächlich Ablesungen vorliegen — sonst würde
    # eine Karte mit lauter Nullen nur verwirren, bevor der Nutzer die
    # Wasser-Seite überhaupt zum ersten Mal befüllt hat) ----
    W = settings_by_type.get("water") or DEFAULT_SETTINGS["water"]
    water_readings = readings_by_type.get("water") or []
    has_water = len(water_readings) > 0
    wm = monthly_consumption(water_readings)
    w_rate = current_daily_rate(water_readings)
    w_forecast = forecast_missing_months(wm, w_rate, date(year, 1, 1), date(year, 12, 31))
    tot_water_m3 = sum(w_forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    water_jahr_kosten = tot_water_m3 * (W.get("arbeitspreis") or 0) + 12 * (W.get("grundpreis") or 0)
    water_abschlaege = 12 * (W.get("abschlag") or 0)
    water_diff = water_abschlaege - water_jahr_kosten
    water_settle = next_settle_date(W.get("settle_month") or 1, W.get("settle_day") or 1, today)

    # ---- Strombezug ----
    E = settings_by_type.get("elec_in") or DEFAULT_SETTINGS["elec_in"]
    elec_in_readings = readings_by_type.get("elec_in") or []
    em = get_effective_monthly("elec_in", elec_in_readings, pv_monthly)
    mo_mit_daten = [k for k in em if k.startswith(f"{year}-")]
    bezug_jahr = (sum(em[k] for k in mo_mit_daten) / len(mo_mit_daten) * 12) if mo_mit_daten else 0
    bezug_kosten = bezug_jahr * (E.get("arbeitspreis") or 0) + 12 * (E.get("grundpreis") or 0)
    bezug_abschlaege = 12 * (E.get("abschlag") or 0)
    bezug_diff = bezug_abschlaege - bezug_kosten
    bezug_settle = next_settle_date(E.get("settle_month") or 3, E.get("settle_day") or 13, today)

    # ---- Einspeisung (PV-gestützt) ----
    EO = settings_by_type.get("elec_out") or DEFAULT_SETTINGS["elec_out"]
    einspeis_abschlag = EO.get("abschlag") or 70
    m_seit_januar = month
    einsp_bezahlt = m_seit_januar * einspeis_abschlag

    cur_month_key = f"{year}-{month:02d}"
    # Der laufende Monat ist per Definition noch nicht vollständig gemessen
    # (auch wenn schon ein PV-Import dafür vorliegt) — sonst würde er sowohl
    # roh in "Gemessen" als auch hochgerechnet in "Prognose" gezählt werden.
    pv_dies_jahr = [d for d in pv_monthly if d["key"].startswith(f"{year}-") and d["key"] != cur_month_key]
    pv_gemessene_keys = [d["key"] for d in pv_dies_jahr]
    einsp_bisher = sum(d["einsp"] for d in pv_dies_jahr)

    pv_cur_month = pv_by_key.get(cur_month_key)
    einsp_laufender_monat = 0.0
    einsp_laufend_label = ""
    if pv_cur_month:
        days_in_month = (date(year + (month == 12), (month % 12) + 1, 1) - date(year, month, 1)).days
        # Wie viele Tage des laufenden Monats deckt der PV-Import ab? Das
        # heutige Datum ist hierfür das verlässliche Signal — die Ablesung
        # des Einspeisungszählers ist eine unabhängige, oft viel seltener
        # gepflegte Datenquelle und darf hier nicht als Anker dienen.
        days_covered = max(min(today.day, days_in_month), 1)
        daily_einsp = pv_cur_month["einsp"] / days_covered
        einsp_laufender_monat = daily_einsp * days_in_month
        einsp_laufend_label = (f"Sungrow {days_covered} Tage: {pv_cur_month['einsp']:.0f} kWh → "
                                f"{einsp_laufender_monat:.0f} kWh/Monat hochgerechnet")

    einsp_prognose = einsp_laufender_monat
    for m in range(1, 13):
        key = f"{year}-{m:02d}"
        if key in pv_gemessene_keys or m == month:
            continue
        prev = pv_by_key.get(f"{year-1}-{m:02d}")
        einsp_prognose += prev["einsp"] if prev else 0

    einsp_jahr_gesamt = einsp_bisher + einsp_prognose
    ep = EO.get("einspeisepreis") or 0
    einsp_jahr_erloes = einsp_jahr_gesamt * ep
    einsp_jahres_abschlaege = 12 * einspeis_abschlag
    einsp_diff = einsp_jahr_erloes - einsp_jahres_abschlaege
    einsp_erloes_bisher = einsp_bisher * ep
    einsp_settle = date(year + 1, 1, 31)

    total_diff = gas_diff + bezug_diff + einsp_diff + (water_diff if has_water else 0)

    return {
        "year": year,
        "gas": {
            "diff": round(gas_diff, 2), "jahr_kosten": round(gas_jahr_kosten, 2),
            "abschlaege": round(gas_abschlaege, 2), "settle_date": gas_settle.isoformat(),
            "days_until_settle": (gas_settle - today).days,
        },
        "elec_in": {
            "diff": round(bezug_diff, 2), "jahr_kosten": round(bezug_kosten, 2),
            "abschlaege": round(bezug_abschlaege, 2), "settle_date": bezug_settle.isoformat(),
            "days_until_settle": (bezug_settle - today).days,
            "monthly_cost": round(bezug_kosten / 12, 2),
        },
        "elec_out": {
            "diff": round(einsp_diff, 2), "jahr_erloes": round(einsp_jahr_erloes, 2),
            "jahres_abschlaege": round(einsp_jahres_abschlaege, 2), "abschlag": einspeis_abschlag,
            "bezahlt": round(einsp_bezahlt, 2), "bisher_kwh": round(einsp_bisher, 1),
            "prognose_kwh": round(einsp_prognose, 1), "jahr_gesamt_kwh": round(einsp_jahr_gesamt, 1),
            "erloes_bisher": round(einsp_erloes_bisher, 2), "m_seit_januar": m_seit_januar,
            "gemessene_monate": len(pv_gemessene_keys), "prognose_monate": 12 - len(pv_gemessene_keys),
            "laufender_monat_label": einsp_laufend_label,
            "settle_date": einsp_settle.isoformat(), "days_until_settle": (einsp_settle - today).days,
        },
        "water": {
            "has_data": has_water,
            "diff": round(water_diff, 2) if has_water else 0,
            "jahr_kosten": round(water_jahr_kosten, 2) if has_water else 0,
            "abschlaege": round(water_abschlaege, 2) if has_water else 0,
            "settle_date": water_settle.isoformat(),
            "days_until_settle": (water_settle - today).days,
        },
        "total_diff": round(total_diff, 2),
    }


def compute_overview_cards(readings_by_type: dict, settings_by_type: dict, pv_monthly: list,
                            range_id: str = "ytd") -> dict:
    """Die vier KPI-Karten (Gas, Bezug, Einspeisung, PV-Ertrag) für den
    gewählten Zeitraum — entspricht renderOvCards() im Original."""
    G = settings_by_type.get("gas") or DEFAULT_SETTINGS["gas"]
    E = settings_by_type.get("elec_in") or DEFAULT_SETTINGS["elec_in"]
    EO = settings_by_type.get("elec_out") or DEFAULT_SETTINGS["elec_out"]
    W = settings_by_type.get("water") or DEFAULT_SETTINGS["water"]

    gas_readings = readings_by_type.get("gas") or []
    elec_in_readings = readings_by_type.get("elec_in") or []
    elec_out_readings = readings_by_type.get("elec_out") or []
    water_readings = readings_by_type.get("water") or []

    gm = monthly_consumption(gas_readings)
    g_rate = current_daily_rate(gas_readings)
    today = date.today()
    g_forecast = forecast_missing_months(gm, g_rate, date(today.year, 1, 1), date(today.year, 12, 31))
    combined_gas = {**gm, **{k: v for k, v in g_forecast.items() if k not in gm}}

    em = get_effective_monthly("elec_in", elec_in_readings, pv_monthly)
    eom = get_effective_monthly("elec_out", elec_out_readings, pv_monthly)

    gas_keys = filter_keys_by_range(list(combined_gas.keys()), range_id)
    gas_m3 = sum(combined_gas.get(k, 0) for k in gas_keys)
    gas_kwh = gas_m3 * (G.get("brennwert") or 1.0)
    n_mo = months_in_range(range_id)
    gas_kosten = gas_kwh * (G.get("arbeitspreis") or 0) + n_mo * (G.get("grundpreis") or 0)

    bezug_keys = filter_keys_by_range(list(em.keys()), range_id)
    bezug_kwh = sum(em.get(k, 0) for k in bezug_keys)
    bezug_kosten = bezug_kwh * (E.get("arbeitspreis") or 0) + n_mo * (E.get("grundpreis") or 0)

    wm = monthly_consumption(water_readings)
    w_rate = current_daily_rate(water_readings)
    w_forecast = forecast_missing_months(wm, w_rate, date(today.year, 1, 1), date(today.year, 12, 31))
    combined_water = {**wm, **{k: v for k, v in w_forecast.items() if k not in wm}}
    water_keys = filter_keys_by_range(list(combined_water.keys()), range_id)
    water_m3 = sum(combined_water.get(k, 0) for k in water_keys)
    water_kosten = water_m3 * (W.get("arbeitspreis") or 0) + n_mo * (W.get("grundpreis") or 0)

    einsp_keys = filter_keys_by_range(list(eom.keys()), range_id)
    # 'eom' bevorzugt bereits die iSolarCloud-Werte je Monat (get_effective_monthly),
    # der Zählerstand dient nur noch als Rückfallebene für Monate ohne Import.
    einsp_total = sum(eom.get(k, 0) for k in einsp_keys)
    pv_keys_filtered = filter_keys_by_range([d["key"] for d in pv_monthly], range_id)
    pv_by_key = {d["key"]: d for d in pv_monthly}
    einsp_erloes = einsp_total * (EO.get("einspeisepreis") or 0)

    pv_ertrag_kwh = sum(pv_by_key[k]["pv"] for k in pv_keys_filtered)

    g_rate_val = current_daily_rate(gas_readings)
    e_rate_val = current_daily_rate_with_pv("elec_in", elec_in_readings, pv_monthly)
    eo_rate_val = current_daily_rate_with_pv("elec_out", elec_out_readings, pv_monthly)
    w_rate_val = current_daily_rate(water_readings)

    return {
        "range": range_id,
        "gas": {
            "kwh": round(gas_kwh, 1), "m3": round(gas_m3, 1), "kosten": round(gas_kosten, 2),
            "daily_rate": round(g_rate_val, 2) if g_rate_val is not None else None, "anbieter": G.get("anbieter") or "",
        },
        "elec_in": {
            "kwh": round(bezug_kwh, 0), "kosten": round(bezug_kosten, 2),
            "daily_rate": round(e_rate_val, 2) if e_rate_val is not None else None,
            "anbieter": E.get("anbieter") or "",
        },
        "elec_out": {
            "kwh": round(einsp_total, 0), "erloes": round(einsp_erloes, 2),
            "daily_rate": round(eo_rate_val, 2) if eo_rate_val is not None else None,
            "anbieter": EO.get("anbieter") or "badenovaNETZE",
            "source": "pv" if pv_monthly else "meter",
        },
        "pv": {
            "kwh": round(pv_ertrag_kwh, 0), "months": len(pv_keys_filtered),
            **PV_PLANT_DEFAULTS,
        },
        "water": {
            "m3": round(water_m3, 1), "kosten": round(water_kosten, 2),
            "daily_rate": round(w_rate_val, 2) if w_rate_val is not None else None,
            "anbieter": W.get("anbieter") or "", "has_data": len(water_readings) > 0,
        },
    }


def compute_cost_trend(readings_by_type: dict, settings_by_type: dict, pv_monthly: list,
                        range_id: str = "ytd") -> list:
    """Monatliche Kostenreihe für den Kostentrend-Chart: je Monat Gas- und
    Strom-Netto-Kosten, getrennt nach 'gemessen' (echte Ablesung oder
    iSolarCloud-Import vorhanden) und 'prognose' (hochgerechnet)."""
    G = settings_by_type.get("gas") or DEFAULT_SETTINGS["gas"]
    E = settings_by_type.get("elec_in") or DEFAULT_SETTINGS["elec_in"]
    EO = settings_by_type.get("elec_out") or DEFAULT_SETTINGS["elec_out"]
    W = settings_by_type.get("water") or DEFAULT_SETTINGS["water"]
    today = date.today()

    gas_readings = readings_by_type.get("gas") or []
    elec_in_readings = readings_by_type.get("elec_in") or []
    elec_out_readings = readings_by_type.get("elec_out") or []
    water_readings = readings_by_type.get("water") or []

    gm = monthly_consumption(gas_readings)
    g_rate = current_daily_rate(gas_readings)
    g_fc = forecast_missing_months(gm, g_rate, date(today.year, 1, 1), date(today.year, 12, 31))

    em = get_effective_monthly("elec_in", elec_in_readings, pv_monthly)
    e_rate = current_daily_rate_with_pv("elec_in", elec_in_readings, pv_monthly)
    e_fc = forecast_missing_months(em, e_rate, date(today.year, 1, 1), date(today.year, 12, 31))

    eom = get_effective_monthly("elec_out", elec_out_readings, pv_monthly)

    wm = monthly_consumption(water_readings)
    w_rate = current_daily_rate(water_readings)
    w_fc = forecast_missing_months(wm, w_rate, date(today.year, 1, 1), date(today.year, 12, 31))
    has_water = len(water_readings) > 0

    all_keys = sorted(set(list(g_fc.keys()) + list(e_fc.keys()) + (list(w_fc.keys()) if has_water else [])))
    filtered_keys = filter_keys_by_range(all_keys, range_id) if range_id != "all" else all_keys

    result = []
    for key in filtered_keys:
        gas_measured = key in gm
        elec_measured = key in em
        gas_m3 = gm.get(key, g_fc.get(key, 0))
        gas_cost = gas_m3 * (G.get("brennwert") or 1.0) * (G.get("arbeitspreis") or 0) + (G.get("grundpreis") or 0)
        elec_kwh = em.get(key, e_fc.get(key, 0))
        elec_cost = elec_kwh * (E.get("arbeitspreis") or 0) + (E.get("grundpreis") or 0)
        einsp_kwh = eom.get(key, 0)
        einsp_credit = einsp_kwh * (EO.get("einspeisepreis") or 0)
        net_elec_cost = elec_cost - einsp_credit
        water_measured = key in wm
        water_m3 = wm.get(key, w_fc.get(key, 0))
        water_cost = water_m3 * (W.get("arbeitspreis") or 0) + (W.get("grundpreis") or 0) if has_water else 0
        result.append({
            "key": key,
            "gas_measured": round(gas_cost, 2) if gas_measured else 0,
            "gas_forecast": 0 if gas_measured else round(gas_cost, 2),
            "elec_measured": round(net_elec_cost, 2) if elec_measured else 0,
            "elec_forecast": 0 if elec_measured else round(net_elec_cost, 2),
            "water_measured": round(water_cost, 2) if (has_water and water_measured) else 0,
            "water_forecast": round(water_cost, 2) if (has_water and not water_measured) else 0,
            "total": round(gas_cost + net_elec_cost + water_cost, 2),
        })
    return result


def compute_kpi_chips(meter_type: str, readings: list, settings_: dict,
                       pv_monthly: Optional[list] = None, today: Optional[date] = None) -> list:
    """Die KPI-Chip-Zeile pro Zählerseite (Letzter Stand, Tagesrate, optimaler
    Abschlag, erwartete Differenz, prognostizierte Jahreskosten) — entspricht
    den gasKpis/elecKpis-Chips im Original."""
    today = today or date.today()
    year = today.year
    unit = METER_META[meter_type]["unit"]
    rate = current_daily_rate_with_pv(meter_type, readings, pv_monthly or [])
    last = readings[-1] if readings else None

    monthly = get_effective_monthly(meter_type, readings, pv_monthly)
    forecast = forecast_missing_months(monthly, rate, date(year, 1, 1), date(year, 12, 31))
    total_this_year = sum(forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))

    if meter_type == "elec_out":
        ep = settings_.get("einspeisepreis") or 0
        jahres_ertrag = total_this_year * ep
        abschlag = settings_.get("abschlag") or 0
        opt_abschlag = round(jahres_ertrag / 12) if jahres_ertrag else 0
        diff = jahres_ertrag - 12 * abschlag
        chips = [
            {"label": "Letzter Stand", "value": f"{last['value']:.0f} {unit}" if last else "–",
             "sub": last["reading_date"] if last else ""},
            {"label": "Tagesrate aktuell", "value": f"{rate:.1f} {unit}/Tag" if rate is not None else "–", "sub": ""},
            {"label": f"Opt. Abschlag {year}", "value": f"{opt_abschlag:.0f} €", "sub": f"statt {abschlag:.0f} €/Mo"},
            {"label": f"Erwart. Diff. {year}", "value": f"{'+' if diff >= 0 else ''}{diff:.0f} €",
             "sub": "Gutschrift" if diff >= 0 else "Nachzahlung", "status": "ok" if diff >= 0 else "red"},
            {"label": "Progn. Jahresertrag", "value": f"{jahres_ertrag:.0f} €", "sub": f"{total_this_year:.0f} {unit}"},
        ]
    else:
        ap = settings_.get("arbeitspreis") or 0
        gp = settings_.get("grundpreis") or 0
        bw = (settings_.get("brennwert") or 1.0) if meter_type == "gas" else 1.0
        cost = total_this_year * bw * ap + 12 * gp
        abschlag = settings_.get("abschlag") or 0
        opt_abschlag = round(cost / 12) if cost else 0
        diff = 12 * abschlag - cost
        chips = [
            {"label": "Letzter Stand", "value": f"{last['value']:.0f} {unit}" if last else "–",
             "sub": last["reading_date"] if last else ""},
            {"label": "Tagesrate aktuell",
             "value": f"{rate:.2f} {unit}/Tag" if rate is not None else "–",
             "sub": f"{(rate * bw):.1f} kWh/Tag" if rate is not None and meter_type == "gas" else ""},
            {"label": f"Opt. Abschlag {year}", "value": f"{opt_abschlag:.0f} €", "sub": f"statt {abschlag:.0f} €/Mo"},
            {"label": f"Erwart. Diff. {year}", "value": f"{'+' if diff >= 0 else ''}{diff:.0f} €",
             "sub": "Gutschrift" if diff >= 0 else "Nachzahlung", "status": "ok" if diff >= 0 else "red"},
            {"label": "Progn. Jahreskosten", "value": f"{cost:.0f} €",
             "sub": f"{total_this_year:.0f} {unit}" + (f" · {(total_this_year*bw):.0f} kWh" if meter_type == "gas" else " Netzbezug")},
        ]
        if meter_type == "elec_in" and pv_monthly:
            # Gesamtverbrauch (Haushalt) direkt aus dem iSolarCloud-Feld —
            # eigenständig ausgewiesen, da es sich nicht exakt aus Netzbezug +
            # Eigenverbrauch ergibt (Batterie-Lade-/Entladeverluste).
            gesamt_monthly = {d["key"]: d["gesamt"] for d in pv_monthly if d.get("gesamt") is not None}
            gesamt_forecast = forecast_missing_months(gesamt_monthly, rate, date(year, 1, 1), date(year, 12, 31))
            gesamt_total_year = sum(gesamt_forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
            chips.append({
                "label": f"Gesamtverbrauch {year}", "value": f"{gesamt_total_year:.0f} kWh",
                "sub": "laut iSolarCloud · Eigenverbrauch + Netzbezug",
            })
    return chips


def consumption_since_settlement(readings: list, settlement_date: date) -> Optional[dict]:
    """Verbrauch seit einem manuell erfassten, tatsächlichen Abrechnungs-
    zeitpunkt — als Reset-Basis dient die letzte Ablesung am oder vor
    diesem Datum (oder, falls keine existiert, die erste Ablesung danach).
    Bewusst unabhängig von der kalenderjahr-basierten Jahresabrechnung
    (compute_full_settlement) gehalten, um deren bereits fein abgestimmte
    Logik nicht anzufassen."""
    if not readings:
        return None
    sorted_readings = sorted(readings, key=lambda r: _parse_date(r["reading_date"]))

    baseline = None
    for r in sorted_readings:
        if _parse_date(r["reading_date"]) <= settlement_date:
            baseline = r
    if baseline is None:
        baseline = sorted_readings[0]

    latest = sorted_readings[-1]
    if latest["id"] == baseline["id"]:
        return None

    # Ein Zählerwechsel zwischen Basis und aktuellem Stand würde die Differenz
    # verfälschen (Sprung auf einen neuen, bei 0 startenden Zähler) — in dem
    # Fall lieber keinen Wert zeigen als einen offensichtlich falschen.
    between = [r for r in sorted_readings if baseline["reading_date"] < r["reading_date"] <= latest["reading_date"]]
    if any(r.get("is_new_meter") for r in between):
        return None

    delta = latest["value"] - baseline["value"]
    days = (_parse_date(latest["reading_date"]) - _parse_date(baseline["reading_date"])).days
    return {
        "since_date": settlement_date.isoformat(),
        "baseline_date": baseline["reading_date"],
        "baseline_value": baseline["value"],
        "latest_date": latest["reading_date"],
        "latest_value": latest["value"],
        "consumption": round(delta, 2),
        "days": days,
    }


def compute_reading_intervals(readings: list) -> list:
    """Ablesungen mit Delta/Tage/Tagesrate zwischen aufeinanderfolgenden
    Ablesungen — für die Detailtabelle je Zählerseite."""
    result = []
    for i, cur in enumerate(readings):
        prev = readings[i - 1] if i > 0 else None
        entry = {**cur, "delta": None, "days": None, "rate": None}
        if prev and not cur.get("is_new_meter"):
            d1, d2 = _parse_date(prev["reading_date"]), _parse_date(cur["reading_date"])
            days = (d2 - d1).days
            if days > 0:
                delta = cur["value"] - prev["value"]
                entry["delta"] = round(delta, 2)
                entry["days"] = days
                entry["rate"] = round(delta / days, 3)
        elif prev and cur.get("is_new_meter"):
            entry["delta"] = "meter_switch"
        result.append(entry)
    return result


def compute_cumulative_cost(meter_type: str, readings: list, settings_: dict,
                             pv_monthly: Optional[list] = None, today: Optional[date] = None) -> list:
    """Kumulative Kosten übers Jahr — Ist-Kosten vs. Abschlag vs. optimaler
    Abschlag, monatsweise aufsummiert. Für den Kumulativ-Chart je Zählerseite
    (nur Gas/Strombezug, keine Einspeisung)."""
    today = today or date.today()
    year = today.year
    rate = current_daily_rate_with_pv(meter_type, readings, pv_monthly or [])
    monthly = get_effective_monthly(meter_type, readings, pv_monthly)
    forecast = forecast_missing_months(monthly, rate, date(year, 1, 1), date(year, 12, 31))

    ap = settings_.get("arbeitspreis") or 0
    gp = settings_.get("grundpreis") or 0
    bw = (settings_.get("brennwert") or 1.0) if meter_type == "gas" else 1.0
    abschlag = settings_.get("abschlag") or 0

    total_this_year = sum(forecast.get(f"{year}-{m:02d}", 0) for m in range(1, 13))
    full_year_cost = total_this_year * bw * ap + 12 * gp
    opt_abschlag = round(full_year_cost / 12) if full_year_cost else 0

    result = []
    cum_cost = cum_abschlag = cum_opt = 0.0
    for m in range(1, 13):
        key = f"{year}-{m:02d}"
        consumption = forecast.get(key, 0)
        cum_cost += consumption * bw * ap + gp
        cum_abschlag += abschlag
        cum_opt += opt_abschlag
        result.append({
            "key": key, "cost": round(cum_cost, 2),
            "abschlag": round(cum_abschlag, 2), "opt_abschlag": round(cum_opt, 2),
        })
    return result


def compute_autarkie_series(pv_monthly: list) -> list:
    """Autarkiegrad (Eigenverbrauchsanteil) je PV-Monatsdatensatz —
    (Gesamtverbrauch − Netzbezug) / Gesamtverbrauch × 100."""
    result = []
    for d in pv_monthly:
        gesamt = d.get("gesamt") or 0
        bezug = d.get("bezug") or 0
        autarkie = round(max(0, gesamt - bezug) / gesamt * 100) if gesamt > 0 else 0
        result.append({"key": d["key"], "autarkie": autarkie})
    return result
