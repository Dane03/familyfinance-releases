"""Regressionsschutz für die Rechenlogik — reine Funktionsaufrufe, kein Server, keine Datenbank.

Jeder Fall hat von Hand nachrechenbare Zahlen (Rechenweg im Kommentar). Läuft in wenigen Sekunden:
    cd kopie/backend && python3 ../scripts/review/rechnen.py
Exit-Code 0 = alles grün, 1 = mindestens eine Abweichung.

Herkunft der Fälle: Nachtlauf Fachlogik 2026-10-11 (Tagesrate, Auto/Haushalt) und Fixes v326
(29.02., 0-%-Darlehen, effektiver Monatszins).
"""
import sqlite3
import sys
from datetime import date
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))          # aus backend/ starten
import meters                                 # noqa: E402
import cost_shares                            # noqa: E402
import finanzierung                           # noqa: E402
import vorsorge                               # noqa: E402
import shared_helpers                         # noqa: E402

FAILS = []


def check(name, got, want, tol=0.005):
    ok = (abs(got - want) <= tol) if isinstance(want, (int, float)) and not isinstance(want, bool) and got is not None \
        else got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


class FakeDate(date):
    TODAY = date(2026, 10, 11)

    @classmethod
    def today(cls):
        return cls.TODAY


# ---------- Intervalle: 300 €/Quartal = 1200 €/Jahr = 100 €/Monat ----------
for freq, amount in (("monthly", 100), ("quarterly", 300), ("yearly", 1200)):
    check(f"monthly_amount {freq}", shared_helpers.monthly_amount(amount, freq), 100)
    check(f"cost_shares._monthly {freq}", cost_shares._monthly(amount, freq), 100)
db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE t (amount REAL, frequency TEXT, split REAL)")
db.executemany("INSERT INTO t VALUES (?,?,?)", [(100, "monthly", 1), (300, "quarterly", 0.5), (1200, "yearly", 1)])
check("monthly_expr Summe (100 + 300/3×0,5 + 1200/12)",
      db.execute(f"SELECT SUM({shared_helpers.monthly_expr('amount', 'frequency', 'split')}) FROM t").fetchone()[0], 250)

# ---------- Tilgung ----------
# 0 %: 12.000 € mit 1.000 €/Monat -> genau 12 Monate, 0 € Zinsen
r = finanzierung.compute_repayment_schedule(12000, 0.0, monthly_payment=1000, start=date(2026, 1, 1))
check("0-%-Darlehen: kein Fehler", r["error"], None)
check("0-%-Darlehen: Monate", r["months_to_payoff"], 12)
check("0-%-Darlehen: Zinsen", r["total_interest"], 0.0)
# 12 % p.a. = 1 %/Monat, 1.000 € Schuld, 510 €/Monat:
#   Monat 1: Zins 10, Tilgung 500 -> 500 Rest; Monat 2: Zins 5, Rest 500 getilgt -> 15 € Zinsen, 2 Monate
r = finanzierung.compute_repayment_schedule(1000, 12.0, monthly_payment=510, start=date(2026, 1, 1))
check("Annuität 12 %: Monate", r["months_to_payoff"], 2)
check("Annuität 12 %: Zinsen", r["total_interest"], 15.0)
# Rate unter den Zinsen (100.000 € × 3 % / 12 = 250 € Zins, Rate 200 €) -> klare Fehlermeldung
r = finanzierung.compute_repayment_schedule(100000, 3.0, monthly_payment=200)
check("Rate unter Zinsen -> Fehler", bool(r["error"]), True)

# ---------- Vorsorge ----------
check("67. Geburtstag bei *29.02.1964 (2031 kein Schaltjahr)", vorsorge.retirement_date_for(date(1964, 2, 29)), date(2031, 2, 28))
check("67. Geburtstag bei *15.06.1985", vorsorge.retirement_date_for(date(1985, 6, 15)), date(2052, 6, 15))
check("Jahre bis Rente am Stichtag", vorsorge.years_until_retirement(date(1964, 2, 29), today=date(2031, 2, 28)), 0.0)
# 1.000 € × 1,03 = 1.030 € nach einem Jahr (nicht 1.030,42 € wie mit 0,25 %/Monat)
check("Projektion 3 % p.a., 1 Jahr", vorsorge.project_private_pension_capital(1000, 0, 1, 0.03), 1030.0)
# 1.000 € × 1,03^10 = 1.343,92 €
check("Projektion 3 % p.a., 10 Jahre", vorsorge.project_private_pension_capital(1000, 0, 10, 0.03), 1343.92)
# 0 %: 100 €/Monat × 12 = 1.200 €
check("Projektion 0 %, Beiträge", vorsorge.project_private_pension_capital(0, 100, 1, 0.0), 1200.0)
# Rente: 300.000 € über 25 Jahre = 300.000 / 300 = 1.000 €/Monat
check("Kapital -> Monatsrente", vorsorge.capital_to_monthly_pension(300000, 25), 1000.0)

# ---------- Strom-Tagesrate im laufenden Monat (heute 11.10.) ----------
with patch.object(meters, "date", FakeDate):
    # 66 kWh bis zum 11. -> 66 / 11 = 6,00 kWh/Tag (Fehler bis v323: 66 / 31 = 2,13)
    check("Tagesrate laufender Monat", meters.current_daily_rate_with_pv("elec_in", [], [{"key": "2026-10", "bezug": 66}]), 6.0)
    # abgeschlossener Monat: 180 kWh im September / 30 = 6,00
    check("Tagesrate Vormonat", meters.current_daily_rate_with_pv("elec_in", [], [{"key": "2026-09", "bezug": 180}]), 6.0)

    # ---------- Auto/Haushalt (Rechenweg aus dem Nachtlauf 2026-10-11) ----------
    # Jeden Tag 6 kWh Bezug, 10 kWh Hausverbrauch, davon 2 kWh Auto; 0,30 €/kWh, 12 €/Monat Grundpreis.
    # Jahreskosten = 365 × 6 × 0,30 + 12 × 12 = 801 €; Auto = 365 × 6 × 0,2 × 0,30 = 131,40 €.
    year = 2026
    pv_daily, ev_readings, cum = [], [], 0.0
    d = date(year, 1, 1)
    while d <= FakeDate.TODAY:
        pv_daily.append({"key": d.isoformat(), "bezug": 6.0, "gesamt": 10.0})
        cum += 2.0
        ev_readings.append({"reading_date": d.isoformat(), "value": cum})
        d = date.fromordinal(d.toordinal() + 1)
    consumption = {f"{year}-{m:02d}": 6.0 * meters._days_in_month(year, m) for m in range(1, 13)}
    ev_monthly = {f"{year}-{m:02d}": 2.0 * meters._days_in_month(year, m) for m in range(1, 13)}
    gesamt = {f"{year}-{m:02d}": 10.0 * meters._days_in_month(year, m) for m in range(1, 13)}
    res = meters.split_auto_household_cost(consumption, ev_monthly, year, 0.30, 12.0,
                                           pv_daily=pv_daily, ev_readings=ev_readings, gesamt_by_month=gesamt)
    check("Auto + Haushalt = Jahreskosten", res["auto"] + res["haus"], 801.0, tol=0.01)
    check("davon Auto", res["auto"], 131.40, tol=0.01)

# ---------- Kostenbeteiligung: 1/2 von 120 €/Monat + 1/2 von 360 €/Quartal = 60 + 60 = 120 € ----------
db = sqlite3.connect(":memory:")
db.row_factory = sqlite3.Row
db.executescript("""
CREATE TABLE income (id INTEGER PRIMARY KEY, label TEXT, amount REAL, frequency TEXT, active INTEGER DEFAULT 1);
CREATE TABLE contracts (id INTEGER PRIMARY KEY, label TEXT, provider TEXT, amount REAL, frequency TEXT,
                        status TEXT DEFAULT 'active', split_share REAL DEFAULT 1.0);
CREATE TABLE income_cost_shares (income_id INTEGER, contract_id INTEGER, share REAL);
INSERT INTO income VALUES (1, 'Anteil Haus', 120, 'monthly', 1);
INSERT INTO contracts (id, label, amount, frequency) VALUES (1, 'Gas', 120, 'monthly'), (2, 'Wasser', 360, 'quarterly');
INSERT INTO income_cost_shares VALUES (1, 1, 0.5), (1, 2, 0.5);
""")
with patch.object(cost_shares, "_contract_names", lambda conn: {}):
    c = cost_shares.check_all(db)[0]
    check("Kostenbeteiligung erwartet", c["expected_monthly"], 120.0)
    check("Kostenbeteiligung ok", c["ok"], True)
    check("ohne split_share keine Warnung", c["split_contracts"], [])
    db.execute("UPDATE contracts SET split_share=0.5 WHERE id=1")
    c = cost_shares.check_all(db)[0]
    check("split_share < 1 -> Warnung", c["split_contracts"], ["Gas"])
    db.execute("UPDATE contracts SET split_share=1.0 WHERE id=1")
    db.execute("UPDATE income SET amount=119.50 WHERE id=1")
    c = cost_shares.check_all(db)[0]
    check("Kostenbeteiligung: 50 Cent Abweichung -> Hinweis (centgenau, v334)", c["ok"], False)

# ---------- Gesamtvermögen ohne ausgeschlossene Vermögenswerte, rückwirkend (v327) ----------
# Giro 5.000 · Sparbuch Kinder 2.000 (Bank, Umsätze +500 am 15.09. und +500 am 01.10.) · Haus 400.000 − 300.000 Darlehen
# Rohsumme = 5.000 + 2.000 + 100.000 = 107.000. Sparbuch ausgeschlossen -> 105.000.
# Alte Momentaufnahme 01.09. (nur Summe 106.000): Sparbuch-Stand vor dem ersten Umsatz = 2.000 − 1.000 = 1.000 -> 105.000.
# Alte Momentaufnahme 20.09. (106.500): nach dem 20.09. kam nur noch +500 -> 1.500 -> 105.000.
import vermoegen_routes  # noqa: E402
db = sqlite3.connect(":memory:")
db.row_factory = sqlite3.Row
db.executescript((Path.cwd() / "schema.sql").read_text(encoding="utf-8"))
db.executescript("""
INSERT INTO assets (id, type, label, current_value) VALUES (1, 'konto', 'Giro', 5000), (2, 'konto', 'Sparbuch Kinder', 2000);
INSERT INTO assets (id, type, label, current_value) VALUES (3, 'immobilie', 'Haus', 400000);
INSERT INTO contracts (id, label, amount, subcategory, remaining_debt, interest_rate) VALUES (1, 'Darlehen', 1000, 'Finanzierung', 300000, 3);
INSERT INTO asset_financing_links (asset_id, contract_id) VALUES (3, 1);
INSERT INTO bank_accounts (id, connection_key, iban, balance, asset_id) VALUES (1, 'bank_conn_1', 'DE00', 2000, 2);
INSERT INTO bank_transactions (bank_account_id, booking_date, amount, tx_hash) VALUES (1, '2026-09-15', 500, 'a'), (1, '2026-10-01', 500, 'b');
INSERT INTO networth_snapshots (snapshot_date, total_networth, liquid, pension_capital, immobilien_netto)
  VALUES ('2026-09-01', 106000, 6000, 0, 100000), ('2026-09-20', 106500, 6500, 0, 100000);
""")
check("Rohsumme alle Vermögenswerte", vermoegen_routes._compute_networth_totals(db, include_excluded=True)["gesamt"], 107000)
db.execute("UPDATE assets SET exclude_from_networth=1 WHERE id=2")
check("Gesamt ohne Sparbuch", vermoegen_routes._compute_networth_totals(db)["gesamt"], 105000)
check("Liquide ohne Sparbuch", vermoegen_routes._compute_networth_totals(db)["liquid"], 5000)
dates = ["2026-09-01", "2026-09-20"]
adj, est = vermoegen_routes._excluded_history_adjustments(db, dates)
check("01.09.: Sparbuch-Stand zurückgerechnet", adj["2026-09-01"]["liquid"], 1000)
check("20.09.: Sparbuch-Stand zurückgerechnet", adj["2026-09-20"]["liquid"], 1500)
check("alte Tage als geschätzt markiert", est["2026-09-01"] and est["2026-09-20"], True)
# Seit v327 gespeicherter Einzelwert schlägt die Schätzung
db.execute("INSERT INTO networth_snapshot_items VALUES ('2026-10-12', 2, 'liquid', 2000)")
adj, est = vermoegen_routes._excluded_history_adjustments(db, ["2026-10-12"])
check("Tag mit Einzelwert: genau abgezogen", adj["2026-10-12"]["liquid"], 2000)
check("Tag mit Einzelwert: nicht geschätzt", est["2026-10-12"], False)
# Erst nach dem Stichtag angelegt -> war nicht in der Summe -> nichts abziehen
db.execute("INSERT INTO assets (id, type, label, current_value, exclude_from_networth, created_at) "
           "VALUES (4, 'sonstiges', 'Auto', 15000, 1, '2026-10-05')")
adj, _ = vermoegen_routes._excluded_history_adjustments(db, ["2026-09-20"])
check("später angelegt: alte Summe unverändert", adj["2026-09-20"]["liquid"], 1500)
# Immobilie ausgeschlossen, Sparbuch und Auto wieder drin: 5.000 + 2.000 + 15.000 = 22.000;
# rückwirkend fällt das Netto (400.000 − 300.000) aus dem Immobilien-Topf
db.execute("UPDATE assets SET exclude_from_networth=0 WHERE id IN (2, 4)")
db.execute("UPDATE assets SET exclude_from_networth=1 WHERE id=3")
check("Immobilie ausgeschlossen", vermoegen_routes._compute_networth_totals(db)["gesamt"], 22000)
adj, _ = vermoegen_routes._excluded_history_adjustments(db, ["2026-09-01"])
check("Immobilie rückwirkend aus Topf", adj["2026-09-01"]["immobilien_netto"], 100000)

# ---------- Jahresabrechnung Gas / Einspeisung / Autarkie (Nachtlauf Fachlogik 2026-10-25) ----------
# Gas: genau 10 m³/Tag, Ablesung 01.01.2026 = 0 und 01.01.2027 = 3.650 -> 3.650 m³ im Jahr.
# kWh = 3.650 × 10,0 (Umrechnungsfaktor) = 36.500; Kosten = 36.500 × 0,10 € + 12 × 10 € = 3.770 €;
# gezahlt 12 × 100 € = 1.200 € -> Differenz −2.570 € (Nachzahlung).
gas_readings = [{"reading_date": "2026-01-01", "value": 0, "is_new_meter": 0},
                {"reading_date": "2027-01-01", "value": 3650, "is_new_meter": 0}]
with patch.object(meters, "date", FakeDate):
    gs = meters.compute_settlement("gas", gas_readings, {"abschlag": 100, "arbeitspreis": 0.10,
                                   "grundpreis": 10, "brennwert": 10.0}, None, today=FakeDate.TODAY)
    check("Gas: Jahresverbrauch m³", gs["total_consumption_this_year"], 3650.0, tol=0.01)
    check("Gas: Jahreskosten", gs["projected_annual_cost_or_revenue"], 3770.0, tol=0.01)
    check("Gas: Differenz zu Abschlägen", gs["diff"], -2570.0, tol=0.01)
    # Einspeisung: 3.650 kWh × 0,08 €/kWh = 292 € Gutschrift, kein Grundpreis
    es = meters.compute_settlement("elec_out", gas_readings, {"abschlag": 0, "einspeisepreis": 0.08},
                                   None, today=FakeDate.TODAY)
    check("Einspeisung: Jahresertrag", es["projected_annual_cost_or_revenue"], 292.0, tol=0.01)
# Autarkie = (Hausverbrauch − Netzbezug) / Hausverbrauch: (10 − 6) / 10 = 40 %; kein Verbrauch -> 0; Bezug > Verbrauch -> 0
au = {x["key"]: x["autarkie"] for x in meters.compute_autarkie_series([
    {"key": "2026-01", "gesamt": 10, "bezug": 6}, {"key": "2026-02", "gesamt": 0, "bezug": 0},
    {"key": "2026-03", "gesamt": 5, "bezug": 7}])}
check("Autarkie 40 %", au["2026-01"], 40)
check("Autarkie ohne Verbrauch", au["2026-02"], 0)
check("Autarkie Bezug > Verbrauch", au["2026-03"], 0)

print()
if FAILS:
    print(f"✗ {len(FAILS)} Abweichung(en): {', '.join(FAILS)}")
    sys.exit(1)
print("✓ Rechenlogik: alle Fälle stimmen")
