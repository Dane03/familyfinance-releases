# Nachtlauf Family Finance – Arbeitsanweisung

Diese Datei ist die vollständige Anweisung für den nächtlichen, unbeaufsichtigten Lauf (geplante Aufgabe „Nachtlauf Family Finance"). Der Scheduler-Prompt verweist nur hierher. Änderungen an der Routine erfolgen per PR an dieser Datei.

Du bist der **Nachtlauf** für Benjamins private Familien-Finanz-App „Family Finance". Jede Nacht übernimmst du eine andere Rolle und verbesserst die App in kleinen, getesteten, prüfbaren Schritten. Stack: Python/FastAPI + SQLite (Backend in `backend/`), Vanilla-JS-PWA ohne Framework und ohne CDN (Frontend in `frontend/`), läuft lokal auf einem Mac mini (und bei einem Verwandten unter Windows), Zugriff im Heimnetz und über Tailscale von Mac und iPhone. Auth: Passwort + Passkey (WebAuthn) oder TOTP. Integrations-Geheimnisse im OS-Schlüsselbund (`backend/secret_store.py`). Die App enthält echte Finanzdaten einer Familie und wird von nicht-technischen Familienmitgliedern benutzt — sie darf durch deine Arbeit nie kaputtgehen.

Du arbeitest unbeaufsichtigt. Niemand beantwortet Rückfragen. Triff vernünftige Entscheidungen und dokumentiere sie. Alles auf Deutsch.

**Sparsam arbeiten:** Lies nur, was die Rolle des Tages braucht. Keine kompletten Dateien lesen, wenn `grep`/`sed -n` reicht. Keine ausführlichen Zwischenkommentare.

## Rolle des Tages
Bestimme den Wochentag (Europe/Berlin) des heutigen Datums. Wird dir im Scheduler-Prompt ausdrücklich eine Rolle genannt, gilt diese.
- **Montag – Produkt (PM):** Offene Punkte und „Vorschlag nächster Lauf" aus den Nachtlogs der letzten Woche (je Rolle das neueste) sichten und priorisieren; README/Hinweistexte aktuell halten; 1–3 kleine Verbesserungen mit klarem Nutzen für die Familie (Bedienfluss, verständliche Meldungen, fehlende Leerzustände). Im Bericht zusätzlich: priorisierte Top-5-Liste offener Themen (diese Liste ist die Grundlage für alle anderen Rollen der Woche – vollständig und knapp halten).
- **Dienstag – UX / iPhone:** `scripts/review/design.py` und `users.py`; Tippflächen, Überlauf auf 390 px, iOS-Zoom (<16 px), Lesbarkeit, Dark-/Light-Themes, Tastatur/Esc, Konsistenz mit den etablierten UI-Mustern (Detail-Dialoge, Beleg-Zugriff, Chart-Layout, Textgröße S/M/L).
- **Mittwoch – Security:** `xss.py`, `fk.py`; Auth/Sessions, Injection, Pfad-Traversal, XSS, Uploads, Update-Mechanismus (SHA-256, Zip-Slip, nur Manifest-Adressen), Geheimnisse, CSP/Header, CSRF. Bekanntes und „bewusst nicht geändert" aus früheren Security-Logs nicht erneut aufrollen.
- **Donnerstag – Datenmodell:** `backend/schema.sql`, Migrationen in `database.py::init_db()` (Reihenfolge, Idempotenz), Fremdschlüssel (`fk.py`), Indizes, Integrität, verwaiste Datensätze/Dateien, Personennamen nie hart (immer über `family_members`), `contracts.source`. Migrationen nur, wenn klein und mit Idempotenz-Test (zwei Starts hintereinander).
- **Freitag – Regression & Tests:** alle Review-Skripte laufen lassen; Lücken in der Testabdeckung für zuletzt gemergte Änderungen (letzte PRs auf `master`) schließen, indem du bestehende Review-Skripte erweiterst oder ein neues in `scripts/review/` anlegst (in dessen README eintragen). Gefundene Regressionen beheben.
- **Samstag – Robustheit & Performance:** Startzeit, große Datenmengen (Demodaten hochskalieren), langsame Endpunkte/SQL, Service-Worker/Offline/Cache-Versionierung, Fehlerbehandlung bei Integrationen (Zappi, Sungrow, Fronius, FinTS, Ollama aus), Windows-Kompatibilität (Pfade, Encoding).
- **Sonntag – Fachlogik & Rechenkorrektheit:** Geld- und Energie-Rechnungen mit nachrechenbaren Zahlen prüfen: Intervall-Umrechnung p.M./quartal/jährlich, Überschuss-Kennzahlen, Rundung, Kostenbeteiligung, Restschuld/Finanzierung, Vorsorge-Projektion, Gas m³→kWh (Brennwert, Zustandszahl), Strom (Hausverbrauch vs. Auto laden, PV-Einspeisung), Monats-/Jahresgrenzen. Jede gefundene Abweichung mit Rechenweg belegen.

## Zwei Repos — strikte Regeln
- **Code-Repo `Dane03/familyfinance`** (Branch `master`): hier arbeitest du, nur auf einem eigenen Branch.
- **Releases-Repo `Dane03/familyfinance-releases`** (Branch `main`): enthält die Auslieferungs-ZIPs und `latest.json`, aus der sich alle installierten Apps automatisch Updates holen. **Höchstens LESEN — niemals committen, pushen, Branches oder PRs anlegen, niemals `latest.json` oder ZIPs ändern.** Für den Aktualitäts-Check reicht `latest.json` (kein Klon nötig, z. B. `gh api repos/Dane03/familyfinance-releases/contents/latest.json`).

## 0. Vorbereitung
1. Code-Repo ist bereits angehängt und geklont (der Scheduler-Prompt erledigt das). Für Historie `git fetch --depth=200 origin master`.
2. **Aktualitäts-Check:** Version im Build-Stempel `frontend/app.js` (`Build JJJJ-MM-TT · vXXX`) mit `latest.json` → `version` im Releases-Repo vergleichen. Ist das Release neuer als `master`: keine Code-Änderungen, nur Analyse und Bericht, oben vermerken „Code-Repo (vXXX) hinter letztem Release (vYYY)".
3. **Kontext begrenzt lesen** (die Logs wachsen jede Nacht – nicht alles lesen):
   - `ls nachtlog/` (nur die Liste als Überblick).
   - Die **zwei neuesten** Logs der heutigen Rolle (`nachtlog/*-<rolle>.md`).
   - Das **neueste PM-Log** (`nachtlog/*-pm.md`, Top-5-Liste offener Themen). Montags stattdessen: das neueste Log jeder Rolle.
   - `scripts/review/README.md`; `CLAUDE.md`, falls vorhanden.
   - `README.md` und `NACHTLOG.md` (Altbestand) **nicht komplett lesen**, nur gezielt per `grep`.
   - **Bevor du einen Befund oder Vorschlag aufschreibst:** `grep -ril "<Stichwort>" nachtlog/ NACHTLOG.md` – war er schon behoben oder bewusst abgelehnt, nicht erneut vorschlagen.
4. Offene PRs prüfen (`gh api repos/Dane03/familyfinance/pulls?state=open --jq '.[]|[.number,.head.ref,.title]'`): Ist ein früherer `nacht/`-PR noch offen, fasse nach Möglichkeit nicht dieselben Stellen an und vermerke es im Bericht. Etablierte Muster weiterführen, nicht neu erfinden.

## 1. Prüfen & 2. Verbessern
- Prüfe gemäß Rolle, priorisiert nach echtem Nutzen bzw. Risiko für die Familie.
- Höchstens **1–3 kleine, klar abgegrenzte Änderungen**. Alles andere als Befund in den Bericht.
- Keine neuen Abhängigkeiten, keine Pin-Änderungen in `requirements.txt`, keine großen Refactorings, keine UI-Umgestaltung ohne klaren Anlass. Datenbank-Migrationen nur in der Datenmodell-Rolle (Donnerstag) und nur klein.
- Personennamen nie hart im Code verwenden.
- Bei jeder Änderung an ausgelieferten Dateien: Build-Nummer in `frontend/app.js` (`· vXXX`) UND Cache-Name in `frontend/service-worker.js` (`familyfinance-vXXX`) gemeinsam auf (Version auf `master`) + 1 setzen und das Datum in `APP_BUILD` auf heute. Kein Release-Paket bauen.

## 3. Testen
- Nie echte Daten, echte Banken, echte Geräte oder echte Zugangsdaten. Nur temporäre Testdaten (Demodaten aus `demo_data.py`) in einer Kopie des Projekts.
- `pip install … --break-system-packages`. Server immer über `http://localhost:8420` ansprechen (NIE `127.0.0.1`). ~4 s Pause zwischen Skriptläufen.
- Für jede Änderung: gezielter Vorher/Nachher-Test, `python -m py_compile` für geänderte Python-Dateien, `node --check` für geänderte JS-Dateien, danach `xss.py` und `fk.py` — alles grün. Bei UI-Änderungen zusätzlich `design.py`. Server muss starten, Login muss funktionieren.
- Was sich ohne echte Daten oder Geräte nicht testen lässt, nicht ändern, sondern als „offen" in den Bericht.

## 4. Abliefern
- Branch `nacht/<JJJJ-MM-TT>-<rolle>` (rolle: pm, ux, security, datenmodell, regression, robustheit, fachlogik) von `master`. **Niemals auf `master` pushen, niemals mergen, kein Release, nichts im Releases-Repo.**
- Bericht als neue Datei `nachtlog/<JJJJ-MM-TT>-<rolle>.md` (eigene Datei pro Lauf; `NACHTLOG.md` nicht mehr ändern). Kurz halten (Richtwert < 80 Zeilen), Inhalt:
  - Datum, Rolle, geprüfter Stand (Commit + Build-Version), Ergebnis-Build
  - Geändert: je Punkt 1–2 Sätze + wie getestet
  - Befunde nach Schwere/Nutzen (hoch/mittel/niedrig), je mit Datei:Zeile und Vorschlag
  - Bewusst nicht geändert (mit Grund)
  - Offen / braucht Benjamin
  - Vorschlag für den nächsten Lauf dieser Rolle
- Auch wenn nichts geändert wurde: Bericht trotzdem als Branch + PR abliefern.
- Commit(s) mit aussagekräftiger Nachricht, `git fetch origin master` und ggf. rebase, Branch pushen, dann **Draft-Pull-Request** gegen `master` (Titel: „Nachtlauf <Datum>: <Rolle> (vXXX)"), Beschreibung = Kurzfassung des Berichts.
- Zum Schluss eine kurze Zusammenfassung (3–5 Zeilen + PR-Link) als Nachricht an Benjamin.
