"""
Family Finance — Backend
Läuft komplett lokal (127.0.0.1 / lokales Netzwerk), keine Cloud-Aufrufe.

Start:
    uvicorn app:app --host 0.0.0.0 --port 8420
"""
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional, List
import re
import html
import json
import io
import hashlib

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Response, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from database import get_connection, init_db
from ocr import extract_receipt_data  # lokale OCR, siehe ocr.py
from chatbot import ask as ask_chatbot  # lokaler Chatbot über Ollama, siehe chatbot.py
from payslip_import import parse_payslip  # Gehaltsabrechnungs-Import, siehe payslip_import.py
from report import generate_report_pdf, generate_energy_report_pdf  # PDF-Export, siehe report.py
import meters  # Energy-Monitor-Berechnungslogik, siehe meters.py
import smart_import  # Intelligenter Datei-Import mit Ollama, siehe smart_import.py
import auth

BASE_DIR = Path(__file__).resolve().parent.parent
RECEIPTS_DIR = BASE_DIR / "data" / "receipts"
PAYSLIPS_DIR = BASE_DIR / "data" / "payslips"
# Auch in vorsorge_routes.py definiert -- bewusst als eigenständige, gleiche
# Definition statt eines Imports, um einen Zirkelbezug zwischen den beiden
# Modulen zu vermeiden (app.py bindet vorsorge_routes ein).
PENSION_DOCS_DIR = BASE_DIR / "data" / "pension_docs"

# Monatsäquivalent-Formel, überall identisch verwendet (Betrag * Anteil, umgerechnet auf p.M.)
from shared_helpers import monthly_expr, _contract_folder_parts, resolve_document_url

app = FastAPI(title="Family Finance")

# CORS bewusst NICHT auf "*": Die App arbeitet mit Cookie-Authentifizierung,
# und eine Wildcard-Freigabe würde bedeuten, dass jede beliebige Webseite,
# die im selben Browser geöffnet ist, Anfragen an den lokalen Server stellen
# könnte. Da Frontend und Backend hier ohnehin vom selben Ursprung
# ausgeliefert werden, braucht es gar keine Fremd-Ursprünge — lediglich der
# eigene (z.B. Tailscale-Hostname) wird zugelassen.
_allowed_origins = [auth.ORIGIN] if getattr(auth, "ORIGIN", None) else []
app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Obergrenze für Uploads: ohne Limit könnte eine sehr große Datei den
# Arbeitsspeicher des kleinen Servers füllen, da die Uploads zum Verarbeiten
# komplett eingelesen werden (OCR, PDF-Parsing, Tabellen-Import).
MAX_UPLOAD_BYTES = 25 * 1024 * 1024   # 25 MB — für Einzel-Uploads (1 Datei)
MAX_BULK_UPLOAD_BYTES = 300 * 1024 * 1024  # 300 MB — für Mehrfach-Import (mehrere
    # Dateien auf einmal ist hier ja der ganze Zweck; das alte 25-MB-Limit galt
    # für den GESAMTEN Request und ließ schon 8-9 normal große gescannte PDFs
    # (je ~3 MB) fälschlich scheitern — für den Nutzer wirkte das wie ein
    # Aufhängen der App, da der Server mitten im Hochladen abbricht.


@app.middleware("http")
async def limit_upload_size(request: Request, call_next):
    content_length = request.headers.get("content-length")
    limit = MAX_BULK_UPLOAD_BYTES if "bulk-upload" in request.url.path else MAX_UPLOAD_BYTES
    if content_length and int(content_length) > limit:
        return JSONResponse(
            status_code=413,
            content={"detail": f"Dateien zusammen zu groß (max. {limit // (1024*1024)} MB)."},
        )
    return await call_next(request)


@app.on_event("startup")
def startup():
    init_db()
    RECEIPTS_DIR.mkdir(parents=True, exist_ok=True)
    # Automatisches Aufräumen alter Test-/vergessener Uploads bei jedem Start.
    # Bewusst mit einer Woche Mindestalter, damit ein gestern hochgeladener,
    # noch nicht bestätigter Beleg nicht versehentlich verschwindet.
    conn = get_connection()
    import receipts_routes
    receipts_routes._cleanup_unconfirmed_receipts(conn, max_age_hours=24 * 7)
    conn.close()

    # Ebenso für nie bestätigte intelligente Datei-Importe (analysiert, aber
    # nie mit "Import starten" abgeschlossen) — sonst sammeln sich in
    # data/smart_import_staging/ auf Dauer verwaiste Dateien an.
    import time
    staging_dir = BASE_DIR / "data" / "smart_import_staging"
    if staging_dir.exists():
        cutoff = time.time() - 24 * 3600
        for f in staging_dir.iterdir():
            if f.is_file() and f.stat().st_mtime < cutoff:
                f.unlink()

    _migrate_receipts_person_separation_once()

    import maintenance
    maintenance.backup_database()
    import vermoegen_routes
    vermoegen_routes.save_networth_snapshot()
    _start_recurring_weather_refresh()


def _start_recurring_weather_refresh():
    """Der Server läuft typischerweise wochenlang durchgehend (launchd hält
    ihn am Leben) — ein reiner Start-Trigger würde also praktisch nie
    erneut greifen, sobald der Rechner einmal länger nicht neu gestartet
    wurde. Deshalb ein dauerhaft laufender Hintergrund-Thread statt nur
    ein einmaliger Aufruf beim Start; die eigentliche Tages-Begrenzung
    steckt bereits in _refresh_actual_temperatures_if_due() selbst, ein
    Aufwachen alle paar Stunden ist also unkritisch, nicht "zu oft"."""
    import threading
    import time as _time

    def _loop():
        while True:
            try:
                import energy_routes
                energy_routes._refresh_actual_temperatures_if_due()
            except Exception:
                pass  # ein Fehlschlag hier darf den Hintergrund-Thread nie beenden
            _time.sleep(6 * 3600)  # alle 6 Stunden erneut pruefen (nicht "erneut abrufen" -- die Tages-Sperre entscheidet das)

    threading.Thread(target=_loop, daemon=True).start()


# ---------- Pydantic-Modelle für Schreibzugriffe ----------

class ContractIn(BaseModel):
    label: Optional[str] = ""
    provider: Optional[str] = None
    contract_number: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    amount: float
    frequency: str = "monthly"
    payment_method: Optional[str] = None
    contract_end: Optional[date] = None
    notice_period_days: Optional[int] = None
    auto_renews: bool = True
    note: Optional[str] = None
    person_id: Optional[int] = None
    interest_rate: Optional[float] = None
    remaining_debt: Optional[float] = None
    repayment_rate: Optional[float] = None
    fixed_interest_until: Optional[date] = None
    insurance_type: Optional[str] = None
    insurance_expiry: Optional[date] = None
    insurance_sum: Optional[float] = None
    insurance_sum_type: Optional[str] = None
    bu_monthly_pension: Optional[float] = None


class ContractPatch(BaseModel):
    """Für manuelle Korrekturen — nur gesetzte Felder werden geändert.
    Bleibt so lange gültig, bis ein neues Update (Foto/Import) den Wert überschreibt."""
    label: Optional[str] = None
    provider: Optional[str] = None
    contract_number: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    amount: Optional[float] = None
    frequency: Optional[str] = None
    payment_method: Optional[str] = None
    contract_end: Optional[date] = None
    notice_period_days: Optional[int] = None
    auto_renews: Optional[bool] = None
    status: Optional[str] = None
    link: Optional[str] = None
    sort_order: Optional[int] = None
    note: Optional[str] = None
    person_id: Optional[int] = None
    interest_rate: Optional[float] = None
    remaining_debt: Optional[float] = None
    repayment_rate: Optional[float] = None
    fixed_interest_until: Optional[date] = None
    insurance_type: Optional[str] = None
    insurance_expiry: Optional[date] = None
    insurance_sum: Optional[float] = None
    insurance_sum_type: Optional[str] = None
    bu_monthly_pension: Optional[float] = None


class FamilyMemberIn(BaseModel):
    name: str
    role: str = "kind"           # 'elternteil' | 'kind'
    birth_date: Optional[date] = None


class FamilyMemberPatch(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None
    birth_date: Optional[date] = None
    sort_order: Optional[int] = None
    freistellungsauftrag_used: Optional[float] = None
    sv_nummer: Optional[str] = None
    steuer_id: Optional[str] = None
    steuerklasse: Optional[str] = None
    krankenkasse: Optional[str] = None
    etin: Optional[str] = None
    steuernummer: Optional[str] = None
    finanzamt: Optional[str] = None


class IncomeIn(BaseModel):
    label: str
    category: Optional[str] = None
    amount: float
    frequency: str = "monthly"
    person_id: Optional[int] = None


class IncomePatch(BaseModel):
    label: Optional[str] = None
    category: Optional[str] = None
    amount: Optional[float] = None
    frequency: Optional[str] = None
    active: Optional[bool] = None
    sort_order: Optional[int] = None
    person_id: Optional[int] = None


# ---------- Login: Passwort + Passkey (2FA) ----------

class SetupIn(BaseModel):
    username: str
    password: str


class LoginIn(BaseModel):
    username: str
    password: str


class PasskeyRegisterIn(BaseModel):
    credential: dict
    label: str = "Passkey"


class PasskeyLoginIn(BaseModel):
    credential: dict


@app.get("/api/auth/status")
def auth_status(request: Request):
    session = None
    try:
        session = auth.require_full_auth(request)
    except HTTPException:
        pass
    return {
        "setup_required": not auth.user_exists(),
        "passkey_registered": auth.has_passkey(request),
        "totp_registered": auth.has_totp(),
        "authenticated": session is not None,
    }


@app.post("/api/auth/setup")
def setup(payload: SetupIn, response: Response, request: Request):
    """Einmalig beim allerersten Start: legt den einen Familien-Zugang an."""
    auth.create_user(payload.username, payload.password)
    auth.issue_session(response, stage="password_ok", request=request)
    return {"status": "created", "next": "passkey_registration"}


@app.post("/api/auth/login")
def login(payload: LoginIn, response: Response, request: Request):
    auth.check_login_allowed(request)
    if not auth.verify_password(payload.username, payload.password):
        auth.register_failed_login(request)
        raise HTTPException(401, "Benutzername oder Passwort falsch.")
    auth.reset_failed_logins(request)
    auth.issue_session(response, stage="password_ok", request=request)
    return {"status": "password_ok", "next": "passkey"}


@app.post("/api/auth/logout")
def logout(response: Response):
    auth.clear_session(response)
    return {"status": "logged_out"}


@app.post("/api/auth/totp/setup/begin")
def totp_setup_begin(session=Depends(auth.require_password_stage)):
    """Kann sowohl direkt nach der Ersteinrichtung (als Alternative zum
    Passkey) als auch später aus den Einstellungen heraus aufgerufen werden
    (dort ist die Sitzung ohnehin schon 'full')."""
    return auth.begin_totp_setup()


class TotpSetupCompleteIn(BaseModel):
    secret: str
    code: str


@app.post("/api/auth/totp/setup/complete")
def totp_setup_complete(payload: TotpSetupCompleteIn, response: Response,
                         session=Depends(auth.require_password_stage)):
    if not auth.complete_totp_setup(payload.secret, payload.code):
        raise HTTPException(400, "Code stimmt nicht überein — bitte erneut versuchen.")
    auth.issue_session(response, stage="full")  # direkt vollständig eingeloggt, wie beim Passkey
    return {"status": "ok"}


class TotpLoginIn(BaseModel):
    code: str


@app.post("/api/auth/totp/login")
def totp_login(payload: TotpLoginIn, response: Response, session=Depends(auth.require_password_stage)):
    if not auth.verify_totp_code(payload.code):
        raise HTTPException(401, "Code falsch oder abgelaufen.")
    auth.issue_session(response, stage="full")
    return {"status": "full"}


@app.post("/api/auth/totp/disable")
def totp_disable(session=Depends(auth.require_full_auth)):
    """Nur aus den Einstellungen heraus (volle Anmeldung nötig) -- nicht
    während des Logins, sonst könnte sich jemand mit nur dem Passwort selbst
    den zweiten Faktor abschalten."""
    auth.disable_totp()
    return {"status": "disabled"}


@app.get("/api/auth/totp/qr")
def totp_qr(secret: str, session=Depends(auth.require_password_stage)):
    """Erzeugt den QR-Code lokal auf dem Server statt über einen externen
    QR-Code-Dienst -- das TOTP-Geheimnis (otpauth://-URL) verlässt damit nie
    den eigenen Rechner, auch nicht in Form einer Anfrage an eine fremde
    QR-Generierungs-API."""
    import pyotp
    import qrcode
    import io
    conn = get_connection()
    row = conn.execute("SELECT username FROM app_user WHERE id=1").fetchone()
    conn.close()
    username = row["username"] if row else "Family Finance"
    otpauth_url = pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name="Family Finance")
    img = qrcode.make(otpauth_url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")


@app.post("/api/auth/passkey/register/begin")
def passkey_register_begin(request: Request, session=Depends(auth.require_password_stage)):
    return auth.begin_passkey_registration(username="Familie", request=request)


@app.post("/api/auth/passkey/register/complete")
def passkey_register_complete(payload: PasskeyRegisterIn, response: Response, request: Request,
                               session=Depends(auth.require_password_stage)):
    import json
    result = auth.complete_passkey_registration(json.dumps(payload.credential), payload.label,
                                                 request=request)
    auth.issue_session(response, stage="full", request=request)  # direkt vollständig eingeloggt
    return result


@app.post("/api/auth/passkey/login/begin")
def passkey_login_begin(request: Request, session=Depends(auth.require_password_stage)):
    return auth.begin_passkey_login(request=request)


@app.post("/api/auth/passkey/login/complete")
def passkey_login_complete(payload: PasskeyLoginIn, response: Response, request: Request,
                            session=Depends(auth.require_password_stage)):
    import json
    auth.complete_passkey_login(json.dumps(payload.credential), request=request)
    auth.issue_session(response, stage="full", request=request)
    return {"status": "full"}


# ---------- Übersicht / Dashboard ----------

def _compute_health_check(monthly_income: float, fixed_expenses: float, savings: float,
                           by_category: list) -> list:
    """Bewertet die aktuelle Finanzverteilung anhand verbreiteter, recherchierter
    Faustregeln (Stand 2026). Jede Regel ist bewusst als grobe Orientierung zu
    verstehen, nicht als individuelle Finanzberatung — das wird auch im
    Frontend so kommuniziert.

    Quellen der Richtwerte:
    - Sparquote 10–20 % empfohlen (u.a. Verbraucherzentrale-Modelle, diverse
      Finanzratgeber); Ø Deutschland 2024/25 lag bei rund 10–11 %.
    - Wohnkostenquote: 30-Prozent-Mietregel (Warmmiete/Finanzierung ≤ 30 % des
      Nettoeinkommens), 40 % gilt verbreitet als Schmerzgrenze.
    - 50-30-20-Regel (Elizabeth Warren): 50 % Grundbedürfnisse, 30 % Wünsche,
      20 % Sparen — hier vereinfacht als "max. 80 % Fixkosten ohne Sparen".

    Bewusst nicht enthalten: ein Notgroschen-Check — die App kennt keine
    tatsächlichen Kontostände, nur monatliche Zahlungsströme, und könnte eine
    vorhandene Rücklage daher nicht seriös bewerten.
    """
    if monthly_income <= 0:
        return []

    def fmt_eur_short(v: float) -> str:
        return f"{v:.0f} €"

    checks = []

    # 1) Sparquote
    savings_rate = (savings / monthly_income) * 100
    if savings_rate >= 20:
        status = "green"
    elif savings_rate >= 10:
        status = "yellow"
    else:
        status = "red"
    checks.append({
        "id": "sparquote",
        "title": "Sparquote",
        "value_label": f"{savings_rate:.0f} %",
        "status": status,
        "target_label": "Empfohlen: 10–20 %, ideal ≥ 20 %",
        "message": (
            f"Ihr spart aktuell {savings_rate:.0f} % des Nettoeinkommens. "
            + ("Das liegt über dem empfohlenen Richtwert — starke Basis für Rücklagen und Vorsorge."
               if status == "green" else
               "Das liegt im empfohlenen Korridor, nach oben wäre noch Luft."
               if status == "yellow" else
               "Das liegt unter dem verbreitet empfohlenen Mindestwert von 10 %.")
        ),
    })

    # 2) Wohnkostenquote — NUR reine Wohnkosten (Nebenkosten, Versicherung o.ä.),
    #    OHNE Finanzierung/Tilgung. Die 30-Prozent-Faustregel stammt aus dem
    #    Mietkontext: bei Miete ist die Zahlung ein reiner Verbrauch ohne
    #    Gegenwert. Eine Finanzierungsrate fürs eigene Haus ist das nicht — ein
    #    Teil davon ist Tilgung, also Vermögensaufbau (das Haus gehört einem
    #    ja am Ende). Beides in einen Topf zu werfen würde die Quote künstlich
    #    aufblähen und so tun, als sei Eigentum finanziell "schlechter" als
    #    Miete, obwohl das Gegenteil der Fall sein kann.
    haus_rows = [row for row in by_category if row["category"] == "Haus" and row["monthly_amount"]]
    financing_cost = sum(
        row["monthly_amount"] for row in haus_rows if (row["subcategory"] or "") == "Finanzierung"
    )
    housing_cost = sum(
        row["monthly_amount"] for row in haus_rows if (row["subcategory"] or "") != "Finanzierung"
    )
    if housing_cost > 0:
        housing_rate = (housing_cost / monthly_income) * 100
        if housing_rate <= 30:
            status = "green"
        elif housing_rate <= 40:
            status = "yellow"
        else:
            status = "red"
        checks.append({
            "id": "wohnkosten",
            "title": "Wohnkostenquote",
            "value_label": f"{housing_rate:.0f} %",
            "status": status,
            "target_label": "Faustregel: ≤ 30 %, Schmerzgrenze ~40 % (ohne Finanzierung/Tilgung)",
            "message": (
                f"Reine Wohnkosten (Nebenkosten, Versicherung o.ä. — ohne Finanzierung) "
                f"machen {housing_rate:.0f} % des Nettoeinkommens aus. "
                + ("Das liegt innerhalb der klassischen 30-Prozent-Regel."
                   if status == "green" else
                   "Das liegt über der 30-Prozent-Regel, aber noch unter der Schmerzgrenze — "
                   "in vielen Ballungsräumen inzwischen normal."
                   if status == "yellow" else
                   "Das liegt über der verbreiteten Schmerzgrenze von ~40 % — wenig Puffer für "
                   "andere Ausgaben und Rücklagen.")
                + (f" Die Finanzierungsrate ({fmt_eur_short(financing_cost)}/Mo) ist bewusst "
                   "nicht mit eingerechnet, da sie überwiegend Vermögensaufbau ist, kein reiner "
                   "Verbrauch." if financing_cost > 0 else "")
            ),
        })

    # 2b) Finanzierung/Tilgung separat als Vermögensaufbau ausweisen, statt sie
    #     wie einen "Kostenfaktor" gegen eine Ausgaben-Regel zu bewerten.
    if financing_cost > 0:
        financing_rate = (financing_cost / monthly_income) * 100
        checks.append({
            "id": "finanzierung",
            "title": "Finanzierung (Vermögensaufbau)",
            "value_label": f"{financing_rate:.0f} %",
            "status": "green",
            "target_label": "Kein Richtwert — fließt ins eigene Vermögen, keine Ausgabe im klassischen Sinn",
            "message": (
                f"{financing_rate:.0f} % des Nettoeinkommens ({fmt_eur_short(financing_cost)}/Mo) "
                f"fließen in die Immobilienfinanzierung. Anders als Miete ist das größtenteils "
                f"Tilgung — das Geld bleibt im eigenen Vermögen, nur eben gebunden im Haus statt "
                f"auf dem Konto."
            ),
        })

    # 3) Fixkosten-Quote gesamt (alles außer Sparen), angelehnt an die
    #    50-30-20-Regel: 20 % sollten fürs Sparen übrig bleiben.
    fixed_rate = (fixed_expenses / monthly_income) * 100
    if fixed_rate <= 80:
        status = "green"
    elif fixed_rate <= 95:
        status = "yellow"
    else:
        status = "red"
    checks.append({
        "id": "fixkosten",
        "title": "Fixkosten-Quote",
        "value_label": f"{fixed_rate:.0f} %",
        "status": status,
        "target_label": "Angelehnt an die 50-30-20-Regel: ≤ 80 % (Rest fürs Sparen)",
        "message": (
            f"Alle Ausgaben außer Sparen zusammen machen {fixed_rate:.0f} % des "
            f"Nettoeinkommens aus. "
            + ("Genug Spielraum bleibt fürs Sparen und Unvorhergesehenes."
               if status == "green" else
               "Der Spielraum fürs Sparen wird knapp."
               if status == "yellow" else
               "Kaum bis kein Spielraum mehr übrig — das Einkommen ist nahezu komplett verplant.")
        ),
    })

    return checks


@app.get("/api/dashboard")
def dashboard(session=Depends(auth.require_full_auth)):
    conn = get_connection()

    monthly_income = conn.execute(
        f"SELECT COALESCE(SUM({monthly_expr('amount', 'frequency')}),0) AS v "
        f"FROM income WHERE active=1"
    ).fetchone()["v"]

    # Alle aktiven Fixkosten außer "Sparen" — das ist der klassische
    # "Überschuss nach Fixkosten" wie in deiner bisherigen Excel.
    fixed_expenses = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND (c.name IS NULL OR c.name != 'Sparen')"""
    ).fetchone()["v"]

    savings = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND c.name = 'Sparen'"""
    ).fetchone()["v"]

    surplus_after_fixed = monthly_income - fixed_expenses
    surplus_after_savings = surplus_after_fixed - savings

    by_category = conn.execute(
        f"""SELECT c.name AS category, co.subcategory,
                   SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}) AS monthly_amount
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active'
            GROUP BY c.name, co.subcategory ORDER BY monthly_amount DESC"""
    ).fetchall()

    income_rows = conn.execute(
        f"""SELECT id, label, amount, frequency, active, source, updated_at,
                   {monthly_expr('amount', 'frequency')} AS monthly_amount
            FROM income ORDER BY active DESC, monthly_amount DESC, label"""
    ).fetchall()

    upcoming = conn.execute(
        """SELECT r.trigger_date, r.reminder_type, r.message, c.label
           FROM reminders r JOIN contracts c ON c.id = r.contract_id
           WHERE r.sent=0 AND r.trigger_date <= date('now', '+28 days')
           ORDER BY r.trigger_date ASC LIMIT 20"""
    ).fetchall()

    conn.close()

    health_check = _compute_health_check(monthly_income, fixed_expenses, savings, by_category)

    return {
        "monthly_income": round(monthly_income, 2),
        "monthly_fixed_expenses": round(fixed_expenses, 2),
        "monthly_savings": round(savings, 2),
        "surplus_after_fixed_costs": round(surplus_after_fixed, 2),
        "surplus_after_savings": round(surplus_after_savings, 2),
        "by_category": [dict(r) for r in by_category],
        "income": [dict(r) for r in income_rows],
        "upcoming_reminders": [dict(r) for r in upcoming],
        "health_check": health_check,
    }


def _sync_reminders(conn, contract_id: int):
    """(Neu) erzeugt die Fälligkeits-Erinnerungen für einen Vertrag, abhängig von
    contract_end/notice_period_days. Bei Haus-Finanzierungen (Baufinanzierung)
    wird die Formulierung passend auf Zinsbindung/Anschlussfinanzierung
    angepasst statt generisch von "Kündigung" zu sprechen. Wird sowohl beim
    Anlegen als auch bei jeder manuellen Korrektur der Termine aufgerufen,
    damit Nachpflegen bestehender (importierter) Verträge genauso Erinnerungen
    erzeugt wie das Neuanlegen."""
    row = conn.execute(
        """SELECT co.label, co.contract_end, co.notice_period_days, co.subcategory,
                  c.name AS category_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.id = ?""",
        (contract_id,),
    ).fetchone()
    if not row:
        return

    # Alte, noch nicht verschickte Erinnerungen für diesen Vertrag verwerfen und neu aufbauen
    conn.execute("DELETE FROM reminders WHERE contract_id=? AND sent=0", (contract_id,))

    if not row["contract_end"]:
        return

    is_financing = row["category_name"] == "Haus" and row["subcategory"] == "Finanzierung"
    contract_end = row["contract_end"]

    if is_financing:
        end_message = f"Zinsbindung von '{row['label']}' endet am {contract_end} — Anschlussfinanzierung nötig."
        notice_message_tpl = (
            f"Jetzt Angebote für die Anschlussfinanzierung von '{row['label']}' vergleichen "
            f"(Zinsbindungsende: {contract_end})."
        )
    else:
        end_message = f"Vertrag '{row['label']}' läuft am {contract_end} aus."
        notice_message_tpl = f"Kündigungsfrist für '{row['label']}' beginnt bald — Laufzeitende: {contract_end}."

    conn.execute(
        "INSERT INTO reminders (contract_id, reminder_type, trigger_date, message) VALUES (?,?,?,?)",
        (contract_id, "contract_end", contract_end, end_message),
    )

    if row["notice_period_days"]:
        notice_date = (date.fromisoformat(contract_end) - timedelta(days=row["notice_period_days"])).isoformat()
        conn.execute(
            "INSERT INTO reminders (contract_id, reminder_type, trigger_date, message) VALUES (?,?,?,?)",
            (contract_id, "notice_period", notice_date, notice_message_tpl),
        )


# ---------- Einstellungen (z.B. manuelle Reihenfolge der Dashboard-Blöcke) ----------

@app.get("/manifest.json")
def dynamic_manifest():
    """Wird dynamisch statt als statische Datei ausgeliefert, damit das
    PWA-Icon zum zuletzt gewählten Theme passt -- ein Betriebssystem liest
    das Manifest nur beim (Neu-)Installieren zum Homescreen, ein späterer
    Theme-Wechsel ändert ein bereits installiertes Icon technisch nicht
    rückwirkend, aber eine Neuinstallation zeigt dann das passende Icon."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='ui_theme'").fetchone()
    conn.close()
    theme = json.loads(row["value"]) if row else "dark"
    if theme not in ("dark", "light", "apple", "nothing", "retro80s"):
        theme = "dark"
    bg_colors = {"dark": "#0f172a", "light": "#f2f2f7", "apple": "#eef1f6", "nothing": "#000000", "retro80s": "#170821"}
    manifest = {
        "name": "Family Finance",
        "short_name": "Finance",
        "start_url": "/",
        "display": "standalone",
        "background_color": bg_colors[theme],
        "theme_color": bg_colors[theme],
        "icons": [
            {"src": f"/icons/icon-{theme}.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any maskable"},
            {"src": f"/icons/icon-{theme}-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
            {"src": f"/icons/icon-{theme}-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"},
        ],
    }
    return JSONResponse(content=manifest)


@app.get("/api/settings/{key}")
def get_setting(key: str, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return {"key": key, "value": json.loads(row["value"]) if row else None}


class SettingIn(BaseModel):
    value: object


@app.put("/api/settings/{key}")
def put_setting(key: str, payload: SettingIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, json.dumps(payload.value)),
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}


# ---------- Passwort-Entschlüsselung für die PDF-Ansicht ----------
class DocumentDecryptIn(BaseModel):
    url: str
    password: str


@app.post("/api/documents/decrypt-preview")
def decrypt_document_preview(payload: DocumentDecryptIn, session=Depends(auth.require_full_auth)):
    """Nimmt Passwort UND Ziel-Dokument entgegen, entschlüsselt serverseitig
    und liefert die entschlüsselten PDF-Bytes zurück -- NICHT dauerhaft
    gespeichert, nur für diese eine Anzeige.

    Bewusst gebaut, weil sich auf die native Passwort-Eingabemaske von iOS
    innerhalb eines eingebetteten <embed>/<iframe> nicht verlassen lässt:
    in der Praxis zeigte <embed> zwar den Hinweis "passwortgeschützt", aber
    kein bedienbares Eingabefeld dafür, <iframe> erkannte die
    Verschlüsselung nicht einmal. Die eigene Passwortabfrage in der
    Wrapper-Seite (siehe pdf_viewer_wrapper) umgeht dieses Problem
    vollständig, da sie mit gewöhnlichem HTML/JS läuft, das sich zuverlässig
    testen lässt, statt sich auf natives, plattformabhängiges
    PDF-Plugin-Verhalten zu verlassen."""
    file_path = resolve_document_url(payload.url)
    if not file_path:
        raise HTTPException(404, "Dokument nicht gefunden.")
    try:
        from pypdf import PdfReader, PdfWriter
        reader = PdfReader(file_path)
        if not reader.is_encrypted:
            # Kein Passwort noetig -- Datei einfach direkt zurueckgeben.
            return Response(content=file_path.read_bytes(), media_type="application/pdf")
        if reader.decrypt(payload.password) == 0:
            raise HTTPException(400, "Falsches Passwort.")
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        buf = io.BytesIO()
        writer.write(buf)
        return Response(content=buf.getvalue(), media_type="application/pdf")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"PDF konnte nicht gelesen werden: {e}")


# ---------- Wrapper-Seite für verschlüsselte PDFs ----------
# Der In-App-Betrachter nutzt ein <iframe>, das unter iOS keinen nativen
# Passwort-Dialog anzeigen kann (siehe serve_document_file). Als Ausweg wird
# eine echte Browser-Navigation ausgelöst -- eine reine PDF-URL hat aber
# selbst KEINERLEI Bedienelemente. In einer als Homescreen-App installierten
# PWA (standalone-Modus) fehlt dabei die normale Safari-Oberfläche mit
# Zurück-Button komplett -- genau das Problem, das der eigene Betrachter von
# Anfang an vermeiden sollte. Diese schlanke Wrapper-Seite bringt deshalb
# einen eigenen, garantiert erreichbaren "Schließen"-Knopf mit und bettet
# die PDF per <embed> ein, das (anders als <iframe>) den nativen
# Passwort-Dialog zeigen kann.
@app.get("/api/documents/pdf-viewer", response_class=HTMLResponse)
def pdf_viewer_wrapper(url: str, title: str = "Dokument", session=Depends(auth.require_full_auth)):
    safe_title = html.escape(title)
    safe_url_js = json.dumps(url)  # sicher fürs Einbetten in ein <script>, inkl. Anführungszeichen/Escaping
    return f"""<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" />
<title>{safe_title}</title>
<script>
  // Dieselbe Design-Einstellung wie die Haupt-App übernehmen -- localStorage
  // ist ursprungsweit geteilt, diese eigenständige Seite kann den Wert also
  // direkt auslesen. Bewusst als allererstes im <head>, damit die Seite
  // nicht erst kurz im falschen Theme aufblitzt.
  document.documentElement.setAttribute("data-theme", localStorage.getItem("ui_theme") || "dark");
</script>
<style>
  /* Dieselben Variablen wie in style.css (:root + [data-theme=...]) --
     eigenständige Seite, kein Zugriff auf das App-eigene Stylesheet, daher
     hier dupliziert statt verlinkt. Nur die Kernfarben, nicht jede
     Theme-spezifische Zusatz-Spielerei (Verläufe, Weichzeichner etc.). */
  html[data-theme="dark"], :root {{
    --bg:#0f172a; --card:#1e293b; --text:#e2e8f0; --muted:#94a3b8;
    --accent:#22d3ee; --bad:#f87171; --font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; --radius:16px;
  }}
  html[data-theme="light"] {{
    --bg:#f2f2f7; --card:#ffffff; --text:#1c1c1e; --muted:#8e8e93;
    --accent:#007aff; --bad:#ff3b30; --font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text",sans-serif; --radius:14px;
  }}
  html[data-theme="nothing"] {{
    --bg:#000000; --card:#1c1c1c; --text:#ffffff; --muted:#6e6e6e;
    --accent:#ff0000; --bad:#8b1a1a; --font-family:"SF Mono","Roboto Mono","Courier New",monospace; --radius:4px;
  }}
  html[data-theme="retro80s"] {{
    --bg:#170821; --card:#2b1040; --text:#fdf4ff; --muted:#c9a8e0;
    --accent:#ff2e97; --bad:#ff5555; --font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; --radius:8px;
  }}
  html[data-theme="apple"] {{
    --bg:#eef1f6; --card:#ffffff; --text:#1c1c1e; --muted:#6e6e73;
    --accent:#0a84ff; --bad:#ff453a; --font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text",sans-serif; --radius:22px;
  }}
  html, body {{ margin:0; height:100%; background:var(--bg); font-family:var(--font-family); }}
  /* Flexbox statt fester Positionierung mit top/bottom-Koordinaten -- ein
     <iframe> ist ein "replaced element" und kann bei position:fixed +
     top/bottom OHNE explizite Höhe auf seine EIGENE, inhaltsbasierte Größe
     zurückfallen, statt den verfügbaren Platz zu füllen. Dasselbe
     Flex-Muster wird bereits beim eigenen In-App-Betrachter zuverlässig
     genutzt. */
  body {{ display:flex; flex-direction:column; }}
  header {{
    display:flex; align-items:center; justify-content:space-between;
    padding:calc(env(safe-area-inset-top, 10px) + 8px) 14px 10px;
    background:var(--card); border-bottom:1px solid rgba(128,128,128,0.2);
    flex-shrink:0;
  }}
  header span {{ color:var(--muted); font-size:0.85rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; margin-right:10px; }}
  header button {{
    background:transparent; color:var(--accent); border:1px solid var(--accent); border-radius:var(--radius);
    padding:6px 16px; font-size:0.9rem; flex-shrink:0; font-family:inherit;
  }}
  /* PDF-Anzeige über PDF.js statt eines <iframe>s mit dem nativen
     Betriebssystem-PDF-Viewer: der übliche Weg, eine PDF auf die volle
     Breite zu skalieren (URL-Fragment "#view=FitH"), erwies sich unter
     iOS/WKWebView (Standalone-PWA) als unzuverlässig -- selbst native
     PDFKit-Apps haben laut Apple-Entwicklerforum Schwierigkeiten, die
     Anfangs-Zoomstufe programmatisch zu setzen. Mit PDF.js wird jede Seite
     stattdessen selbst auf ein <canvas> gerendert, in der exakt
     berechneten Breite des verfügbaren Bereichs -- vollständig unter
     eigener Kontrolle, ohne auf natives, plattformabhängiges Verhalten
     angewiesen zu sein. */
  #pdf-container {{
    flex:1; width:100%; min-height:0; overflow-y:auto; overflow-x:hidden;
    background:#525659; display:none; -webkit-overflow-scrolling:touch;
  }}
  #pdf-container canvas {{ display:block; margin:8px auto; box-shadow:0 2px 8px rgba(0,0,0,0.3); }}
  #pdf-loading {{ color:#9aa4b8; text-align:center; padding:20px; font-size:0.85rem; }}
  /* Eigene Passwort-Abfrage statt der nativen PDF-Betrachter-Funktion des
     Betriebssystems: sowohl <embed> als auch <iframe> erwiesen sich beim
     Testen als unzuverlässig für verschlüsselte PDFs -- <embed> zeigte den
     Hinweis "passwortgeschützt", aber kein bedienbares Eingabefeld dafür,
     <iframe> erkannte die Verschlüsselung nicht einmal. Diese eigene
     Passwortabfrage läuft mit gewöhnlichem HTML/JS, das sich zuverlässig
     testen lässt, statt sich auf natives, plattformabhängiges
     PDF-Plugin-Verhalten zu verlassen, das bislang nicht funktionierte. */
  #pw-screen {{
    flex:1; display:flex; flex-direction:column; align-items:center;
    justify-content:center; padding:24px; text-align:center; gap:14px; background:var(--bg);
  }}
  #pw-screen .lock {{ font-size:2.4rem; }}
  #pw-screen p {{ color:var(--text); margin:0; font-size:1rem; }}
  #pw-screen input {{
    width:100%; max-width:280px; padding:10px 12px; border-radius:var(--radius);
    border:1px solid rgba(128,128,128,0.3); background:var(--card); color:var(--text);
    font-size:1rem; font-family:inherit; box-sizing:border-box;
  }}
  #pw-screen button.submit {{
    width:100%; max-width:280px; padding:10px 12px; border-radius:var(--radius);
    border:none; background:var(--accent); color:var(--bg); font-weight:600;
    font-size:1rem; font-family:inherit;
  }}
  #pw-error {{ color:var(--bad); font-size:0.85rem; min-height:1.2em; }}
</style>
</head>
<body>
  <header>
    <span>{safe_title}</span>
    <button onclick="schliessen()">✕ Schließen</button>
  </header>
  <div id="pw-screen">
    <div class="lock">🔒</div>
    <p>Dieses Dokument ist passwortgeschützt.</p>
    <form id="pw-form" onsubmit="return entschluesseln(event)">
      <input type="password" id="pw-input" placeholder="Passwort" autocomplete="off" autofocus />
      <div id="pw-error"></div>
      <button type="submit" class="submit">Öffnen</button>
    </form>
  </div>
  <div id="pdf-container"></div>
  <script>
    const documentUrl = {safe_url_js};
    let objectUrl = null;

    async function entschluesseln(e) {{
      e.preventDefault();
      const password = document.getElementById("pw-input").value;
      const errorEl = document.getElementById("pw-error");
      const screen = document.getElementById("pw-screen");
      errorEl.textContent = "";
      screen.querySelector(".submit").disabled = true;
      screen.querySelector(".submit").textContent = "Wird geprüft …";
      try {{
        const res = await fetch("/api/documents/decrypt-preview", {{
          method: "POST",
          headers: {{ "Content-Type": "application/json" }},
          body: JSON.stringify({{ url: documentUrl, password: password }}),
        }});
        if (!res.ok) {{
          const data = await res.json().catch(() => ({{}}));
          errorEl.textContent = data.detail || "Passwort falsch.";
          screen.querySelector(".submit").disabled = false;
          screen.querySelector(".submit").textContent = "Öffnen";
          return false;
        }}
        const blob = await res.blob();
        objectUrl = URL.createObjectURL(blob);
        screen.style.display = "none";
        await pdfAnzeigen(objectUrl);
      }} catch (err) {{
        errorEl.textContent = "Verbindungsfehler — bitte erneut versuchen.";
        screen.querySelector(".submit").disabled = false;
        screen.querySelector(".submit").textContent = "Öffnen";
      }}
      return false;
    }}

    async function pdfAnzeigen(quelle) {{
      // Eigenes Rendering über PDF.js statt eines <iframe>s mit dem
      // nativen PDF-Viewer: der übliche Weg, eine PDF auf volle Breite zu
      // skalieren (URL-Fragment "#view=FitH"), erwies sich unter
      // iOS/WKWebView als unzuverlässig. Jede Seite wird hier stattdessen
      // exakt auf die Breite des verfügbaren Bereichs berechnet und selbst
      // auf ein <canvas> gezeichnet -- vollständig unter eigener
      // Kontrolle, seitenweise untereinander für gewohntes Scrollen durch
      // mehrseitige Dokumente.
      const container = document.getElementById("pdf-container");
      container.style.display = "block";
      container.innerHTML = '<p id="pdf-loading">Lade Dokument …</p>';
      try {{
        const pdfjsLib = await import("/vendor/pdfjs/pdf.min.mjs");
        pdfjsLib.GlobalWorkerOptions.workerSrc = "/vendor/pdfjs/pdf.worker.min.mjs";
        const pdf = await pdfjsLib.getDocument(quelle).promise;
        container.innerHTML = "";
        const dpr = window.devicePixelRatio || 1;
        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {{
          const page = await pdf.getPage(pageNum);
          // Skalierung anhand der tatsächlich verfügbaren Breite des
          // Containers (abzüglich eines kleinen Rands) berechnen, statt
          // der Originalgröße der PDF-Seite -- das ist der eigentliche
          // Kern der Korrektur: die Seite füllt garantiert die Breite,
          // unabhängig vom PDF-eigenen ursprünglichen Seitenformat.
          const unscaledViewport = page.getViewport({{ scale: 1 }});
          const targetWidth = container.clientWidth - 16;
          const scale = targetWidth / unscaledViewport.width;
          const viewport = page.getViewport({{ scale }});

          const canvas = document.createElement("canvas");
          const ctx = canvas.getContext("2d");
          canvas.width = viewport.width * dpr;
          canvas.height = viewport.height * dpr;
          canvas.style.width = viewport.width + "px";
          canvas.style.height = viewport.height + "px";
          ctx.scale(dpr, dpr);
          container.appendChild(canvas);
          await page.render({{ canvasContext: ctx, viewport: viewport }}).promise;
        }}
      }} catch (err) {{
        container.innerHTML = '<p id="pdf-loading">Dokument konnte nicht angezeigt werden: ' + (err && err.message ? err.message : err) + '</p>';
      }}
    }}

    function schliessen() {{
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      // window.close() funktioniert nur bei Tabs, die per Skript geöffnet
      // wurden (bei uns immer der Fall) -- als Rückfallebene trotzdem
      // zurück zur App navigieren, falls der Browser das aus
      // Sicherheitsgründen verweigert.
      window.close();
      setTimeout(function() {{ location.href = "/"; }}, 200);
    }}
  </script>
</body>
</html>"""


# ---------- PDF-Report-Export ----------

@app.get("/api/report/pdf")
def download_report(session=Depends(auth.require_full_auth)):
    pdf_bytes = generate_report_pdf()
    filename = f"Finanzreport_{datetime.now().strftime('%Y-%m-%d')}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/report/energy-pdf")
def download_energy_report(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    has_data = conn.execute("SELECT 1 FROM meter_readings LIMIT 1").fetchone() is not None
    conn.close()
    if not has_data:
        raise HTTPException(400, "Noch keine Zählerstände erfasst — Report kann noch nicht erstellt werden.")
    pdf_bytes = generate_energy_report_pdf()
    filename = f"Energy-Monitor-Report_{datetime.now().strftime('%Y-%m-%d')}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---------- Kategorien ----------

@app.get("/api/categories")
def list_categories(session=Depends(auth.require_full_auth)):
    from categorize import CATEGORIES
    conn = get_connection()
    db_names = {r["name"] for r in conn.execute("SELECT name FROM categories").fetchall()}
    conn.close()
    all_names = set(CATEGORIES) | db_names
    return sorted(all_names, key=lambda s: s.lower())


# ---------- Familienmitglieder (Stammdaten für Vorsorge/Risikoabsicherung) ----------

@app.get("/api/family-members")
def list_family_members(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM family_members ORDER BY sort_order, name"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/family-members")
def create_family_member(payload: FamilyMemberIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM family_members WHERE name=?", (payload.name,)).fetchone()
    if existing:
        conn.close()
        raise HTTPException(400, "Dieser Name ist schon als Familienmitglied angelegt.")
    max_order = conn.execute("SELECT COALESCE(MAX(sort_order),-1) AS m FROM family_members").fetchone()["m"]
    cur = conn.execute(
        "INSERT INTO family_members (name, role, birth_date, sort_order) VALUES (?,?,?,?)",
        (payload.name, payload.role, payload.birth_date, max_order + 1),
    )
    conn.commit()
    fid = cur.lastrowid
    conn.close()
    return {"id": fid, "status": "created"}


@app.patch("/api/family-members/{member_id}")
def update_family_member(member_id: int, patch: FamilyMemberPatch, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM family_members WHERE id=?", (member_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Familienmitglied nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    if not fields:
        conn.close()
        return {"status": "unchanged"}
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE family_members SET {set_clause} WHERE id=?", (*fields.values(), member_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/family-members/{member_id}")
def delete_family_member(member_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM family_members WHERE id=?", (member_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Familienmitglied nicht gefunden")
    # Verträge/Rentenkonten, die auf diese Person zeigen, bleiben erhalten,
    # verlieren aber die Zuordnung — kein Fremdschlüssel-Fehler beim Löschen.
    conn.execute("UPDATE contracts SET person_id=NULL WHERE person_id=?", (member_id,))
    conn.execute("DELETE FROM family_members WHERE id=?", (member_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


class CategoryIn(BaseModel):
    name: str


@app.post("/api/categories")
def create_category(payload: CategoryIn, session=Depends(auth.require_full_auth)):
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Bitte einen Namen angeben.")
    conn = get_connection()
    existing = conn.execute("SELECT id FROM categories WHERE name=?", (name,)).fetchone()
    if not existing:
        conn.execute("INSERT INTO categories (name) VALUES (?)", (name,))
        conn.commit()
    conn.close()
    return {"status": "created", "name": name}


@app.get("/api/maintenance/backups")
def get_backups(session=Depends(auth.require_full_auth)):
    import maintenance
    return maintenance.list_backups()


@app.post("/api/maintenance/backup-now")
def trigger_backup_now(session=Depends(auth.require_full_auth)):
    import maintenance
    return maintenance.backup_database()


@app.get("/api/maintenance/outdated-packages")
def get_outdated_packages(session=Depends(auth.require_full_auth)):
    """Live-Check beim Klick auf den Button in den Einstellungen — separat
    vom wöchentlichen Hintergrund-Check (check_dependencies.py), der
    unabhängig von einer offenen App-Sitzung läuft und sein Ergebnis in der
    settings-Tabelle hinterlegt."""
    import maintenance
    return maintenance.check_outdated()


@app.get("/api/maintenance/check-app-update")
def check_app_update_endpoint(session=Depends(auth.require_full_auth)):
    """Prüft das öffentliche Release-Manifest auf eine neuere App-Version
    (nicht zu verwechseln mit den Python-Paket-Updates oben)."""
    import maintenance
    return maintenance.check_app_update()


class ApplyAppUpdateIn(BaseModel):
    download_url: str
    sha256: str


@app.post("/api/maintenance/apply-app-update")
def apply_app_update_endpoint(payload: ApplyAppUpdateIn, session=Depends(auth.require_full_auth)):
    """Lädt die neue Version herunter, prüft sie und spielt sie ein —
    ausschließlich nach explizitem Klick des Nutzers (kein automatischer
    Hintergrund-Download ohne Bestätigung)."""
    import maintenance
    return maintenance.apply_app_update(payload.download_url, payload.sha256)


def _check_all_updates() -> dict:
    import maintenance
    return {"app": maintenance.check_app_update(), "packages": maintenance.check_outdated()}


def _apply_all_updates(payload: "ApplyAllUpdatesIn") -> dict:
    import maintenance
    results = {}

    if payload.apply_packages:
        pkg_result = maintenance.upgrade_all()
        results["packages"] = pkg_result
        if not pkg_result.get("success"):
            return {"status": "error", "results": results}
        conn = get_connection()
        conn.execute("DELETE FROM settings WHERE key='dependency_check_result'")
        conn.commit()
        conn.close()

    if payload.apply_app and payload.download_url:
        app_result = maintenance.apply_app_update(payload.download_url, payload.sha256 or "")
        results["app"] = app_result
        if app_result.get("status") != "applied":
            return {"status": "error", "results": results}
        # apply_app_update startet den Dienst bereits selbst neu
    elif payload.apply_packages:
        maintenance.restart_service()

    return {"status": "applied", "results": results}


@app.get("/api/maintenance/check-all-updates")
def check_all_updates_endpoint(session=Depends(auth.require_full_auth)):
    """Bündelt beide Update-Arten (App-Version + Python-Pakete) in einer
    Antwort — für den kombinierten 'Nach Updates suchen'-Button, der beim
    Start der Seite automatisch und in den Einstellungen manuell aufgerufen
    wird, statt zwei getrennte Prüfungen anzubieten."""
    return _check_all_updates()


class ApplyAllUpdatesIn(BaseModel):
    apply_app: bool = False
    apply_packages: bool = False
    download_url: Optional[str] = None
    sha256: Optional[str] = None


@app.post("/api/maintenance/apply-all-updates")
def apply_all_updates_endpoint(payload: ApplyAllUpdatesIn, session=Depends(auth.require_full_auth)):
    """Spielt genau das ein, was beim Check als verfügbar bestätigt wurde —
    zuerst Python-Pakete (falls angefordert), danach die neue App-Version
    (falls angefordert). Ein einzelner Neustart am Ende reicht in jedem
    Fall, auch wenn nur Pakete aktualisiert wurden."""
    return _apply_all_updates(payload)


@app.get("/api/public/check-updates")
def public_check_updates_endpoint():
    """Bewusst OHNE Login erreichbar -- die Update-Prüfung soll schon vor
    der Anmeldung stattfinden können (z.B. wenn ein Familienmitglied sich
    aus der App ausgesperrt hat, aber dennoch aktualisieren möchte). Rein
    lesend: fragt nur das öffentliche Release-Manifest und lokal
    installierte Paketversionen ab, gibt keine privaten Daten preis."""
    return _check_all_updates()


@app.post("/api/public/apply-updates")
def public_apply_updates_endpoint(payload: ApplyAllUpdatesIn):
    """Bewusst OHNE Login erreichbar, aus demselben Grund wie oben. Die
    Update-Quelle bleibt trotzdem strikt auf die fest einprogrammierte,
    vertrauenswürdige Domain begrenzt (siehe apply_app_update) und jede
    heruntergeladene Datei wird per Prüfsumme verifiziert, bevor sie
    eingespielt wird -- ein fehlender Login ändert daran nichts."""
    return _apply_all_updates(payload)


@app.post("/api/maintenance/restart-service")
def restart_service_endpoint(session=Depends(auth.require_full_auth)):
    import maintenance
    return maintenance.restart_service()


@app.post("/api/maintenance/upgrade-packages")
def upgrade_packages(session=Depends(auth.require_full_auth)):
    import maintenance
    result = maintenance.upgrade_all()
    if result["success"]:
        conn = get_connection()
        conn.execute("DELETE FROM settings WHERE key='dependency_check_result'")
        conn.commit()
        conn.close()
    return result


@app.get("/api/maintenance/last-background-check")
def get_last_background_check(session=Depends(auth.require_full_auth)):
    """Ergebnis des letzten automatischen Wochen-Checks (siehe
    check_dependencies.py) — läuft per launchd auch dann, wenn die App
    gerade nicht offen ist."""
    conn = get_connection()
    row = conn.execute(
        "SELECT value FROM settings WHERE key='dependency_check_result'"
    ).fetchone()
    conn.close()
    if not row:
        return {"checked_at": None, "outdated": []}
    return json.loads(row["value"])


@app.get("/api/insurance-types")
def list_insurance_types_dynamic(session=Depends(auth.require_full_auth)):
    from vorsorge import INSURANCE_TYPES
    conn = get_connection()
    db_names = {r["name"] for r in conn.execute("SELECT name FROM insurance_types").fetchall()}
    conn.close()
    all_names = set(INSURANCE_TYPES) | db_names
    return sorted(all_names, key=lambda s: s.lower())


@app.post("/api/insurance-types")
def create_insurance_type(payload: CategoryIn, session=Depends(auth.require_full_auth)):
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Bitte einen Namen angeben.")
    conn = get_connection()
    existing = conn.execute("SELECT id FROM insurance_types WHERE name=?", (name,)).fetchone()
    if not existing:
        conn.execute("INSERT INTO insurance_types (name) VALUES (?)", (name,))
        conn.commit()
    conn.close()
    return {"status": "created", "name": name}


# ---------- Verträge ----------

@app.get("/api/contracts")
def list_contracts(category: Optional[str] = None, status: str = "active",
                    needs_review: Optional[bool] = None,
                    session=Depends(auth.require_full_auth)):
    from categorize import derive_contract_label
    conn = get_connection()
    query = f"""SELECT co.*, c.name AS category_name, f.name AS person_name,
                       {monthly_expr('co.amount', 'co.frequency', 'co.split_share')} AS monthly_amount
               FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
                                  LEFT JOIN family_members f ON f.id = co.person_id
               WHERE co.status = ?"""
    params = [status]
    if category:
        query += " AND c.name = ?"
        params.append(category)
    if needs_review is not None:
        query += " AND co.reviewed = ?"
        params.append(0 if needs_review else 1)
    query += " ORDER BY c.name, co.subcategory, co.sort_order, COALESCE(co.provider, co.label)"
    rows = conn.execute(query, params).fetchall()
    conn.close()

    result = []
    for r in rows:
        d = dict(r)
        d["label_is_manual"] = bool(d["label"])
        if not d["label"]:
            d["label"] = derive_contract_label(
                d["category_name"], d["insurance_type"], d["person_name"],
                d["provider"], d["contract_number"],
            )
        result.append(d)
    return result


@app.patch("/api/contracts/{contract_id}")
def update_contract(contract_id: int, patch: ContractPatch,
                     session=Depends(auth.require_full_auth)):
    """Manuelle Korrektur — bleibt gültig, bis ein neues automatisches Update
    (z.B. per Foto-Beleg) den Wert erneut überschreibt."""
    conn = get_connection()
    existing = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")

    fields = patch.dict(exclude_unset=True)
    category_name = fields.pop("category", None)
    category_changed = False
    if category_name:
        cur = conn.execute("SELECT id FROM categories WHERE name=?", (category_name,))
        row = cur.fetchone()
        new_category_id = row["id"] if row else conn.execute(
            "INSERT INTO categories (name) VALUES (?)", (category_name,)
        ).lastrowid
        category_changed = new_category_id != existing["category_id"]
        fields["category_id"] = new_category_id

    # Nur tatsächlich GEÄNDERTE Felder übernehmen — das Formular schickt beim
    # Speichern immer alle Felder mit, auch unveränderte. Ohne diesen
    # Abgleich würde jedes Öffnen+Speichern ohne echte Änderung trotzdem
    # updated_at/source überschreiben.
    def _norm(v):
        if v is None:
            return None
        if isinstance(v, bool):
            return int(v)
        if hasattr(v, "isoformat"):
            return v.isoformat()
        return v

    changed = {
        k: v for k, v in fields.items()
        if k not in existing.keys() or _norm(v) != _norm(existing[k])
    }
    if category_changed:
        # Explizite Kategorie-Wahl gilt als "geprüft" — auch wenn wieder
        # "Sonstiges" gewählt wird, verschwindet die Position dann aus der
        # Review-Liste, weil jetzt bewusst bestätigt statt nur importiert.
        changed["reviewed"] = 1
    fields = changed

    if not fields:
        conn.close()
        return {"status": "unchanged"}

    fields["source"] = "manuell"
    fields["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE contracts SET {set_clause} WHERE id=?",
                 (*fields.values(), contract_id))

    if {"contract_end", "notice_period_days", "category_id", "subcategory"} & fields.keys():
        _sync_reminders(conn, contract_id)

    conn.commit()
    conn.close()
    return {"status": "updated"}




ARCHIVE_DIR = RECEIPTS_DIR / "_archiv"


def _migrate_receipts_person_separation_once():
    """Einmalige Migration: Verträge, die einer Person zugeordnet sind,
    bekommen nachträglich eine eigene Ordnerebene (z.B.
    Versicherungen/Berufsunfähigkeitsversicherung/Anna/... statt alle
    Personen im selben Anbieter-Ordner zu vermischen). Verschiebt bestehende
    Ordner physisch und aktualisiert die gespeicherten Beleg-Pfade
    entsprechend — sowohl für aktive als auch archivierte Verträge."""
    conn = get_connection()
    flag = conn.execute(
        "SELECT value FROM settings WHERE key='migration_receipts_person_separation'"
    ).fetchone()
    if flag:
        conn.close()
        return

    contracts = conn.execute(
        """SELECT co.id, co.status, co.subcategory, co.provider, co.label, co.person_id,
                  c.name AS category_name, fm.name AS person_name
           FROM contracts co
           LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.person_id IS NOT NULL"""
    ).fetchall()

    moved_count = 0
    for contract in contracts:
        if not contract["person_name"]:
            continue
        old_parts = _contract_folder_parts(
            contract["category_name"], contract["subcategory"], contract["provider"], contract["label"]
        )
        new_parts = _contract_folder_parts(
            contract["category_name"], contract["subcategory"], contract["provider"], contract["label"],
            contract["person_name"],
        )
        if old_parts == new_parts:
            continue  # z.B. Provider/Label leer -> beide Pfade zufällig identisch

        if contract["status"] == "cancelled":
            old_dir = ARCHIVE_DIR.joinpath(*(old_parts[:-1] + [f"{old_parts[-1]}_{contract['id']}"]))
            new_dir = ARCHIVE_DIR.joinpath(*(new_parts[:-1] + [f"{new_parts[-1]}_{contract['id']}"]))
        else:
            old_dir = RECEIPTS_DIR.joinpath(*old_parts)
            new_dir = RECEIPTS_DIR.joinpath(*new_parts)

        if not old_dir.exists() or not old_dir.is_dir():
            continue
        if old_dir == new_dir:
            continue

        new_dir.parent.mkdir(parents=True, exist_ok=True)
        if new_dir.exists():
            # Zielordner existiert schon (unwahrscheinlich, aber möglich) —
            # Dateien einzeln verschieben statt zu überschreiben.
            for item in old_dir.iterdir():
                dest = new_dir / item.name
                if not dest.exists():
                    item.rename(dest)
            try:
                old_dir.rmdir()
            except OSError:
                pass
        else:
            old_dir.rename(new_dir)

        # Beleg-Pfade in der DB auf die neue Lage nachziehen, sonst würden
        # "Beleg ansehen"-Links auf nicht mehr existierende Pfade zeigen.
        receipts = conn.execute(
            "SELECT id, stored_path FROM receipts WHERE contract_id=?", (contract["id"],)
        ).fetchall()
        for r in receipts:
            old_path = BASE_DIR / r["stored_path"]
            try:
                rel = old_path.relative_to(old_dir)
            except ValueError:
                continue
            new_path = new_dir / rel
            conn.execute(
                "UPDATE receipts SET stored_path=? WHERE id=?",
                (str(new_path.relative_to(BASE_DIR)), r["id"]),
            )
        moved_count += 1

    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('migration_receipts_person_separation', 'true')"
    )
    conn.commit()
    conn.close()
    if moved_count:
        print(f"Migration: {moved_count} Vertragsordner nach Person getrennt")


@app.delete("/api/contracts/{contract_id}")
def delete_contract(contract_id: int, session=Depends(auth.require_full_auth)):
    """'Löschen' archiviert den Vertrag, statt ihn hart zu entfernen: Status
    wird auf 'cancelled' gesetzt (verschwindet damit aus der aktiven Liste
    und aus allen Kosten-Berechnungen, die nach status='active' filtern),
    und ein eventuell vorhandener Belege-Ordner wird strukturiert ins Archiv
    verschoben. Ein echtes Löschen würde entweder die verknüpften Belege per
    FOREIGN KEY-Fehler blockieren, oder — falls man das stattdessen einfach
    entkoppelt — Dokumente und Historie unwiederbringlich von ihrem
    Vertragskontext trennen. Damit bleiben Dateien und Zuordnung erhalten
    und sind über das Archiv weiterhin auffindbar."""
    conn = get_connection()
    contract = conn.execute(
        """SELECT co.*, c.name AS category_name, fm.name AS person_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.id=?""",
        (contract_id,),
    ).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")

    parts = _contract_folder_parts(
        contract["category_name"], contract["subcategory"], contract["provider"], contract["label"],
        contract["person_name"],
    )
    source_dir = RECEIPTS_DIR.joinpath(*parts)
    if source_dir.exists() and source_dir.is_dir() and any(source_dir.iterdir()):
        archive_parts = parts[:-1] + [f"{parts[-1]}_{contract_id}"]
        target_dir = ARCHIVE_DIR.joinpath(*archive_parts)
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        if not target_dir.exists():
            source_dir.rename(target_dir)
            # Alle Belege, deren Datei im verschobenen Ordner lag, auf den
            # neuen Pfad umbiegen, damit "Beleg ansehen" weiterhin funktioniert.
            receipts = conn.execute(
                "SELECT id, stored_path FROM receipts WHERE contract_id=?", (contract_id,)
            ).fetchall()
            for r in receipts:
                old_path = BASE_DIR / r["stored_path"]
                try:
                    rel = old_path.relative_to(source_dir)
                except ValueError:
                    continue  # Datei lag aus irgendeinem Grund nicht in diesem Ordner
                new_path = target_dir / rel
                if new_path.exists():
                    conn.execute(
                        "UPDATE receipts SET stored_path=? WHERE id=?",
                        (str(new_path.relative_to(BASE_DIR)), r["id"]),
                    )

    # Erinnerungen (Kündigungsfrist etc.) sind für einen archivierten Vertrag
    # irrelevant und würden sonst weiter Benachrichtigungen auslösen.
    conn.execute("DELETE FROM reminders WHERE contract_id=?", (contract_id,))
    conn.execute("UPDATE contracts SET status='cancelled' WHERE id=?", (contract_id,))
    conn.commit()
    conn.close()
    return {"status": "archived"}


@app.post("/api/contracts/{contract_id}/restore")
def restore_contract(contract_id: int, session=Depends(auth.require_full_auth)):
    """Macht das Archivieren rückgängig: Status zurück auf 'active', Belege-
    Ordner (falls vorhanden) zurück an seinen normalen Platz verschoben."""
    conn = get_connection()
    contract = conn.execute(
        """SELECT co.*, c.name AS category_name, fm.name AS person_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.id=?""",
        (contract_id,),
    ).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")
    if contract["status"] != "cancelled":
        conn.close()
        raise HTTPException(400, "Dieser Vertrag ist nicht archiviert.")

    parts = _contract_folder_parts(
        contract["category_name"], contract["subcategory"], contract["provider"], contract["label"],
        contract["person_name"],
    )
    archive_parts = parts[:-1] + [f"{parts[-1]}_{contract_id}"]
    source_dir = ARCHIVE_DIR.joinpath(*archive_parts)
    target_dir = RECEIPTS_DIR.joinpath(*parts)

    if source_dir.exists() and source_dir.is_dir():
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        if target_dir.exists():
            # Es gibt schon wieder einen aktiven Ordner mit demselben Namen
            # (z.B. ein neuer Vertrag beim selben Anbieter) — Dateien werden
            # einzeln hinein verschoben statt den ganzen Ordner umzubenennen,
            # damit dabei nichts überschrieben wird.
            for item in source_dir.iterdir():
                dest = target_dir / item.name
                if not dest.exists():
                    item.rename(dest)
            try:
                source_dir.rmdir()
            except OSError:
                pass  # Ordner nicht leer (Namenskollision) — bleibt als Rest im Archiv liegen
        else:
            source_dir.rename(target_dir)

        receipts = conn.execute(
            "SELECT id, stored_path FROM receipts WHERE contract_id=?", (contract_id,)
        ).fetchall()
        for r in receipts:
            old_path = BASE_DIR / r["stored_path"]
            new_path = target_dir / old_path.name
            if new_path.exists():
                conn.execute(
                    "UPDATE receipts SET stored_path=? WHERE id=?",
                    (str(new_path.relative_to(BASE_DIR)), r["id"]),
                )

    conn.execute("UPDATE contracts SET status='active' WHERE id=?", (contract_id,))
    conn.commit()
    conn.close()
    return {"status": "restored"}


@app.get("/api/contracts/{contract_id}/repayment-schedule")
def get_repayment_schedule(contract_id: int, session=Depends(auth.require_full_auth)):
    """Tilgungsplan für eine Immobilienfinanzierung ab der aktuellen
    Restschuld. Nutzt die monatliche Vertragsrate; ist keine sinnvolle Rate
    hinterlegt, wird auf den Tilgungssatz zurückgegriffen."""
    from finanzierung import compute_repayment_schedule
    conn = get_connection()
    c = conn.execute(
        """SELECT co.*, cat.name AS category_name FROM contracts co
           LEFT JOIN categories cat ON cat.id = co.category_id WHERE co.id=?""",
        (contract_id,),
    ).fetchone()
    conn.close()
    if not c:
        raise HTTPException(404, "Vertrag nicht gefunden")

    monthly = c["amount"] if c["frequency"] == "monthly" else (
        c["amount"] / 3 if c["frequency"] == "quarterly" else c["amount"] / 12
    )
    return compute_repayment_schedule(
        remaining_debt=c["remaining_debt"],
        interest_rate=c["interest_rate"],
        monthly_payment=monthly,
        repayment_rate=c["repayment_rate"],
    )


@app.get("/api/verbindlichkeiten/overview")
def verbindlichkeiten_overview(session=Depends(auth.require_full_auth)):
    """Übersicht über alle laufenden Finanzierungen: gewichteter
    Durchschnittszins, anstehende Zinsbindungsenden, und ein aggregierter
    Tilgungsplan über ALLE Finanzierungen zusammen (Restschuld + kumulierte
    Zinsen pro Jahr summiert) — für den Fall, dass keine einzelne
    Finanzierung ausgewählt ist."""
    from finanzierung import compute_repayment_schedule
    conn = get_connection()
    rows = conn.execute(
        """SELECT co.* FROM contracts co
           LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.subcategory = 'Finanzierung' AND co.status = 'active'"""
    ).fetchall()
    conn.close()

    if not rows:
        return {"average_interest_rate": None, "total_remaining_debt": 0, "upcoming_rate_locks": [],
                "aggregated_schedule": {"error": "Keine laufende Finanzierung unter Ausgaben hinterlegt.", "schedule": []}}

    total_debt = sum(r["remaining_debt"] or 0 for r in rows)
    weighted_rate = (
        sum((r["remaining_debt"] or 0) * (r["interest_rate"] or 0) for r in rows) / total_debt
        if total_debt else None
    )

    upcoming_rate_locks = sorted([
        {"label": r["label"], "contract_end": r["contract_end"], "remaining_debt": r["remaining_debt"]}
        for r in rows if r["contract_end"]
    ], key=lambda x: x["contract_end"])

    per_loan_schedules = []
    total_monthly_payment = 0.0
    max_payoff_year = None
    min_start_year = None
    for r in rows:
        if not r["remaining_debt"] or not r["interest_rate"]:
            continue
        monthly = r["amount"] if r["frequency"] == "monthly" else (
            r["amount"] / 3 if r["frequency"] == "quarterly" else r["amount"] / 12
        )
        result = compute_repayment_schedule(
            remaining_debt=r["remaining_debt"], interest_rate=r["interest_rate"],
            monthly_payment=monthly, repayment_rate=r["repayment_rate"],
        )
        if result.get("error"):
            continue
        total_monthly_payment += monthly
        per_loan_schedules.append({p["year"]: p for p in result["schedule"]})
        years_here = [p["year"] for p in result["schedule"]]
        if max_payoff_year is None or years_here[-1] > max_payoff_year:
            max_payoff_year = years_here[-1]
        if min_start_year is None or years_here[0] < min_start_year:
            min_start_year = years_here[0]

    schedule = []
    if per_loan_schedules and min_start_year is not None:
        # Über den GESAMTEN Zeitraum aller Darlehen hinweg: ein Darlehen, das
        # früher fertig getilgt ist, wird für die restlichen Jahre mit
        # eingefrorener Restschuld (0) und eingefrorenen Gesamtzinsen
        # fortgeschrieben — sonst würde sein bereits gezahlter Zins beim
        # Zusammenzählen später fälschlich aus der Summe herausfallen.
        last_known = [None] * len(per_loan_schedules)
        for y in range(min_start_year, max_payoff_year + 1):
            debt_sum = 0.0
            interest_sum = 0.0
            for i, loan_schedule in enumerate(per_loan_schedules):
                point = loan_schedule.get(y)
                if point is not None:
                    last_known[i] = point
                elif last_known[i] is not None:
                    point = {"remaining_debt": 0.0, "interest_paid_cumulative": last_known[i]["interest_paid_cumulative"]}
                if point is not None:
                    debt_sum += point["remaining_debt"]
                    interest_sum += point["interest_paid_cumulative"]
            schedule.append({"year": y, "remaining_debt": round(debt_sum, 2), "interest_paid_cumulative": round(interest_sum, 2)})

    total_interest_final = schedule[-1]["interest_paid_cumulative"] if schedule else 0
    start_year = schedule[0]["year"] if schedule else None

    aggregated_schedule = {
        "error": None if schedule else "Keine Finanzierung mit vollständigen Angaben (Restschuld, Zinssatz) gefunden.",
        "schedule": schedule,
        "remaining_debt": round(total_debt, 2),
        "interest_rate": round(weighted_rate, 2) if weighted_rate is not None else None,
        "monthly_payment": round(total_monthly_payment, 2),
        "payoff_year": max_payoff_year,
        "years_to_payoff": round(max_payoff_year - start_year, 1) if max_payoff_year and start_year else None,
        "total_interest": round(total_interest_final, 2),
    }

    return {
        "average_interest_rate": round(weighted_rate, 2) if weighted_rate is not None else None,
        "total_remaining_debt": round(total_debt, 2),
        "upcoming_rate_locks": upcoming_rate_locks,
        "aggregated_schedule": aggregated_schedule,
    }


@app.get("/api/contracts/{contract_id}/receipts")
def list_contract_receipts(contract_id: int, session=Depends(auth.require_full_auth)):
    """Alle Belege zu einem Vertrag (aktiv oder archiviert) — für 'alle
    Dateien anzeigen', ohne dafür ins Dateisystem wechseln zu müssen."""
    conn = get_connection()
    contract = conn.execute("SELECT id FROM contracts WHERE id=?", (contract_id,)).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")
    rows = conn.execute(
        """SELECT id, original_filename, detected_amount, detected_date, uploaded_at
           FROM receipts WHERE contract_id=? ORDER BY uploaded_at DESC""",
        (contract_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/api/archive")
def list_archived_contracts(session=Depends(auth.require_full_auth)):
    """Archivierte (gekündigte/gelöschte) Verträge inkl. Beleg-Anzahl, für
    den Archiv-Bereich in der UI."""
    conn = get_connection()
    rows = conn.execute(
        """SELECT co.id, co.label, co.provider, co.subcategory, c.name AS category_name,
                  co.updated_at,
                  (SELECT COUNT(*) FROM receipts WHERE contract_id = co.id) AS receipt_count
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.status = 'cancelled'
           ORDER BY co.updated_at DESC"""
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/contracts")
def create_contract(contract: ContractIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    category_id = None
    if contract.category:
        cur = conn.execute("SELECT id FROM categories WHERE name=?", (contract.category,))
        row = cur.fetchone()
        category_id = row["id"] if row else conn.execute(
            "INSERT INTO categories (name) VALUES (?)", (contract.category,)
        ).lastrowid

    cur = conn.execute(
        """INSERT INTO contracts
           (label, provider, contract_number, category_id, subcategory, amount, frequency,
            payment_method, contract_end, notice_period_days, auto_renews, status, source,
            person_id, interest_rate, remaining_debt, repayment_rate, fixed_interest_until,
            insurance_type, insurance_expiry, insurance_sum, insurance_sum_type, bu_monthly_pension)
           VALUES (?,?,?,?,?,?,?,?,?,?,?, 'active', 'manuell', ?,?,?,?,?,?,?,?,?,?)""",
        (contract.label or "", contract.provider, contract.contract_number, category_id,
         contract.subcategory, contract.amount, contract.frequency, contract.payment_method,
         contract.contract_end, contract.notice_period_days, int(contract.auto_renews),
         contract.person_id, contract.interest_rate, contract.remaining_debt,
         contract.repayment_rate, contract.fixed_interest_until, contract.insurance_type,
         contract.insurance_expiry, contract.insurance_sum, contract.insurance_sum_type,
         contract.bu_monthly_pension),
    )
    contract_id = cur.lastrowid
    conn.commit()

    _sync_reminders(conn, contract_id)
    conn.commit()
    conn.close()
    return {"id": contract_id, "status": "created"}


# ---------- Einnahmen ----------

@app.get("/api/income")
def list_income(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        f"""SELECT *, {monthly_expr('amount', 'frequency')} AS monthly_amount
            FROM income ORDER BY active DESC, monthly_amount DESC, label"""
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/api/income")
def create_income(payload: IncomeIn, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO income (label, category, amount, frequency, active, source, person_id) VALUES (?,?,?,?,1,'manuell',?)",
        (payload.label, payload.category or "Sonstiges", payload.amount, payload.frequency, payload.person_id),
    )
    conn.commit()
    conn.close()
    return {"id": cur.lastrowid, "status": "created"}


@app.patch("/api/income/{income_id}")
def update_income(income_id: int, patch: IncomePatch, session=Depends(auth.require_full_auth)):
    """Manuelle Korrektur — bleibt gültig, bis die nächste Gehaltsabrechnung importiert wird."""
    conn = get_connection()
    existing = conn.execute("SELECT * FROM income WHERE id=?", (income_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Einnahme nicht gefunden")
    fields = patch.dict(exclude_unset=True)

    # Nur tatsächlich geänderte Felder übernehmen (gleicher Fix wie bei den
    # Verträgen) — sonst würde jedes Öffnen+Speichern ohne echte Änderung
    # trotzdem updated_at/source überschreiben.
    def _norm(v):
        if v is None:
            return None
        if isinstance(v, bool):
            return int(v)
        return v

    changed = {
        k: v for k, v in fields.items()
        if k not in existing.keys() or _norm(v) != _norm(existing[k])
    }
    if not changed:
        conn.close()
        return {"status": "unchanged"}
    changed["source"] = "manuell"
    changed["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k}=?" for k in changed)
    conn.execute(f"UPDATE income SET {set_clause} WHERE id=?", (*changed.values(), income_id))
    conn.commit()
    conn.close()
    return {"status": "updated"}


@app.delete("/api/income/{income_id}")
def delete_income(income_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM income WHERE id=?", (income_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Einnahme nicht gefunden")
    conn.execute("DELETE FROM income WHERE id=?", (income_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


# ---------- Chatbot (lokal, über Ollama) ----------

class ChatIn(BaseModel):
    question: str


@app.post("/api/chat")
def chat(payload: ChatIn, session=Depends(auth.require_full_auth)):
    answer = ask_chatbot(payload.question)
    return {"answer": answer}





# ---------- Statische PWA ausliefern ----------
# Energy-Monitor-Endpunkte aus dem eigenen Modul einbinden. Bewusst HIER,
# direkt vor dem StaticFiles-Mount: Der Mount auf "/" fängt sonst alles ab,
# was vorher nicht registriert wurde.
import energy_routes
app.include_router(energy_routes.router)

import vorsorge_routes
app.include_router(vorsorge_routes.router)

import vermoegen_routes
app.include_router(vermoegen_routes.router)

import receipts_routes
app.include_router(receipts_routes.router)

app.mount("/", StaticFiles(directory=str(BASE_DIR / "frontend"), html=True), name="frontend")
