"""
Client für die (von myenergi selbst als "inoffiziell unterstützt"
bezeichnete) myenergi-API — liest die täglich geladene Energiemenge der
Zappi-Wallbox aus, um sie als eigenen Zählertyp ("ev_charging") in die App
zu übernehmen und so vom normalen Hausverbrauch zu trennen.

WICHTIG, ehrlich gesagt: Diese API ist nicht offiziell dokumentiert. Der
Authentifizierungs-Ablauf (Director-Weiterleitung + Digest-Auth mit der
Hub-Seriennummer) ist gut belegt und wird von mehreren seit Jahren
funktionierenden Open-Source-Projekten genutzt (siehe z.B.
github.com/twonk/MyEnergi-App-Api, github.com/G6EJD/MyEnergi-Python-Example).
Das genaue Feldformat der Tagesdaten-Antwort konnte ich mangels Netzzugriff
in dieser Umgebung nicht gegen die echten Server verifizieren — die
Fehlermeldungen unten sind bewusst konkret gehalten, damit ein
abweichendes Format beim ersten echten Test sofort auffällt, statt
stillschweigend falsche Werte zu übernehmen.
"""
import httpx
from datetime import date, timedelta
from typing import Optional

DIRECTOR_HOST = "director.myenergi.net"


class MyenergiError(Exception):
    pass


def _client(hub_serial: str, hub_password: str, host: str) -> httpx.Client:
    return httpx.Client(
        auth=httpx.DigestAuth(hub_serial, hub_password),
        base_url=f"https://{host}",
        timeout=15.0,
        headers={"User-Agent": "FamilyFinance/1.0"},
    )


def _resolve_server(hub_serial: str, hub_password: str) -> str:
    """Der Director gibt per Response-Header bekannt, welcher Regionalserver
    für den jeweiligen Hub zuständig ist -- ALLE weiteren Aufrufe müssen
    gegen DIESEN Server gehen, nicht gegen den Director selbst."""
    with _client(hub_serial, hub_password, DIRECTOR_HOST) as c:
        r = c.get(f"/cgi-jstatus-E{hub_serial}")
        if r.status_code == 401:
            raise MyenergiError("Anmeldung fehlgeschlagen — Hub-Seriennummer oder Passwort falsch.")
        r.raise_for_status()
        server = r.headers.get("x_myenergi-asn")
        if not server:
            raise MyenergiError(
                "Der Director hat keinen zuständigen Server genannt (Header "
                "'x_myenergi-asn' fehlt) — das API-Format hat sich vermutlich "
                "geändert."
            )
        return server


def test_connection(hub_serial: str, hub_password: str) -> dict:
    """Nur Zugangsdaten prüfen, ohne Daten zu importieren — für einen
    'Verbindung testen'-Knopf getrennt vom eigentlichen Sync."""
    try:
        server = _resolve_server(hub_serial, hub_password)
        return {"ok": True, "server": server}
    except MyenergiError as e:
        return {"ok": False, "error": str(e)}
    except httpx.HTTPError as e:
        return {"ok": False, "error": f"Verbindung fehlgeschlagen: {e}"}


def fetch_daily_charge_kwh(hub_serial: str, hub_password: str, zappi_serial: str,
                            start: date, end: date) -> dict:
    """Liefert {'YYYY-MM-DD': geladene_kWh} für jeden Tag im Bereich [start, end].

    Nutzt den 'cgi-jday-Z<seriennummer>-<datum>'-Endpunkt, der laut den oben
    verlinkten Referenzprojekten je Tag eine Liste von ~5-Minuten-Einträgen
    liefert; die geladene Energiemenge steckt darin als Watt-Sekunden je
    Kanal (üblicherweise 'h1d' = importierter Netzstrom in Wh, wenn der
    Wagen lädt). Da sich das Feldformat je nach Zappi-Firmware/-Version
    unterscheiden kann, wird hier bewusst defensiv geparst -- ein
    unerwartetes Format führt zu einem klaren Fehler statt einer
    stillschweigend falschen Zahl."""
    server = _resolve_server(hub_serial, hub_password)
    result = {}
    with _client(hub_serial, hub_password, server) as c:
        day = start
        while day <= end:
            date_str = day.strftime("%Y-%m-%d")
            r = c.get(f"/cgi-jday-Z{zappi_serial}-{date_str}")
            if r.status_code == 404:
                day += timedelta(days=1)
                continue  # kein Wagen angeschlossen an dem Tag -> 0, einfach überspringen
            r.raise_for_status()
            payload = r.json()
            entries = payload.get(f"U{zappi_serial}") if isinstance(payload, dict) else None
            if entries is None and isinstance(payload, list):
                entries = payload
            if not entries:
                day += timedelta(days=1)
                continue
            # 'h1d' ist in den Referenzimplementierungen der Kanal für vom
            # Zappi bezogene Netzenergie in Wh, kumulativ über den Tag --
            # der höchste Wert des Tages ist damit die Tagesenergie.
            wh_values = [e.get("h1d") for e in entries if isinstance(e, dict) and "h1d" in e]
            if not wh_values:
                raise MyenergiError(
                    f"Unerwartetes Antwortformat für {date_str} — Feld 'h1d' nicht gefunden. "
                    "Das deutet auf eine geänderte API hin und sollte geprüft werden, "
                    "bevor automatisch weiter importiert wird."
                )
            result[date_str] = round(max(wh_values) / 1000.0, 3)
            day += timedelta(days=1)
    return result
