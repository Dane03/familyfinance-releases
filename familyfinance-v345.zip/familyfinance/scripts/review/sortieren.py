"""Offene Bankumsätze sortieren, Direktübernahme-Hinweise, Monatsabschluss und Statuszeile (v342). Ohne Server, Sekunden.
    cd kopie/backend && python3 ../scripts/review/sortieren.py
Exit-Code 0 = alles grün. Arbeitet nur in einem Temp-Ordner.

Fälle:
 1) GET /api/banks/open-groups: Gruppierung je Empfänger (Umsätze ohne Empfänger gesammelt), größte Summe zuerst, Alltag/zugeordnete zählen nicht mit.
 2) POST /api/banks/transactions/bulk-assign: Alltag, Vertrag (lernt Regel, ordnet gleiche Umsätze nach), zurück auf
    offen; leere Auswahl -> 400, unbekanntes Ziel -> 404, falscher Modus -> 400; zugeordnete Umsätze bleiben unberührt;
    apply_rules fasst Alltag nie an.
 2b) Begründung (rule_reason) bei Regel-Umsätzen.
 3) Dashboard-Hinweis "offene Umsätze" erscheint ohne Schlüssel (nicht ablehnbar) und verschwindet nach dem Sortieren.
 4) GET /api/month-close: Punkte nur wenn zutreffend; Abrechnung fehlt/vorhanden, Bank frisch/alt, offene Umsätze.
 5) GET /api/status-line: Bank-/PV-/Sicherungs-Zeitstempel.
"""
import contextlib
import io
import sqlite3
import sys
import tempfile
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
TMP = Path(tempfile.mkdtemp(prefix="ff_sort_"))
(TMP / "data").mkdir()

import database  # noqa: E402
import maintenance  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"
maintenance.BASE_DIR = TMP

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
    import app as appmod
import auth  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

appmod.app.dependency_overrides[auth.require_full_auth] = lambda: {"stage": "full"}
cl = TestClient(appmod.app, base_url="http://localhost:8420", raise_server_exceptions=False)
c = sqlite3.connect(database.DB_PATH)
c.row_factory = sqlite3.Row

c.execute("INSERT INTO bank_accounts (connection_key, iban, label, balance_updated_at) VALUES ('k','DE00','Giro',?)",
          ((datetime.now() - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S"),))
acc = c.execute("SELECT id FROM bank_accounts").fetchone()[0]
c.execute("INSERT INTO contracts (label, amount, frequency, status, source) VALUES ('Strom', 50, 'monthly', 'active', 'manuell')")
strom = c.execute("SELECT id FROM contracts WHERE label='Strom'").fetchone()[0]
n = 0


def tx(name, amount, day, iban=None):
    global n
    n += 1
    c.execute("INSERT INTO bank_transactions (bank_account_id, booking_date, amount, counterparty_name, counterparty_iban, purpose, tx_hash) "
              "VALUES (?,?,?,?,?,?,?)", (acc, f"2026-10-{day:02d}", amount, name, iban, "Zweck", f"h{n}"))
    return c.execute("SELECT MAX(id) FROM bank_transactions").fetchone()[0]


for i in range(4): tx("AMAZON EU", -20.0 - i, i + 1)          # 4 Umsätze, 86 EUR
for i in range(3): tx("ALDI SUED", -35.5, i + 1)              # 3 Umsätze, gleicher Betrag
stadt = [tx("STADTWERKE", -50.0, i + 1) for i in range(2)]
done = tx("SCHON ZUGEORDNET", -9.0, 5)
c.execute("UPDATE bank_transactions SET contract_id=?, match_source='manual' WHERE id=?", (strom, done))
tx("", -1.0, 6)                                               # ohne jedes Merkmal -> eigene Sammelgruppe
c.commit()


def groups():
    return cl.get("/api/banks/open-groups").json()


print("== 1) Gruppen")
g = groups()
check("Status", cl.get("/api/banks/open-groups").status_code, 200)
check("Reihenfolge nach Summe (inkl. Gruppe ohne Empfänger zuletzt)", [x["name"] for x in g["groups"]], ["ALDI SUED", "STADTWERKE", "AMAZON EU", "Ohne Empfängerangabe"])
check("Anzahl + Summe Amazon", [(x["count"], x["total"]) for x in g["groups"] if x["name"] == "AMAZON EU"], [(4, -86.0)])
check("gleicher Betrag erkannt", {x["name"]: x["same_amount"] for x in g["groups"]},
      {"ALDI SUED": True, "STADTWERKE": True, "AMAZON EU": False, "Ohne Empfängerangabe": True})
check("offen insgesamt (ohne Zugeordnete)", g["total_open"], 10)

print("== 2) Sammelzuordnung")
aldi = next(x for x in g["groups"] if x["name"] == "ALDI SUED")
r = cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": aldi["tx_ids"], "mode": "everyday"})
check("Alltag: 200, 3 geändert", (r.status_code, r.json().get("changed")), (200, 3))
check("Alltag aus offener Liste", "ALDI SUED" in [x["name"] for x in groups()["groups"]], False)
check("Alltag ohne Vertrag/Einnahme", tuple(c.execute("SELECT contract_id, income_id FROM bank_transactions WHERE counterparty_name='ALDI SUED'").fetchone()), (None, None))
appmod_bm = __import__("bank_matching")
check("apply_rules fasst Alltag nie an", (appmod_bm.apply_rules(c), c.execute("SELECT DISTINCT match_source FROM bank_transactions WHERE counterparty_name='ALDI SUED'").fetchone()[0]), (0, "everyday"))

r = cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": stadt, "mode": "target", "kind": "contract", "target_id": strom})
check("Vertrag: 200, 2 geändert", (r.status_code, r.json().get("changed")), (200, 2))
check("Vertrag gesetzt, manuell", sorted(tuple(x) for x in c.execute("SELECT contract_id, match_source FROM bank_transactions WHERE counterparty_name='STADTWERKE'").fetchall()), [(strom, "manual")] * 2)
check("Regel gelernt (Empfänger -> Vertrag)", c.execute("SELECT COUNT(*) FROM bank_match_rules WHERE kind='contract' AND target_id=?", (strom,)).fetchone()[0] >= 1, True)
tx("STADTWERKE", -50.0, 9); c.commit()
check("neuer gleicher Umsatz folgt der Regel", appmod_bm.apply_rules(c), 1)

r = cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": aldi["tx_ids"], "mode": "open"})
check("zurück auf offen: 3 geändert", r.json().get("changed"), 3)
check("wieder in offener Liste", "ALDI SUED" in [x["name"] for x in groups()["groups"]], True)
r = cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": [done], "mode": "everyday"})
check("bereits zugeordneter Umsatz bleibt unberührt", (r.json().get("changed"), c.execute("SELECT contract_id FROM bank_transactions WHERE id=?", (done,)).fetchone()[0]), (0, strom))
check("leere Auswahl: 400", cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": [], "mode": "everyday"}).status_code, 400)
check("unbekanntes Ziel: 404", cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": aldi["tx_ids"], "mode": "target", "kind": "contract", "target_id": 99999}).status_code, 404)
check("falscher Modus: 400", cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": aldi["tx_ids"], "mode": "x"}).status_code, 400)
check("falscher kind: 400", cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": aldi["tx_ids"], "mode": "target", "kind": "x", "target_id": 1}).status_code, 400)

print("== 2b) Warum wurde das zugeordnet?")
rows = cl.get(f"/api/banks/accounts/{acc}/transactions?q=STADTWERKE").json()
rule_rows = [r for r in rows if r["match_source"] == "rule"]
check("Regel-Umsatz hat Begründung", bool(rule_rows) and "Empfängername stadtwerke" in rule_rows[0]["rule_reason"], True)
check("Begründung nennt Betrag und Datum", bool(rule_rows) and "Betrag 50,00 €" in rule_rows[0]["rule_reason"] and "gelernt am" in rule_rows[0]["rule_reason"], True)
check("manuelle Zuordnung hat keine Begründung", all("rule_reason" not in r for r in rows if r["match_source"] == "manual"), True)

print("== 3) Dashboard-Hinweis")
hints = [h for h in cl.get("/api/dashboard").json()["hints"] if h["anchor"] == "bank-open-card"]
check("Hinweis vorhanden, nicht ablehnbar", (len(hints), hints[0]["key"] if hints else "?"), (1, None))
open_ids = [i for x in groups()["groups"] for i in x["tx_ids"]]
cl.post("/api/banks/transactions/bulk-assign", json={"tx_ids": open_ids, "mode": "everyday"})
hints = [h for h in cl.get("/api/dashboard").json()["hints"] if h["anchor"] == "bank-open-card"]
check("Hinweis weg, wenn nichts mehr offen", (len(hints), groups()["total_open"]), (0, 0))

print("== 4) Monatsabschluss")
mc = cl.get("/api/month-close").json()
keys = {i["key"]: i["ok"] for i in mc["items"]}
check("Bank frisch", keys.get("bank"), True)
check("keine Gehaltsabrechnungen -> kein Punkt", "payslips" not in keys, True)
check("keine Zähler -> kein Punkt", "meters" not in keys, True)
check("Zähler: Zählung done/total stimmt", (mc["done"], mc["total"]), (sum(keys.values()), len(keys)))
prev = (date.today().replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
c.execute("INSERT INTO income (label, category, amount, frequency, active) VALUES ('Gehalt', 'Gehalt', 1000, 'monthly', 1)")
inc = c.execute("SELECT MAX(id) FROM income").fetchone()[0]
def months_ago(k):
    t = date.today().replace(day=1)
    t = t.replace(year=t.year - (1 if t.month - k <= 0 else 0), month=(t.month - k - 1) % 12 + 1)
    return t.strftime("%Y-%m")
c.execute("INSERT INTO payslips (original_filename, stored_path, detected_month, income_id, review_needed) VALUES ('a.pdf','x','2000-01',?,0)", (inc,))
c.commit()
keys = {i["key"]: i for i in cl.get("/api/month-close").json()["items"]}
check("nur uralte Abrechnung (kein Rhythmus) -> kein Punkt", "payslips" not in keys, True)
c.execute("INSERT INTO income (label, category, amount, frequency, active) VALUES ('Einspeisevergütung', 'Sonstiges', 80, 'monthly', 1)")
einsp = c.execute("SELECT MAX(id) FROM income").fetchone()[0]
for k in (2, 3):
    c.execute("INSERT INTO payslips (original_filename, stored_path, detected_month, income_id, review_needed) VALUES ('e.pdf','e',?,?,0)", (months_ago(k), einsp))
c.execute("INSERT INTO payslips (original_filename, stored_path, detected_month, income_id, review_needed) VALUES ('g1.pdf','g',?,?,0)", (months_ago(3), inc))
c.execute("INSERT INTO payslips (original_filename, stored_path, detected_month, income_id, review_needed) VALUES ('g2.pdf','g',?,?,0)", (months_ago(2), inc))
c.commit()
keys = {i["key"]: i for i in cl.get("/api/month-close").json()["items"]}
check("monatliches Gehalt mit Lücke -> offen mit Namen", (keys["payslips"]["ok"], "Gehalt" in keys["payslips"]["detail"]), (False, True))
check("monatlich eingetragene Einspeisevergütung (Kategorie Sonstiges) wird nie gemahnt", "Einspeisevergütung" not in keys["payslips"]["detail"], True)
c.execute("INSERT INTO payslips (original_filename, stored_path, detected_month, income_id, review_needed) VALUES ('b.pdf','y',?,?,0)", (prev, inc))
c.commit()
keys = {i["key"]: i for i in cl.get("/api/month-close").json()["items"]}
check("Abrechnung des Vormonats -> erledigt", keys["payslips"]["ok"], True)
c.execute("UPDATE bank_accounts SET balance_updated_at=?", ((datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d %H:%M:%S"),)); c.commit()
check("Bank 10 Tage alt -> offen", {i["key"]: i["ok"] for i in cl.get("/api/month-close").json()["items"]}["bank"], False)
c.execute("INSERT INTO meter_readings (meter_type, reading_date, value) VALUES ('gas','2000-01-01',1)"); c.commit()
check("Zählerstand uralt -> offen", {i["key"]: i["ok"] for i in cl.get("/api/month-close").json()["items"]}["meters"], False)

print("== 5) Statuszeile")
c.execute("INSERT INTO pv_daily (key, pv) VALUES ('2026-10-20', 5)"); c.commit()
maintenance.backup_database(mirror_documents=False)
st = cl.get("/api/status-line").json()
check("Bank-Zeitstempel", bool(st["bank"]) and st["has_bank"], True)
check("PV bis", st["pv_until"], "2026-10-20")
check("lokale Sicherung vorhanden", bool(st["backup"]["local"]), True)
check("Statuszeile ohne Bankkonto: has_bank False", (c.execute("UPDATE bank_accounts SET ignored=1") and c.commit() or cl.get("/api/status-line").json())["has_bank"], False)

print()
if FAILS:
    print("✗ FEHLER:", FAILS)
    sys.exit(1)
print("ALLES GRÜN")
