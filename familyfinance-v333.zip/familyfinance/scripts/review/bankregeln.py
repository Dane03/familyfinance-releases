"""Gelernte Bank-Regeln: Empfänger UND Betrag (v333). Ohne Server, Sekunden.
    cd kopie/backend && python3 ../scripts/review/bankregeln.py
Exit-Code 0 = alles grün.

Fälle: Empfänger mit einem Ziel (wie bisher, auch nach Preisänderung), Empfänger mit zwei Zielen
(Betrag entscheidet), nicht eindeutig -> offen, alte Regel ohne Betrag + zweites Ziel, Korrektur,
"Regel vergessen" nur für dieses Ziel, Hinweis "wiederkehrend" je Betragsgruppe, Migration alter Datenbanken.
"""
import sqlite3
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
import bank_matching as bm   # noqa: E402
import database               # noqa: E402

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


def fresh():
    db = sqlite3.connect(":memory:")
    db.row_factory = sqlite3.Row
    db.executescript((Path.cwd() / "schema.sql").read_text(encoding="utf-8"))
    database._migrate_schema(db)              # Spalten aus _COLUMN_MIGRATIONS (wie beim echten Start)
    database._migrate_bank_rules_amount(db)
    db.executescript("""
        INSERT INTO contracts (id, label, amount, source) VALUES (1, 'Haftpflicht', 8.50, 'manuell'),
                                                                 (2, 'Hausrat', 12.00, 'manuell'),
                                                                 (3, 'Strom', 90.00, 'manuell');
        INSERT INTO income (id, label, amount) VALUES (1, 'Anteil Haus', 150), (2, 'Taschengeld-Erstattung', 40);
        INSERT INTO bank_accounts (id, connection_key, iban, label) VALUES (1, 'bank_conn_1', 'DE00', 'Giro');
    """)
    return db


_n = [0]


def tx(db, amount, name="VHV Versicherung", iban="DE89370400440532013000", day="2026-10-01"):
    _n[0] += 1
    cur = db.execute("INSERT INTO bank_transactions (bank_account_id, booking_date, amount, counterparty_name, "
                     "counterparty_iban, tx_hash) VALUES (1, ?, ?, ?, ?, ?)", (day, amount, name, iban, f"h{_n[0]}"))
    return cur.lastrowid


def target(db, tx_id):
    r = db.execute("SELECT contract_id, income_id FROM bank_transactions WHERE id=?", (tx_id,)).fetchone()
    return ("contract", r["contract_id"]) if r["contract_id"] else (("income", r["income_id"]) if r["income_id"] else None)


# ---------- 1) Ein Empfänger, ein Ziel: wie bisher, auch nach Preisänderung ----------
db = fresh()
bm.assign(db, tx(db, -90.00, "Naturwerke", "DE02120300000000202051"), "contract", 3)
t = tx(db, -97.50, "Naturwerke", "DE02120300000000202051", "2026-11-01"); bm.apply_rules(db)
check("1 ein Ziel, neuer Betrag (+8 %) -> trotzdem zugeordnet", target(db, t), ("contract", 3))
t = tx(db, -140.00, "Naturwerke", "DE02120300000000202051", "2026-12-01"); bm.apply_rules(db)
check("1 ein Ziel, ganz anderer Betrag -> trotzdem zugeordnet (wie vor v333)", target(db, t), ("contract", 3))

# ---------- 2) Ein Empfänger (gleiche IBAN), zwei Verträge: Betrag entscheidet ----------
db = fresh()
bm.assign(db, tx(db, -8.50), "contract", 1)
r = bm.assign(db, tx(db, -12.00), "contract", 2)
check("2 zweite Zuordnung überschreibt die erste Regel nicht", db.execute("SELECT COUNT(*) FROM bank_match_rules").fetchone()[0], 2)
a, b = tx(db, -8.50, day="2026-11-01"), tx(db, -12.00, day="2026-11-01"); bm.apply_rules(db)
check("2 8,50 € -> Haftpflicht", target(db, a), ("contract", 1))
check("2 12,00 € -> Hausrat", target(db, b), ("contract", 2))
c = tx(db, -12.60, day="2026-12-01"); bm.apply_rules(db)
check("2 Preiserhöhung Hausrat 12,00 -> 12,60 (5 %) -> Hausrat", target(db, c), ("contract", 2))
d = tx(db, -30.00, day="2026-12-01"); bm.apply_rules(db)
check("2 30 € passt zu keinem -> bleibt offen", target(db, d), None)

# ---------- 3) Nicht eindeutig: gleich weit von beiden Beträgen -> offen ----------
db = fresh()
bm.assign(db, tx(db, -10.00), "contract", 1)
bm.assign(db, tx(db, -11.00), "contract", 2)
e = tx(db, -10.50, day="2026-11-01"); bm.apply_rules(db)
check("3 genau zwischen zwei Beträgen -> offen statt geraten", target(db, e), None)

# ---------- 3b) Zwei Verträge mit sehr ähnlichem Betrag (27,27 / 27,78 €) ----------
db = fresh()
bm.assign(db, tx(db, -27.27, "Barmenia", "DE70330000000000012345"), "contract", 1)
bm.assign(db, tx(db, -27.78, "Barmenia", "DE70330000000000012345"), "contract", 2)
x1, x2, x3 = (tx(db, a, "Barmenia", "DE70330000000000012345", "2026-11-01") for a in (-27.27, -27.78, -27.50))
bm.apply_rules(db)
check("3b exakt 27,27 -> Vertrag 1", target(db, x1), ("contract", 1))
check("3b exakt 27,78 -> Vertrag 2", target(db, x2), ("contract", 2))
check("3b 27,50 (knapp näher an 27,27) -> offen statt geraten", target(db, x3), None)

# ---------- 3c) Per Regel FALSCH zugeordnete Umsätze folgen einer besseren Regel ----------
db = fresh()
z1 = tx(db, -8.50, day="2026-08-01"); bm.assign(db, z1, "contract", 2)          # alte Lage: alles -> Hausrat
z2 = tx(db, -8.50, day="2026-09-01"); bm.apply_rules(db)
check("3c vorher: 8,50 € per Regel bei Hausrat", (target(db, z2), db.execute("SELECT match_source FROM bank_transactions WHERE id=?", (z2,)).fetchone()[0]), (("contract", 2), "rule"))
bm.assign(db, tx(db, -8.50, day="2026-10-01"), "contract", 1)                     # Korrektur: 8,50 € ist Haftpflicht
check("3c per Regel zugeordneter 8,50-€-Umsatz folgt der Korrektur", target(db, z2), ("contract", 1))
check("3c manuelle Zuordnung bleibt unangetastet", target(db, z1), ("contract", 2))
db.execute("UPDATE bank_transactions SET match_source='rule', contract_id=3 WHERE id=?", (z2,))
db.execute("DELETE FROM bank_match_rules")
bm.apply_rules(db)
check("3c ohne passende Regel: bisherige Zuordnung bleibt (nie still auf offen)", target(db, z2), ("contract", 3))

# ---------- 4) Überweisungen derselben Person an zwei Einnahmen ----------
db = fresh()
bm.assign(db, tx(db, 150.00, "Mama", "DE12500105170648489890"), "income", 1)
bm.assign(db, tx(db, 40.00, "Mama", "DE12500105170648489890"), "income", 2)
f, g = tx(db, 150.00, "Mama", "DE12500105170648489890", "2026-11-01"), tx(db, 40.00, "Mama", "DE12500105170648489890", "2026-11-01")
bm.apply_rules(db)
check("4 Mama 150 € -> Anteil Haus", target(db, f), ("income", 1))
check("4 Mama 40 € -> Erstattung", target(db, g), ("income", 2))

# ---------- 5) Alte Regel (vor v333, ohne Betrag) + zweites Ziel ----------
db = fresh()
old_tx = tx(db, -8.50)
db.execute("UPDATE bank_transactions SET contract_id=1, match_source='manual' WHERE id=?", (old_tx,))
db.execute("INSERT INTO bank_match_rules (kind, target_id, match_field, match_value) VALUES ('contract', 1, 'iban', 'DE89370400440532013000')")
h = tx(db, -8.50, day="2026-11-01"); bm.apply_rules(db)
check("5 alte Regel ohne Betrag greift weiter", target(db, h), ("contract", 1))
bm.assign(db, tx(db, -12.00, day="2026-11-01"), "contract", 2)
check("5 alte Regel bekommt beim zweiten Ziel ihren Betrag (8,50 €)",
      db.execute("SELECT amount_cents FROM bank_match_rules WHERE target_id=1").fetchone()[0], 850)
i, j = tx(db, -8.50, day="2026-12-01"), tx(db, -12.00, day="2026-12-01"); bm.apply_rules(db)
check("5 danach 8,50 € -> Haftpflicht", target(db, i), ("contract", 1))
check("5 danach 12,00 € -> Hausrat", target(db, j), ("contract", 2))

# ---------- 6) Korrektur: gleicher Empfänger, gleicher Betrag, anderes Ziel ----------
db = fresh()
bm.assign(db, tx(db, -8.50), "contract", 1)
bm.assign(db, tx(db, -8.50, day="2026-11-01"), "contract", 2)
check("6 Korrektur ersetzt die Regel (keine Doppelregel)",
      [tuple(r) for r in db.execute("SELECT target_id, amount_cents FROM bank_match_rules")], [(2, 850)])

# ---------- 7) "Regel vergessen" nur für dieses Ziel ----------
db = fresh()
k = tx(db, -8.50); bm.assign(db, k, "contract", 1)
bm.assign(db, tx(db, -12.00), "contract", 2)
bm.unassign(db, k, forget_rule=True)
check("7 vergessen entfernt nur Empfänger -> Haftpflicht",
      [r[0] for r in db.execute("SELECT target_id FROM bank_match_rules")], [2])

# ---------- 8) Hinweis "wiederkehrend, kein Vertrag" je Betragsgruppe ----------
db = fresh()
for m in ("2026-07", "2026-08", "2026-09"):
    tx(db, -8.50, "Allianz", "DE44500105175407324931", f"{m}-03")
    tx(db, -23.10, "Allianz", "DE44500105175407324931", f"{m}-05")
rec = bm.recurring_unmapped(db, date(2026, 10, 15))
check("8 zwei Beträge desselben Empfängers -> zwei Hinweise", sorted(r["amount"] for r in rec), [8.5, 23.1])
db = fresh()
for m in ("2026-07", "2026-08"):
    tx(db, -19.99, "Netflix", "DE60500105175896589512", f"{m}-02")
rec = bm.recurring_unmapped(db, date(2026, 10, 15))
check("8 ein Betrag -> Hinweis-Schlüssel unverändert (abgelehnte bleiben abgelehnt)",
      [r["hint_key"] for r in rec], ["recurring:iban:DE60500105175896589512"])

# ---------- 9) Migration einer Datenbank im alten Format ----------
db = sqlite3.connect(":memory:")
db.row_factory = sqlite3.Row
db.executescript("""
    CREATE TABLE bank_match_rules (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, target_id INTEGER NOT NULL,
        match_field TEXT NOT NULL, match_value TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(match_field, match_value));
    INSERT INTO bank_match_rules (kind, target_id, match_field, match_value) VALUES
        ('contract', 1, 'iban', 'DE1'), ('income', 2, 'name', 'mama'), ('contract', 3, 'creditor_mandate', 'X|Y');
""")
database._migrate_bank_rules_amount(db)
database._migrate_bank_rules_amount(db)   # zweiter Start: darf nichts ändern
check("9 alle Regeln übernommen, Ziele unverändert",
      [tuple(r) for r in db.execute("SELECT kind, target_id, match_field, match_value, amount_cents FROM bank_match_rules ORDER BY id")],
      [("contract", 1, "iban", "DE1", None), ("income", 2, "name", "mama", None), ("contract", 3, "creditor_mandate", "X|Y", None)])
db.execute("INSERT INTO bank_match_rules (kind, target_id, match_field, match_value, amount_cents) VALUES ('contract', 2, 'iban', 'DE1', 1200)")
check("9 jetzt erlaubt: gleicher Empfänger, anderer Betrag", db.execute("SELECT COUNT(*) FROM bank_match_rules WHERE match_value='DE1'").fetchone()[0], 2)
try:
    db.execute("INSERT INTO bank_match_rules (kind, target_id, match_field, match_value, amount_cents) VALUES ('contract', 3, 'iban', 'DE1', 1200)")
    dup = "erlaubt"
except sqlite3.IntegrityError:
    dup = "abgelehnt"
check("9 doppelte Regel (Empfänger + gleicher Betrag) wird abgelehnt", dup, "abgelehnt")

# ---------- 10) Umbau lernt aus bisherigen manuellen Zuordnungen (Lage vor v333) ----------
db = fresh()
db.execute("DROP INDEX IF EXISTS idx_bank_rules_key")
db.executescript("""
    DROP TABLE bank_match_rules;
    CREATE TABLE bank_match_rules (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, target_id INTEGER NOT NULL,
        match_field TEXT NOT NULL, match_value TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(match_field, match_value));
""")
# Vor v333: Haftpflicht (8,50) und Hausrat (12,00) manuell zugeordnet -- die Regel zeigt nur noch auf das LETZTE Ziel
for amount, cid, day in ((-8.50, 1, "2026-08-01"), (-12.00, 2, "2026-08-02"), (-8.50, 1, "2026-09-01"), (-12.00, 2, "2026-09-02")):
    t_ = tx(db, amount, day=day)
    db.execute("UPDATE bank_transactions SET contract_id=?, match_source='manual' WHERE id=?", (cid, t_))
db.execute("INSERT INTO bank_match_rules (kind, target_id, match_field, match_value) VALUES ('contract', 2, 'iban', 'DE89370400440532013000')")
database._migrate_bank_rules_amount(db)
database._migrate_bank_rules_amount(db)
check("10 nach Umbau: Regeln je Betrag",
      sorted((r["target_id"], r["amount_cents"]) for r in db.execute("SELECT * FROM bank_match_rules")), [(1, 850), (2, 1200)])
y1, y2 = tx(db, -8.50, day="2026-10-01"), tx(db, -12.00, day="2026-10-02"); bm.apply_rules(db)
check("10 neue 8,50 € -> Haftpflicht (vorher wäre es Hausrat gewesen)", target(db, y1), ("contract", 1))
check("10 neue 12,00 € -> Hausrat", target(db, y2), ("contract", 2))

print()
if FAILS:
    print(f"✗ {len(FAILS)} Abweichung(en): {', '.join(FAILS)}")
    sys.exit(1)
print("✓ Bank-Regeln: alle Fälle stimmen")
