"""
Mehrseitiger PDF-Report — Überblick, Diagramme, Einnahmen, Ausgaben im Detail
und anstehende Fälligkeiten. Läuft komplett lokal (reportlab), kein Cloud-Aufruf.

Layout-Grundsätze (nach den Lesbarkeitsproblemen der ersten Fassung):
- Alle Textzellen sind Paragraphs -> brechen sauber um statt zu überlappen
- Spaltenbreiten summieren sich exakt auf die nutzbare Seitenbreite
- Zahlen rechtsbündig, Text linksbündig
- Diagramme geben einen schnellen visuellen Überblick vor den Detailtabellen
"""
import io
import json
from datetime import datetime
from xml.sax.saxutils import escape as _xml_escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether,
)
from reportlab.graphics.shapes import Drawing, String, Rect
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.pdfgen import canvas as pdfcanvas

from database import get_connection
import meters as meters_module

ACCENT = colors.HexColor("#0f172a")
GOOD = colors.HexColor("#166534")
BAD = colors.HexColor("#991b1b")
GRID = colors.HexColor("#d8dee9")
ZEBRA = colors.HexColor("#f7f9fc")

# Farbpalette für Diagramme — bewusst gut unterscheidbar, auch bei S/W-Druck
CHART_COLORS = [
    colors.HexColor("#0ea5e9"), colors.HexColor("#f59e0b"), colors.HexColor("#10b981"),
    colors.HexColor("#8b5cf6"), colors.HexColor("#ef4444"), colors.HexColor("#14b8a6"),
    colors.HexColor("#f97316"), colors.HexColor("#6366f1"), colors.HexColor("#84cc16"),
    colors.HexColor("#ec4899"), colors.HexColor("#64748b"), colors.HexColor("#0891b2"),
]

FREQ_LABEL = {"monthly": "monatlich", "quarterly": "quartalsweise", "yearly": "jährlich"}
# reportlabs Standardschriften (Helvetica) stellen das Unicode-Zeichen "³"
# nicht dar (rendert als Leerzeichen) — deshalb hier als <super>-Auszeichnung.
METER_UNIT_PDF = {"m³": "m<super>3</super>", "kWh": "kWh"}

PAGE_WIDTH = A4[0] - 3 * cm  # linker + rechter Rand je 1,5 cm


def _fmt_eur(value) -> str:
    if value is None:
        return "–"
    return f"{value:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")


def _monthly_equiv(amount: float, frequency: str) -> float:
    if frequency == "quarterly":
        return amount / 3.0
    if frequency == "yearly":
        return amount / 12.0
    return amount


class _NumberedCanvas(pdfcanvas.Canvas):
    """Fügt jeder Seite unten eine Seitenzahl "Seite X von Y" hinzu."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_pages = []

    def showPage(self):
        self._saved_pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved_pages)
        for state in self._saved_pages:
            self.__dict__.update(state)
            self.setFont("Helvetica", 8)
            self.setFillColor(colors.grey)
            self.drawRightString(
                A4[0] - 1.5 * cm, 1 * cm,
                f"Seite {self._pageNumber} von {total} · Family Finance",
            )
            super().showPage()
        super().save()


# ---------------- Textbausteine ----------------

_styles = getSampleStyleSheet()
CELL = ParagraphStyle("Cell", parent=_styles["Normal"], fontSize=8.5, leading=10.5)
CELL_RIGHT = ParagraphStyle("CellRight", parent=CELL, alignment=TA_RIGHT)
CELL_HEAD = ParagraphStyle("CellHead", parent=CELL, textColor=colors.white,
                           fontName="Helvetica-Bold")
CELL_HEAD_RIGHT = ParagraphStyle("CellHeadRight", parent=CELL_HEAD, alignment=TA_RIGHT)


def _p(text, right=False):
    return Paragraph(str(text if text is not None else "–"), CELL_RIGHT if right else CELL)


def _pe(text, right=False):
    """Wie _p, aber für Daten aus der Datenbank: escaped Sonderzeichen wie & oder <,
    die sonst als XML-Markup interpretiert würden (z.B. 'Tagesgeld R&B')."""
    safe = _xml_escape(str(text)) if text is not None else "–"
    return Paragraph(safe, CELL_RIGHT if right else CELL)


def _h(text, right=False):
    return Paragraph(str(text), CELL_HEAD_RIGHT if right else CELL_HEAD)


def _table(rows, col_widths, right_cols=()):
    """rows: Liste von Listen bereits fertiger Paragraphs/Strings."""
    t = Table(rows, colWidths=col_widths, repeatRows=1)
    style = [
        ("GRID", (0, 0), (-1, -1), 0.4, GRID),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, ZEBRA]),
        ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    t.setStyle(TableStyle(style))
    return t


# ---------------- Diagramme ----------------

def _legend_swatch(color, label, value, width):
    """Eine Legendenzeile als Mini-Tabelle: Farbfeld + Text + Wert."""
    box = Drawing(8, 8)
    box.add(Rect(0, 0, 8, 8, fillColor=color, strokeColor=None))
    return [box, _pe(label), _p(value, right=True)]


def _pie_chart(data, labels, title):
    """Kuchendiagramm mit Legende daneben (Legende als Tabelle -> bricht sauber um)."""
    d = Drawing(7.5 * cm, 7.5 * cm)
    pie = Pie()
    pie.x = 0.6 * cm
    pie.y = 0.6 * cm
    pie.width = 6.2 * cm
    pie.height = 6.2 * cm
    pie.data = data
    pie.labels = None  # Beschriftung läuft über die Legende, sonst überlappt es
    pie.slices.strokeWidth = 0.5
    pie.slices.strokeColor = colors.white
    for i in range(len(data)):
        pie.slices[i].fillColor = CHART_COLORS[i % len(CHART_COLORS)]
    d.add(pie)

    total = sum(data) or 1
    legend_rows = []
    for i, (label, value) in enumerate(zip(labels, data)):
        share = value / total * 100
        legend_rows.append(_legend_swatch(
            CHART_COLORS[i % len(CHART_COLORS)], label,
            f"{_fmt_eur(value)} ({share:.0f} %)", 0,
        ))
    legend = Table(legend_rows, colWidths=[0.6 * cm, 5.4 * cm, 3.6 * cm])
    legend.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LEFTPADDING", (0, 0), (-1, -1), 2),
    ]))

    layout = Table([[d, legend]], colWidths=[7.6 * cm, 9.6 * cm])
    layout.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    return layout


def _income_expense_bar(income, fixed, savings):
    """Balkendiagramm Einnahmen vs. Ausgaben (Fixkosten + Sparen)."""
    d = Drawing(PAGE_WIDTH, 6.5 * cm)
    chart = VerticalBarChart()
    chart.x = 2.2 * cm
    chart.y = 1.2 * cm
    chart.height = 4.6 * cm
    chart.width = PAGE_WIDTH - 3.2 * cm
    chart.data = [[income, fixed, savings]]
    chart.categoryAxis.categoryNames = ["Einnahmen", "Fixkosten", "Sparen"]
    chart.categoryAxis.labels.fontSize = 9
    chart.categoryAxis.labels.dy = -4
    chart.valueAxis.valueMin = 0
    chart.valueAxis.labels.fontSize = 8
    chart.barWidth = 0.5 * cm
    chart.groupSpacing = 2.2 * cm
    chart.bars[0].strokeColor = None
    # Einzelfarben je Balken
    chart.bars[(0, 0)].fillColor = colors.HexColor("#10b981")   # Einnahmen grün
    chart.bars[(0, 1)].fillColor = colors.HexColor("#ef4444")   # Fixkosten rot
    chart.bars[(0, 2)].fillColor = colors.HexColor("#0ea5e9")   # Sparen blau
    chart.barLabels.fontSize = 8.5
    chart.barLabelFormat = lambda v: _fmt_eur(v)
    chart.barLabels.dy = 8
    d.add(chart)
    return d


def _consumption_bar(months, values, unit, color):
    """Balkendiagramm Monatsverbrauch — gleicher Aufbau wie der Einnahmen/
    Ausgaben-Chart, nur mit variabler Anzahl Monate statt fixer 3 Balken."""
    d = Drawing(PAGE_WIDTH, 6 * cm)
    chart = VerticalBarChart()
    chart.x = 1.6 * cm
    chart.y = 1.4 * cm
    chart.height = 4.0 * cm
    chart.width = PAGE_WIDTH - 2.4 * cm
    chart.data = [values]
    chart.categoryAxis.categoryNames = months
    chart.categoryAxis.labels.fontSize = 7.5
    chart.categoryAxis.labels.dy = -4
    chart.categoryAxis.labels.angle = 45
    chart.categoryAxis.labels.boxAnchor = "ne"
    chart.valueAxis.valueMin = 0
    chart.valueAxis.labels.fontSize = 8
    chart.barWidth = 0.7 * cm
    chart.groupSpacing = 0.3 * cm
    chart.bars[0].strokeColor = None
    chart.bars[0].fillColor = color
    chart.barLabels.fontSize = 7
    chart.barLabelFormat = lambda v: f"{v:.0f}"
    chart.barLabels.dy = 6
    d.add(chart)
    return d


# ---------------- Report ----------------

def generate_report_pdf() -> bytes:
    conn = get_connection()
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleCustom", parent=styles["Title"], textColor=ACCENT)
    subtitle = ParagraphStyle("Subtitle", parent=styles["Normal"], fontSize=11,
                              textColor=colors.HexColor("#475569"), spaceBefore=6)
    h2 = ParagraphStyle("H2Custom", parent=styles["Heading2"], textColor=ACCENT,
                        spaceBefore=16, spaceAfter=8, fontSize=14)
    h3 = ParagraphStyle("H3Custom", parent=styles["Heading3"], textColor=ACCENT,
                        spaceBefore=12, spaceAfter=5, fontSize=11)
    normal = styles["Normal"]
    muted = ParagraphStyle("Muted", parent=styles["Normal"], textColor=colors.grey, fontSize=9)

    story = []

    # ---------- Kennzahlen berechnen ----------
    monthly_income = conn.execute(
        "SELECT COALESCE(SUM(CASE frequency WHEN 'monthly' THEN amount "
        "WHEN 'quarterly' THEN amount/3.0 WHEN 'yearly' THEN amount/12.0 END),0) AS v "
        "FROM income WHERE active=1"
    ).fetchone()["v"]

    fixed_expenses = conn.execute(
        "SELECT COALESCE(SUM(CASE co.frequency WHEN 'monthly' THEN co.amount*co.split_share "
        "WHEN 'quarterly' THEN co.amount*co.split_share/3.0 "
        "WHEN 'yearly' THEN co.amount*co.split_share/12.0 END),0) AS v "
        "FROM contracts co LEFT JOIN categories c ON c.id=co.category_id "
        "WHERE co.status='active' AND (c.name IS NULL OR c.name != 'Sparen')"
    ).fetchone()["v"]

    savings = conn.execute(
        "SELECT COALESCE(SUM(CASE co.frequency WHEN 'monthly' THEN co.amount*co.split_share "
        "WHEN 'quarterly' THEN co.amount*co.split_share/3.0 "
        "WHEN 'yearly' THEN co.amount*co.split_share/12.0 END),0) AS v "
        "FROM contracts co LEFT JOIN categories c ON c.id=co.category_id "
        "WHERE co.status='active' AND c.name = 'Sparen'"
    ).fetchone()["v"]

    surplus_after_fixed = monthly_income - fixed_expenses
    surplus_after_savings = surplus_after_fixed - savings

    # ---------- Titelseite ----------
    story.append(Spacer(1, 3.5 * cm))
    story.append(Paragraph("Family Finance Report", title_style))
    story.append(Paragraph(datetime.now().strftime("Stand: %d.%m.%Y, %H:%M Uhr"), subtitle))
    story.append(Spacer(1, 1.2 * cm))

    # Kernaussage direkt auf die Titelseite
    highlight = [
        [_h("Monatlicher Überblick"), _h("Betrag", right=True)],
        [_p("Einnahmen"), _p(_fmt_eur(monthly_income), right=True)],
        [_p("Fixkosten (ohne Sparen)"), _p(_fmt_eur(fixed_expenses), right=True)],
        [_p("Sparen"), _p(_fmt_eur(savings), right=True)],
        [_p("<b>Überschuss nach Fixkosten</b>"),
         _p(f"<b>{_fmt_eur(surplus_after_fixed)}</b>", right=True)],
        [_p("<b>Überschuss nach Sparen</b>"),
         _p(f"<b>{_fmt_eur(surplus_after_savings)}</b>", right=True)],
    ]
    t = _table(highlight, [PAGE_WIDTH * 0.62, PAGE_WIDTH * 0.38])
    t.setStyle(TableStyle([
        ("TEXTCOLOR", (1, 4), (1, 4), GOOD if surplus_after_fixed >= 0 else BAD),
        ("TEXTCOLOR", (1, 5), (1, 5), GOOD if surplus_after_savings >= 0 else BAD),
        ("LINEABOVE", (0, 4), (-1, 4), 1, ACCENT),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.8 * cm))
    story.append(Paragraph(
        "Erstellt mit Family Finance — alle Daten liegen lokal auf dem eigenen Rechner.",
        muted))
    story.append(PageBreak())

    # ---------- Diagramme ----------
    story.append(Paragraph("Auf einen Blick", h2))
    story.append(Paragraph("Einnahmen gegenüber Fixkosten und Sparen", h3))
    story.append(_income_expense_bar(monthly_income, fixed_expenses, savings))

    by_category = conn.execute(
        "SELECT c.name AS category, co.subcategory, "
        "SUM(CASE co.frequency WHEN 'monthly' THEN co.amount*co.split_share "
        "WHEN 'quarterly' THEN co.amount*co.split_share/3.0 "
        "WHEN 'yearly' THEN co.amount*co.split_share/12.0 END) AS monthly_amount "
        "FROM contracts co LEFT JOIN categories c ON c.id=co.category_id "
        "WHERE co.status='active' GROUP BY c.name, co.subcategory "
        "HAVING monthly_amount > 0 ORDER BY monthly_amount DESC"
    ).fetchall()

    if by_category:
        story.append(Paragraph("Verteilung der Ausgaben nach Kategorie", h3))
        # Bei sehr vielen Kategorien die kleinsten zu "Sonstige" zusammenfassen,
        # sonst wird das Kuchendiagramm unleserlich.
        MAX_SLICES = 9
        labels, values = [], []
        for r in by_category:
            name = r["category"] or "Ohne Kategorie"
            if r["subcategory"]:
                name += f" · {r['subcategory']}"
            labels.append(name)
            values.append(round(r["monthly_amount"], 2))
        if len(values) > MAX_SLICES:
            rest = sum(values[MAX_SLICES:])
            labels = labels[:MAX_SLICES] + ["Weitere"]
            values = values[:MAX_SLICES] + [round(rest, 2)]
        story.append(_pie_chart(values, labels, "Ausgabenverteilung"))

    story.append(PageBreak())

    # ---------- Einnahmen im Detail ----------
    story.append(Paragraph("Einnahmen im Detail", h2))
    income_rows = conn.execute("SELECT * FROM income ORDER BY amount DESC").fetchall()
    if income_rows:
        widths = [PAGE_WIDTH * 0.40, PAGE_WIDTH * 0.18, PAGE_WIDTH * 0.24, PAGE_WIDTH * 0.18]
        data = [[_h("Bezeichnung"), _h("Betrag", right=True), _h("Zahlungsweise"),
                 _h("€ / Monat", right=True)]]
        for r in income_rows:
            monthly = _monthly_equiv(r["amount"], r["frequency"])
            label = r["label"] + ("" if r["active"] else " (inaktiv)")
            data.append([
                _pe(label), _p(_fmt_eur(r["amount"]), right=True),
                _p(FREQ_LABEL.get(r["frequency"], r["frequency"])),
                _p(_fmt_eur(monthly), right=True),
            ])
        total_income = sum(_monthly_equiv(r["amount"], r["frequency"]) for r in income_rows if r["active"])
        data.append([_p("<b>Summe / Monat</b>"), _p(""), _p(""),
                     _p(f"<b>{_fmt_eur(total_income)}</b>", right=True)])
        t = _table(data, widths)
        t.setStyle(TableStyle([("LINEABOVE", (0, -1), (-1, -1), 1, ACCENT)]))
        story.append(t)
    else:
        story.append(Paragraph("Keine Einnahmen erfasst.", normal))

    story.append(PageBreak())

    # ---------- Ausgaben im Detail ----------
    story.append(Paragraph("Ausgaben im Detail", h2))
    contracts = conn.execute(
        "SELECT co.*, c.name AS category_name FROM contracts co "
        "LEFT JOIN categories c ON c.id=co.category_id "
        "WHERE co.status='active' ORDER BY c.name, co.subcategory, co.amount DESC"
    ).fetchall()

    groups = {}
    for c in contracts:
        key = c["category_name"] or "Ohne Kategorie"
        if c["subcategory"]:
            key += f" · {c['subcategory']}"
        groups.setdefault(key, []).append(c)

    def _group_sum(items):
        return sum(_monthly_equiv(i["amount"], i["frequency"]) * (i["split_share"] or 1.0)
                   for i in items)

    grand_total = 0.0
    # Spalten ohne "Quelle" (im Report ohne Mehrwert), dafür mehr Platz für die Bezeichnung
    widths = [PAGE_WIDTH * 0.34, PAGE_WIDTH * 0.19, PAGE_WIDTH * 0.13,
              PAGE_WIDTH * 0.13, PAGE_WIDTH * 0.21]

    for group_name, items in sorted(groups.items(), key=lambda kv: _group_sum(kv[1]), reverse=True):
        gsum = _group_sum(items)
        grand_total += gsum

        # Kategoriename ist Zeile 0 der Tabelle (nicht separate Überschrift) —
        # so wird er zusammen mit dem Spaltenkopf auf Folgeseiten wiederholt und
        # eine über zwei Seiten laufende Kategorie bleibt zuordenbar.
        group_header = Paragraph(
            f"<b>{_xml_escape(group_name)} — {_fmt_eur(gsum)}/Monat</b>",
            ParagraphStyle("GroupHead", parent=CELL, fontSize=10.5, leading=13,
                           textColor=colors.white),
        )
        data = [
            [group_header, "", "", "", ""],
            [_h("Bezeichnung"), _h("Vertragsnr."), _h("Betrag", right=True),
             _h("€ / Monat", right=True), _h("Zahlweise / fällig")],
        ]
        for c in sorted(items, key=lambda i: _monthly_equiv(i["amount"], i["frequency"]), reverse=True):
            monthly = _monthly_equiv(c["amount"], c["frequency"]) * (c["split_share"] or 1.0)
            freq_and_due = FREQ_LABEL.get(c["frequency"], c["frequency"])
            if c["contract_end"]:
                freq_and_due += f"<br/>bis {_xml_escape(str(c['contract_end']))}"
            label_cell = _xml_escape(c["label"] or "–")
            if c["provider"]:
                label_cell += f"<br/><font size=7 color='#64748b'>{_xml_escape(c['provider'])}</font>"
            data.append([
                Paragraph(label_cell, CELL),
                _pe(c["contract_number"] or "–"),
                _p(_fmt_eur(c["amount"]), right=True),
                _p(_fmt_eur(monthly), right=True),
                _p(freq_and_due),
            ])

        t = Table(data, colWidths=widths, repeatRows=2)
        t.setStyle(TableStyle([
            ("GRID", (0, 1), (-1, -1), 0.4, GRID),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("ROWBACKGROUNDS", (0, 2), (-1, -1), [colors.white, ZEBRA]),
            ("SPAN", (0, 0), (-1, 0)),
            ("BACKGROUND", (0, 0), (-1, 1), ACCENT),
            ("LINEBELOW", (0, 0), (-1, 0), 0.6, colors.HexColor("#334155")),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(t)
        story.append(Spacer(1, 12))

    story.append(Spacer(1, 4))
    total_table = _table(
        [[_h("Summe aller Ausgaben"), _h(f"{_fmt_eur(grand_total)} / Monat", right=True)]],
        [PAGE_WIDTH * 0.62, PAGE_WIDTH * 0.38],
    )
    story.append(total_table)

    # ---------- Fälligkeiten ----------
    story.append(PageBreak())
    story.append(Paragraph("Fälligkeiten, Vertragsabläufe & Anschlussfinanzierung", h2))
    reminders = conn.execute(
        "SELECT r.trigger_date, r.message FROM reminders r WHERE r.sent=0 "
        "ORDER BY r.trigger_date ASC"
    ).fetchall()
    if reminders:
        data = [[_h("Datum"), _h("Hinweis")]]
        for r in reminders:
            data.append([_p(r["trigger_date"]), _pe(r["message"])])
        story.append(_table(data, [PAGE_WIDTH * 0.18, PAGE_WIDTH * 0.82]))
    else:
        story.append(Paragraph("Keine anstehenden Fälligkeiten.", normal))

    conn.close()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=1.5 * cm, rightMargin=1.5 * cm, topMargin=1.5 * cm, bottomMargin=1.8 * cm,
        title="Family Finance Finanzreport", author="Family Finance",
    )
    doc.build(story, canvasmaker=_NumberedCanvas)
    return buffer.getvalue()


def generate_energy_report_pdf() -> bytes:
    """Eigenständiger Energy-Monitor-Report — Gas, Strombezug, Einspeisung.
    Nur relevant, wenn das Energy-Monitor-Modul aktiviert ist und Zähler-
    daten vorliegen; sonst wirft diese Funktion (Prüfung liegt beim Aufrufer/
    Endpunkt, siehe app.py)."""
    conn = get_connection()
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleCustom", parent=styles["Title"], textColor=ACCENT)
    subtitle = ParagraphStyle("Subtitle", parent=styles["Normal"], fontSize=11,
                              textColor=colors.HexColor("#475569"), spaceBefore=6)
    h2 = ParagraphStyle("H2Custom", parent=styles["Heading2"], textColor=ACCENT,
                        spaceBefore=16, spaceAfter=8, fontSize=14)
    h3 = ParagraphStyle("H3Custom", parent=styles["Heading3"], textColor=ACCENT,
                        spaceBefore=12, spaceAfter=5, fontSize=11)
    normal = styles["Normal"]
    muted = ParagraphStyle("Muted", parent=styles["Normal"], textColor=colors.grey, fontSize=9)

    story = []
    meter_colors = {
        "gas": colors.HexColor("#f97316"), "elec_in": colors.HexColor("#0ea5e9"),
        "elec_out": colors.HexColor("#10b981"), "water": colors.HexColor("#38bdf8"),
    }

    # ---------- Daten laden ----------
    readings_by_type, settings_by_type, any_meter_data = {}, {}, False
    for meter_type in meters_module.METER_TYPES:
        readings = [dict(r) for r in conn.execute(
            "SELECT reading_date, value, is_new_meter FROM meter_readings "
            "WHERE meter_type=? ORDER BY reading_date ASC", (meter_type,),
        ).fetchall()]
        readings_by_type[meter_type] = readings
        if readings:
            any_meter_data = True
        settings_row = conn.execute(
            "SELECT value FROM settings WHERE key=?", (f"meter_settings_{meter_type}",),
        ).fetchone()
        settings_by_type[meter_type] = {
            **meters_module.DEFAULT_SETTINGS.get(meter_type, {}),
            **(json.loads(settings_row["value"]) if settings_row else {}),
        }

    pv_monthly = [dict(r) for r in conn.execute(
        "SELECT key, pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_monthly ORDER BY key"
    ).fetchall()]

    overview = meters_module.compute_overview_cards(readings_by_type, settings_by_type, pv_monthly, "ytd")
    settlement = meters_module.compute_full_settlement(readings_by_type, settings_by_type, pv_monthly)

    # ---------- Titelseite ----------
    story.append(Spacer(1, 3.5 * cm))
    story.append(Paragraph("Energy Monitor Report", title_style))
    story.append(Paragraph(datetime.now().strftime("Stand: %d.%m.%Y, %H:%M Uhr"), subtitle))
    story.append(Spacer(1, 1.2 * cm))

    highlight = [
        [_h("Aktuelles Jahr"), _h("Verbrauch", right=True), _h("Kosten/Erlös", right=True)],
        [_p("Gas"), _p(f"{overview['gas']['kwh']:.0f} kWh", right=True), _p(_fmt_eur(overview['gas']['kosten']), right=True)],
        [_p("Strombezug"), _p(f"{overview['elec_in']['kwh']:.0f} kWh", right=True), _p(_fmt_eur(overview['elec_in']['kosten']), right=True)],
        [_p("Einspeisung"), _p(f"{overview['elec_out']['kwh']:.0f} kWh", right=True), _p(_fmt_eur(overview['elec_out']['erloes']), right=True)],
        [_p("PV-Ertrag"), _p(f"{overview['pv']['kwh']:.0f} kWh", right=True), _p("–", right=True)],
        [_p("<b>Gesamt (Gas + Bezug − Einspeisung)</b>"),
         _p(""), _p(f"<b>{'+' if settlement['total_diff'] >= 0 else ''}{settlement['total_diff']:.0f} €</b>", right=True)],
    ]
    t = _table(highlight, [PAGE_WIDTH * 0.44, PAGE_WIDTH * 0.28, PAGE_WIDTH * 0.28])
    t.setStyle(TableStyle([
        ("TEXTCOLOR", (2, 5), (2, 5), GOOD if settlement["total_diff"] >= 0 else BAD),
        ("LINEABOVE", (0, 5), (-1, 5), 1, ACCENT),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.8 * cm))
    story.append(Paragraph(
        "Erstellt mit Family Finance — alle Daten liegen lokal auf dem eigenen Rechner.",
        muted))
    story.append(PageBreak())

    # ---------- Jahresabrechnung ----------
    story.append(Paragraph(f"Jahresabrechnung {settlement['year']}", h2))
    settle_rows = [[_h("Zähler"), _h("Gezahlt", right=True), _h("Progn. Jahreskosten", right=True), _h("Differenz", right=True)]]
    settle_rows.append([
        _p("Gas"), _p(_fmt_eur(settlement["gas"]["abschlaege"]), right=True),
        _p(_fmt_eur(settlement["gas"]["jahr_kosten"]), right=True),
        _p(f"{'+' if settlement['gas']['diff'] >= 0 else ''}{settlement['gas']['diff']:.0f} €", right=True),
    ])
    settle_rows.append([
        _p("Strombezug"), _p(_fmt_eur(settlement["elec_in"]["abschlaege"]), right=True),
        _p(_fmt_eur(settlement["elec_in"]["jahr_kosten"]), right=True),
        _p(f"{'+' if settlement['elec_in']['diff'] >= 0 else ''}{settlement['elec_in']['diff']:.0f} €", right=True),
    ])
    settle_rows.append([
        _p("Einspeisung"), _p(_fmt_eur(settlement["elec_out"]["bezahlt"]), right=True),
        _p(_fmt_eur(settlement["elec_out"]["jahr_erloes"]), right=True),
        _p(f"{'+' if settlement['elec_out']['diff'] >= 0 else ''}{settlement['elec_out']['diff']:.0f} €", right=True),
    ])
    settle_table = _table(settle_rows, [PAGE_WIDTH * 0.28, PAGE_WIDTH * 0.24, PAGE_WIDTH * 0.24, PAGE_WIDTH * 0.24])
    settle_table.setStyle(TableStyle([
        ("TEXTCOLOR", (3, 1), (3, 1), GOOD if settlement["gas"]["diff"] >= 0 else BAD),
        ("TEXTCOLOR", (3, 2), (3, 2), GOOD if settlement["elec_in"]["diff"] >= 0 else BAD),
        ("TEXTCOLOR", (3, 3), (3, 3), GOOD if settlement["elec_out"]["diff"] >= 0 else BAD),
    ]))
    story.append(settle_table)

    def _de_date(iso: str) -> str:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m.%Y")

    story.append(Paragraph(
        f"Nächste Abrechnungen: Gas {_de_date(settlement['gas']['settle_date'])} (in {settlement['gas']['days_until_settle']} "
        f"Tagen) · Strombezug {_de_date(settlement['elec_in']['settle_date'])} (in {settlement['elec_in']['days_until_settle']} "
        f"Tagen) · Einspeisung {_de_date(settlement['elec_out']['settle_date'])} (in {settlement['elec_out']['days_until_settle']} Tagen).",
        muted,
    ))

    # ---------- Pro Zähler: Verbrauch je Monat ----------
    energy_story = []
    for meter_type in meters_module.METER_TYPES:
        readings = readings_by_type[meter_type]
        has_pv_data = meter_type in ("elec_in", "elec_out") and bool(pv_monthly)
        if not readings and not has_pv_data:
            continue
        meta = meters_module.METER_META[meter_type]
        unit = meta["unit"]
        unit_pdf = METER_UNIT_PDF.get(unit, unit)
        settings_ = settings_by_type[meter_type]
        meter_settlement = meters_module.compute_settlement(meter_type, readings, settings_, pv_monthly)
        monthly = meters_module.get_effective_monthly(meter_type, readings, pv_monthly)
        rate = meters_module.current_daily_rate_with_pv(meter_type, readings, pv_monthly)

        block = [Paragraph(meta['label'], h3)]
        stat_rows = [
            [_h("Aktuelle Tagesrate"), _h(f"Verbrauch {meter_settlement['year']}", right=True),
             _h(meter_settlement['diff'] >= 0 and "Voraussichtliches Guthaben" or "Voraussichtliche Nachzahlung", right=True)],
            [_p(f"{rate:.2f} {unit_pdf}/Tag" if rate is not None else "–"),
             _p(f"{meter_settlement['total_consumption_this_year']:.0f} {unit_pdf}", right=True),
             _p(_fmt_eur(abs(meter_settlement['diff'])), right=True)],
        ]
        stat_table = _table(stat_rows, [PAGE_WIDTH / 3] * 3)
        stat_table.setStyle(TableStyle([
            ("TEXTCOLOR", (2, 1), (2, 1), GOOD if meter_settlement["diff"] >= 0 else BAD),
        ]))
        block.append(stat_table)
        block.append(Spacer(1, 0.4 * cm))

        months_sorted = sorted(monthly.keys())[-12:]
        if months_sorted:
            short_labels = [m[2:].replace("-", "/") for m in months_sorted]
            values = [round(monthly[m], 1) for m in months_sorted]
            block.append(_consumption_bar(short_labels, values, unit, meter_colors.get(meter_type, ACCENT)))
        block.append(Spacer(1, 0.6 * cm))
        energy_story.append(KeepTogether(block))

    if any_meter_data:
        story.append(PageBreak())
        story.append(Paragraph("Verbrauch je Monat", h2))
        story.append(Paragraph(
            "Helle Hochrechnung für Monate ohne echte Ablesung nicht gesondert markiert — "
            "siehe App für Details.", muted,
        ))
        story.extend(energy_story)

    conn.close()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=1.5 * cm, rightMargin=1.5 * cm, topMargin=1.5 * cm, bottomMargin=1.8 * cm,
        title="Family Finance Energy Monitor Report", author="Family Finance",
    )
    doc.build(story, canvasmaker=_NumberedCanvas)
    return buffer.getvalue()
