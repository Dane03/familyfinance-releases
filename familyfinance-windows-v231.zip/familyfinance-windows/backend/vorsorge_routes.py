"""
Vorsorge — Rentenkonten, Vorsorge-Dokumente, Personen-Dokumente sowie die
Auswertungen zu Versorgungslücke (Rente) und Risikoabsicherung.

Aus app.py herausgelöst, um die zentrale Datei überschaubar zu halten. Die
Routen sind unverändert übernommen und werden über einen APIRouter in app.py
eingebunden — die URLs bleiben exakt dieselben wie vorher.
"""
import hashlib
import json
import re
import shutil
from datetime import date, datetime
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

import auth
import vorsorge
from database import get_connection
from shared_helpers import monthly_expr

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent
# Auch in receipts_routes.py/energy_routes.py definiert -- bewusst als
# eigenständige, gleiche Definition statt eines Imports, um einen
# Zirkelbezug zwischen den Modulen zu vermeiden.
SMART_IMPORT_STAGING = BASE_DIR / "data" / "smart_import_staging"

class PensionAccountIn(BaseModel):
    person_id: int
    type: str                       # 'gesetzlich' | 'privat'
    label: str
    provider: Optional[str] = None
    current_value: Optional[float] = None
    is_riester: Optional[bool] = False
    monthly_contribution: Optional[float] = None
    linked_contract_id: Optional[int] = None
    projected_monthly_at_67: Optional[float] = None
    disability_pension_monthly: Optional[float] = None
    return_rate_assumption: Optional[float] = None
    note: Optional[str] = None
    document_staging_id: Optional[str] = None
    document_original_filename: Optional[str] = None


class PensionAccountPatch(BaseModel):
    label: Optional[str] = None
    provider: Optional[str] = None
    current_value: Optional[float] = None
    is_riester: Optional[bool] = None
    monthly_contribution: Optional[float] = None
    linked_contract_id: Optional[int] = None
    projected_monthly_at_67: Optional[float] = None
    disability_pension_monthly: Optional[float] = None
    return_rate_assumption: Optional[float] = None
    note: Optional[str] = None
    # Kein echtes Datenbankfeld -- wird unten herausgenommen, bevor das
    # generische UPDATE gebaut wird. Ermöglicht, beim Bearbeiten eines
    # BESTEHENDEN Kontos einen per analyze-document zwischengespeicherten
    # Beleg anzuhängen (vorher ging das nur beim Neuanlegen).
    document_staging_id: Optional[str] = None
    document_original_filename: Optional[str] = None


PENSION_DOCS_DIR = BASE_DIR / "data" / "pension_docs"


@router.post("/api/pension-accounts/analyze-document")
async def analyze_pension_document(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    """Liest einen hochgeladenen Beleg (Renteninformation, Depotauszug, ...)
    und schlägt einen monatlichen Rentenwert vor — VOR dem Anlegen eines
    Kontos, damit das Formular direkt vorausgefüllt werden kann. Der
    Vorschlag muss im Formular noch bestätigt werden, wird nie blind
    übernommen."""
    from ocr import extract_pension_document_data
    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    content = await file.read()
    ext = Path(file.filename or "dokument.pdf").suffix or ".pdf"
    staging_id = f"pension_{hashlib.sha256(content).hexdigest()[:16]}{ext}"
    staging_path = SMART_IMPORT_STAGING / staging_id
    staging_path.write_bytes(content)

    result = extract_pension_document_data(staging_path)
    return {
        "staging_id": staging_id,
        "original_filename": file.filename,
        "suggested_monthly_amount": result["suggested_monthly_amount"],
        "all_amounts_found": result["all_amounts_found"],
        "provider": result["provider"],
        "ocr_error": result["ocr_error"],
    }


def _attach_staged_pension_document(conn, account_id: int, staging_id: str, original_filename: Optional[str]):
    """Verschiebt eine per analyze-document zwischengespeicherte Datei zum
    fertig angelegten Rentenkonto — gleiche Idee wie beim Belege-Import:
    erst analysieren/anzeigen, dann erst nach Bestätigung endgültig ablegen.
    Fügt der Dokument-Zeitreihe einen neuen Eintrag hinzu, statt ein
    eventuell vorhandenes Dokument zu ersetzen."""
    if not re.match(r"^pension_[0-9a-f]{16}\.\w+$", staging_id):
        raise HTTPException(400, "Ungültige Zwischenspeicher-Kennung.")
    staging_path = SMART_IMPORT_STAGING / staging_id
    if not staging_path.exists():
        raise HTTPException(404, "Zwischengespeicherte Datei nicht gefunden — bitte erneut hochladen.")
    PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    content = staging_path.read_bytes()
    safe_name = re.sub(r"[^\w.-]", "_", original_filename or "dokument")[:80]
    stored_name = f"{account_id}_{staging_id[8:18]}_{safe_name}"
    stored_path = PENSION_DOCS_DIR / stored_name
    stored_path.write_bytes(content)
    staging_path.unlink(missing_ok=True)
    conn.execute(
        "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
        (account_id, original_filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest()),
    )


@router.get("/api/pension-accounts")
def list_pension_accounts(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        """SELECT pa.*, f.name AS person_name
           FROM pension_accounts pa JOIN family_members f ON f.id = pa.person_id
           ORDER BY f.sort_order, pa.type DESC, pa.label"""
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.post("/api/pension-accounts")
def create_pension_account(payload: PensionAccountIn, session=Depends(auth.require_full_auth)):
    if payload.type not in ("gesetzlich", "privat"):
        raise HTTPException(400, "type muss 'gesetzlich' oder 'privat' sein.")
    conn = get_connection()
    person = conn.execute("SELECT id FROM family_members WHERE id=?", (payload.person_id,)).fetchone()
    if not person:
        conn.close()
        raise HTTPException(400, "Person nicht gefunden.")
    cur = conn.execute(
        """INSERT INTO pension_accounts
           (person_id, type, label, provider, current_value, is_riester, monthly_contribution, linked_contract_id,
            projected_monthly_at_67, disability_pension_monthly, return_rate_assumption, note)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (payload.person_id, payload.type, payload.label, payload.provider,
         payload.current_value, int(bool(payload.is_riester)), payload.monthly_contribution, payload.linked_contract_id,
         payload.projected_monthly_at_67,
         payload.disability_pension_monthly, payload.return_rate_assumption, payload.note),
    )
    pid = cur.lastrowid
    if payload.document_staging_id:
        _attach_staged_pension_document(conn, pid, payload.document_staging_id, payload.document_original_filename)
    conn.commit()
    conn.close()
    return {"id": pid, "status": "created"}


@router.patch("/api/pension-accounts/{account_id}")
def update_pension_account(account_id: int, patch: PensionAccountPatch,
                            session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")
    fields = patch.dict(exclude_unset=True)
    # Keine echten Spalten -- separat behandeln, sonst würde das generische
    # UPDATE unten mit "UPDATE ... SET document_staging_id=?" fehlschlagen.
    staging_id = fields.pop("document_staging_id", None)
    staging_filename = fields.pop("document_original_filename", None)
    if staging_id:
        _attach_staged_pension_document(conn, account_id, staging_id, staging_filename)
    if fields:
        fields["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE pension_accounts SET {set_clause} WHERE id=?", (*fields.values(), account_id))
    elif not staging_id:
        conn.close()
        return {"status": "unchanged"}
    conn.commit()
    conn.close()
    return {"status": "updated"}


@router.delete("/api/pension-accounts/{account_id}")
def delete_pension_account(account_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")
    docs = conn.execute(
        "SELECT stored_path FROM pension_documents WHERE pension_account_id=?", (account_id,)
    ).fetchall()
    for d in docs:
        (BASE_DIR / d["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM pension_documents WHERE pension_account_id=?", (account_id,))
    conn.execute("DELETE FROM pension_accounts WHERE id=?", (account_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.post("/api/pension-accounts/{account_id}/document")
async def upload_pension_document(account_id: int, file: UploadFile = File(...),
                                   session=Depends(auth.require_full_auth)):
    """Fügt der Dokument-Zeitreihe dieses Rentenkontos einen neuen Eintrag
    hinzu (z.B. die jährliche Renteninformation) — ersetzt frühere
    Dokumente nicht, damit die Historie erhalten bleibt."""
    conn = get_connection()
    account = conn.execute("SELECT id FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")

    PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    content = await file.read()
    safe_name = re.sub(r"[^\w.-]", "_", file.filename or "dokument")[:80]
    stored_name = f"{account_id}_{hashlib.sha256(content).hexdigest()[:10]}_{safe_name}"
    stored_path = PENSION_DOCS_DIR / stored_name
    stored_path.write_bytes(content)

    cur = conn.execute(
        "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
        (account_id, file.filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest()),
    )
    conn.commit()
    conn.close()
    return {"status": "uploaded", "filename": file.filename, "id": cur.lastrowid}


@router.get("/api/pension-accounts/{account_id}/documents")
def list_pension_documents(account_id: int, session=Depends(auth.require_full_auth)):
    """Die volle Zeitreihe aller Dokumente zu diesem Rentenkonto. Ist das
    Konto mit einem Vertrag unter Ausgaben verknüpft, kommen die Belege
    von DORT (dieselbe Zeitreihe, kein doppeltes Hochladen nötig) statt
    aus einer eigenen pension_documents-Historie."""
    conn = get_connection()
    account = conn.execute(
        "SELECT linked_contract_id FROM pension_accounts WHERE id=?", (account_id,)
    ).fetchone()
    if account and account["linked_contract_id"]:
        rows = conn.execute(
            "SELECT id, original_filename, uploaded_at FROM receipts WHERE contract_id=? ORDER BY uploaded_at DESC",
            (account["linked_contract_id"],),
        ).fetchall()
        conn.close()
        return [{"id": r["id"], "original_filename": r["original_filename"],
                 "uploaded_at": r["uploaded_at"], "source": "contract"} for r in rows]

    rows = conn.execute(
        "SELECT id, original_filename, uploaded_at FROM pension_documents WHERE pension_account_id=? ORDER BY uploaded_at DESC",
        (account_id,),
    ).fetchall()
    conn.close()
    return [{**dict(r), "source": "pension"} for r in rows]


@router.get("/api/pension-documents/{document_id}")
def get_pension_document_by_id(document_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT * FROM pension_documents WHERE id=?", (document_id,)).fetchone()
    conn.close()
    if not doc:
        raise HTTPException(404, "Dokument nicht gefunden")
    file_path = BASE_DIR / doc["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Dokument-Datei fehlt auf der Festplatte")
    # Standardmäßig direkt im Browser anzeigen (inline) statt automatisch
    # herunterzuladen — ein Klick öffnete sonst nur einen leeren Tab, während
    # die Datei im Hintergrund heruntergeladen wurde. Download bewusst als
    # separate Option (?download=true), nicht als Standardverhalten.
    return FileResponse(
        file_path, filename=doc["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


@router.delete("/api/pension-documents/{document_id}")
def delete_pension_document(document_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT stored_path FROM pension_documents WHERE id=?", (document_id,)).fetchone()
    if not doc:
        conn.close()
        raise HTTPException(404, "Dokument nicht gefunden")
    (BASE_DIR / doc["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM pension_documents WHERE id=?", (document_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


PERSON_DOCS_DIR = BASE_DIR / "data" / "person_docs"


@router.post("/api/family-members/{person_id}/documents")
async def upload_person_document(person_id: int, file: UploadFile = File(...),
                                  session=Depends(auth.require_full_auth)):
    """Dokument zu einer Person (z.B. Sozialversicherungsausweis,
    Lohnsteuerbescheinigung) — fügt der Historie hinzu, ersetzt frühere
    Dokumente nicht."""
    conn = get_connection()
    person = conn.execute("SELECT id FROM family_members WHERE id=?", (person_id,)).fetchone()
    if not person:
        conn.close()
        raise HTTPException(404, "Person nicht gefunden")

    PERSON_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    content = await file.read()
    safe_name = re.sub(r"[^\w.-]", "_", file.filename or "dokument")[:80]
    stored_name = f"{person_id}_{hashlib.sha256(content).hexdigest()[:10]}_{safe_name}"
    stored_path = PERSON_DOCS_DIR / stored_name
    stored_path.write_bytes(content)

    cur = conn.execute(
        "INSERT INTO person_documents (person_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
        (person_id, file.filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest()),
    )
    conn.commit()
    conn.close()
    return {"status": "uploaded", "filename": file.filename, "id": cur.lastrowid}


@router.get("/api/family-members/{person_id}/documents")
def list_person_documents(person_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT id, original_filename, uploaded_at FROM person_documents WHERE person_id=? ORDER BY uploaded_at DESC",
        (person_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.get("/api/person-documents/{document_id}")
def get_person_document_by_id(document_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT * FROM person_documents WHERE id=?", (document_id,)).fetchone()
    conn.close()
    if not doc:
        raise HTTPException(404, "Dokument nicht gefunden")
    file_path = BASE_DIR / doc["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Dokument-Datei fehlt auf der Festplatte")
    return FileResponse(
        file_path, filename=doc["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


@router.delete("/api/person-documents/{document_id}")
def delete_person_document(document_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    doc = conn.execute("SELECT stored_path FROM person_documents WHERE id=?", (document_id,)).fetchone()
    if not doc:
        conn.close()
        raise HTTPException(404, "Dokument nicht gefunden")
    (BASE_DIR / doc["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM person_documents WHERE id=?", (document_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.get("/api/vorsorge/risiko")
def vorsorge_risiko_overview(session=Depends(auth.require_full_auth)):
    """Übersicht aller Versicherungen, gruppiert nach Typ, mit Sollbereichen
    (nicht nur Ampel) — siehe vorsorge.py für die Faustregeln und deren
    Quellen. Bezieht dabei Daten von anderen Seiten der App mit ein: Anzahl
    Kinder im Haushalt (Familienmitglieder) und eine laufende
    Immobilienfinanzierung (Ausgaben), da beides den Absicherungsbedarf
    erhöht."""
    from vorsorge import compute_bu_assessment, compute_rlv_assessment, compute_bu_em_combination
    conn = get_connection()
    contracts = conn.execute(
        """SELECT co.*, f.name AS person_name
           FROM contracts co LEFT JOIN family_members f ON f.id = co.person_id
           LEFT JOIN categories c ON c.id = co.category_id
           WHERE co.status='active' AND c.name = 'Versicherungen'
           ORDER BY co.insurance_type, f.sort_order, co.label"""
    ).fetchall()

    income_by_person = {}
    for row in conn.execute(
        f"""SELECT person_id, SUM({monthly_expr('amount', 'frequency')}) AS v
            FROM income WHERE active=1 AND person_id IS NOT NULL GROUP BY person_id"""
    ).fetchall():
        income_by_person[row["person_id"]] = row["v"]

    child_count = conn.execute(
        "SELECT COUNT(*) AS n FROM family_members WHERE role='kind'"
    ).fetchone()["n"]
    has_children = child_count > 0

    person_names = {
        row["id"]: row["name"] for row in conn.execute("SELECT id, name FROM family_members").fetchall()
    }

    # Erwerbsminderungsrente je Person aus den gesetzlichen Rentenkonten —
    # relevant für die Deckelungsprüfung zusammen mit der privaten BU-Rente.
    em_by_person = {}
    for row in conn.execute(
        """SELECT person_id, COALESCE(SUM(disability_pension_monthly),0) AS v
           FROM pension_accounts WHERE type='gesetzlich' GROUP BY person_id"""
    ).fetchall():
        em_by_person[row["person_id"]] = row["v"]

    financing_monthly = conn.execute(
        f"""SELECT COALESCE(SUM({monthly_expr('co.amount', 'co.frequency', 'co.split_share')}),0) AS v
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND c.name='Haus' AND co.subcategory='Finanzierung'"""
    ).fetchone()["v"]

    conn.close()

    groups = {}
    for c in contracts:
        itype = c["insurance_type"] or "Sonstige Versicherung"
        groups.setdefault(itype, []).append(c)

    result = []
    for itype, items in groups.items():
        entries = []
        for c in items:
            entry = {
                "id": c["id"], "label": c["label"], "provider": c["provider"],
                "person_id": c["person_id"], "person_name": c["person_name"],
                "amount": c["amount"], "frequency": c["frequency"],
            }
            net_income = income_by_person.get(c["person_id"], 0) if c["person_id"] else 0

            if itype == "Berufsunfähigkeitsversicherung":
                entry["bu_monthly_pension"] = c["bu_monthly_pension"]
                entry.update(compute_bu_assessment(c["bu_monthly_pension"], net_income))
                entry["bu_em_combination"] = compute_bu_em_combination(
                    c["bu_monthly_pension"], em_by_person.get(c["person_id"], 0), net_income
                )
            elif itype == "Risikolebensversicherung":
                entry["insurance_sum"] = c["insurance_sum"]
                entry["insurance_expiry"] = c["insurance_expiry"]
                entry["insurance_sum_type"] = c["insurance_sum_type"]
                entry.update(compute_rlv_assessment(c["insurance_sum"], net_income, has_children, financing_monthly))
            else:
                entry["assessment"] = "present"
            entries.append(entry)
        result.append({"insurance_type": itype, "entries": entries})

    # Häufige Standard-Absicherungen, die fehlen könnten (rein informativ).
    # Mit Begründung, damit klar wird, WARUM etwas empfohlen wird — nicht nur
    # eine nackte Liste. Bei Kindern im Haushalt kommt eine Unfallversicherung
    # dazu: die gesetzliche Unfallversicherung über Schule/Kita deckt nur den
    # direkten Schulweg und die Einrichtung selbst ab, nicht die Freizeit —
    # dort passiert der Großteil der Kinderunfälle.
    present_types = set(groups.keys())
    essential_types = [
        ("Haftpflichtversicherung", "Deckt Schäden, die ihr anderen zufügt — mit Kindern im Haushalt besonders relevant, da sie oft für Schäden haften, die die Kinder verursachen."),
        ("Hausratversicherung", "Schützt die gesamte Wohnungseinrichtung bei Feuer, Einbruch oder Leitungswasser."),
        ("Berufsunfähigkeitsversicherung", "Die gesetzliche Absicherung bei Erwerbsunfähigkeit fällt oft deutlich niedriger aus als das bisherige Einkommen."),
        ("Risikolebensversicherung", "Mit Kindern im Haushalt besonders wichtig — sichert den Lebensunterhalt der Familie ab, falls ein Elternteil stirbt."),
    ]
    if has_children:
        essential_types.append((
            "Unfallversicherung",
            "Die gesetzliche Unfallversicherung über Schule/Kita gilt nur auf dem direkten Weg dorthin und vor Ort — Freizeitunfälle, wo die meisten Kinderunfälle passieren, sind nicht mitversichert.",
        ))
    missing_common = [
        {"insurance_type": t, "reason": reason}
        for t, reason in essential_types if t not in present_types
    ]
    essential_total = len(essential_types)
    essential_present = essential_total - len(missing_common)

    # Zusammenfassende Empfehlung je einkommensbeziehender Person, damit man
    # nicht erst durch alle Gruppen suchen muss, um zu sehen, wo man steht.
    persons_summary = []
    for person_id, net_income in income_by_person.items():
        if net_income <= 0:
            continue
        person_name = person_names.get(person_id)
        bu_entries = [
            e for g in result if g["insurance_type"] == "Berufsunfähigkeitsversicherung"
            for e in g["entries"] if e["person_id"] == person_id
        ]
        rlv_entries = [
            e for g in result if g["insurance_type"] == "Risikolebensversicherung"
            for e in g["entries"] if e["person_id"] == person_id
        ]
        best_bu = max(bu_entries, key=lambda e: e.get("bu_monthly_pension") or 0, default=None)
        best_rlv = max(rlv_entries, key=lambda e: e.get("insurance_sum") or 0, default=None)
        bu_assessment = best_bu or compute_bu_assessment(None, net_income)
        rlv_assessment = best_rlv or compute_rlv_assessment(None, net_income, has_children, financing_monthly)
        persons_summary.append({
            "person_id": person_id,
            "person_name": person_name,
            "net_income_monthly": round(net_income, 2),
            "bu_em_combination": compute_bu_em_combination(
                best_bu.get("bu_monthly_pension") if best_bu else None,
                em_by_person.get(person_id, 0), net_income,
            ),
            "bu": bu_assessment,
            "rlv": rlv_assessment,
        })

    return {
        "groups": result,
        "missing_common_types": missing_common,
        "essential_total": essential_total,
        "essential_present": essential_present,
        "household": {
            "child_count": child_count,
            "financing_monthly": round(financing_monthly, 2),
        },
        "persons_summary": persons_summary,
    }


@router.get("/api/vorsorge/rente")
def vorsorge_rente_overview(session=Depends(auth.require_full_auth)):
    """Versorgungslücken-Analyse je Person MIT eigenem Einkommen (wie bisher)
    sowie zusammengefasst für den ganzen Haushalt — im Alter tragen meist
    beide Einkommen gemeinsam den Lebensstandard, insofern ist die
    Haushaltssicht oft aussagekräftiger als die reine Einzelbetrachtung.
    Eine bis zum Renteneintritt abbezahlte Immobilienfinanzierung wird dabei
    als Entlastung der Zielrente berücksichtigt (weniger Ausgaben im Alter =
    selbst eine Form von Vorsorge) — hinterlegt wird das ganz normal über
    das 'Vertragsende' bei der Finanzierung."""
    from vorsorge import (
        years_until_retirement, project_private_pension_capital,
        capital_to_monthly_pension, compute_pension_gap, compute_household_pension_gap,
        DEFAULT_RETURN_RATE, RETIREMENT_AGE, TARGET_REPLACEMENT_RATE,
    )
    conn = get_connection()
    members = conn.execute(
        "SELECT * FROM family_members WHERE role='elternteil' ORDER BY sort_order"
    ).fetchall()

    result = []
    household_net_income = 0.0
    household_statutory = 0.0
    household_private = 0.0
    latest_retirement_date = None
    persons_ages = []
    person_birthdates = []
    today = date.today()

    for person in members:
        net_income = conn.execute(
            f"""SELECT COALESCE(SUM({monthly_expr('amount', 'frequency')}),0) AS v
                FROM income WHERE active=1 AND person_id=?""",
            (person["id"],),
        ).fetchone()["v"]

        accounts = conn.execute(
            """SELECT pa.*, co.amount AS linked_contract_amount, co.label AS linked_contract_label
               FROM pension_accounts pa
               LEFT JOIN contracts co ON co.id = pa.linked_contract_id
               WHERE pa.person_id=? ORDER BY pa.type DESC, pa.label""",
            (person["id"],),
        ).fetchall()

        birth_date = date.fromisoformat(person["birth_date"]) if person["birth_date"] else None
        years_left = years_until_retirement(birth_date)
        if birth_date:
            retirement_date = date(birth_date.year + RETIREMENT_AGE, birth_date.month, birth_date.day)
            if latest_retirement_date is None or retirement_date > latest_retirement_date:
                latest_retirement_date = retirement_date
            age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
            persons_ages.append({"person_name": person["name"], "age": age})
            person_birthdates.append({"person_name": person["name"], "birth_date": birth_date})

        statutory_total = sum(
            (a["projected_monthly_at_67"] or 0) for a in accounts if a["type"] == "gesetzlich"
        )

        private_total = 0.0
        private_accounts_detail = []
        for a in accounts:
            if a["type"] != "privat":
                continue
            # Verknüpftes Konto: der Beitrag kommt live vom Vertrag unter
            # Ausgaben statt aus einem separat gepflegten Wert — so muss er
            # nur an einer Stelle aktuell gehalten werden.
            effective_contribution = a["linked_contract_amount"] if a["linked_contract_id"] else a["monthly_contribution"]
            if a["projected_monthly_at_67"] is not None:
                monthly = a["projected_monthly_at_67"]
                projected_capital = a["current_value"]
            elif years_left is not None:
                rate = a["return_rate_assumption"] if a["return_rate_assumption"] is not None else DEFAULT_RETURN_RATE
                projected_capital = project_private_pension_capital(
                    a["current_value"] or 0, effective_contribution or 0, years_left, rate
                )
                monthly = capital_to_monthly_pension(projected_capital)
            else:
                # Kein Geburtsdatum hinterlegt -> keine Restlaufzeit berechenbar,
                # ohne direkten Prognosewert kann dieses Konto nicht projiziert werden.
                monthly = 0
                projected_capital = a["current_value"]
            private_total += monthly
            private_accounts_detail.append({
                "id": a["id"], "label": a["label"], "provider": a["provider"],
                "current_value": a["current_value"],
                # Für das Bearbeiten-Formular nötig: ohne diese Felder würde das
                # Formular sie leer vorbelegen und beim Speichern überschreiben.
                "monthly_contribution": effective_contribution,
                "is_riester": bool(a["is_riester"]),
                "linked_contract_id": a["linked_contract_id"],
                "linked_contract_label": a["linked_contract_label"],
                "projected_monthly_at_67": a["projected_monthly_at_67"],
                "note": a["note"],
                "projected_capital_at_67": round(projected_capital or 0, 2),
                "projected_monthly": round(monthly, 2),
            })

        gap = compute_pension_gap(net_income, statutory_total, private_total) if net_income > 0 else None

        # Jahr-für-Jahr-Kapitalverlauf über ALLE privaten Konten dieser Person
        # zusammen -- macht den abstrakten Endwert ("Prognose 67") als echten
        # Wachstumsverlauf sichtbar, nicht nur als einzelne Zielzahl.
        capital_projection = []
        if years_left is not None and years_left > 0:
            projectable = [a for a in accounts if a["type"] == "privat" and a["projected_monthly_at_67"] is None]
            current_year = date.today().year
            span = min(int(years_left) + 1, 45)  # Deckel gegen ausufernde Datenmengen bei sehr jungen Personen
            for offset in range(0, span + 1):
                year_total = 0.0
                for a in projectable:
                    rate = a["return_rate_assumption"] if a["return_rate_assumption"] is not None else DEFAULT_RETURN_RATE
                    contribution = a["linked_contract_amount"] if a["linked_contract_id"] else a["monthly_contribution"]
                    year_total += project_private_pension_capital(a["current_value"] or 0, contribution or 0, offset, rate)
                capital_projection.append({"year": current_year + offset, "capital": round(year_total, 2)})

        household_net_income += net_income
        household_statutory += statutory_total
        household_private += private_total

        result.append({
            "person_id": person["id"], "person_name": person["name"],
            "birth_date": person["birth_date"], "years_until_retirement": round(years_left, 1) if years_left is not None else None,
            "net_income_monthly": round(net_income, 2),
            "statutory_accounts": [dict(a) for a in accounts if a["type"] == "gesetzlich"],
            "private_accounts": private_accounts_detail,
            "gap_analysis": gap,
            "capital_projection": capital_projection,
        })

    # Finanzierung(en), die bis zum Renteneintritt des zuletzt in Rente
    # gehenden Elternteils abbezahlt sein werden — deren monatliche Rate
    # entfällt dann als Ausgabe und senkt die benötigte Zielrente.
    from finanzierung import compute_repayment_schedule
    financing_rows = conn.execute(
        f"""SELECT co.amount, co.frequency, co.remaining_debt, co.interest_rate, co.repayment_rate,
                   co.label, co.provider, co.contract_number
            FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
            WHERE co.status='active' AND c.name='Haus' AND co.subcategory='Finanzierung'"""
    ).fetchall()
    financing_details = []
    expense_relief = 0.0
    for f in financing_rows:
        monthly_amt = f["amount"] if f["frequency"] == "monthly" else (
            f["amount"] / 3 if f["frequency"] == "quarterly" else f["amount"] / 12
        )
        # Ob die Finanzierung vor der Rente abbezahlt ist, wird jetzt aus dem
        # echten Zins+Tilgungsrechner ermittelt (Restschuld/Zins/Rate) statt
        # aus einem manuell eingetragenen Datum — das war zuvor mit der
        # Zinsbindung verwechselbar und daher unzuverlässig.
        schedule = compute_repayment_schedule(
            remaining_debt=f["remaining_debt"], interest_rate=f["interest_rate"],
            monthly_payment=monthly_amt, repayment_rate=f["repayment_rate"],
        )
        payoff_year = schedule.get("payoff_year") if not schedule.get("error") else None
        paid_off_before_retirement = bool(
            payoff_year and latest_retirement_date and payoff_year <= latest_retirement_date.year
        )
        if paid_off_before_retirement:
            expense_relief += monthly_amt
        # Alter beider Elternteile IM Tilgungsjahr (nicht das heutige Alter!) —
        # deutlich aussagekräftiger, um einzuschätzen, ob die Finanzierung
        # realistisch vor bzw. erst nach dem Renteneintritt abbezahlt ist.
        ages_at_payoff = None
        if payoff_year:
            ages_at_payoff = [
                {"person_name": pb["person_name"], "age": payoff_year - pb["birth_date"].year}
                for pb in person_birthdates
            ]
        base_label = f["label"] or f["provider"] or "Darlehen"
        # Mehrere Darlehen derselben Bank (z.B. Haupt- + KfW-Darlehen bei
        # derselben Bank) tragen sonst identische, nicht unterscheidbare
        # Labels — die Kontonummer macht sie eindeutig.
        display_label = f"{base_label} ({f['contract_number']})" if f["contract_number"] else base_label
        financing_details.append({
            "label": display_label, "monthly_amount": round(monthly_amt, 2),
            "payoff_year": payoff_year,
            "calculation_error": schedule.get("error"),
            "paid_off_before_retirement": paid_off_before_retirement,
            "ages_at_payoff": ages_at_payoff,
        })

    household_gap = (
        compute_household_pension_gap(household_net_income, household_statutory, household_private, expense_relief)
        if household_net_income > 0 else None
    )

    conn.close()
    return {
        "retirement_age": RETIREMENT_AGE,
        "target_replacement_rate": TARGET_REPLACEMENT_RATE,
        "default_return_rate": DEFAULT_RETURN_RATE,
        "persons": result,
        "household": {
            "net_income_monthly": round(household_net_income, 2),
            "statutory_pension_monthly": round(household_statutory, 2),
            "private_pension_monthly": round(household_private, 2),
            "financing": financing_details,
            "gap_analysis": household_gap,
            "persons_ages": persons_ages,
        },
    }


@router.post("/api/pension-accounts/{account_id}/bulk-upload-documents")
async def bulk_upload_pension_documents(account_id: int, files: List[UploadFile] = File(...),
                                         session=Depends(auth.require_full_auth)):
    """Mehrere Dokumente auf einmal zu einem Rentenkonto — z.B. mehrere
    Jahre an Renteninformationen auf einen Schlag nachtragen. Gleiches
    Prinzip wie beim Vermögenswerte-Sammelimport: Duplikate (gleicher
    Dateiinhalt, gleiches Rentenkonto) werden übersprungen, nie doppelt
    abgelegt."""
    conn = get_connection()
    account = conn.execute("SELECT id, label FROM pension_accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        conn.close()
        raise HTTPException(404, "Rentenkonto nicht gefunden")

    PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        existing = conn.execute(
            "SELECT id FROM pension_documents WHERE pension_account_id=? AND file_hash=?",
            (account_id, file_hash),
        ).fetchone()
        if existing:
            results.append({"document_id": existing["id"], "filename": file.filename, "skipped": True})
            continue

        safe_name = re.sub(r"[^\w.-]", "_", file.filename or "dokument")[:80]
        stored_name = f"{account_id}_{file_hash[:10]}_{safe_name}"
        stored_path = PENSION_DOCS_DIR / stored_name
        stored_path.write_bytes(content)

        cur = conn.execute(
            "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
            (account_id, file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash),
        )
        results.append({"document_id": cur.lastrowid, "filename": file.filename, "skipped": False})

    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}

