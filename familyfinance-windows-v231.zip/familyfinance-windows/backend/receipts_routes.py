"""
Belege & Import — Gehaltsabrechnungen, Beleg-Upload und -Bestätigung,
Duplikatserkennung sowie der intelligente Datei-Import (CSV/XLSX/ODS).

Aus app.py herausgelöst, um die zentrale Datei überschaubar zu halten. Die
Routen sind unverändert übernommen und werden über einen APIRouter in app.py
eingebunden — die URLs bleiben exakt dieselben wie vorher.
"""
import hashlib
import json
import re
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

import auth
import meters
import ocr
import smart_import
from database import get_connection
from ocr import extract_receipt_data
from shared_helpers import monthly_expr, _contract_folder_parts
from payslip_import import parse_payslip

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent
RECEIPTS_DIR = BASE_DIR / "data" / "receipts"
PAYSLIPS_DIR = BASE_DIR / "data" / "payslips"
# Auch in vorsorge_routes.py/energy_routes.py definiert -- bewusst als
# eigenständige, gleiche Definition statt eines Imports, um einen
# Zirkelbezug zwischen den Modulen zu vermeiden.
PENSION_DOCS_DIR = BASE_DIR / "data" / "pension_docs"

# ---------- Gehaltsabrechnungen (PDF, teils passwortgeschützt) ----------

@router.post("/api/payslips/bulk-upload")
async def bulk_upload_payslips(income_id: int = Form(...), files: List[UploadFile] = File(...),
                                password: Optional[str] = Form(None),
                                session=Depends(auth.require_full_auth)):
    """Für den initialen Import eines ganzen Stapels alter Gehaltsabrechnungen
    auf einmal. Anders als der Einzel-Upload wird hier NIE der Betrag der
    verknüpften Einnahme aktualisiert — auch nicht durch die zeitlich
    neueste Datei im Stapel. Die Dateien landen direkt (ohne Review-Schritt)
    als bestätigte Zeitreihen-Einträge, der aktuelle Einkommenswert bleibt
    unangetastet, da ein Rückblick-Import keine Aussage über das AKTUELLE
    Gehalt treffen soll."""
    conn = get_connection()
    income = conn.execute("SELECT id FROM income WHERE id=?", (income_id,)).fetchone()
    if not income:
        conn.close()
        raise HTTPException(404, "Einnahme nicht gefunden")

    PAYSLIPS_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        # Byteidentische Datei für dieselbe Einnahme bereits vorhanden? Dann
        # nicht erneut anlegen — verhindert genau die Art von Duplikaten, die
        # z.B. durch zweimaliges versehentliches Auswählen derselben Datei
        # im Dateidialog entstehen.
        existing = conn.execute(
            "SELECT id FROM payslips WHERE income_id=? AND file_hash=?", (income_id, file_hash)
        ).fetchone()
        if existing:
            results.append({"payslip_id": existing["id"], "filename": file.filename, "month": None, "error": "Übersprungen — identische Datei bereits vorhanden."})
            continue

        stored_path = PAYSLIPS_DIR / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{file.filename}"
        stored_path.write_bytes(content)
        try:
            parsed = parse_payslip(stored_path, password)
            net_amount, employer, month = parsed["net_amount"], parsed["employer"], parsed["month"]
            error = None
        except Exception as e:
            # Einzelne nicht lesbare/beschädigte Datei soll den restlichen
            # Stapel nicht abbrechen — sie wird trotzdem archiviert, nur ohne
            # erkannte Werte. parse_payslip kann je nach Fehlerart
            # unterschiedliche Exception-Typen werfen (ungültiges PDF,
            # falsches Passwort, o.ä.), daher hier bewusst breit gefangen.
            net_amount, employer, month = None, None, None
            error = str(e)
        cur = conn.execute(
            """INSERT INTO payslips
               (original_filename, stored_path, file_hash, detected_net_amount,
                detected_employer, detected_month, income_id, review_needed)
               VALUES (?,?,?,?,?,?,?,0)""",
            (file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash, net_amount, employer, month, income_id),
        )
        results.append({"payslip_id": cur.lastrowid, "filename": file.filename, "month": month, "error": error})
    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}


@router.post("/api/payslips/upload")
async def upload_payslip(file: UploadFile = File(...), password: Optional[str] = Form(None),
                          session=Depends(auth.require_full_auth)):
    content = await file.read()
    PAYSLIPS_DIR.mkdir(parents=True, exist_ok=True)
    stored_path = PAYSLIPS_DIR / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{file.filename}"
    stored_path.write_bytes(content)

    try:
        result = parse_payslip(stored_path, password)
    except ValueError as e:
        raise HTTPException(400, str(e))

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO payslips
           (original_filename, stored_path, file_hash, raw_text, detected_net_amount,
            detected_employer, detected_month, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(stored_path.relative_to(BASE_DIR)), hashlib.sha256(content).hexdigest(),
         result["raw_text"], result["net_amount"], result["employer"], result["month"]),
    )
    payslip_id = cur.lastrowid
    conn.commit()

    matched_income = _find_matching_income(conn, result.get("name_candidates") or [])
    conn.close()

    note = "Bitte kurz bestätigen."
    if matched_income:
        note = f"Automatisch {matched_income['label']!r} zugeordnet — bitte nur kurz bestätigen."
    else:
        note = "Konnte nicht automatisch zugeordnet werden — bitte Einkommens-Eintrag auswählen."

    return {
        "payslip_id": payslip_id,
        "detected": {k: v for k, v in result.items() if k != "raw_text"},
        "matched_income": matched_income,
        "note": note,
    }


class PayslipConfirmIn(BaseModel):
    income_id: Optional[int] = None
    new_income_label: Optional[str] = None
    update_income: bool = True  # False = Beleg nur ablegen/bestätigen, kein Einkommen buchen


@router.post("/api/payslips/{payslip_id}/confirm")
def confirm_payslip(payslip_id: int, payload: PayslipConfirmIn,
                     session=Depends(auth.require_full_auth)):
    conn = get_connection()
    slip = conn.execute("SELECT * FROM payslips WHERE id=?", (payslip_id,)).fetchone()
    if not slip:
        conn.close()
        raise HTTPException(404, "Gehaltsabrechnung nicht gefunden")

    if not payload.update_income:
        # Nur ablegen/als gesichtet markieren, kein Einkommen anlegen oder
        # überschreiben — z.B. bei einem Dokument, das gar keine reguläre
        # Lohnzahlung darstellt (Bonuszusage, Bescheinigung o.ä.).
        conn.execute("UPDATE payslips SET review_needed=0, income_id=? WHERE id=?",
                     (payload.income_id, payslip_id))
        conn.commit()
        conn.close()
        return {"status": "confirmed", "income_id": payload.income_id}

    if not slip["detected_net_amount"]:
        conn.close()
        raise HTTPException(400, "Kein Betrag erkannt — bitte Einkommen manuell nachtragen.")

    if payload.income_id:
        conn.execute(
            "UPDATE income SET amount=?, source='lohnabrechnung', updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (slip["detected_net_amount"], payload.income_id),
        )
        income_id = payload.income_id
    else:
        label = payload.new_income_label or slip["detected_employer"] or slip["original_filename"]
        cur = conn.execute(
            "INSERT INTO income (label, amount, frequency, active, source) "
            "VALUES (?,?, 'monthly', 1, 'lohnabrechnung')",
            (label, slip["detected_net_amount"]),
        )
        income_id = cur.lastrowid

    conn.execute("UPDATE payslips SET review_needed=0, income_id=? WHERE id=?",
                 (income_id, payslip_id))
    conn.commit()
    conn.close()
    return {"status": "confirmed", "income_id": income_id}


@router.get("/api/income/{income_id}/payslips")
def list_income_payslips(income_id: int, session=Depends(auth.require_full_auth)):
    """Die volle Zeitreihe aller Gehaltsabrechnungen zu dieser Einnahme,
    nicht nur die zuletzt hochgeladene. Sortiert nach dem erkannten
    Abrechnungsmonat (steht bei jedem Import mit dabei) statt nach dem
    Hochlade-Zeitpunkt — sonst würde ein nachträglich importierter
    Alt-Beleg (z.B. Januar, aber erst heute hochgeladen) an der falschen
    Stelle der Zeitreihe erscheinen. Einträge ohne erkannten Monat fallen
    auf den Hochlade-Zeitpunkt zurück und landen sortiert am Ende."""
    conn = get_connection()
    rows = conn.execute(
        """SELECT id, original_filename, detected_net_amount, detected_month, detected_employer, uploaded_at
           FROM payslips WHERE income_id=?
           ORDER BY COALESCE(detected_month, '0000-00') DESC, uploaded_at DESC""",
        (income_id,),
    ).fetchall()
    conn.close()

    # Zuletzt gepflegter Arbeitgeber-Wert dieser Einnahme (nach Hochlade-
    # Zeitpunkt, nicht nach Abrechnungsmonat — "zuletzt gepflegt" meint den
    # jüngsten tatsächlichen Dateneingabe-Zeitpunkt) als Rückfallwert für
    # Belege, bei denen der Arbeitgeber nicht automatisch erkannt wurde.
    with_employer = [r for r in rows if r["detected_employer"]]
    last_known_employer = with_employer[0]["detected_employer"] if with_employer else None
    if with_employer:
        last_known_employer = max(with_employer, key=lambda r: r["uploaded_at"] or "")["detected_employer"]

    result = []
    for r in rows:
        d = dict(r)
        d["employer"] = d["detected_employer"] or last_known_employer
        d["employer_is_fallback"] = not d["detected_employer"] and last_known_employer is not None
        result.append(d)
    return result


@router.get("/api/payslips/{payslip_id}/file")
def get_payslip_file(payslip_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    slip = conn.execute("SELECT stored_path, original_filename FROM payslips WHERE id=?", (payslip_id,)).fetchone()
    conn.close()
    if not slip:
        raise HTTPException(404, "Gehaltsabrechnung nicht gefunden")
    file_path = BASE_DIR / slip["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Datei fehlt auf der Festplatte")
    return FileResponse(
        file_path, filename=slip["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


@router.delete("/api/payslips/{payslip_id}")
def delete_payslip(payslip_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    slip = conn.execute("SELECT stored_path FROM payslips WHERE id=?", (payslip_id,)).fetchone()
    if not slip:
        conn.close()
        raise HTTPException(404, "Gehaltsabrechnung nicht gefunden")
    (BASE_DIR / slip["stored_path"]).unlink(missing_ok=True)
    conn.execute("DELETE FROM payslips WHERE id=?", (payslip_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


# ---------- Belege / Foto-Upload ----------

def _cleanup_unconfirmed_receipts(conn, max_age_hours: Optional[float] = None) -> dict:
    """Räumt nicht bestätigte Belege auf (z.B. Test-Uploads, die nie
    'Bestätigen & übernehmen' durchlaufen haben) — sowohl die Datei in
    data/receipts/_unbestaetigt/ als auch den Datenbankeintrag.

    max_age_hours=None -> alle unbestätigten Belege werden entfernt (für den
    manuellen "Jetzt aufräumen"-Button). Mit einem Wert gesetzt (z.B. 168 für
    eine Woche) werden nur ältere entfernt — so für den automatischen
    Aufräumlauf beim Serverstart, damit ein frisch hochgeladener, noch nicht
    bestätigter Beleg von heute nicht versehentlich verschwindet.
    """
    if max_age_hours is not None:
        rows = conn.execute(
            "SELECT id, stored_path FROM receipts "
            "WHERE review_needed=1 AND uploaded_at < datetime('now', ?)",
            (f"-{max_age_hours} hours",),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, stored_path FROM receipts WHERE review_needed=1"
        ).fetchall()

    deleted_files = 0
    for row in rows:
        file_path = BASE_DIR / row["stored_path"]
        if file_path.exists():
            file_path.unlink()
            deleted_files += 1
    ids = [row["id"] for row in rows]
    if ids:
        placeholders = ",".join("?" * len(ids))
        conn.execute(f"DELETE FROM receipts WHERE id IN ({placeholders})", ids)
        conn.commit()

    # Zusätzlich: Dateien im Zwischenablage-Ordner, die gar keinen
    # Datenbankeintrag mehr haben (z.B. Reste aus manuellen Tests direkt
    # gegen das Backend, ohne über die eigentliche Upload-Route zu laufen).
    orphan_files = 0
    staging_dir = RECEIPTS_DIR / "_unbestaetigt"
    if staging_dir.exists():
        known_paths = {
            str((BASE_DIR / r["stored_path"]).resolve())
            for r in conn.execute("SELECT stored_path FROM receipts").fetchall()
        }
        for f in staging_dir.iterdir():
            if f.is_file() and str(f.resolve()) not in known_paths:
                f.unlink()
                orphan_files += 1

    return {"removed_receipts": len(ids), "removed_files": deleted_files + orphan_files}


def _find_matching_income(conn, name_candidates: list) -> Optional[dict]:
    """Ordnet eine Gehaltsabrechnung automatisch dem passenden Einkommens-
    Eintrag zu — z.B. "Gehalt Anna" bei einer Abrechnung für "Anna".
    Nutzt einen Vorsilben-Abgleich (erste 3 Zeichen), damit auch Kurzformen
    wie "Anna"/"Anna Musterfrau" oder "Tom"/"Tom Mustermann" zueinander passen, ohne
    Namen fest im Code zu hinterlegen."""
    if not name_candidates:
        return None
    rows = conn.execute("SELECT id, label FROM income WHERE active=1").fetchall()
    # Generische Gehaltsabrechnungs-/Finanzbegriffe ausschließen — sonst würde
    # z.B. ein Einkommens-Label wie "Gehalt Anna (Steuerklasse 4)" über das
    # Wort "Steuerklasse" mit "Steuer" matchen, das auf JEDER Abrechnung
    # vorkommt (unabhängig davon, wessen Abrechnung es ist).
    stop_words = {
        "gehalt", "lohn", "einkommen", "salär", "salary", "steuerklasse", "steuer",
        "brutto", "netto", "abrechnung", "beitrag", "beiträge", "konto", "bank",
        "freibetrag", "verdienst", "bezüge", "bezug", "personal", "geburtsdatum",
        "konfession", "auszahlung", "auszahlungsbetrag", "lohnsteuer", "kirchensteuer",
    }
    for row in rows:
        label_words = [
            w for w in re.findall(r"[A-Za-zÄÖÜäöüß]+", row["label"])
            if w.lower() not in stop_words and len(w) >= 3
        ]
        for w in label_words:
            for cand in name_candidates:
                if len(cand) < 3:
                    continue
                if w[:3].lower() != cand[:3].lower():
                    continue
                # Längenverhältnis-Schutz: "Steuer"(6) vs. "Steuerklasse"(12)
                # hätte dieselbe 3-Buchstaben-Vorsilbe, ist aber offensichtlich
                # ein anderes Wort — bei einem echten Namens-Kurzform-Paar wie
                # "Anna"(4)/"Anna Musterfrau"(13) liegen die Längen viel näher beieinander.
                shorter, longer = sorted((len(w), len(cand)))
                if shorter / longer < 0.55:
                    continue
                return {"id": row["id"], "label": row["label"]}
    return None


def _find_matching_contract(conn, provider: Optional[str], contract_number: Optional[str]) -> Optional[dict]:
    """Versucht, einen Beleg automatisch einem bestehenden Vertrag zuzuordnen.
    Eingriff durch den Nutzer soll nur nötig sein, wenn hier nichts Eindeutiges
    gefunden wird — deshalb wird bewusst nur bei klaren Treffern automatisch
    zugeordnet, bei Mehrdeutigkeit lieber gar nicht."""
    rows = conn.execute(
        "SELECT id, label, provider, contract_number, category_id FROM contracts WHERE status='active'"
    ).fetchall()

    # 1. Höchste Sicherheit: Vertragsnummer stimmt exakt überein (Groß-/Kleinschreibung, Leerzeichen egal)
    if contract_number:
        norm_target = re.sub(r"[\s\-./]", "", contract_number).lower()
        matches = [
            r for r in rows
            if r["contract_number"] and re.sub(r"[\s\-./]", "", r["contract_number"]).lower() == norm_target
        ]
        if len(matches) == 1:
            return {"id": matches[0]["id"], "label": matches[0]["label"], "confidence": "vertragsnummer"}

    # 2. Anbieter taucht eindeutig im Vertragspartner oder in der Bezeichnung auf
    if provider:
        provider_key = provider.lower()
        matches = [
            r for r in rows
            if (r["provider"] and r["provider"].lower() in provider_key)
            or (r["label"] and r["label"].lower() in provider_key)
            or (r["provider"] and provider_key in r["provider"].lower())
        ]
        if len(matches) == 1:
            return {"id": matches[0]["id"], "label": matches[0]["label"], "confidence": "anbieter"}

    return None


@router.post("/api/receipts/cleanup")
def cleanup_receipts(session=Depends(auth.require_full_auth)):
    """Löscht alle aktuell unbestätigten Belege (Datei + Datenbankeintrag) —
    z.B. um Test-Uploads aus der Entwicklung/Fehlersuche aufzuräumen."""
    conn = get_connection()
    result = _cleanup_unconfirmed_receipts(conn, max_age_hours=None)
    conn.close()
    return result


@router.get("/api/receipts/duplicates")
def list_receipt_duplicates(session=Depends(auth.require_full_auth)):
    """Findet Gruppen von Belegen mit identischem Dateiinhalt (gleicher Hash) —
    z.B. entstanden durch mehrfaches Hochladen derselben Rechnung mit
    unterschiedlicher Zuordnung beim Testen."""
    conn = get_connection()
    hashes = conn.execute(
        "SELECT file_hash FROM receipts WHERE file_hash IS NOT NULL "
        "GROUP BY file_hash HAVING COUNT(*) > 1"
    ).fetchall()

    groups = []
    for h in hashes:
        rows = conn.execute(
            """SELECT r.id, r.original_filename, r.uploaded_at, r.review_needed,
                      r.detected_amount, r.contract_id,
                      co.label AS contract_label, e.id AS expense_id, e.amount AS expense_amount
               FROM receipts r
               LEFT JOIN contracts co ON co.id = r.contract_id
               LEFT JOIN expenses e ON e.receipt_id = r.id
               WHERE r.file_hash = ?
               ORDER BY r.uploaded_at ASC""",
            (h["file_hash"],),
        ).fetchall()
        groups.append({"file_hash": h["file_hash"], "receipts": [dict(r) for r in rows]})
    conn.close()
    return {"groups": groups}


class DuplicateResolveIn(BaseModel):
    keep_id: int
    remove_ids: list[int]


@router.post("/api/receipts/duplicates/resolve")
def resolve_receipt_duplicates(payload: DuplicateResolveIn, session=Depends(auth.require_full_auth)):
    """Entfernt die angegebenen Duplikate (Datei + Datenbankeintrag + damit
    verknüpfte Ausgaben-Buchung), behält nur den gewählten 'keep_id'-Beleg.
    Prüft vorher, dass alle wirklich zur selben Datei gehören — sonst könnte
    aus Versehen ein eigenständiger, richtiger Beleg mitgelöscht werden."""
    conn = get_connection()
    keep = conn.execute("SELECT file_hash FROM receipts WHERE id=?", (payload.keep_id,)).fetchone()
    if not keep:
        conn.close()
        raise HTTPException(404, "Zu behaltender Beleg nicht gefunden.")

    removed = 0
    for rid in payload.remove_ids:
        row = conn.execute("SELECT * FROM receipts WHERE id=?", (rid,)).fetchone()
        if not row or row["file_hash"] != keep["file_hash"]:
            continue  # gehört nicht zur selben Duplikat-Gruppe -> überspringen, nicht anfassen
        file_path = BASE_DIR / row["stored_path"]
        if file_path.exists():
            file_path.unlink()
        conn.execute("DELETE FROM expenses WHERE receipt_id=?", (rid,))
        conn.execute("UPDATE contracts SET last_receipt_id=NULL WHERE last_receipt_id=?", (rid,))
        conn.execute("DELETE FROM receipts WHERE id=?", (rid,))
        removed += 1
    conn.commit()
    conn.close()
    return {"removed": removed}


@router.post("/api/contracts/{contract_id}/bulk-upload-receipts")
async def bulk_upload_receipts(contract_id: int, files: List[UploadFile] = File(...),
                                session=Depends(auth.require_full_auth)):
    """Für den initialen Import eines ganzen Stapels alter Belege zu EINEM
    bereits ausgewählten Vertrag auf einmal — anders als der Einzel-Upload
    läuft hier keine OCR-basierte Vertragserkennung (der Vertrag steht ja
    schon fest) und der Vertragsbetrag wird NIE aktualisiert, auch nicht
    durch die zeitlich neueste Datei im Stapel. Ein Rückblick-Import soll
    keine Aussage über den AKTUELLEN Betrag treffen (gleiches Prinzip wie
    beim Gehaltsabrechnungs-Sammelimport)."""
    conn = get_connection()
    contract = conn.execute(
        """SELECT co.label, co.provider, co.subcategory, c.name AS category_name, fm.name AS person_name
           FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
           LEFT JOIN family_members fm ON fm.id = co.person_id
           WHERE co.id = ?""",
        (contract_id,),
    ).fetchone()
    if not contract:
        conn.close()
        raise HTTPException(404, "Vertrag nicht gefunden")

    parts = _contract_folder_parts(
        contract["category_name"], contract["subcategory"], contract["provider"],
        contract["label"], contract["person_name"],
    )
    final_dir = RECEIPTS_DIR.joinpath(*parts)
    final_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for file in files:
        content = await file.read()
        file_hash = hashlib.sha256(content).hexdigest()

        existing = conn.execute(
            "SELECT id FROM receipts WHERE contract_id=? AND file_hash=?", (contract_id, file_hash)
        ).fetchone()
        if existing:
            results.append({"receipt_id": existing["id"], "filename": file.filename, "skipped": True})
            continue

        safe_name = re.sub(r"[^\w.\-]", "_", file.filename or "beleg")
        stored_path = final_dir / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}_{safe_name}"
        stored_path.write_bytes(content)

        cur = conn.execute(
            """INSERT INTO receipts (original_filename, stored_path, file_hash, contract_id, review_needed)
               VALUES (?,?,?,?,0)""",
            (file.filename, str(stored_path.relative_to(BASE_DIR)), file_hash, contract_id),
        )
        results.append({"receipt_id": cur.lastrowid, "filename": file.filename, "skipped": False})

    conn.commit()
    conn.close()
    return {"status": "imported", "count": len(results), "results": results}


@router.post("/api/receipts/upload")
async def upload_receipt(file: UploadFile = File(...), session=Depends(auth.require_full_auth)):
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    file_hash = hashlib.sha256(content).hexdigest()

    conn = get_connection()

    # Jeder neue Upload verwirft automatisch alles, was von einem vorherigen
    # Upload noch offen/unbestätigt in der Maske stand — die Beleg-Maske ist
    # ein Zwischenspeicher, kein Ablageort: wer nicht auf "Bestätigen"
    # gedrückt hat, hat es damit implizit verworfen. Kein manueller
    # Aufräum-Knopf nötig, und die eben hochgeladene Datei kann dadurch nie
    # aus Versehen mitgelöscht werden (sie existiert ja noch gar nicht).
    _cleanup_unconfirmed_receipts(conn, max_age_hours=None)

    # Duplikat-Prüfung: wurde exakt diese Datei (byteidentisch) schon einmal
    # BESTÄTIGT importiert? Dann wird der Upload direkt blockiert statt nur
    # gewarnt — ein zweiter, unbestätigter Test-Upload wurde durch die
    # Bereinigung oben ohnehin gerade schon entfernt, kann hier also gar
    # nicht mehr als Duplikat auftauchen.
    existing = conn.execute(
        """SELECT r.id, r.uploaded_at, r.detected_amount, co.label AS contract_label
           FROM receipts r LEFT JOIN contracts co ON co.id = r.contract_id
           WHERE r.file_hash = ? AND r.review_needed = 0
           ORDER BY r.uploaded_at DESC LIMIT 1""",
        (file_hash,),
    ).fetchone()
    if existing:
        conn.close()
        target = f" und {existing['contract_label']!r} zugeordnet" if existing["contract_label"] else ""
        raise HTTPException(
            409,
            f"Diese exakte Datei wurde bereits am {existing['uploaded_at']} importiert{target}. "
            "Falls das wirklich ein zweiter, eigenständiger Beleg ist (z.B. eine neue, andere "
            "Rechnung), kann es nicht dieselbe Datei sein — bitte prüfen, ob die richtige Datei "
            "ausgewählt wurde.",
        )
    conn.close()

    today = datetime.now()
    safe_stem = re.sub(r"[^\w.-]", "_", Path(file.filename or "beleg").stem)[:80] or "beleg"
    suffix = Path(file.filename or "").suffix or ".jpg"
    filename = f"{today.strftime('%Y%m%d%H%M%S')}_{safe_stem}{suffix}"

    # Solange noch kein Vertrag zugeordnet ist (das passiert erst beim Bestätigen),
    # landet die Datei in einem Zwischenablage-Ordner nach bestem Kategorie-Tipp.
    tmp_path = RECEIPTS_DIR / "_unbestaetigt" / filename
    tmp_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path.write_bytes(content)

    # Lokale OCR-Erkennung (kein Cloud-Aufruf, siehe ocr.py). Schlägt sie fehl,
    # wird der Beleg trotzdem gespeichert — nur ohne automatische Erkennung.
    result = extract_receipt_data(tmp_path)

    conn = get_connection()
    cur = conn.execute(
        """INSERT INTO receipts
           (original_filename, stored_path, file_hash, ocr_text, detected_amount,
            detected_provider, detected_date, review_needed)
           VALUES (?,?,?,?,?,?,?,1)""",
        (file.filename, str(tmp_path.relative_to(BASE_DIR)), file_hash, result.get("raw_text"),
         result.get("amount"), result.get("provider"),
         result["date"].isoformat() if result.get("date") else None),
    )
    receipt_id = cur.lastrowid
    conn.commit()

    matched = _find_matching_contract(conn, result.get("provider"), result.get("contract_number"))
    conn.close()

    # Nur dort um Eingriff bitten, wo wirklich etwas unklar ist: fehlender
    # Betrag, oder keine eindeutige automatische Zuordnung möglich.
    needs_attention = []
    if result.get("amount") is None:
        needs_attention.append("Betrag")
    if not matched:
        needs_attention.append("Zuordnung zu einem Vertrag")

    if result.get("ocr_error"):
        note = result["ocr_error"] + " Der Beleg wurde trotzdem gespeichert — bitte Angaben manuell eintragen."
    elif needs_attention:
        note = "Bitte kurz prüfen: " + ", ".join(needs_attention) + "."
    else:
        note = f"Automatisch erkannt und {matched['label']!r} zugeordnet — bitte nur kurz bestätigen."

    return {
        "receipt_id": receipt_id,
        "stored_path": str(tmp_path.relative_to(BASE_DIR)),
        "detected": result,
        "matched_contract": matched,
        "needs_attention": needs_attention,
        "note": note,
    }


class ReceiptConfirmIn(BaseModel):
    contract_id: Optional[int] = None
    asset_id: Optional[int] = None       # Alternative zu contract_id: Beleg gehört zu einem
                                          # Vermögenswert (Kontoauszug, Depotauszug, Immobilie)
    pension_account_id: Optional[int] = None  # Alternative: Beleg gehört zu einem Rentenkonto
                                          # (Vorsorge) — landet dann in pension_documents statt receipts
    amount: Optional[float] = None       # überschreibt den erkannten Betrag, falls OCR falsch lag
    provider: Optional[str] = None
    contract_number: Optional[str] = None
    link: Optional[str] = None
    expense_date: Optional[date] = None
    update_expense: bool = True          # False = Beleg nur ablegen, keine Ausgabe/Betrag buchen
                                          # (z.B. reine Benachrichtigungen ohne Zahlung, wie eine
                                          # Zählerwechsel-Mitteilung)


@router.post("/api/receipts/{receipt_id}/confirm")
def confirm_receipt(receipt_id: int, payload: ReceiptConfirmIn,
                     session=Depends(auth.require_full_auth)):
    if not payload.contract_id and not payload.asset_id and not payload.pension_account_id:
        raise HTTPException(400, "Ein Beleg muss einem Vertrag, Vermögenswert oder Rentenkonto zugeordnet werden.")

    conn = get_connection()
    receipt = conn.execute("SELECT * FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")

    if payload.pension_account_id:
        # Rentenkonto-Dokumente leben in einer eigenen Tabelle
        # (pension_documents), nicht in receipts — die Datei wird dorthin
        # verschoben und die ursprüngliche receipts-Zeile entfernt, statt
        # nur ein Fremdschlüssel-Feld umzubiegen.
        account = conn.execute("SELECT id, current_value FROM pension_accounts WHERE id=?", (payload.pension_account_id,)).fetchone()
        if not account:
            conn.close()
            raise HTTPException(400, "Das zugeordnete Rentenkonto existiert nicht (mehr).")

        final_amount = payload.amount if payload.amount is not None else receipt["detected_amount"]
        old_path = BASE_DIR / receipt["stored_path"]
        PENSION_DOCS_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^\w.-]", "_", receipt["original_filename"] or "dokument")[:80]
        stored_name = f"{payload.pension_account_id}_{receipt['file_hash'][:10] if receipt['file_hash'] else 'x'}_{safe_name}"
        new_path = PENSION_DOCS_DIR / stored_name
        if old_path.exists():
            old_path.rename(new_path)

        conn.execute(
            "INSERT INTO pension_documents (pension_account_id, original_filename, stored_path, file_hash) VALUES (?,?,?,?)",
            (payload.pension_account_id, receipt["original_filename"], str(new_path.relative_to(BASE_DIR)), receipt["file_hash"]),
        )
        conn.execute("DELETE FROM receipts WHERE id=?", (receipt_id,))
        if payload.update_expense and final_amount is not None:
            conn.execute("UPDATE pension_accounts SET current_value=? WHERE id=?", (final_amount, payload.pension_account_id))
        conn.commit()
        conn.close()
        return {"status": "confirmed"}

    if payload.asset_id:
        asset = conn.execute("SELECT type, label FROM assets WHERE id=?", (payload.asset_id,)).fetchone()
        if not asset:
            conn.close()
            raise HTTPException(400, "Der zugeordnete Vermögenswert existiert nicht (mehr).")

        final_amount = payload.amount if payload.amount is not None else receipt["detected_amount"]
        stored_path = receipt["stored_path"]
        final_dir = RECEIPTS_DIR / "_vermoegen" / re.sub(r"[^\w\-]", "_", asset["label"])
        final_dir.mkdir(parents=True, exist_ok=True)
        old_path = BASE_DIR / stored_path
        new_path = final_dir / old_path.name
        if old_path.exists():
            old_path.rename(new_path)
            stored_path = str(new_path.relative_to(BASE_DIR))

        update_fields = {"asset_id": payload.asset_id, "review_needed": 0}
        conn.execute(
            "UPDATE receipts SET stored_path=?, asset_id=?, review_needed=0 WHERE id=?",
            (stored_path, payload.asset_id, receipt_id),
        )
        if payload.update_expense and final_amount is not None:
            conn.execute("UPDATE assets SET current_value=?, updated_at=? WHERE id=?",
                         (final_amount, datetime.now().isoformat(), payload.asset_id))
        conn.commit()
        conn.close()
        return {"status": "confirmed"}

    if not payload.contract_id:
        raise HTTPException(400, "Ein Beleg muss einem Vertrag zugeordnet werden.")

    conn = get_connection()
    receipt = conn.execute("SELECT * FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")

    contract_exists = conn.execute("SELECT 1 FROM contracts WHERE id=?", (payload.contract_id,)).fetchone()
    if not contract_exists:
        conn.close()
        raise HTTPException(400, "Der zugeordnete Vertrag existiert nicht (mehr).")

    final_amount = payload.amount if payload.amount is not None else (receipt["detected_amount"] or 0)
    final_provider = payload.provider or receipt["detected_provider"] or receipt["original_filename"]
    final_date = (payload.expense_date.isoformat() if payload.expense_date
                  else receipt["detected_date"] or date.today().isoformat())
    contract_id = payload.contract_id

    if payload.update_expense:
        conn.execute(
            """INSERT INTO expenses (contract_id, label, amount, date, receipt_id)
               VALUES (?,?,?,?,?)""",
            (contract_id, final_provider, final_amount, final_date, receipt_id),
        )

    stored_path = receipt["stored_path"]

    if contract_id:
        contract = conn.execute(
            """SELECT co.label, co.provider, co.subcategory, c.name AS category_name, fm.name AS person_name
               FROM contracts co LEFT JOIN categories c ON c.id = co.category_id
               LEFT JOIN family_members fm ON fm.id = co.person_id
               WHERE co.id = ?""",
            (contract_id,),
        ).fetchone()

        if contract:
            # Datei aus dem Zwischenablage-Ordner in die endgültige Struktur
            # verschieben: Rubrik (→ Unterrubrik bei Haus, → Person falls
            # zugeordnet) → ein Ordner pro Vertrag. Das passiert IMMER,
            # unabhängig von update_expense — ein Beleg soll beim richtigen
            # Vertrag abgelegt sein, auch wenn er keine Zahlung auslöst
            # (z.B. eine reine Benachrichtigung ohne Rechnungsbetrag).
            # Dieselbe Funktion wie beim Archivieren/Wiederherstellen, damit
            # es nur eine einzige Stelle mit dieser Logik gibt.
            parts = _contract_folder_parts(
                contract["category_name"], contract["subcategory"], contract["provider"],
                contract["label"], contract["person_name"],
            )

            final_dir = RECEIPTS_DIR.joinpath(*parts)
            final_dir.mkdir(parents=True, exist_ok=True)
            old_path = BASE_DIR / stored_path
            new_path = final_dir / old_path.name
            if old_path.exists():
                old_path.rename(new_path)
                stored_path = str(new_path.relative_to(BASE_DIR))

        # Vertragsnummer/Anbieter/Link sind reine Stammdaten-Korrekturen, unabhängig
        # von einer Zahlung — die werden immer übernommen, wenn mitgegeben. Ebenso
        # wird der Beleg immer als "letzter Beleg" hinterlegt (für den "📎 Beleg
        # ansehen"-Link), auch wenn er keine Zahlung auslöst — er soll ja trotzdem
        # auffindbar beim Vertrag liegen. Nur der Betrag selbst wird ausgespart,
        # wenn dieser Beleg keine echte Ausgabe darstellt (update_expense=False) —
        # sonst würde z.B. eine reine Zählerwechsel-Mitteilung ohne Rechnungsbetrag
        # den Vertragsbetrag überschreiben.
        update_fields = {"last_receipt_id": receipt_id}
        if payload.update_expense:
            update_fields["amount"] = final_amount
            update_fields["source"] = "foto"
        if payload.contract_number:
            update_fields["contract_number"] = payload.contract_number
        if payload.link:
            update_fields["link"] = payload.link
        if payload.provider:
            update_fields["provider"] = payload.provider
        update_fields["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k}=?" for k in update_fields)
        conn.execute(f"UPDATE contracts SET {set_clause} WHERE id=?",
                     (*update_fields.values(), contract_id))

    conn.execute("UPDATE receipts SET review_needed=0, contract_id=?, stored_path=? WHERE id=?",
                 (contract_id, stored_path, receipt_id))

    conn.commit()
    conn.close()
    return {"status": "confirmed"}


@router.get("/api/receipts/{receipt_id}/file")
def get_receipt_file(receipt_id: int, download: bool = False, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    receipt = conn.execute("SELECT stored_path, original_filename FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    conn.close()
    if not receipt:
        raise HTTPException(404, "Beleg nicht gefunden")
    file_path = BASE_DIR / receipt["stored_path"]
    if not file_path.exists():
        raise HTTPException(404, "Beleg-Datei fehlt auf der Festplatte")
    return FileResponse(
        file_path, filename=receipt["original_filename"] or file_path.name,
        content_disposition_type="attachment" if download else "inline",
    )


class ReceiptReassignIn(BaseModel):
    asset_id: int


@router.patch("/api/receipts/{receipt_id}/reassign-asset")
def reassign_receipt_asset(receipt_id: int, payload: ReceiptReassignIn,
                            session=Depends(auth.require_full_auth)):
    """Ordnet einen bereits hochgeladenen Beleg einem ANDEREN Vermögenswert
    zu — z.B. wenn beim Bestätigen versehentlich der falsche Vermögenswert
    gewählt wurde. Verschiebt auch die physische Datei in den Ordner des
    neuen Vermögenswerts, damit die Ablage konsistent bleibt."""
    conn = get_connection()
    receipt = conn.execute("SELECT stored_path FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")
    asset = conn.execute("SELECT label FROM assets WHERE id=?", (payload.asset_id,)).fetchone()
    if not asset:
        conn.close()
        raise HTTPException(400, "Der Ziel-Vermögenswert existiert nicht (mehr).")

    final_dir = RECEIPTS_DIR / "_vermoegen" / re.sub(r"[^\w\-]", "_", asset["label"])
    final_dir.mkdir(parents=True, exist_ok=True)
    old_path = BASE_DIR / receipt["stored_path"]
    new_path = final_dir / old_path.name
    stored_path = receipt["stored_path"]
    if old_path.exists():
        old_path.rename(new_path)
        stored_path = str(new_path.relative_to(BASE_DIR))

    conn.execute(
        "UPDATE receipts SET asset_id=?, stored_path=? WHERE id=?",
        (payload.asset_id, stored_path, receipt_id),
    )
    conn.commit()
    conn.close()
    return {"status": "reassigned"}


@router.delete("/api/receipts/{receipt_id}")
def delete_receipt(receipt_id: int, session=Depends(auth.require_full_auth)):
    """Entfernt einen einzelnen Beleg aus der 'Alle Belege'-Liste — Datei
    UND Datenbankeintrag. Die verknüpfte Ausgabe bleibt bewusst erhalten
    (der Beleg war nur ihr Nachweis, nicht ihre einzige Existenzgrundlage);
    nur die last_receipt_id-Referenz wird aufgeräumt, falls sie hierher zeigte."""
    conn = get_connection()
    receipt = conn.execute("SELECT stored_path FROM receipts WHERE id=?", (receipt_id,)).fetchone()
    if not receipt:
        conn.close()
        raise HTTPException(404, "Beleg nicht gefunden")
    file_path = BASE_DIR / receipt["stored_path"]
    file_path.unlink(missing_ok=True)
    conn.execute("UPDATE contracts SET last_receipt_id=NULL WHERE last_receipt_id=?", (receipt_id,))
    conn.execute("UPDATE expenses SET receipt_id=NULL WHERE receipt_id=?", (receipt_id,))
    conn.execute("DELETE FROM receipts WHERE id=?", (receipt_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}



# ---------- Intelligenter Datei-Import (CSV/XLSX/ODS, Ollama-gestützt) ----------

SMART_IMPORT_STAGING = BASE_DIR / "data" / "smart_import_staging"
SMART_IMPORT_TARGETS = ("expenses", "income", "contracts", "pv_monthly", "meter_readings", "assets")


def _validate_import_target(target: str):
    if target not in SMART_IMPORT_TARGETS:
        raise HTTPException(404, f"Unbekanntes Import-Ziel: {target}")


@router.post("/api/smart-import/{target}/analyze")
async def smart_import_analyze(target: str, file: UploadFile = File(...),
                                session=Depends(auth.require_full_auth)):
    _validate_import_target(target)
    content = await file.read()
    if not content:
        raise HTTPException(400, "Leere Datei — bitte erneut versuchen.")

    SMART_IMPORT_STAGING.mkdir(parents=True, exist_ok=True)
    suffix = Path(file.filename or "").suffix.lower() or ".csv"
    staging_id = hashlib.sha256(content + target.encode()).hexdigest()[:16]
    staging_path = SMART_IMPORT_STAGING / f"{staging_id}{suffix}"
    staging_path.write_bytes(content)

    df, err = smart_import.read_tabular_file(staging_path)
    if err:
        staging_path.unlink(missing_ok=True)
        raise HTTPException(400, err)

    columns = df.columns.tolist()
    sig = smart_import.header_signature(columns)
    sample_rows = json.loads(df.head(5).to_json(orient="records"))

    conn = get_connection()
    learned = conn.execute(
        "SELECT column_mapping FROM import_schemas WHERE target=? AND header_signature=?",
        (target, sig),
    ).fetchone()
    conn.close()

    if learned:
        mapping = json.loads(learned["column_mapping"])
        source = "learned"
    else:
        mapping, source = smart_import.guess_mapping(columns, sample_rows, target)

    return {
        "staging_id": staging_id + suffix,
        "columns": columns,
        "sample_rows": sample_rows,
        "row_count": len(df),
        "mapping": mapping,
        "mapping_source": source,
        "target_fields": smart_import.TARGET_FIELDS[target],
        "required_fields": smart_import.REQUIRED_FIELDS[target],
    }


class SmartImportConfirmIn(BaseModel):
    staging_id: str
    mapping: dict
    save_schema: bool = True
    meter_type: Optional[str] = None  # nur für target='meter_readings' nötig


@router.post("/api/smart-import/{target}/confirm")
def smart_import_confirm(target: str, payload: SmartImportConfirmIn,
                          session=Depends(auth.require_full_auth)):
    _validate_import_target(target)
    if target == "meter_readings":
        if payload.meter_type not in meters.METER_TYPES:
            raise HTTPException(400, "Für Zählerablesungen muss ein gültiger Zählertyp angegeben werden.")
    if not re.match(r"^[0-9a-f]{16}\.(csv|xlsx|xls|ods)$", payload.staging_id):
        raise HTTPException(400, "Ungültige Zwischenspeicher-Kennung.")
    staging_path = SMART_IMPORT_STAGING / payload.staging_id
    if not staging_path.exists():
        raise HTTPException(404, "Zwischengespeicherte Datei nicht gefunden — bitte erneut hochladen.")

    df, err = smart_import.read_tabular_file(staging_path)
    if err:
        raise HTTPException(400, err)

    rows, skipped = smart_import.apply_mapping(df, payload.mapping, target)

    conn = get_connection()

    def _resolve_category(name: Optional[str]) -> Optional[int]:
        if not name:
            return None
        row = conn.execute("SELECT id FROM categories WHERE name=?", (name,)).fetchone()
        if row:
            return row["id"]
        return conn.execute("INSERT INTO categories (name) VALUES (?)", (name,)).lastrowid

    imported = 0
    for item in rows:
        if target == "expenses":
            category_id = _resolve_category(item.get("category"))
            conn.execute(
                "INSERT INTO expenses (label, amount, category_id, date, note) VALUES (?,?,?,?,?)",
                (item["label"], item["amount"], category_id, item["date"], item.get("provider")),
            )
        elif target == "income":
            conn.execute(
                "INSERT INTO income (label, amount, frequency, active, source) VALUES (?,?,?,1,'import')",
                (item["label"], item["amount"], item.get("frequency") or "monthly"),
            )
        elif target == "contracts":
            category_id = _resolve_category(item.get("category"))
            conn.execute(
                """INSERT INTO contracts (label, provider, contract_number, category_id, amount,
                   frequency, contract_end, status) VALUES (?,?,?,?,?,?,?, 'active')""",
                (item["label"], item.get("provider"), item.get("contract_number"), category_id,
                 item["amount"], item.get("frequency") or "monthly", item.get("contract_end")),
            )
        elif target == "pv_monthly":
            # Nicht-destruktiv: Felder, die dieser Import gar nicht mitliefert
            # (z.B. weil "Netzbezug" nicht gemappt wurde), sollen bestehende
            # Werte NICHT auf 0 überschreiben — sonst würde ein reiner
            # PV+Einspeisung-Import versehentlich den Netzbezug löschen und
            # dadurch die Autarkiequote auf fälschlich 100% springen lassen.
            existing_pv = conn.execute(
                "SELECT pv, bezug, einsp, batt_lad, batt_ent, gesamt FROM pv_monthly WHERE key=?",
                (item["key"],),
            ).fetchone()

            def _keep_or_new(field):
                if item.get(field) is not None:
                    return item[field]
                return existing_pv[field] if existing_pv else 0

            conn.execute(
                """INSERT INTO pv_monthly (key, pv, bezug, einsp, batt_lad, batt_ent, gesamt)
                   VALUES (?,?,?,?,?,?,?)
                   ON CONFLICT(key) DO UPDATE SET pv=excluded.pv, bezug=excluded.bezug,
                     einsp=excluded.einsp, batt_lad=excluded.batt_lad, batt_ent=excluded.batt_ent,
                     gesamt=excluded.gesamt""",
                (item["key"], _keep_or_new("pv"), _keep_or_new("bezug"), item["einsp"],
                 _keep_or_new("batt_lad"), _keep_or_new("batt_ent"), _keep_or_new("gesamt")),
            )
        elif target == "meter_readings":
            existing = conn.execute(
                "SELECT id FROM meter_readings WHERE meter_type=? AND reading_date=?",
                (payload.meter_type, item["reading_date"]),
            ).fetchone()
            if existing:
                skipped += 1
                continue
            conn.execute(
                "INSERT INTO meter_readings (meter_type, reading_date, value) VALUES (?,?,?)",
                (payload.meter_type, item["reading_date"], item["value"]),
            )
        elif target == "assets":
            asset_type = (item.get("type") or "sonstiges").strip().lower()
            if asset_type not in ("konto", "depot", "immobilie", "sonstiges"):
                asset_type = "sonstiges"
            conn.execute(
                "INSERT INTO assets (type, label, provider, current_value) VALUES (?,?,?,?)",
                (asset_type, item["label"], item.get("provider"), item["current_value"]),
            )
        imported += 1

    if payload.save_schema:
        columns = df.columns.tolist()
        sig = smart_import.header_signature(columns)
        conn.execute(
            """INSERT INTO import_schemas (target, header_signature, column_mapping, use_count)
               VALUES (?,?,?,1)
               ON CONFLICT(target, header_signature) DO UPDATE SET
                 column_mapping=excluded.column_mapping,
                 use_count=use_count+1,
                 last_used_at=CURRENT_TIMESTAMP""",
            (target, sig, json.dumps(payload.mapping)),
        )

    conn.commit()
    conn.close()
    staging_path.unlink(missing_ok=True)

    return {"imported": imported, "skipped": skipped}


@router.get("/api/smart-import/schemas")
def list_import_schemas(session=Depends(auth.require_full_auth)):
    """Übersicht der gelernten Datei-Zuordnungen — z.B. um sie bei Bedarf zu löschen."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT id, target, header_signature, column_mapping, label, use_count, last_used_at "
        "FROM import_schemas ORDER BY last_used_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.delete("/api/smart-import/schemas/{schema_id}")
def delete_import_schema(schema_id: int, session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM import_schemas WHERE id=?", (schema_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}


