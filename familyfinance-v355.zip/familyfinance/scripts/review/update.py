"""App-Selbst-Update (maintenance.check_app_update / apply_app_update, app._apply_all_updates). Ohne Server, ohne Netz,
Sekunden.
    cd kopie/backend && python3 ../scripts/review/update.py
Exit-Code 0 = alles grün.

Netzaufrufe (urllib.request.urlopen) werden durch ein Fälschungs-Manifest und lokal erzeugte Test-ZIPs ersetzt,
restart_service durch einen Zähler. Gearbeitet wird ausschließlich in temporären Ordnern (eigener App-Ordner je Fall,
eigene Datenbank); data/ der Kopie und der echte App-Ordner werden nie angefasst.

Fälle:
 1) Manifest: Plattform-Eintrag, Versionsvergleich, Netzfehler -> Fehlermeldung statt Absturz.
 2) Falscher / fehlender SHA-256 -> abgelehnt, nichts installiert, kein Neustart.
 3) Zip-Slip (../x, absolute Pfade, verschachteltes ../../, Symlink-Eintrag) -> nichts außerhalb des App-Ordners.
 4) Fremde Download-Adresse (http, fremder Host, Host-Anhängsel, Benutzerteil, anderes Repo, ../ im Pfad, auch
    %-kodiert) -> abgelehnt, ohne dass überhaupt etwas heruntergeladen wird.
 5) Adresse/Prüfsumme aus der Anfrage werden ignoriert (nur das Manifest zählt), auch über den öffentlichen Endpunkt.
 6) Gültiges Paket -> eingespielt, data/ und scripts/ bleiben unangetastet, genau ein Neustart.
 7) Kaputtes ZIP mit passender Prüfsumme -> sauber abgelehnt.

Nicht ohne echtes Netz prüfbar (nur Hinweis): Weiterleitungen (GitHub leitet Release-Downloads auf
objects/release-assets.githubusercontent.com um; urllib folgt Weiterleitungen zu JEDEM Host -- abgesichert ist das
allein durch die Prüfsumme aus dem Manifest), echtes TLS/Zertifikat, Zeitüberschreitungen.
"""
import hashlib
import io
import json
import os
import shutil
import stat
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))

TMP = Path(tempfile.mkdtemp(prefix="ff_update_"))
(TMP / "dbapp" / "data").mkdir(parents=True)

import database  # noqa: E402
import maintenance  # noqa: E402

# Datenbank vorsichtshalber umbiegen, falls beim Import von app.py etwas angelegt wird.
database.BASE_DIR = TMP / "dbapp"
database.DB_PATH = TMP / "dbapp" / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "dbapp" / "data" / "demo.db"

ORIG_BASE = maintenance.BASE_DIR
ORIG_URLOPEN = urllib.request.urlopen
ORIG_RESTART = maintenance.restart_service
ORIG_CHECK = maintenance.check_app_update

GOOD_URL = "https://github.com/Dane03/familyfinance-releases/releases/download/v999/familyfinance-mac.zip"

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


# ---------- Fälschungen ----------
class FakeResp(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


NET = {"payload": b"", "calls": [], "error": None}
RESTARTS = []


def fake_urlopen(req, timeout=None):
    url = req.full_url if hasattr(req, "full_url") else req
    NET["calls"].append(url)
    if NET["error"]:
        raise NET["error"]
    return FakeResp(NET["payload"])


def serve(payload: bytes):
    NET["payload"], NET["calls"], NET["error"] = payload, [], None


urllib.request.urlopen = fake_urlopen
maintenance.restart_service = lambda delay_seconds=1.5: RESTARTS.append(1) or {"status": "restarting"}


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def make_zip(entries: dict, symlinks: dict = None) -> bytes:
    """entries: Name im ZIP -> Inhalt. Namen werden UNVERÄNDERT eingetragen (auch ../ und /absolut)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data in entries.items():
            zf.writestr(zipfile.ZipInfo(name), data)
        for name, target in (symlinks or {}).items():
            zi = zipfile.ZipInfo(name)
            zi.external_attr = (stat.S_IFLNK | 0o777) << 16
            zf.writestr(zi, target)
    return buf.getvalue()


def make_app(root: Path) -> Path:
    """Minimaler App-Ordner mit echten Daten, die ein Update nie berühren darf."""
    app = root / "app"
    (app / "backend").mkdir(parents=True)
    (app / "frontend").mkdir()
    (app / "data").mkdir()
    (app / "scripts").mkdir()
    (app / "backend" / "app.py").write_text("ALT")
    (app / "frontend" / "app.js").write_text('const APP_BUILD = "Build 2026-01-01 · v100";')
    (app / "data" / "finance.db").write_text("ECHTE DATEN")
    (app / "scripts" / "eigen.sh").write_text("EIGEN")
    return app


def snapshot(folder: Path) -> dict:
    out = {}
    for p in sorted(folder.rglob("*")):
        rel = str(p.relative_to(folder))
        if p.is_symlink():
            out[rel] = "LINK->" + os.readlink(p)
        elif p.is_file():
            out[rel] = p.read_bytes()
        else:
            out[rel] = "DIR"
    return out


def case_dir(name: str) -> Path:
    d = TMP / name
    d.mkdir()
    return d


try:
    # ---------- 1) Manifest ----------
    root = case_dir("c1")
    maintenance.BASE_DIR = make_app(root)
    manifest = {"version": "v999", "notes": "Test",
                "platforms": {"mac": {"download_url": GOOD_URL, "sha256": "ab" * 32},
                              "windows": {"download_url": GOOD_URL.replace("mac", "win"), "sha256": "cd" * 32}}}
    serve(json.dumps(manifest).encode())
    info = maintenance.check_app_update()
    check("1 aktuelle Version aus app.js", info.get("current_version"), "v100")
    check("1 Update erkannt (v999 > v100)", info.get("update_available"), True)
    check("1 Download-Adresse aus dem Manifest", info.get("download_url") in (GOOD_URL, GOOD_URL.replace("mac", "win")),
          True)
    check("1 Manifest von der festen Adresse geholt", NET["calls"], [maintenance.UPDATE_MANIFEST_URL])
    serve(json.dumps({"version": "v50", "platforms": {}}).encode())
    check("1 ältere Version ist kein Update", maintenance.check_app_update().get("update_available"), False)
    NET["error"] = urllib.error.URLError("kein Netz")
    info = maintenance.check_app_update()
    check("1 Netzfehler -> Fehlermeldung statt Absturz", "error" in info and not info.get("update_available"), True)
    NET["error"] = None
    serve(b"<html>kein json</html>")
    check("1 kaputtes Manifest -> Fehlermeldung", "error" in maintenance.check_app_update(), True)

    # ---------- 2) falscher / fehlender SHA-256 ----------
    good_zip = make_zip({"familyfinance/backend/app.py": "NEU", "familyfinance/frontend/app.js": "NEU-JS"})
    for label, digest in [("falsch", "0" * 64), ("fehlt", ""), ("None", None),
                          ("Prüfsumme eines anderen Pakets", sha(b"anderes"))]:
        root = case_dir(f"c2_{label.replace(' ', '_')}")
        app = make_app(root)
        maintenance.BASE_DIR = app
        before = snapshot(root)
        RESTARTS.clear()
        serve(good_zip)
        r = maintenance.apply_app_update(GOOD_URL, digest)
        check(f"2 SHA {label}: abgelehnt", r.get("status"), "error")
        check(f"2 SHA {label}: nichts installiert", snapshot(root) == before, True)
        check(f"2 SHA {label}: kein Neustart", len(RESTARTS), 0)

    # ---------- 3) Zip-Slip ----------
    root = case_dir("c3")
    app = make_app(root)
    maintenance.BASE_DIR = app
    outside_abs = root / "absolut_draussen.txt"
    slip_zip = make_zip({
        "familyfinance/backend/app.py": "NEU",
        "../draussen1.txt": "PWN",
        "../../draussen2.txt": "PWN",
        "familyfinance/../../draussen3.txt": "PWN",
        "familyfinance/backend/../../../draussen4.txt": "PWN",
        str(outside_abs): "PWN",
        "..\\draussen5.txt": "PWN",
    }, symlinks={"familyfinance/link_raus": str(root)})
    before_outside = {k: v for k, v in snapshot(root).items() if not k.startswith("app")}
    RESTARTS.clear()
    serve(slip_zip)
    r = maintenance.apply_app_update(GOOD_URL, sha(slip_zip))   # Manifest gilt hier als kompromittiert
    after_outside = {k: v for k, v in snapshot(root).items() if not k.startswith("app")}
    check("3 nichts neben dem App-Ordner geschrieben", sorted(set(after_outside) - set(before_outside)), [])
    check("3 absoluter Pfad nicht geschrieben", outside_abs.exists(), False)
    links = [str(p.relative_to(app)) for p in app.rglob("*") if p.is_symlink()]
    check("3 kein Symlink im App-Ordner angelegt", links, [])
    escaped = [str(p) for p in app.rglob("*") if not p.resolve().is_relative_to(app.resolve())]
    check("3 alles liegt innerhalb des App-Ordners", escaped, [])
    check("3 echte Daten unangetastet", (app / "data" / "finance.db").read_text(), "ECHTE DATEN")
    print(f"  (Ergebnis Zip-Slip-Paket: {r.get('status')})")

    # ---------- 4) fremde Download-Adresse ----------
    bad_urls = [
        "http://github.com/Dane03/familyfinance-releases/releases/download/v999/x.zip",
        "https://evil.example/Dane03/familyfinance-releases/x.zip",
        "https://github.com.evil.example/Dane03/familyfinance-releases/x.zip",
        "https://evilgithub.com/Dane03/familyfinance-releases/x.zip",
        "https://github.com@evil.example/Dane03/familyfinance-releases/x.zip",
        "https://github.com/Fremder/familyfinance-releases/releases/download/v999/x.zip",
        "https://github.com/Dane03/familyfinance/archive/master.zip",
        "https://github.com/Dane03/familyfinance-releases-fake/x.zip",
        "https://raw.githubusercontent.com/Dane03/familyfinance-releases/../../Fremder/repo/main/x.zip",
        "https://raw.githubusercontent.com/Dane03/familyfinance-releases/main/../../../Fremder/repo/main/x.zip",
        "https://raw.githubusercontent.com/Dane03/familyfinance-releases/%2e%2e/%2E%2E/Fremder/repo/main/x.zip",
        "https://raw.githubusercontent.com/Dane03/familyfinance-releases/main/..%2f..%2f..%2fFremder/x.zip",
        "https://raw.githubusercontent.com/Dane03/familyfinance-releases/%252e%252e/%252e%252e/Fremder/x.zip",
        "https://raw.githubusercontent.com/Dane03/familyfinance-releases/main/..\\..\\..\\Fremder/x.zip",
        "file:///etc/passwd",
        "",
    ]
    root = case_dir("c4")
    app = make_app(root)
    maintenance.BASE_DIR = app
    before = snapshot(root)
    for u in bad_urls:
        serve(good_zip)
        RESTARTS.clear()
        r = maintenance.apply_app_update(u, sha(good_zip))
        check(f"4 abgelehnt: {u or '(leer)'}", (r.get("status"), NET["calls"], len(RESTARTS)), ("error", [], 0))
    check("4 nichts installiert", snapshot(root) == before, True)

    # ---------- 5) Adresse/Prüfsumme aus der Anfrage zählen nicht ----------
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        client = TestClient(app_module.app, base_url="http://localhost:8420")
        seen = []
        orig_apply = maintenance.apply_app_update
        maintenance.apply_app_update = lambda url, digest: seen.append((url, digest)) or {"status": "applied"}
        maintenance.check_app_update = lambda: {"update_available": True, "download_url": GOOD_URL,
                                                "sha256": "ab" * 32}
        evil = {"apply_app": True, "download_url": "https://evil.example/x.zip", "sha256": "ee" * 32}
        resp = client.post("/api/public/apply-updates", json=evil)
        check("5 öffentlicher Endpunkt: Status 200", resp.status_code, 200)
        check("5 öffentlicher Endpunkt: nur Manifest-Adresse/Prüfsumme", seen, [(GOOD_URL, "ab" * 32)])
        seen.clear()
        app_module._apply_all_updates(app_module.ApplyAllUpdatesIn(**evil), allow_packages=False)
        check("5 _apply_all_updates: nur Manifest-Adresse/Prüfsumme", seen, [(GOOD_URL, "ab" * 32)])
        seen.clear()
        maintenance.check_app_update = lambda: {"update_available": True, "download_url": GOOD_URL, "sha256": None}
        r = app_module._apply_all_updates(app_module.ApplyAllUpdatesIn(**evil), allow_packages=False)
        check("5 Manifest ohne Prüfsumme -> kein Einspielen (auch nicht mit der aus der Anfrage)",
              (r.get("status"), seen), ("error", []))
        maintenance.check_app_update = lambda: {"update_available": False, "download_url": GOOD_URL,
                                                "sha256": "ab" * 32}
        r = app_module._apply_all_updates(app_module.ApplyAllUpdatesIn(**evil), allow_packages=False)
        check("5 kein Update verfügbar -> nichts eingespielt (kein Downgrade)", (r.get("status"), seen), ("error", []))
        resp = client.post("/api/public/apply-updates", json={"apply_packages": True})
        check("5 öffentlich: Pakete nicht ohne Login", (resp.json().get("status"), seen), ("error", []))
        # Ende-zu-Ende über das gefälschte Manifest: fremde Adresse im Manifest -> abgelehnt
        maintenance.apply_app_update = orig_apply
        maintenance.check_app_update = ORIG_CHECK
        root = case_dir("c5")
        app = make_app(root)
        maintenance.BASE_DIR = app
        before = snapshot(root)
        serve(json.dumps({"version": "v999", "platforms": {
            k: {"download_url": "https://evil.example/x.zip", "sha256": sha(good_zip)} for k in ("mac", "windows")}})
            .encode())
        RESTARTS.clear()
        r = app_module._apply_all_updates(app_module.ApplyAllUpdatesIn(apply_app=True), allow_packages=False)
        check("5 fremde Adresse im Manifest -> abgelehnt",
              (r.get("status"), NET["calls"], len(RESTARTS)), ("error", [maintenance.UPDATE_MANIFEST_URL], 0))
        check("5 fremde Adresse im Manifest -> nichts installiert", snapshot(root) == before, True)
    except ImportError as e:
        print(f"✗ 5 nicht ausführbar: {e}")
        FAILS.append("5 import")
    finally:
        maintenance.check_app_update = ORIG_CHECK

    # ---------- 6) gültiges Paket ----------
    root = case_dir("c6")
    app = make_app(root)
    maintenance.BASE_DIR = app
    pkg = make_zip({
        "familyfinance/backend/app.py": "NEU",
        "familyfinance/backend/neu.py": "NEU2",
        "familyfinance/frontend/app.js": 'const APP_BUILD = "Build 2026-10-27 · v999";',
        "familyfinance/data/finance.db": "ÜBERSCHRIEBEN",
        "familyfinance/scripts/eigen.sh": "ÜBERSCHRIEBEN",
        "familyfinance/backend/__pycache__/x.pyc": "MÜLL",
        "familyfinance/update.command": "ÜBERSCHRIEBEN",
    })
    RESTARTS.clear()
    serve(pkg)
    r = maintenance.apply_app_update(GOOD_URL, sha(pkg).upper())   # Groß-/Kleinschreibung der Prüfsumme egal
    check("6 gültiges Paket: eingespielt", r.get("status"), "applied")
    check("6 Download von der Manifest-Adresse", NET["calls"], [GOOD_URL])
    check("6 backend/app.py ersetzt", (app / "backend" / "app.py").read_text(), "NEU")
    check("6 neue Datei angelegt", (app / "backend" / "neu.py").read_text(), "NEU2")
    check("6 neue Version danach erkannt", maintenance._current_app_version(), "v999")
    check("6 data/ unangetastet", (app / "data" / "finance.db").read_text(), "ECHTE DATEN")
    check("6 scripts/ unangetastet", (app / "scripts" / "eigen.sh").read_text(), "EIGEN")
    check("6 kein update.command eingespielt", (app / "update.command").exists(), False)
    check("6 genau ein Neustart", len(RESTARTS), 1)
    # ZIP ohne Wurzelordner funktioniert ebenso
    root = case_dir("c6b")
    app = make_app(root)
    maintenance.BASE_DIR = app
    flat = make_zip({"backend/app.py": "FLACH", "data/finance.db": "ÜBERSCHRIEBEN"})
    serve(flat)
    r = maintenance.apply_app_update(GOOD_URL, sha(flat))
    check("6 ZIP ohne Wurzelordner: eingespielt",
          (r.get("status"), (app / "backend" / "app.py").read_text(), (app / "data" / "finance.db").read_text()),
          ("applied", "FLACH", "ECHTE DATEN"))

    # ---------- 7) kaputtes ZIP ----------
    root = case_dir("c7")
    app = make_app(root)
    maintenance.BASE_DIR = app
    before = snapshot(root)
    junk = b"PK\x03\x04 das ist kein ZIP"
    RESTARTS.clear()
    serve(junk)
    r = maintenance.apply_app_update(GOOD_URL, sha(junk))
    check("7 kaputtes ZIP: abgelehnt, nichts installiert, kein Neustart",
          (r.get("status"), snapshot(root) == before, len(RESTARTS)), ("error", True, 0))
    NET["error"] = OSError("Verbindung abgebrochen")
    r = maintenance.apply_app_update(GOOD_URL, sha(junk))
    check("7 Download-Abbruch: abgelehnt", r.get("status"), "error")
    NET["error"] = None
finally:
    urllib.request.urlopen = ORIG_URLOPEN
    maintenance.restart_service = ORIG_RESTART
    maintenance.check_app_update = ORIG_CHECK
    maintenance.BASE_DIR = ORIG_BASE
    shutil.rmtree(TMP, ignore_errors=True)

print()
print("Hinweis (nicht ohne echtes Netz prüfbar): Weiterleitungen beim Download (urllib folgt ihnen zu jedem Host; "
      "Schutz dort allein über die Manifest-Prüfsumme), echtes TLS, Zeitüberschreitungen.")
print("ALLES GRÜN" if not FAILS else f"{len(FAILS)} FEHLER: {FAILS}")
sys.exit(1 if FAILS else 0)
