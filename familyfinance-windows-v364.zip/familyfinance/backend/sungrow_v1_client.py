"""
Client für die offizielle iSolarCloud Open API im Modus "V1" (ohne OAuth).

Warum dieser Weg: Beim OAuth-Weg scheiterte die Freigabe der Anlage an der
Meldung "Diese Anlage wurde bereits freigegeben" (vermutlich eine noch beim
Installateur-Konto hängende Zuordnung). Der V1-Modus kennt diesen
Freigabeschritt gar nicht -- die App meldet sich direkt mit App Key, Secret
Key und den Owner-Zugangsdaten an.

Aufgebaut nach einer öffentlich einsehbaren, im Betrieb funktionierenden
Referenzimplementierung (github.com/jsanchezdelvillar/Sungrow-API): gleiche
Endpunkte, Header, Payload-Felder und Verschlüsselung. Zwei Varianten:
- ohne RSA-Schlüssel: Klartext-JSON
- mit RSA-Schlüssel (aus dem Entwicklerportal): Body AES-verschlüsselt, der
  zufällige AES-Schlüssel RSA-verschlüsselt im Header "x-random-secret-key"

SCHUTZ VOR KONTOSPERRE (Lehre aus dem alten Passwort-Weg): Das Passwort wird
nur für den Login benutzt, danach wird der Token wiederverwendet. Ein
fehlgeschlagener Login wird NIE automatisch wiederholt -- das entscheidet der
Aufrufer (siehe energy_routes: 'login_blocked').
"""
import base64
import json
import random
import string
import time

import httpx
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7

BASE_URL = "https://gateway.isolarcloud.eu"
TIMEOUT = 20.0

# Messpunkte des "Anlagen"-Geräts (device_type 11) laut Referenz -- alles
# TAGESwerte in Wh, die um Mitternacht auf 0 zurückspringen.
POINT_PV_TODAY = "83022"        # PV-Ertrag heute
POINT_EXPORT_TODAY = "83072"    # Einspeisung heute
POINT_IMPORT_TODAY = "83102"    # Netzbezug heute
# Hausverbrauch heute ("Use Energy", Anlagenebene) -- dokumentiert u.a. in
# GoSungrow. Berücksichtigt die Batterie, anders als die Rechnung
# PV - Einspeisung + Bezug (die lag im Test 2,4 kWh = 11 % zu hoch, genau um
# die netto in die Batterie geladene Energie). Liefert eine Anlage den Punkt
# nicht, bleibt die Rechnung als Rückfall.
POINT_LOAD_TODAY = "83118"
BATTERY_HEADROOM_KWH = 50   # Spielraum über PV + Netzbezug für Batterie-Entladung (v364)


class SungrowV1Error(Exception):
    pass


class SungrowLoginError(SungrowV1Error):
    """Login abgelehnt -- darf NICHT automatisch wiederholt werden."""


class SungrowTokenExpired(SungrowV1Error):
    """Token ungültig/abgelaufen -- ein erneuter Login ist sinnvoll."""


# ---------- Verschlüsselung (nur wenn ein RSA-Schlüssel hinterlegt ist) ----------

def _random_string(length: int) -> str:
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))


def _rsa_encrypt(text: str, public_key_b64: str) -> str:
    key_bytes = base64.urlsafe_b64decode(public_key_b64.strip() + "=" * (-len(public_key_b64.strip()) % 4))
    public_key = serialization.load_der_public_key(key_bytes, backend=default_backend())
    chunk = public_key.public_numbers().n.bit_length() // 8 - 11
    data = text.encode("utf-8")
    encrypted = b"".join(
        public_key.encrypt(data[i:i + chunk], padding.PKCS1v15()) for i in range(0, len(data), chunk)
    )
    return base64.urlsafe_b64encode(encrypted).decode("utf-8")


def _aes_key(secret: str) -> bytes:
    return secret.encode("utf-8").ljust(16)[:16]


def _aes_encrypt(text: str, secret: str) -> str:
    padder = PKCS7(128).padder()
    padded = padder.update(text.encode("utf-8")) + padder.finalize()
    enc = Cipher(algorithms.AES(_aes_key(secret)), modes.ECB(), backend=default_backend()).encryptor()
    return (enc.update(padded) + enc.finalize()).hex().upper()


def _aes_decrypt(hex_text: str, secret: str) -> str:
    dec = Cipher(algorithms.AES(_aes_key(secret)), modes.ECB(), backend=default_backend()).decryptor()
    padded = dec.update(bytes.fromhex(hex_text.strip())) + dec.finalize()
    unpadder = PKCS7(128).unpadder()
    return (unpadder.update(padded) + unpadder.finalize()).decode("utf-8")


def _post(path: str, payload: dict, access_key: str, rsa_public: str | None, token: str | None = None) -> dict:
    headers = {
        "User-Agent": "FamilyFinance",
        "x-access-key": access_key,
        "Content-Type": "application/json",
        "sys_code": "901",
    }
    if token:
        headers["token"] = token
    url = f"{BASE_URL}{path}"
    with httpx.Client(timeout=TIMEOUT) as client:
        if rsa_public:
            secret = _random_string(16)
            headers["x-random-secret-key"] = _rsa_encrypt(secret, rsa_public)
            payload = {**payload, "api_key_param": {"nonce": _random_string(32), "timestamp": str(int(time.time() * 1000))}}
            r = client.post(url, headers=headers, content=_aes_encrypt(json.dumps(payload), secret))
            if r.status_code == 401:
                raise SungrowTokenExpired("Token abgelaufen (HTTP 401).")
            r.raise_for_status()
            try:
                return json.loads(_aes_decrypt(r.text, secret))
            except ValueError:
                return r.json()  # manche Fehlerantworten kommen unverschlüsselt
        r = client.post(url, headers=headers, json=payload)
        if r.status_code == 401:
            raise SungrowTokenExpired("Token abgelaufen (HTTP 401).")
        r.raise_for_status()
        return r.json()


# ---------- Öffentliche Funktionen ----------

def login(appkey: str, access_key: str, rsa_public: str | None, account: str, password: str) -> str:
    """Genau EIN Login-Versuch. Gibt den Token zurück oder wirft
    SungrowLoginError mit der Originalmeldung von Sungrow."""
    payload = {"appkey": appkey, "user_account": account, "user_password": password}
    if rsa_public:
        payload["login_type"] = "1"
    data = _post("/openapi/login", payload, access_key, rsa_public)
    if data.get("result_code") != "1":
        raise SungrowLoginError(data.get("result_msg") or f"Login abgelehnt (Code {data.get('result_code')}).")
    result = data.get("result_data") or {}
    if str(result.get("login_state")) != "1" or not result.get("token"):
        msg = result.get("msg") or result.get("login_state_msg") or "Login abgelehnt."
        raise SungrowLoginError(str(msg))
    return result["token"]


def _check_token_response(data: dict):
    code = str(data.get("result_code"))
    if code == "1":
        return
    msg = str(data.get("result_msg") or "")
    if "token" in msg.lower() or code in ("E00003", "er_token_login_invalid"):
        raise SungrowTokenExpired(msg or "Token ungültig.")
    raise SungrowV1Error(msg or f"Fehler (Code {code}).")


def get_plants(appkey: str, access_key: str, rsa_public: str | None, token: str) -> list:
    """Anlagenliste -- dient nur der automatischen Erkennung der Anlagen-ID.
    Schlägt der Aufruf fehl, kann die ID weiterhin manuell eingetragen werden."""
    data = _post("/openapi/getPowerStationList", {"appkey": appkey, "curPage": 1, "size": 50}, access_key, rsa_public, token)
    _check_token_response(data)
    result = data.get("result_data") or {}
    return result.get("pageList") or result.get("list") or []


def get_today_values(appkey: str, access_key: str, rsa_public: str | None, token: str, ps_id: str) -> dict:
    """Heutige Tageswerte der Anlage in kWh: pv, einsp, bezug."""
    payload = {
        "appkey": appkey,
        "device_type": 11,
        "point_id_list": [POINT_PV_TODAY, POINT_EXPORT_TODAY, POINT_IMPORT_TODAY, POINT_LOAD_TODAY],
        "ps_key_list": [f"{ps_id}_11_0_0"],
    }
    data = _post("/openapi/getDeviceRealTimeData", payload, access_key, rsa_public, token)
    _check_token_response(data)
    points = ((data.get("result_data") or {}).get("device_point_list") or [{}])[0].get("device_point") or {}

    def kwh(point_id: str) -> float:
        raw = points.get(f"p{point_id}")
        try:
            return round(float(raw) / 1000.0, 3)
        except (TypeError, ValueError):
            return 0.0

    if not points:
        raise SungrowV1Error("Keine Messwerte erhalten — Anlagen-ID prüfen.")
    pv, einsp, bezug = kwh(POINT_PV_TODAY), kwh(POINT_EXPORT_TODAY), kwh(POINT_IMPORT_TODAY)
    verbrauch, verbrauch_note = None, "Sungrow liefert den Punkt nicht"
    if points.get(f"p{POINT_LOAD_TODAY}") not in (None, "", "--"):
        v = kwh(POINT_LOAD_TODAY)
        # Plausibilität nur gegen grob falsche Skalierung (z. B. Faktor 1000). Bis v363 lag die Grenze bei
        # PV + Netz + 1 kWh -- morgens deckt aber die Batterie die Nacht, der echte Verbrauch liegt dann
        # um die entladene Energie darüber, und der richtige Wert wurde verworfen. Großzügiger Spielraum
        # für die Batterie (Heimspeicher < 50 kWh).
        if 0 <= v <= pv + bezug + BATTERY_HEADROOM_KWH:
            verbrauch, verbrauch_note = v, None
        else:
            verbrauch_note = f"Sungrow-Wert {v} kWh unplausibel"
    return {"pv": pv, "einsp": einsp, "bezug": bezug, "verbrauch": verbrauch, "verbrauch_note": verbrauch_note,
            "device_date": device_date_of(points.get("device_time"))}


def device_date_of(raw) -> str | None:
    """Datum (JJJJ-MM-TT) aus `device_time` der Echtzeitantwort, Format
    JJJJMMTTHHMMSS in Anlagen-Ortszeit (Beispielantwort u. a. im Java-Client
    Afrouper/sungrow-api-client). Fehlt oder passt es nicht → None."""
    s = str(raw or "").strip()
    if len(s) < 8 or not s[:8].isdigit():
        return None
    try:
        from datetime import date as _date
        return _date(int(s[:4]), int(s[4:6]), int(s[6:8])).isoformat()
    except ValueError:
        return None


def get_day_totals(appkey: str, access_key: str, rsa_public: str | None, token: str, ps_id: str, day) -> dict:
    """Tageswerte eines VERGANGENEN Tages aus den Minutenwerten kurz vor
    Mitternacht. p83118 (Hausverbrauch) & Co. sind Tageszähler, die bis 24 Uhr
    steigen -- der letzte Wert des Tages ist der Tageswert. Ein kurzes Fenster
    genügt; laut pysolarcloud liefern Fenster über ~3 h ohnehin unvollständige
    Reihen. Einheiten kommen aus dem mitgelieferten Punkt-Verzeichnis.
    Ergebnis in kWh, fehlende Punkte als None."""
    points = [POINT_PV_TODAY, POINT_EXPORT_TODAY, POINT_IMPORT_TODAY, POINT_LOAD_TODAY]
    payload = {
        "appkey": appkey, "ps_id_list": [str(ps_id)], "points": ",".join("p" + p for p in points),
        "is_get_point_dict": "1", "minute_interval": "5",
        "start_time_stamp": day.strftime("%Y%m%d") + "223000",
        "end_time_stamp": day.strftime("%Y%m%d") + "235959",
    }
    data, last_err = None, None
    # Nicht-OAuth-Variante zuerst (wie bei allen unseren V1-Aufrufen), sonst /platform
    for path in ("/openapi/getPowerStationPointMinuteDataList", "/openapi/platform/getPowerStationPointMinuteDataList"):
        try:
            data = _post(path, payload, access_key, rsa_public, token)
        except SungrowTokenExpired:
            raise
        except Exception as e:
            last_err, data = e, None
            continue
        if str(data.get("result_code")) == "1":
            break
        msg = str(data.get("result_msg") or "")
        if "token" in msg.lower():
            raise SungrowTokenExpired(msg)
        last_err, data = SungrowV1Error(msg or f"Code {data.get('result_code')}"), None
    if data is None:
        raise SungrowV1Error(f"Verlaufsdaten nicht abrufbar: {last_err}")
    result = data.get("result_data") or {}
    units = {str(p.get("point_id")): str(p.get("point_unit") or p.get("unit") or "").lower()
             for p in (result.get("point_dict") or []) if isinstance(p, dict)}
    frames = result.get(str(ps_id)) or next((v for k, v in result.items() if k != "point_dict" and isinstance(v, list)), [])
    frames = sorted((f for f in frames if isinstance(f, dict)), key=lambda f: f.get("time_stamp", ""))

    def last_value(point_id):
        for f in reversed(frames):
            raw = f.get("p" + point_id)
            try:
                v = float(raw)
            except (TypeError, ValueError):
                continue
            unit = units.get(point_id, "wh")
            return round(v if unit == "kwh" else v / 1000.0, 3)
        return None

    return {"pv": last_value(POINT_PV_TODAY), "einsp": last_value(POINT_EXPORT_TODAY),
            "bezug": last_value(POINT_IMPORT_TODAY), "verbrauch": last_value(POINT_LOAD_TODAY)}
