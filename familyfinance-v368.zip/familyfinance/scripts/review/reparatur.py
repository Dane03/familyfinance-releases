"""Einmal-Reparatur v366: verwaiste Vermögens-Dokumente wieder zuordnen, hängende Einträge vorsichtig aufräumen.
Ohne Server, Sekunden.
    cd kopie/backend && python3 ../scripts/review/reparatur.py
Exit-Code 0 = alles grün. Arbeitet nur in einem Temp-Ordner.

Nachgestellt nach Benjamins Dateiabgleich (29.10.2026): Kontoauszüge im Ordner eines Vermögenswerts ohne Eintrag,
ein bestätigter Beleg und eine Gehaltsabrechnung ohne Datei.

Fälle:
 1) Datei im eindeutigen Ordner eines Vermögenswerts ohne Eintrag -> Eintrag angelegt (asset_id, Prüfsumme,
    bestätigt, Originalname ohne Zeitstempel, Hochladezeit aus dem Namen), Datei bleibt am Ort.
 2) Ordner passt zu zwei Vermögenswerten (gleicher Name) -> nichts zugeordnet, gemeldet.
 3) Gleiche Prüfsumme schon als Beleg beim selben Vermögenswert -> nichts doppelt.
 4) Datei, die schon einen Eintrag hat -> unberührt. iCloud-Platzhalter -> übersprungen.
 5) Eintrag ohne Datei: unbestätigt und unbenutzt -> entfernt; bestätigt und an einem Vertrag ("letzter Beleg")
    -> bleibt; Eintrag mit iCloud-Platzhalter -> bleibt.
 6) Läuft nur einmal (Marker), init_db zweimal -> keine Änderung beim zweiten Lauf.
 7) v367: Ordner ohne Vermögenswert -> synthetischer Konto-Eintrag (Name aus Ordner, Kontonummer aus Dateinamen,
    Wert 0, nicht im Gesamtvermögen), Dateien zugeordnet; unklare Person -> nichts angelegt; zweiter Start ohne Änderung.
 8) v368: Gehaltsabrechnung ohne Datei nur entfernt, wenn dieselbe Abrechnung mit Datei existiert (Einnahme+Monat oder
    Prüfsumme); ohne Gegenstück bleibt sie; iCloud-Platzhalter zählt als vorhanden.
"""
import contextlib
import hashlib
import io
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))

TMP = Path(tempfile.mkdtemp(prefix="ff_reparatur_"))
(TMP / "data").mkdir()

import database  # noqa: E402

database.BASE_DIR = TMP
database.DB_PATH = TMP / "data" / "finance.db"
database.DEMO_DB_PATH = TMP / "data" / "demo.db"

import receipts_routes as rr  # noqa: E402

rr.BASE_DIR = TMP
rr.VERMOEGEN_DIR = TMP / "data" / "Vermoegen"
rr.RECEIPTS_DIR = TMP / "data" / "Belege"
rr.PAYSLIPS_DIR = TMP / "data" / "Gehalt"

FAILS = []


def check(name, got, want):
    ok = got == want
    print(f"{'✓' if ok else '✗'} {name}: {got!r}" + ("" if ok else f" (erwartet {want!r})"))
    if not ok:
        FAILS.append(name)


# Datenbank ohne Marker anlegen (init_db läuft die Reparatur sonst schon auf leerem Stand)
with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
c = sqlite3.connect(database.DB_PATH)
c.row_factory = sqlite3.Row
c.execute("DELETE FROM settings WHERE key='migration_relink_orphan_asset_docs'")
c.execute("INSERT INTO assets (id, type, label) VALUES (1, 'konto', 'Hauskonto')")       # Haushalt (ohne Person)
c.execute("INSERT INTO assets (id, type, label) VALUES (2, 'depot', 'Doppelt')")
c.execute("INSERT INTO assets (id, type, label) VALUES (3, 'depot', 'Doppelt')")
c.execute("INSERT INTO contracts (id, label, amount, source) VALUES (5, 'BU', 50, 'manuell')")

V = TMP / "data" / "Vermoegen" / "Haushalt"
(V / "Hauskonto").mkdir(parents=True)
(V / "Doppelt").mkdir(parents=True)
f1 = V / "Hauskonto" / "2026-08-31_115108_Girokonto_Kontoauszug_20260301.pdf"
f1.write_bytes(b"%PDF auszug maerz")
f2 = V / "Hauskonto" / "20260831133552_Kontoauszug_20240803.pdf"
f2.write_bytes(b"%PDF auszug alt")
f_dup = V / "Hauskonto" / "2026-09-02_142350_Kopie.pdf"
f_dup.write_bytes(b"%PDF schon da")
f_known = V / "Hauskonto" / "bekannt.pdf"
f_known.write_bytes(b"%PDF bekannt")
f_amb = V / "Doppelt" / "auszug.pdf"
f_amb.write_bytes(b"%PDF doppelt")
(V / "Hauskonto" / ".fern.pdf.icloud").write_bytes(b"x")
c.execute("INSERT INTO receipts (id, original_filename, stored_path, file_hash, asset_id, review_needed) "
          "VALUES (10, 'alt.pdf', 'data/Vermoegen/Haushalt/Hauskonto/woanders.pdf', ?, 1, 0)",
          (hashlib.sha256(b"%PDF schon da").hexdigest(),))
(V / "Hauskonto" / "woanders.pdf").write_bytes(b"%PDF schon da")
c.execute("INSERT INTO receipts (id, original_filename, stored_path, asset_id, review_needed) "
          "VALUES (11, 'bekannt.pdf', 'data/Vermoegen/Haushalt/Hauskonto/bekannt.pdf', 1, 0)")
# Einträge ohne Datei
c.execute("INSERT INTO receipts (id, original_filename, stored_path, review_needed) "
          "VALUES (20, 'weg.pdf', 'data/Belege/_unbestaetigt/weg.pdf', 1)")
c.execute("INSERT INTO receipts (id, original_filename, stored_path, review_needed, contract_id) "
          "VALUES (21, 'SwissLifeBU.pdf', 'data/Belege/_unbestaetigt/SwissLifeBU.pdf', 0, 5)")
c.execute("UPDATE contracts SET last_receipt_id=21 WHERE id=5")
(TMP / "data" / "Belege" / "_unbestaetigt").mkdir(parents=True)
(TMP / "data" / "Belege" / "_unbestaetigt" / ".nur_icloud.pdf.icloud").write_bytes(b"x")
c.execute("INSERT INTO receipts (id, original_filename, stored_path, review_needed) "
          "VALUES (22, 'nur_icloud.pdf', 'data/Belege/_unbestaetigt/nur_icloud.pdf', 1)")
c.commit()

r = rr.relink_orphan_asset_documents_once(c)
rows = {x["stored_path"]: dict(x) for x in c.execute("SELECT * FROM receipts")}

print("— 1) eindeutiger Ordner")
p1 = "data/Vermoegen/Haushalt/Hauskonto/2026-08-31_115108_Girokonto_Kontoauszug_20260301.pdf"
p2 = "data/Vermoegen/Haushalt/Hauskonto/20260831133552_Kontoauszug_20240803.pdf"
check("1 beide Auszüge zugeordnet", sorted(r["relinked"]), sorted([p1, p2]))
check("1 Vermögenswert", (rows[p1]["asset_id"], rows[p2]["asset_id"]), (1, 1))
check("1 bestätigt", rows[p1]["review_needed"], 0)
check("1 Prüfsumme", rows[p1]["file_hash"], hashlib.sha256(b"%PDF auszug maerz").hexdigest())
check("1 Originalname ohne Zeitstempel", (rows[p1]["original_filename"], rows[p2]["original_filename"]),
      ("Girokonto_Kontoauszug_20260301.pdf", "Kontoauszug_20240803.pdf"))
check("1 Hochladezeit aus dem Namen", (rows[p1]["uploaded_at"], rows[p2]["uploaded_at"]),
      ("2026-08-31 11:51:08", "2026-08-31 13:35:52"))
check("1 Dateien bleiben am Ort", (f1.exists(), f2.exists()), (True, True))

print("— 2) mehrdeutiger Ordner")
check("2 nichts zugeordnet, gemeldet", "data/Vermoegen/Haushalt/Doppelt/auszug.pdf" in r["ambiguous"], True)
check("2 kein Eintrag", "data/Vermoegen/Haushalt/Doppelt/auszug.pdf" in rows, False)

print("— 3/4) Duplikat, bekannte Datei, Platzhalter")
check("3 gleiche Prüfsumme beim selben Wert: nicht doppelt", ("data/Vermoegen/Haushalt/Hauskonto/2026-09-02_142350_Kopie.pdf" in rows,
                                                             r["duplicates"]), (False, 1))
check("4 bekannte Datei unberührt", rows["data/Vermoegen/Haushalt/Hauskonto/bekannt.pdf"]["id"], 11)
check("4 iCloud-Platzhalter übersprungen", r["placeholders"], 1)

print("— 5) Einträge ohne Datei")
ids = {x["id"] for x in rows.values()}
check("5 unbestätigt & unbenutzt -> entfernt", (20 in ids, r["dropped_missing"]), (False, [20]))
check("5 bestätigt & am Vertrag -> bleibt (gemeldet)", (21 in ids, 21 in r["kept_missing"]), (True, True))
check("5 Vertrag behält seinen Beleg", c.execute("SELECT last_receipt_id FROM contracts WHERE id=5").fetchone()[0], 21)
check("5 Eintrag mit iCloud-Platzhalter bleibt", 22 in ids, True)

print("— 6) einmalig")
check("6 zweiter Aufruf läuft nicht", rr.relink_orphan_asset_documents_once(c), {"skipped": "schon gelaufen"})
before = c.execute("SELECT COUNT(*) FROM receipts").fetchone()[0]
c.close()
with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
    database.init_db()
c = sqlite3.connect(database.DB_PATH)
check("6 init_db zweimal: keine Änderung", c.execute("SELECT COUNT(*) FROM receipts").fetchone()[0], before)
c.close()

print("— 7) Ordner ohne Vermögenswert (v367): synthetischer Eintrag")
c = sqlite3.connect(database.DB_PATH)
c.row_factory = sqlite3.Row
c.execute("DELETE FROM settings WHERE key IN ('migration_synthetic_assets_for_orphans', 'migration_relink_orphan_asset_docs_v2')")
c.execute("INSERT INTO family_members (id, name) VALUES (90, 'Zwei fach'), (91, 'Zwei/fach')")   # gleicher Ordner Zwei_fach
c.commit()
G = TMP / "data" / "Vermoegen" / "Haushalt" / "Altes_Konto"
G.mkdir(parents=True)
for n in ("2026-08-31_115108_Girokonto_5421587394_Kontoauszug_20260301.pdf",
          "2026-08-31_115108_Information_20260324.pdf",
          "2026-09-02_142350_Girokonto_5421587394_Kontoauszug_20260902.pdf"):
    (G / n).write_bytes(n.encode())
U = TMP / "data" / "Vermoegen" / "Zwei_fach" / "Konto"          # Person nicht eindeutig -> nichts anlegen
U.mkdir(parents=True)
(U / "x.pdf").write_bytes(b"x")
assets_before = c.execute("SELECT COUNT(*) FROM assets").fetchone()[0]
c.close()
with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
c = sqlite3.connect(database.DB_PATH)
c.row_factory = sqlite3.Row
new = [dict(x) for x in c.execute("SELECT * FROM assets WHERE id > (SELECT MAX(id) FROM assets) - 5 AND note LIKE 'Automatisch%'")]
check("7 genau ein synthetischer Eintrag (Ordner mit Doppelt-Werten und Zweifach-Person nicht)", len(new), 1)
a = new[0] if new else {}
check("7 Name aus dem Ordner", a.get("label"), "Altes Konto")
check("7 Kontonummer aus den Dateinamen", a.get("account_number"), "5421587394")
check("7 Girokonto, ohne Person, Wert 0", (a.get("type"), a.get("account_type"), a.get("person_id"), a.get("current_value")),
      ("konto", "giro", None, 0))
check("7 nicht im Gesamtvermögen, nicht archiviert", (a.get("exclude_from_networth"), a.get("archived_at")), (1, None))
check("7 Anlagedatum = frühester Upload", a.get("created_at"), "2026-08-31")
linked = c.execute("SELECT COUNT(*) FROM receipts WHERE asset_id=?", (a.get("id"),)).fetchone()[0]
check("7 alle drei Dateien zugeordnet", linked, 3)
check("7 Dateien bleiben am Ort", all((G / n).exists() for n in os.listdir(G)), True)
check("7 sonst keine neuen Vermögenswerte", c.execute("SELECT COUNT(*) FROM assets").fetchone()[0], assets_before + 1)
c.close()
with contextlib.redirect_stdout(io.StringIO()):
    database.init_db()
c = sqlite3.connect(database.DB_PATH)
check("7 zweiter Start: nichts Neues", (c.execute("SELECT COUNT(*) FROM assets").fetchone()[0],
                                         c.execute("SELECT COUNT(*) FROM receipts WHERE asset_id=?", (a.get("id"),)).fetchone()[0]),
      (assets_before + 1, 3))
c.close()

print("— 8) Gehaltsabrechnungen ohne Datei (v368)")
c = sqlite3.connect(database.DB_PATH)
c.row_factory = sqlite3.Row
c.execute("DELETE FROM settings WHERE key='migration_drop_dead_payslip_duplicates'")
c.execute("DELETE FROM payslips")
c.execute("INSERT INTO income (id, label, amount, source) VALUES (50, 'Gehalt', 3000, 'manuell')")
GH = TMP / "data" / "Gehalt" / "Benjamin"
GH.mkdir(parents=True, exist_ok=True)
(GH / "juli_neu.pdf").write_bytes(b"juli")
(GH / "aug.pdf").write_bytes(b"aug")
(GH / ".nur_icloud.pdf.icloud").write_bytes(b"x")
rows8 = [  # id, stored_path, file_hash, income_id, month
    (1, "data/payslips/2026-08-09_Lohnabrechnung_Juli.pdf", "h-alt", 50, "2026-07"),   # tot, Gegenstück #3
    (2, "data/payslips/2026-08-09_Brutto-Netto_Juli.pdf", "h-juli", None, None),       # tot, gleiche Prüfsumme wie #3
    (3, "data/Gehalt/Benjamin/juli_neu.pdf", "h-juli", 50, "2026-07"),                  # lebt
    (4, "data/payslips/2026-06.pdf", "h-juni", 50, "2026-06"),                           # tot, KEIN Gegenstück
    (5, "data/Gehalt/Benjamin/aug.pdf", "h-aug", 50, "2026-08"),                         # lebt
    (6, "data/Gehalt/Benjamin/nur_icloud.pdf", "h-i", 50, "2026-09"),                    # nur in iCloud -> vorhanden
]
c.executemany("INSERT INTO payslips (id, stored_path, file_hash, income_id, detected_month, review_needed) "
              "VALUES (?,?,?,?,?,0)", rows8)
c.commit()
r8 = rr.drop_dead_payslip_duplicates_once(c)
left = sorted(x[0] for x in c.execute("SELECT id FROM payslips"))
check("8 Doppel mit Gegenstück entfernt (Einnahme+Monat, Prüfsumme)", sorted(d["id"] for d in r8["dropped"]), [1, 2])
check("8 ohne Gegenstück bleibt", r8["kept_missing"], [4])
check("8 übrig: lebende, Platzhalter und der ohne Gegenstück", left, [3, 4, 5, 6])
check("8 zweiter Aufruf läuft nicht", rr.drop_dead_payslip_duplicates_once(c), {"skipped": "schon gelaufen"})
c.close()

print()
if FAILS:
    print(f"✗ Reparatur: {len(FAILS)} Fehler: {', '.join(FAILS)}")
    sys.exit(1)
print("✓ Reparatur: alle Fälle stimmen")
