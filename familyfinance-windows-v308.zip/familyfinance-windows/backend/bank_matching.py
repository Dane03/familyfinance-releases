"""
Zuordnung von Bankumsätzen zu Verträgen (Ausgaben) und Einnahmen -- plus die
daraus ableitbaren Hinweise (Preisänderung, ausbleibende Zahlung, neue
wiederkehrende Abbuchung).

GRUNDSÄTZE:
- Regeln entstehen NUR aus einer Handlung des Nutzers (manuelle Zuordnung).
  Vorschläge der App werden nie still übernommen.
- Eine Regel nutzt das eindeutigste vorhandene Merkmal: Gläubiger-ID +
  Mandatsreferenz (je Vertrag eindeutig) > Gläubiger-ID > IBAN > Name.
- Vertragsbeträge ändern sich nie von allein -- ein Preis-Hinweis bietet nur
  "übernehmen" an (wie beim Beleg-Import).
- Preis-Hinweis erst nach ZWEI aufeinanderfolgenden gleich abweichenden
  Buchungen; eine einzelne Abweichung (Nachzahlung, anteiliger Monat) wird
  nur dezent markiert.
- "Zahlung ausgeblieben" nur für Verträge, die bereits zugeordnete Umsätze
  haben -- läuft ein Vertrag über ein nicht angebundenes Konto, gäbe es sonst
  ständig Fehlalarme.
"""
import re
from datetime import date, timedelta
from typing import Optional

FIELD_PRIORITY = ["creditor_mandate", "creditor", "iban", "name"]
PERIOD_DAYS = {"monthly": 31, "quarterly": 92, "yearly": 366}
AMOUNT_TOLERANCE = 0.01   # Euro -- darunter gilt ein Betrag als unverändert

_CRED_RE = re.compile(r"CRED\+\s*([A-Z]{2}\d{2}[A-Z0-9]{3}[A-Z0-9]{1,28})", re.I)
_CRED_TEXT_RE = re.compile(r"Gl(?:ä|ae)ubiger-?ID[:\s]+([A-Z]{2}\d{2}[A-Z0-9]{3}[A-Z0-9]{1,28})", re.I)
_MREF_RE = re.compile(r"MREF\+\s*([^\s+]{1,35})", re.I)
_MREF_TEXT_RE = re.compile(r"Mandat(?:sref(?:erenz)?)?[:\s.]+([A-Za-z0-9\-/.]{1,35})", re.I)


def extract_sepa(purpose: Optional[str]) -> tuple:
    """Gläubiger-ID und Mandatsreferenz aus dem Verwendungszweck. Banken
    liefern sie meist als 'CRED+…'/'MREF+…' (SEPA-Strukturfelder), manche
    als Klartext ('Gläubiger-ID: …', 'Mandatsref.: …')."""
    text = purpose or ""
    cred = _CRED_RE.search(text) or _CRED_TEXT_RE.search(text)
    mref = _MREF_RE.search(text) or _MREF_TEXT_RE.search(text)
    return (cred.group(1).upper() if cred else None, mref.group(1) if mref else None)


IBAN_LEN = {"DE": 22, "AT": 20, "CH": 21, "LU": 20, "FR": 27, "NL": 18, "BE": 16, "IT": 27, "ES": 24,
            "IE": 22, "GB": 22, "PL": 28, "DK": 18, "SE": 24, "NO": 15, "FI": 18, "PT": 25, "CZ": 24}


def _iban_ok(iban: str) -> bool:
    """Prüfziffer (mod 97) -- verhindert, dass ein Name, der zufällig wie 'DE12…' beginnt, zerlegt wird."""
    s = iban[4:] + iban[:4]
    try:
        return int("".join(str(int(c, 36)) for c in s)) % 97 == 1
    except ValueError:
        return False


def split_name_iban(name: Optional[str]) -> tuple:
    """Manche Banken liefern IBAN und Name in einem Feld ('DE5150…7394Benjamin Moecklin').
    Liefert (Name, IBAN) -- IBAN nur, wenn Länge UND Prüfziffer stimmen, sonst (Name, None)."""
    text = (name or "").strip()
    m = re.match(r"^([A-Za-z]{2})(\d{2})", text)
    n = IBAN_LEN.get(m.group(1).upper()) if m else None
    if not n:
        return text, None
    collected, end = "", 0
    for i, ch in enumerate(text):
        if ch == " ":
            continue
        if not ch.isalnum():
            break
        collected += ch
        end = i + 1
        if len(collected) == n:
            break
    collected = collected.upper()
    if len(collected) != n or not _iban_ok(collected):
        return text, None
    rest = text[end:].strip(" ,:;-/")
    return rest, collected


def clean_counterparty(name: Optional[str], iban: Optional[str]) -> tuple:
    """(Name, IBAN) bereinigt: eine im Namen steckende IBAN wandert ins IBAN-Feld, falls dort noch nichts steht."""
    clean, found = split_name_iban(name)
    if found is None:
        return name, iban
    return (clean or None), (iban or found)


def _norm_name(name: Optional[str]) -> str:
    n = re.sub(r"[^a-z0-9äöüß ]", " ", (name or "").lower())
    n = re.sub(r"\b(gmbh|ag|se|kg|e ?v|co|und|mbh|ltd|inc|sarl|bv)\b", " ", n)
    return re.sub(r"\s+", " ", n).strip()


def identifiers(tx: dict) -> dict:
    """Alle verfügbaren Merkmale eines Umsatzes, stärkstes zuerst."""
    ids = {}
    cred, mref = tx.get("creditor_id"), tx.get("mandate_ref")
    if cred and mref:
        ids["creditor_mandate"] = f"{cred}|{mref}"
    if cred:
        ids["creditor"] = cred
    iban = re.sub(r"\s", "", tx.get("counterparty_iban") or "").upper()
    if len(iban) >= 15:
        ids["iban"] = iban
    name = _norm_name(tx.get("counterparty_name"))
    if len(name) >= 3:
        ids["name"] = name
    return ids


def backfill_sepa(conn):
    """Gläubiger-ID/Mandat für Umsätze nachtragen, die vor v284 gespeichert wurden."""
    rows = conn.execute("SELECT id, purpose FROM bank_transactions WHERE creditor_id IS NULL AND mandate_ref IS NULL "
                        "AND purpose IS NOT NULL").fetchall()
    for r in rows:
        cred, mref = extract_sepa(r["purpose"])
        if cred or mref:
            conn.execute("UPDATE bank_transactions SET creditor_id=?, mandate_ref=? WHERE id=?", (cred, mref, r["id"]))
    conn.commit()


# ---------- Regeln ----------

def _target_exists(conn, kind: str, target_id: int) -> bool:
    table = "contracts" if kind == "contract" else "income"
    return conn.execute(f"SELECT 1 FROM {table} WHERE id=?", (target_id,)).fetchone() is not None


def find_rule(conn, tx: dict):
    ids = identifiers(tx)
    for field in FIELD_PRIORITY:
        if field in ids:
            r = conn.execute("SELECT * FROM bank_match_rules WHERE match_field=? AND match_value=?",
                             (field, ids[field])).fetchone()
            if r and _target_exists(conn, r["kind"], r["target_id"]):
                return r
    return None


def backfill_names(conn):
    """Bereits gespeicherte Umsätze/Regeln bereinigen: IBAN aus dem Namensfeld lösen (idempotent)."""
    rows = conn.execute("SELECT id, counterparty_name, counterparty_iban FROM bank_transactions "
                        "WHERE counterparty_name GLOB '[A-Za-z][A-Za-z][0-9][0-9]*'").fetchall()
    for r in rows:
        name, iban = clean_counterparty(r["counterparty_name"], r["counterparty_iban"])
        if (name, iban) != (r["counterparty_name"], r["counterparty_iban"]):
            conn.execute("UPDATE bank_transactions SET counterparty_name=?, counterparty_iban=? WHERE id=?", (name, iban, r["id"]))
    # Gelernte Namens-Regeln: die normalisierte IBAN-Vorsilbe abschneiden, Duplikate entfernen
    for r in conn.execute("SELECT id, match_value FROM bank_match_rules WHERE match_field='name'").fetchall():
        v = r["match_value"]
        cc = v[:2].upper()
        n = IBAN_LEN.get(cc)
        if n and re.match(r"^[a-z]{2}\d{2}", v) and len(v) > n and _iban_ok(v[:n].upper()):
            new = v[n:].strip()
            if len(new) < 3:
                continue
            if conn.execute("SELECT 1 FROM bank_match_rules WHERE match_field='name' AND match_value=? AND id<>?", (new, r["id"])).fetchone():
                conn.execute("DELETE FROM bank_match_rules WHERE id=?", (r["id"],))
            else:
                conn.execute("UPDATE bank_match_rules SET match_value=? WHERE id=?", (new, r["id"]))
    conn.commit()


def apply_rules(conn) -> int:
    """Ordnet alle noch offenen Umsätze anhand der Regeln zu. 'none' (bewusst
    keine Zuordnung) und manuelle Zuordnungen werden nie angefasst."""
    backfill_sepa(conn)
    backfill_names(conn)
    rows = conn.execute("SELECT * FROM bank_transactions WHERE match_source IS NULL").fetchall()
    n = 0
    for tx in rows:
        rule = find_rule(conn, dict(tx))
        if rule:
            col = "contract_id" if rule["kind"] == "contract" else "income_id"
            conn.execute(f"UPDATE bank_transactions SET {col}=?, match_source='rule' WHERE id=?", (rule["target_id"], tx["id"]))
            n += 1
    conn.commit()
    return n


def assign(conn, tx_id: int, kind: str, target_id: int, learn: bool = True) -> dict:
    if kind not in ("contract", "income"):
        raise ValueError("kind muss 'contract' oder 'income' sein")
    tx = conn.execute("SELECT * FROM bank_transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx:
        raise LookupError("Umsatz nicht gefunden")
    if not _target_exists(conn, kind, target_id):
        raise LookupError("Vertrag/Einnahme nicht gefunden")
    contract_id = target_id if kind == "contract" else None
    income_id = target_id if kind == "income" else None
    conn.execute("UPDATE bank_transactions SET contract_id=?, income_id=?, match_source='manual' WHERE id=?",
                 (contract_id, income_id, tx_id))
    rule_field = None
    if learn:
        ids = identifiers(dict(tx))
        for field in FIELD_PRIORITY:
            if field in ids:
                conn.execute("INSERT INTO bank_match_rules (kind, target_id, match_field, match_value) VALUES (?,?,?,?) "
                             "ON CONFLICT(match_field, match_value) DO UPDATE SET kind=excluded.kind, target_id=excluded.target_id",
                             (kind, target_id, field, ids[field]))
                rule_field = field
                break
    conn.commit()
    retro = apply_rules(conn) if rule_field else 0
    return {"rule_field": rule_field, "also_assigned": retro}


def unassign(conn, tx_id: int, forget_rule: bool = False):
    tx = conn.execute("SELECT * FROM bank_transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx:
        raise LookupError("Umsatz nicht gefunden")
    if forget_rule:
        for field, value in identifiers(dict(tx)).items():
            conn.execute("DELETE FROM bank_match_rules WHERE match_field=? AND match_value=?", (field, value))
    conn.execute("UPDATE bank_transactions SET contract_id=NULL, income_id=NULL, match_source='none' WHERE id=?", (tx_id,))
    conn.commit()


# ---------- Vorschläge ----------

def _tokens(text: Optional[str]) -> set:
    return {t for t in _norm_name(text).split() if len(t) >= 3}


def suggestions(conn, tx_id: int, limit: int = 3) -> list:
    """Kandidaten für einen offenen Umsatz -- Ausgaben für Abbuchungen,
    Einnahmen für Gutschriften. Bewertet Namensübereinstimmung und wie nah
    der Betrag am hinterlegten Betrag liegt."""
    tx = conn.execute("SELECT * FROM bank_transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx or tx["amount"] is None:
        return []
    amount = abs(tx["amount"])
    tx_tokens = _tokens(tx["counterparty_name"]) | _tokens(tx["purpose"])
    if tx["amount"] < 0:
        rows = conn.execute("SELECT id, label, provider, amount FROM contracts WHERE COALESCE(status,'active') = 'active'").fetchall()
        kind = "contract"
    else:
        rows = conn.execute("SELECT id, label, NULL AS provider, amount FROM income WHERE COALESCE(active,1)=1").fetchall()
        kind = "income"
    scored = []
    for r in rows:
        name_hits = len(tx_tokens & (_tokens(r["label"]) | _tokens(r["provider"])))
        amt = r["amount"] or 0
        amount_score = max(0.0, 1 - abs(amount - amt) / amt) if amt else 0.0
        score = name_hits * 2 + amount_score * 1.5
        if name_hits or amount_score > 0.9:
            scored.append({"kind": kind, "id": r["id"], "label": r["label"], "provider": r["provider"],
                           "amount": amt, "score": round(score, 2)})
    scored.sort(key=lambda s: -s["score"])
    return scored[:limit]


# ---------- Hinweise (Preisänderung & Co.) ----------

_DISMISS_DDL = ("CREATE TABLE IF NOT EXISTS bank_dismissed_hints (hint_key TEXT PRIMARY KEY, kind TEXT NOT NULL, "
                "title TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")


def dismiss_hint(conn, hint_key: str, kind: str, title: str = ""):
    conn.execute(_DISMISS_DDL)
    conn.execute("INSERT OR REPLACE INTO bank_dismissed_hints (hint_key, kind, title) VALUES (?,?,?)",
                 (hint_key, kind, (title or "")[:200]))
    conn.commit()


def restore_hint(conn, hint_key: str):
    conn.execute(_DISMISS_DDL)
    conn.execute("DELETE FROM bank_dismissed_hints WHERE hint_key=?", (hint_key,))
    conn.commit()


def _booking(tx) -> dict:
    """Eine Buchung für die Detailansicht: bereinigt, Verwendungszweck gekürzt."""
    name, iban = clean_counterparty(tx["counterparty_name"], tx["counterparty_iban"])
    purpose = re.sub(r"\s+", " ", tx["purpose"] or "").strip()
    return {"date": tx["booking_date"], "amount": tx["amount"], "name": name, "iban": iban,
            "purpose": purpose[:240], "account": tx["account_label"]}


def _interval_days(dates) -> Optional[int]:
    """Typischer Abstand zwischen den Buchungen (Median, Tage) -- zeigt den Rhythmus."""
    ds = []
    for d in dates:
        try:
            ds.append(date.fromisoformat(str(d)[:10]))
        except ValueError:
            pass
    ds.sort()
    gaps = sorted((b - a).days for a, b in zip(ds, ds[1:]) if (b - a).days > 0)
    return gaps[len(gaps) // 2] if gaps else None


def insights(conn, today: Optional[date] = None) -> dict:
    today = today or date.today()
    conn.execute(_DISMISS_DDL)
    dismissed_rows = conn.execute("SELECT hint_key, kind, title, created_at FROM bank_dismissed_hints "
                                  "ORDER BY created_at DESC LIMIT 100").fetchall()
    dismissed = {r["hint_key"] for r in dismissed_rows}
    price_changes, deviations, missing = [], [], []
    targets = [("contract", r) for r in conn.execute(
        "SELECT id, label, amount, frequency FROM contracts WHERE COALESCE(status,'active') = 'active'")]
    targets += [("income", r) for r in conn.execute(
        "SELECT id, label, amount, frequency FROM income WHERE COALESCE(active,1)=1")]
    for kind, t in targets:
        col = "contract_id" if kind == "contract" else "income_id"
        txs = conn.execute(f"SELECT bt.booking_date, bt.amount, bt.purpose, bt.counterparty_name, bt.counterparty_iban, "
                           f"ba.label AS account_label FROM bank_transactions bt JOIN bank_accounts ba ON ba.id = bt.bank_account_id "
                           f"WHERE bt.{col}=? AND bt.amount IS NOT NULL ORDER BY bt.booking_date DESC, bt.id DESC LIMIT 6",
                           (t["id"],)).fetchall()
        if not txs:
            continue
        expected = abs(t["amount"] or 0)
        latest = abs(txs[0]["amount"])
        bookings = [_booking(x) for x in txs]
        last_b = bookings[0]
        base = {"kind": kind, "id": t["id"], "label": (t["label"] or "").strip() or last_b["name"] or "Ohne Bezeichnung",
                "expected": round(expected, 2), "actual": round(latest, 2), "last_date": txs[0]["booking_date"],
                "counterparty_name": last_b["name"], "iban": last_b["iban"], "purpose": last_b["purpose"],
                "account_label": last_b["account"], "bookings": bookings,
                "interval_days": _interval_days(x["booking_date"] for x in txs)}
        if abs(latest - expected) > AMOUNT_TOLERANCE:
            if len(txs) >= 2 and abs(abs(txs[1]["amount"]) - latest) <= AMOUNT_TOLERANCE:
                key = f"price:{kind}:{t['id']}:{round(latest, 2)}"
                if key not in dismissed:
                    price_changes.append({**base, "hint_key": key})   # zweimal hintereinander derselbe neue Betrag
            else:
                deviations.append(base)      # einmalig abweichend -- nur dezent
        period = PERIOD_DAYS.get(t["frequency"] or "monthly")
        try:
            last = date.fromisoformat(str(txs[0]["booking_date"])[:10])
        except ValueError:
            last = None
        if period and last and (today - last).days > period + 10:
            key = f"missing:{kind}:{t['id']}:{txs[0]['booking_date']}"
            if key not in dismissed:
                missing.append({**base, "days_since": (today - last).days, "hint_key": key})
    recurring = recurring_unmapped(conn, today, dismissed)
    return {"price_changes": price_changes, "deviations": deviations, "missing": missing,
            "recurring_unmapped": recurring, "dismissed": [dict(r) for r in dismissed_rows]}


def recurring_unmapped(conn, today: date, dismissed: Optional[set] = None) -> list:
    """Offene Abbuchungen desselben Empfängers in mindestens zwei
    verschiedenen Monaten mit ähnlichem Betrag -- vermutlich ein Vertrag, der
    noch nicht angelegt ist."""
    dismissed = dismissed or set()
    since = (today - timedelta(days=200)).isoformat()
    rows = conn.execute("SELECT bt.*, ba.label AS account_label FROM bank_transactions bt "
                        "JOIN bank_accounts ba ON ba.id = bt.bank_account_id "
                        "WHERE bt.match_source IS NULL AND bt.amount < 0 AND bt.booking_date >= ? "
                        "ORDER BY bt.booking_date", (since,)).fetchall()
    groups = {}
    for tx in rows:
        d = dict(tx)
        d["counterparty_name"], d["counterparty_iban"] = clean_counterparty(d["counterparty_name"], d["counterparty_iban"])
        ids = identifiers(d)
        key = next((f"{f}:{ids[f]}" for f in FIELD_PRIORITY if f in ids), None)
        if key:
            groups.setdefault(key, []).append(tx)
    out = []
    for key, txs in groups.items():
        months = {str(t["booking_date"])[:7] for t in txs}
        amounts = [abs(t["amount"]) for t in txs]
        if len(months) >= 2 and (max(amounts) - min(amounts)) <= max(1.0, 0.1 * max(amounts)):
            hint_key = f"recurring:{key}"
            if hint_key in dismissed:
                continue
            last = txs[-1]
            bookings = [_booking(x) for x in reversed(txs[-6:])]
            out.append({"counterparty_name": bookings[0]["name"], "iban": bookings[0]["iban"],
                        "amount": round(abs(last["amount"]), 2), "amount_min": round(min(amounts), 2),
                        "amount_max": round(max(amounts), 2), "months": len(months), "count": len(txs),
                        "first_date": txs[0]["booking_date"], "last_date": last["booking_date"],
                        "purpose": bookings[0]["purpose"], "account_label": bookings[0]["account"],
                        "interval_days": _interval_days(x["booking_date"] for x in txs),
                        "bookings": bookings, "transaction_id": last["id"], "hint_key": hint_key})
    return sorted(out, key=lambda o: -o["amount"])
