"""
Client für die (von myenergi selbst als "inoffiziell unterstützt"
bezeichnete) myenergi-API — liest die täglich geladene Energiemenge der
Zappi-Wallbox aus, um sie als eigenen Zählertyp ("ev_charging") in die App
zu übernehmen und so vom normalen Hausverbrauch zu trennen.

WICHTIG, ehrlich gesagt: Diese API ist nicht offiziell dokumentiert. Der
Authentifizierungs-Ablauf (Director-Weiterleitung + Digest-Auth mit der
Hub-Seriennummer) ist gut belegt und wird von mehreren seit Jahren
funktionierenden Open-Source-Projekten genutzt (siehe z.B.
github.com/twonk/MyEnergi-App-Api, github.com/G6EJD/MyEnergi-Python-Example).
Das genaue Feldformat der Tagesdaten-Antwort konnte ich mangels Netzzugriff
in dieser Umgebung nicht gegen die echten Server verifizieren — die
Fehlermeldungen unten sind bewusst konkret gehalten, damit ein
abweichendes Format beim ersten echten Test sofort auffällt, statt
stillschweigend falsche Werte zu übernehmen.
"""
import httpx
from datetime import date, datetime, timedelta, timezone

DIRECTOR_HOST = "director.myenergi.net"


class MyenergiError(Exception):
    pass


def _client(hub_serial: str, hub_password: str, host: str) -> httpx.Client:
    return httpx.Client(
        auth=httpx.DigestAuth(hub_serial, hub_password),
        base_url=f"https://{host}",
        timeout=15.0,
        headers={"User-Agent": "FamilyFinance/1.0"},
    )


def _resolve_server(hub_serial: str, hub_password: str) -> str:
    """Der Director gibt per Response-Header bekannt, welcher Regionalserver
    für den jeweiligen Hub zuständig ist -- ALLE weiteren Aufrufe müssen
    gegen DIESEN Server gehen, nicht gegen den Director selbst."""
    with _client(hub_serial, hub_password, DIRECTOR_HOST) as c:
        r = c.get(f"/cgi-jstatus-E{hub_serial}")
        if r.status_code == 401:
            raise MyenergiError("Anmeldung fehlgeschlagen — Hub-Seriennummer oder Passwort falsch.")
        r.raise_for_status()
        server = r.headers.get("x_myenergi-asn")
        if not server:
            raise MyenergiError(
                "Der Director hat keinen zuständigen Server genannt (Header "
                "'x_myenergi-asn' fehlt) — das API-Format hat sich vermutlich "
                "geändert."
            )
        return server


def test_connection(hub_serial: str, hub_password: str) -> dict:
    """Nur Zugangsdaten prüfen, ohne Daten zu importieren — für einen
    'Verbindung testen'-Knopf getrennt vom eigentlichen Sync."""
    try:
        server = _resolve_server(hub_serial, hub_password)
        return {"ok": True, "server": server}
    except MyenergiError as e:
        return {"ok": False, "error": str(e)}
    except httpx.HTTPError as e:
        return {"ok": False, "error": f"Verbindung fehlgeschlagen: {e}"}


def _entry_utc(entry: dict, requested_day: date) -> datetime:
    """UTC-Zeitpunkt einer Minuten-Zeile. myenergi lässt Felder mit Wert 0 weg
    (fehlendes 'hr'/'min' = 0); Datum steht in yr/mon/dom, sonst gilt der
    angefragte UTC-Tag."""
    try:
        return datetime(int(entry.get("yr", requested_day.year)), int(entry.get("mon", requested_day.month)),
                        int(entry.get("dom", requested_day.day)), int(entry.get("hr", 0)),
                        int(entry.get("min", 0)), tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return datetime(requested_day.year, requested_day.month, requested_day.day, tzinfo=timezone.utc)


def _fetch_utc_day(client, zappi_serial: str, day: date) -> list:
    r = client.get(f"/cgi-jday-Z{zappi_serial}-{day.strftime('%Y-%m-%d')}")
    if r.status_code == 404:
        return []   # kein Wagen angeschlossen an dem Tag
    r.raise_for_status()
    payload = r.json()
    entries = payload.get(f"U{zappi_serial}") if isinstance(payload, dict) else None
    if entries is None and isinstance(payload, list):
        entries = payload
    return [e for e in (entries or []) if isinstance(e, dict)]


def fetch_daily_charge_kwh(hub_serial: str, hub_password: str, zappi_serial: str,
                            start: date, end: date) -> dict:
    """Liefert {'YYYY-MM-DD': geladene_kWh} je LOKALEM Kalendertag in [start, end].

    Format (an echter Antwort verifiziert, siehe Projektnotizen): je UTC-Tag
    bis zu 1440 Minuten-Zeilen; 'h1b'/'h2b'/'h3b' (Netz-Boost) und
    'h1d'/'h2d'/'h3d' (Solarüberschuss) = in dieser Minute geladene Energie
    in Joule, nur in Minuten mit Ladung vorhanden.

    ZEITZONE: myenergi liefert UTC-Tage, ein "Tag" läuft dort in Deutschland
    von 01:00/02:00 bis 01:00/02:00 Uhr. Früher wurde je UTC-Tag summiert --
    Nachtladungen (z.B. per Timer um 00:30) landeten dadurch beim Vortag.
    Jetzt wird jede Minute in die LOKALE Zeit des Servers umgerechnet
    (astimezone(); der Server läuft im Haushalt, also deutsche Zeit inkl.
    Sommerzeit) und dem richtigen Kalendertag zugeordnet. Dafür wird der
    UTC-Vortag von 'start' mitgeholt, er enthält die lokalen Nachtstunden."""
    CHARGE_FIELDS = ("h1b", "h2b", "h3b", "h1d", "h2d", "h3d")
    server = _resolve_server(hub_serial, hub_password)
    totals = {}
    with _client(hub_serial, hub_password, server) as c:
        day = start - timedelta(days=1)
        while day <= end:
            for e in _fetch_utc_day(c, zappi_serial, day):
                local_day = _entry_utc(e, day).astimezone().date()
                if start <= local_day <= end:
                    totals[local_day] = totals.get(local_day, 0) + sum(e.get(k, 0) for k in CHARGE_FIELDS)
            day += timedelta(days=1)
    return {d.isoformat(): round(j / 3_600_000, 3) for d, j in sorted(totals.items())}
