"""
Fronius-Wechselrichter über die LOKALE Fronius Solar API v1 (HTTP im
Heimnetz, ohne Passwort, ohne Cloud). Funktioniert mit Symo/Primo/Galvo
(Datamanager) und GEN24/Tauro; bei GEN24 muss die Schnittstelle im
Wechselrichter-Menü eingeschaltet sein (Kommunikation → Solar API).

WICHTIG (vor dem Bau recherchiert): GEN24/Tauro liefern DAY_ENERGY und
YEAR_ENERGY grundsätzlich als null -- nur TOTAL_ENERGY (Gesamtzähler, Wh).
Tageswerte entstehen deshalb aus Zählerstand-Differenzen (fronius_routes).

Zähler:
- Wechselrichter TOTAL_ENERGY: AC-Erzeugung gesamt. Gemessen auf der
  Wechselstrom-Seite -- bei Hybridgeräten ist die Batterie damit bereits
  verrechnet, Hausverbrauch = Erzeugung − Einspeisung + Bezug stimmt also.
- Smart Meter am Netzanschluss: EnergyReal_WAC_Plus_Absolute = Bezug gesamt,
  EnergyReal_WAC_Minus_Absolute = Einspeisung gesamt (laut Fronius die
  Werte, die auch Solar.web verwendet).
"""
import re
from typing import Optional

import httpx

TIMEOUT = 10.0
_HOST_RE = re.compile(r"^[A-Za-z0-9.\-]{1,253}(:\d{1,5})?$")


class FroniusError(Exception):
    pass


def normalize_host(host: str) -> str:
    """Nur Hostname/IP (optional mit Port) -- Schema und Pfade werden entfernt."""
    h = (host or "").strip()
    h = re.sub(r"^https?://", "", h, flags=re.I).split("/")[0]
    if not _HOST_RE.match(h):
        raise FroniusError("Ungültige Adresse — bitte nur die IP oder den Hostnamen des Wechselrichters angeben, z.B. 192.168.178.50")
    return h


def _get(client: httpx.Client, host: str, path: str) -> dict:
    try:
        r = client.get(f"http://{host}/solar_api/v1/{path}")
    except httpx.HTTPError as e:
        raise FroniusError(f"Wechselrichter unter {host} nicht erreichbar ({type(e).__name__}). "
                           "Läuft der Server im selben Netz, und ist bei GEN24 die Solar API eingeschaltet?")
    if r.status_code == 404:
        raise FroniusError("Schnittstelle nicht gefunden — bei GEN24 im Wechselrichter-Menü unter "
                           "Kommunikation → Solar API einschalten.")
    if r.status_code >= 400:
        raise FroniusError(f"Unter {host} antwortet ein Gerät mit HTTP {r.status_code} — ist das die Adresse des "
                           "Wechselrichters (nicht des Routers), und ist bei GEN24 die Solar API eingeschaltet?")
    try:
        return r.json()
    except ValueError:
        raise FroniusError("Antwort ist kein gültiges JSON — ist das wirklich ein Fronius-Wechselrichter?")


def _sum_values(field) -> Optional[float]:
    """TOTAL_ENERGY/DAY_ENERGY kommen bei Scope=System als {"Values": {"1": 123}},
    bei Scope=Device als {"Value": 123}; null bei GEN24 (DAY_ENERGY)."""
    if not isinstance(field, dict):
        return None
    if "Values" in field and isinstance(field["Values"], dict):
        vals = [v for v in field["Values"].values() if isinstance(v, (int, float))]
        return float(sum(vals)) if vals else None
    v = field.get("Value")
    return float(v) if isinstance(v, (int, float)) else None


def _pick_meter(data: dict, meter_id: Optional[str]) -> Optional[dict]:
    if not isinstance(data, dict) or not data:
        return None
    if meter_id is not None and str(meter_id) in data:
        return data[str(meter_id)]
    # Sonst: Zähler am Netzanschluss bevorzugen (Meter_Location_Current 0 = Einspeisepunkt)
    for m in data.values():
        if isinstance(m, dict) and m.get("Meter_Location_Current") in (0, 0.0):
            return m
    return next((m for m in data.values() if isinstance(m, dict)), None)


def read_counters(host: str, meter_id: Optional[str] = None) -> dict:
    """Aktuelle Zählerstände in Wh: pv_total, import_total, export_total
    (letztere None ohne Smart Meter), dazu day_energy (None bei GEN24)."""
    host = normalize_host(host)
    with httpx.Client(timeout=TIMEOUT) as c:
        inv = _get(c, host, "GetInverterRealtimeData.cgi?Scope=System")
        data = (inv.get("Body") or {}).get("Data") or {}
        pv_total = _sum_values(data.get("TOTAL_ENERGY"))
        day_energy = _sum_values(data.get("DAY_ENERGY"))
        if pv_total is None:
            # Manche GEN24-Firmwares liefern bei Scope=System nichts -> Gerät 1 direkt fragen
            inv = _get(c, host, "GetInverterRealtimeData.cgi?Scope=Device&DeviceId=1&DataCollection=CumulationInverterData")
            data = (inv.get("Body") or {}).get("Data") or {}
            pv_total = _sum_values(data.get("TOTAL_ENERGY"))
            day_energy = _sum_values(data.get("DAY_ENERGY"))
        if pv_total is None:
            raise FroniusError("Der Wechselrichter liefert keinen Gesamtzähler (TOTAL_ENERGY).")
        import_total = export_total = None
        try:
            met = _get(c, host, "GetMeterRealtimeData.cgi?Scope=System")
            meter = _pick_meter((met.get("Body") or {}).get("Data") or {}, meter_id)
            if meter:
                imp, exp = meter.get("EnergyReal_WAC_Plus_Absolute"), meter.get("EnergyReal_WAC_Minus_Absolute")
                import_total = float(imp) if isinstance(imp, (int, float)) else None
                export_total = float(exp) if isinstance(exp, (int, float)) else None
        except FroniusError:
            pass   # ohne Smart Meter: nur Erzeugung verfügbar
    return {"pv_total": pv_total, "import_total": import_total, "export_total": export_total,
            "day_energy": day_energy, "has_meter": import_total is not None and export_total is not None}
