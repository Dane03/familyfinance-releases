"""
Fronius-Integration (lokale Solar API) -- Alternative zu Sungrow als PV-Quelle.
Schreibt dieselben Tageswerte (pv_daily) wie der Sungrow-Abruf, damit Charts,
Kennzahlen und Prognosen ohne Umbau funktionieren.

Nur EINE PV-Quelle darf Tageswerte schreiben -- sonst überschreiben sich
Sungrow und Fronius gegenseitig. Ist beides eingerichtet, pausieren beide
Abrufe mit einem klaren Hinweis.
"""
import json
import threading
import time as _time
from datetime import date, datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import auth
import fronius_client
from database import get_connection

router = APIRouter()
KEEP_DAYS = 10
DAY_START_MAX_GAP = timedelta(hours=2)


class FroniusIn(BaseModel):
    host: str
    meter_id: Optional[str] = None


def get_settings(conn) -> Optional[dict]:
    row = conn.execute("SELECT value FROM settings WHERE key='fronius_settings'").fetchone()
    return json.loads(row["value"]) if row else None


def sungrow_configured(conn) -> bool:
    import secret_store
    c = secret_store.read_settings_json(conn, "sungrow_v1_credentials") or {}
    return bool(c.get("password") and c.get("access_key"))


def _set_last(conn, status: str, message: str):
    conn.execute("INSERT INTO settings (key, value) VALUES ('fronius_last_sync', ?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (json.dumps({"timestamp": datetime.now().isoformat(timespec="seconds"), "status": status, "message": message}),))
    conn.commit()


def day_values(conn, day: date) -> Optional[dict]:
    """Tageswerte (kWh) aus den Schnappschüssen. Tagesbeginn = letzter
    Schnappschuss vor Mitternacht, wenn höchstens 2 h davor (Server lief
    durch), sonst der erste des Tages (Nachtstunden ohne Daten fehlen dann)."""
    start = datetime.combine(day, datetime.min.time())
    end = start + timedelta(days=1)
    rows = conn.execute("SELECT * FROM fronius_snapshots WHERE ts >= ? AND ts < ? ORDER BY ts",
                        (start.isoformat(), end.isoformat())).fetchall()
    if not rows:
        return None
    prev = conn.execute("SELECT * FROM fronius_snapshots WHERE ts < ? ORDER BY ts DESC LIMIT 1",
                        (start.isoformat(),)).fetchone()
    base = prev if prev and start - datetime.fromisoformat(prev["ts"]) <= DAY_START_MAX_GAP else rows[0]
    last = rows[-1]

    def delta(field):
        if last[field] is None or base[field] is None:
            return None
        return round(max(0.0, last[field] - base[field]) / 1000.0, 3)   # Zählerwechsel -> nie negativ

    pv = delta("pv_wh")
    if last["day_energy_wh"] is not None and day == date.today():
        pv = round(last["day_energy_wh"] / 1000.0, 3)   # Symo & Co.: exakter Tageswert ab Mitternacht
    einsp, bezug = delta("export_wh"), delta("import_wh")
    has_meter = einsp is not None and bezug is not None
    return {"pv": pv or 0.0, "einsp": einsp or 0.0, "bezug": bezug or 0.0,
            "verbrauch": round(max(0.0, (pv or 0.0) - einsp + bezug), 3) if has_meter else None,
            "no_meter": not has_meter}


def do_sync(conn) -> dict:
    import energy_routes
    s = get_settings(conn)
    if not s or not s.get("host"):
        raise HTTPException(400, "Noch keine Fronius-Adresse hinterlegt.")
    if sungrow_configured(conn):
        msg = "Sungrow ist ebenfalls als PV-Quelle eingerichtet — bitte eine der beiden entfernen, sonst überschreiben sie sich gegenseitig."
        _set_last(conn, "error", msg)
        raise HTTPException(409, msg)
    try:
        c = fronius_client.read_counters(s["host"], s.get("meter_id"))
    except fronius_client.FroniusError as e:
        _set_last(conn, "error", str(e))
        raise HTTPException(502, str(e))
    except Exception as e:
        _set_last(conn, "error", f"Unerwarteter Fehler: {type(e).__name__}: {e}")
        raise HTTPException(502, f"Unerwarteter Fehler beim Abruf: {type(e).__name__}: {e}")
    now = datetime.now()
    conn.execute("INSERT INTO fronius_snapshots (ts, pv_wh, import_wh, export_wh, day_energy_wh) VALUES (?,?,?,?,?)",
                 (now.isoformat(timespec="seconds"), c["pv_total"], c["import_total"], c["export_total"], c["day_energy"]))
    conn.execute("DELETE FROM fronius_snapshots WHERE ts < ?", ((now - timedelta(days=KEEP_DAYS)).isoformat(),))
    conn.commit()
    stored = {}
    for d in (date.today() - timedelta(days=1), date.today()):   # gestern final + heute laufend
        v = day_values(conn, d)
        if v:
            energy_routes._store_sungrow_day(conn, d.isoformat(), v)
            stored[d.isoformat()] = v
    today = stored.get(date.today().isoformat()) or {}
    msg = (f"Heute: {today.get('pv', 0)} kWh PV" + (f", Hausverbrauch {today['verbrauch']} kWh" if today.get("verbrauch") is not None
           else " (ohne Smart Meter nur Erzeugung)"))
    _set_last(conn, "ok", msg)
    return {"status": "ok", "today": today, "counters": c}


@router.get("/api/fronius/settings")
def read_fronius_settings(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    s = get_settings(conn) or {}
    conflict = bool(s.get("host")) and sungrow_configured(conn)
    conn.close()
    return {"host": s.get("host", ""), "meter_id": s.get("meter_id") or "", "configured": bool(s.get("host")),
            "connected": bool(s.get("host")) and _last_ok(), "conflict_with_sungrow": conflict}


def _last_ok() -> bool:
    """'Verbunden' erst nach einem erfolgreichen Abruf -- bloßes Speichern der
    Adresse sagt nichts darüber, ob der Wechselrichter erreichbar ist."""
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='fronius_last_sync'").fetchone()
    conn.close()
    return bool(row) and json.loads(row["value"]).get("status") == "ok"


@router.put("/api/fronius/settings")
def write_fronius_settings(payload: FroniusIn, session=Depends(auth.require_full_auth)):
    try:
        host = fronius_client.normalize_host(payload.host)
    except fronius_client.FroniusError as e:
        raise HTTPException(400, str(e))
    conn = get_connection()
    conn.execute("INSERT INTO settings (key, value) VALUES ('fronius_settings', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (json.dumps({"host": host, "meter_id": (payload.meter_id or "").strip() or None}),))
    conn.execute("DELETE FROM settings WHERE key='fronius_last_sync'")   # neue Adresse: erst neu testen
    conn.commit()
    conn.close()
    return {"status": "saved", "host": host}


@router.delete("/api/fronius/settings")
def delete_fronius_settings(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    conn.execute("DELETE FROM settings WHERE key IN ('fronius_settings', 'fronius_last_sync')")
    conn.execute("DELETE FROM fronius_snapshots")
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.post("/api/fronius/test")
def test_fronius(session=Depends(auth.require_full_auth)):
    """Liest die Zähler live, ohne etwas zu speichern -- zum Prüfen der Adresse."""
    conn = get_connection()
    s = get_settings(conn) or {}
    conn.close()
    if not s.get("host"):
        raise HTTPException(400, "Bitte zuerst die Adresse speichern.")
    try:
        c = fronius_client.read_counters(s["host"], s.get("meter_id"))
    except fronius_client.FroniusError as e:
        raise HTTPException(502, str(e))
    except Exception as e:
        raise HTTPException(502, f"Unerwarteter Fehler beim Abruf: {type(e).__name__}: {e}")
    conn = get_connection()
    _set_last(conn, "ok", "Verbindungstest erfolgreich")
    conn.close()
    return {"status": "ok", **c}


@router.post("/api/fronius/sync")
def sync_fronius(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    try:
        return do_sync(conn)
    finally:
        conn.close()


@router.get("/api/fronius/last-sync")
def fronius_last_sync(session=Depends(auth.require_full_auth)):
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='fronius_last_sync'").fetchone()
    conn.close()
    return json.loads(row["value"]) if row else {"timestamp": None, "status": None, "message": None}


def start_background_sync(interval_minutes: int = 15):
    """Alle 15 Minuten ein lokaler Abruf (im Heimnetz, ohne Anmeldung, kein
    Sperr-Risiko). Häufig genug, dass der Stand bei Tagesbeginn genau ist."""
    def _loop():
        while True:
            try:
                conn = get_connection()
                try:
                    s = get_settings(conn)
                    if s and s.get("host"):
                        do_sync(conn)
                finally:
                    conn.close()
            except Exception:
                pass
            _time.sleep(interval_minutes * 60)
    threading.Thread(target=_loop, daemon=True).start()
