"""
Zentraler Tresor für die Zugangsdaten der Integrationen (Zappi, Sungrow).

WARUM: Der Datenordner liegt im iCloud-Backup-Ordner -- alles, was in der
Datenbank steht, wandert damit in die Cloud. Passwörter, API-Schlüssel und
Tokens gehören deshalb ins Betriebssystem-Schlüsselbund (macOS-Schlüsselbund,
Windows-Anmeldeinformationsverwaltung), nicht in die Datenbank.

WAS DAS NICHT IST: Passkeys selbst können keine Geheimnisse aufbewahren. Der
Schutz kommt vom Schlüsselbund; die Passkey-Anmeldung bleibt davon getrennt
dafür zuständig, dass nur du an die Einstellungen kommst -- die Endpunkte
geben Geheimnisse ohnehin nie zurück, nur "hinterlegt ja/nein".

REGELN (damit nie ein Zugang verloren geht):
- Ein Geheimnis wird erst aus der Datenbank entfernt, wenn es im Schlüsselbund
  NACHWEISLICH lesbar zurückkommt (schreiben + zurücklesen + vergleichen).
- Gibt es kein funktionierendes Schlüsselbund, bleibt alles wie bisher in der
  Datenbank -- sichtbar gemeldet (status()), nie stillschweigend.
- Löschen nur bei ausdrücklichem None; ein leerer oder fehlender Wert fasst den
  Schlüsselbund-Eintrag nicht an (z.B. wenn er beim Lesen gerade nicht
  erreichbar war, darf ein späteres Speichern ihn nicht mitlöschen).
- Klartext-Dateibackends (keyrings.alt) werden bewusst NICHT benutzt.
"""
import json
import sys
import time
from typing import Optional

SERVICE = "FamilyFinance"

# Welche Felder je Einstellungs-Schlüssel geheim sind.
SECRET_FIELDS = {
    "zappi_credentials": ["hub_password"],
    "sungrow_v1_credentials": ["access_key", "rsa_public", "password", "token"],
    "sungrow_oauth_credentials": ["access_key", "tokens"],
    "sungrow_credentials": ["password"],  # Altbestand (alter Passwort-Weg)
}
# Dynamische Schlüssel: jede Bankverbindung liegt unter "bank_conn_<id>",
# geheim ist dort nur die PIN.
DYNAMIC_SECRET_PREFIXES = {"bank_conn_": ["pin"]}
JSON_FIELDS = {"tokens"}          # Felder, die ein dict/list sind -> als JSON ablegen


def _fields_for(key: str) -> list:
    if key in SECRET_FIELDS:
        return SECRET_FIELDS[key]
    for prefix, fields in DYNAMIC_SECRET_PREFIXES.items():
        if key.startswith(prefix):
            return fields
    return []


def _all_secret_keys(conn) -> list:
    """Feste Integrations-Schlüssel plus alle vorhandenen dynamischen (Bankverbindungen)."""
    keys = list(SECRET_FIELDS.keys())
    for prefix in DYNAMIC_SECRET_PREFIXES:
        rows = conn.execute("SELECT key FROM settings WHERE key LIKE ?", (prefix + "%",)).fetchall()
        keys.extend(r["key"] for r in rows)
    return keys


def delete_all_for_key(conn, key: str):
    """Entfernt beim Löschen einer Bankverbindung auch deren Geheimnisse aus dem
    Schlüsselbund -- sonst bliebe die PIN dort verwaist liegen."""
    be = _get_backend()
    if be is not None:
        for field in _fields_for(key):
            _kc_delete(be, key, field)
    conn.execute("DELETE FROM settings WHERE key=?", (key,))
    conn.commit()
MARKER = "_secrets_in_keychain"   # in der DB: welche Felder im Schlüsselbund liegen

_backend = None
_backend_label = None
_injected = False
_last_failed_probe = 0.0
_last_error = None
_RETRY_AFTER_SECONDS = 30


# ---------- Backend-Auswahl ----------

def set_backend(backend, label: str = "Testspeicher"):
    """Nur für Tests: einen Ersatzspeicher (Schnittstelle wie 'keyring') einspielen."""
    global _backend, _backend_label, _injected, _last_failed_probe, _last_error
    _backend, _backend_label, _injected, _last_failed_probe, _last_error = backend, label, backend is not None, 0.0, None


def reset_backend():
    global _backend, _backend_label, _injected, _last_failed_probe, _last_error
    _backend, _backend_label, _injected, _last_failed_probe, _last_error = None, None, False, 0.0, None


def _label_for(kr) -> str:
    mod = kr.__class__.__module__
    if "macOS" in mod:
        return "macOS-Schlüsselbund"
    if "Windows" in mod:
        return "Windows-Anmeldeinformationsverwaltung"
    if "SecretService" in mod or "kwallet" in mod.lower():
        return "Linux-Schlüsselbund"
    return kr.__class__.__name__


def _get_backend():
    """Liefert ein GEPRÜFT funktionierendes Schlüsselbund oder None. Ein Erfolg
    wird gemerkt; nach einem Fehlschlag wird frühestens nach 30 s erneut
    geprüft (Schlüsselbund kann z.B. direkt nach dem Login noch gesperrt sein).
    Der genaue Fehlschlags-Grund wird in _last_error gemerkt (siehe status()) --
    ein still verschlucktes 'geht nicht' hilft beim Fehlersuchen nicht weiter."""
    global _backend, _backend_label, _last_failed_probe, _last_error
    if _backend is not None:
        return _backend
    if time.time() - _last_failed_probe < _RETRY_AFTER_SECONDS:
        return None
    try:
        import keyring
        from keyring.backends import fail, null
        kr = keyring.get_keyring()
        if isinstance(kr, (fail.Keyring, null.Keyring)) or kr.__class__.__module__.startswith("keyrings.alt"):
            raise RuntimeError(f"kein sicheres Backend gefunden (aktiv: {kr.__class__.__module__}.{kr.__class__.__name__})")
        kr.set_password(SERVICE, "__probe__", "ok")
        if kr.get_password(SERVICE, "__probe__") != "ok":
            raise RuntimeError(f"Probe-Eintrag über {kr.__class__.__module__}.{kr.__class__.__name__} geschrieben, aber nicht lesbar zurückgekommen")
        kr.delete_password(SERVICE, "__probe__")
    except Exception as e:
        _last_failed_probe = time.time()
        _last_error = f"{type(e).__name__}: {e}"
        return None
    _backend, _backend_label, _last_error = kr, _label_for(kr), None
    return _backend


# ---------- Einzelne Einträge ----------

def _name(key: str, field: str) -> str:
    return f"{key}:{field}"


def _kc_get(be, key: str, field: str):
    try:
        raw = be.get_password(SERVICE, _name(key, field))
    except Exception:
        return None
    if raw is None:
        return None
    if field in JSON_FIELDS:
        try:
            return json.loads(raw)
        except ValueError:
            return None
    return raw


def _kc_set(be, key: str, field: str, value) -> bool:
    """Schreiben + zurücklesen + vergleichen -- nur dann gilt es als gesichert."""
    text = json.dumps(value) if field in JSON_FIELDS else str(value)
    try:
        be.set_password(SERVICE, _name(key, field), text)
        return be.get_password(SERVICE, _name(key, field)) == text
    except Exception:
        return False


def _kc_delete(be, key: str, field: str):
    try:
        be.delete_password(SERVICE, _name(key, field))
    except Exception:
        pass  # war nicht vorhanden oder nicht erreichbar -- nichts zu tun


# ---------- Lesen / Schreiben der Einstellungs-JSONs ----------

def _read_raw(conn, key: str) -> Optional[dict]:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return json.loads(row["value"]) if row else None


def _upsert(conn, key: str, data: dict):
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, json.dumps(data)),
    )
    conn.commit()


def read_settings_json(conn, key: str) -> Optional[dict]:
    """Wie bisher das JSON aus der Datenbank -- aber mit den Geheimnissen aus
    dem Schlüsselbund wieder eingefügt. Nicht lesbare Geheimnisse fehlen
    einfach im Ergebnis (nie als leerer Wert, siehe write_settings_json)."""
    data = _read_raw(conn, key)
    if data is None:
        return None
    in_keychain = data.pop(MARKER, [])
    if in_keychain:
        be = _get_backend()
        if be is not None:
            for field in in_keychain:
                value = _kc_get(be, key, field)
                if value is not None:
                    data[field] = value
    return data


def write_settings_json(conn, key: str, data: dict):
    """Speichert das JSON; Geheimnisse gehen ins Schlüsselbund und werden aus dem
    DB-Eintrag entfernt. Regeln: siehe Modul-Kopf."""
    data = dict(data)
    fields = _fields_for(key)
    previous = _read_raw(conn, key) or {}
    marker = set(previous.get(MARKER, []))
    be = _get_backend() if fields else None

    for field in fields:
        if field not in data:
            continue                                   # fehlt -> unangetastet
        value = data[field]
        if value is None:                              # ausdrücklich löschen
            if be is not None:
                _kc_delete(be, key, field)
            marker.discard(field)
            data.pop(field)
        elif value in ("", {}, []):                    # leer -> nichts speichern, nichts löschen
            data.pop(field)
        elif be is not None and _kc_set(be, key, field, value):
            marker.add(field)                          # nachweislich gesichert
            data.pop(field)
        # sonst: kein Schlüsselbund -> bleibt (wie bisher) in der Datenbank

    marker = {f for f in marker if f not in data}
    if marker:
        data[MARKER] = sorted(marker)
    else:
        data.pop(MARKER, None)
    _upsert(conn, key, data)


def secure_all(conn) -> dict:
    """Beim Start: noch im Klartext in der Datenbank liegende Geheimnisse ins
    Schlüsselbund umziehen. Idempotent -- tut nichts, wenn nichts zu tun ist."""
    moved, kept = 0, 0
    be = _get_backend()
    for key in _all_secret_keys(conn):
        fields = _fields_for(key)
        raw = _read_raw(conn, key)
        if raw is None:
            continue
        plain = [f for f in fields if raw.get(f) not in (None, "", {}, [])]
        if not plain:
            continue
        if be is None:
            kept += len(plain)
            continue
        marker = set(raw.get(MARKER, []))
        for field in plain:
            if _kc_set(be, key, field, raw[field]):
                marker.add(field)
                raw.pop(field)
                moved += 1
            else:
                kept += 1
        if marker:
            raw[MARKER] = sorted(marker)
        _upsert(conn, key, raw)
    return {"moved": moved, "kept_in_database": kept, "keychain": _backend_label if be else None}


def status(conn) -> dict:
    """Für die Oberfläche: Wo liegen die Zugangsdaten gerade wirklich?"""
    be = _get_backend()
    plaintext, missing, secured = [], [], []
    for key in _all_secret_keys(conn):
        fields = _fields_for(key)
        raw = _read_raw(conn, key)
        if raw is None:
            continue
        if any(raw.get(f) not in (None, "", {}, []) for f in fields):
            plaintext.append(key)
        listed = raw.get(MARKER, [])
        if listed:
            if be is not None and any(_kc_get(be, key, f) is None for f in listed):
                missing.append(key)
            else:
                secured.append(key)
    return {
        "keychain": _backend_label if be is not None else None,
        "available": be is not None,
        "error": _last_error if be is None else None,
        "python_version": sys.version.split()[0] if be is None else None,
        "in_database_plaintext": plaintext,   # Integrationen mit Klartext in der DB
        "missing_on_this_device": missing,    # laut DB im Schlüsselbund, dort aber nicht da
        "secured": secured,
    }
