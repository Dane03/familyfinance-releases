# Nachtlog

## 2026-10-09 – Security-Review (Nachtlauf, unbeaufsichtigt)

**Rolle:** Security-Reviewer · **Geprüfter Stand:** `master` @ `a42acb3`, Build v315 (= aktuelles Release v315 laut `latest.json`, Code-Repo also aktuell) · **Ergebnis-Build:** v316 (2026-10-09), kein Release gebaut.

### Behoben

1. **Zwei-Faktor-Anmeldung ließ sich mit dem Passwort allein umgehen (hoch).**
   Nach dem Passwort-Schritt (`password_ok`) konnte man jederzeit einen *eigenen* Passkey registrieren
   (`/api/auth/passkey/register/*`) oder ein *eigenes* TOTP-Geheimnis setzen (`/api/auth/totp/setup/*`) und
   bekam damit sofort eine volle Sitzung. Das TOTP-Setup überschrieb dabei sogar das echte Geheimnis
   (Besitzer ausgesperrt). RP-ID/Origin kommen aus Host-/Origin-Header, sind also frei wählbar.
   Neu: `auth.require_factor_enrollment` – mit nur dem Passwort ist Einrichten nur erlaubt, solange **noch gar
   kein** zweiter Faktor existiert (Ersteinrichtung); sonst ist volle Anmeldung nötig (Einstellungen).
   Zusätzlich: TOTP-Login hat jetzt eine Fehlversuchs-Sperre (8 Versuche / 15 min, eigener Zähler, den ein
   erfolgreicher Passwort-Login nicht zurücksetzt) und setzt das Secure-Flag passend zur Verbindung.
   *Test:* TestClient gegen `http://localhost:8420`, vorher/nachher: Angriff vorher 200 + Dashboard 200 und
   TOTP überschrieben; nachher 403/403/401, Original-TOTP intakt; Brute-Force vorher 9×401, nachher 429 ab
   Versuch 9; Ersteinrichtung, TOTP-/Passkey-Einrichtung aus den Einstellungen und UI-Login (Passwort + TOTP,
   Playwright) funktionieren.
2. **Reflektiertes XSS im PDF-Betrachter (hoch)** – `app.py` `/api/documents/pdf-viewer`: `json.dumps(url)` im
   `<script>` maskiert `</script>` nicht. Ein präparierter Link (Cookie ist SameSite=Lax, wird bei
   Link-Navigation mitgeschickt) konnte im eingeloggten Browser beliebiges JS ausführen. Jetzt werden `< > &`
   als `<…` maskiert. *Test:* Playwright vorher `window.__pwned=true`, nachher `false` und `documentUrl`
   unverändert korrekt.
3. **XSS beim Smart-Import (mittel–hoch)** – `frontend/app.js` `renderSmartImportMapping`: Spaltenköpfe und
   Beispielzeile einer importierten CSV/ODS/XLSX gingen ungefiltert in `innerHTML`. Jetzt `escHtml`.
   *Test:* Playwright mit CSV-Kopf `<img onerror>`: vorher ausgelöst (8 `<img>`), nachher 0, Dropdown-Wert
   bleibt exakt der Spaltenname (Zuordnung funktioniert).

Allgemein: `py_compile` (app.py, auth.py), `node --check` (app.js, service-worker.js), `xss.py` grün,
`fk.py` 0 Serverfehler, Server startet, Login funktioniert. Build v315 → v316, Datum 2026-10-09.

### Verhaltensänderung (bitte beachten)
Eine **neue Adresse/ein neues Gerät ohne eigenen Passkey** (z. B. erstmals über die Tailscale-Adresse) kann
nicht mehr direkt nach dem Passwort einen Passkey anlegen, sobald irgendwo schon ein zweiter Faktor existiert.
Weg: an einem eingerichteten Gerät anmelden → Einstellungen → Authenticator-Code (TOTP) einrichten → am neuen
Gerät mit Passwort + TOTP anmelden → dort in den Einstellungen Passkey hinzufügen. Die Fehlermeldung erklärt das.
Bestehende Passkeys/TOTP funktionieren unverändert. Notfall: `reset-password.command` / `Reset-Password.bat`.

### Befunde (nicht behoben)

**Mittel**
- Weitere ungefilterte `innerHTML`-Stellen in `frontend/app.js` (mit `escHtml` nachziehen):
  Lohnabrechnung `employer`/`month` aus PDF (:828), Versicherungsarten (:1234, :1753, :5357–5370),
  Zähler-Anbieter (:3461), Abrechnungsnotiz (:4454, in :4471 korrekt), Einnahmen-Kategorie (:618),
  `categoryOptionsHTML` value-Attribut (:941), Depot ISIN/Assetklasse (:6433f.), Update-Notizen aus
  `latest.json` (:1066–1091), Sungrow-Fehlertexte (:4406–4435), diverse `data.detail`/`ocr_error`
  (:2158, :2184, :4023, :4529, :5040, :5049). Vorschlag: alle in einem Rutsch escapen und `xss.py` erweitern.
- `app.py` `/api/maintenance/apply-app-update` übernimmt `download_url` + `sha256` aus der Anfrage. Nur Pfade
  im Releases-Repo erlaubt, aber damit lässt sich jede **ältere** Version aus dessen Historie einspielen
  (Downgrade auf bekannte Lücken). Wird vom Frontend nicht benutzt → entfernen oder wie
  `_apply_all_updates` nur das Manifest verwenden.
- Keine Content-Security-Policy. Eine CSP (`default-src 'self'`) würde XSS-Reste stark entschärfen; vorher
  Inline-Skripte/-Styles (u. a. PDF-Betrachter) prüfen.

**Niedrig**
- `/api/public/apply-updates` ohne Login: jeder im Heimnetz kann ein (echtes, geprüftes) verfügbares Update
  samt Neustart auslösen → alle Sitzungen abgemeldet. Bewusste Entscheidung, nur zur Kenntnis.
- Lohnabrechnungs-Upload nutzt `file.filename` unbereinigt im Dateipfad (`receipts_routes.py:80`, `:112`);
  Pfad-Traversal scheitert nur zufällig, `/` im Namen ergibt Serverfehler. Wie bei Belegen per `re.sub` bereinigen.
- `auth.begin_passkey_login` verwendet `rp_id=RP_ID` (Konstante) statt der pro Anfrage ermittelten `rp_id` –
  bitte prüfen, ob Passkey-Login über die Tailscale-Adresse nur dank Umgebungsvariable funktioniert.
- WebAuthn-Challenges global in einem Slot, nicht an die Sitzung gebunden; Login-Challenge wird bei Fehlschlag
  nicht verworfen. TOTP ohne Schutz gegen Wiederverwendung desselben Codes.
- Sitzungen sind zustandslos: Logout löscht nur das Cookie, ein kopiertes Token bleibt bis 12 h gültig.
- Fehlversuchs-Sperre pro IP: hinter `tailscale serve` kommen evtl. alle Anfragen von 127.0.0.1 → gemeinsamer Zähler.
- Fehlermeldungen geben Exception-Texte weiter (z. B. `app.py` „PDF konnte nicht gelesen werden: {e}“).
- `secret_store`: ohne Schlüsselbund bleiben Geheimnisse im Klartext in der DB (wird in den Einstellungen angezeigt).

**Geprüft, unauffällig:** SQL durchgehend parametrisiert (dynamische Spalten nur aus Pydantic-Feldern/
Whitelists); Update: SHA-256 wird vor dem Entpacken geprüft, `zipfile.extractall` neutralisiert `..`/absolute
Pfade, `data/` wird nie überschrieben; subprocess nur mit fester Argumentliste; CORS nur eigener Origin;
Cookie HttpOnly + SameSite=Lax + Secure bei HTTPS; Zugangsdaten-Endpunkte geben Passwörter/PIN nicht zurück;
alle Datenendpunkte verlangen volle Anmeldung (ohne Login nur Status, Setup, Login, Logout, Manifest, Update-Check/-Einspielen).

### Offen / braucht Benjamin
- Mit echten Geräten testen (ging nachts nicht): Passkey-Login am Mac (localhost) und iPhone (Tailscale),
  danach Passkey „Weiteres Gerät“ aus den Einstellungen.
- Entscheiden, ob die Verhaltensänderung oben so passt (Alternative: Passkey für neue Adresse nur mit
  Bestätigung von einem bereits angemeldeten Gerät).
- Nach Review: mergen, Release bauen.

### Vorschlag nächster Lauf
Alle oben gelisteten `innerHTML`-Stellen escapen + `xss.py` um Import/Lohnabrechnung/Versicherungsarten
erweitern; `apply-app-update` auf Manifest umstellen; Lohnabrechnungs-Dateinamen bereinigen; CSP vorbereiten.
